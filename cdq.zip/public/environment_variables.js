window.env = {
    REACT_APP_DEV_API: "http://10.22.243.46:8000/"
    // REACT_APP_DEV_API: "http://127.0.0.1:8000/"
}
