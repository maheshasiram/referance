#!/bin/bash
export GIT_TAG=$(git describe --abbrev=0 --tags)
export GIT_COMMITS=$(git rev-list $GIT_TAG..HEAD --count)
export DOCKER_IMAGE_VERSION=$(echo $GIT_TAG | awk -F. '{print $1"."$2+1".0"}')
export DOCKER_IMAGE_VERSION=$(echo $DOCKER_IMAGE_VERSION |awk -F. '{print $1"."$2"."$3+'$GIT_COMMITS'}')
docker build -t 10.22.241.192:8086/docker_pvt_repo/cdq-ui:$DOCKER_IMAGE_VERSION .
DOCKER_IMAGE="10.22.241.192:8086/docker_pvt_repo/cdq-ui:$DOCKER_IMAGE_VERSION"
echo "$CI_COMMIT_SHORT_SHA | $DOCKER_IMAGE" >> $HOME/build_info_cdq_UI.txt
mapfile -t lines <$HOME/build_info_cdq_UI.txt
echo "GitLab Commit ID,Docker Image Name" > $HOME/build_info_cdq_UI.csv
for line in "${lines[@]:1}"; do
  commit_id=$(echo "$line" | cut -d'|' -f1)
  docker_image_name=$(echo "$line" | cut -d'|' -f2)
  echo "$commit_id,$docker_image_name" >> $HOME/build_info_cdq_UI.csv 
done
