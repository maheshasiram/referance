#!/bin/bash
export GIT_TAG=$(git describe --abbrev=0 --tags)
export GIT_COMMITS=$(git rev-list $GIT_TAG..HEAD --count)
export DOCKER_IMAGE_VERSION=$(echo $GIT_TAG | awk -F. '{print $1"."$2+1".0"}')
export DOCKER_IMAGE_VERSION=$(echo $DOCKER_IMAGE_VERSION |awk -F. '{print $1"."$2"."$3+'$GIT_COMMITS'}')
SERVICE_NAME="cdq-ui"
DOCKER_IMAGE="10.22.241.192:8086/docker_pvt_repo/cdq-ui:$DOCKER_IMAGE_VERSION"

if docker service ls | grep -q "\s${SERVICE_NAME}\s"; then
    echo "-----------------------------------------------------"
    echo "Updating existing Docker service '${SERVICE_NAME}'..."
    echo "-----------------------------------------------------"
    docker service update --image "${DOCKER_IMAGE}" --update-failure-action rollback $SERVICE_NAME
else
    echo "-----------------------------------------------------"
    echo "Deploying new Docker service '${SERVICE_NAME}'..."
    echo "-----------------------------------------------------"
    docker service create --name $SERVICE_NAME \
  --publish 8090:8090 \
  --constraint 'node.labels.master==true' \
  --health-cmd "curl -f http://localhost:8090/formsearch || exit 1" \
  --health-interval 20s \
  --health-retries 3 \
  --health-timeout 5s \
  "$DOCKER_IMAGE"
fi

