import openpyxl
with open('/home/gitlab-runner/build_info.txt', 'r') as file:
    lines = file.readlines()

workbook = openpyxl.Workbook()

sheet = workbook.active

sheet['A1'] = 'GitLab Commit ID'
sheet['B1'] = 'Docker Image Name'

for row_num, line in enumerate(lines, start=2):
    data_values = line.strip().split('|')
    for col_num, data_value in enumerate(data_values, start=1):
        sheet.cell(row=row_num, column=col_num, value=data_value)

workbook.save('/home/gitlab-runner/build_info.xlsx')
