#!/bin/bash
COMMIT_ID=$CI_COMMIT_SHA 
DOCKER_IMAGE_NAME=$DOCKER_IMAGE 
echo "GitLab Commit ID: $COMMIT_ID | Docker Image Name: $DOCKER_IMAGE" >> build_info.txt
