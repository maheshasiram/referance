#!/bin/bash
subject="ESlint_Report"
content="Please find the attachment."
recipients=$(echo "$RECIPIENTS" | tr -d '"')
for recipient in "${recipients[@]}"; do
    echo "$content" | mail -s "$subject" -a "report.log" $recipient
done

echo "Emails sent successfully."
echo $RECIPIENTS
