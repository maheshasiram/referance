import { combineReducers } from 'redux';
import { Mappings } from './Mappings';


export default combineReducers({
    Mappings
})