import { Types } from '../constants/Types';
import { outputNodes } from '../constants/IqaRepo';

const _outputNodes = []
outputNodes.map(item => {
    _outputNodes.push({ id: item.form_id, formName: item.form_name })
})
const initialState = {
    isLoading: false,
    inputNodes: [],
    studiesData: [],
    edgesData: [],
    formEdgeMessage: '',
    selectedStudy: '',
    outputNodes: _outputNodes,
    flowNodes: null,
    variablesEdges: [],
    variableEdgeMessage: '',
    variableInputNodes: [],
    variableOutputNodes: [],
    isMapped: false,
    isStudyPopup: false,
    selectedForm: '',
    isToast: false,
    isVariableToast: false,
    originalFormId: ''
}

export const Mappings = (state = initialState, action) => {
    switch (action.type) {
        case Types.ON_SET_LOADER:
            return { ...state, isLoading: action.payload }
        case Types.ON_INPUTNODES_FLOW_NODES:
            return { ...state, inputNodes: action.payload }
        case Types.ON_OUTPUTNODES_FLOW_NODES:
            return { ...state, outputNodes: action.payload }
        case Types.ON_UPDATE_FLOW_NODES:
            return { ...state, flowNodes: action.payload }
        case Types.GET_STUDY_INFO:
            return {
                ...state,
                studiesData: action.payload,
            }
        case Types.GET_FORMS_MAPPING:
            return {
                ...state,
                edgesData: action.payload,
                formEdgeMessage: action.message,
            }
        case Types.SELECTED_STUDY:
            return {
                ...state,
                selectedStudy: action.payload,
            }
        case Types.GET_VARIABLES_INFO:
            return {
                ...state,
                variableInputNodes: action.payload,
            }
        case Types.GET_VARIABLE_MAPPING:
            return {
                ...state,
                variablesEdges: action.payload,
                variableEdgeMessage: action.message
            }

        case Types.GET_VARIABLE_OUTPUT_NODES:
            return { ...state, variableOutputNodes: action.payload }

        case Types.OPEN_FLOW_POPUP_FOR_STUDIES:
            return { ...state, isStudyPopup: action.payload }
        case Types.IS_FORM_NODES_MAPPED:
            return { ...state, isMapped: action.payload }
        case Types.SELECTED_FORM:
            return { ...state, selectedForm: action.payload }
        case Types.IS_MAP_FORM_TOAST_DISABLE:
            return { ...state, isToast: false }
        case Types.IS_MAP_FORM_TOAST_ENABLE:
            return { ...state, isToast: true }
        case Types.IS_MAP_VARIABLE_TOAST_DISABLE:
            return { ...state, isVariableToast: false }
        case Types.IS_MAP_VARIABLE_TOAST_ENABLE:
            return { ...state, isVariableToast: true }
        case Types.ORIGINAL_FORM_ID:
            return { ...state, originalFormId: action.payload }

        default:
            return { ...state }
    }
}

