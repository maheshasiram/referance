import React from "react";
// import CircularProgress from '@mui/material/CircularProgress';
// import Backdrop from '@mui/material/Backdrop';
import './Loader.css';
function Loader() {
    return (
        <div className='overlay-box'>
        <div id="nest2"></div>
        </div>
    )
}

export default Loader;
