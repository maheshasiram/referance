
import { Position } from 'reactflow';

export const NodesFlow=(inputNodes,outputNodes)=>{

  const defaultNodeStyle = {
    // border: '2px solid #ff0071',
    // background: 'white',
    // borderRadius: 20,
    borderWidth: '1px',
    borderStyle: 'solid',
    borderColor: '#0e2740 !important',
    // color:'#0e2740 !important',
    padding: '10px',
    borderRadius: '3px',
    minWidth: '150px',
    fontSize: '12px',
    textAlign: 'center',
    // backgroundColor: 'red',
    width:'auto'
  };
       const nodeDefaults = {
         sourcePosition: Position.Right,
         targetPosition: Position.Left,
       };
       let _initNodes = [...[], ...inputNodes]
       let _outputNodes = [...[], ...outputNodes]

        var updatedNodes = [{
         id: 'iGroup',
         type: 'group',
         data: { label: 'FORMS' },
         position: { x: -100, y: 0 },
         draggable: false,
         style: {
           width: 250,
           height: 0,
         },
         ...nodeDefaults
       },
       {
        id: 'oGroup',
        type: 'group',
        data: { label: 'FORMS' },
        position: { x: 700, y: 0 },
        draggable: false,
        style: {
          width: 200,
          height: 0,
        },
        ...nodeDefaults
      }
      ];

       _initNodes.map((nodeitem, index) =>{
         updatedNodes.push(
          { id: nodeitem,
           type: 'custom',
           data: { label: nodeitem },
           position: { x: 10, y: 10+(index*90) },
           parentNode: 'iGroup',
           extent: 'parent',
           draggable: false,
           style: defaultNodeStyle,
           ...nodeDefaults
           })
         updatedNodes[0].style.height= 90*(_initNodes.length)
       }); 

       _outputNodes.map((nodeitem, index) =>{
        updatedNodes.push(
         { id: "output"+nodeitem.id,
          type: 'tooltip',
          data: { label: nodeitem.id ,formName:nodeitem.formName, toolbarPosition: Position.Right},
          position: { x: 10, y: 10+(index*60) },
          parentNode: 'oGroup',
          extent: 'parent',
          draggable: false,
          style:defaultNodeStyle,
          ...nodeDefaults
          })
        updatedNodes[1].style.height= 60*(_outputNodes.length)
        // updatedNodes[0].position.y =  (updatedNodes[1].style.height)/2
        // updatedNodes[1].position.y =  (updatedNodes[1].style.height)/2

      

      }); 

       return updatedNodes 
      }

  
