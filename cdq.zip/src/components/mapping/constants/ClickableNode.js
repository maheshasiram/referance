import React, { memo } from 'react';
import { Handle, Position } from 'reactflow';
import { useDispatch, useSelector } from 'react-redux';
import { getVariablesInfo } from '../../../actions/actions';
import { useNavigate } from 'react-router-dom';
import { outputNodes } from '../../../constants/IqaRepo';
import { Types } from '../../../constants/Types';
import ModelPopoup from '../helpers/ModelPopoup';
import { getFormsEdges } from '../../../actions/actions';

function CustomNode({ id, data }) {
    const dispatch = useDispatch();
    const { selectedStudy, isMapped, edgesData } = useSelector(state => state.Mappings)
    let navigate = useNavigate();

    const onNodeClick = (id) => {
        const variableOutputNodes = []
        // dispatch({ type: Types.OPEN_FLOW_POPUP_FOR_STUDIES, payload:true })

        if (!isMapped) {
            dispatch(getFormsEdges({ study: selectedStudy, raw_form: id, compare_id: true, pre_processed: false }, (response) => {
                let target_id = response.output[0].original
                dispatch({ type: Types.ORIGINAL_FORM_ID, payload: target_id })
                outputNodes.map((item) => {
                    if (item.form_id === target_id) {
                        variableOutputNodes.push(
                            item.variables.map((id) => id.id)
                        )
                    }
                });
            }))
        }
        else {
            let original_id = ''
            edgesData.map((item) => {
                if (item.input === id) {
                    original_id = item.original
                }
            })
            dispatch({ type: Types.ORIGINAL_FORM_ID, payload: original_id })
            outputNodes.map((item) => {
                if (item.form_id === original_id) {
                    variableOutputNodes.push(
                        item.variables.map((id) => id.id)
                    )
                }
            });

        }
        dispatch(getVariablesInfo({ study: selectedStudy, raw_form: id }))
        dispatch({ type: Types.GET_VARIABLE_OUTPUT_NODES, payload: variableOutputNodes })


        setTimeout(() => {
            navigate('/variableMapping')
        }, 1000)

        dispatch({ type: Types.SELECTED_FORM, payload: id })
        dispatch({ type: Types.GET_VARIABLE_MAPPING, payload: [] })
    }


    return (
        <div className="px-4 py-2 shadow-md rounded-md bg-white border-2 border-stone-400">
            <div className="flex">
                <div className="rounded-full w-12 h-12 flex justify-center items-center bg-gray-100">

                    <ModelPopoup
                        label={data.label}
                        nodeId={id}
                        onVariblemaped={onNodeClick}
                    />
                </div>
                {/* <div className="ml-2">
          <div className="text-lg font-bold">{data.label}</div>
          <div className="text-gray-500">{data.label}</div>
        </div> */}
            </div>

            {/* <Handle type="target" position={Position.Left} className="w-16 !bg-teal-500" /> */}
            <Handle type="source" position={Position.Right} className="w-16 !bg-teal-500" />
        </div>
    );
}

export default memo(CustomNode);