import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import ReactFlow, {
  MiniMap, addEdge, applyEdgeChanges, ControlButton, useReactFlow, ReactFlowProvider,
  applyNodeChanges, Controls, updateEdge,
} from 'reactflow';
import 'reactflow/dist/style.css';
import 'reactflow/dist/base.css';
import { useDispatch, useSelector } from 'react-redux';
import { NodesFlow } from './constants/nodes.js';
import { Types } from '../../constants/Types.js';
import { getFormsEdges } from '../../actions/actions.js';
import './Mapper.css'
import TooltipNode from './constants/TooltipNode.js';
import ClickableNode from './constants/ClickableNode.js';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import Select from '@mui/material/Select';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import AlertTitle from '@mui/material/AlertTitle';

const rfStyle = {
  backgroundColor: 'white',
};

const nodeTypes = {
  custom: ClickableNode,
  tooltip: TooltipNode,
  // selectable:true	
};

function Flow() {
  const { setViewport } = useReactFlow();

  const dispatch = useDispatch();
  const { inputNodes, outputNodes, isToast, formEdgeMessage, selectedStudy, edgesData } = useSelector((state) => state.Mappings);
  const edgeUpdateSuccessful = useRef(true);
  const [nodes, setNodes] = useState(null);
  // const [tempinodes, setTempinodes] = useState(null)
  const initialEdges = []
  const [edges, setEdges] = useState(initialEdges);
  const [sortedInodes, setSortedinodes] = useState(null)
  const [sortedOnodes, setSortedonodes] = useState(null)
  const [disableConnectDialog, setDisableConnectDialog] = useState(false)
  const [manuallyMapped, setManuallyMapped] = useState([])
  const [edgeColour, setEdgeColour] = useState('all');
  const [tempEdges, setTempEdges] = useState(initialEdges);
  const [fromNode, setFromNode] = useState('')
  const [toNode, setToNode] = useState('')
  const [enableToast, setEnableToast] = useState(false)
  const [fromNodesID, setFromNodesId] = useState([])
  const axis = {
    vertical: 'top',
    horizontal: 'right',
  }
  // const maxBy = (arr, fn) => Math.max(...arr.map(typeof fn === 'function' ? fn : val => val[fn]));

  const onButtonClick = () => {
    dispatch(getFormsEdges({ study: selectedStudy, raw_form: '', compare_id: true, pre_processed: false }))

    dispatch({ type: Types.IS_FORM_NODES_MAPPED, payload: true });

  }

  const onResetClick = () => {

    let flowNodes = NodesFlow(inputNodes.sort(), outputNodes.sort())

    // dispatch({type:Types.GET_FORMS_MAPPING, payload:[]})

    setNodes(flowNodes)
    setEdges([])
    setTempEdges([])
    setManuallyMapped([])
    setFromNodesId([])
    setEdgeColour('all')
  }

  const onPaneClick = () => {

    if (sortedInodes != null) {
      var flowNodes = NodesFlow(sortedInodes, sortedOnodes)
    }
    else {
      flowNodes = NodesFlow(inputNodes.sort(), outputNodes.sort())
    }

    setNodes(flowNodes)
    const updatedEdges = edges.map((item) => {
      item.animated = false
      return item;
    })

    setEdges(updatedEdges)

  }

  const onEdgeClick = (edge) => {

    if (sortedInodes != null) {
      var flowNodes = NodesFlow(sortedInodes, sortedOnodes)
    }
    else {
      flowNodes = NodesFlow(inputNodes.sort(), outputNodes.sort())
    }
    const nodeResult = flowNodes.map((node) => {
      if (node.id === edge.source) {
        node.style = {
          ...node.style, ...{
            boxShadow: "2px 12px 15px #999",
          }
        };
      }
      else if (node.id === edge.target) {
        node.style = {
          ...node.style, ...{
            boxShadow: "2px 12px 15px #999",
            backgroundColor: "#364479",
            color: "white"
          }
        };
      }
      else {
        node.style = {
          ...node.style, ...{
            opacity: 0.4
          }
        };
      }
      return node;
    })
    setNodes(nodeResult)

    const updatedEdges = edges.map((item) => {
      item.animated = false
      if (item.id == edge.id) {
        item.animated = true
      }
      return item;
    })

    setEdges(updatedEdges)

  }


  const onFitViewClick = useCallback(() => {
    setViewport({ x: 250, y: 10, zoom: 0.6 }, { duration: 800 });
  }, [setViewport]);

  const handleSelect = (e) => {
    setEdgeColour(e.target.value)
    var filteredArr = (e.target.value === 'all') ? tempEdges : tempEdges.filter(function (el) {
      return el.style.stroke == e.target.value
    })
    setEdges(filteredArr)
  }

  const dynamicSort = (property) => {
    var sortOrder = 1;
    if (property[0] === "-") {
      sortOrder = -1;
      property = property.substr(1);
    }
    return function (a, b) {
      if (sortOrder == -1) {
        return b[property].localeCompare(a[property]);
      } else {
        return a[property].localeCompare(b[property]);
      }
    }
  }

  useEffect(() => {
    outputNodes.sort(dynamicSort("id"));

    let flowNodes = NodesFlow(inputNodes.sort(), outputNodes.sort())

    setNodes(flowNodes);
    // setTempinodes(flowNodes);

    let mappedEdges = []
    let tempEdges = []
    let _manuallyMapped = [...[], ...manuallyMapped]
    // let _manuallyMapped = []

    if (manuallyMapped.length) {
      _manuallyMapped && _manuallyMapped.map((item, index) => {
        edgesData && edgesData.map((i, _index) => {
          if (item.source == i.input && (!item.id.includes('reactflow__edge'))) {
            _manuallyMapped.splice(index, 1)
          }
          else if (item.source === i.input) {
            edgesData.splice(_index, 1)
            setEnableToast(true)
          }
        })
      })
      setManuallyMapped(_manuallyMapped)

    }

    if (edgesData.length) {
      edgesData.map((item) => {
        tempEdges.push(item)
      })
    }
    tempEdges && tempEdges.map((item) => {
      mappedEdges.push({
        id: item.input + "_" + item.original,
        source: item.input,
        target: 'output' + item.original,
        style: (item.similarity == 1) ? { stroke: 'green' } : (item.similarity == 0.9) ? { stroke: 'orange' } : { stroke: 'red' }
      })
    })
    if (_manuallyMapped.length) {
      _manuallyMapped.map((item) => {
        mappedEdges.push(item)
      })
    }

    setEdges(mappedEdges);
    setTempEdges(mappedEdges);
    setManuallyMapped(mappedEdges)

  }, [inputNodes, edgesData]);


  const sortNodes = () => {
    const arr1 = inputNodes;
    const arr2 = edges.map((item) => item.source)
    const outputNodearray = outputNodes
    const arr3 = edges.map((item) => item.target.substr(6))
    const uniqObj = new Set(arr3)
    const uniqInputObj = new Set(arr2)


    const sortingFun = (resetArray, uniqueObject) => {
      const Array1 = resetArray.slice(-(uniqueObject.size))
      const Array2 = resetArray.slice(0, (resetArray.length - uniqueObject.size))
      const sortedarray = [...Array1, ...Array2]
      return sortedarray
    }

    const sortByReference = (arr1, arr2) => {

      arr1.sort((a, b) => {
        return arr2.indexOf(a) - arr2.indexOf(b);
      });
    };

    

    const sortArray = (arr1, arr2) => {
      arr2.sort((a, b) => {

        const aKey = Object.values(a)[0];
        const bKey = Object.values(b)[0];

        return arr1.indexOf(aKey) - arr1.indexOf(bKey);
      });
    };
    // sortArray(arr1, arr2);


    if(edges.length !=0){
      console.log("inside if")
      sortByReference(arr1, arr2);
      let sortedIarray = sortingFun(arr1, uniqInputObj)
      setSortedinodes(sortedIarray)


      sortArray(arr3, outputNodearray);
      let sortedOarray = sortingFun(outputNodearray, uniqObj)
      setSortedonodes(sortedOarray)
  
      let flowNodes = NodesFlow(sortedIarray, sortedOarray)
      setNodes(flowNodes)
    }
 
  
  }

  const onNodesChange = useCallback(
    (changes) => setNodes((nds) => applyNodeChanges(changes, nds)),
    [setNodes]
  );
  const onEdgesChange = useCallback(
    (changes) => setEdges((eds) => applyEdgeChanges(changes, eds)),
    [setEdges]
  );
  const onConnect = useCallback(
    (connection) => {
      setFromNode(connection.source)
      setToNode(connection.target.substr(6))
      setEdges((eds) => addEdge(connection, eds))
      setDisableConnectDialog(true);
    },
    [setEdges],

  );

  // refference
  // const [nodes, setNodes, onNodesChange] = useNodesState(null);
  // const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);
  // const onConnect = useCallback((params) => setEdges((els) => addEdge(params, els)), []);

  const onEdgeUpdateStart = useCallback(() => {
    edgeUpdateSuccessful.current = false;
  }, []);

  const onEdgeUpdateEnd = useCallback((_, edge) => {
    if (!edgeUpdateSuccessful.current) {
      setEdges((eds) => eds.filter((e) => e.id !== edge.id));
      setManuallyMapped((eds) => eds.filter((e) => e.id !== edge.id));
    }
    edgeUpdateSuccessful.current = true;
  }, []);

  const onEdgeUpdate = useCallback((oldEdge, newConnection) => {
    edgeUpdateSuccessful.current = true;
    setEdges((els) => updateEdge(oldEdge, newConnection, els));
  }, []);

  const onManualConnect = () => {
    let tempArr = []
    let filtered_edges = edges.filter(function (el) { return el.source !== fromNode || el.id.includes('reactflow__edge'); });
    const updatedEdges = filtered_edges.map((item) => {
      if (item.id.includes('reactflow__edge')) {
        item.style = { strokeWidth: 2, stroke: 'black' }
        tempArr.push(item.source)
      }
      return item;
    })
    setFromNodesId(tempArr)
    setTempEdges(updatedEdges)
    setManuallyMapped(updatedEdges)
    setEdges(updatedEdges)
    setDisableConnectDialog(false)
  }

  const hideDisableProductFooter = () => {
    let new_edges = edges.slice(0, edges.length - 1)
    setEdges(new_edges)
    setDisableConnectDialog(false);
  }

  const disableConnectDailogFooter = (
    <React.Fragment>
      <Button label="No" icon="pi pi-times" className="p-button-text" onClick={hideDisableProductFooter} />
      <Button label="Yes" icon="pi pi-check" className="p-button-text" onClick={onManualConnect} />
    </React.Fragment>
  );

  const Alert = React.forwardRef(function Alert(props, ref) {
    return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
  });

  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setEnableToast(false);
  };
  const { vertical, horizontal } = axis;

  // const nodeTypes = useMemo(() => ({ type: 'input' }), []);

  const proOptions = { hideAttribution: true };

  const edgeTypes = useMemo(() => ({ deletable: true, animated: true }), []);
  return (

    <div style={{ paddingLeft: "10px" }}>
      <Snackbar anchorOrigin={{ vertical, horizontal }} open={enableToast} autoHideDuration={5000} onClose={handleClose} key={vertical + horizontal}>
        <Alert onClose={handleClose} severity="warning" sx={{ width: '100%' }}>
          <AlertTitle>Warning</AlertTitle>
          <strong>{fromNodesID.join(' ')}</strong> did not map automatically because already mapped.
        </Alert>
      </Snackbar>

      <div id="FormToast" className={isToast ? 'show' : ''} >
        <div id="Formimg">Message:</div>
        <div id="Formdesc">{formEdgeMessage}</div>
      </div>

      <div>
        <h4
          style={{ marginBottom: 0, height: "50px", display: "flex", padding: "10px" }}
        >Study Form Mapping</h4></div>

      <div style={{ textAlign: "left" }}>
        <FormControl sx={{ m: 1, minWidth: 150 }}>
          <InputLabel id="demo-simple-select-label">
            Edge Colour
          </InputLabel>
          <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            value={edgeColour}
            label="EdgeColour"
            onChange={handleSelect}
          >
            <MenuItem value="all">All</MenuItem>
            <MenuItem value="red">Red</MenuItem>
            <MenuItem value="orange">Amber</MenuItem>
            <MenuItem value="green">Green</MenuItem>
            <MenuItem value="black">Manual</MenuItem>

          </Select>
        </FormControl>
      </div>

      <Dialog visible={disableConnectDialog} style={{ width: '450px' }} header="Confirm"
        modal footer={disableConnectDailogFooter} onHide={hideDisableProductFooter}>
        <div className="confirmation-content">
          <i className="pi pi-exclamation-triangle mr-3" style={{ fontSize: '2rem', color: "red" }} /> &nbsp;&nbsp;
          <div className="confirmation-message">Are you sure, you want to map {fromNode}  to  {toNode}?</div>
        </div>
      </Dialog>

      <table id="mappingHeader">
        <tbody>
          <tr>
            <th style={{ maxWidth: "60px", minWidth: "50px" }}>{selectedStudy.trim()}</th>
            <th>IqaRepo</th>
          </tr>
        </tbody>
      </table>

      <div style={{ height: "76vh" }}>
        {nodes && <ReactFlow
          nodes={nodes}
          edges={edges}
          edgeTypes={edgeTypes}
          nodeTypes={nodeTypes}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          fitView
          snapToGrid
          style={rfStyle}
          onEdgeUpdate={onEdgeUpdate}
          onEdgeUpdateStart={onEdgeUpdateStart}
          onEdgeUpdateEnd={onEdgeUpdateEnd}
          // attributionPosition="top-right"
          proOptions={proOptions}
          onEdgeClick={(event, edge) => onEdgeClick(edge)}
          onPaneClick={() => onPaneClick()}
        >

          {/* <Background /> */}
          <MiniMap nodeStrokeWidth={3} zoomable pannable ariaLabel="Layout" />
          <Controls onFitView={() => onFitViewClick()}>
            <ControlButton onClick={() => sortNodes()}>
              <div><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-sort-down" viewBox="0 0 16 16">
                <path d="M3.5 2.5a.5.5 0 0 0-1 0v8.793l-1.146-1.147a.5.5 0 0 0-.708.708l2 1.999.007.007a.497.497 0 0 0 .7-.006l2-2a.5.5 0 0 0-.707-.708L3.5 11.293V2.5zm3.5 1a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zM7.5 6a.5.5 0 0 0 0 1h5a.5.5 0 0 0 0-1h-5zm0 3a.5.5 0 0 0 0 1h3a.5.5 0 0 0 0-1h-3zm0 3a.5.5 0 0 0 0 1h1a.5.5 0 0 0 0-1h-1z" />
              </svg></div>
            </ControlButton>
          </Controls>
        </ReactFlow>

        }

      </div>
      <div style={{ float: "right", paddingTop: "10px", marginBottom: "10px" }}>
        <button type="button" onClick={() => onButtonClick()} style={{ width: 'auto', backgroundColor: '#435597' }}
          className="btn btn-success">  Map forms </button>
        <button type="button" onClick={() => onResetClick()} style={{ width: 'auto', backgroundColor: '#435597', marginLeft: "10px" }}
          className="btn btn-success">  Reset </button>
      </div>
    </div >

  );
}

function FlowWithProvider(props) {
  return (
    <ReactFlowProvider>
      <Flow {...props} />
    </ReactFlowProvider>
  );
}

export default FlowWithProvider;