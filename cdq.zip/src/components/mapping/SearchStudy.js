import React, { useEffect } from "react";
import { useDispatch, useSelector } from 'react-redux';
import LazyAutocomplete from "../../helpers/LazyAutocomplete";
import { useNavigate } from 'react-router-dom';
import { Types } from "../../constants/Types";

import { getFormsMapping, getStudiesData } from "../../actions/actions";

function Formsearch() {
    const dispatch = useDispatch();
    const { studiesData } = useSelector(state => state.Mappings)
    const [study, setStudy] = React.useState('')

    useEffect(() => {
        dispatch(getStudiesData())
    }, []);

    let navigate = useNavigate();

    const onSubmit = () => {
        dispatch(getFormsMapping({ study: study }))
        navigate('/subflow')
        dispatch({ type: Types.SELECTED_STUDY, payload: study })
        dispatch({type:Types.GET_FORMS_MAPPING, payload:[]})
        dispatch({type:Types.GET_VARIABLE_MAPPING, payload:[]})
        
    }

    const onInputChangeHandler = (e, value) => {
        setStudy(value)
    }

    return (
        <div style={{paddingLeft:'10px'}}  >
            <div className="formheader">
                <h3>Search Study</h3>
            </div>
            <div>
                <div className="element multi-btn-element">
                    <LazyAutocomplete
                        values={studiesData && studiesData.sort()}
                        // onSubmitHander={onPlatformSubmit}
                        // onResetFilters={onResetFilters}
                        placeholder="Platform"
                        onInputChange={(e, value) => onInputChangeHandler(e, value)}
                    // reset={reset}
                    // onClear = {onPlatformClear}
                    />
                </div>
            </div>
            <div style={{width:'20%', paddingLeft:"20%", paddingTop:"10px"}} className="autocomplete justify-content-start d-inline-flex align-items-start">
                        <button className="btn btn-primary"
                            style={{ height: 35, fontSize: 14, lineHeight: '14px', fontWeight: 600, background:"#1C4E80"}}
                            type="button" onClick={onSubmit}> Submit </button>
                    </div>

        </div>

    )

}

export default Formsearch;