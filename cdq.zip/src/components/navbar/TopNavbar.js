import InductiveLogo from "../../constants/Inductivelogo";

function TopNavbar(props) {

    return (
        <div className="sticky-top">
            <nav className="navbar navbar-expand-lg navbar-light top-navbar" style={{ padding: "10px",height:"50px"}}>
                <button
                    className={`btn-toggler navbar-toggler toggle-collapse btn-top-0 ${props.menuShow ? "show" : ""}`}
                    id="toggle-button"
                    type="button"
                    onClick={props.menuButtonClick}
                >
                    <div className="mainMenu">
                        <div></div>   <div></div>    <div></div>
                    </div>
                </button>
                <div id="dash_header">
                    <InductiveLogo/>
                    
                    </div>

            </nav>

        </div>

    )

}

export default TopNavbar;