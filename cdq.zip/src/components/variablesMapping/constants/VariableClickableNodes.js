import React, { memo } from 'react';
import { Handle, Position } from 'reactflow';
import VariablesPopup from '../helpers/VariablesModalPopup';

function VariableClickableNodes({ id, data }) {
    return (
        <div className="px-4 py-2 shadow-md rounded-md bg-white border-2 border-stone-400">
            <div className="flex">
                <div className="rounded-full w-12 h-12 flex justify-center items-center bg-gray-100">

                    <VariablesPopup
                        label={data.label}
                        nodeId={id}
                    />
                </div>
            </div>
            <Handle type="source" position={Position.Right} className="w-16 !bg-teal-500" />
        </div>
    );
}

export default memo(VariableClickableNodes);