
const domain =  `${window.env.REACT_APP_DEV_API}iqa/v1/cdq/`



export const request = {
    StudyInformation: {
        studies: (`${domain}studies`),
    },
    FormsInformation: {
        forms: (`${domain}forms`),
        mapping: (`${domain}forms/mapping`),

    },
    VariableInformation: {
        variables: (`${domain}variables`),
        variablesMapping: (`${domain}variables/mapping`),
    }
}
