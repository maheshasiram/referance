import axios from 'axios';

export const fetch = (request) => {
    const options = {
        method: request.method,
        url: request.url,
        data: request.data,
        timeout: (60 * 2 * 1000),
        headers: request.headers,
        responseType: request.responseType,
    };
    return axios(options)
        .then(response => {
            return response;
        });
}