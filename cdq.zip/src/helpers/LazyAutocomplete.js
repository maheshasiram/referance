
import TextField from '@mui/material/TextField';
import Autocomplete from '@mui/material/Autocomplete';
import * as React from 'react';

function LazyAutocomplete(props) {

  return (

    <Autocomplete
      disablePortal
      id="combo-box-demo"
      options={props.values}
      sx={{ width: 300 }}
      onInputChange={props.onInputChange}
      renderInput={(params) => <TextField {...params} label="Study Forms" />}
    />

  )

}

export default LazyAutocomplete;

