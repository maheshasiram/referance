import './App.css';
import React from 'react';
import TopNavbar from './components/navbar/TopNavbar';
import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom';
import Formsearch from './components/mapping/SearchStudy';
import FlowWithProvider from './components/mapping/FormMapping';
import Loader from './components/loader/Loader';
import { useSelector } from 'react-redux';
import VariableFlowWithProvider from './components/variablesMapping/VariablesMapping';

function App() {

  const [menuShow, setMenuShow] = React.useState(true)
  const [isColapse, setisColapse] = React.useState(true)
  const [isColapse1, setisColapse1] = React.useState(true)
  const [isColapse2, setisColapse2] = React.useState(true)
  const [isColapse3, setisColapse3] = React.useState(true)
  const { isLoading } = useSelector(state => state.Mappings)
  const { inputNodes } = useSelector((state) => state.Mappings);

  const menuButtonClick = () => {
    setMenuShow((prevState) => !prevState);
  }

  const onChangeHandler = (index) => {
    if (index === 'isColapse') {
      setisColapse(!isColapse)
      setisColapse1(true)
      setisColapse2(true)
      setisColapse3(true)
    }
    else if (index === 'isColapse1') {
      setisColapse1(!isColapse1)
      setisColapse(true)
      setisColapse2(true)
      setisColapse3(true)
    }
    else if (index === 'isColapse2') {
      setisColapse2(!isColapse2)
      setisColapse1(true)
      setisColapse(true)
      setisColapse3(true)
    }
    else {
      setisColapse3(!isColapse3)
      setisColapse1(true)
      setisColapse2(true)
      setisColapse(true)
    }

  }

  return (

    <div className='App_main' style={{ "height": "100vh" }}>

      <BrowserRouter>
        <TopNavbar
          menuButtonClick={menuButtonClick}
          menuShow={menuShow}
        />
        <div className="main-class">
          <nav className={`col-md-3 col-lg-2 d-md-block  sidebar p-0 full-screen maximized ${!menuShow ? "minimized" : ""}`} id="sidebar">
            <div className="nav flex-column nav-custom-bar" data-toggle="collapse" aria-expanded="false" id="accordian">
              <ul>
                <li className={`${isColapse ? '' : "active"}`}>
                  <h3>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#6F7377" className="bi bi-house" viewBox="0 0 16 16">
                      <path d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L2 8.207V13.5A1.5 1.5 0 0 0 3.5 15h9a1.5 1.5 0 0 0 1.5-1.5V8.207l.646.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5ZM13 7.207V13.5a.5.5 0 0 1-.5.5h-9a.5.5 0 0 1-.5-.5V7.207l5-5 5 5Z" />
                    </svg>
                    <a href="#" onClick={() => onChangeHandler('isColapse')}><i className="fa fa-lg fa-tachometer"></i>Home</a>

                  </h3>
                  <ul>
                    <li><NavLink to="/">Home</NavLink></li>
                    <li><a href="#">Search</a></li>
                  </ul>
                </li>
                <li className={`${isColapse1 ? '' : "active"}`}>
                  <h3>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#6F7377" className="bi bi-arrow-left-right" viewBox="0 0 16 16">
                      <path fillRule="evenodd" d="M1 11.5a.5.5 0 0 0 .5.5h11.793l-3.147 3.146a.5.5 0 0 0 .708.708l4-4a.5.5 0 0 0 0-.708l-4-4a.5.5 0 0 0-.708.708L13.293 11H1.5a.5.5 0 0 0-.5.5zm14-7a.5.5 0 0 1-.5.5H2.707l3.147 3.146a.5.5 0 1 1-.708.708l-4-4a.5.5 0 0 1 0-.708l4-4a.5.5 0 1 1 .708.708L2.707 4H14.5a.5.5 0 0 1 .5.5z" />
                    </svg>
                    <a href="#" onClick={() => onChangeHandler('isColapse1')}><i className="fa fa-lg fa-tasks"></i>Mapping</a></h3>
                  <ul>
                    <li><NavLink to="/mapping">Mapping</NavLink></li>
                    <li >
                      <NavLink to="/formsearch">Formsearch</NavLink>

                    </li>
                  </ul>
                </li>
                <li className={`${isColapse2 ? '' : "active"}`}>
                  <h3>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#6F7377" className="bi bi-file-text" viewBox="0 0 16 16">
                      <path d="M5 4a.5.5 0 0 0 0 1h6a.5.5 0 0 0 0-1H5zm-.5 2.5A.5.5 0 0 1 5 6h6a.5.5 0 0 1 0 1H5a.5.5 0 0 1-.5-.5zM5 8a.5.5 0 0 0 0 1h6a.5.5 0 0 0 0-1H5zm0 2a.5.5 0 0 0 0 1h3a.5.5 0 0 0 0-1H5z" />
                      <path d="M2 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V2zm10-1H4a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1z" />
                    </svg>
                    <a href="#" onClick={() => onChangeHandler('isColapse2')}><i className="fa fa-lg fa-calendar"></i>About</a></h3>
                  <ul>
                    <li> <NavLink to="/about">About</NavLink></li>
                    <li><a href="#">Current Week</a></li>

                  </ul>
                </li>
                <li className={`${isColapse3 ? '' : "active"}`}>
                  <h3>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#6F7377" className="bi bi-bookmark-star" viewBox="0 0 16 16">
                      <path d="M7.84 4.1a.178.178 0 0 1 .32 0l.634 1.285a.178.178 0 0 0 .134.098l1.42.206c.145.021.204.2.098.303L9.42 6.993a.178.178 0 0 0-.051.158l.242 1.414a.178.178 0 0 1-.258.187l-1.27-.668a.178.178 0 0 0-.165 0l-1.27.668a.178.178 0 0 1-.257-.187l.242-1.414a.178.178 0 0 0-.05-.158l-1.03-1.001a.178.178 0 0 1 .098-.303l1.42-.206a.178.178 0 0 0 .134-.098L7.84 4.1z" />
                      <path d="M2 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v13.5a.5.5 0 0 1-.777.416L8 13.101l-5.223 2.815A.5.5 0 0 1 2 15.5V2zm2-1a1 1 0 0 0-1 1v12.566l4.723-2.482a.5.5 0 0 1 .554 0L13 14.566V2a1 1 0 0 0-1-1H4z" />
                    </svg>
                    <a href="#" onClick={() => onChangeHandler('isColapse3')}><i className="fa fa-lg fa-heart"></i>Favourites</a></h3>
                  <ul>
                    <li><a href="#">Global favs</a></li>
                    <li><a href="#">My favs</a></li>
                  </ul>
                </li></ul>

            </div>


          </nav>
          <main className={`col-md-9 ms-sm-auto col-lg-10 px-md-0 expand ${!menuShow ? "main-colapse" : ""}`}>
            <div className={isLoading ? 'parentDisable' : ''}>
              {isLoading && <Loader />}
            </div>
            <Routes>


              <Route path="/" element={<h1>Home</h1>} />
              {/* <Route path="/mapping" element={<Mapper />} /> */}
              <Route path="/subflow" element={inputNodes.length !== 0 ? <FlowWithProvider /> : <Formsearch />} />
              <Route path="/about" element={<h1>Contact Admin</h1>} />
              <Route path="/formsearch" element={<Formsearch />} />
              <Route path="/variableMapping" element={inputNodes.length !== 0 ? <VariableFlowWithProvider /> : <Formsearch />} />


            </Routes>
          </main>

        </div>
      </BrowserRouter >
    </div >


  );
}

export default App;
