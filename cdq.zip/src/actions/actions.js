import axios from 'axios';
import { Types } from '../constants/Types';
import { request } from '../constants/environment';
import { fetch } from '../constants/fetch';

export const Loader = (payload) => {
  return (dispatch) => {
    dispatch({ type: Types.ON_SET_LOADER, payload })
  }
}

export const getStudiesData = () => {
  return (dispatch) => {
    //   dispatch({ type: Types.IS_LOADING_ENABLED })
    axios.get(`${request.StudyInformation.studies}`)
      // dispatch(Loader(true))
      .then((response) => {
        let _data = response.data.output
        dispatch({
          type: Types.GET_STUDY_INFO,
          payload: _data
        })
        // dispatch(Loader(false))
      })
  }
}

export const getFormsMapping = (params) => {
  let url = `${request.FormsInformation.forms}?`
  return (dispatch) => {
    dispatch(Loader(true))
    fetch({
      method: 'POST',
      url: url,
      data: params
    })
      .then((response) => {
        dispatch({ type: Types.ON_INPUTNODES_FLOW_NODES, payload: response.data.output })
        dispatch(Loader(false))
      })
  }
}

export const getFormsEdges = (params,callback) => {
  let url = `${request.FormsInformation.mapping}`
  return (dispatch) => {
    dispatch(Loader(true))
    fetch({
      method: 'POST',
      url: url,
      data: params
    })
      .then((response) => {
        if (callback) { callback(response.data) }
        if (response.data.message) {
          dispatch({ type: Types.IS_MAP_FORM_TOAST_ENABLE })
        }
        dispatch({
          type: Types.GET_FORMS_MAPPING, payload: response.data.output,
          message: (params.form === '' ? 'No forms are mapped automatically.' : response.data.message)
        })
        setTimeout(() => {
          dispatch({ type: Types.IS_MAP_FORM_TOAST_DISABLE })
        }, 3000);
        dispatch(Loader(false))
      })
  }
}

export const getVariablesInfo = (params) => {
  let url = `${request.VariableInformation.variables}`
  return (dispatch) => {
    dispatch(Loader(true))
    fetch({
      method: 'POST',
      url: url,
      data: params
    })
      .then((response) => {
        dispatch({ type: Types.GET_VARIABLES_INFO, payload: response.data.output })
        dispatch(Loader(false))
      })
  }
}

export const getVariablesEdges = (params) => {
  let url = `${request.VariableInformation.variablesMapping}`
  return (dispatch) => {
    dispatch(Loader(true))
    fetch({
      method: 'POST',
      url: url,
      data: params
    })
      .then((response) => {
        if (response.data.message) {
          dispatch({ type: Types.IS_MAP_VARIABLE_TOAST_ENABLE })
        }
        dispatch({
          type: Types.GET_VARIABLE_MAPPING, payload: response.data.output,
          message: response.data.message
        })
        setTimeout(() => {
          dispatch({ type: Types.IS_MAP_VARIABLE_TOAST_DISABLE })
        }, 3000);
        dispatch(Loader(false))
      })
  }
}