#!/bin/bash
CONTAINER_NAME="cdq-ui"
# Checking if the container is running
if docker container inspect --format='{{.State.Running}}' "$CONTAINER_NAME" >/dev/null 2>&1; then
  echo "Stopping existing container..."
  # Stoping the container
  docker container stop "$CONTAINER_NAME"
  STOP_EXIT_STATUS=$?

  if [ $STOP_EXIT_STATUS -ne 0 ]; then
    echo "no such conatiner with the $CONTAINER_NAME"
    exit 1
  fi
fi
# Checking if the exsting conatiner removing.
if docker container inspect --format='{{.State.Status}}' "$CONTAINER_NAME" >/dev/null 2>&1; then
  echo "Removing existing container..."
  docker container rm "$CONTAINER_NAME"
  REMOVE_EXIT_STATUS=$?

  if [ $REMOVE_EXIT_STATUS -ne 0 ]; then
    echo "so unable to find $CONTAINER_NAME"
    exit 1
  fi
fi
