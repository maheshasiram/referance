import React from 'react';
import logo from './logo.svg';
import DocumentComponent from './DocumentComponent';
import '../src/App.css'
function App() {
  return (
    <div className="App">
      <DocumentComponent/>
    </div>
  );
}

export default App;
