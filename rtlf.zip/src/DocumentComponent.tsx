// import "./styles.css";
import HtmlToRtfBrowser from "html-to-rtf-browser";
import { useEffect } from "react";
// const HtmlToRtfBrowser = require('html-to-rtf-browser');
import { Buffer } from 'buffer';
import '../src/App.css';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableFooter from '@mui/material/TableFooter';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { products } from "./data";
import IconButton from '@mui/material/IconButton';
import FirstPageIcon from '@mui/icons-material/FirstPage';
import KeyboardArrowLeft from '@mui/icons-material/KeyboardArrowLeft';
import KeyboardArrowRight from '@mui/icons-material/KeyboardArrowRight';
import LastPageIcon from '@mui/icons-material/LastPage';
import { useTheme } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Pagination from '@mui/material/Pagination';




export default function DocumentComponent() {
  var htmlToRtf = new HtmlToRtfBrowser();

  const [page, setPage] = React.useState(5);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);

  const handleConvert = () => {
    window.Buffer = window.Buffer || require("buffer").Buffer;
    let html = document.getElementById('mainDiv') as HTMLElement
    const rtf = htmlToRtf.convertHtmlToRtf(html.outerHTML)
    // console.log(rtf);
    // from here on, works only on browser
    const blob = new Blob([rtf], { type: "application/rtf;charset=utf-8" });
    const link = window.URL.createObjectURL(blob);
    window.location.href = link;
  };


  interface TablePaginationActionsProps {
    count: number;
    page: number;
    rowsPerPage: number;
    onPageChange: (
      event: React.MouseEvent<HTMLButtonElement>,
      newPage: number,
    ) => void;
  }

  function createData(
    name: string,
    calories: number,
    fat: number,
    carbs: number,
    protein: number,
  ) {
    return { name, calories, fat, carbs, protein };
  }

  const rows = [
    createData('Frozen yoghurt', 159, 6.0, 24, 4.0),
    createData('Ice cream sandwich', 237, 9.0, 37, 4.3),
    createData('Eclair', 262, 16.0, 24, 6.0),
    createData('Cupcake', 305, 3.7, 67, 4.3),
    createData('Gingerbread', 356, 16.0, 49, 3.9),
  ];

  const productHeaders = ["Code", "Name", "Category", "Quantity"]

  const handleChangePage = (event: React.MouseEvent<HTMLButtonElement> | null,
    newPage: number) => {
    setPage(newPage);
  }

  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  }

  const emptyRows =
    page > 0 ? Math.max(0, (1 + page) * rowsPerPage - products.length) : 0;

  function TablePaginationActions(props: TablePaginationActionsProps) {
    const theme = useTheme();
    const { count, page, rowsPerPage, onPageChange } = props;

    const emptyRows =
      page > 0 ? Math.max(0, (1 + page) * rowsPerPage - products.length) : 0;

    const handleFirstPageButtonClick = (
      event: React.MouseEvent<HTMLButtonElement>,
    ) => {
      onPageChange(event, 0);
    };

    const handleBackButtonClick = (event: React.MouseEvent<HTMLButtonElement>) => {
      onPageChange(event, page - 1);
    };

    const handleNextButtonClick = (event: React.MouseEvent<HTMLButtonElement>) => {
      onPageChange(event, page + 1);
    };

    const handleLastPageButtonClick = (event: React.MouseEvent<HTMLButtonElement>) => {
      onPageChange(event, Math.max(0, Math.ceil(count / rowsPerPage) - 1));
    };

    return (
      <Box sx={{ flexShrink: 0, ml: 2.5 }}>
        <IconButton
          onClick={handleFirstPageButtonClick}
          disabled={page === 0}
          aria-label="first page"
        >
          {theme.direction === 'rtl' ? <LastPageIcon /> : <FirstPageIcon />}
        </IconButton>
        <IconButton
          onClick={handleBackButtonClick}
          disabled={page === 0}
          aria-label="previous page"
        >
          {theme.direction === 'rtl' ? <KeyboardArrowRight /> : <KeyboardArrowLeft />}
        </IconButton>
        <IconButton
          onClick={handleNextButtonClick}
          disabled={page >= Math.ceil(count / rowsPerPage) - 1}
          aria-label="next page"
        >
          {theme.direction === 'rtl' ? <KeyboardArrowLeft /> : <KeyboardArrowRight />}
        </IconButton>
        <IconButton
          onClick={handleLastPageButtonClick}
          disabled={page >= Math.ceil(count / rowsPerPage) - 1}
          aria-label="last page"
        >
          {theme.direction === 'rtl' ? <FirstPageIcon /> : <LastPageIcon />}
        </IconButton>
      </Box>
    );
  }



  return (
    <React.Fragment>
      <button type="button" onClick={handleConvert}>click here</button>
      <div className="mainDiv">
        <p style={{ color: "rgb(255,0,0)" }}>testds </p>
        <div>
          <p>1234556 </p>
          <div>
            <p>testds </p>
            <div>
              <h1>12324</h1>
            </div>
          </div>
        </div>
        <div id="mainDiv" >
          <TableContainer component={Paper}>
            <Table aria-label="simple table">
              <TableHead>
                <TableRow>
                  {productHeaders && productHeaders.map((item: any) => (
                    <TableCell>{item}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <div id="table-body">
                <TableBody>
                  {(rowsPerPage > 0
                    ? products.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                    : products
                  ).map((row) => (
                    <TableRow key={row.name}>
                      <TableCell >{row.code}</TableCell>
                      <TableCell >{row.name}</TableCell>
                      <TableCell>{row.category}</TableCell>
                      <TableCell >{row.quantity}</TableCell>
                    </TableRow>
                  ))}
                  {emptyRows > 0 && (
                    <TableRow >
                      <TableCell colSpan={6} />
                    </TableRow>
                  )}
                </TableBody>
              </div>
              {/* <Pagination count={10} variant="outlined" shape="rounded" /> */}

              {/* <TableFooter>
                <TablePagination
                  rowsPerPageOptions={[5, 10, 25, { label: 'All', value: -1 }]}
                  colSpan={3}
                  count={products.length}
                  rowsPerPage={rowsPerPage}
                  page={page}
                  SelectProps={{
                    inputProps: {
                      'aria-label': 'rows per page',
                    },
                    native: false,
                  }}
                  onPageChange={handleChangePage}
                  onRowsPerPageChange={handleChangeRowsPerPage}
                  ActionsComponent={TablePaginationActions}
                />
              </TableFooter> */}
            </Table>
          </TableContainer>
        </div>
          <Pagination count={10} variant="outlined" shape="rounded" />
      </div>
    </React.Fragment >
  );
}
