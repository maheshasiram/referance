
window.env = {
    // REACT_APP_DOMAIN :  "https://graviteem-dev.inductivequotient.com/platform-admin-app/edc/pfa/",
    REACT_APP_DOMAIN: "https://graviteem-dev.inductivequotient.com",
    REACT_APP_KEYCLOAK_URL: "https://kc-dev.inductivequotient.com/realms/platformadmin",
    // REACT_APP_AUTHORIZATION_END_POINT :"https://kc-dev.inductivequotient.com/realms/platformadmin/protocol/openid-connect/auth",
    // REACT_APP_TOKEN_END_POINT : "https://kc-dev.inductivequotient.com/realms/platformadmin/protocol/openid-connect/token",
    REACT_APP_CLIENT_ID: "gravitee-client"
    // REACT_APP_LOGOUT_END_POINT : "https://kc-dev.inductivequotient.com/realms/platformadmin/protocol/openid-connect/logout",
    // REACT_APP_LOG_OUT_REDIRECT:"https://kc-dev.inductivequotient.com/realms/platformadmin/protocol/openid-connect/auth"
}



