module.exports = {
    env: {
      browser: true,
      node: true,
      es6: true,
      jest: true,
    },
    extends: [
      'eslint:recommended',
      'plugin:react/recommended',
      'plugin:react-hooks/recommended',
      'plugin:@typescript-eslint/eslint-recommended',
      'plugin:@typescript-eslint/recommended',
    ],
    ignorePatterns: ["*.png","*.scss","*.jpg","*.test.tsx","*.css"],
    parser: "@typescript-eslint/parser",
    parserOptions: {
      propject: 'tsconfig.json',
      sourceType: 'module',
    },
    plugins: ["@typescript-eslint", "@typescript-eslint"],
    rules: {
      "curly": "error",
      "no-unused-vars": ["error", { "vars": "all", "args": "after-used", "ignoreRestSiblings": false }],
      "no-duplicate-imports": ["error", { "includeExports": true }],
      "@typescript-eslint/no-explicit-any": "off"
    }
  };