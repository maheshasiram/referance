const path = require('path');
var webpack = require('webpack');
const Dotenv = require('dotenv-webpack');

const HtmlWebpackPlugin = require('html-webpack-plugin');
module.exports = {
    entry: './src/index.tsx',
    devServer: {
        static: {
            directory: path.join(__dirname, 'public'),
        },
        compress: true,
        port: 3001,
    },
    module: {
        rules: [
            {
                test: /\.(scss|css)$/i,
                use: [
                    // Creates `style` nodes from JS strings
                    "style-loader",
                    // Translates CSS into CommonJS
                    "css-loader",
                    // Compiles Sass to CSS
                    "sass-loader",
                ],
            },
            {
                test: /\.tsx?$/,
                use: 'ts-loader',
                exclude: /node_modules/,
            },
        ],
    },
    resolve: {
        extensions: ['.ts','.tsx','.js'],
    },
    plugins: [
        new Dotenv({
            // eslint-disable-next-line no-undef
            path: `./.env${env.file ? `.${env.file}` : ''}`
        }),
        new webpack.DefinePlugin({
            process: {
                SERVICE_URL: JSON.stringify('https://dev.example.com')
            }
        }),
        new HtmlWebpackPlugin({
            title: "Your custom title",
            template: './public/index.html'
        })],

    output: {
        filename: 'bundle.js',
        path: path.resolve(__dirname, 'dist'),
         clean: true,
            publicPath: '/'
    },
};