sed -i "s|REACT_APP_DOMAIN: \".*\"|REACT_APP_DOMAIN: \"$REACT_APP_DOMAIN\"|g" environment_variables.js
sed -i "s|REACT_APP_KEYCLOAK_URL: \".*\"|REACT_APP_KEYCLOAK_URL: \"$REACT_APP_KEYCLOAK_URL\"|g" environment_variables.js
