

export const name = 'Inductive Admin App';
