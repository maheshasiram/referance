

export const messages = {

    users: {
        createUser: "User created  successfully",
        editUser: "User updated successfully",
        deleteUser: "Are you sure you want to delete this user ?",
        userDocument: "Are you sure you want to delete this document ?",
        DocDownload: "User not having any documents to download ",
        DocDownloadSuccess: "Document downloaded successfully",
        DocDeleted: "Document deleted successfully",
        userActivate: "Are you sure you want to ",
        deletedSuccessfully: 'User deleted successfully',
        restoreSuccessfully: 'User restored successfully',
        succesfully: "User successfully",
    },
    study: {
        ActivateStudy: "Are you sure you want to activate this study ?",
        saveStudy: "Study saved succesfully. Do you want to continue ?",
        deleteStudy: "Are you sure you want to delete this Study ?",
        studyDeletedSuccess: 'Study deleted successfully',
        submitStudy: "Study submited successfully",
        updateStudy: "Study updated successfully",
        ReSubmit: "Study re-submitted successfully",
        updated: "Updated successfully",
        DocumentDeleted: "Document deleted successfully",
        studyDocument: "Are you sure you want to delete this document ?",
        ContactDetails: "Contact details added successfully",
        studyActivatedSuccess: "Study activated successfully",
        studyApproved: "Study approved successfully", // Bug #5261
        // studyApproved: "Study Bookmarked successfully",
        studyRejected: "Study Rejected Successfully",
        studyHold: "study Hold Successfully"



    },
    roles: {
        deleteRole: "Are you sure you want to delete",
        privilageInRole: "Privileges updated successfully",
        createRole: "Role created and privileges applied successfully",
        updateRole: 'Role Updated and privileges applied successfully',
        RoleDeleted: "Deleted role cannot be activated, Are you sure you want to delete this Role ?"
    },
    privilages: {
        addPrivilage: "Privilege added successfully",
        deleteprivilage: "Are you sure you want to delete this Privilege ?",
        deleted: "Privileges deleted successfully",
        editprivilage: "Privilege updated successfully",
        deleteGroup: "Privilege group deleted successfully",
        AllGroupDelete: "Are sure do you want to delete this group. All respective Privileges will be deleted ?",
        privilageAssignedTogroup: "Privilege assigned to group successfully",
        deleteselectedprivilage: "Are you sure you want to delete all selected Privileges ?",
    },
    organization: {
        editOrg: "Organization updated successfully",
        deletedOrgsuccess: "Organization deleted successfully",
        ActiveOrg: "Are you sure you want to activate",
        deleteOrganization: "Are you sure you want to delete",
        organizationContact: "Organization contacts updated successfully",
        deleteSucces: "Contact deleted  successfully",
        orgName: "Organization name already exist",
        deleteContact: 'Are you sure you want to delete this Contact ?'
    },
    commonMessages: {
        apiError: 'Something went wrong',
        delete: 'Are you sure do you want to delete',
        restore: 'Are you sure do you want to restore ',
        inActivated: 'Deleted Successfully',
        orgNameActivated: 'Activated Successfully',
        activated: 'Restored Successfully',
    },
    dbdetails: {
        created: "Created successfully",
        updated: "Updated successfully"
    },
    HealthStatusMsgs:{
        submit:"Notified to user"
    }

}
