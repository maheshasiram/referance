// export const { NODE_ENV = 'development' } = process.env;

// export const baseUrl = 'http://192.168.10.118:8080/platform-admin-app/edc/pfa/'

// export const baseUrl = 'http://192.168.10.118:8081/platform-admin-app/edc/pfa/'

// // export const baseUrl = 'http://10.22.243.24:8082/platform-admin-app/edc/pfa/'
// declare global {
//     interface Window {
//       env: any
//     }
//   }
// export const baseUrl = 'http://localhost:8080/platform-admin-app/edc/pfa/'
// export const baseUrl = 'https://graviteem-dev.inductivequotient.com/platform-admin-app/edc/pfa/'

export const baseUrl = window.env.REACT_APP_DOMAIN + '/platform-admin-app/edc/pfa/';
// export const baseUrl = "https://graviteem-dev.inductivequotient.com" + '/platform-admin-app/edc/pfa/';
// export const baseUrl = 'http://10.22.242.56:8082' + '/platform-admin-app/edc/pfa/';

export const requests = {
   configDataType: (baseUrl + 'configData/v1/getByTypeCode'),

   fetchAllConfigDataType: (baseUrl + 'configData/v1/fetchAllConfigData'),
    config: {
        getByCode: (baseUrl + 'configData/v1/getByCode'),
        getByTypeCode: (baseUrl + 'configData/v1/getByTypeCode')
    },
    organization: {
        saveORupdateOrganization: (baseUrl + 'orgDetails/v1/saveOrUpdateOrganization'),
        findOrganizationById: (baseUrl + 'orgDetails/v1/findOrganizationById'),
        deleteOrganization: (baseUrl + 'orgDetails/v1/deleteOrganization'),
        restoreOrganization: (baseUrl + 'orgDetails/v1/restoreOrganization'),
        updateOrganizationContact: (baseUrl + 'orgDetails/v1/updateOrganizationContact'),
        deleteOrganizationContact: (baseUrl + 'orgDetails/v1/deleteOrganizationContact'),
        findAllOrganizationsByStatus: (baseUrl + 'orgDetails/v1/findAllOrganizationsByStatus'),
        orgTypes: (baseUrl + 'configData/v1/getConfigDataByTypeCode/ORG_TYPE'),
        countriesApi: {
            allCountries: (baseUrl + 'country/v1/findAllCountries'),
            statesByCountry: (baseUrl + 'country/v1/findStatesByCountryId'),
            citiesByStates: (baseUrl + 'country/v1/findCitiesByStateId'),
            findCityDetails: (baseUrl + 'country/v1/findByCityId')
        },
        contactDetails: {
            configData: (baseUrl + 'configData/v1/getByTypeCode')
        },
        organizationDetails: {
            findAllOrganizations: (baseUrl + 'orgDetails/v1/findAllOrganizations')
        },
        Downloads:(baseUrl + 'downloads/Downloads')
    },
    roles: {
        getAssignRole:(baseUrl+'userRole/v1/getAssignRole'),
        changeRole:(baseUrl+'role/v1/changeRole'),
        fetchAllRoles: (baseUrl + 'role/v1/fetchAllRoles'),
        fetchAllRolePrivileges: (baseUrl + 'role/v1/fetchAllRolePrivileges'),
        fetchRolePrivilegesByRoleId: (baseUrl + 'role/v1/fetchRolePrivilegesByRoleId'),
        getAllPrivilegesAssignedToGrp: (baseUrl + 'privilegeGroup/v1/getAllPrivilegesAssignedToGroup'),
        fetchAssignedRolePrivileges: (baseUrl + 'role/v1/fetchAssignedRolePrivileges'),
        createRole: (baseUrl + 'role/v1/createRole'),
        assignPrivilegesToRole: (baseUrl + 'role/v1/assignPrivilegesToRole'),
        deleteRolePrivilegesByRoleId: (baseUrl + 'role/v1/deleteRolePrivilegesByRoleId'),
        updateAllRolePrivileges: (baseUrl + 'role/v1/updateAllRolePrivileges'),
        fetchAllRolesWithPrivileges: (baseUrl + 'role/v1/fetchAllRolesWithPrivileges'),
        updateRole: (baseUrl + 'role/v1/updateRole'),
        deleteRoleByRoleId: (baseUrl + 'role/v1/deleteRoleByRoleId?roleId='),
        getAllUsersWithSameRole: (baseUrl + 'userRole/v1/getAllUsersWithSameRole'),
        updateUserRoles: (baseUrl + 'userRole/v1/updateUserRoles'),

    },
    //PRIVILEGES 
    privileges: {
        getAllPrivilegesAssignedToGroup: (baseUrl + 'privilegeGroup/v1/getAllPrivilegesAssignedToGroup'),
        addPrivilegeGroup: (baseUrl + 'privilegeGroup/v1/addPrivilegeGroup'),
        deletePrivilegeByPrevId: (baseUrl + 'privilegeGroup/v1/deletePrivilegeByPrevId'),
        insertNewPrivilegesToGroup: (baseUrl + 'privilegeGroup/v1/insertNewPrivilegesToGroup'),
        updatePrivilegeById: (baseUrl + 'privilegeGroup/v1/updatePrivilegeById'),
        updatePrivilegeGroup: (baseUrl + 'privilegeGroup/v1/updatePrivilegeGroup'),
        deletePrivilegeGroup: (baseUrl + 'privilegeGroup/v1/deletePrivilegeGroup'),
        deleteMultiplePrivileges: (baseUrl + 'privilegeGroup/v1/deleteMultiplePrivilegesByPrevId'),
    },
    users: {
        allUser: (baseUrl + 'userDetails/v1/findAllActiveUsers'),
        userList: (baseUrl + 'userDetails/v1/findAllUsers'),
        UserDetails: (baseUrl + 'userDetails/v1/findUserById'),
        getUserDetailsFromLdap: (baseUrl + "userDetails/v1/getUserDetailsFromLdap?user="),
        submitUserDetails: (baseUrl + 'userDetails/v1/saveUser'),
        AllRole: (baseUrl + 'role/v1/fetchAllRoles'),
        DocumentTypes: (baseUrl + 'configData/v1/getDocumentTypes'),
        sendDocument: (baseUrl + 'userDocuments/v1/uploadUserDocuments'),
        downloadfile: (baseUrl + 'userDocuments/v1/downloadDocById'),
        getUsersByStatus: (baseUrl + 'userDetails/v1/findAllUsersByStatus'),
        findUserByUserId: (baseUrl + 'userDetails/v1/findUserByUserId'),
        updateUser: (baseUrl + 'userDetails/v1/updateUser'),
        deleteDocumentById: (baseUrl + 'userDocuments/v1/deleteDocumentById'),
        currentUser: (baseUrl + 'userDetails/v1/current-user'),
        getUserByUserName: (baseUrl + 'userDetails/v1/getUserByUserName'),
        restoreUser:(baseUrl + 'userDetails/v1/restoreUser'),
        deleteUser:(baseUrl + 'userDetails/v1/deleteUser')

    },
    studies: {
        findOrgByContactID: (baseUrl + "orgDetails/v1/findContactsByOrgId"),
        fetchAllStudies: (baseUrl + 'study/v1/fetchAllStudies'),
        studyType: (baseUrl + 'configData/v1/getByTypeCode/STUDY_TYPE'),
        studyPhase: (baseUrl + 'configData/v1/getByTypeCode/STUDY_PHASE'),
        solutions: (baseUrl + 'configData/v1/getByTypeCode/APPLICATION'),
        edcModules: (baseUrl + 'configData/v1/getByTypeCode/EDC_MODULES'),
        getApprovers: (baseUrl + 'userDetails/v1/getApprovers'),
        approve: (baseUrl + 'study/v1/approve'),
        uploadStudyDocuments: (baseUrl + 'studyDocuments/v1/uploadStudyDocuments'),
        saveStudy: (baseUrl + 'study/v1/save'),
        submitStudy: (baseUrl + 'study/v1/submit'),
        deleteStudyById: (baseUrl + 'study/v1/deleteByStudyId'),
        findStudyDetailsById: (baseUrl + 'study/v1/findStudyDetailsById'),
        reSubmit: (baseUrl + 'study/v1/reSubmit'),
        fetchTransactionForStudy: (baseUrl + 'study/v1/fetchTransactionForStudy'),
        findAllStudiesByLoggedInUser: (baseUrl + 'study/v1/findAllStudiesByLoggedInUser'),
        findAllStudiesByStatus: (baseUrl + 'study/v1/findAllStudiesByStatus'),
        addNewContactDetails: (baseUrl + 'orgDetails/v1/saveOrganizationContact'),
        downloadDocument: (baseUrl + 'studyDocuments/v1/downloadDocById/'),
        deleteDocument: (baseUrl + 'studyDocuments/v1/deleteStudyById/'),
        activateByStudyId: (baseUrl + 'study/v1/activateByStudyId'),
        
    },

    dbDetail: {
        fetchDbDetails: (baseUrl + 'getDbDetails'),
        createDbDetails: (baseUrl + 'saveDbDetails'),
        deleteDbDetails :(baseUrl + 'deleteDbDetails'),
        restoreDbDetails:(baseUrl + 'restoreDbDetails'),
        fetchSavedRecords: (baseUrl + 'editDbDetails'),
        getRegionDetailsById: (baseUrl + 'getRegionDetailsById'),
        getRegionDetails :(baseUrl + 'getRegionDetails'),
        updateDbDetails: (baseUrl + 'updateDbDetails'),
        fetchDbDetailsByRegion: (baseUrl + 'fetchDbDetailsByRegion')
    },
    devOps: {
        validateEdcStudySchemaExist:(baseUrl + 'devOps/v1/validateEdcStudySchemaExist'),
        validateEdcStudySchemaAndTables:(baseUrl + 'devOps/v1/validateEdcStudySchemaAndTables'),
        getSchemaEnvironmentStatus:(baseUrl + 'devOps/v1/getSchemaEnvironmentStatus'),
        saveProvisionerDetails:(baseUrl + 'devOps/v1/saveProvisionerDetails'),
        approveOrRejectStudy:(baseUrl + 'devOps/v1/approveOrRejectStudy'),
        findProvisionerDetailsByStudyId:(baseUrl + 'devOps/v1/findProvisionerDetailsByStudyId'),
        createSchemaAndTables:(baseUrl + 'devOps/v1/createSchemaAndTables'),
        validateSchemas:(baseUrl + 'devOps/v1/validateSchemas'),
        validateTables:(baseUrl + 'devOps/v1/validateTables'),
    },
    pushNotification :{
        notifications: (baseUrl + "pushNotifications/v1/getUserNotificationsByUserName"),
        deleteNotification: (baseUrl+ "pushNotifications/v1/deleteNotificationById"),
        webSocketNotify:  (baseUrl+ "notifications")
    },
    healthStatus:{
        getAllOrganizationHealthCheckList:(baseUrl + "orghealthcheck/v1/getAllOrganizationHealthCheckList"),
        fetchAllStudyDomainHealthCheck:(baseUrl + "orghealthcheck/v1/fetchAllStudyDomainHealthCheck"),
        getAllUsers:(baseUrl + "orghealthcheck/v1/getAllUsers"),
        saveOrgDomainHealthCheckUserNotify:(baseUrl + "orghealthcheck/v1/saveOrgDomainHealthCheckUserNotify"),
        saveStudyDomainHealthCheck:(baseUrl + "orghealthcheck/v1/saveStudyDomainHealthCheck"),
        saveOrganizationDomainHealthCheck:(baseUrl + "orghealthcheck/v1/saveOrganizationDomainHealthCheck")


    }
}


