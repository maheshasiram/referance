import React from 'react';
// import { render, screen } from '@testing-library/react';
// import App from './App';

// test('renders learn react link', () => {
//   render(<App />);
//   const linkElement = screen.getByText(/learn react/i);
//   expect(linkElement).toBeInTheDocument();
// });

describe('sum module', () => {
  test('renders learn react link', () => {
    const count =1;
    expect(count).toEqual(1);
  });
  });
