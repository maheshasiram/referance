import Keycloak from 'keycloak-js';

const test:any ={
    "url":"https://kc-dev.inductivequotient.com",
    "realm": "master",
    "auth-server-url": "https://kc-dev.inductivequotient.com/",
    "clientId": "gravitee-client",
    "ssl-required": "external",
    "resource": "gravitee-client",
    "verify-token-audience": true,
    "grant_type": "password",
    "credentials": {
        "secret": "DTIzcae7i1zY3u8irI1i4buwVHMDRNaF"
    },
    "disable-trust-manager": false,
    "token": "bearer Z3Jhdml0ZWUtY2xpZW50OkRUSXpjYWU3aTF6WTN1OGlySTFpNGJ1d1ZITURSTmFG",
    "autodetect-bearer-only": true,
    "confidential-port": 0,
    "policy-enforcer": {},
    "providers":[{
        "provide":"HTTP_INTERCEPTEORS", "useClass":"KeycloakBearerIntercepter", "multi":true
    }],
    "headers": {
        "Content-Type": "application/x-www-form-urlencoded",        
        "Authorization": "Basic Z3Jhdml0ZWUtY2xpZW50OkRUSXpjYWU3aTF6WTN1OGlySTFpNGJ1d1ZITURSTmFG"
    }
}

export const keycloak: any = new Keycloak(test)