import { lazy } from "react";

export const privateRoutes = [
    // {
    //     name:'Home',
    //     pathName:'/home',
    //     component:lazy(()=>import('../Components/Home/Home')),
    //     navigateTo:'/home',
    //     access:'Home'
    // },
    {
        name: 'Dashboard',
        pathName:"/dashboard",
        Component:lazy(()=>import('../Components/Studies/DashBoards/Dashboard')),
        navigateTo:'/dashboard',
        access:'ViewStudy',
    },
    {
        name:'User',
        pathName:'/users',
        Component:lazy(()=>import('../Components/Users/User')),
        navigateTo:'/users',
        access:'ViewUsers',

    },
    {
        name:'Forgetpassword',
        pathName:'/forgetpassword/:userId',
        Component:lazy(()=>import('../Components/Login/ForgotPassword/ForgotPassword')),
        navigateTo:'/forgetpassword/:userId',
        access:'ForgetPassword',
    },
    {
        name:'Resetpassword',
        pathName:'/resetpassword',
        Component:lazy(()=>import('../Components/Login/ResetPassword/ResetPassword')),
        navigateTo:'resetpassword',
        access:"ResetPassword",
    },
    {
        name:'Organizations',
        pathName:'/organizations',
        Component:lazy(()=>import('../Components/Organization/Dashboard/Organizations')),
        navigateTo:'/organizations',
        access:'ViewOrganization',
    },
    {
        name:'Createorganization',
        pathName:'/createorganization',
        Component:lazy(()=>import('../Components/Organization/CreateOrganization/CreateOrganization')),
        navigateTo:'/createorganization',
        access:'CreateOrganization',
    },
    {
        name:'Createstudy',
        pathName:'/createstudy/:id',
        Component:lazy(()=>import('../Components/Studies/CreateStudy/CreateStudy')),
        navigateTo:'/createstudy/:id',
        access:'CreateStudy',
    },
    {
        name:'Editstudy',
        pathName:'/createstudy/:id',
        Component:lazy(()=>import('../Components/Studies/CreateStudy/CreateStudy')),
        navigateTo:'/createstudy/:id',
        access:'EditStudy',
    },
    {
        name:'Roles',
        pathName:'/roles',
        Component:lazy(()=>import('../Components/Roles/Roles')),
        navigateTo:'/roles',
        access:'ViewRolesandPrivileges',
    },
    {
        name:'Devops',
        pathName:'/devops/:id',
        Component:lazy(()=>import('../Components/devops/index')),
        navigateTo:'/devops/:id',
        access:'DevopsApprover',
    },
    {
        name:'Devops',
        pathName:'/devops/:id',
        Component:lazy(()=>import('../Components/devops/index')),
        navigateTo:'/devops/:id',
        access:'Provisioner',
    },
    {
        name:'Dbdetails',
        pathName:'/dbdetails',
        Component:lazy(()=>import('../Components/DBdetails/index')),
        navigateTo:'/dbdetails',
        access:'ViewDatabase',
    },
    {
        name:'Approvestudy',
        pathName:'/study/:id',
        Component:lazy(()=>import('../Components/Studies/ApproveStudy/ApproveStudy')),
        navigateTo:'/study/:id',
        access:'StudyApprover',
    },
    {
        name:'OrganizationUrls',
        pathName:'/organizationUrls',
        Component:lazy(()=>import('../Components/OrganizationUrl/index')),
        navigateTo:'/organizationUrls',
        access:'ViewOrganization',
    }
]