import { currentUserDetails } from "./Types"

export const currentUserData: currentUserDetails = {

    userId: NaN,
    userName: "",
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    timeZone: "",
    lastActiveDate: "",
    isActive: false,
    comments: "",
    createdBy: "",
    createdOn: "",
    updatedBy: "",
    updatedOn: "",
    role: {
        id: NaN,
        name: "",
        code: "",
        description: "",
        configDataType: {
            id: NaN,
            name: "",
            code: "",
            description: ""
        }
    },
    roleId: NaN,
    country: {
        id: NaN,
        name: "",
        countryCode: "",
        phoneCode: NaN
    },
    userDocuments: [
        {
            id: NaN,
            fileName: "",
            fileContentType: "",
            user: {
                userId: NaN,
                userName: "",
                firstName: "",
                lastName: "",
                email: "",
                phone: NaN,
                timeZone: "",
                lastActiveDate: "",
                isActive: false,
                comments: "",
                createdBy: "",
                createdOn: "",
                updatedBy: "",
                updatedOn: "",
                role: "",
                roleId: NaN,
                country: {
                    id: NaN,
                    name: "",
                    countryCode: "",
                    phoneCode: NaN
                },
                userDocuments: []
            },
            documentType: {
                id: NaN,
                name: "",
                code: "",
                description: "",
                configDataType: {
                    id: NaN,
                    name: "",
                    code: "",
                    description: ""
                }
            }
        }
    ]

}