export const publicRoutes = [
    {
        name: 'ViewStudy',
        pathName: "/dashboard",
    },
    {
        name: 'ViewUsers',
        pathName: "/users",
    },
    {
        name: 'ViewOrganization',
        pathName: "/organizations",
    },
    {
        name: 'ViewRolesandPrivileges',
        pathName: "/roles",
    },
    {
        name: 'ViewDatabase',
        pathName: "/dbdetails",
    },
    {
        name: 'OrganizationUrls',
        pathName: "/organizationUrls",
    },
]

