export const Types = {
    ROLE_SETTINGS:'ROLE_SETTINGS',
    ON_SET_LOADER: 'ON_SET_LOADER',
    FETCH_STUDY_NOTIFICATIONS: 'FETCH_STUDY_NOTIFICATIONS',

    //Current User 
    CURRENT_USER_DETAILS: "CURRENT_USER_DETAILS",

    //global configData
     CONFIG_DATA:"CONFIG_DATA",

    CREATE_ORGANIZATION: 'CREATE_ORGANIZATION',
    CREATE_USER: ' CREATE_USER',

    //global alertdialog
    ON_OPEN_ALERT_DIALOG: 'ON_OPEN_ALERT_DIALOG',
    ON_CLOSE_ALERT_DIALOG: 'ON_CLOSE_ALERT_DIALOG',
    IS_TOAST_ENABLED:'IS_TOAST_ENABLED',


    //role
    ON_ALL_ROLES: 'ON_ALL_ROLES',
    ON_ALL_PRIVILEGES: 'ON_ALL_PRIVILEGES',

    //Privileges
    PRIVILEGES_DATA: 'PRIVILEGES_DATA',

    //global AllconfigData
    FETCH_ALL_CONFIG_DATA:"FETCH_ALL_CONFIG_DATA",

}



export type primaryContact =
    {
        firstName?: string;
        lastName?: string;
        email?: string;
        phoneNumber?: any;
    }
export type secondaryContact =
    [{
        firstName?: string;
        lastName?: string;
        email?: string;
        phoneNumber?: any;
    }]
export type createOrgnization =
    {
        name?: string;
        addressLine1?: string;
        addressLine2?: string,
        country?: string;
        state?: string;
        city?: string;
        zip?: any;
        phoneNumber?: any;
        companyWebsite?: string;
        primaryContact?: primaryContact;
        secondaryContact?: secondaryContact;
    }
export type userValues = {
    comments?: string,
    createdBy?: string,
    createdOn?: string,
    email?: string,
    firstName?: string,
    isActive?: string,
    lastActiveDate?: string,
    lastName?: string,
    phone?: string,
    timeZone?: string,
    updatedBy?: string,
    updatedOn?: string,
    userId?: string,
    userName?: string,
    CountryCode?: string,
    Role?: string,
    approvaldate?: string,
    approvaldocument?: string,
}
export type roles = {
    id?: number,
    roleName?: string,
    privileges: [{
        id?: number,
        privilege_name?: string,
        status?: string
    }
    ]
}

export type rolePrivilage = {
    Grp_Name?: string,
    id?: number,
    privilege: [
        {
            id?: number,
            privilege_name?: string,
            status?: string
        },
    ]
}


export type currentUserDetails = {

    userId?: number,
    userName?: string,
    firstName?: string,
    lastName?: string,
    email?: string,
    phone?: string,
    timeZone?: string,
    lastActiveDate?: string,
    isActive?: boolean,
    comments?: string,
    createdBy?: string,
    createdOn?: string,
    updatedBy?: string,
    updatedOn?: string,
    role?: {
        id?: number,
        name?: string,
        code?: string,
        description?: string,
        configDataType?: {
            id?: number,
            name?: string,
            code?: string,
            description?: string
        }
    },
    roleId?: number,
    country?: {
        id?: number,
        name?: string,
        countryCode?: string,
        phoneCode?: number
    },
    userDocuments?: [
        {
            id?: number
            fileName?: string,
            fileContentType?: string,
            user?: {
                userId?: number,
                userName?: string,
                firstName?: string,
                lastName?: string,
                email?: string,
                phone?: number,
                timeZone?: string,
                lastActiveDate?: string,
                isActive?: boolean,
                comments?: string,
                createdBy?: string,
                createdOn?: string,
                updatedBy?: string,
                updatedOn?: string,
                role?: string,
                roleId?: number,
                country?: {
                    id?: number,
                    name?: string,
                    countryCode?: string,
                    phoneCode?: number
                },
                userDocuments?: []
            },
            documentType?: {
                id?: number,
                name?: string,
                code?: string,
                description?: string,
                configDataType?: {
                    id?: number,
                    name?: string,
                    code?: string,
                    description?: string
                }
            }
        }
    ],

}