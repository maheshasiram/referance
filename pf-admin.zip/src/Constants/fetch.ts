import axios from 'axios';
import { Loader } from '../actions/actions';
import store from '../sagas/main';

export const fetch = (request: any) => {
    const options = {
        method: request.method,
        url: request.url,
        data: request.data,
        timeout: (60 * 2 * 1000),
        headers: {
            Authorization: `Bearer ${sessionStorage.token}`
        },
        responseType: request.responseType,
    };
    // store.dispatch(Loader(true));
    return axios(options)
        .then(response => {         
            // store.dispatch(Loader(false));
            return response;
        });
}