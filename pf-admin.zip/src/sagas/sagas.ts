// eslint-disable-next-line require-yield
export function* helloSaga() {
  console.log('Hello Sagas!')
}