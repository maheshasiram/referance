import { combineReducers } from "redux";
import { application } from "./applications";
import { organization } from '../../Components/Organization/reducer/organization'
import { modalapp } from "./modalapp";
// import { privileges } from '../../Components/Privileges/reducer/privileges'
import { users } from '../../Components/Users/Reducer/User';
import { roles } from "../../Components/Roles/Reducer/Role";
import { study } from "../../Components/Studies/reducer/study";
import { devops } from "../../Components/devops/reducer/devops"
import { dbDetails } from "../../Components/DBdetails/reducer/dbDetails";
import {OrganizationStatusUrl} from "../../Components/OrganizationUrl/reducer/OrganizationStatusUrl"



const reducer = combineReducers({
    users,
    app: application,
    organization,
    modalapp,
    // privileges,
    roles,
    study,
    devops,
    dbDetails,
    OrganizationStatusUrl

});

export type RootState = ReturnType<typeof reducer>;

export default reducer;
