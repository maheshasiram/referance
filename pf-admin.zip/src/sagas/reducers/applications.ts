import { Types } from "../../Constants/Types"
import { currentUserData } from "../../Constants/Models"

const initialState = {
    isLoader: false,
    notificationsData: [],
    conFigData: {},
    allConFigData:{},
    config: {
        CONTACT_TYPE_OTHERS: 'CONTACT_TYPE_OTHERS',
        CONTACT_TYPE_CLINICAL_TRAILS: 'CONTACT_TYPE_CLINICAL_TRAILS',
        WF_STATUS_TYPE: 'WF_STATUS_TYPE',
        WF_STATUS_TYPE_HOLD: 'WF_STATUS_TYPE_HOLD',
        WF_STATUS_TYPE_REJECTED: 'WF_STATUS_TYPE_REJECTED',
        WF_STATUS_TYPE_SUBMIT_RE_APPROVAL: 'WF_STATUS_TYPE_SUBMIT_RE_APPROVAL',
        WF_STATUS_TYPE_SUBMIT_APPROVAL: 'WF_STATUS_TYPE_SUBMIT_APPROVAL',
        WF_STATUS_TYPE_APPROVED: 'WF_STATUS_TYPE_APPROVED',
        WF_STATUS_TYPE_DRAFT: 'WF_STATUS_TYPE_DRAFT'
    },
    // user: {
    //     role: 'admin',
    //     userName: "ajoshi",
    //     firstName: "aishwarya",
    //     lastName: 'joshi',
    //     id: 7
    // },

    user: currentUserData,
    roleSettings: null,
    


}

export const application = (state = initialState, action: { type: any, payload: any }) => {

    switch (action.type) {
        case Types.ON_SET_LOADER:
            return { ...state, isLoader: action.payload }
        case Types.FETCH_STUDY_NOTIFICATIONS:
            return { ...state, notificationsData: action.payload }
        case Types.CURRENT_USER_DETAILS:
            return { ...state, user: action.payload }
        case Types.CONFIG_DATA:
            return { ...state, conFigData: action.payload }
        case Types.ROLE_SETTINGS:
            return { ...state, roleSettings: action.payload }
            case Types.FETCH_ALL_CONFIG_DATA:
                return { ...state, allConFigData: action.payload }
        default:
            return { ...state }
    }
}