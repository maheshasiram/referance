import { Types } from "../../Constants/Types"

const initialState = {
  isLoader: false,
  modal: {
    header: '',
    status: 0,
    open: false,
    message: "",
    disabled: false,
    actionType: '',
    // onOk: () => { },
    // onCancel: () => { },
  },
  isToast: { status: 0, message: '', open: false },
  autoCompleteSelectedVal: null
}
export const modalapp = (state = initialState, action: any) => {

  switch (action.type) {
    case Types.ON_OPEN_ALERT_DIALOG:
      // console.log('.....22', action.payload);
      return { ...state, modal: action.payload }
    case Types.ON_CLOSE_ALERT_DIALOG:
      return { ...state, modal: action.payload }
    case Types.IS_TOAST_ENABLED:
      // console.log('payload28...',action.payload);
      return { ...state, isToast: action.payload }
    default:
      return { ...state }
  }

}