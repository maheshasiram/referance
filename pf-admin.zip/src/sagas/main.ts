import thunk from 'redux-thunk';
import { configureStore } from '@reduxjs/toolkit';
import reducer from './reducers'


const store = configureStore(
  { reducer: reducer,
    middleware: [thunk]
  }
)
  
export default store;







// ...
// import { createStore, applyMiddleware } from 'redux'
// import createSagaMiddleware from 'redux-saga'

// // ...
// import { helloSaga } from './sagas'
// import reducer from './reducers'

// const sagaMiddleware = createSagaMiddleware()
// const store = createStore(
//   reducer,
//   applyMiddleware(sagaMiddleware)
// )
// sagaMiddleware.run(helloSaga)

// export default store;