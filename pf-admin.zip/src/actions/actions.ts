import { Types } from '../Constants/Types';
import store from '../sagas/main';
import { requests } from '../configs/env';
import { fetch } from '../Constants/fetch'

// GET Current User Details when Logged in
// interface apidataType{
//   dispatch:any
// }
// const MyComponent = function MyComponent() { ... }

export const currentUser: any = () => {
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: "GET",
      url: requests.users.currentUser,
      data: ''
    }).then((response: any) => {
      dispatch({ type: Types.CURRENT_USER_DETAILS, payload: response.data });
      dispatch(Loader(false))
      // return response as apidataType;
    }).catch((err: any) => {
      console.log('err........', err)
    })
  }
}


export const ValidateRole = () => {
  const { user } = store.getState().app;
  return (user && user.role && user.role.name) === "admin" ? true : false
  // return (user && user.role === "admin")
}

export const Alert: any = (data: any) => {
  return (dispatch: any) => {
    dispatch({
      type: Types.ON_OPEN_ALERT_DIALOG,
      payload: {
        ...data,
        header: 'Alert',
        open: true
      }
    })
  }
}

export const Confirm: any = (data: any) => {
  return (dispatch: any) => {
    dispatch({
      type: Types.ON_OPEN_ALERT_DIALOG,
      payload: {
        ...data,
        header: 'Confirm',
        open: true
      }
    })
  }
}

export const Loader = (payload: any) => {
  return (dispatch: any) => {
    dispatch({ type: Types.ON_SET_LOADER, payload })
  }
}
export const toastAlert: any = (payload: any) => {
  return (dispatch: any) => {
    dispatch({
      type: Types.IS_TOAST_ENABLED,
      payload
    })
  }
}
export const rowClassName = (rowData: any) => {
  // console.log('...72',rowData)
  return rowData.isActive ? '' : 'rowDisabled'
}
// console.log('rowdat72..',rowData)




// api for notifications 

export const fetchStudyNotifications: any = (userName: any, roleId: any) => {
  const url = `${requests.pushNotification.notifications}?&userName=${userName}&roleId=${roleId}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: '',
    })
      .then((response) => {
        // console.log("fetchStudyNotifications",response.data);
        const userNotificationDetails = response.data.userNotificationDetails;
        // Added condition for dispatch only array data to reducer for not getting run time bug in QA/Dev for notification data - Akshay
        dispatch({
          type: Types.FETCH_STUDY_NOTIFICATIONS, payload: userNotificationDetails ? userNotificationDetails : []
        })
        dispatch(Loader(false));
      }).catch((error: any) => {
        console.log('error', error)
      })

  }
}

// API for delete notifications

export const deleteNotificationByID: any = (Id: any, callback: any) => {
  const url = `${requests.pushNotification.deleteNotification}?id=${Id}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: url,
      data: ''
    }).then((response) => {
      if (callback) { callback(response.data) }
    }).catch((err:any)=>{})
  }
}

// api for admin config data
export const fetchConfigData: any = (param: any, callback: any) => {
  const url = `${requests.configDataType}/${param}`
  return function (dispatch: any) {
    // dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: '',
    })
    .then((response: any) => {
        console.warn('params.....', response)
        if (callback) { callback(response.data) }
        // dispatch(Loader(false))
      }).catch((err:any)=>{})
  }
}

export const saveConfigData: any = (payload: any) => {
  return (dispatch: any) => {
    dispatch({
      type: Types.CONFIG_DATA,
      payload: payload
    })
  }
}

export const getAssignRole: any = (userId: any) => {
  const url = `${requests.roles.getAssignRole}?userId=${userId}`
  return function (dispatch: any) {
    fetch({
      method: 'GET',
      url: url,
      data: null,
    })
      .then((response: any) => {
        dispatch({ type: Types.ROLE_SETTINGS, payload: response.data.roles });
      }).catch((error: any) => {
        console.log('error', error)
      })
  }
}

export const changeRole: any = (payload: any, callback: any) => {
  const url = `${requests.roles.changeRole}?roleId=${payload.roleId}&userId=${payload.userId}`
  return function () {
    fetch({
      method: 'POST',
      url: url,
      data: null,
    })
      .then((response: any) => {
        if (callback) { callback(response.data) }
      }).catch((error: any) => {
        console.log('error', error)
      })
  }
}

// api for fetching all  config data
export const fetchAllConfigData: any = () => {
  const url = requests.fetchAllConfigDataType
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: null,
    })
      .then((response: any) => {
        dispatch({ type: Types.FETCH_ALL_CONFIG_DATA, payload: response.data });
        // if (callback) { callback(response.data) }
        dispatch(Loader(false))
      }).catch((err: any) => {
        console.log('err........', err)
      })
  }
}