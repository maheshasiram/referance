export const url = [
    {
        org: "some org 1",
        studiesCount: "12",
        status: "Operational",
        checkLink: "https:google.com"
    },
    {
        org: "some org 2",
        studiesCount: "12",
        status: "Major Outage",
        checkLink: "https:google.com"
    },
    {
        org: "some org 3",
        studiesCount: "11",
        status: "Partial Outage",
        checkLink: "https:google.com"
    },
    {
        org: "some org 4",
        studiesCount: "13",
        status: "Maintenance",
        checkLink: "https:google.com"
    }
]