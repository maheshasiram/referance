export const viewstudy = [
    {
        studyName: "study 1",
        status: true,
    },
    {
        studyName: "study 2",
        status: false,
    },
    {
        studyName: "study 3",
        status: false,
    }
]