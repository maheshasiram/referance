import { fetch } from '../../../Constants/fetch';
import { requests } from '../../../configs/env';
import { Loader } from '../../../actions/actions';
import { Types } from '../constants/Types';

export const organizationUrl: any = (id: any) => {
    console.log(id);

}
export const getAllOrgHealthCheckList: any = (callback: any) => {
    const url = `${requests.healthStatus.getAllOrganizationHealthCheckList}`
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'GET',
            url: url,
            data: ''
        })
            .then((response: any) => {
                // console.log("..33", response?.data);
                dispatch({ type: Types.ORGANIZATION_URL, payload: response.data })
                if (callback) {
                    callback(response.data)
                }
                dispatch(Loader(false));
            })
            .catch(err => console.log("...err", err))
    }
}


export const fetchAllStudyDomainHealthCheck: any = (orgDomianHealthCheckId: any, callback: any) => {
    console.log("..87", orgDomianHealthCheckId);
    const url = `${requests.healthStatus.fetchAllStudyDomainHealthCheck}?orgHealthCheckId=${orgDomianHealthCheckId}`
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'GET',
            url: url,
            data: ''
        })
            .then((response: any) => {
                // console.log("..133", response?.data);
                dispatch({ type: Types.VIEW_STUDY_ORG, payload: response.data })
                if (callback) {
                    callback(response.data)
                }
                dispatch(Loader(false));
            }).catch((error: any) => {
                console.log('error', error)
            })
    }
}

export const getAllUsers: any = (callback: any) => {
    const url = `${requests.healthStatus.getAllUsers}`
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'GET',
            url: url,
            data: ''
        })
            .then((response: any) => {
                console.log("..13", response?.data);
                dispatch({ type: Types.NOTIFY_USER, payload: response.data })
                if (callback) {
                    callback(response.data)
                }
                dispatch(Loader(false));
            }).catch((error: any) => {
                console.log('error', error)
            })
    }
}

export const saveCheckUserNotify: any = (name: any, callback: any) => {
    const url = `${requests.healthStatus.saveOrgDomainHealthCheckUserNotify}?name=${name}`
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'POST',
            url: url,
            data: ''
        })
            .then((response: any) => {
                console.log("..123", response?.data);
                dispatch({ type: Types.SAVE_NOTIFY_USER, payload: response.data })
                if (callback) {
                    callback(response.data)
                }
                dispatch(Loader(false));
            }).catch((error: any) => {
                console.log('error', error)
            })
    }
}

export const saveStudyDomainHealthCheck: any = (callback: any) => {
    const url = `${requests.healthStatus.saveStudyDomainHealthCheck}`
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'POST',
            url: url,
            data: ''
        })
            .then((response: any) => {
                console.log("..123", response?.data);
                dispatch({ type: Types.SAVE_STUDIES_HEALTH_CHECK, payload: response.data })
                if (callback) {
                    callback(response.data)
                }
                dispatch(Loader(false));
            }).catch((error: any) => {
                console.log('error', error)
            })
    }
}

export const saveOrgHealthCheck: any = (callback: any) => {
    const url = `${requests.healthStatus.saveOrganizationDomainHealthCheck}`
    return function (dispatch: any) {
        // dispatch(Loader(true));
        fetch({
            method: 'POST',
            url: url,
            data: ''
        })
            .then((response: any) => {
                console.log("..123", response?.data);
                dispatch({ type: Types.SAVE_NOTIFY_USER, payload: response.data })
                if (callback) {
                    callback(response.data)
                }
                // dispatch(Loader(false));
            }).catch((error: any) => {
                console.log('error', error)
            })
    }
}
