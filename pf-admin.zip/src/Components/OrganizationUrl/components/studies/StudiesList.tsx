import React from "react";
import { fetchAllStudyDomainHealthCheck } from "../../actions/Actions";
import { useDispatch, useSelector } from "react-redux";
import VisibilityIcon from '@mui/icons-material/Visibility';
import CustomDialog from "../../../../Common/modals/CustomDialog";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import CancelOutlinedIcon from '@mui/icons-material/CancelOutlined';
import CheckCircleOutlineRoundedIcon from '@mui/icons-material/CheckCircleOutlineRounded';


function StudiesList(props: any) {
    const dispatch = useDispatch();
    const { item } = props
    const [openStudy, setOpenStudy] = React.useState(false);
    const { viewStudyOrgUrl } = useSelector((state: any) => state.OrganizationStatusUrl);

    const onCloseHandler = () => {
        setOpenStudy(false)
    }
    const onViewStudies = () => {
        setOpenStudy(true)
        console.log("..32", item);
        dispatch(fetchAllStudyDomainHealthCheck(item?.orgHealthCheckId));

    }
    const DevActionsBodyTemplate = (i: any) => {
        return (
            <div className="">
                {i.devStatusCode === "HEALTH_CHECK_STATUS_MAINTANENCE"
                    ? <CancelOutlinedIcon className="text-danger" /> : i.devStatusCode === "HEALTH_CHECK_STATUS_OPERATIONAL" ? <CheckCircleOutlineRoundedIcon className="text-success " /> : '-'}

            </div>
        )
    }
    const ProdActionsBodyTemplate = (i: any) => {
        return (
            <div className="">
                {i.prodStatusCode === "HEALTH_CHECK_STATUS_MAINTANENCE"
                    ? <CancelOutlinedIcon className="text-danger" /> : i.prodStatusCode === "HEALTH_CHECK_STATUS_OPERATIONAL" ? <CheckCircleOutlineRoundedIcon className="text-success " /> : '-'}
            </div>
        )
    }
    const UatActionsBodyTemplate = (i: any) => {
        return (
            <div className="">
                {i.uatStatusCode === "HEALTH_CHECK_STATUS_MAINTANENCE"
                    ? <CancelOutlinedIcon className="text-danger" /> : i.uatStatusCode === "HEALTH_CHECK_STATUS_OPERATIONAL" ? <CheckCircleOutlineRoundedIcon className="text-success " /> : '-'}
            </div>
        )
    }
    return (
        <React.Fragment>
            <span><VisibilityIcon className="eye-icon" onClick={onViewStudies} /> </span>
            <CustomDialog
                title={"Studies Status Overview"}
                onClose={onCloseHandler}
                // onSubmitHandler={() => { }}
                fullWidth={true}
                open={openStudy}
                maxWidth={'sm'}
                className="create-dy-field"
                // actionType={'Close'}
                closeType='Close'
            >
                <div>
                    {viewStudyOrgUrl && <div className=" m-2 ">

                        <DataTable
                            value={viewStudyOrgUrl}
                            responsiveLayout="scroll"
                        >
                            <Column field='studyName' header="Study Name "></Column>
                            <Column body={DevActionsBodyTemplate} header="Dev"></Column>
                            <Column body={ProdActionsBodyTemplate} header="Dev"></Column>
                            <Column body={UatActionsBodyTemplate} header="Dev"></Column>
                        </DataTable>
                    </div>}
                </div>

            </CustomDialog>

        </React.Fragment>
    )
}
export default StudiesList
