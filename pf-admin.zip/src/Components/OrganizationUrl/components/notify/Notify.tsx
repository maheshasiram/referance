import React from "react";
import CustomDialog from "../../../../Common/modals/CustomDialog";
import { Formik, Form, Field } from 'formik';
import { notifyValidation } from "../../Helpers/Validate";
import { useDispatch, useSelector } from 'react-redux';
import { getAllUsers, saveCheckUserNotify } from "../../actions/Actions";
import { toastAlert } from "../../../../actions/actions";
import { toastMsg } from "../../../../Common/Messages";
import { messages } from "../../../../configs/messages";


function Notify() {
    const dispatch = useDispatch();
    const [open, setOpen] = React.useState(false);
    const { OrgHealthStatus, notifyUser } = useSelector((state: any) => state.OrganizationStatusUrl);
    // let _payload: any;


    const onCloseHandler = () => {
        setOpen(false)
    }
    const onOpenNotify = () => {
        dispatch(getAllUsers())
        setOpen(true)

    }
    const onSubmitHandler = (values: any) => {
        console.log("...654", values)
        dispatch(saveCheckUserNotify(values?.notify, (response: any) => {
            if (response) {
                dispatch(toastAlert({
                    status: 1,
                    message: toastMsg(messages.HealthStatusMsgs.submit, ''),
                    open: true
                }));
                setOpen(false)
            }
        }))
    }
    const onChangeNotifyUser = () => {
        // _payload = notifyUser && notifyUser.find((element: any) => element.id === parseInt(e.target.value));
    }

    return (
        <React.Fragment>
            <div className="notify-form">
                <div>
                    <a href="# " className="notify-align" onClick={() => onOpenNotify()}> Notify </a>
                </div>
                <CustomDialog
                    title={"Notify User"}
                    onClose={onCloseHandler}
                    onSubmitHandler={' '}
                    fullWidth={true}
                    open={open}
                    form="notifyuser"
                    maxWidth={'xs'}
                    className="create-dy-field"
                    actionType={'Submit'}
                >
                    <Formik
                        initialValues={OrgHealthStatus}
                        validationSchema={notifyValidation}
                        onSubmit={(values: any) => { onSubmitHandler(values) }}
                    >
                        {({ errors, values, setFieldValue }) => (
                            <div className="m-3 Notify-algnments">
                                <>{console.log("68....", errors)}</>
                                <Form id="notifyuser" className="d-block">
                                    <div className="fld">
                                        <label id='notify'><b>Notify user :</b><span className='text-danger mx-1'>*</span> </label>
                                        <Field
                                            name='notify'
                                            as='select'
                                            value={values.notify}
                                            className="form-select select-field"
                                            placeholder={"Select notify user"}
                                            onChange={(e: any) => {
                                                onChangeNotifyUser()
                                                setFieldValue('notify', e.target.value)
                                            }}
                                        >
                                            <option value=''>Select notify user</option>
                                            {notifyUser && notifyUser.map((item: any, index: any) => {
                                                return (
                                                    <option key={index} value={item?.userName}>{item?.userName}</option>
                                                )
                                            })}
                                        </Field>
                                        <div className='text-danger'>{errors.notify as string}</div>
                                    </div>
                                </Form>

                            </div>
                        )}
                    </Formik>

                </CustomDialog>
            </div>
        </React.Fragment>
    )
}
export default Notify;