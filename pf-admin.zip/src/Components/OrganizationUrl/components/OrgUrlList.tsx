import React from "react";
import StudiesList from "./studies/StudiesList";
import Notify from "./notify/Notify";
import RecentActorsIcon from '@mui/icons-material/RecentActors';
import MonitorHeartIcon from '@mui/icons-material/MonitorHeart';
import { useDispatch, useSelector } from 'react-redux';
import { getAllOrgHealthCheckList, saveOrgHealthCheck, saveStudyDomainHealthCheck } from "../actions/Actions";

function OrgUrlList() {
    const dispatch = useDispatch();
    const { orgUrl } = useSelector((state: any) => state.OrganizationStatusUrl);
    const loaded = React.useRef(false);

    React.useEffect(() => {
        if (!loaded.current) {
            dispatch(saveOrgHealthCheck(() => {
                dispatch(getAllOrgHealthCheckList(() => {
                    dispatch(saveStudyDomainHealthCheck());
                }))
            }))
            loaded.current = true
        }
    }, [dispatch])

    console.log("..88", orgUrl);

    return (
        <React.Fragment>
            <div className="card card-container"  >
                <ul className="list-group list-group-flush">
                    <li className="list-group-item mt-4"><span><RecentActorsIcon /></span>Organizations Url status </li>
                    <div className="card sub-container">
                        <ul className="list-group list-group-flush">
                            <li className="list-group-item mt-4"><span><MonitorHeartIcon /></span>Global Organization service health status </li>
                            <div className="card sub-content">
                                {orgUrl && orgUrl.map((item: any, index: number) => {
                                    return (
                                        <div className="card-body d-flex" key={index}>
                                            <div className="col-sm-3 org-font">
                                                <h6>Organization Name</h6> {item.orgName}
                                            </div>
                                            <div className="col-borders">|</div>
                                            <div className="col-sm-2 studies-border">
                                                <div><h6>Studies</h6>{item.studiesCount}
                                                </div><StudiesList item={item} /> </div>
                                            <div className="col-borders">|</div>
                                            <div className="col-sm-3 studies-border">
                                                <h6>Status</h6>
                                                <span className={`${item.statusName === "Operational" ? "operation-color" : item.statusName === "Major Outage" ? "majoroutage-color" : item.statusName === "Partial Outage" ? "partial-outage-colr" : item.statusName === "Maintanence" ? "maintenance-color" : ''}`}>
                                                    {item.statusName} </span>
                                                {/* <span className={`${item.status === "HEALTH_CHECK_STATUS_OPERATIONAL" ? "operation-color" : item.status === "HEALTH_CHECK_STATUS_MAJOR_OUATGE" ? "majoroutage-color" : item.status === "HEALTH_CHECK_STATUS_PARTIAL_OUTAGE" ? "partial-outage-colr" : item.status === "HEALTH_CHECK_STATUS_MAINTANENCE" ? "maintenance-color" : ''}`}>
                                                {`${item.statusName === "HEALTH_CHECK_STATUS_OPERATIONAL" ? "Operational" : "HEALTH_CHECK_STATUS_MAINTANENCE" ? "Maintenance" : "HEALTH_CHECK_STATUS_PARTIAL_OUTAGE" ? "Partial Outage" :"HEALTH_CHECK_STATUS_MAJOR_OUATGE" ? "Major Outage"  : ''}`} </span> */}
                                            </div>
                                            <div className="col-borders">|</div>
                                            <div className="col-sm-3 notifyBorder"><h6>Action</h6><Notify /> </div>
                                        </div>
                                    )

                                })}
                            </div>
                        </ul>
                    </div >
                </ul >
            </div >

        </React.Fragment >
    )
}
export default OrgUrlList;