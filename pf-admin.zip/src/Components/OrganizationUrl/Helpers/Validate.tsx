import * as Yup from 'yup';

export const notifyValidation = Yup.object().shape({
    notify: Yup.string()
        .required("Please select notify user"),
    
})