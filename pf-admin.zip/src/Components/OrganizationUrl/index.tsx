import React from "react";
import OrgUrlList from './components/OrgUrlList';
import './Styles/Styles.scss'

function index() {
    return (
        <React.Fragment>
            <div>
                <OrgUrlList />
            </div>
        </React.Fragment>
    )
}
export default index;