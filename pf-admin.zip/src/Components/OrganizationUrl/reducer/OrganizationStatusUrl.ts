import { Types } from '../constants/Types'


const initialState = {
    OrgHealthStatus: { notifyUser: ''},
    orgUrl: [],
    viewStudyOrgUrl: [],
    notifyUser: [],
    saveNotify: null,
    saveStudies:null,
    saveOrghealtheck:null
}

export const OrganizationStatusUrl = (state = initialState, action: { type: any, payload: any }) => {

    switch (action.type) {
        case Types.ORG_HEALTH_STATUS:
            return { ...state, OrgHealthStatus: action.payload }
        case Types.ORGANIZATION_URL:
            return { ...state, orgUrl: action.payload }
        case Types.VIEW_STUDY_ORG:
            return { ...state, viewStudyOrgUrl: action.payload }
        case Types.NOTIFY_USER:
            console.log("..145", action.payload);
            return { ...state, notifyUser: action.payload }
        case Types.SAVE_NOTIFY_USER:
            return { ...state, saveNotify: action.payload }
            case Types.SAVE_STUDIES_HEALTH_CHECK:
            return { ...state, saveStudies: action.payload }
            case Types.SAVE_ORG_HEALTH_STATUS:
                return { ...state, saveOrghealtheck: action.payload }
        default:
            return { ...state }
    }
}