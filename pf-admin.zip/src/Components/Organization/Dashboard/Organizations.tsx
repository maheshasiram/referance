/* eslint-disable no-lone-blocks */

import { DataTable } from 'primereact/datatable';
import 'primeicons/primeicons.css';
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import { Column } from 'primereact/column';
import { NavLink, useNavigate } from 'react-router-dom';
import React, { useState, useRef } from 'react';
import {
  EditOrganizationById, statesByCountry, citiesByStates, deleteOrganization,
  findAllOrganizationsByStatus, Downloads, restoreOrganization, getConfigdataByCode
} from '../actions/actions';
import { useDispatch, useSelector } from 'react-redux';
import { Types } from '../reducer/Types';
import { Alert, Confirm, toastAlert } from '../../../actions/actions';
import GroupAddIcon from '@mui/icons-material/GroupAdd';
import PrimaryContactPopover from '../Helpers/PrimaryContactPopover';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
// import { ValidateRole } from '../../../actions/actions';
import { Button } from 'primereact/button';
// import autoTable from 'jspdf-autotable'
import CustomizedTooltip from '../../../Common/CustomizedTooltip/CustomizedTooltip';
import { messages } from '../../../configs/messages';
import { useTranslation } from 'react-i18next';
import ClearSharpIcon from '@mui/icons-material/ClearSharp';
import { confirmMsg, toastMsg } from '../../../Common/Messages';
import Loader from '../../../Common/Loader';
import _ from "lodash";



const Organizations = () => {
  const { t } = useTranslation();
  const { user, allConFigData } = useSelector((state: any) => state.app)
  const { fetchAllOrganization, createOrgInitialVal, organizationParams, jobDetailsDownload } = useSelector((state: any) => state.organization);
  // const [first, setFirst] = React.useState(0);
  const [filter, setFilter] = React.useState('orgName');
  const [searchValue, setSearchValue] = React.useState('')
  const [statusValue, setStatusValue] = React.useState('true');
  const [pageClick, setpageChange] = useState(false);

  const dt = useRef(null)
  const dispatch = useDispatch();

  const navigate = useNavigate();
  const loaded = React.useRef(false);

  React.useEffect(() => {
    if (!loaded.current) {
      dispatch(getConfigdataByCode('CONTACT_TYPE'))
      const payload: any = { ...organizationParams, limit: 10, offset: 0, orgName: '', country: '', phoneNo: "", status: true };
      dispatch({ type: Types.ORGANIZATION_PARAMS, payload: payload });
      dispatch(findAllOrganizationsByStatus(payload))
      loaded.current = true
    }
  }, [organizationParams, dispatch]);

  const onUpdateOrganization = (rowData: any) => {
    dispatch({ type: Types.SUPER_ADMIN, payload: true })
    dispatch({ type: Types.ACTION_TYPE, payload: 'edit' })
    setStatusValue("true")
    navigate('/createorganization', { state: { actionType: 1 } })
    dispatch(EditOrganizationById(rowData.id, (response: any) => {
      dispatch(statesByCountry(response.country.id))
      dispatch(citiesByStates(response.state.id))
    }));
  }

  const onDeleteOrganization = (rowData: any) => {
    dispatch(Confirm({
      status: 0,
      message: confirmMsg(messages.organization.deleteOrganization, rowData.orgName),
      onOk: () => {
        dispatch(deleteOrganization(rowData.id, (response: any) => {
          if (response.status === 500) {
            (dispatch as any)(Alert({
              status: 1,
              message: response.error,
              onOk: () => {
                console.log('..', response.error);
              }
            }))
          }
          else if (!response.errorCode) {
            const _payload = { ...organizationParams, offset: 0 }
            dispatch(findAllOrganizationsByStatus(_payload))
            dispatch({ type: Types.ORGANIZATION_PARAMS, payload: _payload });
            dispatch(toastAlert({
              status: 1,
              message: toastMsg(messages.commonMessages.inActivated, rowData.orgName),
              open: true
            }))
          }
          else {
            if (response.errorCode) {
              (dispatch as any)(Alert({
                status: 1,
                message: response.errorMessage,
                onOk: () => { return '' }
              }))
            }
          }
        }))
      }
    }))
  }

  const onRestoreOrganization = (rowData: any) => {
    dispatch(Confirm({
      status: 0,
      message: confirmMsg(messages.organization.ActiveOrg, rowData.orgName),
      onOk: () => {
        dispatch(restoreOrganization(rowData.id, (response: any) => {
          if (!response.errorCode) {
            const payload = { ...organizationParams, status: rowData.isActive, offset: 0 }
            dispatch(findAllOrganizationsByStatus(payload))
            dispatch({ type: Types.ORGANIZATION_PARAMS, payload: payload });
            dispatch(toastAlert({
              status: 1,
              message: toastMsg(messages.commonMessages.orgNameActivated, rowData.orgName),
              open: true
            }))
          }
        }));
      }
    }));
  }

  const actionsBodyTemplate = (rowData: any) => {
    // eslint-disable-next-line no-script-url
    if (rowData.isActive) {
      return <div className='d-flex actions justify-content-center'>
        {user?.userRolePrivileges?.data.EditOrganization && <CustomizedTooltip title={t("Edit Organization")}><EditIcon onClick={() => onUpdateOrganization(rowData)} sx={{ fontSize: 14, opacity: .8 }} /></CustomizedTooltip>}
        {user?.userRolePrivileges?.data.EditOrganization && user?.userRolePrivileges?.data.DeleteOrganization && <span>|</span>}
        {user?.userRolePrivileges?.data.DeleteOrganization && <CustomizedTooltip title={t("Delete Organization")}><DeleteIcon onClick={() => { onDeleteOrganization(rowData) }} sx={{ fontSize: 14, opacity: .8 }} /></CustomizedTooltip>}
      </div>
    } else {
      return (
        user?.userRolePrivileges?.data.RestoreOrganization && <div className='actions'><a href='# ' onClick={() => { onRestoreOrganization(rowData) }}>{t("Activate")}</a></div>
      )
    }
  }

  const primaryContactTemplate = (rowData: any) => {
    return (
      rowData.orgContacts.map((item: any, index: any) => (
        (item?.contactType?.code === allConFigData?.PrimaryContact) &&
        (<div key={index}>
          <PrimaryContactPopover
            firstName={item.firstName}
            lastName={item.lastName}
            email={item.email}
            phone={item.phoneNo}
          />
        </div>)

      )
      )
    )
  }

  const orgBodyTemplate = (rowData: any) => {
    // console.log('rowData176...', rowData)
    return (rowData.isActive ?
      <a className='org-name'
        //  href={`${rowData.companyUrl}`} 
        href={`https://www.google.com`}
        target="_blank" rel="noopener noreferrer external">{rowData.orgName}</a> : <span>{rowData.orgName}</span>)
  }

  const onPageClick = (event: any) => {
    // setFirst(event.first)
    if ((event.page > 0 || (pageClick && event.page === 0)) && organizationParams.offset !== event.first) {
      const _payload = {
        ...organizationParams, offset: event.first,
        country: searchValue !== '' && filter === 'countryName' ? searchValue : organizationParams.country,
        orgName: searchValue !== '' && filter === 'orgName' ? searchValue : organizationParams.orgName,
        phoneNo: searchValue !== '' && filter === 'phone' ? searchValue : organizationParams.phoneNo
      }
      // dispatch(findAllOrganizationsByStatus(_payload));
      dispatch({ type: Types.ORGANIZATION_PARAMS, payload: _payload });
      dispatch(findAllOrganizationsByStatus(_payload));
      setpageChange(true)
    }
  }

  const onChangeOrgStatus = (e: any) => {
    setStatusValue(e.target.value === 'true' ? 'true' : 'false')
    const payload = { ...organizationParams, status: e.target.value, limit: 10, offset: 0, orgName: '', country: '', phoneNo: "" }
    dispatch({ type: Types.ORGANIZATION_PARAMS, payload: payload })
    setSearchValue('');
    dispatch(findAllOrganizationsByStatus(payload))
  }


  const onFilterChange = (e: any) => {
    setSearchValue('');
    setFilter(e.target.value)
    const _payload = { ...organizationParams, limit: 10, offset: 0, orgName: '', country: '', phoneNo: "" }
    dispatch({ type: Types.ORGANIZATION_PARAMS, payload: _payload })
    dispatch(findAllOrganizationsByStatus(_payload))
  }

  const onSearchOrgnization = (e: any) => {
    {
      if (filter === "orgName") {
        const payload = { ...organizationParams, orgName: e.target.value, offset: 0 }
        dispatch({ type: Types.ORGANIZATION_PARAMS, payload: payload });
        dispatch(findAllOrganizationsByStatus(payload))
      }
      else if (filter === "countryName") {
        const payload = { ...organizationParams, country: e.target.value, offset: 0 }
        dispatch({ type: Types.ORGANIZATION_PARAMS, payload: payload });
        dispatch(findAllOrganizationsByStatus(payload))
      }
      else if (filter === "phone") {
        const payload = { ...organizationParams, phoneNo: e.target.value, offset: 0 }
        dispatch({ type: Types.ORGANIZATION_PARAMS, payload: payload });
        dispatch(findAllOrganizationsByStatus(payload))
      }
    }
    // setFirst(0)
    setSearchValue(e.target.value);
  }
  // const _data = allOrganization && allOrganization.map((item: any, index: number) => {
  //   let _arr = [item.orgName, item.country?.name, item.state?.name, item.city?.name, item.postalZipCode, item.phone]
  //   item.orgContacts.map(
  //     (data: any) => {
  //       if (data.contactType && data.contactType.name != null && data.contactType.name === "Primary") {
  //         _arr.push(data.firstName + " " + data.lastName)
  //       }
  //     }
  //   );
  //   return _arr
  // });

  // const headers = [`${t("Name")}`, `${t("Country")}`, `${t("State")}`, `${t("City")}`, `${t("Zip")}`, `${t("Phone No")}`, `${t("Primary Contact")}`]

  const downloadFile = (e: any, fileType: any) => {
    const { orgName, phoneNo, country } = organizationParams;
    const _payload = _.cloneDeep(jobDetailsDownload);
    _payload.fileType = fileType
    _payload.searchColumns.orgName = orgName
    _payload.searchColumns.country = country
    _payload.searchColumns.phoneNo = phoneNo
    _payload.searchColumns.status = statusValue
    dispatch(Downloads(_payload))
  }

  const onClearSearch = () => {
    const payload = { ...organizationParams, orgName: '', phoneNo: '', country: '', offset: 0 }
    dispatch({ type: Types.ORGANIZATION_PARAMS, payload: payload });
    dispatch(findAllOrganizationsByStatus(payload))
    setSearchValue('');
  }

  return (
    <div className='main'>
      {!fetchAllOrganization && <Loader />}
      <h2>{t("Organizations")}</h2>
      <div className='d-flex mb-0 justify-content-between'>
        <div className="d-flex align-items-center export-buttons">
          {fetchAllOrganization?.totalRecords > 0 && <div className="d-flex align-items-center export-buttons">
            <CustomizedTooltip title={t("Download CSV")}><Button type="button" icon="pi pi-file" onClick={(e: any) => downloadFile(e, 'Csv')} data-pr-tooltip="CSV" /></CustomizedTooltip>
            <CustomizedTooltip title={t("Download Excel")}><Button type="button" icon="pi pi-file-excel" onClick={(e: any) => downloadFile(e, 'Excel')} className="p-button-success mx-2" data-pr-tooltip="XLS" /></CustomizedTooltip>
            <CustomizedTooltip title={t("Download PDF")}><Button type="button" icon="pi pi-file-pdf" onClick={(e: any) => downloadFile(e, 'PDF')} className="p-button-warning" data-pr-tooltip="PDF" /></CustomizedTooltip>
          </div>}
        </div>
        <div className='d-flex justify-content-end org-filters-section'>
          <div className="search-container align-items-center d-flex">
            <div className=" pe-2 selectBy"  >
              <select className="" onChange={(e) => onFilterChange(e)} >
                <option value="orgName">{t("Organization Name")}</option>
                <option value="countryName">{t("Country")}</option>
                <option value="phone">{t("Mobile No")}</option>
              </select>
            </div>
            <div className=" ms-2 align-items-center d-flex">
              <input className="form-input" value={searchValue} onChange={(e) => onSearchOrgnization(e)} placeholder={t("Search by Key")} />
              {searchValue && <span className='clearSearchIcon'><CustomizedTooltip title={t("Clear Search")}><ClearSharpIcon sx={{ fontSize: 15, opacity: .8 }} onClick={() => onClearSearch()} /></CustomizedTooltip></span>}
            </div>
          </div>
          <div className={'d-flex ustify-content-end'}>
            <div className={'d-flex filters'}>
              {user?.userRolePrivileges?.data?.CreateOrganization && <NavLink to="../createorganization" className='link-add-item addOrg-link' onClick={() => {
                dispatch({ type: Types.SUPER_ADMIN, payload: false })
                dispatch({ type: Types.ACTION_TYPE, payload: 'create' })
                dispatch({ type: Types.CREATE_OR_EDIT_ORGANIZATION, payload: createOrgInitialVal })
              }}>
                <GroupAddIcon style={{ fontSize: 15 }} />
                {`${t("Create Organization")}`}
              </NavLink>}
              <select className='form-select' value={statusValue} onChange={(e) => onChangeOrgStatus(e)}>
                <option value="true">{t("Active")}</option>
                <option value="false">{t("InActive")}</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      {fetchAllOrganization &&
        <div>
          <div className="card" >
            <DataTable value={fetchAllOrganization?.orgs}
              ref={dt}
              lazy
              responsiveLayout="scroll"
              paginator={(fetchAllOrganization?.totalRecords > organizationParams.limit) ? true : false}
              selectionMode="single"
              totalRecords={fetchAllOrganization?.totalRecords}
              rows={organizationParams.limit}
              onPage={onPageClick}
              first={organizationParams.offset}
            >
              <Column field="orgName" body={orgBodyTemplate} style={{ width: 200 }} header={t("Name")}></Column>
              <Column field="country.name" header={t("Country")}></Column>
              <Column field="state.name" header={t("State")}></Column>
              <Column field="city.name" header={t("City")}></Column>
              <Column field="postalZipCode" header={t("Zip")}></Column>
              <Column field="phone" header={t("Mobile No")}></Column>
              <Column field='orgContacts.firstName' body={primaryContactTemplate} header={t("Primary Contact")}></Column>
              {(user?.userRolePrivileges?.data.EditOrganization || user?.userRolePrivileges?.data.DeleteOrganization || user?.userRolePrivileges?.data.RestoreOrganization) && <Column style={{ textAlign: 'center' }} body={actionsBodyTemplate} header={t("Actions")}></Column>}
            </DataTable>
          </div>
        </div>
      }
    </div>
  )
}
export default Organizations;