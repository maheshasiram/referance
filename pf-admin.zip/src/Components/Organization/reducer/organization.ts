import { Types } from "./Types";
import { CreateOrganizationDeatils, orgDownloads } from '../Helpers/Models'
import _ from 'lodash';


const initialState = {
    allCountriesData: [],
    stateByCountry: [],
    cityByStates: [],
    createOrganization: CreateOrganizationDeatils,
    contactTypes: [],
    allOrganization: [],
    fetchAllOrganization: null,
    createOrgInitialVal: CreateOrganizationDeatils,
    actionType: 'create',
    searchedOrgnization: [],
    organizationCopy: [],
    orgTypes: [],
    backToStudy: false,
    // organizationParams: { studyId: 0, offset: 0, limit: 10, nameCriteria: '',siteIdName:'',countryName:'' },
    organizationParams: { status: true, limit: 10,  offset: 0, orgName: '', country: '',phoneNo: "" },
    jobDetailsDownload:orgDownloads

}

export const organization = (state = initialState, action: { type: any, payload: any }) => {
    switch (action.type) {
        case Types.FIND_ALL_ORGANIZATION:
            return {
                ...state,
                allOrganization: action.payload,
                organizationCopy: _.cloneDeep(action.payload)
            }
        case Types.ALL_COUNTRIES_DATA:
            return { ...state, allCountriesData: action.payload }
        case Types.STATE_BY_COUNTRY:
            return { ...state, stateByCountry: action.payload }
        case Types.CITIES_BY_STATES:
            return { ...state, cityByStates: action.payload }
        case Types.CREATE_OR_EDIT_ORGANIZATION:
            return { ...state, createOrganization: action.payload }
        case Types.CONTACT_CONFIG_DATA:
            return { ...state, contactTypes: action.payload }
        case Types.ACTION_TYPE:
            return { ...state, actionType: action.payload }
        case Types.ON_SEARCH_ORGNIZATION:
            return { ...state, searchedOrgnization: action.payload }
        case Types.FILTERED_ORGANIZATION:
            return { ...state, allOrganization: action.payload }
        case Types.ORG_TYPE_CONFIG_DATA:
            return { ...state, orgTypes: action.payload }
        case Types.BACK_TO_STUDY:
            return{ ...state, backToStudy: action.payload}    
        case Types.FIND_ALL_ORGANIZATION_BY_STATUS:
            return{ ...state, fetchAllOrganization: action.payload}    
        case Types.ORGANIZATION_PARAMS:
            return{ ...state, organizationParams: action.payload}    
            case Types.DETAILS_DOWNLOAD_JOB:
                return { ...state, jobDetailsDownload: action.payload }    
        default:
            return { ...state }
    }
}