import { CreateOrganization, orgDownloadsDatatype } from './DataTypes'

export type Response = {
    success: boolean
}

export type OrgContacts = [{
    id: '',
    organizationId: '',
    firstName: '',
    lastName: '',
    email: '',
    phoneNo: '',
    contactDesgn: '',
    contactType: {
        id: 0,
        name: '',
        code: '',
        description: '',
        configDataType: {
            id: '',
            name: '',
            code: '',
            description: ''
        }
    },
    active: boolean
}]

export const CreateOrganizationDeatils: CreateOrganization = {
    addressLine1: '',
    addressLine2: '',
    isActive: true,
    city: {
        id: '',
        name: '',
        state: {
            id: '',
            name: '',
            country: {
                id: '',
                name: '',
                countryCode: '',
                phoneCode: ''
            }
        }
    },
    companyUrl: '',
    country: {
        id: '',
        name: '',
        countryCode: '',
        phoneCode: ''
    },
    id: 0,
    orgContacts: [
        {
            active: true,
            contactDesgn: '',
            contactType: null,
            email: '',
            firstName: '',
            lastName: '',
            phoneNo: ''
        }
    ],
    orgName: '',
    phone: '',
    telephone: '',
    orgShortname: "",
    postalZipCode: '',
    state: {
        id: '',
        name: '',
        country: {
            id: NaN,
            name: '',
            countryCode: '',
            phoneCode: ''
        }
    },
    //update model on orgType
    orgType: {
        id: 0,
        name: "",
        code: "",
        description: "",
        configDataType: {
            id: 0,
            name: "",
            code: "",
            description: ""
        }
    }
    // {
    //     id: 0,
    //     organizationId: 0,
    //     type: {
    //         id: 0,
    //         name: '',
    //         code: '',
    //         description: '',
    //         configDataType: {
    //             id: 0,
    //             name: '',
    //             code: '',
    //             description: ''
    //         }
    //     }
    // }
}
// console.log(".......110",CreateOrganizationDeatils)

export const orgDownloads: orgDownloadsDatatype = {
    "fileType": "",
    "reportName": "Organisation Details",
    "columnNames": [
        "Name", "Country", "State", "City", "Zip", "Phone No", "Primary Contact"
    ],
    "searchColumns": {
        "country": "",
        "orgName": "",
        "phoneNo": "",
        "status": true
    }
}