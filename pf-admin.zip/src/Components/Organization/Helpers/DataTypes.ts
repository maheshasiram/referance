type country = {
    countryCode?: string
    id?: any
    name?: string
    phoneCode?: string
}
type state = {
    country?: country
    id?: any
    name?: string

}

type city = {
    id?: any
    name?: string
    state?: state
}
type configDataType = {
    code?: string
    description?: string
    id?: number
    name?: string
}

// type contactType = {
//     code?: string
//     configDataType?: configDataType
//     description?: string
//     id?: number
//     name?: string
// }

// type orgContacts =
//     [{
//         active?: boolean
//         contactDesgn?: string
//         contactType?: contactType
//         email?: string
//         firstName?: string
//         id?: number,
//         lastName?: string
//         phoneNo?: string,
//         studyId?: number,
//         userName?: string
//     }]

// type organizationType = {
//     code?: string
//     configDataType?: configDataType
//     description?: string
//     id?: number
//     name?: string
// }

type orgType = {
    id?: number,
    name?: string,
    code?: string,
    description?: string
    configDataType?: configDataType
}

// type orgType =
//     {
//         id?: any,
//         organizationId?: number
//         type?: {
//             id?: any
//             name?: string
//             code?: string
//             description?: string
//             configDataType?: {
//                 id?: number
//                 name?: string
//                 code?: string
//                 description?: string
//             }
//         }
//     }


export type CreateOrganization = {
    addressLine1?: string
    addressLine2?: string
    city?: city
    companyUrl?: string
    country?: country
    id?: number
    isActive?: boolean
    orgContacts?: any
    orgName?: string
    orgShortname?: string
    orgType?: orgType,
    passcode?: string
    phone?: string
    postalZipCode?: string
    state?: state
    telephone?: string
}

export type orgDownloadsDatatype = {
    columnNames?: any,
    fileType?: string,
    reportName?: string,
    searchColumns: {
        country?: string,
        orgName?: string,
        phoneNo?: string,
        status?: boolean
    }
}