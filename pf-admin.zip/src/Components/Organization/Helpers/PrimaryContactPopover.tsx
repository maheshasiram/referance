import * as React from 'react';
import Popover from '@mui/material/Popover';
import Typography from '@mui/material/Typography';
import { useTranslation } from 'react-i18next';


export default function PrimaryContactPopover(props: {
  
  firstName: string, lastName: string, email: string, phone: string
}) {
  const [anchorEl, setAnchorEl] = React.useState<HTMLElement | null>(null);

  const handlePopoverOpen = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handlePopoverClose = () => {
    setAnchorEl(null);
  };
  
  const { t } = useTranslation();



  const open = Boolean(anchorEl);
  const id = open ? 'simple-popover' : undefined;

  return (
    <div>
      <span aria-describedby={id}
        onMouseEnter={handlePopoverOpen}
        onMouseLeave={handlePopoverClose}
      >{props.firstName} {props.lastName}</span>

      <Popover
        id="mouse-over-popover"
        sx={{
          pointerEvents: 'none',
          boxShadow: 1,

        }}
        open={open}
        anchorEl={anchorEl}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'left',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'left',
        }}

        onClose={handlePopoverClose}
        disableRestoreFocus
      >
        <Typography component={'div'} sx={{ p: 2, boxShadow: 0, background: '#4b4c4c', color: '#FFF' }}>
          <div className='emui-popover'>
            <h6>{t("Contact Details")} :</h6>
            <p> <strong>{t("Email")}</strong>: {props.email}</p>
            <p><strong>{t("Phone")}</strong>: {props.phone}</p>
          </div>
        </Typography>
      </Popover>
    </div>
  );
}
