import { Types } from '../reducer/Types';
import { fetch } from '../../../Constants/fetch';
import { requests } from '../../../configs/env';
import { Loader } from '../../../actions/actions';
import { OrgContacts } from '../Helpers/Models';
import { Callback } from 'yup/lib/types';
import store from '../../../sagas/main';

// find all organization
export const findAllOrganizations: any = () => {
  const url = `${requests.organization.organizationDetails.findAllOrganizations}`
  return function (dispatch: any) {
    // dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        dispatch({ type: Types.FIND_ALL_ORGANIZATION, payload: response.data });
        dispatch({ type: Types.ON_SEARCH_ORGNIZATION, payload: response.data });
        // callback()  
        // dispatch(Loader(false));
      }).catch((error: any) => {
        console.log('error', error)
      })
  }
}

export const findAllCountries: any = () => {
  const url = requests.organization.countriesApi.allCountries
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        dispatch({ type: Types.ALL_COUNTRIES_DATA, payload: response.data })
        dispatch(Loader(false));
      }).catch((error: any) => {
        console.log('error', error)
      })
  }
}

export const statesByCountry: any = (id: any) => {
  const url = `${requests.organization.countriesApi.statesByCountry}?countryId=${id}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        dispatch({ type: Types.STATE_BY_COUNTRY, payload: response.data })
        dispatch(Loader(false));
      }).catch((error: any) => {
        console.log('error', error)
      })
  }
}

export const citiesByStates: any = (id: number) => {
  const url = `${requests.organization.countriesApi.citiesByStates}?stateId=${id}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        dispatch({ type: Types.CITIES_BY_STATES, payload: response.data })
        dispatch(Loader(false));
      }).catch((error: any) => {
        console.log('error', error)
      })
  }
}


// city details
export const findCityDetails: any = (cityId: number) => {
  const url = `${requests.organization.countriesApi.findCityDetails}?cityId=${cityId}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then(() => {
        // callback(response.data)
        // dispatch({ type: Types.CITIES_BY_STATES, payload: response.data })
        dispatch(Loader(false));
      }).catch((error: any) => {
        console.log('error', error)
      })
  }
}


// Contact donfig data
export const getConfigdataByCode: any = (code: string) => {
  const url = `${requests.organization.contactDetails.configData}/${code}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        // let _data = response.data
        // let _findContactIndex = _data.findIndex((item: any) => item.name == 'Clinical Trail')
        // _data[_findContactIndex].name = 'Others'
        // _data.splice(_findContactIndex, 1)
        // console.log('109data',_data)
        const orgContactTypes = response.data.filter((type: any) => type.code === store.getState().app.allConFigData.PrimaryContact || type.code === store.getState().app.allConFigData.SecondryContact ||
          type.code === store.getState().app.allConFigData.OthersContact)
        dispatch({ type: Types.CONTACT_CONFIG_DATA, payload: orgContactTypes })
        // dispatch({ type: Types.CONTACT_CONFIG_DATA, payload: response.data })
        dispatch(Loader(false));
      }).catch((error: any) => {
        console.log('error', error)
      })

  }
}

// Org type config data
export const fetchOrgTypes: any = () => {
  const url = requests.organization.orgTypes
  return function (dispatch: any) {
    dispatch(Loader(true))
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        // console.log("org type response.............", response.data.ORG_TYPE)
        dispatch({ type: Types.ORG_TYPE_CONFIG_DATA, payload: response.data.ORG_TYPE })
        dispatch(Loader(false))
      }).catch((error: any) => {
        console.log('error', error)
      })

  }
}

export const onUpdateOrganizationContact = (payload: OrgContacts, callback: any) => {
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: requests.organization.updateOrganizationContact,
      data: payload
    })
      .then((response: any) => {
        callback(response.data);
        dispatch(Loader(false));
      }).catch((error: any) => {
        console.log('error', error)
      })
  }
}


// Save or Update organization
export const saveORupdateOrganization: any = (payload: any, callback: Callback) => {
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: `${requests.organization.saveORupdateOrganization}`,
      data: payload
    })
      .then((response: any) => {
        callback(response.data)
        dispatch(Loader(false));
      }).catch((error) => {
        console.log("error....", error)
        // callback(error.response.data);
        // dispatch(Loader(false))
      })
  }
}

export const findAllOrganizationsByStatus: any = (payload: any) => {
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: `${requests.organization.findAllOrganizationsByStatus}`,
      data: payload
    })
      .then((response: any) => {
        dispatch({ type: Types.FIND_ALL_ORGANIZATION_BY_STATUS, payload: response.data })
        dispatch(Loader(false))
      }).catch((error: any) => {
        console.log('error', error)
      })
  }
}

// Edit Organization
export const EditOrganizationById: any = (id: number, callback: any) => {
  const url = `${requests.organization.findOrganizationById}/${id}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        callback(response.data)
        dispatch({ type: Types.CREATE_OR_EDIT_ORGANIZATION, payload: response.data })
        dispatch(Loader(false));
      }).catch((error: any) => {
        console.log('error', error)
      })

  }
}

export const onDeleteOrganizationContact: any = (contactId: number, callback: any) => {
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'DELETE',
      url: `${requests.organization.deleteOrganizationContact}/${contactId}`,
      data: ''
    })
      .then((response: any) => {
        callback(response.data)
        if (response.data) {
          dispatch(findAllOrganizations());
        }
        dispatch(Loader(false));
      }).catch((error: any) => {
        console.log('error', error)
      })
  }
}

// Delete organization
export const deleteOrganization: any = (id: number, callback: Callback) => {
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: `${requests.organization.deleteOrganization}/${id}`,
      data: ''
    }).then((response: any) => {
      callback(response.data)
      dispatch(Loader(false))
    }).catch((error) => {
      console.log("error", error)
    })
  }

}

//Restore organization
export const restoreOrganization: any = (id: any, callback: any) => {
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: `${requests.organization.restoreOrganization}?orgId=${id}`,
      data: ''
    }).then((response: any) => {
      if (callback) { callback(response.data) }
      dispatch(Loader(false))
    }).catch((error) => {
      console.log('error', error)
      // dispatch(Loader(false))
    })
  }
}

// defining type for create organization
export const navigateToCreate: any = (payload: any) => {
  return (dispatch: any) => {
    dispatch({ type: Types.ACTION_TYPE, payload: payload })
  }
}

//Back to study
export const backToStudy: any = (payload: any) => {
  return (dispatch: any) => {
    dispatch({ type: Types.BACK_TO_STUDY, payload: payload })
  }
}


//Organization Short name
// export const organizationShortName: any = (payload: any) => {
//   return (
//     console.log("..226 organization short name")
//   )
// }

export const Downloads: any = (payload: any) => {
  console.log("payload....290",payload)
  const url = `${requests.organization.Downloads}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: url,
      responseType: 'blob',
      data: payload
    })

      .then((blob: any) => {
        const url = window.URL.createObjectURL(new Blob([blob.data]));
        const fileType: any = payload.fileType === 'Excel' ? 'xls' : payload.fileType
        const link: any = document.createElement('a');
        link.href = url;
        link.setAttribute('download', `${payload.reportName + `${"."}` + fileType}`);
        // 3. Append to html page
        document.body.appendChild(link);
        // 4. Force download
        link.click();
        // dispatch({ type: Types.DETAILS_DOWNLOAD_JOB, payload: response.data });
        // if(callback){
        //   callback(response.data)
        // }
        dispatch(Loader(false));
      }).catch((error: any) => {
        console.log('error', error)
      })
  }
} 