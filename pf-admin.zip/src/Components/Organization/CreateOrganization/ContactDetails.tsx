import React, { useState } from 'react';
import { Field, FieldArray, ErrorMessage } from 'formik';
import AddCircleOutlineTwoToneIcon from '@mui/icons-material/AddCircleOutlineTwoTone';
import { getConfigdataByCode } from '../actions/actions';
import { useDispatch, useSelector } from 'react-redux';
import RemoveCircleOutlineIcon from '@mui/icons-material/RemoveCircleOutline';
import '../Styles/Styles.scss';
import CustomizedTooltip from '../../../Common/CustomizedTooltip/CustomizedTooltip'
import { useTranslation } from 'react-i18next';
import _ from "lodash";
function ContactDetails(props: any) {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const { values, setFieldTouched, setFieldValue, setExistPhoneContact, existPhoneContact, existEmailContact, setExistEmailContact, setMessage } = props;
  const { contactTypes, actionType } = useSelector((state: any) => state.organization);
  const { allConFigData } = useSelector((state: any) => state.app)

  const [contact] = useState({
    active: true,
    contactDesgn: '',
    contactType: {},
    email: '',
    firstName: '',
    lastName: '',
    phoneNo: ''
  })

  const loaded = React.useRef(false);
  React.useEffect(() => {
    if (!loaded.current) {
      dispatch(getConfigdataByCode('CONTACT_TYPE'))
      loaded.current = true
    }
  }, [dispatch])

  const onChangleHandler = (e: any, index: any) => {
    const contactType = contactTypes && contactTypes.find((element: any) => element.code === e.target.value);
    // if (contactType.code === "CONTACT_TYPE_PRIMARY_CONTACT") {
    //   setPrimaryContact("Primary contact already selected ")
    // }
    setFieldValue(`orgContacts.${index}.contactType`, contactType);
    props.onChangeContactType();
  }


  const onSetContactType = () => {

    const SecondaryContacts = values.orgContacts.findIndex((element: any) => element?.contactType?.code === allConFigData?.SecondryContact)
    const otherContacts = values.orgContacts.findIndex((element: any) => element?.contactType?.code === allConFigData?.OthersContact)
    if ((values.orgContacts.length === 1 || values.orgContacts.length === 2) && SecondaryContacts === -1) {
      const _Secondary = contactTypes && contactTypes.find((item: any) => item.code === allConFigData?.SecondryContact)
      return _Secondary
    } else if ((values.orgContacts.length === 2) && otherContacts === -1) {
      const _Others = contactTypes && contactTypes.find((item: any) => item.code === allConFigData?.OthersContact)
      return _Others
    }
  }

  const onValidateContactType = (contact: any) => {
    if (contact.contactType && contact.contactType.code !== allConFigData?.PrimaryContact) {
      // dispatch(Confirm({
      //   message: 'Do you want to remove this contact?', onOk: () => {
      //     return true;
      //   }
      // }))
      return true;
    }
    return false;
  }
  return (
    <React.Fragment>
      <FieldArray
        name='orgContacts'
        render={(contactsArr) => {
          const orgContacts: any = _.cloneDeep(values.orgContacts);
          return (
            <React.Fragment>
              <div className="Contact d-flex justify-content-between align-items-center mx-4">
                <h6 >{t("Contact Details")} :</h6>
                <span >
                  {actionType === 'create' && <CustomizedTooltip title={t("Add Contact")}>
                    <AddCircleOutlineTwoToneIcon
                      className={`${(orgContacts && orgContacts.length < 3) ? 'add-primary-icon' : 'add-secondary-icon'} orgicon`}
                      onClick={() => {
                        if (orgContacts && orgContacts.length < 3 && !existEmailContact && !existPhoneContact) {
                          contactsArr.push({ ...contact, organizationId: orgContacts[0].organizationId, contactType: onSetContactType() })
                        }
                      }} />
                  </CustomizedTooltip>}
                </span>
              </div>
              <hr className='m-0'></hr>
              <div className='text-danger text-center d-block'>{props.message ? props.message : <span>&nbsp;</span>}</div>
              {/* <div className='text-danger text-center d-block'>{primaryContact ? primaryContact : <span>&nbsp;</span>}</div> */}
              <div className='existOrgContact ms-4'>{existEmailContact ? existEmailContact : existPhoneContact}</div>
              <div className={`create-contact`}>
                {orgContacts && orgContacts.map((contact: any, index: number) => (
                  <div key={`${index}_div1`}>
                    {
                      // (orgContacts && orgContacts[index].contactType && orgContacts[index].contactType.name && orgContacts[index].name != "Clinical Trail"
                      // ) &&
                      <div className={`px-4 d-flex contact-title ${index > 0 ? 'mt-3' : ''}`} key={`${index}_div2`}>
                        {/* {ValidateRole() && <Field type='checkbox'
                          className="form-check-input rounded-circle"
                          name={`orgContacts.${index}.active`}
                        />} */}
                        <label className={`${orgContacts[index].active ? 'active' : 'inactive'}`}>
                          {orgContacts && orgContacts[index].contactType && orgContacts[index].contactType.name}</label>
                        {/* {orgContacts && orgContacts[index].contactType && orgContacts[index].contactType.description}</label> */}
                      </div>}
                    {
                      <div className='d-flex mb-2 mx-3 px-2' key={`${index}_div3`} >
                        <div className={`${values.id !== 0 ? 'e-column' : 'e-column-25'}`} key={`${index}_div4`}>
                          <div className='form-group'>
                            <label>{t("First Name")} :<span className='text-danger mx-1'>*</span></label>
                            <Field name={`orgContacts.${index}.firstName`}
                              aria-label="orgContacts.firstName"
                              className='input form-control'
                              value={values.orgContacts[index].firstName}
                              onChange={(e: any) => {
                                // if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
                                //   setFieldValue(`orgContacts.${index}.firstName`, e.target.value);
                                //   //  setDisableBtn(false);
                                // }
                                console.log('regex........', (/[^A-Za-z0-9.\s]/g.test(e.target.value)));
                                
                                if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || 
                                (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0) ) {
                                  setFieldValue(`orgContacts.${index}.firstName`, e.target.value);
                                  //  setDisableBtn(false);
                                }
                                setFieldTouched(`orgContacts.${index}.firstName`, true)
                                // setFieldValue(`orgContacts.${index}.firstName`, e.target.value.replace(/\s\s+/g, ' '))
                                props.enableSubmit(false)
                              }}
                              disabled={actionType === 'create' ? false : true}
                            />
                            <span className='text-danger'><ErrorMessage name={`orgContacts.${index}.firstName`} /></span>
                          </div>
                        </div>
                        <div className={`${values.id !== 0 ? 'e-column' : 'e-column-25'} mx-2`}>
                          <div className='form-group'>
                            <label>{t("Last Name")} :<span className='text-danger mx-1'>*</span></label>
                            <Field name={`orgContacts.${index}.lastName`}
                              aria-label="orgContacts.lastName"
                              className='input form-control'
                              value={values.orgContacts[index].lastName}
                              onChange={(e: any) => {
                                if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
                                  setFieldValue(`orgContacts.${index}.lastName`, e.target.value);
                                  //  setDisableBtn(false);
                                }
                                setFieldTouched(`orgContacts.${index}.lastName`, true)
                                props.enableSubmit(false)
                              }}
                              disabled={actionType === 'create' ? false : true}
                            // disabled={actionType === 'create' ? false : ValidateRole() ? false : true}
                            />
                            <span className='text-danger'><ErrorMessage name={`orgContacts.${index}.lastName`} /></span>
                          </div>
                        </div>
                        <div className={`${values.id !== 0 ? 'e-column' : 'e-column-25'} mx-2`}>
                          <div className='form-group'>
                            <label>{t("Email")} :<span className='text-danger mx-1'>*</span></label>
                            <Field name={`orgContacts.${index}.email`}
                              aria-label="orgContacts.email"
                              className='input form-control'
                              value={values.orgContacts[index].email}
                              disabled={actionType === 'create' ? false : true}
                              onChange={(e: any) => {
                                if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
                                  setFieldValue(`orgContacts.${index}.email`, e.target.value);
                                }
                                setFieldTouched(`orgContacts.${index}.email`, true)
                                props.enableSubmit(false);
                                if (e.target.value && orgContacts.filter((item: any) => e.target.value === item.email).length > 0) {


                                  setExistEmailContact("Entered email should not be same : " + e.target.value);
                                } else {
                                  setExistEmailContact('');
                                }
                              }}
                            />
                            <span className='text-danger'><ErrorMessage name={`orgContacts.${index}.email`} /></span>
                          </div>
                        </div>
                        <div className={`${values.id !== 0 ? 'e-column' : 'e-column-25'} mx-2`}>
                          <div className='form-group'>
                            <label>{t("Phone No")}:<span className='text-danger mx-1'>*</span></label>
                            <Field name={`orgContacts.${index}.phoneNo`}
                              type="number"
                              aria-label="orgContacts.phoneNo"
                              className='input form-control'
                              value={values.orgContacts[index].phoneNo}
                              disabled={actionType === 'create' ? false : true}
                              onKeyPress={(e: any) => {
                                if (e.key === "-" || e.key === "+" || e.key === "e" || e.key === ".") {
                                  e.preventDefault();
                                }
                              }}
                              onChange={(e: any) => {
                                setFieldTouched(`orgContacts.${index}.phoneNo`, true);
                                setFieldValue(`orgContacts.${index}.phoneNo`, e.target.value);
                                props.enableSubmit(false);
                                if (e.target.value && orgContacts.filter((item: any) =>
                                  e.target.value === item.phoneNo).length > 0) {
                                  setExistPhoneContact("Entered phone number should not be same : " + e.target.value);
                                } else {
                                  setExistPhoneContact('');
                                }
                              }}
                            />
                            <span className='text-danger'><ErrorMessage name={`orgContacts.${index}.phoneNo`} /></span>
                          </div>
                        </div>
                        {values.id !== 0 &&
                          <div className='e-column'>
                            <div className='form-group'>
                              <label>{t("Contact Details")} :</label>
                              <div className=''>
                                <Field
                                  as="select"
                                  className='form-select form-control-lg'
                                  name={`orgContacts.${index}.contactType.name`}
                                  value={values && values.orgContacts[index].contactType && values.orgContacts[index].contactType.code}
                                  disabled={actionType && actionType === 'create' ? false : (values.orgContacts.length > 1) ? false : true}
                                  // disabled={actionType && actionType === 'create' ? false : (values.orgContacts[index].contactType.code ==="CONTACT_TYPE_PRIMARY_CONTACT" ) ? true : false}
                                  onChange={(e: any) => {
                                    onChangleHandler(e, index);
                                    setFieldTouched(`orgContacts.${index}.contactType.name`, true)
                                    props.enableSubmit(false)
                                  }}
                                >
                                  {
                                    contactTypes && contactTypes.length > 0 && contactTypes.map((item: any, index: number) => {
                                      return (
                                        <option key={index} value={item.code}>{item.name}</option>
                                      )
                                    })
                                  }
                                </Field>
                              </div>
                            </div>
                          </div>}
                        {(onValidateContactType(contact)) && values.orgContacts[index].contactType.code !== allConFigData?.PrimaryContact &&
                          values.orgContacts.length !== 0 &&
                          <div className='e-column-del'>
                            <div className='form-group'>
                              <CustomizedTooltip title={t("Remove Contact")}>
                                <RemoveCircleOutlineIcon
                                  color="error"
                                  onClick={() => {
                                    setExistEmailContact('')
                                    setExistPhoneContact('')
                                    setMessage('')
                                    if (orgContacts.length <= 2) {
                                      const _primary = orgContacts.findIndex((i: any) => i.contactType.code === allConFigData?.PrimaryContact)
                                      if (_primary === -1 || (_primary === index)) {
                                        const _contactType = contactTypes && contactTypes.find((i: any) => i.code === allConFigData?.PrimaryContact)
                                        const _index = index === 0 ? 1 : 0
                                        setFieldValue(`orgContacts.${_index}.contactType`, _contactType);
                                      }
                                    }
                                    if (orgContacts.length > 1) {
                                      contactsArr.remove(index)
                                      props.enableSubmit(false)
                                    }
                                    // if(orgContacts[index].contactType.code !=="CONTACT_TYPE_PRIMARY_CONTACT"){
                                    //   alert()
                                    // }
                                    // if (orgContacts && orgContacts.map((item: any) => (item.contactType.code === "CONTACT_TYPE_PRIMARY_CONTACT"))) {
                                    //   // setMessage('one should be primary')
                                    //   // let _orgContacts = { ...{}, ...orgContacts[0].contactType }
                                    //   // console.log("orgcontacts...285", _orgContacts, orgContacts)
                                    //   // orgContacts[0].contactType = _orgContacts;
                                    //   // contactsArr.replace({ ...orgContacts[0], contactType: primaryContact })
                                    // }
                                    // if (!contact.id) {
                                    //   contactsArr.remove(index)
                                    //   // setExistEmailContact('')
                                    // } else {
                                    //   dispatch(Confirm({
                                    //     status: 0,
                                    //     message: messages.organization.deleteContact,
                                    //     onOk: () => {
                                    //       dispatch(onDeleteOrganizationContact(contact.id, (data: any) => {
                                    //         if (!data.errorCode) {
                                    //           dispatch(toastAlert({
                                    //             status: 1,
                                    //             message: toastMsg(messages.organization.deleteSucces, ''),
                                    //             open: true
                                    //           }))
                                    //           contactsArr.remove(index);
                                    //           props.enableSubmit(false)
                                    //         }
                                    //         else {
                                    //           if (data.errorCode) {
                                    //             dispatch(toastAlert({
                                    //               status: 1,
                                    //               message: toastMsg(messages.organization.deleteSucces, ''),
                                    //               open: true
                                    //             }))
                                    //             contactsArr.remove(index);
                                    //             props.enableSubmit(false)
                                    //           }
                                    //           else {
                                    //             if (data.errorCode) {
                                    //               dispatch(toastAlert({
                                    //                 status: 1,
                                    //                 message: toastMsg(data.errorMessage, ''),
                                    //                 open: true
                                    //               }))
                                    //               props.enableSubmit(false)
                                    //             }
                                    //           }
                                    //         }
                                    //       }))
                                    //     }
                                    //   }))
                                    // }
                                  }}
                                />
                              </CustomizedTooltip>
                            </div>
                          </div>
                        }
                      </div>
                    }
                  </div>
                ))
                }
              </div>
            </React.Fragment>
          )
        }}
      />
    </React.Fragment >
  )
}
export default ContactDetails