import React, { useState } from 'react';
import { Formik, Form } from 'formik';
import * as Yup from "yup";
import { useDispatch, useSelector } from 'react-redux';
import OrganizationDetails from './OrganizationDetails';
import CommonCard from '../../../Common/CommonCard';
import { findAllCountries, saveORupdateOrganization, fetchOrgTypes, backToStudy } from '../actions/actions'
import ContactDetails from './ContactDetails';
import { Alert, toastAlert } from '../../../actions/actions';
import { useNavigate } from 'react-router-dom';
import '../Styles/Styles.scss';

// import { ValidateRole } from '../../../actions/actions'; 

import { Types } from '../reducer/Types';
import { CreateOrganizationDeatils } from '../Helpers/Models';
import { useTranslation } from 'react-i18next';
import KeyboardDoubleArrowLeftIcon from '@mui/icons-material/KeyboardDoubleArrowLeft';

import _ from "lodash";

function CreateOrganization() {
  const { t } = useTranslation();

  const { createOrganization, actionType, orgTypes, allCountriesData, contactTypes } = useSelector((state: any) => state.organization);
  const { studyDetails } = useSelector((state: any) => state.study);
  const {  allConFigData } = useSelector((state: any) => state.app)
  

  const [message, setMessage] = useState('');

  const [btnState, setBtnState] = useState(true);
  const [existEmailContact, setExistEmailContact] = useState('');
  const [existPhoneContact, setExistPhoneContact] = useState('');

  const dispatch: any = useDispatch()
  const navigate = useNavigate()
  const loaded = React.useRef(false);

  React.useEffect(() => {
    if (!loaded.current) {
      if (allCountriesData && allCountriesData.length === 0) {
        dispatch(findAllCountries())
      }
      if (orgTypes && orgTypes.length === 0) {
        dispatch(fetchOrgTypes())
      }
      if (actionType === 'create' || actionType === 'fromStudy') {
        const payload = _.cloneDeep(CreateOrganizationDeatils);
        CreateOrganizationDeatils.orgContacts.map((cntype: any, index: number) => (cntype.contactType === null && (payload.orgContacts[index].contactType = contactTypes && contactTypes.find((element: any) => element.code === allConFigData?.PrimaryContact))))
        dispatch({ type: Types.CREATE_OR_EDIT_ORGANIZATION, payload: payload })
      }
      loaded.current = true
    }
  }, [actionType, allCountriesData, contactTypes, dispatch, orgTypes,allConFigData?.PrimaryContact])

  const CreateOrganizationSchema = Yup.object().shape({
    orgName: Yup.string()
      .required(t("Please Enter Organization Name"))
      .matches(/^[^\s]/, t("Organization name should not start with space")),
    addressLine1: Yup.string().required(t('Please Enter Address Line 1')).matches(/^[^\s]/, t("Address Should Not Start With Space")),
    addressLine2: Yup.string().matches(/^[^\s]/, t("Address Should Not Start With Space")),
    country: Yup.object().shape({ name: Yup.string().required(t("Please Select Country")) }),
    state: Yup.object().shape({ name: Yup.string().required(t("Please Select State")) }),
    city: Yup.object().shape({ name: Yup.string().required(t("Please Select City")) }),
    phone: Yup.string().required(t('Please Enter Phone Number'))
      .matches(/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/, t('Please Enter Valid Phone Number')),

    // .matches(/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/, t("Please Enter Valid Phone Number"))
    // .required(t("Please Enter Phone Number")),
    telephone: Yup.string()
      .required(t("Please Enter Telephone Number"))
      .matches(/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/, t("Please Enter Valid Telephone Number")),
    postalZipCode: Yup.string()
      .required(t("Please Enter Zip Code"))
      .min(5, t("Zip code should be minimum length of 5"))
      .max(9, t("Zip code should be maximum length of 9"))
      .matches(/^[+]?([0-9]+(?:[0-9]*)?|\.[0-9]+)$/, t('Please enter a valid Zip code.')),
    //website name should not start with http/https
    companyUrl: Yup.string()
      // .matches(/((https?):\/\/)?(www.)?[a-z0-9]+(\.[a-z]{2,}){1,3}(#?\/?[a-zA-Z0-9#]+)*\/?(\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$/,
      .matches(/^((!https?):\/\/)?(!www.)?[a-zA-Z0-9]+(\.[a-z]{2,}){1,3}(#?\/?[a-zA-Z0-9#]+)*\/?(\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$/,
        t('Enter correct website name (http/https) not allowed')).required(t('Please enter company website')),

    orgContacts: Yup.array().of(Yup.object().shape({
      email: Yup.string()
        .email(t('Please Enter Valid Email Address'))
        .required(t("Please Enter Email")),
      firstName: Yup.string()
        .required(t('Please Enter First Name'))
        .matches(/^[^\s]/, t("First name should not start with space"))
        .matches(/^[^\d]+$/, t("First name should not contain numbers"))
        .matches(/^[^*|":<>[\]{}`\\()~';@&$#!?%=_-]+$/, t('First name should not contain special characters')),
      lastName: Yup.string()
        .required(t('Please Enter Last Name'))
        .matches(/^[^\s]/, t("Last name should not start with space"))
        .matches(/^[^\d]+$/, t("Last name should not contain numbers"))
        .matches(/^[^*|":<>[\]{}`\\()~';@&$#!?%=_-]+$/, t("Last name should not contain special characters")),
      phoneNo: Yup.string()
        .required(t('Please Enter Phone Number'))
        .matches(/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/, t('Please Enter Valid Phone Number')),
      // contactType: Yup.object().shape({
      //   name: Yup.string()
      //     .required('Please select one contact')
      // })
    })
    ),
    // orgType: Yup.object().shape({
    //   type: Yup.object().shape({
    //     name: Yup.string().required(t("Please Select Organization Type")),
    //   })
    // })
    //   .required(t("Please Select Organization Type"))
    //   .nullable(),
    // orgType: Yup.object().shape({
    //   type: Yup.object().shape({
    //     name: Yup.string().required((t("Please Select Organization Type"))).nullable()
    //   })
    // }),
    orgType: Yup.object().shape({ name: Yup.string().required(t("Please Select Organization Type")).nullable() }),

    orgShortname: Yup.string()
      .required(t("Please Enter Organization Short Name"))
      // .matches(/^[^\s]/, t("Organization Short Name Should Not Start With Space"))
      .matches(/^[a-zA-Z]/, 'Organization short name Should Start With Only Text')
      // .max(8, "Maximun of 8 characters")
      .matches(/^[a-zA-Z0-9]+$/, "Special Characters And Spaces Are Not Allowed"),
  });
  const onChangeContactType = () => {
    setMessage('');
  }

  const onSubmitHandler = (values: any) => {

    setMessage('');
    const emailValues = values.orgContacts.map((item: any) => { return item.email })
    const duplicateEmail = emailValues.some((i: any, index: number) => {
      return emailValues.indexOf(i) !== index
    })

    const phoneValues = values.orgContacts.map((number: any) => { return number.phoneNo })
    const dupliactePhoneNumber = phoneValues.some((i: any, index: number) => {
      return phoneValues.indexOf(i) !== index
    })
    const primaryContacts = values.orgContacts.filter((contact: { contactType: { code: string } }) => contact && contact.contactType?.code === allConFigData?.PrimaryContact)
    const secondaryContacts = values.orgContacts.filter((contact: { contactType: { code: string } }) => contact && contact.contactType?.code === allConFigData?.SecondryContact)
    const otherContacts = values.orgContacts.filter((contact: { contactType: { code: string } }) => contact && contact.contactType?.code === allConFigData?.OthersContact)

    if (primaryContacts.length > 1) {
      setMessage(t("Orgnization Must Have Only One Primary Contact!"));
    } else if (secondaryContacts.length > 1) {
      setMessage(t("Orgnization  should have Only One Secondary Contact!"));
    } else if (otherContacts.length > 1) {
      setMessage(t("Orgnization should have Only One Others Contact!"));
    }
    // else if (primaryContacts.length === 0 && primaryContacts[0].contactType.code === "CONTACT_TYPE_PRIMARY_CONTACT") {
    //   setMessage(t("Orgnization must have atleast one primary contact!"));
    // } 
    else if (secondaryContacts.length === 1 && otherContacts.length === 1 && primaryContacts.length === 0) {
      setMessage(t("Orgnization must have atleast one primary contact!"));
    }
    else if (primaryContacts.length === 1 && primaryContacts[0].active === false) {
      setMessage(t("Orgnization must have atleast one primary contact!"));
    } else if (duplicateEmail) {
      setExistEmailContact("Entered email should not be same")
    } else if (dupliactePhoneNumber) {
      setExistPhoneContact("Entered Phone No should not be same")
    } else if (values.phone === values.telephone) {
      setMessage("Mobile-No & Telephone-No Should not be same")
    }
    else {
      dispatch(saveORupdateOrganization(values, (response: any) => {
        if (response.status === 500) {
          (dispatch as any)(Alert({
            status: 1,
            message: response.error,
            onOk: () => {
              console.log('...176');
            }
          }))
        }
        else if (response.success) {
          dispatch(toastAlert({
            status: 1,
            message: actionType === 'create' ? 'Organization Created Successfully' : 'Organization Update Successfully',
            open: true
          }))
          navigate("/organizations");
          // (dispatch as any)(Alert({
          //   status: 2,
          //   message: actionType === 'create' ? 'Organization Created Successfully' : 'Organization Update Successfully',
          //   onOk: () => {
          //     navigate("/organizations");
          //   }
          // }));
        }
        else {
          if (response.errorCode) {
            (dispatch as any)(Alert({
              status: 1,
              message: response.errorMessage,
              onOk: () => { return ''}
            }))
          }
        }
      }))
    }
  }

  const backToStudyHandler = () => {
    //dispatch(updateStudyPayload(createStudyPayload));
    navigate(`/createStudy/${studyDetails.id}`);
    dispatch({ type: Types.CREATE_OR_EDIT_ORGANIZATION, payload: CreateOrganizationDeatils })
    dispatch(backToStudy(true));
  }
  const onBackToOrganizationDetails = () => {
    if (actionType === 'create' || actionType === 'edit') {
      navigate('/organizations');
    } else {
      navigate('/createStudy/0');
    }
  }


  return (
    <React.Fragment>
      <div className=" d-flex justify-content-between">
        <h2>{(actionType === 'create' || actionType === 'fromStudy') ? `${t('Create Organization')}` : `${t('Update Organization')}`}</h2>
        <div className="backto-organization">
          <span onClick={onBackToOrganizationDetails}><KeyboardDoubleArrowLeftIcon /> Back To Organization</span>
        </div>
      </div>
      <CommonCard
        title={t('Create Organization')}
      >
        <Formik
          enableReinitialize={true}
          initialValues={createOrganization}
          validationSchema={CreateOrganizationSchema}
          onSubmit={(values) => {
            if (!existPhoneContact && !existEmailContact) { onSubmitHandler(values) }
          }}
        >
          {({ errors, touched, values, setFieldValue, setFieldTouched, setFieldError }) => (
            <Form id="createOrganization-submit" className='createOrganization-form' >
              <OrganizationDetails
                errors={errors}
                touched={touched}
                values={values}
                setFieldValue={setFieldValue}
                setFieldTouched={setFieldTouched}
                backToStudyHandler={backToStudyHandler}
                setFieldError={setFieldError}
                enableSubmit={(value: any) => setBtnState(value)}
                setMessage={setMessage}
              />
              <ContactDetails
                // isAdmin={(user.role !== 'admin' && actionType !== 'create') ? true : false}
                // isAdmin = {!ValidateRole() && actionType !== 'create' ? true : false }
                onChangeContactType={onChangeContactType}
                message={message}
                errors={errors}
                touched={touched}
                values={values}
                setFieldValue={setFieldValue}
                setFieldTouched={setFieldTouched}
                enableSubmit={(value: any) => setBtnState(value)}
                existEmailContact={existEmailContact}
                setExistEmailContact={setExistEmailContact}
                existPhoneContact={existPhoneContact}
                setExistPhoneContact={setExistPhoneContact}
                setMessage={setMessage}
              />
              <div className='d-flex justify-content-end px-4 py-4'>
                <button type='button' onClick={onBackToOrganizationDetails} className='btn-esecondary mx-2'>{t("Cancel")}</button>
                <button type='submit' className={btnState ? 'btn-esecondary' : 'btn-eprimary'} disabled={btnState}>{(actionType === 'create' || actionType === 'fromStudy') ? t('Submit') : t('Update')}</button>
              </div>
            </Form>
          )}
        </Formik>
      </CommonCard>
    </React.Fragment>
  )
}
export default CreateOrganization;

