import React from 'react';
import { Field, ErrorMessage } from 'formik';
import { useDispatch, useSelector } from 'react-redux';
import { statesByCountry, citiesByStates, findCityDetails } from '../actions/actions';
import { useTranslation } from 'react-i18next';
import { CreateOrganizationDeatils } from '../Helpers/Models';
import '../Styles/Styles.scss'

function OrganizationDetails(props: any) {
  const { t } = useTranslation();
  const dispatch = useDispatch()


  const { allCountriesData, stateByCountry, cityByStates, orgTypes, createOrganization } = useSelector((state: any) => state.organization);

  const { errors, values, setFieldTouched, setFieldValue, touched, enableSubmit, setMessage } = props

  const [cities, setCities] = React.useState([cityByStates])

  const onCountryChange = (e: any) => {
    const countryData = allCountriesData && allCountriesData.find((element: any) => element.name === e.target.value);
    setFieldTouched('country.name', true);
    countryData && dispatch(statesByCountry(countryData.id))
    setFieldValue('country', countryData ? countryData : CreateOrganizationDeatils.country);
    enableSubmit(false);
    if (e.target.value) {
      setFieldValue('city.name', '')
      setFieldValue('state.name', '')
      setCities([])
    } else {
      setFieldValue('city.name', '')
      setFieldValue('state.name', '')
    }
  }

  const onStateChange = (e: any) => {
    const stateData = stateByCountry && stateByCountry.find((element: any) => element.name === e.target.value);
    stateData && dispatch(citiesByStates(stateData.id))
    setFieldTouched('state.name', true);
    setFieldValue('city.name', '')
    setFieldValue('state', stateData ? stateData : CreateOrganizationDeatils.state);
    setCities([cityByStates])
    enableSubmit(false);
  }

  const onCityChange = (e: any) => {
    const cityData = cityByStates && cityByStates.find((element: any) => element.name === e.target.value)
    if (cityData) {
      dispatch(findCityDetails(cityData.id
      //   , () => {
      // }
      ))
    }
    setFieldTouched('city.name', true);
    setFieldValue('city', cityData ? cityData : CreateOrganizationDeatils.city)
  }

  // const onBackToOrganizationDetails = () => {
  //   navigate('/organizations');
  //   let _payload = { ...organizationParams, offset: 0 }
  //   dispatch({ type: Types.ORGANIZATION_PARAMS, payload: _payload });
  //   dispatch(findAllOrganizationsByStatus(_payload))
  // }

  // Telephone number validation for entering same mobile number ---- charan
  const validateTelephoneNumber = (e: any, values: any) => {
    let error;
    if (values.phone === values.telephone) {
      error = values.telephone === e ? 'Mobile No and telephone No, should not be same' : ""
    }
    return error;
  }

  return (
    <React.Fragment>
      <div className="d-flex justify-content-between align-items-center mx-4">
        <div><h6>{t("Organization Details")}</h6></div>
        {/* {actionType == 'fromStudy' ? 
        <div><button type='button' onClick={backToStudyHandler} className='btn btn-sm btn-secondary'>{`back to create Study`}</button></div>:
        <div><button type='button' onClick={onBackToOrganizationDetails} className='btn btn-sm btn-secondary'>{`back to Organization`}</button></div>
        } */}
      </div>
      <hr className='m-0'></hr>
      <div className="row my-3 mx-3">
        <div className="d-flex justify-content-between">
          <div className='col-sm-4 form-group'>
            <label>{t("Name")} :<span className='text-danger mx-1'>*</span></label>
            <div className=''>
              <Field name="orgName"
                className='form-control'
                value={values.orgName}
                onChange={(e: any) => {
                  if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
                    setFieldValue("orgName", e.target.value);
                    //  setDisableBtn(false);
                  }
                  // setFieldTouched('orgName', true)
                  // setFieldValue('orgName', e.target.value.replace(/\s\s+/g, ' '))
                  props.enableSubmit(false)
                }}
              />
              <span className='text-danger'><ErrorMessage name='orgName' /></span>
            </div>
          </div>
          <div className='col-sm-4 px-3 form-group'>
            <label>{t("Address Line 1")}:<span className='text-danger mx-1'>*</span></label>
            <div className=''>
              <Field
                name="addressLine1"
                aria-label="addressLine1"
                className='form-control '
                value={values.addressLine1}
                onChange={(e: any) => {
                  if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
                    setFieldValue("addressLine1", e.target.value);
                    //  setDisableBtn(false);
                  }
                  // setFieldTouched("addressLine1", true)
                  props.enableSubmit(false)
                }}
              />
              <span className='text-danger'><ErrorMessage name='addressLine1' /></span>
            </div>
          </div>
          <div className='col-sm-4 form-group'>
            <label>{t("Address Line 2")} :</label>
            <div className=''>
              <Field
                name="addressLine2"
                aria-label="addressLine2"
                className='form-control '
                value={values.addressLine2}
                onChange={(e: any) => {
                  if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
                    setFieldValue("addressLine2", e.target.value);
                    //  setDisableBtn(false);
                  }
                  // setFieldTouched("addressLine2", true)
                  props.enableSubmit(false)
                }}
              />
              <span className='text-danger'><ErrorMessage name='addressLine2' /></span>
            </div>
          </div>
        </div>
        <div className="d-flex justify-content-between">
          <div className='col-sm-4 form-group my-3'>
            <label>{t("Country")} :<span className='text-danger mx-1'>*</span></label>
            <div className=''>
              <Field
                as="select"
                className='form-select form-control-lg'
                name="country.name"
                placeholder={t("Select Your Country")}
                value={values.country.name}
                onChange={(e: any) => {
                  onCountryChange(e);
                }}
              >
                <option value="">{t("Select Your Country")}</option>
                {
                  allCountriesData && allCountriesData.map((item: any, index: any) => {
                    return (
                      <option key={index} value={item.name}>{item.name}</option>
                    )
                  })
                }
              </Field>
              {/* <span className='text-danger'><ErrorMessage name='country.name' /></span> */}
              {(errors.country && touched.country && !values.country.name) ? (<div className='text-danger'>{errors.country.name as string}</div>) : null}
            </div>
          </div>
          <div className='col-sm-4 px-3 form-group  my-3'>
            <label>{t("State")} :<span className='text-danger mx-1'>*</span></label>
            <div className=''>
              <Field
                name="state.name"
                placeholder={t("Select Your State")}
                className='form-select form-control-lg'
                disabled={!values.country.name}
                value={values.country.name ? values.state.name : ''}
                as="select"
                onChange={(e: any) => {
                  onStateChange(e)
                  props.enableSubmit(false)
                }}
              >
                <option value="">{t("Select Your State")}</option>
                {
                  stateByCountry && stateByCountry.map((item: any, index: any) => {
                    return (
                      <option key={index} value={item.name}>{item.name}</option>
                    )
                  })
                }
              </Field>
              {/* <span className='text-danger'><ErrorMessage name='state.name' /></span> */}
              {errors.state && touched.state /* && values.country.name */ ? (<div className='text-danger'>{errors.state.name as string}</div>) : null}
            </div>
          </div>
          <div className='col-sm-4 form-group my-3'>
            <label>{t("City")}:<span className='text-danger mx-1'>*</span></label>
            <div className=''>
              <Field
                as="select"
                name="city.name"
                className='form-select form-control-lg'
                value={values.city.name}
                disabled={!values.country.name || !values.state.name}
                onChange={(e: any) => {
                  onCityChange(e)
                  // setFieldTouched('city.name', true)
                  setFieldValue('city.name', e.target.value)
                  props.enableSubmit(false)
                }}
              >
                <option value="">{t("Select Your City")}</option>
                {/* {
                  cityByStates && cityByStates.map((item: any, index: any) => {
                    return (
                      <option key={index} value={item.name}>{item.name}</option>
                    )
                  })
                } */}
                {cities.length > 0 ? cityByStates && cityByStates.map((item: any, index: any) => {
                  return (
                    <option key={index} value={item.name}>{item.name}</option>
                  )
                }) : cities && cities.map((itm: any, index: any) => {
                  return (
                    <option key={index} value={itm.name}>{itm.name}</option>
                  )
                })}
              </Field>
              {/* {!values.state.name && <span className='text-danger'><ErrorMessage name='city.name' /></span>} */}
              {errors.city && touched.city /* && values.state.name*/ ? (<div className='text-danger'>{errors.city.name as string}</div>) : null} 
            </div>
          </div>
        </div>
        <div className="d-flex justify-content-between">
          <div className='col-sm-4 form-group'>
            <label>{t("Mobile No")}:<span className='text-danger mx-1'>*</span></label>
            <div className='d-flex'>
              <input className='col-2 phone-code'
                value={values.country.phoneCode}
                type='text'
                // onChange={(e) => onFilterChange(e)}
                disabled={true}
              />
              <Field
                name="phone"
                type="number"
                aria-label="Mobile"
                className='form-control ms-2'
                value={values.phone}
                onChange={(e: any) => {
                  setMessage('')
                  setFieldTouched('phone', true)
                  setFieldValue('phone', e.target.value)
                  props.enableSubmit(false)
                }}
              />
            </div>
            <span className='text-danger'><ErrorMessage name={`phone`} /></span>
            {/* <span className='text-danger'><ErrorMessage name='phone' /></span> */}
          </div>
          <div className='col-sm-4 px-3 form-group'>
            <label>{t("Telephone no")}:<span className='text-danger mx-1'>*</span></label>

            <div className=''>
              <Field name="telephone"
                type='number'
                aria-label="telephone"
                className='form-control'
                value={values.telephone}
                validate={(e: any) => validateTelephoneNumber(e, values)}  // charan
                onChange={(e: any) => {
                  setMessage('')
                  setFieldTouched(`telephone`, true);
                  setFieldValue("telephone", e.target.value)
                  props.enableSubmit(false)
                }}
              />
              <span className='text-danger'><ErrorMessage name={`telephone`} /></span>
            </div>
          </div>
          <div className='col-sm-4 form-group'>
            <label>{t("Zip")}:<span className='text-danger mx-1'>*</span></label>
            <div className=''>
              <Field name="postalZipCode"
                type='number'
                aria-label="postalZipCode"
                className='form-control '
                value={values.postalZipCode}
                onChange={(e: any) => {
                  setFieldTouched('postalZipCode', true)
                  setFieldValue("postalZipCode", e.target.value)
                  props.enableSubmit(false)
                }}
              />
              <span className='text-danger'><ErrorMessage name={`postalZipCode`} /></span>
            </div>
          </div>
        </div>
        <div className="d-flex justify-content-between">
          <div className='col-sm-4 form-group mt-3'>
            <label>{t("Company Website")}:<span className='text-danger mx-1'>*</span></label>
            <div className=''>
              <Field name="companyUrl"
                aria-label="companyUrl"
                className='form-control'
                value={values.companyUrl}
                onChange={(e: any) => {
                  if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
                    setFieldValue("companyUrl", e.target.value);
                    //  setDisableBtn(false);
                  }
                  // setFieldTouched('companyUrl', true)
                  props.enableSubmit(false)
                }}
              />
              <span className='text-danger'><ErrorMessage name='companyUrl' /></span>
            </div>
          </div>


          <div className='col-sm-4 form-group mt-3 px-3'>
            <label>{t("Organization Type")} : <span className='text-danger mx-1'>*</span></label>
            <div>
              <Field
                as="select"
                className='form-select form-control-lg'
                name='orgType.name'
                value={values?.orgType?.id}
                onChange={(e: any) => {
                  const _orgType = { ...{}, ...createOrganization.orgType }
                  //Fixed redmine issue 4414 -Akshay 
                  const _findOrgType = orgTypes && orgTypes.find((ele: any) => ele.id === parseInt(e.target.value))
                  setFieldValue('orgType', _findOrgType ? _findOrgType : _orgType)
                  // setFieldTouched('orgType.name', true)
                  props.enableSubmit(false)
                }}
              >
                <option value="">{t("Select Organization Type")}</option>
                {
                  orgTypes && orgTypes.map((item: any, index: any) => {
                    return (
                      <option key={index} value={item.id}>{item.name}</option>
                    )
                  })
                }
              </Field>
              <span className='text-danger'><ErrorMessage name='orgType.name' /></span>
            </div>
          </div>
          <div className='col-sm-4 form-group mt-3'>
            <label>{t("Organization Short Name")}:<span className='text-danger mx-1'>*</span></label>
            <div className=''>
              <Field name="orgShortname"
                aria-label="orgShortName"
                className='form-control '
                value={values.orgShortname}
                // onBlur={(e: any) => {
                //   // setFieldTouched('orgShortname', true)
                //   if (e.target.value) {
                //     organizationShortName()
                //   }
                // }}
                onChange={(e: any) => {
                  if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
                    setFieldValue("orgShortname", e.target.value);
                    //  setDisableBtn(false);
                  }
                  // setFieldTouched('orgShortname', true)
                  props.enableSubmit(false)
                }}
              />
              <span className='text-danger'><ErrorMessage name='orgShortname' /></span>
            </div>
          </div>
        </div>
      </div>
    </React.Fragment >
  )
}
export default OrganizationDetails;