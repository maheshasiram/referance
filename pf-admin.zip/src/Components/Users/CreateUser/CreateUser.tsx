import React, { useRef } from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import _ from 'lodash';
import { useDispatch, useSelector } from 'react-redux';
import './Style/styles.scss'
import { SaveUserDetails, fetchAllPrivilegedRoles, findUserDetailsFromLdap, getDocumentTypes, UpdateUser, finAllUsersByStatus, uploadDocument } from '../Actions/Action'
import Validateschema from './Validate';
import { findAllCountries } from '../../Organization/actions/actions'
import { Confirm, toastAlert } from '../../../actions/actions';
import DeleteIcon from '@mui/icons-material/Delete';
import { Types } from '../Reducer/Types';
import CustomizedTooltip from '../../../Common/CustomizedTooltip/CustomizedTooltip';
import { messages } from '../../../configs/messages';
import CloseIcon from '@mui/icons-material/Close';
import { useTranslation } from 'react-i18next';
import { toastMsg } from '../../../Common/Messages';
import { CreateUser as userInitialPayload } from '../constants/models';
import RemoveRedEyeIcon from '@mui/icons-material/RemoveRedEye';
import ZoomInIcon from '@mui/icons-material/ZoomIn';
import ViewAssignedRoles from './ViewAssignedRoles';

function CreateUser(props: any) {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const inputRef = useRef(null)
  const { actionType, onCloseHandler, setSearchValue } = props
  const { userInitialDetails, privilegedRoles, timeZone, userStatus, allUsers, deletedUserDocument, userParams } = useSelector((state: any) => state.users);
  const { allCountriesData } = useSelector((state: any) => state.organization);
  const [userName, setUserName] = React.useState('');
  const [userError, setUserError] = React.useState('');
  const [message, setMessage] = React.useState("");
  const [validateUser, setValidateUser] = React.useState(false)
  const [viewRoles, setViewRoles] = React.useState(false)
  const { user } = useSelector((state: any) => state.app)
  const loaded = React.useRef(false);
  let allRoles: any = []
  const roles = (rolesList: any) => {
    const options: any = [];
    rolesList?.map((item: any) => {
      const option = {
        // id: item?.roleId?.id,
        label: item?.roleId?.name,
        value: item?.roleId?.id
      }
      return options.push(option)
    })
    return options
  }

  // console.log('privilegedRoles........', privilegedRoles);

  React.useEffect(() => {
    if (!loaded.current) {
      dispatch(getDocumentTypes());
      dispatch(fetchAllPrivilegedRoles());
      dispatch(findAllCountries());
      setRolesInOrder()
      loaded.current = true
    }
    // eslint-disable-next-line 
  }, [dispatch]);

  const setRolesInOrder = () => {
    let unSelectedRole: any = []
    let selectedRole: any = []
    privilegedRoles.map((item: any) => {
      if (userInitialDetails.roleId.find((i: any) => (i.value === item.roleId.id)) === undefined) {
        return unSelectedRole.push(item.roleId)
      } else {
        return selectedRole.push(item.roleId)
      }
    })
    allRoles = selectedRole.concat(unSelectedRole);
    return allRoles;
  }

  const onUserSearchHandler = (values: any) => {
    values.phone = '';
    values.fileUpload = "";
    values.timeZone = '';
    values.country.countryCode = '';
    values.role = [];
    let _document = document.getElementById('filename') as HTMLInputElement
    _document.value = ''
    // let _document = document.getElementById('filename') as HTMLInputElement
    // _document.value = ''
    // console.log('_document........', _document)
    // if (values.file) {
    //   // delete values.file
    //   // inputRef.current = null
    // }
    const user = allUsers.find((user: any) => (user.userName && user.userName.toLowerCase() === userName.toLowerCase()));
    setUserError('');
    setValidateUser(true)
    if (!user) {
      dispatch(findUserDetailsFromLdap(userName, (data: any) => {
        if (!data.userName && !data.email) {
          setUserError("This user doesn't  exits in our LDAP directory. Please try with valid user!");
        }
      }));
    } else {
      setUserError('User Already Exist');
    }
  }

  const onDeleteDocument = (documentId: any, values: any) => {
    (dispatch as any)(Confirm({
      status: 0,
      message: messages.users.userDocument,
      onOk: () => {
        setTimeout(() => {
          dispatch(toastAlert({
            status: 1,
            message: toastMsg(messages.users.DocDeleted, ''),
            open: true,
          }))
          const _userDocument = _.cloneDeep(values)
          _userDocument.userDocuments = [];
          dispatch({ type: Types.ALL_USER_INITIAL_VALUES, payload: _userDocument });
          let _deletedUserDocument = deletedUserDocument
          _deletedUserDocument = documentId
          dispatch({ type: Types.DELETED_USER_DOCUMENT, payload: _deletedUserDocument });
        }, 100);
      }
    }));
  }

  const onSaveUserDetails = (values: any) => {
    values.roleId = userInitialDetails.roleId
    if (privilegedRoles.length > 0) {
      if (actionType === 'add' && values.file) {
        validateUser === false && setUserError("Please search user from LDAP");

        if (validateUser) {
          // privilegedRoles
          // const allPrivileges = privilegedRoles?.map((item: any) => item.roleId)
          const roleId = values.roleId.map((item: any) => item.value);
          // eslint-disable-next-line array-callback-return
          // const result = allPrivileges.find((obj: any) => {

          //   console.log('122',roleId);
          //   if (obj.id === roleId) {
          //     return obj.id
          //   }
          // })
          const _values = { ...values, isActive: true, userId: 0, createdBy: user.userId, roleId: roleId };
          // let _values = { ...values, isActive: true, userId: user.userId, createdBy: user.userId };
          // delete _values.documentTypeId
          delete _values.file
          dispatch(SaveUserDetails(_values, (response: any) => {
            if (response.errorCode) {
              setMessage(response.errorMessage)
            } else {
              const formData = new FormData();
              formData.append("userDocuments", values.file);
              const payload = _.cloneDeep(values)
              payload.userId = response.userId
              dispatch(uploadDocument(payload, formData, () => {
                onCloseHandler();
                dispatch(toastAlert({
                  status: 1,
                  message: toastMsg(messages.users.createUser, values.userName),
                  open: true
                }));
                const _payload = { ...userParams, status: true, offset: 0, userName: "", email: "", phone: "", }
                dispatch({ type: Types.USERS_PARAMS, payload: _payload })
                dispatch(finAllUsersByStatus(_payload))
              }));
            }
          }
          ));
        }
      } else {
        const _values = _.cloneDeep(values);
        if (_values.userDocuments.length > 0 || values.file) {

          const roleId = values.roleId.map((item: any) => item.value);
          const _values = { ...values, roleId: roleId };
          delete _values.filename
          dispatch(UpdateUser(_values, deletedUserDocument, (response: any) => {
            if (response.status === 500) {
              dispatch(toastAlert({
                status: 1,
                message: response.error,
                open: true
              }));
            } else if (response.errorCode) {
              dispatch(toastAlert({
                status: 2,
                message: response.errorMessage,
                open: true
              }));
            } else {
              if (values.file) {
                const formData = new FormData();
                formData.append("userDocuments", values.file);
                const payload = _.cloneDeep(values)
                // delete payload.documentTypeId
                dispatch(uploadDocument(payload, formData, () => {
                  onCloseHandler();
                  setSearchValue('')
                  dispatch(toastAlert({
                    status: 1,
                    message: toastMsg(messages.users.editUser, values.userName),
                    open: true
                  }));
                  const payload = { ...userParams, status: userStatus, offset: 0, userName: "", email: "", phone: "", }
                  dispatch({ type: Types.USERS_PARAMS, payload: payload })
                  dispatch(finAllUsersByStatus(payload))
                }));
              } else {
                onCloseHandler();
                dispatch(toastAlert({
                  status: 1,
                  message: toastMsg(messages.users.editUser, values.userName),
                  open: true
                }));
                setSearchValue('')
                const payload = { ...userParams, status: userStatus, offset: 0, userName: "", email: "", phone: "", }
                dispatch({ type: Types.USERS_PARAMS, payload: payload })
                setSearchValue('')
                dispatch(finAllUsersByStatus(payload))
              }
            }
          }));
        }
      }
    }
  }


  const handleViewSelectedRoles = () => {
    setViewRoles(true)
  }
  const handleRoleChange = (e: any, setFieldValue: any, values: any) => {
    // let _payload = _.cloneDeep(values);
    // let _payload = { ...{}, ...values };
    const selectedRole = privilegedRoles && privilegedRoles.find((item: any) => item?.roleId?.id === parseInt(e.target.value))
    console.log('selectedRole......', selectedRole, userInitialPayload.role)
    setFieldValue('role', e.target.value !== '' ? selectedRole?.roleId : userInitialPayload.role)
    props.enableSubmit(false);
    values.roleId = userInitialDetails.roleId


    // dispatch({ type: Types.ALL_USER_INITIAL_VALUES, payload: _payload });

    // _payload.roleId?.length > 0 ? _payload.roleId.push({
    //   label: values.role.name,
    //   value: values.role.id
    // }) : _payload.roleId = [{
    //   label: values.role.name,
    //   value: values.role.id
    // }];
    // dispatch({ type: Types.ALL_USER_INITIAL_VALUES, payload: _payload })s
    // console.log('224...', userInitialDetails)
  }
  console.log('userInitialDetails...', userInitialDetails, userInitialPayload)
  return (
    <div className="row" >
      <Formik
        enableReinitialize={true}
        initialValues={userInitialDetails}
        validationSchema={Validateschema()}
        onSubmit={(values) => {
          onSaveUserDetails(values);
        }}
      >
        {({ errors, touched, values, setFieldValue, setFieldTouched, resetForm }) => (
          <Form id="createUser">
            {message && (
              <p className="error  text-center">
                <i className='pi pi-exclamation-triangle  text-danger' ></i>
                <span className="" style={{ color: 'red', marginLeft: 10 }}>{message}</span>
              </p>
            )}
            <div className={actionType === "edit" ? 'd-none' : 'row user-auto-complete'} id='username'>
              <div className='text-danger'>{userError}</div>
              <div>
                <div>User Name :</div>
                <div className='d-inline-flex search-container-common'>
                  <Field
                    name="userName"
                    id='userName'
                    value={values.userName}
                    type="text"
                    placeholder={t("User Name")}
                    onChange={(e: any) => {
                      setUserName(e.target.value);
                      setValidateUser(false);
                      //username Field shouldn't accept spaces and shouldn't allow number--Bindhu
                      // if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
                      //   const regex = /^[A-Za-z]+$/;
                      //   if (!e.target.value || regex.test(e.target.value.toString())) {
                      //     setFieldValue("userName", e.target.value);
                      //   }
                      // }
                      setUserError('');
                      setFieldValue('firstName', '')
                      setFieldValue('lastName', '')
                      setFieldValue('email', '')
                      // setFieldTouched(`userName`, true)
                      setFieldValue(`userName`, e.target.value.replace(/\s\s+/g, ' '))
                      props.enableSubmit(false);
                    }}
                  />
                  {userName &&
                    <span className="del-icon">
                      <CloseIcon className="disableClose"
                        onClick={() => {
                          setUserName('')
                          setUserError('')
                          resetForm()
                          let _document = document.getElementById('filename') as HTMLInputElement
                          _document.value = ''
                          // console.log('_document........', _document)
                          dispatch({ type: Types.ALL_USER_INITIAL_VALUES, payload: userInitialPayload });
                        }} />
                    </span>}
                  <span className="search px-1">
                    <ZoomInIcon className="disabled" onClick={() => userName ? onUserSearchHandler(values) : null} />
                  </span>
                </div>
              </div>
              {/* {!userName ? <span className='text-danger'><ErrorMessage name={`userName`} /></span> : ''} */}
              <span className='text-danger'><ErrorMessage name={`userName`} /></span>
              {/* {errors.userName && touched.userName ?
                <div className='text-danger'>{errors.userName as any}</div>
                : null
              } */}
            </div>
            <div className='details'>
              <h6>{t("User Details")}</h6>
              {/* <hr /> */}
              <div className='row mt-3'>
                <div className='col-4'>
                  <div className='form-group '>
                    <label id='label'> {t("First Name")} :<span className='text-danger mx-1'>*</span></label>
                    <Field
                      className="form-control"
                      name="firstName"
                      disabled={true}
                      value={values.firstName}
                      id='txt-firstName'
                      placeholder={t("First Name")}
                      onChange={(e: any) => {
                        setFieldTouched('firstName', true)
                        setFieldValue('firstName', e.target.value)
                        props.enableSubmit(false)
                      }}
                    />
                    {errors.firstName && touched.firstName && values.userName ?
                      <div className='text-danger'>{errors.firstName as any}</div>
                      : null}
                  </div>
                </div>
                <div className='col-4'>
                  <div className='form-group  '>
                    <label id='label' > {t("Last Name")} :<span className='text-danger mx-1'>*</span> </label>
                    <Field
                      className="form-control "
                      name="lastName"
                      disabled={true}
                      value={values.lastName}
                      id='txt-lastName'
                      placeholder={t("Last Name")}
                    />
                    {errors.lastName && touched.lastName && values.userName ?
                      <div className='text-danger'>{errors.lastName as any}</div>
                      : null}
                  </div>
                </div>
                <div className='col-4'>
                  <div className='form-group'>
                    <label id='label'>{t("Email")} :<span className='text-danger mx-1'>*</span> </label>
                    <Field
                      className="form-control "
                      name="email"
                      disabled={true}
                      value={values.email}
                      id='txt-email'
                      placeholder={t("Email")}
                    />
                    {errors.email && touched.email && values.userName ?
                      <div className='text-danger'>{errors.email as any}</div>
                      : null}
                  </div>
                </div>
              </div>
              <div className='row mt-2'>
                <div className='col-4'>
                  <div className='form-group'>
                    <label id='label'> {t("Phone No")} :<span className='text-danger mx-1'>*</span> </label>
                    <Field
                      className="form-control"
                      name="phone"
                      type="number"
                      id='txt-phone'
                      min={"0"}
                      placeholder={t("Phone Number")}
                      onChange={(e: any) => {
                        setMessage('')
                        setFieldTouched('phone', true)
                        setFieldValue('phone', e.target.value)
                        props.enableSubmit(false)
                      }}
                      onKeyPress={(e: any) => {
                        if (e.key === "-" || e.key === "+" || e.key === "e" || e.key === ".") {
                          e.preventDefault();
                        }
                      }}
                    />
                    <div className="text-danger">
                      <ErrorMessage name={`phone`} />
                    </div>
                  </div>
                </div>
                <div className='col-4'>
                  <div className='form-group'>
                    <label id='label'>{t("Country")} :<span className='text-danger mx-1'>*</span> </label>
                    <Field
                      as="select"
                      className="form-select"
                      name="country.countryCode"
                      id='countryCode'
                      placeholder={t("Country Code")}
                      onChange={(e: any) => {
                        const country = allCountriesData.find((item: any) => item.countryCode === e.target.value);
                        const _country = {
                          countryCode: "",
                          id: "",
                          name: "",
                          phoneCode: ""
                        }
                        setFieldValue('country', country ? country : _country);
                        props.enableSubmit(false)

                      }}
                    >
                      <option value="">{t("Select Country")}</option>
                      {allCountriesData &&
                        allCountriesData.map(
                          (item: any, index: any) => (
                            <option key={index} value={item.countryCode} id="sel-groupname">
                              {item.name}
                            </option>
                          )
                        )}
                    </Field >
                    <div className="text-danger">
                      <ErrorMessage name={`country.countryCode`} />
                    </div>
                  </div>
                </div>
                <div className='col-4'>
                  <div className='form-group'>
                    <label id='label'>{t("TimeZone")} :<span className='text-danger mx-1'>*</span> </label>
                    <Field
                      as="select"
                      className="form-select"
                      name="timeZone"
                      // value={values.timeZone ? values.timeZone : ''}
                      id='timeZone'
                      onChange={(e: any) => {
                        setFieldTouched('timeZone', true)
                        setFieldValue('timeZone', e.target.value)
                        props.enableSubmit(false)
                      }}
                    >
                      <option value=''>{t("Select TimeZone")}</option>
                      {timeZone &&
                        timeZone.data.map(
                          (item: any, index: any) => {
                            return (
                              <option key={index} value={item} id="sel-groupname">
                                {item}
                              </option>
                            )
                          }
                        )}
                    </Field>
                    <div className="text-danger">
                      <ErrorMessage name={`timeZone`} />
                    </div>
                  </div>
                </div>
              </div>
              <div className='row mt-2'>
                <div className='col-4'>
                  <div className='form-group'>
                    <div className='d-flex'>
                      <label htmlFor='role' id='label'> {t("Role")} :<span className='text-danger mx-1'>*</span> </label>
                      <CustomizedTooltip title="View all roles">
                        <RemoveRedEyeIcon
                          sx={{ fontSize: 13, opacity: .8, cursor: 'pointer' }}
                          onClick={handleViewSelectedRoles}
                        />
                      </CustomizedTooltip>
                      <ViewAssignedRoles
                        actionType={actionType}
                        viewRoles={viewRoles}
                        setViewRoles={setViewRoles}
                        roles={roles(privilegedRoles)}
                        value={values?.roleId}
                        values={values}
                        setFieldValue={setFieldValue}
                        form={"ViewAssignedRoles"}
                        // btn={"Submit"}
                        enableSubmit={props.enableSubmit}
                        setOpenCreateUser={props.setOpenCreateUser}
                        openCreateUser={props.openCreateUser}
                      />
                    </div>
                    <Field
                      as="select"
                      className="form-select"
                      name="role.id"
                      value={values?.role?.id ? values?.role?.id : ''}
                      disabled={user.userId === values.userId}
                      id='roleId'
                      onChange={(e: any) => handleRoleChange(e, setFieldValue, values)}
                    >
                      <option value=''>{"Select Role"}</option>
                      {setRolesInOrder() && allRoles.map(
                        (item: any, index: any) => {
                          // const allValues = []
                          // // const allRoles = userInitialDetails?.roleId.find((i: any) => i.value === item.roleId.id) !== undefined ? false : true
                          // const allRoles = userInitialDetails?.roleId.find((i: any) =>
                          // console.log("...503",i)
                          //   i.value === item.roleId.id)
                          // allValues.push(allRoles)
                          // allValues.sort(function (x: any, y: any) {
                          //   return (x === y) ? 0 : x ? 1 : -1
                          // })
                          return <option
                            key={index}
                            value={item?.id}
                            id="sel-groupname"
                            disabled={(userInitialDetails.roleId.find((i: any) => i.value === item.id) !== undefined ? false : true)}
                          >
                            {item?.name}
                          </option>
                        }
                      )}
                    </Field >
                    <div className="text-danger">
                      <ErrorMessage name={`role.id`} />
                    </div>
                    <>
                      {
                        console.log('errors........', errors, touched, values)
                      }
                    </>
                    {/* changing role field from single select to multiselect */}
                    {/* <Field
                      component={SelectField}
                      name="roleId"
                      id='roleId'
                      options={roles(privilegedRoles)}
                      className="form-select"
                      isMulti
                      // multiple
                      value={values?.roleId}
                      onChange={(e: any) => {
                        props.enableSubmit(false)
                        setFieldValue('roleId', e.target.value)
                        setFieldTouched('roleId', true)
                        // setFieldValue('roleId', e.target.value)
                      }}
                    >
                    </Field> */}
                    {/* <div className="text-danger">
                      <ErrorMessage name={`roleId`} />
                    </div> */}
                    {/* {errors.roleId && touched.roleId &&
                      <div className='text-danger'>{errors.roleId as any}</div>} */}
                    {/* {(!values.role && touched.role) && <div className='text-danger'>{t("Please Select Role")}</div>} */}
                    {/* {(!values.role && touched.role) && <div className='text-danger'>{values.errors.roleId}</div>} */}
                    {/* {values.roleId.length === 0 && <div className='text-danger'>{t("Please Select Role")}</div>} */}
                    {/* code commented on 23Aug for removing validation for roleId after selection also -- Naveen */}
                    {/* {errors.roleId && touched.roleId && touched.role ?
                      <div className='text-danger'>{errors.roleId as any}</div>
                      : (((values.role === null || (!values?.roleId) || values.role === "") && touched.role)) ?
                        <div className='text-danger'>Please select at least one role</div>
                        : null
                    } */}
                    {

                    }
                  </div>
                </div>
                <div className='col-4'>
                  <div className='form-group'>
                    <label id='label' className='emailDoc'>{t("E-mail Document")} :<span className='text-danger mx-1'>*</span> <b>{values.userDocuments && values.userDocuments[0]?.fileName}</b>
                      {values.userDocuments && values.userDocuments[0]?.id && <span className='btn-rounded'><CustomizedTooltip title="Delete Document"><DeleteIcon onClick={() => onDeleteDocument(values.userDocuments[0].id, values)} sx={{ fontSize: 13, opacity: .8, cursor: 'pointer' }} /></CustomizedTooltip></span>} </label>
                    <input
                      className="form-control p-2 "
                      type='file'
                      // name="fileUpload"
                      // id='filename'
                      id='filename'
                      // placeholder={t("Approval Document")}
                      // ref={inputRef.current}
                      // key={filevalue}
                      // innerRef={fileref}
                      // disabled={values.userDocuments && values.userDocuments[0]?.documentType ? true : false}
                      disabled={values.userId > 0 && (values.userDocuments?.length > 0) ? true : false}
                      onChange={(event: any) => {
                        setFieldValue("file", event?.currentTarget?.files[0]);
                        setFieldTouched('filename', true)
                        props.enableSubmit(false)
                      }}
                    />
                    {(values.userId === 0 ||
                      (values.userId !== 0 && !values.userDocuments[0]?.documentType && values.userDocuments?.length === 0))
                      && (touched.filename && !values.file) && <div className='text-danger'>{t("Please Upload Document")}</div>}
                  </div>
                </div>
                {/* <div className='col-4'>
                  <label id='label'>{t("Document Type")} :<span className='text-danger mx-1'>*</span> </label>
                  <Field
                    as="select"
                    className="form-select"
                    name="documentTypeId"
                    value={values.documentTypeId ? values.documentTypeId : ''}
                    id='documentTypeId'
                    placeholder={t("Select Document Type")}
                    disabled={values.userDocuments && values.userDocuments[0]?.documentType ? true : false}
                    onChange={(event: any) => {
                      setFieldValue('documentTypeId', event.target.value);
                      props.enableSubmit(false)
                    }}
                  >
                    <option value="">{t("Select Document Type")}</option>
                    {documentTypes && documentTypes.map(
                      (item: any, index: any) => (
                        <option key={index} value={item.id} id="sel-groupname">
                          {item.name}
                        </option>
                      )
                    )}
                  </Field>
                  {(values.userId == 0 || (values.userId !== 0 && !values.userDocuments[0]?.documentType)) && touched.documentTypeId && !values.documentTypeId && <div className='text-danger'>{t("Please Select Your Document Type")}</div>}

                </div> */}
              </div>
              <div>
              </div>
            </div>
          </Form>
        )}
      </Formik>
    </div >
  );
}

export default CreateUser;
