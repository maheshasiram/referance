import React, { useEffect } from 'react'
import CustomDialog from '../../../Common/modals/CustomDialog'
import { useTranslation } from 'react-i18next';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import Checkbox from '@mui/material/Checkbox';
import { useSelector, useDispatch } from 'react-redux';
import { Types } from '../Reducer/Types';
function ViewAssignedRoles(props: any) {
    const { t } = useTranslation();
    // const [btnState, setBtnState] = React.useState(true);
    const { roles, values, openCreateUser } = props
    const [checked, setChecked] = React.useState([0]);
    const { userInitialDetails, privilegedRoles } = useSelector((state: any) => state.users)
    const dispatch = useDispatch();
    const onCloseHandler = () => {
        props.setViewRoles(false)
    }
    // console.log('checked...', checked, props.values, openCreateUser,props.value );

    useEffect(() => {
        if (!openCreateUser) {
            // alert('test')
            props.setFieldValue('roleId', [])
        }
    }, [openCreateUser])
    React.useEffect(() => {
        const _value = props.value?.map((val: any) => {
            return val.value
        })
        setChecked(_value)
    }, [props.value, userInitialDetails.role])

    const handleToggle = (item: number) => () => {
        const currentIndex = checked.indexOf(item);
        const newChecked = [...checked];
        const options: any = []
        if (currentIndex === -1) {
            newChecked.push(item);
            privilegedRoles.filter((i: any) => {
                newChecked.map((j: any) => {
                    if (i.roleId.id === j) {
                        const option = {
                            label: i.roleId.name,
                            value: i.roleId.id
                        }
                        options.push(option)
                    }
                    return null
                })
                return null
            })
            userInitialDetails.roleId = options
        } else {

            newChecked.splice(currentIndex, 1);
            privilegedRoles.filter((i: any) => {
                newChecked.map((j: any) => {
                    if (i.roleId.id === j) {
                        const option = {
                            label: i.roleId.name,
                            value: i.roleId.id
                        }
                        options.push(option)
                    }
                    return null
                })
                return null
            })
            userInitialDetails.roleId = options
            // console.log('...49', userInitialDetails.roleId);
            if (userInitialDetails.roleId.length === 0) {
                // console.log("...userInitialDetails", values, userInitialDetails.roleId.length);
                props.setFieldValue('role', '')
            }
            dispatch({ type: Types.ALL_USER_INITIAL_VALUES, payload: userInitialDetails });

        }
        setChecked(newChecked);
        props.enableSubmit(false)
    };

    return (
        <div>
            <CustomDialog
                title={props.actionType === 'add' ? t("Assign Role") : t('Edit Assigned Role')}
                onClose={onCloseHandler}
                open={props.viewRoles}
                maxWidth="xs"
                className="create-dy-field"
                // onSubmitHandler={onSubmitHandler}
                actionType={'Close'}
            // disabled={btnState}
            >
                <List dense sx={{ width: '100%', maxWidth: 360, bgcolor: 'background.paper' }}>
                    {roles.map((value: any) => {
                        const labelId = `checkbox-list-secondary-label-${value.value}`;
                        return (
                            <ListItem
                                key={value.value}
                                secondaryAction={
                                    <Checkbox
                                        // edge="end"
                                        onChange={handleToggle(value.value)}
                                        checked={checked.indexOf(value.value) !== -1}
                                        inputProps={{ 'aria-labelledby': labelId }}

                                    />
                                }
                                disablePadding
                            >
                                <ListItemButton>
                                    <ListItemText id={labelId} primary={value.label} />
                                </ListItemButton>
                            </ListItem>
                        );
                    })}
                </List>
            </CustomDialog>
        </div >
    )
}

export default ViewAssignedRoles