
import * as Yup from 'yup';
import { useTranslation } from 'react-i18next';

function Validateschema() {
    const { t } = useTranslation();
    const phoneRegExp = /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/
    // phoneNumber: Yup.string().matches(phoneRegExp, 'Phone number is not valid')

    return Yup.object().shape({
        userName: Yup.string().required(t('Please enter User Name')).nullable()
            .matches(/^[^\s]/, t("user name should not start with space")).nullable(),
        // userName: userName ? Yup.string().matches(/^[^\s]/, t("user name should n   ot start with space")).nullable() : Yup.string().required(t('Please Enter User Name')).nullable(),
        firstName: Yup.string().nullable()
            .required(t('Please Enter First Name')),
        lastName: Yup.string().nullable()
            .required(t('Please Enter Last Name')),
        email: Yup.string().nullable()
            .required(t('Please Enter Email'))
            .min(2, t("Too Short!"))
            .email(t('Please Enter Valid Email Address'))
            .max(50, t("Too Long!")),
        phone: Yup.string().matches(phoneRegExp, "Phone Number is Not valid").nullable()
            .min(10, t("Too Short !"))
            .max(10, t("Too Long !"))
            .required(t('Please Enter Phone Number')),
        // .matches(/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/, t('Please Enter Valid Phone Number'))
        timeZone: Yup.string()
            .required(t('Please Select Time Zone')).nullable(),
        // roleId: Yup.array().of(Yup.object().shape({
        //     id: Yup.string().required("Please select role")
        // })),
        // roleId: Yup.array().required("Please select role"),
        // roleId: Yup.array().of(Yup.object({
        //     id: Yup.string().required(t('Please select role')).nullable()
        // })),
        role: Yup.object().shape({
            id: Yup.string().required(t('Please select role')),
        }),
        roleId: Yup.array()
        // .min(1, 'Please select atleast one role')
        // .of(
        //     Yup.object().shape({
        //         label: Yup.string().required(),
        //         value: Yup.string().required(),
        //     })
        // )
        ,
        country: Yup.object().shape({
            countryCode: Yup.string()
                .required(t('Please Select Country'))
        })
    })
}

export default Validateschema






