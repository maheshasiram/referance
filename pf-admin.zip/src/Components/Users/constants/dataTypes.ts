
type Country = {
    id?: number,
    name?: string,
    countryCode?: string,
    phoneCode?: number
}
// type roleDetails = {
//     id?: string,
//     name?: string,
//     description?: string,
//     status?: boolean,
//     staticRole?: boolean
// }
// type roleId = [{
//     id?: number,
//     label?: string,
//     value?: number
// }]

export type User = {
    userId?: any,
    userName: string,
    firstName: string,
    lastName: string,
    email: string,
    phone: string,
    timeZone: string,
    lastActiveDate: string,
    isActive?: boolean,
    comments: string,
    createdBy: string,
    createdOn: string,
    updatedBy: string,
    updatedOn: string,
    roleId: any,
    role: any,
    country?: Country,
    approvaldate?: string,
    // documentTypeId?:string,
    filename?: any
}

export type UserDocument = {
    userDocuments?: any,
    documentTypeId?: any
}
