import { User, UserDocument } from "./dataTypes";

export const CreateUser: User = {
  userId: 0,
  userName: "",
  firstName: "",
  lastName: "",
  email: "",
  phone: "",
  timeZone: "",
  lastActiveDate: "",
  isActive: true,
  comments: "",
  createdBy: "",
  createdOn: "",
  updatedBy: "",
  updatedOn: "",
  roleId: [],
  // roleId: [{
  //   id: 0,
  //   label: '',
  //   value: 0
  // }],
  // role: {
  //   id: "",
  //   name: "",
  //   description: "",
  //   status: true,
  //   staticRole: true
  // },
  role: {
    "id": '',
    "name": "",
    "description": "",
    "status": true,
    "staticRole": true
  },
  country: {
    id: 0,
    name: "",
    countryCode: "",
    phoneCode: 0
  },
  approvaldate: "",
  // "documentTypeId": "",
  filename: null
}


export const CreateUserDocument: UserDocument = {
  userDocuments: [""],
  // documentTypeId:null
}
