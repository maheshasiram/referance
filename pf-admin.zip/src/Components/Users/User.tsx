import React, { useEffect, useRef } from 'react'
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import './Styles/style.scss'
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import CustomDialog from '../../Common/modals/CustomDialog';
import CreateUser from './CreateUser/CreateUser';
import { Confirm, Alert, toastAlert } from '../../actions/actions';
import { useDispatch, useSelector } from 'react-redux';
import { finAllUsersByStatus, downloadUserfile, findAllUsers, getUserOnEdit, deleteUser, restoreUser, fetchAllPrivilegedRoles } from '../../Components/Users/Actions/Action';
import { Types } from './Reducer/Types';
import ReplayIcon from '@mui/icons-material/Replay';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import FileDownloadOutlinedIcon from '@mui/icons-material/FileDownloadOutlined';
import CustomizedTooltip from '../../Common/CustomizedTooltip/CustomizedTooltip';
import { messages } from '../../configs/messages';
import { useTranslation } from 'react-i18next';
import ClearSharpIcon from '@mui/icons-material/ClearSharp';
import { confirmMsg, toastMsg } from '../../Common/Messages';
import Loader from '../../Common/Loader'
import { CreateUserDocument } from './constants/models';
import { CreateUser as userInitialPayload } from './constants/models';
import _ from 'lodash';
const AllUser = () => {
  const { t } = useTranslation();
  const [open, setOpen] = React.useState(false);
  const [actionType, setActionType] = React.useState<any | null>('');
  const [searchValue, setSearchValue] = React.useState('');
  const [filter, setFilter] = React.useState('userName');
  const { initialValues, userStatus, userParams, allUserdataByStatus, privilegedRoles } = useSelector((state: any) => state.users);
  const { user } = useSelector((state: any) => state.app);
  const [btnState, setBtnState] = React.useState(true);
  const [pageClick, setpageChange] = React.useState(false);
  const loaded = useRef(false);

  const dispatch = useDispatch()

  useEffect(() => {
    if (!loaded.current) {
      const _payload = { ...userParams, limit: 10, offset: 0, userName: "", email: "", phone: "", roleName: "", status: true }
      dispatch({ type: Types.USERS_PARAMS, payload: _payload })
      dispatch(finAllUsersByStatus(_payload))
      dispatch(fetchAllPrivilegedRoles())
      loaded.current = true
    }
  }, [dispatch, userParams]);

  const onCloseHandler = () => {
    setOpen(false);
    dispatch({type: Types.ALL_USER_INITIAL_VALUES, payload: _.cloneDeep({...userInitialPayload, roleId:[]})})
  }

  const onSubmitUser = () => {
    if (actionType !== 'add') {
      setOpen(false);
    }
  }

  const deleteAndRestoreUser = (rowData: any, statusAction: boolean) => {
    (dispatch as any)(Confirm({
      status: 0,
      message: rowData.isActive ? confirmMsg(messages.commonMessages.delete, rowData.userName) : confirmMsg(messages.commonMessages.restore, rowData.userName),
      onOk: () => {
        dispatch((statusAction ? restoreUser : deleteUser)(rowData.userId, () => {
          const _payload = { ...userParams, status: statusAction === true ? false : true }
          dispatch({ type: Types.USERS_PARAMS, payload: _payload })
          dispatch(finAllUsersByStatus(_payload))
          dispatch(findAllUsers());
          dispatch(toastAlert({
            status: 1,
            message: rowData.isActive ? toastMsg(messages.users.deletedSuccessfully, rowData.userName) : toastMsg(messages.users.restoreSuccessfully, rowData.userName),
            open: true
          }));
        }))
      }
    }));
  }

  const downloadDocument = (rowData: any) => {
    dispatch(getUserOnEdit(rowData.userId, (response: any) => {
      if (response.userDocuments.length > 0) {
        dispatch(downloadUserfile(response))
        dispatch(toastAlert({
          status: 1,
          message: toastMsg(messages.users.DocDownloadSuccess, ''),
          open: true
        }));
      } else {
        dispatch(Alert({
          status: 2,
          message: messages.users.DocDownload,
          onOk: () => {
            dispatch(findAllUsers());
            dispatch(finAllUsersByStatus(userStatus));
          }
        }))
      }
    }));
  }


  const onFindUserDetails = (rowData: any) => {
    dispatch(getUserOnEdit(rowData.userId, (response: any) => {
      const allPrivileges = privilegedRoles?.map((item: any) => item.roleId)
      console.log("allPrivileges..103", allPrivileges)
      const data = response.roleId
      const matchedValues = allPrivileges?.filter(function (item: any) {
        return data.indexOf(item.id) !== -1
      })
      const selectedValues: any = []
      matchedValues.map((i: any) => {
        const option = {
          // id: i?.id,
          label: i.name,
          value: i.id
        }
        return selectedValues.push(option)
      })
      dispatch({ type: Types.ALL_USER_INITIAL_VALUES, payload: { ...response, roleId: selectedValues } });
    }));


    setActionType('edit');
    setOpen(true);
    setBtnState(true);
  }

  const onOpenCreateUserModal = () => {
    dispatch(findAllUsers());
    // dispatch({ type: Types.ALL_USER_INITIAL_VALUES, payload: initialValues })
    setActionType('add');
    setOpen(true);
    setBtnState(true);
  }

  const actionsBodyTemplate = (rowData: any) => {
    return <div className='actions d-flex align-items-center justify-content-center' >
      {rowData.isActive ? <React.Fragment>
        {(user?.userRolePrivileges?.data?.EditUser && user.userId !== rowData.userId) && <CustomizedTooltip title={t("Edit User")}><EditIcon onClick={() => onFindUserDetails(rowData)} sx={{ fontSize: 14, opacity: .8 }} /></CustomizedTooltip>}
        {user?.userRolePrivileges?.data?.EditUser && (user?.userRolePrivileges?.data['DeleteUser/RestoreUser'] && user?.userName !== rowData.userName) && <span>|</span>}
        {(user?.userRolePrivileges?.data?.['DeleteUser/RestoreUser'] && user?.userId !== rowData.userId) && <CustomizedTooltip title={t("Delete User")}><DeleteIcon onClick={() => { deleteAndRestoreUser(rowData, false) }} sx={{ fontSize: 14, opacity: .8 }} /></CustomizedTooltip>}
        {(rowData.recentDocId === 0 || rowData.recentDocId > 0) && <React.Fragment>
          {((user?.userRolePrivileges?.data['DeleteUser/RestoreUser'] || user?.userRolePrivileges?.data?.EditUser) && (user?.userId !== rowData.userId)) && <span>|</span>}
          {<CustomizedTooltip title={t('Download Email')}><FileDownloadOutlinedIcon onClick={() => downloadDocument(rowData)} sx={{ fontSize: 14, opacity: .8 }} /></CustomizedTooltip>}
        </React.Fragment>}
      </React.Fragment> : <CustomizedTooltip title={'Restore User'}><ReplayIcon onClick={() => deleteAndRestoreUser(rowData, true)} sx={{ fontSize: 14, opacity: .8 }} /></CustomizedTooltip>
      }
    </div>
  }

  const onPageClick = (event: any) => {
    if ((event.page > 0 || (pageClick && event.page === 0)) && userParams.offset !== event.first) {
      const _payload = {
        ...userParams, offset: event.first,
        userName: searchValue !== '' && filter === 'userName' ? searchValue : userParams.userName,
        email: searchValue !== '' && filter === 'email' ? searchValue : userParams.email,
        phone: searchValue !== '' && filter === 'phone' ? searchValue : userParams.phone,
        roleName: searchValue !== '' && filter === 'roleName' ? searchValue : userParams.roleName
      }
      dispatch({ type: Types.USERS_PARAMS, payload: _payload });
      dispatch(finAllUsersByStatus(_payload));
      setpageChange(true)
    }
  }
  const onChangeUserStatus = (e: any) => {
    setSearchValue('');
    const _payload = { ...userParams, limit: 10, offset: 0, userName: "", email: "", phone: "", roleName: "", status: e.target.value }
    dispatch({ type: Types.USERS_PARAMS, payload: _payload });
    dispatch(finAllUsersByStatus(_payload));
  }

  const onFilterChange = (e: any) => {
    setSearchValue('');
    setFilter(e.target.value)
    const _payload = { ...userParams, limit: 10, offset: 0, userName: "", email: "", phone: "", roleName: "" }
    dispatch({ type: Types.USERS_PARAMS, payload: _payload })
    dispatch(finAllUsersByStatus(_payload))
  }

  const onSearchUsers = (e: any) => {
    setSearchValue(e.target.value);
    if (filter === "userName") {
      const payload = { ...userParams, userName: e.target.value, offset: 0 }
      dispatch({ type: Types.USERS_PARAMS, payload: payload })
      dispatch(finAllUsersByStatus(payload))
    }
    else if (filter === "email") {
      const payload = { ...userParams, email: e.target.value, offset: 0 }
      dispatch({ type: Types.USERS_PARAMS, payload: payload })
      dispatch(finAllUsersByStatus(payload))
    }
    else if (filter === "phone") {
      const payload = { ...userParams, phone: e.target.value, offset: 0 }
      dispatch({ type: Types.USERS_PARAMS, payload: payload })
      dispatch(finAllUsersByStatus(payload))
    }
    else if (filter === "roleName") {
      const payload = { ...userParams, roleName: e.target.value, offset: 0 }
      dispatch({ type: Types.USERS_PARAMS, payload: payload })
      dispatch(finAllUsersByStatus(payload))
    }

  }

  const onClearSearch = () => {
    setSearchValue('');
    const _payload = { ...userParams, limit: 10, offset: 0, userName: "", email: "", phone: "", roleName: "" }
    dispatch({ type: Types.USERS_PARAMS, payload: _payload })
    dispatch(finAllUsersByStatus(_payload))
  }

  return (
    <React.Fragment>
      <CustomDialog
        title={actionType === 'add' ? t("Create User") : t('Edit User')}
        onClose={onCloseHandler}
        open={open}
        maxWidth="md"
        form={"createUser"}
        className="create-dy-field"
        disabled={btnState}
        actionType={actionType === 'add' ? 'Submit' : 'Update'}
      >
        <CreateUser
          actionType={actionType}
          onCloseHandler={onCloseHandler}
          onSubmitCreateUser={onSubmitUser}
          setSearchValue={setSearchValue}
          enableSubmit={(value: any) => setBtnState(value)}
          openCreateUser={open}
          setOpenCreateUser={setOpen}
        />
      </CustomDialog>
      {!allUserdataByStatus && <Loader />}
      <h2>{t("All Users")}</h2>
      <div className='d-flex justify-content-end org-filters-section'>
        <div className="search-container align-items-center d-flex">
          <div className="pe-2 selectBy"  >
            <select className="" onChange={(e) => onFilterChange(e)} >
              <option value="userName">{t("User Name")}</option>
              <option value="email">{t("Email")}</option>
              <option value="phone">{t("Phone No")}</option>
              <option value="roleName">{t("Role")}</option>
            </select>
          </div>
          <div className="align-items-center d-flex">
            <input className="form-input" value={searchValue} onChange={(e) => onSearchUsers(e)} placeholder={t("Search by Key")} />
            {searchValue && <span className='clearSearchIcon'><CustomizedTooltip title={t("Clear Search")}><ClearSharpIcon sx={{ fontSize: 15, opacity: .8 }} onClick={() => onClearSearch()} /></CustomizedTooltip></span>}
          </div>
        </div>
        {/* {ValidateRole() && */}
        <div className='d-flex'>
          {user?.userRolePrivileges?.data?.CreateUser && <div className='d-flex  filters  justify-content-center'>
            <a href="# " onClick={onOpenCreateUserModal} className='link-add-item '>
              <AccountCircleIcon />{t("Create User")}
            </a>
          </div>}
          <div className='d-flex  filters  justify-content-end'>
            <select className='form-select' onChange={(e) => onChangeUserStatus(e)}>
              <option value="true">{t("Active")}</option>
              <option value="false">{t("InActive")}</option>
            </select>
          </div>
        </div>
      </div>
      {allUserdataByStatus &&
        <div className="card">
          <DataTable value={allUserdataByStatus.users}
            // responsiveLayout="scroll"
            lazy
            paginator={(allUserdataByStatus?.totalRecords && allUserdataByStatus?.totalRecords > 10) ? true : false}
            rows={userParams.limit}
            selectionMode="single"
            totalRecords={allUserdataByStatus?.totalRecords}
            first={userParams.offset}
            onPage={onPageClick}
          >
            <Column field="userName" header={t("User Name")}></Column>
            <Column field="firstName" header={t("First Name")}></Column>
            <Column field="lastName" header={t("Last Name")}></Column>
            <Column field="role.name" header={t("Role")}></Column>
            <Column field="email" header={t("Email")}></Column>
            <Column field="phone" header={t("Phone No")}></Column>
            <Column field="country.name" header={t("Country")}></Column>
            <Column body={actionsBodyTemplate} header={t("Actions")}></Column>
          </DataTable>
        </div>
      }
    </React.Fragment>
  )

}

export default AllUser;