import * as React from 'react';
import IconButton from '@mui/material/IconButton';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import FileDownloadOutlinedIcon from '@mui/icons-material/FileDownloadOutlined';
import { useDispatch ,useSelector} from 'react-redux';
import { downloadUserfile, deleteUserDocument ,  finAllUsersByStatus} from './Actions/Action';
import { Alert, Confirm, toastAlert } from '../../actions/actions';
import DeleteIcon from '@mui/icons-material/Delete';
import { messages } from '../../configs/messages';
import { toastMsg } from '../../Common/Messages';


const ITEM_HEIGHT = 28;
function KababMenu(props: any) {
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const { userStatus} = useSelector((state: any) => state.users);
  const open = Boolean(anchorEl);
  const { rowData } = props;
  const dispatch = useDispatch();
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const downloadDocument = () => {

    if (rowData.userDocuments.length > 0) {
      handleClose()
      dispatch(downloadUserfile(rowData))
    } else {
      dispatch(Alert({
        status: 2,
        message: messages.users.DocDownload, 
        onOk: () => {
          // dispatch(findAllUsers());
          dispatch(finAllUsersByStatus(userStatus));
        }
      }))
    }
  }

  const deleteDocument = () => {
    if (rowData.userDocuments.length > 0) {
      handleClose();
        (dispatch as any)(Confirm({
          status: 0,
          message: messages.users.userDocument,
          onOk: () => {
            dispatch(deleteUserDocument(rowData.userDocuments[0].id, (data: any) => {
              if(data){
                dispatch(toastAlert({
                  status: 1,
                  message: toastMsg(data, ''),
                  open: true,
                }))
                dispatch(finAllUsersByStatus(userStatus));
                // dispatch(Alert({
                //   status: 2,
                //   message: data,
                //   onOk: () => {
                //     // dispatch(findAllUsers());
                //   }
                // }))
              }
             }));
          }
        }))
    }
  }

  return (
    <div>
      <IconButton
        aria-label="more"
        id="long-button"
        aria-controls={open ? 'long-menu' : undefined}
        aria-expanded={open ? 'true' : undefined}
        aria-haspopup="true"
        onClick={handleClick}
        className='p-0'
      >
        <MoreVertIcon />
      </IconButton>
      <Menu
        id="long-menu"
        MenuListProps={{
          'aria-labelledby': 'long-button',
        }}
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        PaperProps={{
          style: {
            maxHeight: ITEM_HEIGHT * 4.5,
            width: 'auto'
          },
        }}
      >

       {rowData.userDocuments.length > 0 ?  
        <div>
        <MenuItem style={{ fontSize: 13}} onClick={() => downloadDocument()}>
          <FileDownloadOutlinedIcon style={{ fontSize: 13, marginRight: 5 }}
            color="action"  /> Download Document
        </MenuItem>

        <MenuItem style={{ fontSize: 13}} onClick={() => deleteDocument()} >
        <span className='btn-rounded danger'>
              <DeleteIcon style={{ fontSize: 13 }} color="action" /> 
            </span>
            Delete Document
        </MenuItem>
        </div>:
        <MenuItem  onClick={()=>handleClose()} >
        Upload Document
        </MenuItem>
        }

      </Menu>
    </div>
  );
}


export default KababMenu;