import { Types } from "./Types"
import { CreateUser, CreateUserDocument } from '../constants/models';
import { timeZone } from '../constants/timeZone'
import _ from 'lodash';

const initialState = {
    userInitialDetails: _.cloneDeep(CreateUser),
    userDcoument: {
        userId: 0,
        documentTypeId: '',
        approvaldocument: ''
    },
    initialValues: _.cloneDeep(CreateUser),
    allUsersData: [],
    AllUsersGridValues: [],
    UserDetails: {},
    allCountries: {},
    timeZone: timeZone,
    showCreateUserDoc: false,
    privilegedRoles: [],
    documentTypes: [],
    allUsers: null,
    userDocumentUpload: CreateUserDocument,
    userStatus: true,
    allUserdataByStatus: null,
    userdata: [],
    allUsersSearch: [],
    deletedUserDocument: '',
    userParams: { limit: 10, offset: 0, userName: "", email: "", phone: "", roleName: "", status: true }
}

export const users = (state = initialState, action: { type: any, payload: any }) => {
    switch (action.type) {
        case Types.ALL_ASSIGNED_PRIVILEGED_ROLES:
            return { ...state, privilegedRoles: action.payload }
        case Types.ALL_USER_INITIAL_VALUES:
            return { ...state, userInitialDetails: action.payload }
        case Types.ALL_USERS_DATA:
            return { ...state, allUser: action.payload }
        case Types.ALL_USERS_LIST:
            return { ...state, allUsers: action.payload, }
        case Types.ALL_USERS_DETAILS:
            return { ...state, UserDetails: action.payload }
        case Types.SAVE_USER_DETAILS:
            return { ...state, SaveUserDetails: action.payload, showCreateUserDoc: true }
        case Types.ALL_ROLE:
            return { ...state, AllRole: action.payload }
        case Types.ALL_COUNTRIES:
            return { ...state, allCountries: action.payload }
        case Types.DOCUMENT_TYPE:
            return { ...state, documentTypes: action.payload }
        case Types.SHOW_CREATE_USER_DOCUMENT:
            return { ...state, showCreateUserDoc: action.payload }
        case Types.USERS_BY_STATUS:
            return {
                ...state, AllUsersGridValues: action.payload,
                userdata: _.cloneDeep(action.payload)
            }
        case Types.DELETED_USER_DOCUMENT:
            return { ...state, deletedUserDocument: action.payload }
        case Types.ON_EDIT_USER:
            return { ...state, userInitialDetails: action.payload }
        case Types.USER_STATUS:
            return { ...state, userStatus: action.payload }
        case Types.FILTERED_USERS:
            return { ...state, allUsersData: action.payload }
        case Types.USERS_PARAMS:
            return { ...state, userParams: action.payload }
        case Types.ALL_USERS_BY_STATUS:
            return { ...state, allUserdataByStatus: action.payload }
        default:
            return { ...state }
    }
}
