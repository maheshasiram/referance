import { Types } from '../Reducer/Types';
import { fetch } from '../../../Constants/fetch';
import { requests } from '../../../configs/env';
import { Loader } from "../../../actions/actions";
import { CreateUser } from '../constants/models';

// interface dataType { 
//   findUserDetailsFromLdap:any
// } 
export const findUserDetailsFromLdap: any = (userName: string, callback: any) => {
  return function (dispatch: any) {
    dispatch(Loader(true))
    fetch({
      method: 'GET',
      url: `${requests.users.getUserDetailsFromLdap}${userName}`,
    })
      .then((response: any) => {
        // console.log("response", response)
        //Default values are taking from Create user model
        const data = {
          ...response.data, country: CreateUser.country, userId: 0, filename: "", documentTypeId: "", role: CreateUser.role,
          phone: CreateUser.phone, timeZone: CreateUser.timeZone, roleId: CreateUser.roleId
        }
        dispatch({ type: Types.ALL_USER_INITIAL_VALUES, payload: data });
        callback(response.data);
        dispatch(Loader(false))
      }).catch((error) => {
        console.log("error....", error)
      })
  }
}



//    this is for alluser list on user page
export const findAllUsers: any = (callback: any) => {
  const url = requests.users.userList
  return function (dispatch: any) {
    dispatch(Loader(true))
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        dispatch({ type: Types.ALL_USERS_LIST, payload: response.data })
        if (callback) {
          callback()
        }
        dispatch(Loader(false))
      }).catch((error) => {
        console.log("error....", error)
      })
  }
}

//    this is for Get alluser list status       
export const finAllUsersByStatus: any = (payload: any) => {
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: requests.users.getUsersByStatus,
      data: payload
    })
      .then((response: any) => {
        dispatch({ type: Types.ALL_USERS_BY_STATUS, payload: response.data })
        dispatch(Loader(false));
      }).catch((error) => {
        console.log("error....", error)
      })
  }
}
//    this is for filling data by id
// export const findUsersDetails: any = (id: any) => {
//   let url = `${requests.users.UserDetails}?id=${id}`
//   return function (dispatch: any) {
//     dispatch(Loader(true))
//     fetch({
//       method: 'GET',
//       url: url,
//       data: ''
//     })
//       .then((response: any) => {
//         dispatch({ type: Types.ALL_USERS_DETAILS, payload: response.data })
//         dispatch(Loader(false))
//       }).catch((error) => {
//         console.log("error....", error)
//       })
//   }
// }

// this is for save user details
export const SaveUserDetails: any = (payload: any, callback: any) => {
  return function (dispatch: any) {
    dispatch(Loader(true))
    fetch({
      method: 'POST',
      url: requests.users.submitUserDetails,
      data: payload
    })
      .then((response: any) => {
        dispatch({ type: Types.SAVE_USER_DETAILS, payload: response.data })
        callback(response.data);
        dispatch(Loader(false))
      })
      .catch((error) => {
        console.log("error....", error)
      })
  }
}

//this is for  Role
export const fetchAllPrivilegedRoles: any = () => {
  return function (dispatch: any) {
    dispatch(Loader(true))
    fetch({
      method: 'GET',
      url: requests.roles.fetchAllRolesWithPrivileges,
      data: ''
    })
      .then((response: any) => {
        dispatch({ type: Types.ALL_ASSIGNED_PRIVILEGED_ROLES, payload: response.data })
        dispatch(Loader(false))
      }).catch((error) => {
        console.log("error....", error)
      })
  }
}

// this api for get document type
export const getDocumentTypes: any = () => {
  return function (dispatch: any) {
    // dispatch(Loader(true))
    fetch({
      method: 'GET',
      url: requests.users.DocumentTypes,
      data: ''
    })
      .then((response: any) => {
        dispatch({ type: Types.DOCUMENT_TYPE, payload: response.data });
        // dispatch(Loader(false))
      }).catch((error) => {
        console.log("error....", error)
      })
  }
}

// this api for  Upload document 
export const uploadDocument: any = (payload: any, formData: any, callback: any) => {
  return function (dispatch: any) {
    dispatch(Loader(true))
    fetch({
      method: 'POST',
      url: `${requests.users.sendDocument}?userId=${payload.userId}`,
      data: formData,
      headers: {
        "Accept": "*/*",
        "Content-Type": "multipart/form-data"
      }
    }).then((response: any) => {
      callback(response.data);
      dispatch(Loader(false))
    }).catch((error) => {
      console.log("error....", error)
    })
  }
}

//on edit user
export const getUserOnEdit: any = (userId: any, callback: any) => {
  const url = `${requests.users.findUserByUserId}?userId=${userId}`
  return function (dispatch: any) {
    dispatch(Loader(true))
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        const _response = response.data
        // _response.documentTypeId = response.data.userDocuments[0]?.documentType.id
        _response.documentTypeId = response.data.userDocuments[0]?.id
        _response.filename = ""
        dispatch({ type: Types.ON_EDIT_USER, payload: _response });
        callback(_response)
        dispatch(Loader(false));
      })
      .catch(err => {
        console.log("....err", err);
      })
  }
}

// this is for Update user details
export const UpdateUser: any = (payload: any, deletedUserDocument: any, callback: any) => {
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: requests.users.updateUser,
      data: payload
    }).then((response: any) => {
      callback(response.data);
      if (deletedUserDocument) {
        dispatch(deleteUserDocument(deletedUserDocument));
      }
      dispatch(Loader(false));
    }).catch((error) => {
      console.log(error)
      // dispatch(Loader(false))
      // callback(error.response.data);
    })
  }
}

//this api for Download File
export const downloadUserfile: any = (payload: any) => {
  const url = `${requests.users.downloadfile}/${payload.userDocuments[0].id}`;
  const fileName = payload.userDocuments[0].fileName;
  return function (dispatch: any) {
    dispatch(Loader(true))
    fetch({
      method: 'GET',
      url: url,
      data: '',
      responseType: 'blob',
      headers: {

      }
    })
      .then((blob: any) => {
        // 2. Create blob link to download
        const url = window.URL.createObjectURL(new Blob([blob.data]));
        // console.log('...286',blob, url)
        const link: any = document.createElement('a');
        link.href = url;
        link.setAttribute('download', `${fileName}`);
        // 3. Append to html page
        document.body.appendChild(link);
        // 4. Force download
        link.click();
        // 5. Clean up and remove the link
        // link.parentNode.removeChild(link);
        dispatch(Loader(false));
      })
  }
}

//this api for delete document   
export const deleteUserDocument: any = (payload: any, callback: any) => {
  const url = `${requests.users.deleteDocumentById}/${payload}`;
  return function (dispatch: any) {
    dispatch(Loader(true))
    fetch({
      method: 'DELETE',
      url: url,
      data: ''
    }).then((response) => {
      console.log("....260", response.data)
      if (callback) {
        callback(response.data);
      }
      dispatch(Loader(false));
    }).catch((error: any) => {
      console.log('error', error)
    })
  }
}

export const restoreUser: any = (userId: any, callback: any) => {
  const url = `${requests.users.restoreUser}?userId=${userId}`;
  return function (dispatch: any) {
    dispatch(Loader(true))
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response) => {
        dispatch(Loader(false));
        callback(response.data);
      }).catch((error: any) => {
        console.log('error', error)
      })
  }
}

export const deleteUser: any = (userId: any, callback: any) => {
  const url = `${requests.users.deleteUser}?userId=${userId}`;
  return function (dispatch: any) {
    dispatch(Loader(true))
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response) => {
        dispatch(Loader(false));
        callback(response.data);
      }).catch((error: any) => {
        console.log('error', error)
      })
  }
}

