import React, { useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";

function NotFound() {
  const navigate = useNavigate()
  const loaded = useRef(false)
  useEffect(() => {
    if (!loaded.current) {
      // navigate('/')
      loaded.current = true
    }
  }, [])
  const onNavigateToHome =()=>{
    navigate('/')
  }
  return (
    <div className="notFound-ciontainer" >
      <div className="text-center" >
        <div className="d-flex align-items-end" >
          <h1 className="mb-1" >404 Error</h1>
          <h6 className="ps-3" >Page Not Found.....!</h6>
        </div>
        <div className="pt-3" >
        <button className="btn-eprimary" onClick={onNavigateToHome} >Back to Home</button>
        </div>
      </div>
    </div>
  )

}

export default NotFound;