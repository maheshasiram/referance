import React from 'react'
import { useTranslation } from 'react-i18next';

function Multilanguages() {

    const { i18n } = useTranslation();

    // const onClickLanguageChange = (e: any) => {
    //     i18n.changeLanguage(language)
    // }
    const changLang = (language: any) => {
        i18n.changeLanguage(language);
    };

    return (
        <div>
            {/* <select value={i18n.language} className='mt-2' onChange={changLang}>
                <option value="en">English</option>
                <option value="fr">French</option>
                <option value="es">Spanish</option>
            </select> */}
            <button onClick={() => changLang("English")}>EN</button>
            <button onClick={() => changLang("Spanish")}>ES</button>
            <button onClick={() => changLang('French')}>FR</button>
        </div>
    )
}
export default Multilanguages;
