import { fetch } from '../../../Constants/fetch';
import { requests } from '../../../configs/env';
import { Types } from '../Constants/Types';
import store from '../../../sagas/main';
import _ from "lodash"
import { Loader } from '../../../actions/actions';


export const fetchAllRoles: any = () => {
  return function (dispatch: any) {
    dispatch(Loader(true))
    fetch({
      method: 'GET',
      url: requests.roles.fetchAllRoles,
    })
      .then((response: any) => {
        response.data && response.data.sort((a: any, b: any) => a.id - b.id);
        dispatch({ type: Types.GET_ALL_ROLES, payload: response.data });
        dispatch({ type: Types.UPDATE_ROLE_NAME, payload: response.data[0] });
        dispatch({ type: Types.UPDATE_TABPANEL_VALUE, payload: response.data[0].id.toString() })
        dispatch(fetchAssignedRolePrivileges(response.data[0].id));
        dispatch(Loader(false))
      }).catch((error: any) => {
        console.log('error', error)
      })
  }
}

export const fetchRolePrivilegesByRoleId: any = () => {
  const url = `${requests.roles.fetchRolePrivilegesByRoleId}/75`
  return function () {
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
  }
}

export const fetchAssignedRolePrivileges: any = (payload: any, callback: any) => {
  const url = `${requests.roles.fetchAssignedRolePrivileges}?roleId=${payload}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        const { allPrivileges } = store.getState().roles;
        const _privilegeData = _.cloneDeep(allPrivileges)
        const _allPrivileges = allPrivileges
        response?.data?.privilegeGroups && response?.data?.privilegeGroups.length > 0 && response?.data?.privilegeGroups.map((item: any) => {
          _allPrivileges.length > 0 && _allPrivileges.map((subItem: any, subIndex: any) => {
            if (item.privilegeGroup.id === subItem.privilegeGroup.id) {
              subItem.privileges.length > 0 && subItem.privileges.map((privItem: any, privIndex: any) => {
                item.privileges.length > 0 && item.privileges.map((rolePriv: any) => {
                  if (privItem.id === rolePriv.id) {
                    _privilegeData[subIndex].privileges[privIndex].status = true
                  }
                  return null
                })
                return null
              })
            }
            return null
          })
          return null
        })
        response.data?.privilegeGroups?.map((item: any) => {
          item.privileges?.map((i: any) => {
            i.defaultSelected = i.status
            return null
          })
          return null
        })
        if (payload > 0) {
          dispatch({ type: Types.GET_PRIVILIGES_ASSIGNED_TO_GRP, payload: response.data.privilegeGroups })
          dispatch({ type: Types.UPDATE_ROLE_INFO, payload: response.data.role })
        }
        if (callback) { callback(response) }
        dispatch(Loader(false));
      }).catch((error: any) => {
        console.log('error', error)
      })
  }
}
//commented -tirumal
// export const fetchAllRolesWithPrivileges: any = () => {
//   // let url = `${requests.roles.fetchAssignedRolePrivileges}?roleId=${payload}`
//   return function (dispatch: any) {
//     dispatch(Loader(true));
//     fetch({
//       method: 'GET',
//       url: 'http://192.168.10.118:8080/platform-admin-app/edc/pfa/role/v1/fetchAllRolePrivileges',
//       data: ''
//     })
//       .then(() => {
//         console.log()
//       })
//   }
// }


export const getAllPrivilegesAssignedToGrp: any = () => {
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: requests.roles.getAllPrivilegesAssignedToGrp,
    })
      .then((response: any) => {
        const _data = [...[], ...response.data]
        response.data && response.data.length > 0 &&
          _data.map((item: any, index: number) => {
            item && item.privileges && item.privileges.length > 0 &&
              item.privileges.map((subItem: any, subIndex: number) => {
                _data[index].privileges[subIndex] = { ...subItem, status: false }
                return null
              })
              return null
          })

        // dispatch({ type: Types.GET_PRIVILIGES_ASSIGNED_TO_GRP, payload: _data })
        dispatch({ type: Types.GET_ALL_PRIVILIGES, payload: _data })
        dispatch(fetchAllRoles(_data))
        dispatch(Loader(false))
      }).catch((error: any) => {
        console.log('error', error)
      })
  }
}

export const getCreateRole: any = (payload: any, callback: any) => {
  const url = `${requests.roles.createRole}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: url,
      data: payload.role
    })
      .then((response: any) => {
        console.log('responsee create.........', response)
        if (callback) { callback(response) }
        // dispatch(assignPrivilegesToRole(params.privilegesAssigned))
        dispatch(Loader(false))
      }).catch((error: any) => {
        console.log('error', error)
      })
  }
}

export const assignPrivilegesToRole: any = (payload: any, callback: any) => {
  const url = `${requests.roles.assignPrivilegesToRole}`
  return function (dispatch: any) {
    fetch({
      method: 'POST',
      url: url,
      data: payload
    })
      .then((response: any) => {
        // console.warn('assigned priviliges...........', response.data);
        dispatch(fetchAllRoles('create'))
        if (callback) { callback(response) }
      }).catch((error: any) => {
        console.log('error', error)
      })
  }
}


export const deleteRoleByRoleId: any = (id: number) => {
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'DELETE',
      url: `${requests.roles.deleteRoleByRoleId}${id}`,
    })
      .then(() => {
        dispatch({ type: Types.UPDATE_ROLE_NAME, payload: { name: '' } })
        dispatch(fetchAllRoles('delete'))

      }).catch((error: any) => {
        console.log('error', error)
      })
  }
}
export const getUpdateRole: any = (payload: any, callback: any) => {
  const url = `${requests.roles.updateRole}`
  return function (dispatch: any) {
    fetch({
      method: 'POST',
      url: url,
      data: payload.role
    })
      .then((response: any) => {
        // dispatch(Alert({ message: response.data, onOk: () => { } }))
        // let params = {...payload.privilegesAssigned.role, name:payload.roleName}
        // payload.privilegesAssigned.role.name = payload.roleName
        // dispatch(updateAllRolePrivileges(payload.privilegesAssigned))
        // console.warn('update name..........', params);
        if (callback) {
          callback(response)
        }

      }).catch((error) => {
        console.log("error....", error)
        dispatch(Loader(false))
        callback(error.response.data)
      })
  }
}

export const updateAllRolePrivileges: any = (payload: any, callback: any) => {
  const url = `${requests.roles.updateAllRolePrivileges}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: url,
      data: payload
    })
      .then((response: any) => {
        dispatch(fetchAllRoles('update'))
        if (callback) { callback(response) }
      }).catch((error: any) => {
        console.log('error', error)
      })
  }
}
export const getAllUsersWithSameRole: any = (payload: any, callback: any) => {
  const url = `${requests.roles.getAllUsersWithSameRole}?roleId=${payload}`
  return function (dispatch: any) {
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        response && response.data && response.data.length > 0 && response.data.map((item: any) => (
          item.roleId = payload
        ))
        // console.log('getAllUsersWithSameRole.............', response.data)
        dispatch({ type: Types.GET_USERS_WITH_SAMEROLE, payload: response.data })
        if (callback) { callback(response) }
      }).catch((error: any) => {
        console.log('error', error)
      })
  }
}

export const getUpdateUserRoles: any = (payload: any,callback: any) => {
  const url = `${requests.roles.updateUserRoles}?roleId=${payload.roleId}`
  return function () {
    fetch({
      method: 'POST',
      url: url,
      data: payload.array
    })
      .then((response: any) => {
        // console.log('updateUserRoles.............', response.data)
        if (callback) { callback(response) }
      }).catch((error: any) => {
        console.log('error', error)
      })
  }
}