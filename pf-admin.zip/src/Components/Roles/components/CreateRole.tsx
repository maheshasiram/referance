import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import _ from 'lodash'
import { Types } from '../Constants/Types';
import PrivilegeAccordion from './PrivilegeAccordion'
import { useTranslation } from 'react-i18next';
// import { userPrivilegesTypes } from '../Constants/Models';

function CreateRole(props: any) {
    const { t } = useTranslation();
    const dispatch = useDispatch()
    const { validateRole, newRole, newPrivileges, RoleInFo } = useSelector((state: any) => state.roles);
    const { allConFigData } = useSelector((state: any) => state.app);
    const { allPrivileges, setBtnState, btnState } = props;
    const [prevGroups, setPrevGroups] = React.useState(allPrivileges);
    const userDynamicPrivilegesTypes = [
        allConFigData.ViewStudy,
        allConFigData.ViewOrganization,
        allConFigData.ViewRolesandPrivileges,
        allConFigData.ViewUsers,
        allConFigData.ViewDatabase

    ]

    const onSelectPrivilege = (e: any, item: any, index: number, subItem: any, subIndex: number) => {
        const _privileges = _.cloneDeep(newPrivileges)
        _privileges[index].privileges[subIndex] = { ...subItem, status: e.target.checked }
        _privileges[index].privilegeGroup.status = true
        _privileges[index].privilegeGroup.grouplevelStatus = false
        _privileges[index]?.privileges?.map((itm: any) => {
            if (itm.status === true) {
                _privileges[index].privilegeGroup.grouplevelStatus = true
            }
            return null
        });
        const _subprivileges = _privileges[index].privileges
        const _userPrivilegesTypes = userDynamicPrivilegesTypes
        _userPrivilegesTypes.map((privilege: any) => {
            _subprivileges.map((item: any) => {
                if (item.code === privilege && item.status === false) {
                    return item.status = e.target.checked
                }
                return null
            })
            return null
        })

        dispatch({ type: Types.GET_VALIDATE_ROLE, payload: { ...validateRole, privilegesSelected: false } });
        dispatch({ type: Types.GET_PRIVILEGES_CREATE_ROLE, payload: _privileges });
        setPrevGroups(_privileges)
    }

    const onRoleNameChange = (event: any) => {
        const _payload = { ...newRole, roleName: event.target.value && event.target.value !== " " ? event.target.value.replace(/\s\s+/g, ' ') : "" }
        dispatch({ type: Types.UPDATE_CREATEROLE_PAYLOAD, payload: _payload })
        dispatch({
            type: Types.GET_VALIDATE_ROLE,
            payload: { ...validateRole, roleName: event.target.value === '' ? true : false, roleNameExist: false }
        })
        setBtnState(false)
    }

    return (
        <React.Fragment>
            <div className='create-role rp-container'>
                <div className=' col-sm-5 pt-2' >
                    <label className="form-label roleNameLabel font-weight-bold">{t("Role Name")} :<span className='text-danger mx-1'>*</span></label>
                    <input className='form-control'
                        placeholder={t("Role Name")}
                        value={newRole.roleName}
                        disabled={RoleInFo?.staticRole}
                        onChange={onRoleNameChange} />
                    {
                        validateRole && validateRole.roleName && <p className='p-0 pt-2 text-danger'>{t("Please enter Role Name")}</p>
                    }
                    {
                        validateRole && validateRole.roleNameExist && <p className='p-0 pt-2 text-danger'>{t("Role Name Already Exist, Please Enter Another Name")}</p>
                    }
                </div>
                {
                    validateRole && validateRole.privilegesSelected && <p className='p-0 pt-2 text-danger text-center'>{t("Please select atleast one Privilege")}</p>
                }

                <div className="d-flex align-content-start flex-wrap previligeGrps privilegeAccGrp pt-2">
                    <h6 className='m-0 py-2'>{t("Privileges")} :</h6>
                    <div className='create-privilegesGrp'>
                        <PrivilegeAccordion
                            privilegesGroups={prevGroups}
                            onSelectPrivilege={onSelectPrivilege}
                            name="update"
                            setBtnState={setBtnState}
                            btnState={btnState}
                        />
                    </div>
                </div>
            </div>
        </React.Fragment>
    )
}

export default CreateRole;