
import React from "react";
import { useSelector, useDispatch } from "react-redux";
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import PrivilegeAccordion from './PrivilegeAccordion';
import { Confirm, toastAlert } from "../../../actions/actions";
import { getAllUsersWithSameRole, getUpdateUserRoles, deleteRoleByRoleId } from "../actions/actions";
import CustomDialog from "../../../Common/modals/CustomDialog";
import { Types } from "../Constants/Types";
import { validateUserRole } from "../Constants/Interfaces";
import CustomizedTooltip from '../../../Common/CustomizedTooltip/CustomizedTooltip'
import { messages } from "../../../configs/messages";
import { useTranslation } from 'react-i18next';
import { confirmMsg, toastMsg } from "../../../Common/Messages";


export default function PriviligesData(props: any) {

  const { t } = useTranslation();
  const dispatch = useDispatch()
  const { roleNameHeader, usersWithSameRole, allRoles, RoleInFo } = useSelector((state: any) => state.roles);
  const { user } = useSelector((state: any) => state.app);
  const { assignedPrivileges } = props
  const [open, setOpen] = React.useState(false);
  const [validateRoles, setValidateRoles] = React.useState(false)
  const [validateUsersList, setvalidateUsersList] = React.useState([]);

  const onSelectPrivilege = () => {
    console.log('...check');

  }

  const onDeleteRole = () => {
    dispatch(Confirm({
      status: 0,
      message: confirmMsg(messages.roles.deleteRole, roleNameHeader.name),
      onOk: () => {
        dispatch(getAllUsersWithSameRole(roleNameHeader.id, (callback: any) => {
          if (callback && callback.data && callback.data.length > 0) {
            setOpen(true)
          }
          else {
            dispatch(deleteRoleByRoleId(roleNameHeader.id))
            dispatch(toastAlert({
              status: 1,
              message: toastMsg(messages.commonMessages.inActivated, roleNameHeader.name),
              open: true
            }))
          }
        }))
      }
    }))
  }

  const onCloseChangeRole = () => {
    setOpen(false)
    setValidateRoles(false)
    setvalidateUsersList([])
  }
  const onChangeUserRole = (e: any, item: any, index: number) => {
    const _usersData = [...[], ...usersWithSameRole]
    _usersData[index].roleId = e.target.value
    dispatch({ type: Types.GET_USERS_WITH_SAMEROLE, payload: _usersData })
    setValidateRoles(false)
    setvalidateUsersList([])
  }

  const onRoleDelete = () => {
    let previousRole = false
    const _array: validateUserRole[] = []
    const _userNotChanged: any = [...[], ...validateUsersList]

    usersWithSameRole && usersWithSameRole?.map((item: any) => {
      if (item.roleId === roleNameHeader.id) {
        previousRole = true
        _userNotChanged.push(item.userName)
      } else {
        const _object: validateUserRole = { userId: item.userId, roleId: item.roleId }
        _array.push(_object)
      }
      return null
    })
    if (_userNotChanged.length < 2) {
      setvalidateUsersList(_userNotChanged)
    }
    if (previousRole) {
      setValidateRoles(true)
    } else {
      setValidateRoles(false)
      const _payload= {array:_array,roleId:roleNameHeader.id,}
      dispatch(getUpdateUserRoles(_payload, (callback: any) => {
        if (callback.data === "User Roles Updated Successfully") {
          dispatch(deleteRoleByRoleId(roleNameHeader.id))
          dispatch(toastAlert({
            status: 1,
            message: toastMsg(messages.commonMessages.inActivated, roleNameHeader.name),
            open: true
          }))
          onCloseChangeRole()
        }
      }))
    }
  }
  return (
    <React.Fragment>
      <CustomDialog
        title={t("Update User Role")}
        onClose={onCloseChangeRole}
        onSubmitHandler={() => onRoleDelete()}
        open={open}
        maxWidth="sm"
        form=""
        className="change-user-roles"
        disabled={false}
        actionType={'Submit'}
      >
        <div>
          {!validateRoles && <p className="mb-0 noteHeader">{t("If you want to continue, Please change the Role for the following Users")}</p>}
          {
            validateRoles && <div className="d-flex justify-content-center pt-2">
              <p className="p-0 m-0 text-danger text-center">{t("Please Change The Role For")}</p>
              {
                <span className="ps-2 text-primary font-weight-bold"> {validateUsersList.length > 0 && validateUsersList.join(', ')}</span>
              }
            </div>
          }
          {
            usersWithSameRole && usersWithSameRole.length > 0 && usersWithSameRole.map((item: any, index: number) => {
              return (
                <div className="d-flex pt-3" key={index}>
                  <div className=" d-flex col-sm-6 pe-2 align-items-center">
                    <label className="col-sm-3 p-0">{t("User Name")}</label>
                    <input value={item.userName} className='form-control' disabled />
                  </div>
                  <div className="d-flex col-sm-6 align-items-center">
                    <label className="col-sm-3 p-0" >{t("Role Name")}</label>
                    <select value={item.roleId} onChange={(e) => onChangeUserRole(e, item, index)} className='form-select' >
                      {allRoles && allRoles.map((item: any) => {
                        return <option key={index} value={item.id}>{item.name}</option>
                      })}
                    </select>
                  </div>
                </div>
              )
            })
          }
        </div>
      </CustomDialog>
      <div className="rp-container">
        <div className="d-flex align-items-center justify-content-between mb-0 rp-header px-3 py-2">
          <div className="d-flex w-100">
            <h5 className="p-0 m-0 role-header d-inline-flex w-50">{roleNameHeader.name ? roleNameHeader.name : '' as string}</h5>
            <div className="w-50 d-inline-flex justify-content-end" style={{ width: '50%' }}>
              {!RoleInFo.staticRole && <div className="d-flex">
                {user?.userRolePrivileges?.data?.EditRolesandPrivileges && <span className="btn-rounded">
                  {<CustomizedTooltip title={t("Edit Role")}><EditIcon onClick={props.onEditRoleHandler} sx={{ fontSize: 14, opacity: .8, cursor: "pointer" }} /></CustomizedTooltip>}
                </span>}
                {!RoleInFo.staticRole && user?.userRolePrivileges?.data?.DeleteRolesandPrivileges && <span className="btn-rounded danger">
                  {<CustomizedTooltip title={t("Delete Role")}>
                    <DeleteIcon onClick={RoleInFo.staticRole ? () => { console.log('static role') } : onDeleteRole}
                      sx={{ fontSize: 14, opacity: .8, cursor: RoleInFo.staticRole ? "not-allowed" : "pointer" }}
                    /></CustomizedTooltip>}
                </span>}
              </div>}

            </div>
          </div>

        </div>
        <div className="d-flex align-content-start  flex-wrap previligeGrps">
          <PrivilegeAccordion
            privilegesGroups={assignedPrivileges}
            onSelectPrivilege={onSelectPrivilege}
            name="render"
          />
        </div>
      </div>
    </React.Fragment>
  )
}