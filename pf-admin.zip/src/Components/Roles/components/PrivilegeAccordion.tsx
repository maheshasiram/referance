import React from "react";
import Accordion from '@mui/material/Accordion';
import AccordionDetails from '@mui/material/AccordionDetails';
import AccordionSummary from '@mui/material/AccordionSummary';
import Typography from '@mui/material/Typography';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
// import { userPrivilegesTypes } from "../Constants/Models";
import { useSelector } from "react-redux";

function PrivilegeAccordion(props: any) {
  const [expanded, setExpanded] = React.useState<string | false>(false);
  const { allConFigData } = useSelector((state: any) => state.app);
  const { privilegesGroups, setBtnState, onSelectPrivilege } = props

  const userDynamicPrivilegesTypes = [
    allConFigData.ViewStudy,
    allConFigData.ViewOrganization,
    allConFigData.ViewRolesandPrivileges,
    allConFigData.ViewUsers,
    allConFigData.ViewDatabase

  ]


  const newPrivilegesGroups = privilegesGroups
  newPrivilegesGroups && newPrivilegesGroups.map((privi: any) => {
    privi.privileges.map((item: any) => {
      if (item.code === allConFigData?.ViewStudy) {
        item.status = true
      }
      return null
    })
    return null
  })

  const handleChange = (panel: string) => (event: React.SyntheticEvent, isExpanded: boolean) => {
    setExpanded(isExpanded ? panel : false);
  };
  const onPrivilegeDisable = (item: any, index: any, subItem: any) => {
    let _disabled = false
    const disabled = item.privileges.filter((privilege: any) =>
      privilege.status === true).length > 1 ? true : false  //previous


    const _userPrivilegesTypes = userDynamicPrivilegesTypes
    _userPrivilegesTypes.map((privi: any) => {
      if (subItem.code === privi && subItem.status) {
        _disabled = disabled
      }
      return null
    })


    if (item.privilegeGroup.code === allConFigData?.Study) {
      if (subItem.code === allConFigData?.StudyApprover) {
        item.privileges.map((privilege: any) => {
          if ((privilege.code === allConFigData?.Provisioner || privilege.code === allConFigData?.DevopsApprover) && privilege.status) {
            _disabled = true
          }
          return null
        })
      }
      else if (subItem.code === allConFigData?.Provisioner) {
        item.privileges.map((privilege: any) => {
          if ((privilege.code === allConFigData?.StudyApprover || privilege.code === allConFigData?.DevopsApprover) && privilege.status) {
            _disabled = true
          }
          return null
        })
      }
      else if (subItem.code === allConFigData?.DevopsApprover) {
        item.privileges.map((privilege: any) => {
          if ((privilege.code === allConFigData?.StudyApprover || privilege.code === allConFigData?.Provisioner) && privilege.status) {
            _disabled = true
          }
          return null
        })
      }
      else if (subItem.code === allConFigData?.ViewOrganization) {
        subItem.status = true
      }
    }
    return _disabled
  }
  return (
    <div className="privilegeAccGrp">
      {
        newPrivilegesGroups && newPrivilegesGroups.length > 0 && newPrivilegesGroups.map((item: any, index: any) => {
          return (
            (item.privileges.length > 0) &&
            <div key={index}>
              <Accordion expanded={expanded === 'panel' + index} onChange={handleChange('panel' + index)}
              >
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel1bh-content"
                  id="panel1bh-header"
                >
                  <Typography
                    // component={'div'} 
                    sx={{ width: '33%', flexShrink: 0, fontSize: '13px' }}>
                    {item.privilegeGroup && item.privilegeGroup.name as string}
                    ({item.privileges && item.privileges.length > 0 &&
                      item.privileges.filter((privilege: any) => privilege.status === true).length}/ {item.privileges.length})
                  </Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography component={'div'} className="privilege-container">
                    {item.privilegeGroup.name === 'User Management' ? true : false}
                    {
                      item.privileges && item.privileges.length > 0 && <div className="d-flex flex-wrap">
                        {
                          item.privileges.map((subItem: any, subIndex: any) => {
                            return <div key={subIndex} className="d-inlin-block mx-1 mb-1 check-container">
                              {props.name === 'render' ?
                                <input
                                  type={'checkbox'}
                                  checked={subItem.status}
                                  className="btn-check"
                                  id={`chk_${props.name}_${index}_${subIndex}`}
                                  // disabled={subItem.code === 'USER_PREV_TYPE_VIEW_USERS' ? true : false}
                                  onChange={(e: any) => {
                                    props.onSelectPrivilege(e, item, index, subItem, subIndex, 'child',)
                                    // setBtnState(false);
                                  }}
                                /> :
                                <input
                                  type={'checkbox'}
                                  // checked={subItem.status}
                                  checked={subItem.status}
                                  className="btn-check"
                                  id={`chk_${props.name}_${index}_${subIndex}`}
                                  onChange={(e: any) => {
                                    onSelectPrivilege(e, item, index, subItem, subIndex, 'child',)
                                    setBtnState(false);
                                  }}
                                  // className="btn-check"
                                  disabled={onPrivilegeDisable(item, index, subItem)}
                                // id={`chk_${props.name}_${index}_${subIndex}`}
                                />

                              }
                              <label className={props.name === 'render' ? "btn btn-outline-primary disabledCheckbox" : "btn btn-outline-primary"}
                                htmlFor={`chk_${props.name}_${index}_${subIndex}`}>
                                <span className={props.name === 'render' ? subItem.status ? '' : 'disabledCheckbox' : ''}>
                                </span> {subItem.name}</label>
                            </div>
                          })
                        }
                      </div>
                    }
                  </Typography>
                </AccordionDetails>
              </Accordion>
              <>
                {
                }
              </>
            </div>
          )
        })
      }
    </div>
  )
}
export default PrivilegeAccordion