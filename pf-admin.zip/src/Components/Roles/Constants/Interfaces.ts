export interface privilegeGroup {
    id?: number
    name?: string
    code?: string
    description?: string
    configDataType: {
        id?: number
        name?: string
        code?: string
        description?: string
    }

}

export interface SelectedPrivileges {
    privilegeGroup: privilegeGroup
    privileges: any,
    privilegeNames: any
}

export interface validateUserRole {
    userId: number,
    roleId: number
}