export type Roles = {
    id?: number,
    roleName?: string,
    privileges: [{
        id?: number,
        privilege_name?: string,
        status?: string
    }
    ]
}

export type PrivilegesGroup = {
    Grp_Name?: string,
    id?: number,
    privilege: [
        {
            id?: number,
            privilege_name?: string,
            status?: string
        },
    ]
}

export const Role: Roles = {
    id: NaN,
    roleName: "",
    privileges: [{
        id: NaN,
        privilege_name: "",
        status: ""
    }
    ]
}

export const RolePrivileges: PrivilegesGroup = {
    Grp_Name: "",
    id: NaN,
    privilege: [
        {
            id: NaN,
            privilege_name: "",
            status: ""
        },
    ]
}

export const RoleInFo = {
    "id": 0,
    "name": "",
    "description": "",
    "status": true,
    "staticRole": false
}

export const userPrivilegesTypes = [
    "USER_PREV_TYPE_VIEW_ORGANIZATION",
    "USER_PREV_TYPE_VIEW_DATABASE",
    "USER_PREV_TYPE_VIEW_USERS",
    "USER_PREV_TYPE_VIEW_ROLES_AND_PRIVILEGES",
    "USER_PREV_TYPE_VIEW_STUDY"
]

