
import { Types } from "../Constants/Types";
import { RolePrivileges, Role, RoleInFo } from '../Constants/Models'

const initialState = {
    allRoles: null,
    allRolePriviliges: null,
    rolePrivilage: RolePrivileges,
    roles: Role,
    allPrivileges: null,
    assignedPrivileges: null,
    tabPanelValue: null,
    roleNameHeader: {
        name: ''
    },
    newRole: {
        roleName: '',
        privilegesAssigned: {
            groupId: 0,
            privilegeGroups: [],
            privileges: [],
            role: null
        }
    },
    validateRole: {
        roleName: false,
        roleNameExist: false,
        privilegesSelected: false
    },
    newPrivileges: null,
    createActionType: true,
    usersWithSameRole: [],
    RoleInFo: RoleInFo,
}

export const roles = (state = initialState, action: { type: any, payload: any }) => {

    switch (action.type) {
        case Types.ON_ALL_ROLES:
            return { ...state, roleObje: action.payload }
        case Types.ON_ALL_PRIVILEGES:
            return { ...state, rolePrivilage: action.payload }
        case Types.GET_ALL_ROLES:
            return { ...state, allRoles: action.payload }
        case Types.GET_ALL_PRIVILIGES:
            return { ...state, allPrivileges: action.payload }
        case Types.GET_PRIVILIGES_ASSIGNED_TO_GRP:
            return { ...state, assignedPrivileges: action.payload }
        case Types.UPDATE_TABPANEL_VALUE:
            return { ...state, tabPanelValue: action.payload }
        case Types.UPDATE_ROLE_NAME:
            return { ...state, roleNameHeader: action.payload }
        case Types.GET_VALIDATE_ROLE:
            return { ...state, validateRole: action.payload }
        case Types.UPDATE_CREATEROLE_PAYLOAD:
            return { ...state, newRole: action.payload }
        case Types.GET_PRIVILEGES_CREATE_ROLE:
            return { ...state, newPrivileges: action.payload }
        case Types.CREATE_ACTION_TYPE:
            return { ...state, createActionType: action.payload }
        case Types.GET_USERS_WITH_SAMEROLE:
            return { ...state, usersWithSameRole: action.payload }
        case Types.UPDATE_ROLE_INFO:
            return { ...state, RoleInFo: action.payload }

        default:
            return { ...state }
    }
}