import * as React from "react";
import { useDispatch } from 'react-redux';
import { getAllPrivilegesAssignedToGrp } from './actions/actions';
import RolesDashboard from './RolesDashBoard';
import './Styles/Styles.scss'
import { useTranslation } from 'react-i18next';

export default function Roles() {

  const { t } = useTranslation();

  const dispatch = useDispatch()
  const loaded = React.useRef(false);
  React.useEffect(() => {
    if (!loaded.current) {
      dispatch(getAllPrivilegesAssignedToGrp());
      loaded.current = true
    }
  }, [dispatch])

  return (
    <React.Fragment>
      <h2>{t("Roles")}</h2>
      <RolesDashboard />
    </React.Fragment>
  );
}
