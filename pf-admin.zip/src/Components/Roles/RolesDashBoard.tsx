import * as React from "react";
import Tab from "@mui/material/Tab";
import Box from "@mui/material/Box";
import { useDispatch, useSelector } from 'react-redux';
import CustomDialog from '../../Common/modals/CustomDialog';
import CreateRole from './components/CreateRole';
import PriviligesData from './components/PriviligesData';
import {
  fetchAssignedRolePrivileges, getCreateRole,
  getUpdateRole, assignPrivilegesToRole,
  getAllUsersWithSameRole,
} from './actions/actions';
import { Types } from './Constants/Types'
import _ from 'lodash'
import { Confirm, currentUser, toastAlert } from '../../actions/actions'
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import { privilegeGroup, SelectedPrivileges } from './Constants/Interfaces';
import CommonCard from "../../Common/CommonCard";
import { messages } from "../../configs/messages";
import { useTranslation } from 'react-i18next';
import { RoleInFo as RoleInFoModal } from "./Constants/Models";
import { toastMsg } from "../../Common/Messages";
import AddIcon from '@mui/icons-material/Add';


function RolesDashboard() {

  const { t } = useTranslation();
  const dispatch = useDispatch()
  const { allRoles, assignedPrivileges, validateRole, newRole, allPrivileges, roleNameHeader,
    newPrivileges, createActionType, tabPanelValue, RoleInFo } = useSelector((state: any) => state.roles);
  const [open, setOpen] = React.useState(false);
  const [tabConextValue, setTabConextValue] = React.useState(tabPanelValue);
  const [btnState, setBtnState] = React.useState(true)
  const { user } = useSelector((state: any) => state.app);
  const [setPrivilegeMsg] = React.useState('Please select atleast one Privilege')
  const loaded = React.useRef(false);

  React.useEffect(() => {
    // if (!loaded.current) {
    setTabConextValue(tabPanelValue);
    loaded.current = true
    // }
  }, [tabPanelValue])

  const handleChange = (event: React.SyntheticEvent, newValue: any) => {
    dispatch(fetchAssignedRolePrivileges(newValue))
    const role = allRoles.find((ele: any) => (ele.id) === parseInt(newValue));
    dispatch({ type: Types.UPDATE_ROLE_NAME, payload: role });
    dispatch({ type: Types.UPDATE_TABPANEL_VALUE, payload: newValue.toString() });
    setTabConextValue(newValue.toString());
  };

  const onCreateRoleHandler = () => {
    dispatch(fetchAssignedRolePrivileges(0, (response: any) => {
      dispatch({ type: Types.GET_PRIVILEGES_CREATE_ROLE, payload: response.data.privilegeGroups })
      dispatch({ type: Types.UPDATE_ROLE_INFO, payload: RoleInFoModal })
      setOpen(true);
    }))
  }
  const onCloseCreateRole = () => {
    setOpen(false);
    dispatch({ type: Types.GET_PRIVILEGES_CREATE_ROLE, payload: _.cloneDeep(allPrivileges) })
    dispatch({ type: Types.GET_VALIDATE_ROLE, payload: { ...validateRole, privilegesSelected: false, roleName: false, roleNameExist: false } })
    dispatch({
      type: Types.UPDATE_CREATEROLE_PAYLOAD, payload: {
        roleName: '',
        privilegesAssigned: { groupId: 0, privilegeGroups: [], privileges: [], role: null }
      }
    })
    dispatch({ type: Types.CREATE_ACTION_TYPE, payload: true })
    const _currentRole = allRoles.find((item: any) => item.id === parseInt(tabConextValue))
    dispatch({ type: Types.UPDATE_ROLE_INFO, payload: _currentRole })
    setBtnState(true)
  }
  const renderPayload = (newPrivileges: any) => {
    const payload: SelectedPrivileges[] = []
    const _privileges = _.cloneDeep(newPrivileges)
    _privileges && _privileges.map((item: any) => {
      const _array: privilegeGroup[] = []
      let _privilegeSelected = false
      item && item.privileges.map((privilege: any) => {
        if ((privilege.status) || (privilege.defaultSelected && !privilege.status)) {
          _privilegeSelected = true
          privilege.groupLevelStatus = true
          const _obj: privilegeGroup = { ...privilege }
          _array.push(_obj)
        }
        return null
      })
      if (_privilegeSelected) {
        const _payload: SelectedPrivileges = { privilegeGroup: item.privilegeGroup, privileges: _array, privilegeNames: [] }
        payload.push(_payload)
      }
      return null
    })
    return payload
  }

  const onSubmitHandler = () => {
    if (newRole && newRole.roleName && newRole.roleName !== '') {
      const _allRoles = _.cloneDeep(allRoles)
      const _duplicateRole = _allRoles && _allRoles.length > 0 && _allRoles.findIndex((ele: any) => ele.name.toLowerCase() === newRole.roleName.toLowerCase())
      if (_duplicateRole === -1 || (!createActionType && (newRole.roleName.toLowerCase() === roleNameHeader.name.toLowerCase()))) {
        const payload = renderPayload(newPrivileges)

        if (payload && payload.length > 0) {
          const _privilegesAssigned = { ...newRole.privilegesAssigned, privilegeGroups: payload }
          const selected: any = []
          _privilegesAssigned?.privilegeGroups.map((item: any) => {
            item.privileges.map((priv: any) => {
              selected.push(priv.status)
              return null
            })
            return null
          })
          const allAreFalse = (selected: any) => {
            return selected.every((e: any) => e === false);
          }

          if (allAreFalse(selected) !== true) {
            const params = {
              role: { ...RoleInFo, name: newRole.roleName },
              privilegesAssigned: _privilegesAssigned
            }
            delete params.privilegesAssigned.groupId
            delete params.privilegesAssigned.privileges
            dispatch((createActionType ? getCreateRole : getUpdateRole)(params, (_response: any) => {
              if (_response.data.errorMessage) {
                dispatch(toastAlert({
                  status: 0,
                  message: _response.data.errorMessage,
                  open: true,
                }))
              } else {
                onCloseCreateRole()
                dispatch(currentUser())
                params.privilegesAssigned.role = _response.data
                console.log('132....', _response.data)
                dispatch(assignPrivilegesToRole(params.privilegesAssigned, (assignResponse:any) => {
                  if(assignResponse?.data?.errorMessage)
                  dispatch(toastAlert({
                    status: assignResponse?.data?.errorMessage ? 0 : 1,
                    message: assignResponse?.data?.errorMessage ? assignResponse?.data?.errorMessage : toastMsg(createActionType ? messages.roles.createRole : messages.roles.updateRole, params.role.name),
                    open: true,
                  }))
                  dispatch({ type: Types.CREATE_ACTION_TYPE, payload: true });
                }))
              }
            }))
          } else {
            // setPrivilegeMsg('')
            dispatch({ type: Types.GET_VALIDATE_ROLE, payload: { ...validateRole, privilegesSelected: true } })
          }
        }
        else {
          dispatch({ type: Types.GET_VALIDATE_ROLE, payload: { ...validateRole, privilegesSelected: true } })
        }
      } else {
        dispatch({ type: Types.GET_VALIDATE_ROLE, payload: { ...validateRole, roleNameExist: true } })
      }
    } else {
      dispatch({ type: Types.GET_VALIDATE_ROLE, payload: { ...validateRole, roleName: true } })
    }
  }
  const onDeleteRole = () => {
    dispatch(Confirm({
      status: 0,
      message: messages.roles.RoleDeleted,
      onOk: () => {
        dispatch(getAllUsersWithSameRole(roleNameHeader.id,
          //  (callback: any) => {
          // if (callback && callback.data && callback.data.length > 0) {
          // }
          // }
        ))
      }
    }))
  }
  const onEditRoleHandler = () => {
    const _payload = { ...newRole, roleName: roleNameHeader.name, privilegesAssigned: { ...newRole.privilegesAssigned, role: roleNameHeader } }
    dispatch({ type: Types.UPDATE_CREATEROLE_PAYLOAD, payload: _payload })
    dispatch({ type: Types.GET_PRIVILEGES_CREATE_ROLE, payload: _.cloneDeep(assignedPrivileges) })
    dispatch({ type: Types.CREATE_ACTION_TYPE, payload: false })
    setOpen(true)
    setBtnState(true)
  }

  return (
    <React.Fragment>
      <CustomDialog
        title={createActionType ? `${t("Create Role")}` : `${t("Update Role")}`}
        onClose={onCloseCreateRole}
        onSubmitHandler={() => onSubmitHandler()}
        open={open}
        maxWidth="md"
        form="createRole"
        className="create-dy-field"
        // disabled={false}
        disabled={btnState}
        actionType={createActionType ? "Submit" : 'Update'}
      >
        {user?.userRolePrivileges?.data?.CreateRolesandPrivileges && <CreateRole
          allPrivileges={newPrivileges}
          setBtnState={setBtnState}
          btnState={btnState}
          setPrivilegeMsg={setPrivilegeMsg}
        />}
      </CustomDialog>

      {user?.userRolePrivileges?.data?.CreateRolesandPrivileges && <div className="d-flex justify-content-end">
        <a href="# " onClick={onCreateRoleHandler} className='e-btn-outline'>
          <AddIcon sx={{ fontSize: 20 }} />
          <span>{t("Create Role")}</span></a>
      </div>}

      <CommonCard title='Role'>
        <div className="RolesDashboard">
          <div className='d-flex justify-content-between mx-3'>
            <h6>{t("All Roles")}</h6>
          </div>
          <hr className="m-0"></hr>
          <React.Fragment>
            <Box className="tab-container">
              {tabConextValue && <TabContext value={tabConextValue}>
                <Box sx={{ width: 300, height: 350, overflowY: 'auto' }} className="left-panel">
                  <TabList
                    variant="scrollable"
                    onChange={handleChange}
                    orientation='vertical'
                    aria-label="lab API tabs example">

                    {allRoles && allRoles.map((tab: any, index: number) => {
                      return (
                        <Tab key={index} id={`${tab.id}`}
                          label={
                            <span className="d-flex">
                              <span className="pi pi-angle-double-right pe-2">
                              </span><p className="m-0 text" >{tab.name}</p>
                            </span>} value={`${tab.id}`}
                        />
                      )
                    })}
                  </TabList>
                </Box>
                <TabPanel style={{ padding: 0, display: 'inline-block', width: '100%', height: 350 }} value={tabConextValue}>
                  <PriviligesData
                    assignedPrivileges={assignedPrivileges}
                    onEditRoleHandler={onEditRoleHandler}
                    onDeleteRole={onDeleteRole}
                  />
                </TabPanel>
              </TabContext>}
            </Box>
          </React.Fragment>
        </div>
      </CommonCard>
    </React.Fragment>
  )
}

export default RolesDashboard;