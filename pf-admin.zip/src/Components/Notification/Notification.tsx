import React from 'react'
import {
  StompSessionProvider,
  useSubscription,
} from "react-stomp-hooks";
import { Types } from '../../Constants/Types';
import { useDispatch, useSelector } from 'react-redux';
import { requests } from '../../configs/env';


function Notification() {

  const url = requests.pushNotification.webSocketNotify
  return (
    <div>
      <StompSessionProvider
        url={url}
      //All options supported by @stomp/stompjs can be used here
      >
        <SubscribingComponent />
      </StompSessionProvider>
    </div >
  )
}

function SubscribingComponent() {
  const dispatch = useDispatch()
  // const [notificationArray, setNotificationArray] = React.useState([])
  const { user, notificationsData } = useSelector((state: any) => state.app)
  useSubscription(`/notifications/${user.userName}`, (message: any) => {
    const _notificationArray: any = [...[], ...notificationsData];
    const id = message.body.slice(message.body.indexOf(',')).match(/(\d+)/)
    if (id?.length > 0) {
      _notificationArray.unshift({
        notifications: message.body.slice(0, message.body.indexOf(',')),
        id: id[0]
      })
    }

    // setNotificationArray(_notificationArray)
    dispatch({ type: Types.FETCH_STUDY_NOTIFICATIONS, payload: _notificationArray })
  });
  return <div></div>

}


export default Notification