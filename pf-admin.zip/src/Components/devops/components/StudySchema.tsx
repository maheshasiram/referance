import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { validateSchemas, validateTables } from '../actions/actions';
import { Types } from '../reducer/Types';
import CancelOutlinedIcon from '@mui/icons-material/CancelOutlined';
import TaskAltOutlinedIcon from '@mui/icons-material/TaskAltOutlined';
import CustomizedTooltip from '../../../Common/CustomizedTooltip/CustomizedTooltip';


function StudySchema(props: any) {
    const { provisionerDetails, enivornmentStatus } = useSelector((state: any) => state.devops);
    const { user, allConFigData } = useSelector((state: any) => state.app);
    const { viewStudyDetails } = useSelector((state: any) => state.study);
    const [validateSchema, setValidateSchema] = useState(false);
    const [schemaStatus, setSchemaStatus] = useState<any>(null);

    const dispatch = useDispatch()

    React.useEffect(() => {
        if (!provisionerDetails?.region?.id) { dispatch({ type: Types.SET_ENIVORNMENT_STATUS, payload: {} }) }
    }, [dispatch, provisionerDetails?.region?.id])

    const onValidateSchemaHandler = () => {
        const validate = props.validateForm(provisionerDetails)
        dispatch({ type: Types.SET_ENIVORNMENT_STATUS, payload: null });
        const _schemaPayload = { dev: provisionerDetails?.devSchema?.replace(/[^a-zA-Z0-9_ ]/g, "").toLowerCase(), uat: provisionerDetails?.uatSchema?.replace(/[^a-zA-Z0-9_ ]/g, "").toLowerCase(), prod: provisionerDetails?.prodSchema?.replace(/[^a-zA-Z0-9_ ]/g, "").toLowerCase() }

        if (validate) {
            dispatch((user?.userRolePrivileges?.data?.Provisioner ? validateSchemas : validateTables)(provisionerDetails.dbDetailsId, _schemaPayload, (_response: any) => {
                if (_response.dev && _response.uat && _response.prod) {
                    props.setButtonDisable(false)
                }
                setSchemaStatus(_response);
                setValidateSchema(true);
            }));
        }
    }

    return (
        <React.Fragment>
            <div className='d-flex justify-content-between align-items-center mx-4'>
                <div><h6>Study Schema</h6></div>
                {(((!schemaStatus && !enivornmentStatus?.initiated) || user?.userRolePrivileges?.data?.DevopsApprover) && viewStudyDetails?.approvalStatus?.code !== allConFigData?.Bookmarked) && <button
                    // className="btn-eprimary btn-disabled"
                    className={((!enivornmentStatus?.initiated && user?.userRolePrivileges?.data?.Provisioner) || user?.userRolePrivileges?.data?.DevopsApprover) ? "btn-eprimary" : "btn-esecondary btn-disabled"}
                    type="button"
                    onClick={onValidateSchemaHandler}
                // disabled={((!enivornmentStatus?.initiated && user?.userRolePrivileges?.data?.Provisioner) || user?.userRolePrivileges?.data?.DevopsApprover || schemaStatus) ? false : true}
                >
                    Validate Schema
                </button>}
            </div>
            <hr className='my-0 mx-3'></hr>
            <table className='devops-schema-tables mx-4'>
                <thead>
                    <tr>
                        <th>Environment</th>
                        <th>Schemas</th>
                        <th>Availability</th>
                        {user?.userRolePrivileges?.data?.Provisioner && <th>Created</th>}
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>DEV</td>
                        <td>{user?.userRolePrivileges?.data?.DevopsApprover ? <span className='label-data-div ms-3'>{provisionerDetails?.devSchema?.replace(/[^a-zA-Z0-9_ ]/g, "").toLowerCase()}</span> :
                            <span>{!(provisionerDetails?.domain) ? "" : provisionerDetails?.devSchema?.replace(/[^a-zA-Z0-9_ ]/g, "").toLowerCase()} </span>
                        }</td>
                        <td className='availability-status'>
                            {validateSchema &&
                                <span >
                                    {schemaStatus?.dev === false &&
                                        <CustomizedTooltip title={user?.userRolePrivileges?.data?.Provisioner ? 'Duplicate Schema' : 'Schema Not Created'} >
                                            <CancelOutlinedIcon style={{ color: 'red' }} />
                                        </CustomizedTooltip>}
                                </span>
                            }
                            {(((enivornmentStatus?.initiated && user?.userRolePrivileges?.data?.Provisioner) || schemaStatus?.dev) || viewStudyDetails?.approvalStatus?.code === allConFigData?.Bookmarked) &&
                                <CustomizedTooltip title={'Schema Validated Successfully'} >
                                    <TaskAltOutlinedIcon style={{ color: 'green' }} />
                                </CustomizedTooltip>
                            }
                        </td>
                        {user?.userRolePrivileges?.data?.Provisioner &&
                            <td className='created-status'>
                                {(enivornmentStatus?.initiated && !enivornmentStatus?.dev && !enivornmentStatus.failed) && `Pending`}
                                {enivornmentStatus && enivornmentStatus.failed && <CustomizedTooltip title={'Failed to create schema'} >
                                    <CancelOutlinedIcon style={{ color: 'red' }} />
                                </CustomizedTooltip>}
                                {((enivornmentStatus && enivornmentStatus.dev && user?.userRolePrivileges?.data?.Provisioner) ||
                                    (enivornmentStatus?.dev && schemaStatus?.dev)) && <CustomizedTooltip title={'Schema Cretaed Successfully'} >
                                        <TaskAltOutlinedIcon style={{ color: 'green' }} />
                                    </CustomizedTooltip>}
                            </td>}
                    </tr>
                    <tr>
                        <td>UAT</td>
                        <td>{user?.userRolePrivileges?.data?.DevopsApprover ?
                            <span className='label-data-div ms-3'>{provisionerDetails.uatSchema}</span> :
                            <span>{!(provisionerDetails?.domain) ? "" : provisionerDetails?.uatSchema?.replace(/[^a-zA-Z0-9_ ]/g, "").toLowerCase()} </span>
                        }</td>
                        <td className='availability-status'>
                            {validateSchema &&
                                <span>
                                    {!schemaStatus?.uat &&
                                        <CustomizedTooltip title={user?.userRolePrivileges?.data?.Provisioner ? 'Duplicate Schema' : 'Schema Not Created'} >
                                            <CancelOutlinedIcon style={{ color: 'red' }} />
                                        </CustomizedTooltip>}
                                </span>
                            }
                            {(((user?.userRolePrivileges?.data?.Provisioner && enivornmentStatus?.initiated) || schemaStatus?.uat) || viewStudyDetails?.approvalStatus?.code === allConFigData?.Bookmarked) &&
                                <CustomizedTooltip title={'Schema Validated Successfully'} >
                                    <TaskAltOutlinedIcon style={{ color: 'green' }} />
                                </CustomizedTooltip>
                            }
                        </td>
                        {user?.userRolePrivileges?.data?.Provisioner && <td className='created-status'>
                            {enivornmentStatus?.initiated && !enivornmentStatus?.uat && !enivornmentStatus.failed && `Pending`}
                            {enivornmentStatus && enivornmentStatus.failed && <CustomizedTooltip title={'Failed to create schema'} >
                                <CancelOutlinedIcon style={{ color: 'red' }} />
                            </CustomizedTooltip>}
                            {((user?.userRolePrivileges?.data?.Provisioner && enivornmentStatus?.uat) || (enivornmentStatus?.uat && schemaStatus?.uat)) && <CustomizedTooltip title={'Schema Cretaed Successfully'} >
                                <TaskAltOutlinedIcon style={{ color: 'green' }} />
                            </CustomizedTooltip>}
                        </td>}
                    </tr>
                    <tr>
                        <td>PROD</td>
                        <td>{user?.userRolePrivileges?.data?.DevopsApprover ?
                            <span className='label-data-div ms-3'>{provisionerDetails.prodSchema}</span> :
                            <span>{!(provisionerDetails?.domain) ? "" : provisionerDetails?.prodSchema?.replace(/[^a-zA-Z0-9_ ]/g, "").toLowerCase()} </span>
                        }</td>
                        <td className='availability-status'>
                            {validateSchema &&
                                <span>
                                    {schemaStatus?.prod === false &&
                                        <CustomizedTooltip title={user?.userRolePrivileges?.data?.Provisioner ? 'Duplicate Schema' : 'Schema Not Created'} >
                                            <CancelOutlinedIcon style={{ color: 'red' }} />
                                        </CustomizedTooltip>}
                                </span>}
                            {(((enivornmentStatus?.initiated && user?.userRolePrivileges?.data?.Provisioner) || schemaStatus?.prod) || viewStudyDetails?.approvalStatus?.code === allConFigData?.Bookmarked) &&
                                <CustomizedTooltip title={'Schema Validated Successfully'} >
                                    <TaskAltOutlinedIcon style={{ color: 'green' }} />
                                </CustomizedTooltip>
                            }
                        </td>
                        {user?.userRolePrivileges?.data?.Provisioner && <td className='created-status'>
                            {enivornmentStatus?.initiated && !enivornmentStatus?.prod && !enivornmentStatus.failed && `Pending`}
                            {enivornmentStatus?.failed && <CustomizedTooltip title={'Failed to create schema'} >
                                <CancelOutlinedIcon style={{ color: 'red' }} />
                            </CustomizedTooltip>}
                            {((enivornmentStatus?.prod && user?.userRolePrivileges?.data?.Provisioner) || (enivornmentStatus?.prod && schemaStatus?.Prod)) && <CustomizedTooltip title={'Schema Cretaed Successfully'} >
                                <TaskAltOutlinedIcon style={{ color: 'green' }} />
                            </CustomizedTooltip>}
                        </td>}
                    </tr>
                </tbody>
            </table>

        </React.Fragment >
    )
}
export default StudySchema;