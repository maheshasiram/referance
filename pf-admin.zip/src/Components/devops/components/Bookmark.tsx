import React from 'react'
import { useSelector } from 'react-redux';

function Bookmark() {
    const { provisionerDetails } = useSelector((state: any) => state.devops)
    
    return (
        <React.Fragment>
            <div className='d-flex justify-content-between align-items-center mx-4'>
                <h6>Bookmark</h6>
            </div>

            <hr className='my-0 mx-3'></hr>
            <div className='mx-3 bodylabdata mt-3 form-group label-data-div'>
                <span className='labelStyle '>Study Url : <a href="orgShortName.inductivequotient.com">{provisionerDetails.studyUrl}</a></span>
            </div>
        </React.Fragment>
    )
}
export default Bookmark;