import { useSelector } from 'react-redux';
import React from 'react'

function Solutions() {
    const { viewStudyDetails } = useSelector((state: any) => state.study);
    return (
        <React.Fragment>
            <div className='d-flex justify-content-between align-items-center mx-4'>
                <h6> Application Tools</h6>
            </div>
            <hr className='my-1 mx-3'></hr>
            <div className='w-100 m-3 bodylabdata'>
                <div className='row'>
                    {viewStudyDetails && viewStudyDetails.solutions.map((solutionData: any ,index:number) => {
                        return (
                            <div className='label-data-div col-sm-3' key={index}>
                                <span className=''>{solutionData?.name}</span><span className='ms-2'></span>
                            </div>
                        )
                    })}
                </div>
            </div>
          {viewStudyDetails?.edcSolutions.length > 0 &&  <div className='ms-4'>
                <h6> EDC Modules:</h6>
            </div>}
            <hr className='my-0 mx-3'></hr>
            <div className='w-100 m-3 bodylabdata'>
                <div className='row'>
                    {viewStudyDetails?.edcSolutions.map((e: any ,index:number) => {
                        return (
                            <div className='label-data-div col-sm-3' key={index}>
                                <span className=''>{e.name}</span><span className='ms-2'></span>
                            </div>
                        )
                    })}
                </div>
            </div>
        </React.Fragment>
    )
}
export default Solutions;
