import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { Types } from "../reducer/Types";
import { Types as viewStudy } from "../../Studies/reducer/Types";
import _ from 'lodash';

function Comments() {
    const dispatch = useDispatch();
    const { approveRejectStudy } = useSelector((state: any) => state.devops);
    const { viewStudyDetails } = useSelector((state: any) => state.study);

    return (
        <React.Fragment>
            <div className='d-flex ms-4'>
                <h6>Comments</h6>
            </div>
            <hr className='my-0 mx-3'></hr>
            {/* <div className="d-flex justify-content-between align-items-end"> */}
            <div className="col-sm-4 mx-3 bodylabdata mt-3 form-group label-data-div">
                <span className='labelStyle '>Comments :</span>
                <textarea
                    className="form-control"
                    value={viewStudyDetails.comments}
                    onChange={(e: any) => {
                        if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
                            // const payload = _.cloneDeep(approveRejectStudy);
                            const payload = _.cloneDeep(viewStudyDetails);
                            const _payload = _.cloneDeep(approveRejectStudy)
                            _payload.comments = e.target.value
                            payload.comments = e.target.value;
                            dispatch({ type: Types.APPROVE_REJECT_STUDY, payload: _payload });
                            dispatch({ type: viewStudy.VIEW_STUDY_DETAILS, payload: payload });
                            // if (
                            //     user?.userRolePrivileges?.data?.Provisioner
                            // ) {
                            //     dispatch({ type: Types.APPROVE_REJECT_STUDY, payload: payload });
                            // }
                            // else if (user?.userRolePrivileges?.data?.DevopsApprover) {
                            //     payload.comments = e.target.value;
                            //     dispatch({ type: Types.APPROVE_REJECT_STUDY, payload: payload });
                            // }
                        }
                    }}
                />

            </div>
        </React.Fragment>
    )
}
export default Comments;