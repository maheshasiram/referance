import React from 'react'
import { useSelector } from 'react-redux';
// import ZoomInIcon from '@mui/icons-material/ZoomIn'

function StudyAdmin() {
    const { viewStudyDetails } = useSelector((state: any) => state.study);

    return (
        <React.Fragment>
            <div className='d-flex justify-content-between align-items-center mx-4'>
                <div><h6>Study Admin</h6></div>
                {/* <button className='btn-eprimary ms-1'>Validate</button> */}
            </div>
            <hr className='my-0 mx-3'></hr>
            <div className='study-admin'>
                <div className="row my-3 mx-3">
                    {
                        viewStudyDetails && viewStudyDetails.studyContacts.map((e: any, index:number) => {
                            return (
                                <React.Fragment key={index}>
                                    <div className='col-sm-4 form-group'>
                                        <label className='active'>{index === 0  ? "Primary ":"Secondary"}</label>
                                    </div>
                                    <div className='w-100 m-2 bodylabdata'>
                                        <div className='create-contact d-flex flex-wrap'>
                                            <div className='label-container'>
                                                <div className='label-data-div'>
                                                    {/* <span className='labelStyle'> User Id </span>: <span className='ms-1'>{e.id}</span> */}
                                                    <span className='labelStyle'> User Name </span>: <span className='ms-1'>{e.userName}</span>
                                                </div>
                                            </div>
                                            <div className='label-container'>
                                                <div className='label-data-div'>
                                                    <span className='labelStyle'> First Name </span>: <span className='ms-1'>{e.firstName}</span>
                                                </div>
                                            </div>
                                            <div className='label-container'>
                                                <div className='label-data-div'>
                                                    <span className='labelStyle'>Last Name</span>: <span className='ms-1'>{e.lastName}</span>
                                                </div>
                                            </div>
                                            <div className='label-container'>
                                                <div className='label-data-div'>
                                                    <span className='labelStyle'> Email</span>: <span className='ms-1'>{e.email}</span>
                                                </div>
                                            </div>
                                            <div className='label-container'>
                                                <div className='label-data-div'>
                                                    <span className='labelStyle'> Phone No</span>: <span className='ms-1'>{e.phoneNo}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </React.Fragment>
                            )
                        })
                    }
                </div>
            </div>
            {/* <div className='ms-4'>
                <h6> EDC Modules:</h6>
            </div>
            <hr className='my-0 mx-3'></hr>
           
            <div className='w-100 m-3 bodylabdata'>
                <div className='row'>
                    {viewStudyDetails?.edcSolutions.map((e: any) => {
                        return (
                            <div className='label-data-div col-sm-3'>
                                <span className=''>{e.name}</span><span className='ms-1'></span>
                            </div>
                        )
                    })}
                </div>
            </div> */}
        </React.Fragment>
    )
}
export default StudyAdmin;