import React from 'react';
import { useSelector } from 'react-redux';


function StudyDetails() {
    const { viewStudyDetails } = useSelector((state: any) => state.study);
    React.useEffect(()=>{
        viewStudyDetails.studySchema = ''
    },[viewStudyDetails])

    return (
        <React.Fragment>
            <div className='d-flex justify-content-between align-items-center mx-4'>
                <div><h6>Study Details</h6></div>
            </div>
                <hr className='my-0 mx-3'></hr>
            <div className='AapproveStudy'>
                <div className='w-100 m-3 bodylabdata'>
                    <div className='row'>
                        <div className='col-sm-6'>
                            {/* <div className='label-data-div'>
                                <span className='rightlabelStyle'>Study Name </span>: <span className='ms-2'>{devOps.studyDeatils.studyName}</span>
                            </div> */}
                            <div className='label-data-div'>
                                <span className='rightlabelStyle'>Protocol ID</span> :<span className='ms-2'>{viewStudyDetails.protocolId}</span>
                            </div>
                            <div className='label-data-div'>
                                <span className='rightlabelStyle'>Protocol Title</span>:<span className='ms-2'>{viewStudyDetails.studyName} </span>
                            </div>
                            <div className='label-data-div'>
                                <span className='rightlabelStyle'>Therapeutic Area</span> :<span className='ms-2'>{viewStudyDetails.therapeuticArea.name}</span>
                            </div>
                            <div className='label-data-div'>
                                <span className='rightlabelStyle'>Indication</span>: <span className='ms-2'>{viewStudyDetails.indication?.name}</span>
                            </div>
                            <div className='label-data-div'>
                                <span className='rightlabelStyle'>Study Design</span>: <span className='ms-2'>{viewStudyDetails?.studyDesign?.name}</span>
                            </div>
                            <div className='label-data-div '>
                                <span className='rightlabelStyle'>Study Phase</span>: <span className='ms-2'>{viewStudyDetails?.ctPhase?.name} </span>
                            </div>
                            <div className='label-data-div '>
                                <span className='rightlabelStyle'>Study Type</span>:<span className='ms-2'>{viewStudyDetails?.studyType?.name} </span>
                            </div>
                        </div>
                        <div className='col-sm-6'>

                            <div className='label-data-div w-100'>
                                <span className='rightlabelStyle'>Regulatory</span> :<span className='ms-2'>{viewStudyDetails?.regulatory?.name}
                                </span>
                            </div>
                            <div className='label-data-div w-100'>
                                <span className='rightlabelStyle'>Start Date</span> :<span className='ms-2'>{viewStudyDetails?.startDate}
                                </span>
                            </div>
                            <div className='label-data-div w-100'>
                                <span className='rightlabelStyle'>End Date</span> :<span className='ms-2'>{viewStudyDetails?.endDate}
                                </span>
                            </div>
                            <div className='label-data-div w-100'>
                                <span className='rightlabelStyle'>Sponser</span> :<span className='ms-2'>{viewStudyDetails?.organization?.orgName}
                                </span>
                            </div><div className='label-data-div w-100'>
                                <span className='rightlabelStyle'>Approver</span> :<span className='ms-2'>{viewStudyDetails?.approver?.userName}
                                </span>
                            </div>
                            {/* <div className='label-data-div w-100'>
                                <span className='rightlabelStyle'>Organization Passcode</span> :<span className='ms-2'>{viewStudyDetails.organization.passcode}
                                </span>
                            </div>
                            <div className='label-data-div w-100'>
                                <span className='rightlabelStyle'>Study Passcode</span> :<span className='ms-2'>{devOps.studyPasscode}
                                </span>
                            </div> */}
                            <div className='label-data-div w-100'>
                                <span className='rightlabelStyle'>Organization Short Name</span> :<span className='ms-2'>{viewStudyDetails.organization.orgShortname}
                                </span>
                            </div>
                            <div className='label-data-div w-100'>
                                <span className='rightlabelStyle'>Study Requestor</span> :<span className='ms-2'>{viewStudyDetails.studyRequestor.name}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </React.Fragment>
    )
}
export default StudyDetails;