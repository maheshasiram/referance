import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Types } from '../reducer/Types';
import { getRegionDetails } from '../actions/actions';


function Deployment(props: any) {
    const dispatch = useDispatch();
    const loaded = React.useRef(false);
    const { provisionerDetails, regionData } = useSelector((state: any) => state.devops)
    const { viewStudyDetails } = useSelector((state: any) => state.study);
    const { user, allConFigData } = useSelector((state: any) => state.app);
    const { error, setError } = props;


    useEffect(() => {
        if (!loaded.current) {
            dispatch(getRegionDetails());
            loaded.current = true
        }
    }, [viewStudyDetails, dispatch])

    const onSelectChange = (e: any) => {
        const _provisionerDetails = { ...{}, ...provisionerDetails }
        const _region = regionData && regionData.region.find((i: any) => i.dbDetailsId === parseInt(e.target.value));
        _provisionerDetails.dbDetailsId = _region.dbDetailsId;
        _provisionerDetails.regionCode = _region ? _region.code : null;
        dispatch({ type: Types.GET_PROVISIONER_DETAILS, payload: _provisionerDetails });
        setError({ ...error, region: e.target.value ? false : true });
    }

    const GravityUrlChange = (e: any) => {
        const _provisionerDetails = { ...{}, ...provisionerDetails, gravityUrl: e.target.value }
        dispatch({ type: Types.GET_PROVISIONER_DETAILS, payload: _provisionerDetails })
        setError({ ...error, edcUrl: e.target.value ? false : true })
    }

    return (
        <React.Fragment>
            <div className='d-flex justify-content-between align-items-center mx-4'>
                <div><h6>Deployment</h6></div>
            </div>
            <hr className='mx-3 my-0'></hr>
            <div className='AapproveStudy'>
                <div className='w-100 mt-3 ms-2 bodylabdata'>
                    <div className='row'>
                        <div className='col-sm-3 form-group'>
                            <label >Region :</label>
                            <div className=''>
                                {/* {user?.userRolePrivileges?.data?.DevopsApprover ? <span className='label-data-div'>{provisionerDetails?.region?.name}</span> : */}
                                <div>
                                    <select className='form-select form-control' placeholder='Select Region'
                                        name="name"
                                        disabled={user?.userRolePrivileges?.data?.DevopsApprover || viewStudyDetails?.approvalStatus?.code === allConFigData?.provisioned}
                                        value={provisionerDetails?.dbDetailsId}
                                        onChange={(e) => onSelectChange(e)}
                                    >
                                        <option value={''}>Select Region</option>
                                        {
                                            regionData && regionData.region?.map((item: any) => (
                                                <option key={item.id} value={item.dbDetailsId}>{item.regionName}</option>
                                            ))
                                        }
                                    </select>
                                </div>
                                {/* } */}
                            </div>
                            {error.region && <span className='text-danger'>Please Select the Region</span>}
                        </div>

                        <div className='col-sm-3 form-group'>
                            <label>EDC Gravity URL : </label>
                            <input className=' form-control'
                                name="gravityUrl"
                                onChange={GravityUrlChange}
                                value={provisionerDetails.gravityUrl}
                                disabled={user?.userRolePrivileges?.data?.DevopsApprover || viewStudyDetails?.approvalStatus?.code === allConFigData?.provisioned}
                            ></input>
                            {error.edcUrl ? <span className='text-danger'>Please Fill the EDC Gravity URL</span> : <span>&nbsp;</span>}

                        </div>

                        <div className='col-sm-3 form-group '>
                            <div className='d-flex justify-content-between mt -1 pb-1'>
                                <label >Sub Domain :</label>
                                {user?.userRolePrivileges?.data?.DevopsApprover ? <span></span> : <a href='# ' className='study-url'>{!(provisionerDetails?.domain) ? "" : provisionerDetails.studyUrl}</a>}
                            </div>
                            <div className=''>
                                {user?.userRolePrivileges?.data?.DevopsApprover ? <span className='label-data-div'>{provisionerDetails?.domain}</span> :
                                    <div>
                                        <input type="text" name="subDomain" className=' form-control'
                                            value={viewStudyDetails.organization.orgShortname?.replace(/[^a-zA-Z0-9_ ]/g, "")}
                                            disabled={true} />
                                        {error.subDomain ? <span className='text-danger'>Please Enter Sub Domain</span> : <span>&nbsp;</span>}
                                    </div>
                                }
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </React.Fragment>
    )
}
export default Deployment;