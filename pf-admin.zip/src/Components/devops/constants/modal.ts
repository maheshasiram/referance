export const devopsModal = {

    studyDeatils: {
        studyName: "Clians",
        protocolId: "Ag946-c-001",
        sponsor: "Apollo1",
        studyType: "",
        studyPhase: "",
        startDate: "2022-01-01",
        endDate: "2022-02-02",
        approver: "Xyz",
        therapeuticArea: "",
        indications: "",
        studyPhases: "",
        studyDesign: "",
        regulatoryType: ""
    },
    orgPassCode: "123123123",
    studyPasscode: "123123123",
    orgShortName: "kims",
    studiesCountInOrg: "",
    solutions: [
        "EDC", "adhoc Reports", "CDT"
    ],
    "studyAdminDetails": [
        {
            userId: "0859",
            firstName: "mahesh",
            lastName: "bhukya",
            emailId: "mbhukya@gmail.com",
            phoneNo: "7894563",
            status: "primary"
        },
        {
            userId: "0583",
            firstName: "Naveen",
            lastName: "Kumar",
            emailId: "nkumar@gmail.com",
            phoneNo: "9874564",
            status: "secondary"
        }
    ],
    region: {
        id: 1,
        name: "Religion",
    },
    bookmarkLink: "orgShortName.inductivequotient.com",
    studySchema: {
        dev: "pmrc_ag946c001_dev",
        uat: "pmrc_ag946c001_uat",
        prod: "pmrc_ag946c001_prod"
    },
    comments: ""
}

export const provisionerDetailsModal = {
    "provisionId": 0,
    "studyId": 0,
    "requestedById": 0,
    "requestedByName": "",
    "regionCode": "",
    "domain": "",
    "devSchema": "",
    "uatSchema": "",
    "prodSchema": "",
    "studyUrl": "",
    "devValidate": false,
    "uatValidate": false,
    "prodValidate": false,
    "devCreate": false,
    "uatCreate": false,
    "prodCreate": false,
    "gravityUrl": "",
    "dbDetailsId": 0
}

export const approveRejectStudyModal = {
    "devOpsProvisionerId": 0,
    "approvedById": 0,
    "primaryStudyAdminStatus": true,
    "secondaryStudyAdminStatus": true,
    "devStatus": true,
    "uatStatus": true,
    "prodStatus": true,
    "domainStatus": true,
    "status": true,
    "comments": "",
    "studyStatus": true,
    "gravityUrl":''
}