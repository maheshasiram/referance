import { Loader } from "../../../actions/actions"
import { requests } from "../../../configs/env"
import { fetch } from "../../../Constants/fetch"
import { devopsModal } from "../constants/modal"
import { Types } from "../reducer/Types"

export const fetchDevopsModal: any = (id: any, callback: any) => {
    const data = devopsModal
    return () => {
        if (callback) {
            callback(data)
        }
    }
}

export const validateEDCschema: any = (payload: any, callback: any) => {
    const url = `${requests.devOps.validateEdcStudySchemaExist}?devSchema=${payload.dev}&uatSchema=${payload.uat}&prodSchema=${payload.prod}`
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'POST',
            url: url,
            data: ''
        })
            .then((response) => {
                if (callback) {
                    callback(response.data)
                }
                dispatch(Loader(false));
            }).catch((error: any) => {
                console.log('error', error)
              })
    }
}

export const validateSchema: any = (payload: any, callback: any) => {
    const url = `${requests.devOps.validateEdcStudySchemaAndTables}?devSchema=${payload.dev}&uatSchema=${payload.uat}&prodSchema=${payload.prod}`
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'POST',
            url: url,
            data: ''
        })
            .then((response) => {
                if (callback) {
                    callback(response.data)
                }
                dispatch(Loader(false));
            }).catch((error: any) => {
                console.log('error', error)
              })
    }
}

export const saveProvisionerDetails: any = (payload: any, callback: any) => {
    const url = `${requests.devOps.saveProvisionerDetails}`
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'POST',
            url: url,
            data: payload
        })
            .then((response) => {
                dispatch({ type: Types.SAVE_PROVISIONER_DETAILS, payload: response.data });
                if (callback) {
                    callback(response.data)
                }
                // dispatch(Loader(false));
            })
            .catch(() => {
                // dispatch(Loader(false));
                // if (callback) { callback(err.response.data)}
            })
    }
}

export const approveOrRejectStudy: any = (payload: any, callback: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'POST',
            url: `${requests.devOps.approveOrRejectStudy}`,
            data: payload
        })
            .then((response) => {
                if (callback) {
                    callback(response.data)
                }
                dispatch(Loader(false));
            }).catch((error: any) => {
                console.log('error', error)
              })
    }
}

export const findProvisionerDetailsByStudyId: any = (studyId: number, callback: any) => {
    const url = `${requests.devOps.findProvisionerDetailsByStudyId}?studyId=${studyId}`
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'GET',
            url: url,
            data: null
        })
            .then((response) => {
                dispatch({ type: Types.GET_PROVISIONER_DETAILS, payload: response.data });
                if (callback) {
                    callback(response.data)
                }
                dispatch(Loader(false));
            }).catch((error: any) => {
                console.log('error', error)
              })
    }
}

export const createSchemaAndTables: any = (payload: any, callback: any) => {
    const url = `${requests.devOps.createSchemaAndTables}?dbDetailsId=${payload._dbDetailsId}&orgShortname=${payload._orgShortName}&protocolId=${payload._protocolId}&gravityUrl=${payload._gravityUrl}&comments=${payload._comments}&userId=${payload._userId}`
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'POST',
            url: url,
            data: null
        })
            .then((response) => {
                if (callback) {
                    callback(response.data)
                }
                //  dispatch(Loader(false));
            })
            .catch(() => {
                // dispatch(Loader(false));
                // if (callback) { callback(err.response.data)}
            })
    }
}

export const getSchemaEnvironmentStatus: any = (payload: any, callback: any) => {
    const url = `${requests.devOps.getSchemaEnvironmentStatus}?orgShortname=${payload._orgShortName}&protocolId=${payload._protocolId}`
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'GET',
            url: url,
            data: null
        })
            .then((response) => {
                dispatch({ type: Types.SET_ENIVORNMENT_STATUS, payload: response.data });
                if (callback) {
                    callback(response.data)
                }
                dispatch(Loader(false));
            })
            .catch(() => {
                // dispatch(Loader(false));
                // if (callback) { callback(err.response.data)}
            })
    }
}
export const validateSchemas: any = (regionId: number, payload: any, callback: any) => {
    const url = `${requests.devOps.validateSchemas}?devSchema=${payload.dev}&uatSchema=${payload.uat}&prodSchema=${payload.prod}&regionId=${regionId}`

    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'GET',
            url: url,
            data: ''
        })
            .then((response) => {
                if (callback) {
                    callback(response.data)
                }
                dispatch(Loader(false));
            })
            .catch(() => {
                // dispatch(Loader(false));
                // if (callback) { callback(err.response.data)}
            })
    }
}

export const validateTables: any = (regionId: number, payload: any, callback: any) => {
    const url = `${requests.devOps.validateTables}?devSchema=${payload.dev}&uatSchema=${payload.uat}&prodSchema=${payload.prod}&regionId=${regionId}`

    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'GET',
            url: url,
            data: ''
        })
            .then((response) => {
                if (callback) {
                    callback(response.data)
                }
                dispatch(Loader(false));
            })
            .catch(() => {
                // dispatch(Loader(false));
                // if (callback) { callback(err.response.data)}
            })
    }
}

// get regions data 

export const getRegionDetails: any = () => {
    const url = requests.dbDetail.getRegionDetails
    return function (dispatch: any) {
        fetch({
            method: 'GET',
            url: url
        }).then((response: any) => {
            dispatch({ type: Types.GET_REGIONS, payload: response.data })
        }).catch((error: any) => {
            console.log('error', error)
          })
    }
}

// export const fetchDbDetailsByRegion: any = (regionId: number, callback: any) => {
//     let url = `${requests.dbDetail.fetchDbDetailsByRegion}?regionId=${regionId}`

//     return function (dispatch: any) {
//         dispatch(Loader(true));
//         fetch({
//             method: 'GET',
//             url: url,
//             data: ''
//         })
//             .then((response) => {
//                 if (callback) {
//                     callback(response.data)
//                 }
//                 dispatch({type: Types.GET_DB_DETAILS_REGIONS, payload : response.data})
//                 dispatch(Loader(false));
//             })
//             .catch((err)=>{
//                 // dispatch(Loader(false));
//                 // if (callback) { callback(err.response.data)}
//             })
//     }
// }
