import React, { useEffect, useState } from "react";
import StudyDetails from "./components/StudyDetails";
import Solutions from "./components/Solutions";
import Deployment from "./components/Deployment";
import StudySchema from "./components/StudySchema";
import StudyAdmin from "./components/StudyAdmin";
import Bookmark from "./components/Bookmark";
import CommonCard from "../../Common/CommonCard";
import "./styles/styles.scss"
import Comments from "./components/Comments";
import KeyboardDoubleArrowLeftIcon from '@mui/icons-material/KeyboardDoubleArrowLeft';
import { fetchAllStudies, findstudiesByUser, findStudyDetailsById } from "../Studies/Actions/actions";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";
import { Types } from "../Studies/reducer/Types";
import { approveOrRejectStudy, createSchemaAndTables, findProvisionerDetailsByStudyId, getSchemaEnvironmentStatus, saveProvisionerDetails } from "./actions/actions";
import { Types as devopsTypes } from "./reducer/Types";
import { toastAlert } from "../../actions/actions";
import _ from 'lodash';
import { provisionerDetailsModal } from "./constants/modal";

function Devops() {
    const { user, allConFigData } = useSelector((state: any) => state.app)
    const { viewStudyDetails, studyPayload } = useSelector((state: any) => state.study);
    const { provisionerDetails, approveRejectStudy, enivornmentStatus } = useSelector((state: any) => state.devops);

    const dispatch = useDispatch();
    const navigate = useNavigate();
    const params = useParams();
    const loaded = React.useRef(false);
    const [error, setError] = React.useState({
        region: false,
        edcUrl: false,
        subDomain: false
    });
    const [setDeployForm] = useState({
        region: '',
        edcUrl: '',
        subDomain: ''
    })
    const [buttonDisable, setButtonDisable] = React.useState(true);
    const [validateCreateSchema, setValidateCreateSchema] = useState<any>({
        dev: null,
        uat: null,
        prod: null
    })

    useEffect(() => {

        if (!loaded.current) {
            // let _provisionerDetails = _.cloneDeep(provisionerDetails);
            // _provisionerDetails.domain = viewStudyDetails.organization.orgShortname;
            // dispatch({type: Types.GET_PROVISIONER_DETAILS, payload: _provisionerDetails});
            if (params && params.id) {
                dispatch(findStudyDetailsById({ studyId: params.id }, (response: any) => {
                    if (response) {
                        dispatch({ type: Types.VIEW_STUDY_DETAILS, payload: response });
                        if (response.regionId) {
                            getProvisionerDetails(response.approvalStatus.code, response);
                        }
                        // let _schemaPayload = {
                        //     _regionId: provisionerDetails?.region?.regionId,
                        //     _protocolId: viewStudyDetails?.protocolId.replace(/[^a-zA-Z0-9_ ]/g, "").toLowerCase(),
                        //     _orgShortName: viewStudyDetails?.organization?.orgShortname.replace(/[^a-zA-Z0-9_ ]/g, "").toLowerCase()
                        // }
                        // if (user?.userRolePrivileges?.data?.Provisioner && provisionerDetails?.region?.regionId) {
                        //     dispatch(getSchemaEnvironmentStatus(_schemaPayload, (enivornmentResponse: any) => { }))
                        // }
                    } else {
                        dispatch(toastAlert({
                            status: !response.errorCode ? 1 : 0,
                            message: response.errorMessage,
                            open: true
                        }));
                    }
                }))
            }
            loaded.current = true
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    useEffect(() => {

        if (params && params.id) {
            if (user.userRolePrivileges.data.Provisioner) {
                createProvisionerSchema();
            }
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [viewStudyDetails]);



    const getProvisionerDetails = (code: string, study: any) => {
        if (user.userRolePrivileges.data.DevopsApprover || user.userRolePrivileges.data.Provisioner) {
            dispatch(findProvisionerDetailsByStudyId(params?.id, (response: any) => {
                if (!response.errorCode) {
                    const _approveRejectStudy = {
                        ...approveRejectStudy,
                        "devOpsProvisionerId": response?.provisionId,
                        "approvedById": user.userId,
                        "primaryStudyAdminStatus": study.studyContacts.length > 0 ? true : false,
                        "secondaryStudyAdminStatus": study.studyContacts.length > 1 ? true : false,
                        "devStatus": true,
                        "uatStatus": true,
                        "prodStatus": true,
                        "domainStatus": true,
                        "studyStatus": study.studyStatus,
                        "gravityUrl": response.gravityUrl,
                    }
                    const _schemaPayload = {
                        _protocolId: study?.protocolId.replace(/[^a-zA-Z0-9_ ]/g, "").toLowerCase(),
                        _orgShortName: study?.organization?.orgShortname.replace(/[^a-zA-Z0-9_ ]/g, "").toLowerCase()
                    }

                    dispatch({ type: devopsTypes.APPROVE_REJECT_STUDY, payload: _approveRejectStudy });
                    if (_schemaPayload._protocolId) {
                        dispatch(getSchemaEnvironmentStatus(_schemaPayload));
                    }
                } else {
                    dispatch(toastAlert({
                        status: !response.errorCode ? 1 : 0,
                        message: response.errorMessage,
                        open: true
                    }));
                }
            }));
        }
    }
    const createProvisionerSchema = () => {
        if (user.userRolePrivileges.data.Provisioner) {
            const _shortName = viewStudyDetails.organization.orgShortname
            const _schemaStr = _shortName + '_' + viewStudyDetails.protocolId
            const _domainUrl = `${viewStudyDetails?.organization?.orgShortname}.inductivequotient.com`
            const _provisionerDetails = {
                ...provisionerDetails,
                devSchema: `${_schemaStr}_dev`,
                uatSchema: `${_schemaStr}_uat`,
                prodSchema: `${_schemaStr}_prod`,
                studyUrl: _domainUrl,
                studyId: viewStudyDetails.id,
                requestedById: user.userId,
                requestedByName: user.userName,
                domain: viewStudyDetails.organization.orgShortname
            }
            dispatch({ type: devopsTypes.GET_PROVISIONER_DETAILS, payload: _provisionerDetails });
        }
    }

    const validateForm = (provisionerDetails: any) => {
        if (!provisionerDetails.dbDetailsId || !provisionerDetails.gravityUrl || !provisionerDetails.domain) {
            setError({
                ...error,
                region: (provisionerDetails?.dbDetailsId) ? false : true,
                edcUrl: (provisionerDetails?.gravityUrl) ? false : true,
                subDomain: (provisionerDetails?.domain) ? false : true
            })
            return false
        } else {
            return true
        }
    }
    const onSubmitHandler = () => {
        const _validate = validateForm(provisionerDetails);
        const _provisionerDetails = _.cloneDeep(provisionerDetails);
        _provisionerDetails.devSchema = _provisionerDetails.devSchema.replace(/[^a-zA-Z0-9_ ]/g, "").toLowerCase();
        _provisionerDetails.uatSchema = _provisionerDetails.uatSchema.replace(/[^a-zA-Z0-9_ ]/g, "").toLowerCase();
        _provisionerDetails.prodSchema = _provisionerDetails.prodSchema.replace(/[^a-zA-Z0-9_ ]/g, "").toLowerCase();
        if (_validate) {
            dispatch(saveProvisionerDetails(_provisionerDetails, () => {
                const _schemaPayload = {
                    _dbDetailsId: provisionerDetails?.dbDetailsId,
                    _protocolId: viewStudyDetails?.protocolId.replace(/[^a-zA-Z0-9_ ]/g, "").toLowerCase(),
                    _orgShortName: viewStudyDetails?.organization?.orgShortname.replace(/[^a-zA-Z0-9_ ]/g, "").toLowerCase(),
                    _gravityUrl: provisionerDetails?.gravityUrl,
                    _userId: user.userId,
                    _comments: viewStudyDetails.comments
                }
                dispatch(createSchemaAndTables(_schemaPayload, (schemaresponse: any) => {
                    if (!schemaresponse.errorCode) {
                        dispatch(toastAlert({
                            status: !schemaresponse.errorCode ? 1 : 0,
                            message: !schemaresponse.errorCode ? `Schema and Tables Creation job added` : `${schemaresponse.errorMessage}`,
                            open: true
                        }));
                        setValidateCreateSchema({ ...validateCreateSchema, dev: !schemaresponse.error ? false : true })
                        dispatch(getSchemaEnvironmentStatus(_schemaPayload, (enivornmentResponse: any) => {
                            if (enivornmentResponse) {
                                navigate('/dashboard');
                                dispatch({ type: devopsTypes.GET_PROVISIONER_DETAILS, payload: provisionerDetailsModal })
                            }
                        }
                        ));
                    } else {
                        dispatch(toastAlert({
                            status: !schemaresponse.errorCode ? 1 : 0,
                            message: schemaresponse.errorMessage,
                            open: true
                        }));
                    }
                }));

            }))
        }
    }

    const onBackToStudy = () => {
        navigate('/dashboard');
        user?.role?.id === 1 ? dispatch(fetchAllStudies(studyPayload)) : dispatch(findstudiesByUser(studyPayload));
        dispatch({ type: Types.DELETED_STUDY_DOCUMENTS, payload: [] });
        dispatch({ type: devopsTypes.GET_PROVISIONER_DETAILS, payload: provisionerDetailsModal })

    }

    const onApproveRejectStudy = (type: any) => {
        const payload = { ...approveRejectStudy, status: type }
        dispatch(approveOrRejectStudy(payload, (response: any) => {
            dispatch(toastAlert({
                status: !response.errorCode ? 1 : 0,
                message: response.errorCode ? response.errorMessage : `study ${type === false ? 'Rejected successfully' : 'Bookmarked successfully'}  `,
                open: true
            }))
            if (!response.errorMessage) {
                navigate('/dashboard');
                dispatch({ type: devopsTypes.GET_PROVISIONER_DETAILS, payload: provisionerDetailsModal })
            }

        }))
    }


    return (
        <React.Fragment>
            <div className=" d-flex justify-content-between">
                <h2>DevOps</h2>
                <div className="backto-mainPage">
                    <span onClick={onBackToStudy}><KeyboardDoubleArrowLeftIcon /> Back To Studies</span>
                </div>
            </div>
            {viewStudyDetails?.id > 0 && <CommonCard title="DevOps">
                <div className="devops-container">
                    <div className="sub-container">
                        {viewStudyDetails?.id > 0 && <StudyDetails />}
                        <StudyAdmin />
                        {user?.userRolePrivileges?.data?.DevopsApprover && <div className=" d-flex justify-content-end "></div>}
                    </div>
                    <div className="sub-container">
                        <Solutions />

                        {user?.userRolePrivileges?.data?.DevopsApprover &&
                            <React.Fragment>
                                <Bookmark />
                                <div className=" d-flex justify-content-end "></div>
                            </React.Fragment>
                        }
                    </div>
                    <Deployment error={error} setError={setError} deployForm setDeployForm={setDeployForm} />
                    <div className="sub-container">
                        <StudySchema
                            setValidateCreateSchema
                            validateCreateSchema={validateCreateSchema}
                            validateForm={validateForm}
                            setButtonDisable={setButtonDisable}
                        />
                    </div>
                    <Comments />
                    <>{console.log('viewStudyDetails..........', viewStudyDetails, allConFigData, user)
                    }</>
                    {<div className=" d-flex justify-content-end me-4 mb-1">
                        <button className="btn btn-secondary btn-sm px-4 me-3" type="button" onClick={onBackToStudy} >Cancel</button>
                        {
                            (!(viewStudyDetails?.approvalStatus?.code === allConFigData?.provisioned) && (viewStudyDetails?.approvalStatus?.code !== allConFigData?.Bookmarked) && (user?.role?.name == "Devops Engineer")) ?
                                <button className="btn btn-success btn-sm px-3" type="submit" onClick={onSubmitHandler}
                                    disabled={(enivornmentStatus?.failed && enivornmentStatus?.initiated) ? false : buttonDisable}>Submit</button>
                                :
                                ""
                        }
                        {(user?.userRolePrivileges?.data?.DevopsApprover && viewStudyDetails?.approvalStatus?.code !== allConFigData?.Bookmarked) && <div>
                            <button className="btn btn-danger btn-sm px-4 me-3" type="submit" onClick={() => onApproveRejectStudy(false)} >Reject</button>
                            <button className="btn btn-success btn-sm px-3" type="submit" disabled={buttonDisable} onClick={() => onApproveRejectStudy(true)} >Approve</button>
                        </div>}
                    </div>}
                </div>
            </CommonCard>}
        </React.Fragment>
    )
}
export default Devops;