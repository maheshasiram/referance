import { Types } from "./Types";
import { approveRejectStudyModal, devopsModal, provisionerDetailsModal } from "../constants/modal";

const initialState = {
    devOps: devopsModal,
    provisionerDetails: provisionerDetailsModal,
    approveRejectStudy: approveRejectStudyModal,
    saveProvisioner: null,
    enivornmentStatus: {},
    regionData: null,
    regionDbDetailsData: null
}

export const devops = (state = initialState, action: { type: any, payload: any }) => {
    switch (action.type) {
        case Types.DEVOPS_DETAILS:
            return { ...state, devops: action.payload }
        case Types.GET_PROVISIONER_DETAILS:
            return { ...state, provisionerDetails: action.payload }
        case Types.APPROVE_REJECT_STUDY:
            return { ...state, approveRejectStudy: action.payload }
        case Types.SAVE_PROVISIONER_DETAILS:
            return { ...state, saveProvisioner: action.payload }
        case Types.SET_ENIVORNMENT_STATUS:
            return { ...state, enivornmentStatus: action.payload }
        case Types.GET_REGIONS:
            return { ...state, regionData: action.payload }
        case Types.GET_DB_DETAILS_REGIONS:
            return { ...state, regionDbDetailsData: action.payload }
        default:
            return { ...state }
    }
}