
export type DbDetailsType = {
    id?: number,
    regionId?: string,
    dbName?: string,
    dbHost?: string,
    dbPort?: string,
    userName?: string,
    passWord?: any
}