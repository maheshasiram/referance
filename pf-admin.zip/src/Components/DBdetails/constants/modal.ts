import { DbDetailsType } from "./dataTypes"

export const DatabaseDetailsModal: DbDetailsType = {
    id: 0,
    regionId: "",
    dbName: "",
    dbHost: "",
    dbPort: "",
    userName: "",
    passWord: ""
}
