import { Types } from "./Types";
import { DatabaseDetailsModal } from "../constants/modal";

const initialState = {
    databaseDetails: DatabaseDetailsModal,
    dbDetails: null,
    getDbDetailsParam: {
        limit: 10,
        offset: 0,
        dbName: ""
    },
    regions: null
}
export const dbDetails = (state = initialState, action: { type: any, payload: any }) => {
    switch (action.type) {
        case Types.CREATE_DB_DETAILS:
            return { ...state, databaseDetails: action.payload }
        case Types.DB_DETAILS_PARAMS:
            return { ...state, getDbDetailsParam: action.payload }
        case Types.GET_DB_DETAILS:
            return { ...state, dbDetails: action.payload }
        case Types.GET_REGION_DATA:
            return { ...state, regions: action.payload }
        default:
            return { ...state }
    }
}