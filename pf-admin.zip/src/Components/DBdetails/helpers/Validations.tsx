import * as Yup from 'yup';

export const DbValidation = Yup.object().shape({
    userName: Yup.string()
        .required("Please enter Username"),
        // .matches(/^[a-zA-Z0-9]+$/, 'Special characters are not allowed'),
    // .matches(/^[^\s].+[^\s]$/, '/Message should not start with spaces')
    passWord: Yup.string()
        .required("Please enter Password"),
    // .matches(/^[^\s].+[^\s]$/, '/Message should not start with spaces')
    // .matches(/^([a-zA-Z0-9]+\s)*[a-zA-Z0-9]+$/, 'Only one space allowed between words')

    regionId: Yup.string()
        .required("Please select Region")
        .matches(/^[a-zA-Z0-9]+$/, 'Special characters are not allowed'),
    // .matches(/^([a-zA-Z0-9]+\s)*[a-zA-Z0-9]+$/, 'Only one space allowed between words'),
    dbName: Yup.string()
        .required("Please enter database Name"),
    // .matches(/^[a-zA-Z0-9]+$/, 'Special characters are not allowed'),
    // .matches(/^[^\s].+[^\s]$/, '/Message should not start with spaces')
    dbHost: Yup.string()
        .required("Please enter database Host"),
    // .matches(/^[a-zA-Z0-9]+$/, 'Special characters are not allowed'),

    dbPort: Yup.string()
        .required("Please enter database Port")
    // .matches(/^[a-zA-Z0-9]+$/, 'Special characters are not allowed'),
    // .matches(/^[^\s].+[^\s]$/, '/Message should not start with spaces')
})