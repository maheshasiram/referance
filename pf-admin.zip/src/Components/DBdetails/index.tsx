import React from "react";
import DBDashboard from "./components/DBDashboard";

function DbDetails() {
    return (
        <React.Fragment>
            <DBDashboard />
        </React.Fragment>
    )
}
export default DbDetails;