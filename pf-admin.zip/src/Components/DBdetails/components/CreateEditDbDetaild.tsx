import React from "react";
import CustomDialog from "../../../Common/modals/CustomDialog";
import { DbValidation } from "../helpers/Validations";
import { Formik, Form, Field, ErrorMessage } from 'formik';
import "../styles/Styles.scss";
import EditIcon from '@mui/icons-material/Edit';
import { useDispatch, useSelector } from 'react-redux';
import CustomizedTooltip from "../../../Common/CustomizedTooltip/CustomizedTooltip";
import { createDbDetails, fetchDbDetails, fetchSavedRecords, getRegionByTypeCode, updateDbDetails } from "../actions/actions";
import { Types } from "../reducer/Types";
import { DatabaseDetailsModal } from "../constants/modal";
import { toastAlert } from "../../../actions/actions";
import { messages } from "../../../configs/messages";


function CreateEditDbDetaild(props: any) {

    const [open, setOpen] = React.useState(false);
    const { databaseDetails, regions, getDbDetailsParam } = useSelector((state: any) => state.dbDetails);
    const [erroeMsg, seterrorMsg] = React.useState('');
    const [btnState, setBtnState] = React.useState(true)
    const { rowData } = props
    const dispatch = useDispatch();
    const onCloseCreateDB = () => {
        setOpen(false);
        seterrorMsg('');
        setBtnState(true)
    }

    const onUserNameHandler = (e: any, setFieldValue: any) => {
        if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
            setFieldValue("userName", e.target.value);
            seterrorMsg('');
            setBtnState(false)
        }
    }
    const onsubmitDbDetails = (values: any) => {
        const _payload = { ...values, regionId: parseInt(values.regionId) }
        const payload = { ...getDbDetailsParam, limit: getDbDetailsParam.limit, offset: getDbDetailsParam.offset, dbName: getDbDetailsParam.dbName }
        dispatch((_payload.id !== 0 ? updateDbDetails : createDbDetails)(_payload, (response: any) => {
            if (response.errorCode === "EDC-PA-405") {
                seterrorMsg(response.errorMessage);
            }
            else {
                props.setSearchDBName('')
                setOpen(false);
                dispatch(fetchDbDetails(payload))
                dispatch(toastAlert({
                    status: 1,
                    message: `${values.dbName} ${_payload.id !== 0 ? messages.dbdetails.updated : messages.dbdetails.created}`,
                    open: true
                }))
            }
        }))
    }

    const onDbProtHandler = (e: any, setFieldValue: any) => {
        if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
            setFieldValue("dbPort", e.target.value);
            seterrorMsg('');
            setBtnState(false)
        }
    }

    const onPasswordHandler = (e: any, setFieldValue: any) => {
        if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
            setFieldValue("passWord", e.target.value);
            seterrorMsg('');
            setBtnState(false)

        }
    }

    const onCreateOrEditDatabase = (type: any) => {
        setOpen(true);
        dispatch(getRegionByTypeCode('REGION'));
        seterrorMsg('');
        if (type === 'add') {
            dispatch({ type: Types.CREATE_DB_DETAILS, payload: DatabaseDetailsModal })
        } else {
            dispatch(fetchSavedRecords(rowData.id, (response: any) => {
                dispatch({ type: Types.CREATE_DB_DETAILS, payload: type !== 'add' ? response.data : DatabaseDetailsModal })
            }))
        }
    }

    const onDbNameHandler = (e: any, setFieldValue: any) => {
        if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
            setFieldValue("dbName", e.target.value);
            seterrorMsg('');
            setBtnState(false)
        }
    }


    const onDbRegionHandler = (e: any, setFieldValue: any) => {
        setFieldValue('regionId', e.target.value)
        seterrorMsg('');
        setBtnState(false)
    }

    const onDbHostHandler = (e: any, setFieldValue: any) => {
        if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
            setFieldValue("dbHost", e.target.value);
            seterrorMsg('');
            setBtnState(false)
        }
    }

    return (
        <React.Fragment>
            <div className="d-flex ">
                {rowData && rowData.id !== 0 ?
                    <div className="editDb">
                        <CustomizedTooltip title="Edit DB Details"><EditIcon sx={{ fontSize: 14, opacity: .8 }} onClick={() => onCreateOrEditDatabase('edit')} /></CustomizedTooltip></div> :
                    <div className="d-flex justify-content-end">
                        <button className=" filters mb-2" onClick={() => onCreateOrEditDatabase('add')}>+ Create DB Details</button>
                    </div>}
            </div>
            <CustomDialog
                title={rowData && rowData.id !== 0 ? 'Update DB' : 'Create DB'}
                open={open}
                onClose={onCloseCreateDB}
                actionType={rowData && rowData.id !== 0 ? 'Update' : 'Submit'}
                form="createDB"
                disabled={btnState}
                maxWidth={'sm'}
                fullWidth={false}
            >
                <Formik
                    enableReinitialize={true}
                    initialValues={databaseDetails}
                    validationSchema={DbValidation}
                    onSubmit={(values: any) => { onsubmitDbDetails(values) }}
                >

                    {({ errors, touched, values, setFieldValue }) => (
                        <Form id="createDB" >
                            {erroeMsg ? <span className="d-flex justify-content-center text-danger">{erroeMsg}</span> : <span>&nbsp;</span>}
                            <div className="create-input ">
                                {/* <div className="">{erroeMsg}</div> */}
                                <label htmlFor="txt-groupName">User Name:<span className='text-danger mx-1'>*</span> </label>
                                <Field
                                    name='userName'
                                    placeholder='Enter user name'
                                    value={values.userName}
                                    className="form-control "
                                    onChange={(e: any) => onUserNameHandler(e, setFieldValue)}
                                />
                                {errors.userName && touched.userName ? <span className="text-danger"><ErrorMessage name={`userName`} /></span> : <span>&nbsp;</span>}
                            </div>

                            <div className="create-input">
                                <label htmlFor="">Password:<span className='text-danger mx-1'>*</span> </label>
                                <Field
                                    name='passWord'
                                    type='password'
                                    placeholder='Enter password'
                                    value={values.passWord}
                                    className="form-control"
                                    onChange={(e: any) => onPasswordHandler(e, setFieldValue)}
                                // onChange={(e: any) => {
                                //     if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) == false && e.target.value.length == 0)) {
                                //         setFieldValue("passWord", e.target.value);
                                //         seterrorMsg('');
                                //     }
                                // }}
                                />
                                {errors.passWord && touched.passWord ? <span className="text-danger"><ErrorMessage name={`passWord`} /></span> : <span>&nbsp;</span>}
                            </div>

                            <div className="create-input">
                                <label id='regionName'>Region :<span className='text-danger mx-1'>*</span> </label>
                                <Field
                                    name='regionId'
                                    as='select'
                                    value={values.regionId}
                                    className="form-select"
                                    placeholder={"regionName"}
                                    onChange={(e: any) => { onDbRegionHandler(e, setFieldValue) }}
                                >
                                    <option value=''>Select region</option>
                                    {
                                        regions && regions.map((region: any, index: any) => (
                                            <option key={index} value={region.id}>{region.name}</option>
                                        ))
                                    }
                                </Field>
                                {errors.regionId && touched.regionId ? <span className="text-danger"><ErrorMessage name={`regionId`} /></span> : <span>&nbsp;</span>}
                            </div>

                            <div className="create-input">
                                <label htmlFor="">DB Name:<span className='text-danger mx-1'>*</span> </label>
                                <Field
                                    name='dbName'
                                    placeholder='Enter db name'
                                    value={values.dbName}
                                    className="form-control"
                                    onChange={(e: any) => onDbNameHandler(e, setFieldValue)}
                                />
                                {errors.dbName && touched.dbName ? <span className="text-danger"><ErrorMessage name={`dbName`} /></span> : <span>&nbsp;</span>}
                            </div>

                            <div className="create-input">
                                <label htmlFor="">DB Host:<span className='text-danger mx-1'>*</span> </label>
                                <Field
                                    name='dbHost'
                                    placeholder='Enter db host'
                                    value={values.dbHost}
                                    className="form-control"
                                    onChange={(e: any) => onDbHostHandler(e, setFieldValue)}
                                />
                                {errors.dbHost && touched.dbHost ? <span className="text-danger"><ErrorMessage name={`dbHost`} /></span> : <span>&nbsp;</span>}
                            </div>

                            <div className="create-input">
                                <label htmlFor="txt-groupName">DB Port:<span className='text-danger mx-1'>*</span> </label>
                                <Field
                                    name='dbPort'
                                    type='number'
                                    value={values.dbPort}
                                    placeholder='Enter db port'
                                    className="form-control form-control-lg"
                                    onKeyPress={(e: any) => {
                                        if (e.key === "-" || e.key === "+" || e.key === "e") {
                                            e.preventDefault();
                                        }
                                    }}
                                    onChange={(e: any) => onDbProtHandler(e, setFieldValue)}
                                />
                                {errors.dbPort && touched.dbPort ? <span className="text-danger"><ErrorMessage name={`dbPort`} /></span> : <span>&nbsp;</span>}
                            </div>
                        </Form>)}
                </Formik>
            </CustomDialog>
        </React.Fragment>
    )
}
export default CreateEditDbDetaild;