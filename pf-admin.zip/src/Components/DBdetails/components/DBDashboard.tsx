
import React from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { useDispatch, useSelector } from 'react-redux';
import { fetchDbDetails } from "../actions/actions";
import {   rowClassName } from "../../../actions/actions";
// import RestoreIcon from '@mui/icons-material/Restore';
import { Types } from "../reducer/Types";
import CustomizedTooltip from "../../../Common/CustomizedTooltip/CustomizedTooltip";
import ClearSharpIcon from '@mui/icons-material/ClearSharp';
import '../styles/Styles.scss'
import CreateEditDbDetaild from "./CreateEditDbDetaild";
import Loader from "../../../Common/Loader";

function DBDashboard() {
    const dispatch = useDispatch();
    const { getDbDetailsParam, dbDetails } = useSelector((state: any) => state.dbDetails);
    const { user } = useSelector((state: any) => state.app)

    const loaded = React.useRef(false);
    const [pageClick, setpageChange] = React.useState(false);
    const [searchDBName, setSearchDBName] = React.useState('')


    React.useEffect(() => {
        if (!loaded.current) {
            const _payload = { ...getDbDetailsParam, limit: getDbDetailsParam.limit, offset: getDbDetailsParam.offset, dbName: getDbDetailsParam.dbName }
            dispatch(fetchDbDetails(_payload))
            loaded.current = true
        }
    }, [dispatch,getDbDetailsParam])

    // const deleteRestoreDbDetails = (rowData: any, type: any) => {
    //     let _payload = { ...getDbDetailsParam, limit: getDbDetailsParam.limit, offset: getDbDetailsParam.offset, dbName: getDbDetailsParam.dbName }
    //     dispatch(Confirm({
    //         status: 0,
    //         message: type == 'delete' ? confirmMsg(messages.commonMessages.delete, rowData.dbName) : confirmMsg(messages.commonMessages.restore, rowData.dbName),
    //         onOk: () => {
    //             dispatch((type == 'delete' ? deleteDbDetails : restoreDbDetails)(rowData.id, (response: any) => {
    //                 console.log("...84", response)
    //                 if (!response.error) {
    //                     dispatch(fetchDbDetails(_payload))
    //                     dispatch(toastAlert({
    //                         status: 1,
    //                         message: rowData.isActive ? toastMsg(messages.commonMessages.inActivated, rowData.dbName) : toastMsg(messages.commonMessages.activated, rowData.dbName),
    //                         open: true
    //                     }))
    //                 }
    //             }))
    //         }
    //     }))
    // }
    const actionsBodyTemplate = (rowData: any) => {
        return <div className='d-flex'>
                <CreateEditDbDetaild rowData={rowData} setSearchDBName={setSearchDBName} />
                </div>
        // if (rowData.isActive) {
        // return <div className='d-flex actions'>
        //     <CreateEditDbDetaild rowData={rowData} />
        /* <span>|</span>
                <CustomizedTooltip title={"Delete DB Details"}><DeleteIcon sx={{ fontSize: 14, opacity: .8 }} onClick={() => deleteRestoreDbDetails(rowData, 'delete')} /></CustomizedTooltip> */
        //     </div>
        // } else {
        // return (
        //     <CustomizedTooltip title={"Restore DB Details"}><ReplayIcon sx={{ fontSize: 14, opacity: .8 }} onClick={() => deleteRestoreDbDetails(rowData, 'restore')} /></CustomizedTooltip>
        // )
        // }
    }

    const onPageClick = (event: any) => {
        if (((event.page > 0) || (pageClick && event.page === 0)) && getDbDetailsParam.offset !== event.first) {
            const _payload = { ...getDbDetailsParam, offset: event.first }
            dispatch({ type: Types.DB_DETAILS_PARAMS, payload: _payload })
            dispatch(fetchDbDetails(_payload))
            setpageChange(true)
        }
    }

    const onSearchDbName = (e: any) => {
        const _payload = { ...getDbDetailsParam, offset: 0, dbName: e.target.value }
        setSearchDBName(e.target.value)
        dispatch(fetchDbDetails(_payload))
    }

    const onClearSearch = () => {
        const _payload = { ...getDbDetailsParam, limit: 10, offset: 0, dbName: '' }
        setSearchDBName('')
        dispatch({ type: Types.DB_DETAILS_PARAMS, payload: _payload })
        dispatch(fetchDbDetails(_payload))
    }

    return (
        <React.Fragment>
            <div className="">
                {!dbDetails && <Loader />}
                <h2>DB Dashboard</h2>
                <div className='d-flex justify-content-end org-filters-section'>
                    <div className="search-container align-items-center d-flex">
                        <div className="align-items-center d-flex">
                            <input className="form-input" value={searchDBName} onChange={(e) => onSearchDbName(e)} placeholder={"Search By DB Name"} />
                            {searchDBName && <span className='clearSearchIcon'><CustomizedTooltip title={"Clear Search"}><ClearSharpIcon sx={{ fontSize: 15, opacity: .8 }} onClick={() => onClearSearch()} /></CustomizedTooltip></span>}
                        </div>
                    </div>
                    <div className={'d-flex ustify-content-end'}>
                       {user?.userRolePrivileges?.data?.CreateDatabase && <CreateEditDbDetaild setSearchDBName={setSearchDBName} />}
                    </div>
                </div>
                {dbDetails && <div className="card">
                    <DataTable responsiveLayout="scroll"
                        lazy
                        value={dbDetails && dbDetails.dbDetails}
                        paginator={dbDetails && dbDetails.totalRecords > getDbDetailsParam.limit ? true : false}
                        rows={getDbDetailsParam.limit}
                        totalRecords={dbDetails && dbDetails.totalRecords}
                        first={getDbDetailsParam.offset}
                        onPage={onPageClick}
                        rowClassName={rowClassName}
                    >
                        <Column field="dbName" header="Db Name "></Column>
                        <Column field="regionName" header="Region"></Column>
                       {user?.userRolePrivileges?.data?.EditDatabase && <Column body={actionsBodyTemplate} header="Actions"></Column>}
                    </DataTable>
                </div>}
            </div>
        </React.Fragment>
    )
}
export default DBDashboard;



