import { Types } from "../reducer/Types";
import { fetch } from "../../../Constants/fetch";
import { requests } from "../../../configs/env";
import { Loader } from "../../../actions/actions";

//fetch DB details data
export const fetchDbDetails: any = (payload: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'POST',
            // url: `${requests.dbDetail.fetchDbDetails}?dbName=${dbName}`,
            url: `${requests.dbDetail.fetchDbDetails}`,
            data: payload
        })
            .then((response: any) => {
                dispatch({ type: Types.GET_DB_DETAILS, payload: response.data })
                dispatch(Loader(false));
            }).catch((error: any) => {
                console.log('error', error)
            })
    }
}

// create DB details
export const createDbDetails: any = (payload: any, callback: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: `${requests.dbDetail.createDbDetails}`,
            data: payload
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data);
                }
                dispatch(Loader(false))
            }).catch((error: any) => {
                console.log('error', error)
            })
    }
}

//getting all regions
export const getRegionByTypeCode: any = (code: string) => {
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: `${requests.config.getByTypeCode}/${code}`,
        })
            .then((response: any) => {
                dispatch({ type: Types.GET_REGION_DATA, payload: response.data });
                dispatch(Loader(false))
            }).catch((error: any) => {
                console.log('error', error)
            })
    }
}

//restore db details api
export const restoreDbDetails: any = (payload: any, callback: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'POST',
            url: `${requests.dbDetail.restoreDbDetails}?id=${payload}`,
        })
            .then((response: any) => {
                if (callback) { callback(response) }
                dispatch(Loader(false))
            }).catch((error: any) => {
                console.log('error', error)
            })
    }
}

// delete db details api
export const deleteDbDetails: any = (payload: any, callback: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'POST',
            url: `${requests.dbDetail.deleteDbDetails}?id=${payload}`
        })
            .then((response: any) => {
                if (callback) { callback(response) }
                dispatch(Loader(false))
            }).catch((error: any) => {
                console.log('error', error)
            })
    }
}

// feching saved data base records
export const fetchSavedRecords: any = (code: any, callback: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'GET',
            url: `${requests.dbDetail.fetchSavedRecords}/${code}`,
        })
            .then((response: any) => {
                if (callback) {
                    callback(response)
                }
                dispatch(Loader(false));
            }).catch((error: any) => {
                console.log('error', error)
            })
    }
}


//fetching perticular region by region id
export const getRegionDetailsById: any = (id: any, callback: any) => {
    return function () {
        fetch({
            method: 'POST',
            url: `${requests.dbDetail.getRegionDetailsById}?id=${id}`,
        })
            .then((response: any) => {
                if (callback) {
                    callback(response)
                }
            }).catch((error: any) => {
                console.log('error', error)
            })
    }
}

//update db 
export const updateDbDetails: any = (payload: any, callback: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'POST',
            url: `${requests.dbDetail.updateDbDetails}`,
            data: payload
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data);
                    dispatch(Loader(false))
                }
            }).catch((error: any) => {
                console.log('error', error)
            })
    }
}