import React from 'react'
import { NavLink, useLocation, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from 'react-redux';
import { Types } from '../Studies/reducer/Types';
import {  saveConfigData } from '../../actions/actions';
import { Study } from '../Studies/Constants/DataTypes';
import { backToStudy } from '../Organization/actions/actions';
import { useTranslation } from 'react-i18next';


function NavBar() {
  const { t, i18n } = useTranslation();
  const onChangeLang = (e: any) => { i18n.changeLanguage(e.target.value); }
  const dispatch = useDispatch();
  const location = useLocation();
  const { user } = useSelector((state: any) => state.app);
  const isActive = location.pathname === "/createorganization";
  
  const isStudyActive = (location.pathname.includes('/createStudy') || location.pathname.indexOf('/study') >= 0);
  const { conFigData } = useSelector((state: any) => state.app)
  const { allSolutions } = useSelector((state: any) => state.study)
  const navigate = useNavigate()

  const onCreateNewStudy = () => {
    if (allSolutions) {
      const _allSolutions: any = [...[], ...allSolutions]
      allSolutions && allSolutions.length > 0 && allSolutions.map((item: any, index: number) => {
      return ( _allSolutions[index].checked = false)
      })
      dispatch({ type: Types.FETCH_ALL_SOLUTIONS, payload: _allSolutions });
    }
    if (conFigData && conFigData.EDC_MODULES) {
      const _EDC_MODULES = [...[], ...conFigData.EDC_MODULES]
      conFigData.EDC_MODULES.map((item: any, index: number) => {
      return(  _EDC_MODULES[index].checked = false)
      })
      conFigData.EDC_MODULES = _EDC_MODULES
      dispatch(saveConfigData(conFigData))
    }

    dispatch({ type: Types.INITIATE_NEW_STUDAY, payload: Study });
    dispatch({ type: Types.UPDATED_FIELD_VALUES, payload: Study });
    dispatch(backToStudy(false));
    dispatch({ type: Types.DELETED_STUDY_DOCUMENTS, payload: [] });
    dispatch({ type: Types.ON_EXTEND_CLICK, payload: false });
    dispatch({ type: Types.CHANGE_ACTION_TYPE, payload: 'create' });
    navigate('/createStudy/0');
    sessionStorage.removeItem('extend');
  }

  return (
    <div className="enav-bar">
      <nav className="enav-container">
        <div className='nav-elements'>
          <ul>
            {user?.userRolePrivileges?.data?.ViewStudy && <li>
              <NavLink className={isStudyActive ? 'active' : ''}
                onClick={() => dispatch({ type: Types.CHANGE_ACTION_TYPE, payload: 'create' })} to="dashboard">{t("Studies")}</NavLink>
            </li>}
            {user?.userRolePrivileges?.data?.ViewOrganization && <li><NavLink className={isActive ? 'active' : ''}
              to="organizations">{t("Organizations")}</NavLink>
            </li>}
            {user?.userRolePrivileges?.data?.ViewRolesandPrivileges && <li><NavLink to="roles">{t("Roles and Privileges")}</NavLink></li>}
            {/* {((user?.userRolePrivileges?.data?.DevopsApprover) || (user?.userRolePrivileges?.data?.Provisioner)) && <li><NavLink to="devops">{t("devops")}</NavLink></li>} */}
            {user?.userRolePrivileges?.data?.ViewDatabase && <li><NavLink to="dbdetails">{t("DB Details")}</NavLink></li>}
            {user?.userRolePrivileges?.data?.ViewUsers && <li><NavLink to="users">{t("Users")}</NavLink></li>}
            {<li><NavLink to="organizationUrls">{t("Organization url's")}</NavLink></li>}
          </ul>
        </div>
        <div className='nav-buttons'>
          {/* {user?.userRolePrivileges?.privilegeGroups?.length > 1 && user?.userRolePrivileges?.data?.CreateStudy && <NavLink className="btn-eprimary" onClick={() => onCreateNewStudy()} to="createStudy/0">{"+ " + t("Create Study")}</NavLink>} */}
          {user?.userRolePrivileges?.privilegeGroups?.length > 1 && user?.userRolePrivileges?.data?.CreateStudy &&
            <label className=" btn-eprimary"
              onClick={() => onCreateNewStudy()} >{"+ " + t("Create Study")}</label>}

          {/* // <NavLink to="/createStudy/0" className=" btn-eprimary" */}
          {/* //   onClick={() => onCreateNewStudy()}>{"+ " + t("Create Study")} */}
          {/* // </NavLink>} */}
          <select value={i18n.language} className='translation ' onChange={onChangeLang}>
            <option value="en">English</option>
            <option value="fr">French</option>
          </select>
        </div>
      </nav>
    </div>

  )
}

export default NavBar;