import * as React from 'react';
import _ from "lodash";
import Drawer from '@mui/material/Drawer';
import Box from '@mui/material/Box';
import Divider from '@mui/material/Divider';
import SettingsIcon from '@mui/icons-material/Settings';
import TabContext from '@mui/lab/TabContext';
import TabPanel from '@mui/lab/TabPanel';
import CloseIcon from '@mui/icons-material/Close';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import IconButton from '@mui/material/IconButton';
import { useDispatch, useSelector } from "react-redux";
import { Types } from '../../Constants/Types';
import { changeRole, getAssignRole } from '../../actions/actions';
import { useNavigate } from "react-router-dom";

function Settings() {
    // type Anchor = 'right';
    const dispatch = useDispatch();
    // const [value, setValue] = React.useState('1');
    const [open, setOpen] = React.useState(false);
    const [btnState, setBtnState] = React.useState(true);
    const { roleSettings, user } = useSelector((state: any) => state.app);
    const navigate = useNavigate()


    const toggleDrawer = (open: boolean) => (event: React.KeyboardEvent | React.MouseEvent) => {
        setBtnState(true)
        if (event.type === 'keydown' && ((event as React.KeyboardEvent).key === 'Tab' || (event as React.KeyboardEvent).key === 'Shift')) {
            return;
        }
        if (open) {
            dispatch(getAssignRole(user.userId));
        }
        setOpen(open);
    };
    const onRoleChange = (e: any) => {
        setBtnState(false)
        const payload = _.cloneDeep(roleSettings)
        roleSettings && roleSettings.filter((item: any, index: number) => {
            if (item.id === parseInt(e.target.value)) {
                return payload[index].status = true
            } else {
                return payload[index].status = false
            }
        })
        dispatch({ type: Types.ROLE_SETTINGS, payload: payload });

    }
    const onSubmit = () => {
        setOpen(false)
        navigate('/');
        roleSettings?.find((item: any) => {
            return ((item.status === true) && dispatch(changeRole({ roleId: item.id, userId: user?.userId }, () => {
                window.location.reload()
            }
            )))
        });
        // roleSettings?.map((item: any) => {
        // if(item.status === true){
        //     dispatch(changeRole({ roleId: item.id, userId: user?.userId }, (response:any)=>{
        //         navigate('/');
        //     }))
        // }
        // });
    }


    const list = () => (
        <Box className='settings pl-2' role="presentation">
            <Divider />
            <TabContext value='1' >
                <Box className='' sx={{ borderBottom: 1, borderColor: 'divider' }}>
                    <div className='settings-header'>
                        <h5>Roles</h5>
                        <IconButton onClick={toggleDrawer(false)} aria-label="close" sx={{ position: 'absolute', right: 8, color: (theme) => theme.palette.grey[500] }} >
                            <CloseIcon />
                        </IconButton>
                    </div>
                </Box>
                <TabPanel className='tab-panel' value="1">
                    <FormControl>
                        <RadioGroup
                            aria-labelledby="demo-radio-buttons-group-label"
                            defaultValue={''}
                            name="radio-buttons-group"
                            onChange={onRoleChange}>
                            {roleSettings && roleSettings.map((item: any, i: any) => {
                                return <span className='settings-data ml-2' key={i}>
                                    <FormControlLabel value={item.id}
                                        control={<Radio />}
                                        label={item.name}
                                        checked={item.status} />
                                </span>
                            })
                            }

                        </RadioGroup>
                    </FormControl>
                </TabPanel>
                {/* <div className='submitButton-alignmnt'><button className='btn-eprimary' onClick={toggleDrawer(false)}> Submit </button></div> */}
                {roleSettings && <div className='submitButton-alignmnt'><button className={btnState ? 'btn-esecondary' : 'btn-eprimary'} onClick={() => onSubmit()} disabled={btnState}> Change Role </button></div>}
            </TabContext >
        </Box >
    )
    return (
        <React.Fragment>
            <SettingsIcon onClick={toggleDrawer(open ? false : true)} color="inherit" />
            <Drawer className='side-drawer' anchor={'right'} open={open} onClose={toggleDrawer(false)} > {list()} </Drawer>
        </React.Fragment>
    )
}

export default Settings