import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import AccountCircle from '@mui/icons-material/AccountCircle';
import MenuItem from '@mui/material/MenuItem';
import Menu from '@mui/material/Menu';
import { Badge } from '@mui/material';
import Divider from '@mui/material/Divider';
import NotificationsNone from '@mui/icons-material/NotificationsNone';
import PersonOutlineIcon from '@mui/icons-material/PersonOutline';
import ExitToAppOutlinedIcon from '@mui/icons-material/ExitToAppOutlined';
import './styles.scss';
import InductiveLogo from './InductiveLogo';
import NavBar from './NavBar';
import { deleteNotificationByID, fetchStudyNotifications, toastAlert } from "../../actions/actions";
import { useDispatch, useSelector } from 'react-redux';
import CustomDialog from '../../Common/modals/CustomDialog'
import CustomizedTooltip from '../../Common/CustomizedTooltip/CustomizedTooltip'
import { useTranslation } from 'react-i18next';
import Notification from '../Notification/Notification';
import MarkEmailReadIcon from '@mui/icons-material/MarkEmailRead';
import Settings from './Settings';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';


export default function HeaderAppBar(props: any) {
  const { t } = useTranslation();
  const { logOut } = props;
  const dispatch = useDispatch()
  const { user, notificationsData } = useSelector((state: any) => state.app)

  // const [auth, setAuth] = React.useState(true);
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const [notification, setNotification] = React.useState<null | HTMLElement>(null);
  const [openViewAll, setOpenViewAll] = React.useState(false);
  const loaded = React.useRef(false);

  const handleMenu = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const notificationHandle = (event: React.MouseEvent<HTMLElement>) => {
    setNotification(event.currentTarget);
  }
  const open = Boolean(notification);

  const handleClose = () => {
    setAnchorEl(null);
    setNotification(null)
  };

  const handleLogout = () => {
    sessionStorage.removeItem("token");
    logOut()
    setAnchorEl(null);
  };

  React.useEffect(() => {
    if (!loaded.current && user.userId > 0 && user.userId) {
      dispatch(fetchStudyNotifications(user.userName, user?.role?.id));
      loaded.current = true
    }
  }, [dispatch, user]);

  const onCloseViewAll = () => {
    setOpenViewAll(false)
  }


  const onViewAllClick = () => {
    setOpenViewAll(true)
  }

  const handleMessageRead = (index: number, id: any) => {
    notificationsData && notificationsData.length > 0 &&
      dispatch(deleteNotificationByID(id, (response: any) => {
        dispatch(toastAlert({
          status: 1,
          message: response,
          open: true
        }))
      }))
    // dispatch(fetchStudyNotifications(user.userName));
    notificationsData && notificationsData.splice(index, 1)
    // dispatch({ type: Types.FETCH_STUDY_NOTIFICATIONS, payload: notificationsData.splice(index,1) })
  }

  return (
    <React.Fragment>
      {
        user?.userId ? <Notification /> : null
      }
      {
        notificationsData && notificationsData.length > 0 &&
        <CustomDialog
          title={t('Notifications')}
          open={openViewAll}
          onClose={onCloseViewAll}
          maxWidth="sm"
          // onSubmitHandler={() => onCloseViewAll()}
          fullWidth={false}
          actionType={'Close'}
        >
          {notificationsData && notificationsData.length > 0 && notificationsData.map((item: any, index: any) => {
            // console.log('item137',item)
            return (

              <div key={index}>
                <MenuItem>
                  <Divider />
                  <div className='item-list d-flex w-100'>
                    {/* <div className='d-flex'>
                    <span><CheckCircleOutlineIcon fontSize="medium" sx={{ color: '#42a4cd', mr: 1, mt: 1 }} /></span>
                    <div className='list-content' onClick={(e: any) => onNotificationClick(e, item)}>
                      <h6>{item.studyName}</h6>
                      <p>{t("This Study Will Expires Within")} <b>{moment(item.endDate).diff(moment(new Date()), 'days')}</b> {t("days on")} <b>{item.endDate}</b>. </p>
                    </div>
                  </div> */}
                    <div className='d-flex '>
                      <div className=''>
                        <CustomizedTooltip>
                          <MarkEmailReadIcon
                            sx={{ color: 'green' }}
                          // onClick={() => handleMessageRead(index, item.id)}
                          />
                        </CustomizedTooltip>
                      </div>
                      <div className=' notifiction-font'>
                        <span>{item.notifications}</span>
                      </div >
                    </div><div className=""></div>
                  </div>
                  <div className=''>
                    <HighlightOffIcon
                      sx={{ color: 'red' }}
                      onClick={() => handleMessageRead(index, item.id)}
                    />
                  </div>

                </MenuItem>
                <Divider />
              </div>
            )
          })
          }
        </CustomDialog>
      }
      <Box sx={{ flexGrow: 1 }}>
        <AppBar position="static" className='app-header'>
          <Toolbar className='app-bar'>
            <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
              <InductiveLogo />
            </Typography>
            <div>
              <Badge
                badgeContent={notificationsData && notificationsData.length}
                color="error"
                style={{ cursor: 'pointer' }}
                anchorOrigin={{
                  vertical: 'top',
                  horizontal: 'right'
                }}
                onClick={notificationHandle}
              >
                <CustomizedTooltip title=" Notification "><NotificationsNone /></CustomizedTooltip>
              </Badge>
              <Menu
                anchorEl={notification}
                id="account-menu"
                open={open}
                className="bell-icon"
                onClose={handleClose}
                onClick={handleClose}
                PaperProps={{
                  elevation: 0,
                  sx: {
                    overflow: 'visible',
                    filter: 'drop-shadow(0px 2px 4px rgba(0,0,0,0.22))',
                    mt: 1.5,
                    '& .MuiAvatar-root': {
                      width: 32,
                      height: 32,
                      ml: -0.5,
                      mr: 1,
                    },
                    '&:before': {
                      content: '""',
                      display: 'block',
                      position: 'absolute',
                      top: 0,
                      right: 14,
                      width: 10,
                      height: 10,
                      bgcolor: 'background.paper',
                      transform: 'translateY(-50%) rotate(45deg)',
                      zIndex: 0,
                    },
                  },
                }}
                transformOrigin={{ horizontal: 'right', vertical: 'top' }}
                anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
              >
                <MenuItem>
                  <div className='header'>
                    <label>{t("Notifications")}</label></div>
                </MenuItem>
                <Divider />
                <div className='notification-container'>
                  {
                    notificationsData && notificationsData.length > 0 ?
                      notificationsData && notificationsData.map((item: any, index: any) => {
                        return (
                          index < 3 && <div key={index}>
                            <MenuItem>
                              {/* <div className='item-list' onClick={index < 3 ? (e: any) => onNotificationClick(e, item) : (e: any) => e.preventDefault()}>
                                  <div className=''>
                                    <span><CheckCircleOutlineIcon fontSize="medium" sx={{ color: '#42a4cd', mr: 1, mt: 1 }} /></span></div>
                                  <div className='list-content'>
                                    <h6>{item.studyName}</h6>
                                    <p>{t("This Study Will Expires Within")} <b>{moment(item.endDate).diff(moment(new Date()), 'days')}</b> {t("days on")} <b>{item.endDate}</b>.<b>({item.approvalStatus.name})</b></p>
                                  </div>
                                </div> */}
                              <div className='d-flex w-100'>
                                <div className='me-2 '>
                                  <CustomizedTooltip title="">
                                    <MarkEmailReadIcon
                                      sx={{ color: 'green' }}
                                    // onClick={() => handleMessageRead(index, item.id)}
                                    />
                                  </CustomizedTooltip>
                                </div>
                                <div className='notifiction-font'>
                                  <span>{item.notifications}</span>
                                </div >
                              </div>
                              <div className=''>
                                <HighlightOffIcon
                                  sx={{ color: 'red' }}
                                  onClick={() => handleMessageRead(index, item.id)}
                                />
                              </div>
                            </MenuItem>
                            <Divider />
                          </div>
                        )
                      }) : <p className='px-3 pt-3'>No notifications to display</p>
                  }
                </div>
                {notificationsData && notificationsData.length > 1 && <div className='viewAll' onClick={onViewAllClick}><a href="# " >{t("View All")}</a></div>}
              </Menu>
            </div>
            <div className='ms-4'>
              < Settings />
            </div>
            <div className='icon-buttton'>
              <IconButton
                size="large"
                aria-label="account of current user"
                aria-controls="menu-appbar"
                aria-haspopup="true"
                onClick={handleMenu}
                color="inherit"
              >
                <AccountCircle />
                {
                  <div className='user-role-align'>
                    <div className='user-alignment'>{t(user.userName)}</div>
                    <div className='roleName-align'>{t(user.role && user.role.name)}</div>
                    {/* <span>{user.firstName}</span>
                    <span>{`(${user.role.name})`}</span> */}
                    {/* <p>{user.firstName}</p>
                    <p>{`(${user.role.name})`}</p> */}
                  </div>
                }
              </IconButton>
              <Menu
                id="menu-appbar"
                anchorEl={anchorEl}
                open={Boolean(anchorEl)}
                onClose={handleClose}
                className='headerSection'
                PaperProps={{
                  elevation: 0,
                  sx: {
                    overflow: 'visible',
                    filter: 'drop-shadow(0px 2px 4px rgba(0,0,0,0.22))',
                    mt: 1.5,
                    '& .MuiAvatar-root': {
                      width: 32,
                      height: 32,
                      ml: -0.5,
                      mr: 1,
                    },
                    '&:before': {
                      content: '""',
                      display: 'block',
                      position: 'absolute',
                      top: 0,
                      right: 14,
                      width: 10,
                      height: 10,
                      bgcolor: 'background.paper',
                      transform: 'translateY(-50%) rotate(45deg)',
                      zIndex: 0,
                    },
                  },
                }}
                transformOrigin={{ horizontal: 'right', vertical: 'top' }}
                anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
              >
                <MenuItem onClick={handleClose}>
                  <div className='item_list'>
                    <div className='start-icon'>
                      <span><PersonOutlineIcon fontSize="small" sx={{ color: '#42a4cd' }} /></span>
                    </div>
                    <div className='list-content m-2'>
                      <h6>{t(user.userName)}</h6>
                      <p>{t(user.role && user.role.name)}</p>
                    </div>
                  </div>
                  {/* <span className='logout'><ExitToAppOutlinedIcon fontSize="small" sx={{ color: '#42a4cd' }} /></span> */}
                </MenuItem>
                <hr />
                <MenuItem onClick={handleLogout}><ExitToAppOutlinedIcon fontSize="small" /><span className='list-items ms-3'>{t('Log Out')}</span></MenuItem>
              </Menu>
            </div>
          </Toolbar>
        </AppBar>
        {user.userRolePrivileges?.privilegeGroups?.length > 1 && <NavBar />}
      </Box>
    </React.Fragment>
  );
}
