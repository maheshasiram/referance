import { requests } from '../../../configs/env';
import { fetch } from '../../../Constants/fetch';
import { Types } from '../reducer/Types';
import { Loader, toastAlert } from '../../../actions/actions';
import { Study } from '../Constants/DataTypes';


// Fetch All Studies

export const fetchAllStudies: any = (paylaod: any, callback: any) => {
  const url = requests.studies.fetchAllStudies
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: url,
      data: paylaod
    })
      .then((response: any) => {
        dispatch({ type: Types.FETCH_ALL_STUDIES, payload: response.data });
        if (callback) {
          callback(response.data)
        }
        dispatch(Loader(false));
      })
  }
}

export const getOrgnizationContacts: any = (orgId: number) => {
  const url = `${requests.studies.findOrgByContactID}/${orgId}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        dispatch({ type: Types.ORG_CONTACTS, payload: response.data })
        dispatch(Loader(false));
      })
  }

}

// api for study type
export const fetchStudyType: any = () => {
  const url = requests.studies.studyType
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        dispatch({ type: Types.FETCH_STUDY_TYPE, payload: response.data })
        dispatch(Loader(false));
      })
  }
}

// api for study phase
export const fetchStudyPhase: any = () => {
  const url = requests.studies.studyPhase
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        dispatch({ type: Types.FETCH_STUDY_PHASE, payload: response.data })
        dispatch(Loader(false));
      })
  }
}

// api for solutions
export const fetchAllSolutions: any = (payload: any, callback: any) => {
  const url = requests.studies.solutions
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        const _data = [...[], ...response.data]
        _data && _data.map((item: any, index: number) => {
          if (payload.solutions && payload.solutions.length > 0) {
            const _payload = payload
            _payload.solutions.map((subItem: any) => {
              if (item.id === subItem.id) {
                _data[index] = { ...item, checked: true }
              }
              return null
            })
          } else {
            _data[index] = { ...item, checked: false }
          }
          return null
        })
        dispatch({ type: Types.FETCH_ALL_SOLUTIONS, payload: _data });
        if (callback) {
          callback(response.data);
        }
        // dispatch(Loader(false));
      })
      .catch((error: any) => {

      })
  }
}

// api for approval
export const getApprovers: any = () => {
  const url = requests.studies.getApprovers
  return function (dispatch: any) {
    // dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        // const activeApprover = response.data.filter((approver: any) => approver.isActive === true)
        // dispatch({ type: Types.GET_APPROVER_LIST, payload: activeApprover })
        dispatch({ type: Types.GET_APPROVER_LIST, payload: response.data })
        // dispatch(Loader(false));
      })
  }
}

export const approve: any = (payload: any, callback: any) => {
  const url = requests.studies.approve
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: url,
      data: payload
    })
      .then((response: any) => {
        if (callback) { callback(response) }
        dispatch(Loader(false));
      })
  }
}

// api for find study details by id (edit)
export const findStudyDetailsById: any = (payload: any, callback: any) => {
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: `${requests.studies.findStudyDetailsById}?studyId=${payload.studyId}`,
    })
      .then((response: any) => {
        if (!(response.data.approver)) {
          response.data.approver = Study.approver
        }
        if (!(response.data.approver.isActive) || (response.data.approver.role.name !== "Study Approver")) {
          response.data.approver = Study.approver
        }
        if (response.data.labExist) {
          response.data.labExist = response.data.labExist ? 'true' : 'false'
        }
        dispatch({ type: Types.UPDATED_FIELD_VALUES, payload: response.data })
        dispatch({ type: Types.GET_STUDY_DETAILS, payload: response.data })
        dispatch({ type: Types.CHANGE_ACTION_TYPE, payload: 'edit' })
        dispatch(getOrgnizationContacts(response.data.organization.id))
        dispatch(fetchAllSolutions(response.data))
        if (callback) {
          callback(response.data)
          // dispatch(Loader(false));
        }
      }).catch((error) => { console.log("error", error) })
  }
}


// api for delete study
export const deleteStudyById: any = (payload: any, callback: any) => {
  const url = `${requests.studies.deleteStudyById}?studyId=${payload.studyId}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: url,
      data: null
    }).then((response: any) => {
      callback(response.data);
      dispatch(Loader(false))
    }).catch((error) => { console.log("error", error) })
  }
}

export const uploadStudyDocuments: any = (payload: any, callback: any) => {
  return function (dispatch: any) {
    dispatch(Loader(true))
    const url = payload[0].endpoint;
    const formData = new FormData();
    formData.append("userDocuments", payload[0].value)
    fetch({
      method: 'POST',
      url: url,
      data: formData,
      headers: {
        "Accept": "*/*",
        "Content-Type": "multipart/form-data"
      }
    }).then((response: any) => {
      console.log('response...',)
      dispatch(Loader(false))
      dispatch(toastAlert({
        status: 1,
        // message: toastMsg(response.errorMessage, ''),
        message: 'Study documents uploaded successfully',
        open: true
      }))
      if (callback) { callback(response.data) }
    })
      .catch((error: any) => {
        dispatch(toastAlert({
          status: 0,
          // message: toastMsg(response.errorMessage, ''),
          message: 'Study documents upload failed',
          open: true
        }))
      })
  }
}

// api for save study
export const saveStudy: any = (payload: any, deletedStudyDocuments: any, callback: any) => {
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: requests.studies.saveStudy,
      data: payload,
    })
      .then((response: any) => {
        callback(response.data);
        if (deletedStudyDocuments?.length > 0) {
          deletedStudyDocuments.map((docId: any) => {
            return dispatch(deleteStudyDocument(docId));
          });
        }
        const endpoints: any = [];
        if (payload?.studyItems?.length > 0 && !response.data.errorCode) {
          const _payload = payload
          _payload.studyItems.map((file: any) => {
            if (file?.documentTypeId !== '' && file?.value !== '') {
              const endpoint = `${requests.studies.uploadStudyDocuments}?studyId=${response.data.id}&documentTypeId=${file.documentTypeId}`
              endpoints.push({ endpoint, value: file.value });
            }
            return null
          })
          dispatch(uploadStudyDocuments(endpoints, () => {
            dispatch(Loader(false));
          }))
        } else {
          callback(response.data);
          dispatch(Loader(false));
        }
        dispatch({ type: Types.DELETED_STUDY_DOCUMENTS, payload: [] });
      }).catch((error) => {
        console.log("error", error);
      })
  }
}

//api for upload study document
// export const uploadDocuments: any = (payload: any, callback: any) => {
//   return function (dispatch: any) {
//     dispatch(Loader(true));
//     const _payload = payload
//     axios.all(_payload.forEach((item: any) => {
//       if (item.value !== '') {
//         const formData = new FormData();
//         formData.append("userDocuments", item.value);
//         return fetch({
//           method: 'POST',
//           url: item.endpoint,
//           data: formData,
//           headers: {
//             "Accept": "*/*",
//             "Content-Type": "multipart/form-data"
//           }
//         })
//       }
//     })).then(() => {
//       callback();
//     })
//   }
// }


// api for submit study
export const submitStudy: any = (payload: any, deletedStudyDocuments: any, callback: any) => {
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: requests.studies.submitStudy,
      data: payload,
    })
      .then((response: any) => {
        //Added condition for solving runtime error on submit study -Akshay
        if (callback) { callback(response.data) }
        if (deletedStudyDocuments.length > 0) {
          deletedStudyDocuments.map((docId: any) => {
            dispatch(deleteStudyDocument(docId));
            return null
          });
        }
        const endpoints: any = [];
        const _payload = payload
        if (_payload.studyItems.length > 0 && _payload.studyItems[0].documentTypeId !== "" && !response.data.errorCode) {
          _payload.studyItems.map((file: any) => {
            const endpoint = `${requests.studies.uploadStudyDocuments}?studyId=${response.data.id}&documentTypeId=${file.documentTypeId}`
            endpoints.push({ endpoint, value: file.value });
            return null
          })
          dispatch(uploadStudyDocuments(endpoints, () => {
            // callback(response.data);
            dispatch(Loader(false));
          }))
        } else {
          callback(response.data);
          dispatch(Loader(false));
        }
        dispatch({ type: Types.DELETED_STUDY_DOCUMENTS, payload: [] });
      }).catch((error) => {
        console.log("error", error)
      })
  }
}





// api for re-submit
export const reSubmitStudy: any = (payload: any, deletedStudyDocuments: any, callback: any) => {
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: requests.studies.reSubmit,
      data: payload,
    })
      .then((response: any) => {
        if (callback) { callback(response.data) }
        if (deletedStudyDocuments.length > 0) {
          deletedStudyDocuments.map((docId: any) => {
            dispatch(deleteStudyDocument(docId));
            return null
          });
        }
        const endpoints: any = [];
        const _payload = payload
        if (_payload.studyItems.length > 0 && _payload.studyItems[0].documentTypeId !== "" && !response.data.errorCode) {
          _payload.studyItems.map((file: any) => {
            const endpoint = `${requests.studies.uploadStudyDocuments}?studyId=${response.data.id}&documentTypeId=${file.documentTypeId}`
            endpoints.push({ endpoint, value: file.value });
            return null
          })
          dispatch(uploadStudyDocuments(endpoints, () => {
            callback(response.data);
            dispatch(Loader(false));
          }))
        } else {
          callback(response.data);
          dispatch(Loader(false));
        }
        dispatch({ type: Types.DELETED_STUDY_DOCUMENTS, payload: [] });
      })
      .catch(() => {
        dispatch(Loader(false));
        // dispatch(Alert({message:'Something went wrong.Please try after some time',onOk:()=>{}}))
      })
  }
}


//  GET STUDIES BY USER
export const findstudiesByUser: any = (payload: any, callback: any) => {
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: requests.studies.findAllStudiesByLoggedInUser,
      data: payload
    })
      .then((response: any) => {
        if (callback) {
          callback(response.data);
        }
        dispatch({ type: Types.FETCH_ALL_STUDIES, payload: response.data });
        dispatch(Loader(false));
      }).catch((error) => {
        console.log("error", error)
      })
  }
}

export const getUserByUserName: any = (userName: number, callback: any) => {
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: `${requests.users.getUserByUserName}?userName=${userName}`
    })
      .then((response: any) => {
        callback(response.data);
        dispatch(Loader(false));
      }).catch((err: any) => {
        console.log("error", err)
        dispatch(Loader(false));
        callback(err.response.data);
      })
  }
}

export const fetchTransactionForStudy: any = (payload: any) => {
  const url = `${requests.studies.fetchTransactionForStudy}?studyId=${payload.studyId}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: null,
    })
      .then((response: any) => {
        dispatch({ type: Types.GET_TRANSACTIONS_DETAILS, payload: response.data })
        dispatch(Loader(false));
      }).catch((error: any) => {
        console.log('error', error)
      })
  }
}

export const findAllStudiesByStatus: any = (payload: any) => {
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: `${requests.studies.findAllStudiesByStatus}?studyStatus=${payload}`,
    })
      .then((response: any) => {
        dispatch({ type: Types.FETCH_ALL_STUDIES, payload: response.data })
        dispatch(Loader(false));
      }).catch((error: any) => {
        console.log('error', error)
      })
  }
}

// any for updating the Data When back from organizations
export const updateStudyPayload: any = (payload: any) => {
  return (dispatch: any) => {
    dispatch({ type: Types.CREATE_OR_EDIT_STUDY, payload: payload })
  }
}

// api for add contacts....
export const addStudyContact: any = (payload: any, callback: any) => {
  const url = requests.studies.addNewContactDetails
  return function () {
    fetch({
      method: 'POST',
      url: url,
      data: payload,
    })
      .then((response: any) => {
        // dispatch(getOrgnizationContacts(response.data.organizationId));
        callback(response.data);
      }).catch((error: any) => {
        console.log('error', error)
      })

  }
}

export const getConfigdataByCode: any = (code: string, callback: any) => {
  return function () {
    fetch({
      method: 'GET',
      url: `${requests.config.getByCode}/${code}`,
    })
      .then((response: any) => {
        callback(response.data);
      }).catch((error: any) => {
        console.log('error', error)
      })

  }
}
export const getDataByTypeCode: any = (code: string) => {
  return function (dispatch: any) {
    dispatch(Loader(true))
    fetch({
      method: 'GET',
      url: `${requests.config.getByTypeCode}/${code}`,
    })
      .then((response: any) => {
        dispatch({ type: Types.GET_WF_STATUS_TYPE, payload: response.data })
        // dispatch({ type: Types.STUDY_CONTACT_TYPE, payload: response.data })
        // dispatch(Loader(false))
      }).catch((error: any) => {
        console.log('error', error)
      })

  }
}

export const getContactDataByTypeCode: any = (code: string) => {
  return function (dispatch: any) {
    dispatch(Loader(true))
    fetch({
      method: 'GET',
      url: `${requests.config.getByTypeCode}/${code}`,
    })
      .then((response: any) => {
        dispatch({ type: Types.STUDY_CONTACT_TYPE, payload: response.data })
        dispatch(Loader(false))
      }).catch((error: any) => {
        console.log('error', error)
      })

  }
}

//  DOWNLOAD STUDIES DOCUMENTS
export const downloadStudyDocument: any = (documentId: number, fileName: string) => {
  return function (dispatch: any) {
    dispatch(Loader(true))
    fetch({
      method: 'GET',
      url: `${requests.studies.downloadDocument}${documentId}`,
      responseType: 'blob',
    })
      .then((blob: any) => {
        // 2. Create blob link to download     
        const url = window.URL.createObjectURL(new Blob([blob.data]));
        const link: any = document.createElement('a');
        link.href = url;
        link.setAttribute('download', `${fileName}`);
        // 3. Append to html page
        document.body.appendChild(link);
        // 4. Force download
        link.click();
        // 5. Clean up and remove the link
        // link.parentNode.removeChild(link);
        dispatch(Loader(false));
      }).catch((error: any) => {
        console.log('error', error)
      })
  }
}

//DELETE STUDY DOCUMENT  
export const deleteStudyDocument: any = (documentId: number, callback: any) => {
  return function (dispatch: any) {
    dispatch(Loader(true))
    fetch({
      method: 'DELETE',
      url: `${requests.studies.deleteDocument}${documentId}`,
    })
      .then((response) => {
        if (callback) {
          callback(response.data);
          dispatch(Loader(false));
          dispatch(toastAlert({
            status: 1,
            message: 'Study documents deleted successfully',
            open: true
          }))
        }
      }).catch((error: any) => {
        console.log('error', error)
        dispatch(toastAlert({
          status: 1,
          message: 'Study documents delete failed',
          open: true
        }))
      })
  }
}

// activate study api
export const activateByStudyId: any = (payload: any, callback: any) => {
  const url = `${requests.studies.activateByStudyId}?studyId=${payload}`
  return function () {
    fetch({
      method: 'POST',
      url: url,
      data: '',
    })
      .then((response) => {
        if (callback) { callback(response.data) }
      }).catch((error: any) => {
        console.log('error', error)
      })
  }
}