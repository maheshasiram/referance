
import { Types } from "./Types";
import { Study, StudyContactModel, initialCreateStudy, studyPayloadModel, studydownload } from '../Constants/DataTypes'
import _ from 'lodash';

const initialState = {
    studyDetails: Study,
    studyTypes: null,
    studyPhases: null,
    allSolutions: null,
    approveList: null,
    studyContact: StudyContactModel,
    extendValue: sessionStorage.getItem('extend') ? true : false,
    studies: null,
    studiesCopy: null,
    studyStatusTypes: null,
    viewStudyDetails: Study,
    adminRole: false,
    initialCreateStudy: initialCreateStudy,
    actionType: 'create',
    contactDetails: null,
    transactionDetails: '',
    createStudyPayload: null,
    updatedFieldValues: Study,
    deletedStudyDocuments: null,
    studyPayload: studyPayloadModel,
    studyDetailsdownload: studydownload,
    studyContactType: null
}

export const study = (state = initialState, action: { type: any, payload: any }) => {
    switch (action.type) {
        case Types.STUDY_CONTACT_TYPE:
            return { ...state, studyContactType: action.payload }
        case Types.INITIATE_NEW_STUDAY:
            return { ...state, studyDetails: action.payload }
        case Types.GET_WF_STATUS_TYPE:
            return { ...state, studyStatusTypes: action.payload }
        case Types.UPDATE_CONTACT_TYPE_CLINICAL_TRAILS:
            return { ...state, studyContact: { ...state.studyContact, contactType: action.payload } }
        case Types.FETCH_ALL_STUDIES:
            return {
                ...state,
                studies: action.payload,
                studiesCopy: _.cloneDeep(action.payload)
            }
        case Types.CREATE_OR_EDIT_STUDY:
            return { ...state, studyDetails: action.payload }
        case Types.FETCH_STUDY_TYPE:
            return { ...state, studyTypes: action.payload }
        case Types.FETCH_STUDY_PHASE:
            return { ...state, studyPhases: action.payload }
        case Types.FETCH_ALL_SOLUTIONS:
            return { ...state, allSolutions: action.payload }
        case Types.GET_APPROVER_LIST:
            return { ...state, approveList: action.payload }
        case Types.ADD_CONTACT_DETAILS:
            return { ...state, studyContact: action.payload }
        case Types.ON_EXTEND_CLICK:
            return { ...state, extendValue: action.payload }
        case Types.VIEW_STUDY_DETAILS:
            return { ...state, viewStudyDetails: action.payload }
        case Types.CHANGE_ACTION_TYPE:
            return { ...state, actionType: action.payload }
        case Types.ORG_CONTACTS:
            return { ...state, contactDetails: action.payload }
        case Types.SAVE_STUDY_DATA:
            return { ...state, studyData: action.payload }
        case Types.UPDATE_STUDY_DATA:
            return { ...state, initialCreateStudy: action.payload }
        case Types.GET_STUDY_DETAILS:
            return {
                ...state,
                studyDetails: { ...action.payload, studyItems: [{ value: "", documentTypeId: "" }] }
            }
        case Types.GET_TRANSACTIONS_DETAILS:
            return { ...state, transactionDetails: action.payload }
        case Types.CREATE_STUDY_PAYLOAD:
            return { ...state, createStudyPayload: action.payload }
        case Types.FILTERED_STUDIES:
            return { ...state, studies: action.payload }
        case Types.UPDATED_FIELD_VALUES:
            return { ...state, updatedFieldValues: action.payload }
        case Types.DELETED_STUDY_DOCUMENTS:
            return { ...state, deletedStudyDocuments: action.payload }
        case Types.STUDY_DETAILS_DOWNLOAD:
            return { ...state, studyDetailsdownload: action.payload }
        case Types.STUDY_PAYLOAD:
            return { ...state, studyPayload: action.payload }
        default:
            return { ...state }
    }
}