import { CreateStudy, addContacts, studyDownloadType } from '../Constants/Types';

export const initialCreateStudy = {
  studyName: '',
  startDate: '',
  endDate: '',
  // protocolId: '',
  studyType: '',
  organization: '',
  studyPhase: '',
  approver: '',
  comments: '',
  primaryContact: '',
  solutions: [],
  signOffDocument: [{ value: "" }],
  secondaryContactOption: '',
  secondaryContact: [],
  afterApproved: {
    dbName: '',
    portId: '',
    hostedRegion: '',
    cloudedProvider: '',
    edcUrl: ''
  }
}
export const Study: CreateStudy = {
  id: 0,
  labExist: "",
  studyName: "",
  visitsCount: '',
  subjectSampleSize: '',
  // protocolTitle: '',
  therapeuticArea: {
    id: '',
    name: "",
    code: "",
    description: "",
    configDataType: {
      id: 0,
      name: "",
      code: "",
      description: ""
    }
  },
  indication: {
    id: '',
    name: "",
    code: "",
    description: "",
    configDataType: {
      id: 0,
      name: "",
      code: "",
      description: ""
    }
  },
  studyDesign: {
    id: '',
    name: "",
    code: "",
    description: "",
    configDataType: {
      id: 0,
      name: "",
      code: "",
      description: ""
    }
  },
  regulatory: {
    id: '',
    name: "",
    code: "",
    description: "",
    configDataType: {
      id: 0,
      name: "",
      code: "",
      description: ""
    }
  },
  investigation: {
    id: '',
    name: "",
    code: "",
    description: "",
    configDataType: {
      id: 0,
      name: "",
      code: "",
      description: ""
    }
  },
  populations: {
    id: '',
    name: "",
    code: "",
    description: "",
    configDataType: {
      id: 0,
      name: "",
      code: "",
      description: ""
    }
  },
  organization: {
    id: '',
    orgName: "",
    addressLine1: "",
    addressLine2: "",
    city: {
      id: NaN,
      name: "",
      state: {
        id: NaN,
        name: "",
        country: {
          id: NaN,
          name: "",
          countryCode: "",
          phoneCode: NaN
        }
      }
    },
    state: {
      id: NaN,
      name: "",
      country: {
        id: NaN,
        name: "",
        countryCode: "",
        phoneCode: NaN
      }
    },
    country: {
      id: NaN,
      name: "",
      countryCode: "",
      phoneCode: NaN
    },
    postalZipCode: "",
    phone: "",
    companyUrl: "",
    passcode: "",
    isActive: true,
    orgContacts: [],
    orgDocuments: [],
    orgType: null,
    orgShortname: "",
    telephone: "",
  },
  ctPhase: {
    id: '',
    name: "",
    code: "",
    description: "",
    configDataType: {
      id: NaN,
      name: "",
      code: "",
      description: ""
    }
  },
  approvalStatus: {
    id: '',
    name: "",
    code: "",
    description: "",
    configDataType: {
      "id": 0,
      name: "",
      code: "",
      description: ""
    }
  },
  startDate: '',
  endDate: '',
  studySchema: "",
  request: null,
  approver: {
    userId: '',
    userName: '',
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    timeZone: '',
    lastActiveDate: '',
    isActive: true,
    comments: '',
    createdBy: '',
    createdOn: '',
    updatedBy: NaN,
    updatedOn: '',
    role: {
      id: NaN,
      name: '',
      code: '',
      description: '',
      configDataType: {
        id: NaN,
        name: '',
        code: '',
        description: ''
      }
    },
    roleId: NaN,
    country: {
      id: NaN,
      name: '',
      countryCode: '',
      phoneCode: NaN,
    },
    userDocuments: []
  },
  studyType: {
    id: '',
    name: '',
    code: '',
    description: '',
    configDataType: {
      id: NaN,
      name: '',
      code: '',
      description: ''
    }
  },
  edcSolutions: [],
  solutions: [],
  protocolId: '',
  comments: '',
  studyDocuments: [{ value: "", documentTypeId: "" }],
  studyContacts: [
    {
      id: 0,
      organizationId: 0,
      firstName: "",
      lastName: "",
      orgName: "",
      email: "",
      phoneNo: "",
      contactDesgn: "",
      contactType: null,
      active: true,
      userName: "",
      studyId: 0
    }
  ],
  studyItems: [{ value: "", documentTypeId: "" }],
  studyStatus: true,
  studyAdmin: "",
}

export const StudyContactModel: addContacts = {
  id: 0,
  organizationId: NaN,
  firstName: '',
  lastName: '',
  email: '',
  phoneNo: '',
  contactDesgn: '',
  // contactType: {
  //   id: 44,
  //   name: "Others Contact",
  //   code: "CONTACT_TYPE_OTHERS_CONTACT",
  //   description: "Others Contact For Organization",
  //   configDataType: {
  //     id: 13,
  //     name: "Contact Type",
  //     code: "CONTACT_TYPE",
  //     description: "descrides Contact Types"
  //   }
  // },
  contactType: {
    id: 58,
    name: 'Other',
    code: 'CONTACT_TYPE_OTHERS_CONTACT',
    description: 'Other Contact',
    configDataType: {
      id: 13,
      name: 'Contact Type',
      code: 'CONTACT_TYPE',
      description: 'describes Contact Types'
    }
  },
  active: true

}
export const studyConfigDataCodes = [
  'STUDY_TYPE',
  "INDICATION",
  "STUDY_DESIGN",
  "REGULATORY",
  "INVESTIGATION",
  'STUDY_PHASE',
  'THERAPEUTIC',
  'POPULATION',
  'EDC_MODULES'
]


export const studyPayloadModel = {
  "limit": 10,
  "offset": 0,
  "protocolId": '',
  "studyPhase": '',
  "userId": 0,
  "approvalStatus": '',
  "studyStatus": true,
  "isStudyApprover": true
}

export const studydownload: studyDownloadType = {
  "fileType": "",
  "reportName": "Study Details",
  "columnNames": [
    "Protocol ID", "Sponsor", "Study Phase", "Request By", "Start Date", "End Date", "Status"
  ],
  "searchColumns": {
    "userId": "",
    "protocolId": "",
    "studyPhase": "",
    "approvalStatus": "",
    "studyStatus": true
  }
}