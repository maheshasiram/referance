

type country = {
    id?: number,
    name?: string,
    countryCode?: string,
    phoneCode?: number
}

type state = {
    id?: number,
    name?: string,
    country?: country,
}

type city = {
    id?: number,
    name?: string,
    state?: state
}

type configStructure = {
    // id?: Number_nullable<number>
    id?: any
    name?: string
    code?: string
    description?: string
    configDataType?: configDataType

}

type organization = {
    id?: any,
    orgName?: string,
    addressLine1?: string,
    addressLine2?: string,
    city?: city,
    state?: state,
    country?: country,
    postalZipCode?: string,
    phone?: string,
    companyUrl?: string,
    passcode?: string,
    isActive?: boolean,
    orgContacts?: [],
    orgDocuments?: [],
    orgType?: any,
    orgShortname?: string,
    telephone?: string
}
type configDataType = {
    id?: number
    name?: string
    code?: string
    description?: string

}
// type orgContacts =
//     [{
//         id?: number,
//         organizationId?: number,
//         contactDesgn?: string
//         contactType?: configStructure
//         email?: string
//         firstName?: string
//         lastName?: string
//         phoneNo?: string
//         active?: boolean
//     }]

type primaryContact = {
    id?: number,
    organizationId?: number,
    firstName?: string,
    lastName?: string,
    email?: string,
    phoneNo?: string,
    contactDesgn?: string,
    contactType?: configStructure,
    active?: boolean
}

type secondaryContact = {
    id?: any,
    organizationId?: number,
    firstName?: string,
    lastName?: string,
    email?: string,
    phoneNo?: string,
    contactDesgn?: string,
    contactType?: configStructure,
    active?: boolean
}

// type request = {
//     id?: number,
//     reqObjectId?: configStructure,
//     reqWfStatusId?: configStructure,
//     completedOn?: string,
//     completedBy?: number
// }

// type documents = [
//     {

//         id?: number,
//         fileName?: string,
//         fileContentType?: string,
//         user?: string,
//         documentType: {
//             id?: number,
//             name?: string,
//             code?: string,
//             description?: string,
//             configDataType?: {
//                 id?: number,
//                 name?: string,
//                 code?: string,
//                 description?: string
//             }
//         }

//     }
// ]

type approver = {
    userId?: any,
    userName?: string,
    firstName?: string,
    lastName?: string,
    email?: string,
    phone?: string,
    timeZone?: string,
    lastActiveDate?: string,
    isActive?: boolean,
    comments?: string,
    createdBy?: string,
    createdOn?: string,
    updatedBy?: number,
    updatedOn?: string,
    role?: configStructure,
    roleId?: number,
    country?: country,
    userDocuments?: []
}


// type Number_nullable<T> = T | null

// type contactType = {
//     id?: number
//     name?: string
//     code?: string
//     description?: string
//     configDataType?: configDataType

// }

type commonStructure = {
    id?: any,
    name?: string,
    code?: string,
    description?: string,
    configDataType: {
        id?: number,
        name?: string,
        code?: string,
        description?: string
    }
}

type studyContacts = [
    {
        id?: any,
        organizationId?: any,
        firstName?: string,
        lastName?: string,
        email?: string,
        phoneNo?: string,
        contactDesgn?: string,
        contactType?: any,
        orgName?:string,
        // contactType: {
        //     id?: any,
        //     name?: string,
        //     code?: any,
        //     description?: string,
        //     configDataType: {
        //         id?: any,
        //         name?: string,
        //         code?: string,
        //         description?: string
        //     }
        // },
        active?: boolean,
        userName?: string,
        studyId?: number
    }
]

export type CreateStudy = {
    id?: number,
    labExist?:any,
    studyName?: string,
    visitsCount?: string,
    subjectSampleSize?: string,
    // protocolTitle?: string,
    therapeuticArea?: commonStructure,
    indication?: commonStructure,
    studyDesign?: commonStructure,
    regulatory?: commonStructure,
    investigation?: commonStructure,
    populations?: commonStructure,
    organization?: organization,
    ctPhase?: configStructure,
    approvalStatus?: any,
    startDate?: string,
    endDate?: string,
    studySchema?: string,
    // studyContact: [
    //     {
    //         id?: any,
    //         organizationId?: number,
    //         firstName?: string,
    //         lastName?: string,
    //         email?: string,
    //         phoneNo?: string,
    //         contactDesgn?: string,
    //         contactType?: contactType,
    //         active?: boolean
    //     }
    // ],
    primaryContact?: primaryContact,
    secondaryContact?: secondaryContact,
    request?: null,
    approver?: approver,
    studyType?: configStructure,
    edcSolutions?: [],
    solutions?: [],
    protocolId?: any,
    comments?: string,
    studyDocuments: any,
    studyContacts: studyContacts,
    studyItems?: any,
    studyStatus?: boolean,
    studyAdmin?: string
}

export type addContacts = {
    id?: number
    organizationId?: number
    firstName?: string
    lastName?: string
    email?: string
    phoneNo?: string
    contactDesgn?: string
    contactType: {
        id?: number
        name?: string
        code?: string
        description?: string
        configDataType: {
            id?: number
            name?: string
            code?: string
            description?: string
        }
    },
    active?: boolean
}
export type studyDownloadType = {
    fileType?: string,
    reportName?: string,
    columnNames?: any,
    searchColumns: {
        userId?: any,
        protocolId?: any,
        studyPhase?: string,
        approvalStatus?: any,
        studyStatus?: boolean
    }
}
