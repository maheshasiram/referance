import * as Yup from 'yup';
import { useTranslation } from 'react-i18next';

export const CreateStudySchema = () => {
    const { t } = useTranslation();

    return Yup.object().shape({
        studyName: Yup.string()
            .required(t('Please enter Protocol Title')),
        startDate: Yup.string()
            .required(t('Please Enter Start Date')),
        visitsCount: Yup.string().max(7, 'Too Long!').matches(/^[1-9][0-9]*$/, t("Should not start with 0"))
            .required(t('Please Enter Visits Count')),
        labExist: Yup.string().required('Please select Dose this Study related to lab or not'),
        subjectSampleSize: Yup.string().max(7, 'Too Long!').matches(/^[1-9][0-9]*$/, t("Should not start with 0"))
            .required(t('Please Enter SampleSize')),
        endDate: Yup.string()
            .required(t("Please Enter End Date")),
        protocolId: Yup.string().max(20, 'Too Long!')
            .required(t('Please Enter Protocol Id')),
        // .matches(/^[a-zA-Z0-9]+$/, "Special Characters And Spaces Are Not Allowed"),
        // protocolTitle: Yup.string()
        //     .required(t('Please Enter protocol Title'))
        //     .matches(/^[^\s]/, t("Protocol Title should not start with space")),

        studyType: Yup.object().shape({
            name: Yup.string()
                .required(t("Please Select Study Type"))
        }),
        ctPhase: Yup.object().shape({
            name: Yup.string()
                .required(t("Please Select Study Phase"))
        }),
        organization: Yup.object().shape({
            orgName: Yup.string()
                .required(t('Please Select Sponser/CRO'))
        }),
        therapeuticArea: Yup.object().shape({
            name: Yup.string()
                .required(t("Please Select Therapeutic Area "))
        }),
        indication: Yup.object().shape({
            name: Yup.string()
                .required(t("Please Select Indication"))
        }),
        studyDesign: Yup.object().shape({
            name: Yup.string()
                .required(t("Please Select Study Design"))
        }),
        regulatory: Yup.object().shape({
            name: Yup.string()
                .required(t("Please Select Regulatory"))
        }),
        investigation: Yup.object().shape({
            name: Yup.string()
                .required(t("Please Select Investigation"))
        }),
        populations: Yup.object().shape({
            name: Yup.string()
                .required(t("Please Select Populations"))
        }),
        approver: Yup.object().shape({
            userName: Yup.string().required(t('Please Select Approver'))
        }),
        studyContacts: Yup.array().of(Yup.object({

            // defaultValue: variableData?.datatype?.code === "DATA_TYP_REAL" ? 
            // Yup.string().matches(/^[0-9]*\./, 'Please Enter  Value') : Yup.string(),

            userName: Yup.string().required(t('Please enter Primary Admin User ID')).nullable()
                .matches(/^[^\s]/, t("admin Id should not start with space")).nullable(),
            email: Yup.string()
                .email(t('Please Enter Valid Email Address')).nullable()
                .required(t("Please Enter Email"))
                .nullable(),
            firstName: Yup.string()
                .required(t('Please Enter First Name')).nullable()
                .matches(/^[^\s]/, t("First name should not start with space")).nullable()
                .matches(/^[^\d]+$/, t("First name should not contain numbers")).nullable()
                .matches(/^[^*|":<>[\]{}`\\()';@&$#!%]+$/, t('First name should not contain special characters')).nullable(),
            lastName: Yup.string()
                .required(t('Please Enter Last Name')).nullable()
                .matches(/^[^\s]/, t("Last name should not start with space")).nullable()
                .matches(/^[^\d]+$/, t("Last name should not contain numbers")).nullable()
                .matches(/^[^*|":<>[\]{}`\\()';@&$#!%]+$/, t("Last name should not contain special characters")),
            phoneNo: Yup.string()
                .required(t('Please Enter Phone Number')).nullable(),
            orgName: Yup.string()
                .required(t('Please enter orginzation Name')).nullable()
        }
        )),
        // primaryContact: Yup.object().shape({
        //     firstName: Yup.string()
        //         .required(t("Please Select Primary Contact"))
        // }),
        // secondaryContact: Yup.object().shape({
        //     firstName: Yup.string()
        //         .required(t("Please Select Secondary Contact"))
        // }),
        solutions: Yup.array()
            .min(1, t("Please select at least one Application tool"))
            .required(t("Required")),
        // documents: Yup.array()
        //     .of(
        //         Yup.object().shape({
        //             value: Yup.string()
        //                 .required('Please Upload SignOff Document'),
        //             documentTypeId: Yup.string()
        //                 .required('Please Select Document Type Id')
        //         })
        //     )
        // studyDocuments: Yup.array()
        //     .of(
        //         Yup.object().shape({
        //             value: Yup.string()
        //                 .required('Please Upload SignOff Document'),
        //             documentTypeId: Yup.string()
        //                 .required('Please Select Document Type Id')
        //         })
        //     )

    })
}

export const StudyContactSchema = () => {
    const { t } = useTranslation();
    return Yup.object().shape({
        firstName: Yup.string()
            .required(t('Please Enter First Name'))
            .matches(/^[^\s]/, t("First name should not start with space"))
            .matches(/^[^\d]+$/, t("First name should not contain numbers"))
            .matches(/^[^*|":<>[\]{}`\\()';@&$#!%]+$/, t('First name should not contain special characters')),
        lastName: Yup.string()
            .required(t('Please Enter Last Name'))
            .matches(/^[^\s]/, t("Last name should not start with space"))
            .matches(/^[^\d]+$/, t("Last name should not contain numbers"))
            .matches(/^[^*|":<>[\]{}`\\()';@&$#!%]+$/, t('Last name should not contain special characters')),
        email: Yup.string()
            .required(t('Please Enter Email'))
            .email(t('Please Enter Valid Email Address')),
        phoneNo: Yup.string()
            .required(t('Please Enter Phone Number'))
            .matches(/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/, t('Please Enter Valid Phone Number')),
    })
}
