import React from 'react';
import CommonCard from '../../../Common/CommonCard';
import TransactionHistory from '../CreateStudy/TranscationHistory/TranscaionHistory';
import { approve, getDataByTypeCode, findStudyDetailsById } from '../Actions/actions';
import { useDispatch, useSelector } from 'react-redux';
import '../style.scss';
import { Confirm, toastAlert } from '../../../actions/actions';
import { useNavigate, useParams } from "react-router-dom";
import { Types } from '../reducer/Types';
import ViewDocuments from '../CreateStudy/AdditionalDetails/ViewDocuments';
import { messages } from '../../../configs/messages';
import KeyboardDoubleArrowLeftIcon from '@mui/icons-material/KeyboardDoubleArrowLeft';
import { Types as constTypes } from "../../../Constants/Types";
import '../../devops/styles/styles.scss'

function ApproveStudy() {
  const navigate = useNavigate()
  const dispatch = useDispatch();
  const params = useParams();
  const [studyDetails, setStudyDetails] = React.useState('');
  const { viewStudyDetails } = useSelector((state: any) => state.study);
  const { config, user,allConFigData } = useSelector((state: any) => state.app);
  const loaded = React.useRef(false);
  const [comments, setComments] = React.useState('');

  React.useEffect(() => {
    if (!loaded.current) {
      dispatch(getDataByTypeCode(config.WF_STATUS_TYPE));
      if (params && params.id) {
        dispatch(findStudyDetailsById({ studyId: params.id }, (response: any) => {
          setStudyDetails(response);
          dispatch({ type: Types.VIEW_STUDY_DETAILS, payload: response })
        }))
      }
      loaded.current = true
    }
  }, [params, dispatch, config.WF_STATUS_TYPE])
  React.useEffect(() => {
    setComments(viewStudyDetails?.comments)
  }, [viewStudyDetails?.comments])

  const onSubmitHandler = (e: any, type: string) => {
    const approvePayload = { "comments": comments, "decision": type, "studyId": viewStudyDetails.id }
    dispatch(Confirm({
      status: 0,
      message: `Are you sure you want to ${type === allConFigData?.Approved ? "approve " : type === allConFigData?.Rejected ? 'reject ' : type === allConFigData?.Hold ? 'hold ' : ''}this study?`,
      onOk: () => {
        dispatch(approve(approvePayload, (response: any) => {
          dispatch(toastAlert({
            status: !response.errorMessage ? 1 : 2,
            message: !response.errorMessage && type === allConFigData?.Approved? messages.study.studyApproved :
              type === allConFigData?.Rejected ? messages.study.studyRejected : type === allConFigData?.Hold ? messages.study.studyHold : response.errorMessage,
            open: true
          }));
          navigate('/dashboard');
        }))
      }
    }))

  }
  const onBackToStudies = () => {
    navigate('/dashboard');
    dispatch({ type: Types.DELETED_STUDY_DOCUMENTS, payload: [] });
    dispatch({ type: constTypes.CONFIG_DATA, payload: {} })
  }

  return (
    <React.Fragment>
      <CommonCard title='Approve Study'>
        {
          (user.userName === viewStudyDetails?.approver?.userName) ?
            (studyDetails && viewStudyDetails) &&
            <div className="devops-container">
              <div className="sub-container">
                <div className='d-flex justify-content-between align-items-center mx-4'>
                  <div><h6>Study Details</h6></div>
                  <div className='d-flex align-items-center'>
                    <TransactionHistory studyId={viewStudyDetails.id} studyName={viewStudyDetails.studyName} />
                    <div className="backto-studies">
                      <span onClick={onBackToStudies}><KeyboardDoubleArrowLeftIcon /> Back To Studies</span>
                    </div>
                  </div>
                </div>

                <hr className='my-0 mx-3'></hr>
                <div className='AapproveStudy'>
                  <div className='w-100 m-3 bodylabdata'>
                    <div className='row'>
                      <div className='col-sm-6'>
                        <div className='label-data-div'>
                          <span className='rightlabelStyle'>Protocol ID</span> :<span className='ms-2'>{viewStudyDetails?.protocolId}</span>
                        </div>
                        <div className='label-data-div'>
                          <span className='rightlabelStyle'>Protocol Title</span>:<span className='ms-2'>{viewStudyDetails?.studyName} </span>
                        </div>
                        <div className='label-data-div'>
                          <span className='rightlabelStyle'>Therapeutic Area</span> :<span className='ms-2'>{viewStudyDetails?.therapeuticArea.name}</span>
                        </div>
                        <div className='label-data-div'>
                          <span className='rightlabelStyle'>Indication</span>: <span className='ms-2'>{viewStudyDetails?.indication?.name}</span>
                        </div>
                        <div className='label-data-div'>
                          <span className='rightlabelStyle'>Study Design</span>: <span className='ms-2'>{viewStudyDetails?.studyDesign?.name}</span>
                        </div>
                        <div className='label-data-div '>
                          <span className='rightlabelStyle'>Study Phase</span>: <span className='ms-2'>{viewStudyDetails?.ctPhase.name} </span>
                        </div>
                        <div className='label-data-div '>
                          <span className='rightlabelStyle'>Study Type</span>:<span className='ms-2'>{viewStudyDetails?.studyType.name} </span>
                        </div>
                        <div className='label-data-div '>
                          <span className='rightlabelStyle'>Documents</span>:<span className='ms-2'>
                            <ViewDocuments
                              values={viewStudyDetails}
                              documents={viewStudyDetails?.studyDocuments}
                              isDelete={false}
                            />
                          </span>
                        </div>
                      </div>
                      <div className='col-sm-6'>

                        <div className='label-data-div w-100'>
                          <span className='rightlabelStyle'>Regulatory</span> :<span className='ms-2'>{viewStudyDetails?.regulatory?.name}
                          </span>
                        </div>
                        <div className='label-data-div w-100'>
                          <span className='rightlabelStyle'>Start Date</span> :<span className='ms-2'>{viewStudyDetails?.startDate}
                          </span>
                        </div>
                        <div className='label-data-div w-100'>
                          <span className='rightlabelStyle'>End Date</span> :<span className='ms-2'>{viewStudyDetails?.endDate}
                          </span>
                        </div>
                        <div className='label-data-div w-100'>
                          <span className='rightlabelStyle'>Sponser</span> :<span className='ms-2'>{viewStudyDetails?.organization?.orgName}
                          </span>
                        </div>
                        <div className='label-data-div w-100'>
                          <span className='rightlabelStyle'>Approver</span> :<span className='ms-2'>{viewStudyDetails?.approver?.userName}
                          </span>
                        </div>
                        <div className='label-data-div w-100'>
                          <span className='rightlabelStyle'>Visits</span> :<span className='ms-2'>{viewStudyDetails?.visitsCount}
                          </span>
                        </div>
                        <div className='label-data-div w-100'>
                          <span className='rightlabelStyle'>Sample Size</span> :<span className='ms-2'>{viewStudyDetails?.subjectSampleSize}
                          </span>
                        </div>
                        <div className='label-data-div w-100'>
                          <span className='rightlabelStyle'>Request By</span>:
                          <span className='ms-2'>
                            {viewStudyDetails?.studyRequestor?.name} </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className='d-flex justify-content-between align-items-center mx-4'>
                  <div><h6>Study Admin</h6></div>
                </div>
                <hr className='my-0 mx-3'></hr>
                <div className='study-admin'>
                  <div className="row my-3 mx-3">
                    {
                      viewStudyDetails && viewStudyDetails.studyContacts.map((e: any, index: number) => {
                        return (
                          <React.Fragment key={index}>
                            <div className='col-sm-4 form-group'>
                              <label className='active'>{index === 0 ? "Primary " : "Secondary"}</label>
                            </div>
                            <div className='w-100 m-2 bodylabdata'>
                              <div className='create-contact d-flex flex-wrap'>
                                <div className='label-container'>
                                  <div className='label-data-div'>
                                    {/* <span className='labelStyle'> User Id </span>: <span className='ms-1'>{e.id}</span> */}
                                    <span className='SA-labelStyle'> User Name </span>: <span className='ms-1'>{e.userName}</span>
                                  </div>
                                </div>
                                <div className='label-container'>
                                  <div className='label-data-div'>
                                    <span className='SA-labelStyle'> First Name </span>: <span className='ms-1'>{e.firstName}</span>
                                  </div>
                                </div>
                                <div className='label-container'>
                                  <div className='label-data-div'>
                                    <span className='SA-labelStyle'>Last Name</span>: <span className='ms-1'>{e.lastName}</span>
                                  </div>
                                </div>
                                <div className='label-container'>
                                  <div className='label-data-div'>
                                    <span className='SA-labelStyle'> Email</span>: <span className='ms-1'>{e.email}</span>
                                  </div>
                                </div>
                                <div className='label-container'>
                                  <div className='label-data-div'>
                                    <span className='SA-labelStyle'> Phone No</span>: <span className='ms-1'>{e.phoneNo}</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </React.Fragment>
                        )
                      })
                    }
                  </div>
                </div>
                <div className='d-flex justify-content-between align-items-center mx-4'>
                  <h6> Application Tools</h6>
                </div>
                <hr className='my-1 mx-3'></hr>
                <div className='w-100 m-3 bodylabdata'>
                  <div className='row'>
                    {viewStudyDetails && viewStudyDetails.solutions.map((solutionData: any, index: number) => {
                      return (
                        <div className='label-data-div col-sm-3' key={index}>
                          <span className='labelStyle'>{solutionData?.name}</span><span className='ms-2'></span>
                        </div>
                      )
                    })}
                  </div>
                </div>
                {viewStudyDetails?.edcSolutions.length >= 1 &&
                  <div>
                    <div className='ms-4'>
                      <h6> EDC Modules:</h6>
                    </div>
                    <hr className='my-0 mx-3'></hr>
                    <div className='w-100 m-3 bodylabdata'>
                      <div className='row'>
                        {
                          viewStudyDetails?.edcSolutions?.map((item: any, index: number) => {
                            return (
                              <div className='w-25' key={index}>
                                <label className="ms-4">{item?.name}</label>
                              </div>
                            )
                          })
                        }
                      </div>
                    </div>
                  </div>}
                <div className='d-flex ms-4'>
                  <h6>Comments</h6>
                </div>
                <hr className='my-0 mx-3'></hr>
                <div className="col-sm-4 mx-3 bodylabdata mt-3 form-group label-data-div">
                  <span className='labelStyle '>Comments :</span>
                  <textarea className="form-control" value={comments} onChange={(e: any) => { setComments(e.target.value) }} />
                </div>
                <div className='button d-flex justify-content-end'>
                  {viewStudyDetails?.approvalStatus?.code !==  allConFigData?.Approved && <div className='me-2'>
                    <button type='submit' className='btn btn-sm btn-success mb-4'
                      onClick={(e: any) => onSubmitHandler(e,  allConFigData?.Approved)}
                    >Approve</button>
                  </div>}
                  {viewStudyDetails?.approvalStatus?.code !== allConFigData?.Rejected && <div className='me-2'>
                    <button type='submit' className='btn btn-sm btn-danger mb-4'
                      onClick={(e: any) => onSubmitHandler(e, allConFigData?.Rejected)}
                    >Reject</button>
                  </div>}
                  <div >
                    <button type='submit' disabled={viewStudyDetails?.approvalStatus?.code === allConFigData?.Hold} className='btn btn-sm btn-warning mb-4'
                      onClick={(e: any) => onSubmitHandler(e, allConFigData?.Hold)}
                    >Hold</button>
                  </div>
                </div>
              </div>
            </div> :
            <div className='AapproveStudy' style={{ minHeight: 300 }}>
              <div className='d-flex justify-content-center align-items-center'>
                Your are not accessble
              </div>
            </div>
        }
      </CommonCard>
    </React.Fragment>
  )
}
export default ApproveStudy;