import React, { useEffect } from 'react';
import { Field } from 'formik';
import { fetchAllSolutions } from '../../Actions/actions'
import { useDispatch, useSelector } from 'react-redux';
import { Types } from '../../reducer/Types';
import _ from 'lodash';
import { useTranslation } from 'react-i18next';
import { saveConfigData } from '../../../../actions/actions';

function Solutions(props: any) {
  const { t } = useTranslation();
  const dispatch = useDispatch()
  const { allSolutions, updatedFieldValues } = useSelector((state: any) => state.study)
  const { conFigData, allConFigData } = useSelector((state: any) => state.app)
  const {touched, values, setFieldValue, extendValue } = props
  const loaded = React.useRef(false);
  const bindEDCmodules = React.useRef(false)

  React.useEffect(() => {
    if (!loaded.current) {
      // if (actionType === 'create') {
      dispatch(fetchAllSolutions([], (data: any) => {
        const _data = [...[], ...data]
        const _updatedFieldValues = _.cloneDeep(updatedFieldValues)
        data && data.map((item: any, index: number) => {
          if (_updatedFieldValues.solutions && _updatedFieldValues.solutions.length > 0) {
            _updatedFieldValues.solutions.map((subItem: any) => {
              if (item.id === subItem.id) {
                _data[index] = { ...item, checked: true }
              }
              return null
            })
          } else {
            _data[index] = { ...item, checked: false }
          }
          return null
        })
        dispatch({ type: Types.FETCH_ALL_SOLUTIONS, payload: _data });
      }));
      loaded.current = true
    }
  }, [dispatch, updatedFieldValues]);
  useEffect(() => {
    if (conFigData.EDC_MODULES?.length > 0 && updatedFieldValues.id > 0 && !bindEDCmodules.current) {
      const _edcModules = conFigData && conFigData.EDC_MODULES
      const _updatedFieldValues = _.cloneDeep(updatedFieldValues)
      _edcModules && _edcModules.length > 0 && _edcModules.map((item: any, index: number) => {
        if (_updatedFieldValues.edcSolutions && _updatedFieldValues.edcSolutions.length > 0) {
          const newUpdatedFieldValues = _updatedFieldValues
          newUpdatedFieldValues.edcSolutions.map((subItem: any) => {
            if (item.id === subItem.id) {
              _edcModules[index] = { ...item, checked: true }
            }
            return null
          })
        } else {
          _edcModules[index] = { ...item, checked: false }
        }
        return null
      })
      // values.edcSolutions = _edcModules
      conFigData.EDC_MODULES = _edcModules
      dispatch(saveConfigData(conFigData))
      bindEDCmodules.current = true
    }
  }, [conFigData.EDC_MODULES, updatedFieldValues, dispatch, conFigData])


  const onSelectSolutions = (e: any, item: any, index: number) => {
    const _solutions = values && values.solutions.findIndex((ele: any) => ele.id === item.id)
    const _values = [...[], ...values.solutions]
    const _edcValues = [...[], ...values.edcSolutions]
    if (_solutions === -1) {
      if (e.target.checked) {
        delete item.checked
        // _values.push({ id: e.target.value, studyId: 0, solution: item })
        _values.push(item)

      }
    } else {
      if (!e.target.checked) {
        _values.splice(_solutions, 1)
        // let _EDCmodule = [...[], ...conFigData.EDC_MODULES]
        // _edcValues.map((item:any,index:number)=>{return (
        //   _EDCmodule[index].checked = e.target.checked
        // )})
        _edcValues.splice(0, 3)
      }
    }
    setFieldValue('solutions', _values)
    setFieldValue('edcSolutions', _edcValues)
    const _allSolutions = [...[], ...allSolutions]
    _allSolutions[index].checked = e.target.checked
    dispatch({ type: Types.FETCH_ALL_SOLUTIONS, payload: _allSolutions });

    const _studyDetails = _.cloneDeep(updatedFieldValues);
    _studyDetails.solutions = _values
    _studyDetails.edcSolutions = _edcValues
    dispatch({ type: Types.UPDATED_FIELD_VALUES, payload: _studyDetails });
  }
  const EDCapplicationChecked = (allSolutions: any) => {

    const index = allSolutions?.findIndex((i: any) => i.code === allConFigData?.InductiveEDC)
    if (allSolutions && allSolutions[index]?.checked) {
      return true
    } else {
      return false
    }
  }
  const onEDCmoduleCheck = (e: any, index: number, item: any) => {
    const _EDCmodule = [...[], ...conFigData.EDC_MODULES]
    console.log('..conFigData.EDC_MODULES', conFigData.EDC_MODULES);

    _EDCmodule[index].checked = e.target.checked
    const _edcSolutions = values && values.edcSolutions.findIndex((ele: any) => ele.id === item.id)
    const _values = [...[], ...values.edcSolutions]
    if (_edcSolutions === -1) {
      if (e.target.checked) {
        delete item.checked
        // _values.push({ id: e.target.value, studyId: 0, solution: item })
        _values.push(item)
      }
    } else {
      if (!e.target.checked) {
        _values.splice(_edcSolutions, 1)
      }
    }
    setFieldValue('edcSolutions', _values)
  }
  return (
    <React.Fragment>
      <div className='ms-4'>
        <h6>{t(" Application Tool")} :<span className='text-danger mx-1'>*</span></h6>
      </div>
      <hr className='m-0'></hr>
      <div className='d-flex mx-4 my-3 checkboxField'>
        <div className='d-flex w-100'>
          {
            allSolutions && allSolutions.map((item: any, index: any) => {
              return (
                <div className='w-25' key={index}>
                  <label className="ms-2">
                    <Field type="checkbox" name="solutions"
                      value={item.id}
                      className="form-check-input lerounded-circ"
                      checked={item.checked}
                      onChange={(e: any) => {
                        onSelectSolutions(e, item, index);
                        props.enableSubmit(false)
                      }}
                      disabled={extendValue ? true : false}
                    />
                    <label className="ms-2">{item.name}</label>
                  </label>
                </div>
              )
            })
          }
        </div>
      </div>
      {/* {errors.solutions && touched.solutions ? (
        <div className='text-danger mx-4'>{errors.solutions}</div>
      ) : null} */}
      {touched.solutions && values.solutions.length === 0 ? (
        <div className='text-danger mx-4'>{'Please select at least one Application tool'}</div>
      ) : null}

      {EDCapplicationChecked(allSolutions) && <div>
        <div className='ms-5'>
          <h6>{t(" EDC Modules")} </h6>
        </div>
        <hr className='m-0'></hr>
        <div className='d-flex mx-5 my-4 checkboxField'>
          {/* {
            // EDCmodule && EDCmodule.map((item: any, index: number) => (
            conFigData && conFigData.EDC_MODULES && conFigData.EDC_MODULES.map((item: any, index: number) => (
              <div className='d-flex w-100'>
                <input type="checkbox" checked={item.checked} onChange={(e: any) => onEDCmoduleCheck(e, index, item)} />
                <label className="ms-2">{item.name}</label>
              </div>
            ))
          } */}
          {
            conFigData && conFigData.EDC_MODULES && conFigData.EDC_MODULES.map((item: any, index: number) => {
              return (
                <div className='w-25' key={index}>
                  <label className="ms-2">
                    <Field type="checkbox" name="edcSolutions"
                      value={item.id}
                      className="form-check-input lerounded-circ"
                      disabled={extendValue ? true : false}
                      checked={item.checked}
                      onChange={(e: any) => {
                        onEDCmoduleCheck(e, index, item)
                        props.enableSubmit(false)
                      }}
                    />
                    <label className="ms-2">{item.name}</label>
                  </label>
                </div>
              )
            })
          }
        </div></div>
      }

    </React.Fragment>
  )
}
export default Solutions;
