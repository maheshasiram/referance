import * as React from 'react';
import Box from '@mui/material/Box';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import Divider from '@mui/material/Divider';
import CheckIcon from '@mui/icons-material/Check';
// import TranscationHistoryLogo from '../../../Assets/Images/transcationHistory.png'
import { useDispatch, useSelector } from 'react-redux';
import { fetchTransactionForStudy } from '../../Actions/actions';
import { Types } from '../../reducer/Types';
import { useTranslation } from 'react-i18next';

export default function TransactionHistory(props: any) {

  const { t } = useTranslation();
  const { studyId } = props;
  const dispatch = useDispatch();
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const { transactionDetails, studyDetails } = useSelector((state: any) => (state.study))
  const open = Boolean(anchorEl);

  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    let _transactionDetails = [...[], ...transactionDetails]
    _transactionDetails = []
    dispatch({ type: Types.GET_TRANSACTIONS_DETAILS, payload: _transactionDetails })
    setAnchorEl(event.currentTarget);
    const transactionPayload = { studyId: studyId }
    dispatch(fetchTransactionForStudy(transactionPayload));
  };
  const handleClose = () => {
    setAnchorEl(null);
  };


  return (
    <React.Fragment>
      <Box sx={{ display: 'flex', alignItems: 'center', textAlign: 'center' }}>
        <a href='# ' title=""
          onClick={handleClick}>{t("Transaction History")}</a>
      </Box>
      <Menu
        anchorEl={anchorEl}
        id="account-menu"
        open={open}
        className="tasnsaction-history"
        onClose={handleClose}
        onClick={handleClose}
        PaperProps={{
          elevation: 0,
          sx: {
            overflow: 'auto',
            filter: 'drop-shadow(0px 2px 4px rgba(0,0,0,0.22))',
            mt: 1.5,
            '& .MuiAvatar-root': {
              width: 32,
              height: 32,
              ml: -0.5,
              mr: 1,
            },
            '&:before': {
              content: '""',
              display: 'block',
              position: 'absolute',
              top: 0,
              right: 14,
              width: 10,
              height: 10,
              bgcolor: 'background.paper',
              transform: 'translateY(-50%) rotate(45deg)',
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: 'right', vertical: 'top' }}
        anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
      >
        {transactionDetails && transactionDetails.map((itemData: any, index: number) => {
          const time = `${itemData.actionOn}`;
          // var localDate = new Date(utcDate);
          // var localDate = new Date(time).toLocaleString("en-US", {
          //   localeMatcher: "best fit",
          //   timeZoneName: "short"
          // });
          const localDate = new Date(time)
          // let formatted = moment(localDate, "hh:mm:ss").format("hh:mm A");
          // let formattedDate = moment(itemData.actionOn).format("DD-MM-YYYY")


          return (
            <div key={index}>
              <MenuItem >
                <div className='item-list'>
                  <div className='start-icon px-1'>
                    <span><CheckIcon fontSize="small" sx={{ color: '#42a4cd' }} /></span></div>
                  <div className='w-75' key={index}>
                    {/* <h6>{studyName}</h6> */}
                    <h6>{studyDetails.protocolId}</h6>
                    <p><b>Request By :</b> {itemData.requestByName}</p>
                    <p><b>Approver :</b> {itemData.actionByName}</p>
                    <p><b>Comments : </b>{itemData.comments}</p>
                    <p><b>Status  :</b>{itemData?.transWfStatusId?.name}</p>
                  </div>
                  <span className='timezone'>{localDate.getDate() + "-" + (localDate.getMonth() + 1) + "-" + localDate.getFullYear()}</span>
                  <span className='timezone'>{localDate.getHours() + ":" + localDate.getMinutes() + ":" + localDate.getSeconds()}</span>
                </div>
              </MenuItem>
              {/* } */}
              <Divider />
            </div>
          )
        })}
        {transactionDetails && transactionDetails.length === 0 && <div className='transcationHistory'>
          <p className='justify-content-center'>Loading transcation history...</p></div>}
      </Menu>
    </React.Fragment>
  );
} 
