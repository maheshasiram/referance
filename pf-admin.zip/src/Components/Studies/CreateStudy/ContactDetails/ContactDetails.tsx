import React from "react";
import { useDispatch, useSelector } from 'react-redux';
import { Field, FieldArray, ErrorMessage } from "formik";
import AddCircleOutlineTwoToneIcon from '@mui/icons-material/AddCircleOutlineTwoTone';
import RemoveCircleOutlineIcon from '@mui/icons-material/RemoveCircleOutline';
import CloseIcon from '@mui/icons-material/Close';
import ZoomInIcon from '@mui/icons-material/ZoomIn';
import '../style.scss'
import { getUserByUserName } from "../../Actions/actions";
import CustomizedTooltip from "../../../../Common/CustomizedTooltip/CustomizedTooltip";
import { toastAlert } from "../../../../actions/actions";
// import { Types } from "../../reducer/Types"

const ContactDetails = (props: any) => {
  const { errors, values, setFieldValue, setFieldTouched, extendValue, setBtnEnable, setUserValues } = props
  const [userError, setUserError] = React.useState("")
  const { studyContactType } = useSelector((state: any) => state.study)
  const { allConFigData } = useSelector((state: any) => state.app);

  const dispatch = useDispatch();
  const [contact] = React.useState({
    id: 0,
    organizationId: 0,
    firstName: "",
    lastName: "",
    email: "",
    phoneNo: "",
    contactDesgn: "",
    contactType: {},
    active: true,
    userName: "",
    studyId: 0
  })
  const setAdminDeatials = (setFieldValue: any, index: any) => {
    setFieldValue(`studyContacts.${index}.firstName`, "")
    setFieldValue(`studyContacts.${index}.lastName`, "")
    setFieldValue(`studyContacts.${index}.email`, "")
    setFieldValue(`studyContacts.${index}.phoneNo`, "")
    setFieldValue(`studyContacts.${index}.orgName`, "")
  }

  const onUserIdSearch = (searchValue: any, setFieldValue: any, index: any) => {
    if (searchValue && searchValue !== ' ') {      //search enable only when field having username for search
      dispatch(getUserByUserName(searchValue, (data: any) => {
        if (!data.userName && !data.email) {
          setUserError("User Not Registered in GPU. Please try with valid user!");
          dispatch(toastAlert({
            status: 0,
            message: "User Not Registered in GPU. Please try with valid user!",
            open: true
          }));
        }
        else {
          setUserError("")
          setFieldValue(`studyContacts.${index}.firstName`, data.firstName)
          setFieldValue(`studyContacts.${index}.lastName`, data.lastName)
          setFieldValue(`studyContacts.${index}.email`, data.email)
          setFieldValue(`studyContacts.${index}.phoneNo`, data.phone)
          setFieldValue(`studyContacts.${index}.orgName`, data.orgName)
          setFieldValue(`studyContacts.${index}.organizationId`, data.orgId)
          values.studyContacts[index].userId = data.userId
        }
      }))
    }

    // dispatch(findUserDetailsFromLdap(searchValue, (data: any) => {
    //   if (!data.userName && !data.email) {
    //     setUserError("User Not Registered in GPU. Please try with valid user!");
    //   }
    //   else {
    //     setUserError("")
    //     setFieldValue(`studyContacts.${index}.firstName`, data.firstName)
    //     setFieldValue(`studyContacts.${index}.lastName`, data.lastName)
    //     setFieldValue(`studyContacts.${index}.email`, data.email)
    //     setFieldValue(`studyContacts.${index}.phoneNo`, data.phone)
    //   }
    // }));
  }

  const clearSearch = (setFieldValue: any, index: any) => {
    setFieldValue(`studyContacts.${index}.userName`, "")
    setFieldValue(`studyContacts.${index}.userId`, "")
    setAdminDeatials(setFieldValue, index)
    setUserError("")
  }

  const validateApprovalStatus = () => {
    if (values?.approvalStatus?.code !== allConFigData?.provisioned &&
      values.approvalStatus.code !== allConFigData?.Bookmarked && values.approvalStatus.code !== allConFigData?.Approved
      // || contactData.contactType && contactData.contactType.code !== "CONTACT_TYPE_PRIMARY_STUDY_ADMIN"
    ) {
      return true
    } else {
      return false
    }
  }

  const onSetContactType = () => {
    const SecondaryContact = values.studyContacts.findIndex((element: any) => element?.contactType?.code === allConFigData?.SecondryStudyAdmin)
    if ((values.studyContacts.length === 1) && SecondaryContact === -1) {
      const _Secondary = studyContactType && studyContactType.find((item: any) => item.code === allConFigData?.SecondryStudyAdmin)
      return _Secondary
    }
  }

  return (
    <React.Fragment>
      <FieldArray
        name="studyContacts"
        render={(contactsArr) => {
          const studyContacts: any = values.studyContacts
          return (
            <div className=" my-3 mx-3">
              <div className="Contact d-flex justify-content-between align-items-center mx-2">
                <h6>Study Admin Details</h6>
                <span>
                  {!extendValue && studyContacts && studyContacts.length < 2 && values.studyContacts[0].firstName && <CustomizedTooltip title="Add Contact">
                    <AddCircleOutlineTwoToneIcon
                      className={`${studyContacts && studyContacts.length < 2 ? 'add-primary-icon' : 'add-secondary-icon'} orgicon  `}
                      // className={values.studyContacts[0].firstName}
                      onClick={() => {
                        if (studyContacts && studyContacts.length < 2) {
                          contactsArr.push({ ...contact, organizationId: studyContacts[0].organizationId, contactType: onSetContactType() })
                        }
                        // addContact(studyContacts, contactsArr)
                        setBtnEnable(false)
                      }}
                    /></CustomizedTooltip>}
                </span>
              </div>
              <hr className='m-0'></hr>
              <div className="main-contact-container">
                {/* {!studyContacts[index].userId && studyContacts[index].userName && <span className="text-danger ml-2">{userError}</span>} */}
                <span className="text-danger ml-2">{userError}</span>
                <div className="d-flex">
                  <div className="w-100">
                    {studyContacts && studyContacts.length > 0 && studyContacts.map((contactData: any, index: number) => (
                      <>
                        <div className="row">
                          <div className="col-4 ms-2">
                            <label className="active m-2">{studyContacts && studyContacts[index]?.contactType?.name}</label>
                            <div
                              className={`search-container-contact ${extendValue ? 'disableSearchField' : ''}`}
                            >
                              <Field
                                name={`contactData.${index + 1}.userName`}
                                className="search-field"
                                disabled={extendValue}
                                placeholder="Enter Admin UserID"
                                type="text"
                                value={values.studyContacts[index].userName}
                                onChange={(e: any) => {
                                  // if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) == false && e.target.value.length == 0)) {
                                  //  setDisableBtn(false);
                                  // setFieldValue(`contactData.${index + 1}.userName`, e.target.value);
                                  // }
                                  setUserValues(errors)
                                  setUserError('')
                                  setAdminDeatials(setFieldValue, index)
                                  setFieldTouched(`studyContacts.${index}.userName`, true)
                                  setFieldValue(`studyContacts.${index}.userName`, e.target.value.replace(/\s\s+/g, ' '))
                                  values.studyContacts[index].organizationId = values.organization.id
                                  props.enableSubmit(false)
                                }}
                              />
                              {values.studyContacts[index].userName && values.studyContacts[index].userName.length >= 1 && <span className="del-icon"> <CloseIcon className={extendValue && 'disableClose'}/*onClick={props.onClearSearch}*/ onClick={() => !extendValue && clearSearch(setFieldValue, index)} /></span>}
                              <span className="search px-1" >
                                <ZoomInIcon className={extendValue && "disabled"} onClick={() => onUserIdSearch(values.studyContacts[index].userName, setFieldValue, index)} />
                              </span>
                            </div>
                            <span className='text-danger ms-2'><ErrorMessage name={`studyContacts.${index}.userName`} /></span>
                          </div>
                        </div>
                        <div className="row  my-3 mx-1" key={index}>
                          <div className="col-sm-3">
                            <div className="form-group">
                              <label > First Name:<span className='text-danger mx-1'>*</span></label>
                              <Field
                                name={`contactData.${index + 1}.firstName`}
                                className='form-control'
                                placeholder=""
                                type="text"
                                value={values.studyContacts[index].firstName}
                                disabled={true}
                                onChange={(e: any) => {
                                  setFieldTouched(`studyContacts.${index}.firstName`, true)
                                  setFieldValue(`studyContacts.${index}.firstName`, e.target.value.replace(/\s\s+/g, ' '))
                                  props.enableSubmit(false)
                                }}
                              />
                              {values.studyContacts[index].userName ? <span className='text-danger'> <ErrorMessage name={`studyContacts.${index}.firstName`} /></span> : null}
                            </div>
                          </div>
                          <div className="col-sm-2">
                            <div className="form-group">
                              <label > Last Name:<span className='text-danger mx-1'>*</span></label>
                              <Field
                                name={`contactData.${index + 1}.lastName`}
                                placeholder=""
                                className='form-control'
                                type="text"
                                value={values.studyContacts[index].lastName}
                                // validate={firstNameVaidation}
                                disabled={true}
                                onChange={(e: any) => {
                                  setFieldTouched(`studyContacts.${index}.lastName`, true)
                                  setFieldValue(`studyContacts.${index}.lastName`, e.target.value.replace(/\s\s+/g, ' '))
                                  props.enableSubmit(false)
                                }}
                              />
                              {values.studyContacts[index].userName ? <span className='text-danger'><ErrorMessage name={`studyContacts.${index}.lastName`} /></span> : null}
                            </div>
                          </div>
                          <div className="col-sm-2">
                            <div className="form-group">
                              <label >Organization Name:<span className='text-danger mx-1'>*</span></label>
                              <Field
                                name={`contactData.${index + 1}.orgName`}
                                className='form-control'
                                placeholder=""
                                type="text"
                                value={values.studyContacts[index].orgName}
                                disabled={true}
                                onChange={(e: any) => {
                                  setFieldTouched(`studyContacts.${index}.orgName`, true)
                                  setFieldValue(`studyContacts.${index}.orgName`, e.target.value.replace(/\s\s+/g, ' '))
                                  props.enableSubmit(false)
                                }}
                              />
                              {values.studyContacts[index].userName ? <span className='text-danger'><ErrorMessage name={`studyContacts.${index}.orgName`} /></span> : null}
                            </div>
                          </div>
                          <div className="col-sm-2">
                            <div className="form-group">
                              <label > Phone No:<span className='text-danger mx-1'>*</span></label>
                              <Field
                                name={`contactData.${index + 1}.phoneNo`}
                                className='form-control'
                                placeholder=""
                                type="text"
                                value={values.studyContacts[index].phoneNo}
                                disabled={true}
                                onChange={(e: any) => {
                                  setFieldTouched(`studyContacts.${index}.phoneNo`, true)
                                  setFieldValue(`studyContacts.${index}.phoneNo`, e.target.value.replace(/\s\s+/g, ' '))
                                  props.enableSubmit(false)
                                }}
                              />
                              {values.studyContacts[index].userName ? <span className='text-danger'><ErrorMessage name={`studyContacts.${index}.phoneNo`} /></span> : null}
                            </div>
                          </div>
                          <div className="col-sm-3">
                            <div className="form-group">
                              <label> Email:<span className='text-danger mx-1'>*</span> </label>
                              <Field
                                name={`contactData.${index + 1}.email`}
                                className='form-control'
                                placeholder=""
                                type="email"
                                value={values.studyContacts[index].email}
                                // validate={firstNameVaidation}
                                disabled={true}
                                onChange={(e: any) => {
                                  setFieldTouched(`studyContacts.${index}.email`, true)
                                  setFieldValue(`studyContacts.${index}.email`, e.target.value.replace(/\s\s+/g, ' '))
                                  props.enableSubmit(false)
                                }}
                              />
                              {values.studyContacts[index].userName ? <span className='text-danger'><ErrorMessage name={`studyContacts.${index}.email`} /></span> : null}
                            </div>
                          </div>
                        </div>
                        <div className="mx-1">
                          {
                            studyContacts && studyContacts.map((i: any, index: any) => {
                              // if (i.contactType && i.contactType.code === "CONTACT_TYPE_SECONDRY_STUDY_ADMIN") {
                              return (
                                (i.contactType && i.contactType.code === allConFigData?.SecondryStudyAdmin) &&
                                <div className='remove-container'>
                                  <div className='form-group ms-1'>
                                    {validateApprovalStatus() &&
                                      <CustomizedTooltip title="Remove Contact">
                                        <RemoveCircleOutlineIcon
                                          color="error"
                                          className="mx-1"
                                          onClick={() => {
                                            if (studyContacts.length > 1) {
                                              contactsArr.remove(index)
                                            }
                                            setBtnEnable(false)
                                            setUserError('')
                                          }}
                                        />
                                      </CustomizedTooltip>
                                    }
                                  </div>
                                </div>
                              )
                              // }
                            })
                          }
                        </div>
                      </>
                    ))}
                  </div>
                  {/* {
                    studyContacts && studyContacts.map((i: any,index:any) => {
                      if (i.contactType && i.contactType.code === "CONTACT_TYPE_SECONDRY_STUDY_ADMIN") {
                        return (
                          <div className='remove-container'>
                            <div className='form-group ms-1'>
                              {validateApprovalStatus(index) &&
                                <CustomizedTooltip title="Remove Contact">
                                  <RemoveCircleOutlineIcon
                                    color="error"
                                    onClick={() => {
                                      if (studyContacts.length > 1) {
                                        contactsArr.remove(index)
                                      }
                                      setBtnEnable(false)
                                    }}
                                  />
                                </CustomizedTooltip>
                              }
                            </div>
                          </div>
                        )
                      }
                    })
                  } */}
                </div>
              </div>
            </div>
          )
        }}
      />
      <br />
    </React.Fragment>
  );
}
export default ContactDetails
