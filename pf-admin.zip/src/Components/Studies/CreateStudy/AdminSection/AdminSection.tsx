import React from "react";
import { ErrorMessage, Field } from 'formik';
import { useTranslation } from 'react-i18next';

function AdminSection(props: any) {

  const { t } = useTranslation();
  const {  values } = props
  return (
    <React.Fragment>
      <div className='ms-4'>
        <h6>Admin Section :</h6>
      </div>
      <hr className='m-0'></hr>
      <div className="row mx-3 my-3">
        <div className="col-sm-4">
          <div className='form-group'>
            <label className="mb-1">Database :</label>
            <Field
              as="select"
              placeholder="Select Your Database"
              className='form-select form-control-lg'
              name="afterApproved.dbName"
              value={values.afterApproved.dbName}
            >
              <option value=''>Select Your Database</option>
              <option value='1'>1</option>
            </Field>
            <span className='text-danger'><ErrorMessage name="afterApproved.dbName" /></span>
          </div>
        </div>

        <div className="col-sm-4">
          <div className='form-group' >
            <label className="mb-1">Port ID :</label>
            <Field
              className='form-control'
              name="afterApproved.portId"
              value={values.afterApproved.portId}
            >
            </Field>
            <span className='text-danger'><ErrorMessage name="afterApproved.portId" /></span>
          </div>

        </div>
        <div className="col-sm-4">
          <div className='form-group'>
            <label className="mb-1">{t("Hosted Region")} :</label>
            <Field
              as="select"
              className='form-select form-control-lg'
              name="afterApproved.hostedRegion"
              value={values.afterApproved.hostedRegion}
            >
              <option value=''>{t("Select Study Phase")}</option>
              <option value='1'>1</option>
            </Field>
            <span className='text-danger'><ErrorMessage name="afterApproved.hostedRegion" /></span>
          </div>
        </div>
      </div>
      <div className="row mx-3 my-3">
        <div className="col-sm-4">
          <div className='form-group'>
            <label className="mb-1">{t("Clouded Provider")} :</label>
            <Field
              as="select"
              placeholder="Select Orgnization"
              className='form-select form-control-lg'
              name="afterApproved.cloudedProvider"
              value={values.afterApproved.cloudedProvider}
            >
              <option value=''>{t("Select Orgnization")}</option>
              <option value='1'>1</option>
            </Field>
            <span className='text-danger'><ErrorMessage name="afterApproved.cloudedProvider" /></span>
          </div>
        </div>
        <div className="col-sm-4">
          <div className='form-group' >
            <label className="mb-1">{t("EDC Url ")}:</label>
            <Field
              as="select"
              placeholder={t("Select Approver")}
              className='form-select form-control-lg'
              name="afterApproved.edcUrl"
              value={values.afterApproved.edcUrl}
            >
              <option value=''>{t("Select Approver")}</option>
              <option value='1'>1</option>
            </Field>
            <span className='text-danger'><ErrorMessage name="afterApproved.edcUrl" /></span>
          </div>
        </div>
      </div>
    </React.Fragment>
  )
}
export default AdminSection;