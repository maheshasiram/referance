import React, { useEffect } from "react";
import { Formik, Form } from 'formik';
import StudyDetails from "./StudyDetails/StudyDetails";
import AdditionalDetails from "./AdditionalDetails/AdditionalDetails";
import ContactDetails from "./ContactDetails/ContactDetails";
import Solutions from "./Solutions/Solutions";
import AdminSection from "./AdminSection/AdminSection";
import './style.scss';
import CommonCard from "../../../Common/CommonCard";
import { useDispatch, useSelector } from "react-redux";
import { Alert, saveConfigData, toastAlert } from "../../../actions/actions";
import { useNavigate, useParams } from "react-router-dom";
import { findStudyDetailsById, getDataByTypeCode, saveStudy, submitStudy, reSubmitStudy, findstudiesByUser } from "../Actions/actions";
import { getDocumentTypes } from "../../Users/Actions/Action";
import { CreateStudySchema } from '../Constants/Validate';
import { Types } from "../reducer/Types";
import { Types as constTypes } from "../../../Constants/Types";
import { messages } from "../../../configs/messages";
import { useTranslation } from 'react-i18next';
import Comment from "./Comments/Comment";
import KeyboardDoubleArrowLeftIcon from '@mui/icons-material/KeyboardDoubleArrowLeft';
import { toastMsg } from "../../../Common/Messages";
import { Study } from "../Constants/DataTypes";
import _ from 'lodash';
import Loader from "../../../Common/Loader";

function CreateStudy() {
  const { t } = useTranslation();

  const dispatch = useDispatch();
  const navigate = useNavigate();
  const params: any = useParams();

  const [btnState, setBtnState] = React.useState('')
  const [primaryValueErr, setPrimaryValueErr] = React.useState('');
  const [secondaryContactErr, setSecondaryContactErr] = React.useState('');
  const { studyDetails, adminRole, extendValue, studyStatusTypes, deletedStudyDocuments, actionType, studyPayload, studyContactType } = useSelector((state: any) => (state.study))
  const { user, config, allConFigData } = useSelector((state: any) => (state.app))
  const [btnEnable, setBtnEnable] = React.useState(true)
  const loaded = React.useRef(false);
  const [userValues, setUserValues] = React.useState('');
  const { documentTypes } = useSelector((state: any) => state.users);
  const [fileTypeError, setFileTypeError] = React.useState(false);

  React.useEffect(() => {
    if (!loaded.current) {
      // dispatch(getContactDataByTypeCode('CONTACT_TYPE'))
      dispatch(getDocumentTypes());
      dispatch(saveConfigData({}))
      dispatch({ type: Types.UPDATED_FIELD_VALUES, payload: Study });
      if (parseInt(params.id) > 0) {
        dispatch(findStudyDetailsById({ studyId: parseInt(params.id) }, (response: any) => {
          if (response) {
            dispatch(getDataByTypeCode(config.WF_STATUS_TYPE));
          } else {
            dispatch(toastAlert({
              status: 0,
              message: response.errorMessage,
              open: true
            }));
          }
        }));
      }
      loaded.current = true
    }
  }, [dispatch, config.WF_STATUS_TYPE, params.id]);

  useEffect(() => {
    const _study = _.cloneDeep(studyDetails);
    if (!(_study.studyContacts[0].contactType)) {
      const _primaryContact = studyContactType?.find((studyType: any) => studyType.code === allConFigData?.PrimaryStudyAdmin)
      _study.studyContacts[0].contactType = _primaryContact
      dispatch({ type: Types.INITIATE_NEW_STUDAY, payload: _study })

    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [studyContactType])

  const onSubmitHandler = (values: any) => {
    const _values = { ...{}, ...values }
    _values.primaryContact = null;
    _values.secondaryContact = null;
    _values.orgType = null
    _values.labExist = values.labExist == "true" ? true : false
    // const documentId = documentTypes?.find((docType: any) => docType.code ==="DOC_TYPE_EMAIL")
    //   values.studyItems[0].documentTypeId = documentId?.id;
    if (parseInt(params.id) > 0 && values.studyDocuments.length === 0) {
      values.studyDocuments.push({ value: "", documentTypeId: "" });
      const documentId = documentTypes?.find((docType: any) => docType.code === "DOC_TYPE_EMAIL")
      values.studyItems[0].documentTypeId = documentId?.id;
      values.studyDocuments[0].documentTypeId = documentId?.id;
    }
    // const { WF_STATUS_TYPE_SUBMIT_RE_APPROVAL } = config;
    if (params.id === 0 || params.id === '0') {
      _values.approvalStatus = null;
    } else {
      const { code } = _values.approvalStatus;
      const statusType = studyStatusTypes?.find((item: any) => item.code === allConFigData?.SubmitForReApproval);
      if (code === allConFigData?.Hold || code === allConFigData?.Rejected) {
        _values.approvalStatus = statusType;
      }
    }
    //Added condition for validations --Akshay
    if (!primaryValueErr && !secondaryContactErr && !fileTypeError) {
      if (((values.studyItems[0]) && (values.studyItems[0]?.documentTypeId !== '' && values.studyItems[0]?.value !== '')) || (actionType !== 'create' && (values.studyDocuments[0]?.documentTypeId !== '' && values.studyDocuments[0]?.value !== ''
        && ((!values.studyItems[0]?.value && !values.studyItems[0]?.documentTypeId) || (values.studyItems[0]?.value && values.studyItems[0]?.documentTypeId))))) {
        if (btnState === 'save') {
          _values.studyStatus = true;
          dispatch(saveStudy(_values, deletedStudyDocuments, (data: any) => {
            if (data.status === 500) {
              dispatch(toastAlert({
                status: 0,
                message: data.error,
                open: true
              }))
            }
            else if (!data.errorCode) {
              dispatch(Alert({
                status: 0,
                message: messages.study.saveStudy,
                actionType: 'StudySave',
                onOk: () => {
                  navigate('/dashboard');
                },
                onCancel: () => {
                  const payload = { studyId: data.id }
                  const _payload = { ...studyPayload, protocolId: '', approvalStatus: '', studyPhase: '', userId: user.userId }
                  dispatch({ type: Types.STUDY_PAYLOAD, payload: _payload })
                  dispatch(findstudiesByUser(_payload, () => {
                    dispatch(findStudyDetailsById(payload));
                  }));
                }
              }))
            } else {
              if (data.errorMessage) {
                dispatch(toastAlert({
                  status: 0,
                  message: data.errorMessage,
                  open: true
                }))
                // (dispatch as any)(Alert({
                //   status: 1,
                //   message: data.errorMessage,
                //   onOk: () => { }
                //   // message: data.response.status === 500 ? 'Somthing Went Wrong !' : data.response.data.errorMessage,
                // }))
              }
            }
          }));
        }
        else if (btnState === 'submit') {
          _values.approvalStatus = values.approvalStatus?.code == "WF_STATUS_TYPE_DRAFT" ? null : values.approvalStatus
          dispatch(submitStudy(_values, deletedStudyDocuments, (data: any) => {
            if (data.status === 500) {
              dispatch(toastAlert({
                status: 0,
                message: data.error,
                open: true
              }))
            }
            else if (!data.errorCode) {
              dispatch(toastAlert({
                status: 1,
                message: toastMsg(actionType === 'create' ? messages.study.submitStudy : messages.study.updateStudy, ''),
                open: true
              }))
              onBackToStudies()
            } else {
              if (data.errorMessage) {
                dispatch(toastAlert({
                  status: 0,
                  message: data.errorMessage,
                  open: true
                }))
              }
            }
          }))
        }
        else if (btnState === 'resubmit') {
          dispatch(reSubmitStudy(_values, deletedStudyDocuments, (response: any) => {
            if (response.status === 500) {
              dispatch(toastAlert({
                status: 0,
                message: response.error,
                open: true
              }))
            }
            else if (!response.errorCode) {
              dispatch(toastAlert({
                status: 1,
                message: toastMsg(messages.study.ReSubmit, ''),
                open: true
              }))
              // navigate('/dashboard')
              onBackToStudies()
            }
            else {
              if (response.errorMessage) {
                dispatch(toastAlert({
                  status: 0,
                  message: response.errorMessage,
                  open: true
                }))
              }
            }
          }))
        }
        else {
          if (btnState === 'submit') {
            _values.approvalStatus = values.approvalStatus?.code == "WF_STATUS_TYPE_DRAFT" ? null : values.approvalStatus
            dispatch(submitStudy(_values, (response: any) => {
              if (!response.errorCode) {
                dispatch(toastAlert({
                  status: 1,
                  message: toastMsg(messages.study.submitStudy, ''),
                  open: true
                }))
                navigate('/dashboard')
              } else {
                if (response.errorMessage) {
                  dispatch(toastAlert({
                    status: 0,
                    message: response.errorMessage,
                    open: true
                  }))
                }
              }
            }))
          }
        }
      }
    }
  }
  const onBackToStudies = () => {
    navigate('/dashboard');
    dispatch({ type: Types.DELETED_STUDY_DOCUMENTS, payload: [] });
    dispatch({ type: constTypes.CONFIG_DATA, payload: {} })
    // dispatch(saveConfigData({}))
    dispatch({ type: Types.UPDATED_FIELD_VALUES, payload: Study });
  }

  return (
    <React.Fragment>
      {/* {studyDetails.id === 0 && <Loader />} */}
      {(studyDetails.id === 0 && parseInt(params.id) > 0) && <Loader />}
      <div className=" d-flex justify-content-between">
        <h2>{`${parseInt(params.id) > 0 ? t("Update") : t("Create")}`} {t("Study")}</h2>
        <div className="backto-studies">
          <span onClick={onBackToStudies}><KeyboardDoubleArrowLeftIcon /> Back To Studies</span>
        </div>
      </div>
      <CommonCard
        title={t('Create Study')}
      >
        <Formik
          enableReinitialize={true}
          initialValues={studyDetails}
          validationSchema={CreateStudySchema()}
          onSubmit={(values) => {
            onSubmitHandler(values);
          }}
        >
          {({ errors, touched, values, setFieldValue, setFieldTouched }) => (
            <Form id="createStudy-submit" className='createStudy-form'>
              <StudyDetails
                errors={errors}
                touched={touched} values={values}
                setFieldValue={setFieldValue} setFieldTouched={setFieldTouched}
                extendValue={extendValue}
                enableSubmit={(value: any) => setBtnEnable(value)}
                setSecondaryContactErr={setSecondaryContactErr}
                setPrimaryValueErr={setPrimaryValueErr}
              />

              <AdditionalDetails
                errors={errors} touched={touched} values={values}
                setFieldValue={setFieldValue} setFieldTouched={setFieldTouched}
                extendValue={extendValue}
                enableSubmit={(value: any) => setBtnEnable(value)}
                fileTypeError={fileTypeError}
                setFileTypeError={setFileTypeError}
              />
              <ContactDetails
                errors={errors}
                touched={touched}
                values={values}
                setFieldValue={setFieldValue} setFieldTouched={setFieldTouched}
                setPrimaryValueErr={setPrimaryValueErr} setSecondaryContactErr={setSecondaryContactErr}
                secondaryContactErr={secondaryContactErr} primaryValueErr={primaryValueErr}
                extendValue={extendValue}
                btnEnable={btnEnable}
                setBtnEnable={setBtnEnable}
                enableSubmit={(value: any) => setBtnEnable(value)}
                setUserValues={setUserValues}
                userValues={userValues}
              />
              <Solutions
                errors={errors} touched={touched} values={values}
                setFieldValue={setFieldValue} setFieldTouched={setFieldTouched}
                extendValue={extendValue}
                enableSubmit={(value: any) => setBtnEnable(value)}
              />
              <Comment
                errors={errors} touched={touched} values={values}
                setFieldValue={setFieldValue} setFieldTouched={setFieldTouched}
                extendValue={extendValue}
                enableSubmit={(value: any) => setBtnEnable(value)}
              />
              {adminRole && <AdminSection
                errors={errors} touched={touched} values={values}
                setFieldValue={setFieldValue} setFieldTouched={setFieldTouched}
                extendValue={extendValue}
              />}
              <div className="d-flex justify-content-end text-right px-4">
                {/* changed Cancel button css */}
                <button type="button" className='btn-esecondary px-4 mx-2'
                  onClick={() => onBackToStudies()}>{t("Cancel")}</button>
                {!extendValue && (actionType === 'create') && <button type="submit"
                  className={btnEnable ? 'btn-esecondary px-4 mx-2' : 'btn-eprimary px-4 mx-2'}
                  disabled={btnEnable}
                  onClick={() => setBtnState("save")}>{t("Save")}</button>}
                <button type="submit"
                  className={btnEnable ? 'btn-esecondary px-4' : 'btn-eprimary px-4'}
                  disabled={btnEnable}
                  onClick={() => setBtnState(values.approvalStatus.name === 'Rejected' || values.approvalStatus.code === allConFigData?.SubmitForReApproval ? "resubmit" : "submit")}>{values.approvalStatus.name === 'Rejected' ? 'Resubmit' : actionType === 'create' ? t("Submit") : t('Update')}</button>
              </div>
            </Form>
          )}
        </Formik>
      </CommonCard>
    </React.Fragment>
  )
}

export default CreateStudy;