import React from 'react';
import { ErrorMessage, Field } from 'formik';
import TransactionHistory from '../TranscationHistory/TranscaionHistory';
import { findAllOrganizations } from '../../../Organization/actions/actions';
import { useDispatch, useSelector } from 'react-redux';
import { getApprovers } from '../../Actions/actions'
import { Types } from '../../reducer/Types';
import { Loader, fetchConfigData, saveConfigData } from '../../../../actions/actions';
import _ from 'lodash';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
// import { Study } from '../../Constants/DataTypes';
import moment from 'moment';
import { useTranslation } from 'react-i18next';
import { studyConfigDataCodes, Study } from '../../Constants/DataTypes';
import { FormControlLabel } from '@mui/material';

function StudyDetails(props: any) {

  const { t } = useTranslation();
  const dispatch: any = useDispatch()
  const loaded = React.useRef(false);
  const { errors, touched, values, setFieldValue,
    setFieldTouched, extendValue, setSecondaryContactErr, setPrimaryValueErr } = props
  // const [maxDate, setMaxDate] = React.useState(null)
  const { approveList, studyDetails, updatedFieldValues } = useSelector((state: any) => state.study)
  const { allOrganization } = useSelector((state: any) => state.organization)
  const { conFigData, user, allConFigData } = useSelector((state: any) => state.app)

  // console.log("updatedFieldValues", updatedFieldValues)

  // const approverData = approveList && approveList.map((item: any) =>
  //   item.userId
  // )
  // console.log("approverData...", approverData.find((i:any)=>i))

  React.useEffect(() => {
    if (!loaded.current) {
      // if (updatedFieldValues.approver.userId !== approverData.find((i: any) => i)) {
      //   console.log(".....38")
      //   updatedFieldValues.approver = Study.approver
      //   dispatch({ type: Types.UPDATED_FIELD_VALUES, payload: updatedFieldValues });
      // }
      dispatch(findAllOrganizations())
      dispatch(getApprovers())
      const getAllConfigData = () => {
        const _configdata = { ...{}, ...conFigData }
        // let data = await studyConfigDataCodes.map(async(code: any, index: number) => {
        //   await dispatch(fetchConfigData(code, async(data: any) => {
        //     _configdata[code] = data
        //     if ((studyConfigDataCodes.length - 1) === index) {
        //       await dispatch(saveConfigData(_configdata))
        //     }
        //   }))
        //   return null
        // })

        dispatch(Loader(true))

        dispatch(fetchConfigData("STUDY_TYPE", (STUDY_TYPE_data: any) => {
          console.warn('DATA RESPONSE......', STUDY_TYPE_data);
          _configdata["STUDY_TYPE"] = STUDY_TYPE_data
          dispatch(fetchConfigData("INDICATION", (INDICATION_data: any) => {
            _configdata["INDICATION"] = INDICATION_data
            dispatch(fetchConfigData("STUDY_DESIGN", async (STUDY_DESIGN_data: any) => {
              _configdata["STUDY_DESIGN"] = STUDY_DESIGN_data
              dispatch(fetchConfigData("REGULATORY", async (REGULATORY_data: any) => {
                _configdata["REGULATORY"] = REGULATORY_data
                dispatch(fetchConfigData("INVESTIGATION", async (INVESTIGATION_data: any) => {
                  _configdata["INVESTIGATION"] = INVESTIGATION_data
                  dispatch(fetchConfigData("STUDY_PHASE", async (STUDY_PHASE_data: any) => {
                    _configdata["STUDY_PHASE"] = STUDY_PHASE_data
                    dispatch(fetchConfigData("THERAPEUTIC", async (THERAPEUTIC_data: any) => {
                      _configdata["THERAPEUTIC"] = THERAPEUTIC_data
                      dispatch(fetchConfigData("POPULATION", async (POPULATION_data: any) => {
                        _configdata["POPULATION"] = POPULATION_data
                        dispatch(fetchConfigData("EDC_MODULES", async (EDC_MODULES_data: any) => {
                          _configdata["EDC_MODULES"] = EDC_MODULES_data
                          dispatch(saveConfigData(_configdata))
                          dispatch(Loader(false))

                        }))
                      }))
                    }))
                  }))
                }))
              }))
            }))
          }))
        }))


      }
      getAllConfigData()
      loaded.current = true
    }
  }, [conFigData, dispatch])

  // React.useEffect(() => {
  //   let payload = _.cloneDeep(Study);
  //   Study.studyContacts.map((studyType: any, index: number) => { studyType.contactType == null && (payload.studyContacts[index].contactType = studyContactType && studyContactType.find((element: any) => element.code === "CONTACT_TYPE_PRIMARY_STUDY_ADMIN")) })
  //   console.log("50....", payload, studyContactType)
  //   dispatch({ type: Types.INITIATE_NEW_STUDAY, payload: payload })
  //   // dispatch({ type: Types.CREATE_OR_EDIT_STUDY, payload: payload })
  // }, [studyContactType])

  const preventMinus = (e: any) => {
    if (e.code === 0) {
      e.preventDefault();
    }
  };
  // const getAllConfigData = () => {
  //   let _configdata = { ...{}, ...conFigData }
  //   studyConfigDataCodes.forEach((code: any, index: number) => {
  //     dispatch(fetchConfigData(code, (data: any) => {
  //       _configdata[code] = data
  //       if ((studyConfigDataCodes.length - 1) === index) {
  //         dispatch(saveConfigData(_configdata))
  //       }
  //     }))
  //   })
  // }
  const onOrganizationChange = (e: any) => {
    if (e.target.value !== "") {
      // dispatch(getOrgnizationContacts(e.target.value))
    }
  }

  // const disablePastDate = () => {
  //   const today = new Date()
  //   // const today = date ? new Date(date) : new Date();
  //   const dd = String(today.getDate() + 0).padStart(2, "0");
  //   const mm = String(today.getMonth() + 1).padStart(2, "0"); //January is 0!
  //   const yyyy = today.getFullYear();
  //   return yyyy + "-" + mm + "-" + dd;
  // };

  // const maxStartDate = (date: any) => {
  //   if (date) {
  //     const today = new Date(date);
  //     const dd = String(today.getDate() - 1).padStart(2, "0");
  //     const mm = String(today.getMonth() + 1).padStart(2, "0"); //January is 0!
  //     const yyyy = today.getFullYear();
  //     return yyyy + "-" + mm + "-" + dd;
  //   }
  // }
  // const onBackToStudies = () => {
  //   navigate('/dashboard');
  //   dispatch(fetchAllStudies(true))
  // }


  const startDateValidation = (value: any) => {
    let error;
    if (values.endDate && moment(value).isAfter(values.endDate)) {
      error = t("Start Date Should Be Less Than End Date")
    }
    //Condition for after approval of study can't change start date - Akshay
    if (((studyDetails && studyDetails.approvalStatus.code === allConFigData?.provisioned) ||
      studyDetails.approvalStatus.code === allConFigData?.Approved ||
      studyDetails.approvalStatus.code === allConFigData?.Bookmarked)
      && moment(studyDetails.startDate).isAfter(values.startDate)
    ) {
      error = t("Start date should not be less than previous date.!")
    }
    return error
  }

  const endDateValidation = (value: any) => {
    // let error;
    const error = moment(value).isSame(values.startDate) ? t("Start Date And End Date Should Not Be Same") : moment(value).isBefore(values.startDate) ? t("End Date Should Be Greater Than Start Date") : ""
    return error
  }

  return (
    <React.Fragment>
      <div className='d-flex justify-content-between align-items-center mx-4'>
        <div><h6>{t("Study Details")}</h6></div>
        {(values.id > 0) && <div className='d-flex align-items-center'>
          {/* <TransactionHistory studyId={values.id} studyName={values.studyName} /></div>} */}
          <TransactionHistory studyId={values.id} /></div>}
      </div>
      <hr className='m-0'></hr>
      <div className="row my-3 mx-3 StudyDetails">
        <div className="col-sm-4">
          <div className='form-group '>
            <label>{t("Protocol ID")} :<span className='text-danger mx-1'>*</span>  </label>
            <div className=''>
              <Field
                className="form-control"
                name="protocolId"
                disabled={extendValue ? true : false}
                value={values.protocolId}
                onChange={(e: any) => {
                  if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes(' ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
                    setFieldValue("protocolId", e.target.value);
                    //  setDisableBtn(false);
                  }
                  // setFieldValue('protocolId', e.target.value.replace(/\s\s+/g, ' '));
                  const _studyDetails = _.cloneDeep(updatedFieldValues);
                  _studyDetails.protocolId = e.target.value
                  dispatch({ type: Types.UPDATED_FIELD_VALUES, payload: _studyDetails });
                  props.enableSubmit(false);
                }}
              />
              <span className='text-danger'><ErrorMessage name='protocolId' /></span>
            </div>
          </div>
        </div>
        <div className="col-sm-4">
          <div className='form-group '>
            <label>{t("Protocol Title")} :<span className='text-danger mx-1'>*</span>  </label>
            <div className=''>
              <Field
                type='text'
                className="form-control"
                name="studyName"
                disabled={extendValue ? true : false}
                value={values.studyName}
                onChange={(e: any) => {
                  if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
                    setFieldValue("studyName", e.target.value);
                    //  setDisableBtn(false);
                  }
                  const _studyDetails = _.cloneDeep(updatedFieldValues);
                  _studyDetails.studyName = e.target.value
                  dispatch({ type: Types.UPDATED_FIELD_VALUES, payload: _studyDetails });
                  props.enableSubmit(false);
                }}
              />
              <span className='text-danger'><ErrorMessage name='studyName' /></span>
            </div>
          </div>
        </div>
        <div className="col-sm-4">
          <div className='form-group '>
            <label>{t("Therapeutic Area")} :<span className='text-danger mx-1'>*</span>  </label>
            <Field
              className="form-select"
              as="select"
              name="therapeuticArea.name"
              disabled={extendValue ? true : false}
              value={values.therapeuticArea && values.therapeuticArea.id}
              onChange={(e: any) => {
                setFieldTouched('therapeuticArea.name', true);
                const findTherapauticArea = conFigData?.THERAPEUTIC?.find((ele: any) => ele.id === parseInt(e.target.value));
                setFieldValue('therapeuticArea', findTherapauticArea ? findTherapauticArea : Study.therapeuticArea);
                const _studyDetails = _.cloneDeep(updatedFieldValues);
                _studyDetails.therapeuticArea = findTherapauticArea ? findTherapauticArea : Study.therapeuticArea
                dispatch({ type: Types.UPDATED_FIELD_VALUES, payload: _studyDetails });
                props.enableSubmit(false);
              }}
            >
              <option value="">{t("Select Therapeutic Area")}</option>
              {
                conFigData?.THERAPEUTIC?.map((item: any, index: number) => (
                  <option key={index} value={item.id}>{item.name}</option>
                ))
              }
            </Field>
            <span className='text-danger'><ErrorMessage name='therapeuticArea.name' /></span>
          </div>
        </div>



      </div>
      <div className='row  mx-3'>
        <div className="col-sm-4">
          <div className='form-group '>
            <label>{t("Indication")} :<span className='text-danger mx-1'>*</span>  </label>
            <Field
              className="form-select"
              as="select"
              name="indication.name"
              disabled={extendValue ? true : false}
              value={values.indication && values.indication.id}
              onChange={(e: any) => {
                setFieldTouched('indication.name', true);
                const findIndication = conFigData?.INDICATION?.find((ele: any) => ele.id === parseInt(e.target.value));
                setFieldValue('indication', findIndication ? findIndication : Study.indication);
                const _studyDetails = _.cloneDeep(updatedFieldValues);
                _studyDetails.indication = findIndication ? findIndication : Study.indication
                dispatch({ type: Types.UPDATED_FIELD_VALUES, payload: _studyDetails });
                props.enableSubmit(false);
              }}
            >
              <option value="">{t("Select Indication")}</option>
              {
                conFigData?.INDICATION?.map((item: any, index: number) => (
                  <option key={index} value={item.id}>{item.name}</option>
                ))
              }

            </Field>
            <span className='text-danger'><ErrorMessage name='indication.name' /></span>
          </div>
        </div>
        <div className="col-sm-4">
          <div className='form-group '>
            <label>{t("Study Design")} :<span className='text-danger mx-1'>*</span>  </label>
            <Field
              className="form-select"
              as="select"
              name="studyDesign.name"
              disabled={extendValue ? true : false}
              value={values.studyDesign && values.studyDesign.id}
              onChange={(e: any) => {
                setFieldTouched('studyDesign.name', true);
                const findStudyDesign = conFigData?.STUDY_DESIGN?.find((ele: any) => ele.id === parseInt(e.target.value));
                setFieldValue('studyDesign', findStudyDesign ? findStudyDesign : Study.studyDesign);
                const _studyDetails = _.cloneDeep(updatedFieldValues);
                _studyDetails.studyDesign = findStudyDesign ? findStudyDesign : Study.studyDesign
                dispatch({ type: Types.UPDATED_FIELD_VALUES, payload: _studyDetails });
                props.enableSubmit(false);
              }}
            >
              <option value="">{t("Select Study Design ")}</option>
              {
                conFigData?.STUDY_DESIGN?.map((item: any, index: number) => (
                  <option key={index} value={item.id}>{item.name}</option>
                ))
              }
            </Field>
            <span className='text-danger'><ErrorMessage name='studyDesign.name' /></span>
          </div>
        </div>
        <div className='col-sm-4'>
          <div className='form-group'>
            <label>{t("Study Phase")} :<span className='text-danger mx-1'>*</span></label>
            <Field
              as="select"
              className="form-select"
              name="ctPhase.name"
              value={values.ctPhase && values.ctPhase.id}
              onChange={(e: any) => {
                setFieldTouched('ctPhase.name', true);
                const _studyDetails = _.cloneDeep(updatedFieldValues);
                const findStudyPhase = conFigData?.STUDY_PHASE?.find((ele: any) => ele.id === parseInt(e.target.value));
                setFieldValue('ctPhase', findStudyPhase ? findStudyPhase : Study.ctPhase);
                _studyDetails.ctPhase = findStudyPhase ? findStudyPhase : Study.ctPhase
                dispatch({ type: Types.UPDATED_FIELD_VALUES, payload: _studyDetails });
                props.enableSubmit(false)
              }}
              disabled={extendValue ? true : false}
            >
              <option value=''>{t("Select Study Phase")}</option>
              {
                conFigData?.STUDY_PHASE?.map((item: any, index: number) => (
                  <option key={index} value={item.id}>{item.name}</option>
                ))
              }
            </Field>
            <span className='text-danger'><ErrorMessage name='ctPhase.name' /></span>
          </div>
        </div>
      </div>
      <div className='row mx-3'>

        <div className='col-sm-4'>
          <div className='form-group my-3'>
            <label>{t("Study Type")} :<span className='text-danger mx-1'>*</span></label>
            <Field
              as="select"
              className="form-select"
              name="studyType.name"
              value={values.studyType && values.studyType.id}
              onChange={(e: any) => {
                setFieldTouched('studyType.name', true);
                const _studyDetails = _.cloneDeep(updatedFieldValues);
                const findStudyType = conFigData?.STUDY_TYPE?.find((ele: any) => ele.id === parseInt(e.target.value));
                setFieldValue('studyType', findStudyType ? findStudyType : Study.studyType);
                _studyDetails.studyType = findStudyType ? findStudyType : Study.studyType
                dispatch({ type: Types.UPDATED_FIELD_VALUES, payload: _studyDetails });
                props.enableSubmit(false)
              }}
              disabled={extendValue ? true : false}
            >
              <option value=''>{t("Select Study Type")}</option>
              {
                conFigData?.STUDY_TYPE?.map((item: any, index: number) => (
                  <option key={index} value={item.id}>{item.name}</option>
                ))
              }
            </Field>
            <span className='text-danger'><ErrorMessage name='studyType.name' /></span>
          </div>
        </div>
        <div className='col-sm-4'>
          <div className='form-group my-3'>
            <label>{t("Regulatory")} :<span className='text-danger mx-1'>*</span></label>
            <Field
              as="select"
              className="form-select"
              name="regulatory.name"
              disabled={extendValue ? true : false}
              value={values.regulatory && values.regulatory.id}
              onChange={(e: any) => {
                setFieldTouched('regulatory.name', true);
                const findRegulatory = conFigData?.REGULATORY?.find((ele: any) => ele.id === parseInt(e.target.value));
                setFieldValue('regulatory', findRegulatory ? findRegulatory : Study.regulatory);
                const _studyDetails = _.cloneDeep(updatedFieldValues);
                _studyDetails.regulatory = findRegulatory ? findRegulatory : Study.regulatory
                dispatch({ type: Types.UPDATED_FIELD_VALUES, payload: _studyDetails });
                props.enableSubmit(false);
              }}
            >
              <option value="">{t("Select Study Regulatory ")}</option>
              {
                conFigData?.REGULATORY?.map((item: any, index: number) => (
                  <option key={index} value={item.id}>{item.name}</option>
                ))
              }
            </Field>
            <span className='text-danger'><ErrorMessage name='regulatory.name' /></span>
          </div>
        </div>
        <div className='col-sm-4'>
          <div className='form-group my-3'>
            <label>{t("Investigation")} :<span className='text-danger mx-1'>*</span></label>
            <Field
              as="select"
              className="form-select"
              name="investigation.id"
              disabled={extendValue ? true : false}
              value={values.investigation && values.investigation.id}
              onChange={(e: any) => {
                setFieldTouched('investigation.name', true);
                const findInvestigation = conFigData?.INVESTIGATION?.find((ele: any) => ele.id === parseInt(e.target.value));
                setFieldValue('investigation', findInvestigation ? findInvestigation : Study.investigation);
                const _studyDetails = _.cloneDeep(updatedFieldValues);
                _studyDetails.investigation.id = findInvestigation ? findInvestigation : Study.investigation
                dispatch({ type: Types.UPDATED_FIELD_VALUES, payload: _studyDetails });
                props.enableSubmit(false);
              }}
            >
              <option value="">{t("Select Investigation ")}</option>
              {
                conFigData?.INVESTIGATION?.map((item: any, index: number) => (
                  <option key={index} value={item.id}>{item.name}</option>
                ))
              }
            </Field>
            <span className='text-danger'><ErrorMessage name='investigation.name' /></span>
          </div>
        </div>
      </div>
      <div className=' row mx-3'>
        <div className='col-sm-4'>
          <div className='form-group '>
            <label>{t("Population")} :<span className='text-danger mx-1'>*</span></label>
            <Field
              as="select"
              className="form-select"
              name="populations.name"
              disabled={extendValue ? true : false}
              value={values.populations && values.populations.id}
              onChange={(e: any) => {
                setFieldTouched('populations.name', true);
                const findPopulations = conFigData?.POPULATION?.find((ele: any) => ele.id === parseInt(e.target.value));
                setFieldValue('populations', findPopulations ? findPopulations : Study.populations);
                const _studyDetails = _.cloneDeep(updatedFieldValues);
                _studyDetails.populations = findPopulations ? findPopulations : Study.populations
                dispatch({ type: Types.UPDATED_FIELD_VALUES, payload: _studyDetails });
                props.enableSubmit(false);
              }}
            >
              <option value="">{t("Select Population ")}</option>
              {
                conFigData?.POPULATION?.map((item: any, index: number) => (
                  <option key={index} value={item.id}>{item.name}</option>
                ))
              }
            </Field>
            <span className='text-danger'><ErrorMessage name='populations.name' /></span> </div>
        </div>
        <div className='col-sm-4'>
          <div className='form-group'>
            <label>{t("Start Date")} :<span className='text-danger mx-1'>*</span></label>
            <div className=''>
              <Field
                type='date'
                className="form-control"
                name="startDate"
                value={values.startDate}
                max="9999-12-31"
                // minDate={values.startDate}
                validate={startDateValidation}
                format="dd-mm-yyyy"
                onChange={(e: any) => {
                  //  setMinDate(e.target.value)
                  setFieldTouched('startDate', true);
                  setFieldTouched('endDate', false);
                  setFieldValue('startDate', e.target.value);
                  const _studyDetails = _.cloneDeep(updatedFieldValues);
                  _studyDetails.startDate = e.target.value
                  dispatch({ type: Types.UPDATED_FIELD_VALUES, payload: _studyDetails });
                  props.enableSubmit(false)
                }}
              />
              <span className='text-danger'><ErrorMessage name='startDate' /></span>
            </div>
          </div>
        </div>
        <div className="col-sm-4">
          <div className='form-group '>
            <label>{t("End Date")} :<span className='text-danger mx-1'>*</span></label>
            <Field
              type='date'
              className="form-control"
              name="endDate"
              value={values.endDate}
              max="9999-12-31"
              // min={disablePastDate()}
              validate={endDateValidation}
              onChange={(e: any) => {
                // setMaxDate(e.target.value)
                setFieldTouched('endDate', true);
                setFieldTouched('startDate', false);
                setFieldValue('endDate', e.target.value)
                const _studyDetails = _.cloneDeep(updatedFieldValues);
                _studyDetails.endDate = e.target.value
                dispatch({ type: Types.UPDATED_FIELD_VALUES, payload: _studyDetails });
                props.enableSubmit(false)
              }}
            />
            {errors.endDate && touched.endDate ? (
              <div className='text-danger'>{errors.endDate}</div>
            ) : null}
          </div>
        </div>
      </div>
      <div className='row mx-3'>
        <div className="col-sm-4">
          <div className='form-group my-3'>
            <label>{t("Sponser/CRO")} :<span className='text-danger mx-1'>*</span></label>
            <div className=''>
              <div className='d-flex align-items-center'>
                <Field
                  as="select"
                  className="form-select"
                  name="organization.orgName"
                  value={values.organization && values.organization.id}
                  onChange={(e: any) => {
                    const _studyDetails = _.cloneDeep(updatedFieldValues);
                    const findOrgDetails = allOrganization && allOrganization.find((ele: any) => ele.id === parseInt(e.target.value));
                    setFieldTouched('organization.orgName', true);
                    setFieldValue('organization', findOrgDetails ? findOrgDetails : Study.organization);
                    _studyDetails.organization = findOrgDetails ? findOrgDetails : Study.organization
                    dispatch({ type: Types.UPDATED_FIELD_VALUES, payload: _studyDetails });
                    onOrganizationChange(e);
                    props.enableSubmit(false);
                    setPrimaryValueErr('')
                    setSecondaryContactErr('')
                  }}
                  disabled={extendValue ? true : false}
                >
                  <option value=''>{t("Select Sponser/CRO")}</option>
                  {
                    allOrganization && allOrganization.map((item: any, index: any) => {
                      return (
                        <option key={index} value={item.id}>{item.orgName}</option>
                      )
                    })
                  }
                </Field>
                {/* {!extendValue && <CustomizedTooltip title={t("Add Organiztion")}>
                  <AddCircleOutlineOutlinedIcon
                    className={`${!extendValue ? 'add-primary-icon' : extendValue ? 'add-secondary-icon' : 'circle-icon mx-2'}`}
                    fontSize='medium' onClick={() => {
                      if (!extendValue) {
                        dispatch(navigateToCreate('fromStudy'))
                        dispatch({ type: Types.CREATE_STUDY_PAYLOAD, payload: values })
                        let _studyDetails = _.cloneDeep(updatedFieldValues);
                        _studyDetails.studyItems = [{ value: "", documentTypeId: "" }]
                        dispatch({ type: Types.INITIATE_NEW_STUDAY, payload: _studyDetails });
                        navigate('/createorganization');
                      }
                    }}
                  /></CustomizedTooltip>} */}

              </div>
              <span className='text-danger'><ErrorMessage name='organization.orgName' /></span>
            </div>
          </div>
        </div>
        <div className='col-sm-4'>
          <div className='form-group my-3'>
            <label>{t("Approver")}:<span className='text-danger mx-1'>*</span></label>
            <Field
              as="select"
              className="form-select"
              name="approver.userName"
              value={values && values?.approver && values?.approver?.userId}
              disabled={extendValue ? true : false}
              onChange={(e: any) => {
                const _studyDetails = _.cloneDeep(updatedFieldValues);
                const findApprover = approveList && approveList.find((ele: any) => ele.userId === parseInt(e.target.value))
                setFieldValue('approver', findApprover ? findApprover : Study.approver);
                // setFieldTouched('approver', true)
                _studyDetails.approver = findApprover ? findApprover : Study.approver
                dispatch({ type: Types.UPDATED_FIELD_VALUES, payload: _studyDetails });
                props.enableSubmit(false)
              }}
            >
              <option value=''>{t("Select Approver")}</option>
              {
                approveList && approveList.map((item: any, index: any) => {
                  return (
                    (item.userId !== user.userId && item.isActive === true) &&
                    <option key={index} disabled={item.userId === user.userId ? true : false} value={item.userId}>
                      {item.userName ? item.userName : ''}</option>)
                  // if (item.userId !== user.userId) {
                  //   if (item.isActive === true) {
                  //     return (
                  //       <option key={index} disabled={item.userId === user.userId ? true : false} value={item.userId}>
                  //         {item.userName ? item.userName : ''}</option>)
                  //   }
                  // }
                })}
            </Field>
            <span className='text-danger'><ErrorMessage name='approver.userName' /></span>
          </div>
        </div>
        <div className="col-sm-4">
          <div className='form-group my-3'>
            <label>{t("Visit Count")} :<span className='text-danger mx-1'>*</span> </label>
            <Field
              className="form-control"
              name="visitsCount"
              type='number'
              min={1}
              // pattern="[0-9]*"
              value={values.visitsCount}
              disabled={extendValue ? true : false}
              onKeyPress={(e: any) => {
                if (e.key === "-" || e.key === "+" || e.key === "e" || e.key === ".") {
                  e.preventDefault();
                }
              }}
              onChange={(e: any) => {
                setFieldTouched('visitsCount', true)
                setFieldValue('visitsCount', e.target.value.replace(/\s\s+/g, ' '));
                const _studyDetails = _.cloneDeep(updatedFieldValues);
                _studyDetails.visitsCount = e.target.value
                dispatch({ type: Types.UPDATED_FIELD_VALUES, payload: _studyDetails });
                props.enableSubmit(false);
              }}
            />
            <span className='text-danger'><ErrorMessage name='visitsCount' /></span>
          </div>
        </div>
      </div>
      <div className='row mx-3'>
        <div className="col-sm-4">
          <div className='form-group my-3'>
            <label>{t("Sample Size")} :<span className='text-danger mx-1'>*</span> </label>
            <Field
              className="form-control"
              name="subjectSampleSize"
              type='number'
              min={1}
              value={values.subjectSampleSize}
              disabled={extendValue ? true : false}
              onKeyPress={(e: any) => {
                if (e.key === "-" || e.key === "+" || e.key === "e" || e.key === ".") {
                  e.preventDefault();
                }
              }}
              onChange={(e: any) => {
                preventMinus(e)
                setFieldTouched('subjectSampleSize', true)
                setFieldValue('subjectSampleSize', e.target.value.replace(/\s\s+/g, ' '));
                const _studyDetails = _.cloneDeep(updatedFieldValues);
                _studyDetails.subjectSampleSize = e.target.value
                dispatch({ type: Types.UPDATED_FIELD_VALUES, payload: _studyDetails });
                props.enableSubmit(false);
              }}
            />
            <span className='text-danger'><ErrorMessage name='subjectSampleSize' /></span>
          </div>
        </div>
        <div className="col-sm-4">
          <div className='form-group my-3'>
            <label>{t("Dose this Study Related To Labs ?")} :<span className='text-danger mx-1'>*</span> </label>
            <div role="group" aria-labelledby="my-radio-group">
              <div className='d-flex mt-1'>
                <div className="d-flex form-check form-check-inline align-items-center">
                  <Field type="radio" className='' id='labExistTrue'
                    name="labExist" value="true"
                    onChange={(e: any) => {
                      // setSubmitDisabled(false)
                      setFieldValue('labExist', e.target.value)
                      const _studyDetails = _.cloneDeep(updatedFieldValues);
                      _studyDetails.labExist = e.target.value
                      dispatch({ type: Types.UPDATED_FIELD_VALUES, payload: _studyDetails });
                      props.enableSubmit(false);
                    }}
                  /><label htmlFor='labExistTrue' className="ps-2" >Yes</label>
                </div>
                <div className="d-flex form-check form-check-inline align-items-center">
                  <Field type="radio" className='' id='labExistFalse'
                    name="labExist" value="false"
                    onChange={(e: any) => {
                      // setSubmitDisabled(false)
                      setFieldValue('labExist', e.target.value)
                      const _studyDetails = _.cloneDeep(updatedFieldValues);
                      _studyDetails.labExist = e.target.value
                      dispatch({ type: Types.UPDATED_FIELD_VALUES, payload: _studyDetails });
                      props.enableSubmit(false);
                    }}
                  />
                  <label htmlFor='labExistFalse' className=" ps-2" >No</label>
                </div>
              </div>
              <span className='text-danger'><ErrorMessage name='labExist' /></span>
            </div>
          </div>
        </div>
      </div>
    </React.Fragment >
  )
}
export default StudyDetails;