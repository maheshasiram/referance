import React from "react";
import { useDispatch, useSelector } from 'react-redux';
import { Field } from 'formik';
import _ from 'lodash';
import { useTranslation } from 'react-i18next';
import { Types } from '../../reducer/Types';

function Comment(props: any) {
    const { t } = useTranslation();
    const dispatch = useDispatch()
    const { setFieldValue, extendValue } = props
    const {  updatedFieldValues } = useSelector((state: any) => state.study);

    return (
        <React.Fragment>
            <div className='col-sm-4'>
                <div className='ms-4'> <h6>{t("Comments")} :</h6></div>
                <hr className='m-0'></hr>
                <div className='form-group ms-5'>
                    <label>{t("Comments")}:</label>
                    <Field
                        as="textarea"
                        className="form-control"
                        name="comments"
                        // value={values.comments}
                        disabled={extendValue ? true : false}
                        onChange={(e: any) => {
                            if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
                                setFieldValue("comments", e.target.value);
                                //  setDisableBtn(false);
                              }
                            // setFieldValue('comments', e.target.value)
                            const _studyDetails = _.cloneDeep(updatedFieldValues);
                            _studyDetails.comments = e.target.value
                            dispatch({ type: Types.UPDATED_FIELD_VALUES, payload: _studyDetails });
                            props.enableSubmit(false)
                        }}
                    />
                    {/* {errors.comments && touched.comments ? (
              <div className='text-danger'>{errors.comments}</div>
            ) : null} */}
                </div>
            </div>
        </React.Fragment>
    )
}
export default Comment