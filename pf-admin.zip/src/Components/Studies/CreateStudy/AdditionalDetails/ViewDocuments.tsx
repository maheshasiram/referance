
import React from 'react';
import CustomDialog from '../../../../Common/modals/CustomDialog';
import DownloadIcon from '@mui/icons-material/Download';
import DeleteIcon from '@mui/icons-material/Delete';
import DocumentScannerIcon from '@mui/icons-material/DocumentScanner';
import { downloadStudyDocument } from '../../Actions/actions';
import { useDispatch, useSelector } from 'react-redux';
import { Types } from '../../reducer/Types';
import { Confirm, toastAlert } from '../../../../actions/actions';
import _ from "lodash";
import { messages } from '../../../../configs/messages';
import CustomizedTooltip from '../../../../Common/CustomizedTooltip/CustomizedTooltip';
import { useTranslation } from 'react-i18next';
import { toastMsg } from '../../../../Common/Messages';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';

function ViewDocuments(props: any) {
  const dispatch = useDispatch();
  const [open, setOpen] = React.useState(false);
  const { extendValue, deletedStudyDocuments } = useSelector((state: any) => (state.study));
  const { t } = useTranslation();
  const onClickHandler = () => {
    setOpen(true);
  }

  const onCloseHandler = () => {
    setOpen(false);
  }

  const actionsBodyTemplate = (rowData: any) => {

    return (
      <div className='d-flex action-icons'>
        <div className='download-icon'><CustomizedTooltip title={t("Download Document")}>
          <DownloadIcon onClick={() => onDownloadDocument(rowData.id, rowData.fileName)} />
        </CustomizedTooltip></div>
        <span> | </span>
        {(props.isDelete && !extendValue) &&
          (
            <div className='delete-icon'>
              <CustomizedTooltip title={t("Delete Document")}>
                <DeleteIcon onClick={() => onDeleteDocument(rowData.id)} sx={{ fontSize: 15, cursor: 'pointer' }} />
              </CustomizedTooltip>
            </div>
          )}
      </div>
    )
  }

  const onDownloadDocument = (id: number, fileName: string) => {
    dispatch(downloadStudyDocument(id, fileName));
  }

  const onDeleteDocument = (id: number) => {
    dispatch(Confirm({
      status: 0,
      message: messages.study.studyDocument,
      onOk: () => {
        const { values } = props;
        const documents = [...[], ...values.studyDocuments];
        const index = documents.findIndex((item: any) => item.id === id);
        documents.splice(index, 1);
        values.studyDocuments = documents;
        const _deletedStudyDocuments = _.cloneDeep(deletedStudyDocuments);
        _deletedStudyDocuments !== null && _deletedStudyDocuments.push(id);
        props.enableSubmit(false)
        setTimeout(() => {
          dispatch(toastAlert({
            status: 1,
            message: toastMsg(messages.study.DocumentDeleted, ''),
            open: true,
          }))
          // dispatch(Alert({
          //   status: 2, 
          //   message: messages.study.DocumentDeleted, 
          //   onOk: () => {
          //      // dispatch({ type: Types.GET_STUDY_DETAILS, payload: values });
          //       // dispatch({type: Types.DELETED_STUDY_DOCUMENTS, payload: _deletedStudyDocuments});
          //   }
          // }))
        }, 100);
        dispatch({ type: Types.DELETED_STUDY_DOCUMENTS, payload: _deletedStudyDocuments });
      }
    }))
  }
  
  return (
    <React.Fragment>
      <CustomizedTooltip title={t("View Document")}>
        <DocumentScannerIcon onClick={() => onClickHandler()} sx={{ fontSize: 15, cursor: 'pointer' }} /></CustomizedTooltip>
      <CustomDialog
        title={t("Documents")}
        onClose={onCloseHandler}
        // onSubmitHandler={onCloseHandler}
        fullWidth={false}
        open={open}
        maxWidth={'sm'}
        form=""
        className="create-dy-field"
        disabled={false}
      // actionType={'Submit'}
      >
        <div className='' style={{ width: 350, minHeight: 300, maxHeight: 300, overflow: 'auto' }}>
          <DataTable
            value={props.documents}
            scrollable>
            <Column field='fileName' header="Document "></Column>
            <Column field='documentType.name' header="Type"></Column>
            <Column body={actionsBodyTemplate} header="Actions"></Column>
          </DataTable>
          {/* <ul className='p-0 m-0'>
            {props.documents.map((item: any,index:number) => (
              <li className='d-flex justify-content-start'>
                <div key={index} className='d-inline-flex w-50'> {item && item.fileName} </div>
                <div key={index} className='d-inline-flex w-25'>{item.documentType && item.documentType.name}</div>
                <div className='d-inline-flex w-25 align-items-center justify-content-end'>
                <CustomizedTooltip title={t("Download Document")}>
                  <DownloadIcon onClick={() => onDownloadDocument(item.id, item.fileName)} sx={{ fontSize: 15, cursor: 'pointer' }} />
                  </CustomizedTooltip>
                  {(props.isDelete && !extendValue) &&
                    (<CustomizedTooltip title={t("Delete Document")}>
                    <DeleteIcon onClick={() => onDeleteDocument(item.id)} sx={{ fontSize: 15, cursor: 'pointer' }} />
                    </CustomizedTooltip>)                  }
                </div>
              </li>
            ))
            }
          </ul> */}
        </div>
      </CustomDialog>
    </React.Fragment>
  )

}

export default ViewDocuments;