import React from 'react';
import { Field, FieldArray } from 'formik';
import { useDispatch, useSelector } from 'react-redux';
import ViewDocuments from './ViewDocuments';
import _ from 'lodash';
import { useTranslation } from 'react-i18next';
import { Types } from '../../reducer/Types';
import { useParams } from 'react-router-dom';

function AdditionalDetails(props: any) {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const params: any = useParams();
  const { touched, values, setFieldValue, extendValue, fileTypeError, setFileTypeError, enableSubmit } = props
  const { documentTypes } = useSelector((state: any) => state.users);

  // const [documenSelectError, setDocumenSelectError] = React.useState('');
  const [documentError, setDocumentError] = React.useState('');
  const { actionType, studyDetails } = useSelector((state: any) => state.study);

  React.useEffect(() => { // for Updating docuemntType -Nitish
    const _study = _.cloneDeep(studyDetails);
    if (parseInt(params.id) === 0) {
      const documentId = documentTypes?.find((docType: any) => docType.code === 'DOC_TYPE_EMAIL')
      _study.studyDocuments[0].documentTypeId = documentId?.id;
      _study.studyItems[0].documentTypeId = documentId?.id;
      dispatch({ type: Types.INITIATE_NEW_STUDAY, payload: _study })
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [documentTypes])

  return (
    <React.Fragment>
      <div className='ms-4'> <h6>{t("Approval Documents")} :</h6></div>
      <hr className='m-0'></hr>
      <div className='row my-3 mx-3 AdditonalDetails'>
        <div className='col-sm-8'>
          <FieldArray
            name="studyItems"
            render={() => {
              const documents = values.studyItems;
              return (
                <React.Fragment>
                  <div className='row d-flex mt-1'>
                    <label className='col-6 d-flex' id='label'>{t("Document Types")} :<span className='text-danger mx-1'>*</span></label>
                    <label className='col-6 d-flex' >{t("Sign Off Document")} :<span className='text-danger mx-1'>*</span>
                      {/* {!extendValue && <CustomizedTooltip title={t("Add Documents")}> */}
                      {/* <AddCircleOutlineOutlinedIcon e
                       className={`${!extendValue ? 'add-primary-icon' : extendValue ? 'add-secondary-icon' : 'circle-icon'}`} 
                      fontSize='medium'
                        onClick={(e: any) => {
                          if (values.studyItems[values.studyItems.length -1].documentTypeId !== '' && values.studyItems[values.studyItems.length -1]?.value !== '') {
                            arrayHelpers.push({ value: "", documentTypeId: "" })
                          } else {
                               setDocumentError("Sign Off Document & Document Type can't be empty");
                          }
                        }}
                      /></CustomizedTooltip>} */}
                      {(values.studyDocuments[0] && values.studyDocuments[0].documentType !== '' && values.studyDocuments[0].value !== '') && (
                        <ViewDocuments
                          className="ml-5"
                          isDelete={true}
                          values={values}
                          documents={values.studyDocuments}
                          enableSubmit={enableSubmit}
                        />
                      )}
                    </label>
                  </div>
                  <div className='text-danger'>{documentError} </div>
                  {documents && documents.map((user: any, index: any) => (
                    <div className='row mb-1' key={index}>
                      <div className='col-6'>
                        <div className='d-flex align-items-center'>
                          <Field
                            as="select"
                            className="form-select"
                            name={`documents.${index}.documentTypeId`}
                            value={parseInt(params.id) <= 0 ? studyDetails?.studyDocuments[0]?.documentTypeId : studyDetails?.studyDocuments[0]?.documentType?.id} //Nitish
                            id='documentTypeId'
                            placeholder={t("Select Document")}
                            onChange={(event: any) => {
                              // setFieldValue(`studyItems.${index}.documentTypeId`, event.target.value);
                              setFieldValue(`docType`, event.target.value);
                              setDocumentError('');
                              enableSubmit(false)
                            }}
                            // disabled={extendValue ? true : false}
                            disabled={true}
                          >
                            <option value="">{t("Select Document Type")}</option>
                            {documentTypes && documentTypes.map(
                              (item: any, index: any) => (
                                <option key={index} value={item.id} id="sel-groupname">
                                  {item.name}
                                </option>
                              )
                            )}
                          </Field >
                          {/* {index > 0 &&
                          <CustomizedTooltip title={t("Remove Documents")}>
                            <RemoveCircleOutlineIcon className='mx-2'
                            sx={{ color: '#e45247', cursor: 'pointer' }}
                            onClick={() => { arrayHelpers.remove(index);
                              setDocumentError(''); }} /></CustomizedTooltip> } */}
                        </div>
                        {/* <div className="text-danger">
                          {actionType === 'create' ?
                            (touched.studyDocuments && touched.studyDocuments[index]?.documentTypeId && !values.studyItems[0]?.documentTypeId) && <div className='text-danger'>{t("Please Select Document Type")}</div> :
                            (values.studyDocuments && values.studyDocuments.length == 0 && !values.studyItems[0]?.documentTypeId || values.studyItems[0]?.value && !values.studyItems[0]?.documentTypeId)
                            && <div className='text-danger'>{t("Please Select Document Type")}</div>}
                        </div> */}
                      </div>
                      <div key={index} className=" align-items-center col-6">
                        <Field
                          type="file"
                          className="form-control"
                          name={`documents.${index}.value`}
                          // name={`studyDocuments.${index}.value`}
                          // value={studyDetails?.studyDocuments}
                          id={`text-restext-${index}`}
                          Accept={'.pdf,.jpg,.msg'}
                          disabled={(extendValue) || (values?.studyDocuments.length > 0 && values?.studyDocuments[0].value !== '' && parseInt(params.id) > 0 && !fileTypeError) ? true : false}
                          onChange={(event: { currentTarget: { files: any; }; }) => {
                            //validation for upload document as per new requirement -Akshay
                            setFieldValue(`studyItems.${index}.value`, event.currentTarget.files[0]);
                            if (event?.currentTarget?.files[0]?.type === 'image/jpeg'
                              || event?.currentTarget?.files[0]?.type === "application/pdf"
                            ) {
                              setFieldValue(`studyItems.${index}.value`, event.currentTarget.files[0]);
                              setFileTypeError(false)
                              setDocumentError('')
                              enableSubmit(false)
                              //validating with endwith for .msg fileType -Tirumal
                            } else if (event?.currentTarget?.files[0]?.type === '' && event?.currentTarget?.files[0]?.name?.endsWith('.msg')) {
                              const mailFile = new File([event?.currentTarget?.files[0]], event?.currentTarget?.files[0].name, { type: 'application/vnd.ms-outlook' });
                              setFieldValue(`studyItems.${index}.value`, mailFile);
                              setFileTypeError(false)
                              setDocumentError('')
                              enableSubmit(false)
                            }
                            else {
                              setFileTypeError(true)
                              // enableSubmit(true)
                            }
                          }}
                        />
                        {
                          fileTypeError ? <p className='text-danger'>
                            Please upload only .msg/.pdf/.jpg file format
                          </p> : <div className='info'>
                            Note: <i>Please upload only .msg/.pdf/.jpg</i>
                          </div>
                        }
                        <p className="text-danger">
                          {actionType === 'create' ?
                            (touched.studyDocuments && touched.studyDocuments[index]?.value && !values.studyItems[0]?.value) && <div className='text-danger'>{t("Please Upload Document")}</div> :
                            (((values.studyDocuments && values.studyDocuments.length === 0) && !values.studyItems[0]?.value) || (!values.studyItems[0]?.value && values.studyItems[0]?.documentTypeId))
                            && <div className='text-danger'>{t("Please Upload Document")}</div>}
                        </p>
                      </div>
                    </div>
                  ))}
                </React.Fragment>
              );
            }}
          />
        </div>
        {/* <div className='col-sm-4'>
          <div className='form-group'>
            <label>{t("Comments")}:</label>
            <Field
              as="textarea"
              className="form-control"
              name="comments" */}
        {/* // value={values.comments} */}
        {/* disabled={extendValue ? true : false}
              onChange={(e: any) => {
                setFieldValue('comments', e.target.value)
                let _studyDetails = _.cloneDeep(updatedFieldValues);
                _studyDetails.comments = e.target.value
                dispatch({ type: Types.UPDATED_FIELD_VALUES, payload: _studyDetails });
                props.enableSubmit(false)
              }}
            /> */}
        {/* {errors.comments && touched.comments ? (
              <div className='text-danger'>{errors.comments}</div>
            ) : null} */}
        {/* </div>
        </div> */}
      </div>


    </React.Fragment>
  )
}
export default AdditionalDetails;