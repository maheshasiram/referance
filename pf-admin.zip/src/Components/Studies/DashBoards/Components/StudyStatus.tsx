import React from 'react'
import ReactECharts from 'echarts-for-react';
import { useSelector } from 'react-redux';
import { useTranslation } from 'react-i18next';

const StudyStatus = () => {
    const { t } = useTranslation();
    const { studies } = useSelector((state: any) => state.study);

    const approvalStatus = ['Draft', 'Hold', 'Submit For Approval', 'Approved', 'Rejected',
        "Provisioned", 'Bookmarked', 'Submit For Re-Approval', 'Devops Rejected']

    const data = approvalStatus.map((i: any) => {
        const val = studies?.studydetails?.filter((item: any) =>
            item.approvalStatus.name.toLowerCase() === i.toLowerCase()
        )
        return val
    }).filter((j: any) => {
        return (
            (j.length > 0) && j
        )
        // if (j.length > 0) {
        //     return j
        // }
    }).map((i: any) => {
        return { value: i.length, name: t(i[0].approvalStatus.name) }
    })

    // const Draft = studies?.studydetails?.filter((item: any) => item.approvalStatus.name == 'Draft').length
    // const Hold = studies?.studydetails?.filter((item: any) => item.approvalStatus.name == 'Hold').length
    // const Submit_For_Approval = studies?.studydetails?.filter((item: any) => item.approvalStatus.name == 'Submit For Approval').length
    // const Approved = studies?.studydetails?.filter((item: any) => item.approvalStatus.name == 'Approved').length
    // const Rejected = studies?.studydetails?.filter((item: any) => item.approvalStatus.name == 'Rejected').length
    // const Provisioned = studies?.studydetails?.filter((item: any) => item.approvalStatus.name == "provisioned").length
    // const bookmarked = studies?.studydetails?.filter((item: any) => item.approvalStatus.name == 'Bookmarked').length
    // const reApproval = studies?.studydetails?.filter((item: any) => item.approvalStatus.name == 'Submit For Re-Approval').length

    //     var _legendData:any = []
    //     legendData.map((item: any, index: any)=>{
    //         let legendDataCount =  studies.filter((ite: any) => ite.approvalStatus.name == item).length
    //         _legendData.push(item + ': '+ legendDataCount)
    //     })

    // var studyStatusLegend: any = [];
    // var studyStatusData: any = [];
    // _.map(studies, (item: any, index: any) => {

    //     let data = { value: 0, name: item.approvalStatus.name }

    //     if (studyStatusLegend.indexOf(item.approvalStatus.name) === -1) {
    //         studyStatusLegend.push(item.approvalStatus.name);
    //         studyStatusData.push(data)
    //     }
    // });
    // studyStatusData.map((item: any, index: any) => {
    //     if (item.value == 0) {
    //         item.value = studies.filter((itm: any, index: any) => itm.approvalStatus.name === item.name).length
    //     }
    // })

    const option = {
        tooltip: {
            trigger: 'item',
            formatter: "{b}: <strong>{c}</strong>",
            responsive: true,
            backgroundColor: 'rgba(50, 50, 50, 0.7)',
            borderRadius: ' 4px',
            textStyle: {
                color: 'rgb(255, 255, 255)',
                fontSize: '13px'
            }
        },
        legend: {
            orient: 'vertical',
            shape: 'circle',
            top: 'middle',
            bottom: 50,
            right: 0,
            selectedMode: false,
            itemGap: 4,
            itemWidth: 15,
            // data: [`${t("Draft")}`, `${t("Hold")}`, `${t("Approved")}`, `${t("Rejected")}`,
            // `${t("bookmarked")}`, `${t("Submit For Approval")}`,
            // `${t("Provisioned")}`, `${t("Submit For ReApproval")}`],
            data: data,
        },
        series: [
            {
                type: 'pie',
                right: 150,
                radius: '50%',
                center: ['50%', '50%'],
                selectedMode: 'single',
                label: {
                    show: true
                },
                // data: [
                //     { value: Draft, name: `${t("Draft")}` },
                //     { value: Approved, name: `${t("Approved")}` },
                //     { value: Hold, name: `${t("Hold")}` },
                //     { value: Rejected, name: `${t("Rejected")}` },
                //     { value: Submit_For_Approval, name: `${t("Submit For Approval")}` },
                //     { value: Provisioned, name: `${t("Provisioned")}` },
                //     { value: bookmarked, name: `${t("bookmarked")}` },
                //     { value: reApproval, name: `${t("Submit For ReApproval")}` },
                // ],
                data: data

            }
        ]
    };
    return <ReactECharts option={option} />;
}

export default StudyStatus

