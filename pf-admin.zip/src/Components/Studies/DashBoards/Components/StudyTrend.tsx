import React, { useEffect, useState } from 'react'
import ReactECharts from 'echarts-for-react';
import { useSelector } from 'react-redux';
import moment from 'moment';



const StudyTrend = () => {
    const { studies } = useSelector((state: any) => state.study);
    const [studyCreatedMonths, setStudyCreatedMonths] = useState([]);
    const [studiesLength, setStudiesLength] = useState([]);
    const loaded = React.useRef(false);

    // console.log("studies...14",studies)

    useEffect(() => {
        if (!loaded.current) {
            let months: any = [];
            const d = new Date();
            d.setDate(1);
            let i;
            for (i = 0; i <= 11; i++) {
                months.push(moment(d).format("MMM YY"));
                d.setMonth(d.getMonth() - 1);
            }
            months = months.reverse();
            setStudyCreatedMonths(months);
            const studiesCount: any = []
            months.map((date: any) => {
                const noOfStudies = studies?.studydetails?.filter((item: any) => moment(item.startDate).format("MMM YY") === date).length
               return studiesCount.push(noOfStudies);
            });
            // console.log("studiesCount",studiesCount)
            setStudiesLength(studiesCount);
            loaded.current = true
        }
    }, [studies]);


    const option = {
        xAxis: {
            type: 'category',
            data: studyCreatedMonths,
            axisLabel: {
                showMaxLabel: true,
                interval: 0,
                rotate: 35,
                fontSize: 11
            }
        },
        yAxis: {
            type: 'value'
        },
        tooltip: {
            trigger: 'axis',
            formatter: "Date:<strong> {b}</strong><br/> Studies: <strong>{c}</strong>",
            responsive: true,
            backgroundColor: 'rgba(50, 50, 50, 0.7)',
            borderRadius: ' 4px',
            textStyle: {
                color: 'rgb(255, 255, 255)',
                fontSize: '13px'
            }
        },
        grid: {
            left: '8%',
            right: '5%',
            top: 20,
            bottom: 35
        },
        series: [{
            data: studiesLength,
            type: 'line'
        }]
    };
    return (
        <div className='TrendChart'>
            <ReactECharts option={option} />
        </div>
    )
}

export default StudyTrend;
