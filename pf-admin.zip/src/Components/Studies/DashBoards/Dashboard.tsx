/* eslint-disable no-script-url */
import { DataTable } from 'primereact/datatable';
import 'primeicons/primeicons.css';
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import { Column } from 'primereact/column';
// import 'primeicons/primeicons.css';
import moment from "moment";
import './Styles/styles.scss'
import StudyStatus from './Components/StudyStatus';
import StudyTrend from './Components/StudyTrend';
import React, { useRef } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { Alert, Confirm, fetchConfigData, toastAlert } from '../../../actions/actions';
import { useDispatch, useSelector } from 'react-redux';
import { Types } from '../reducer/Types';
// import { useNavigate } from 'react-router-dom';
import { Study } from '../Constants/DataTypes';
import {
  deleteStudyById, activateByStudyId, findstudiesByUser
} from '../Actions/actions';
import { messages } from '../../../configs/messages';
import { Button } from 'primereact/button';

import CustomizedTooltip from '../../../Common/CustomizedTooltip/CustomizedTooltip'
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import { useTranslation } from 'react-i18next';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import ClearSharpIcon from '@mui/icons-material/ClearSharp';
import { backToStudy, Downloads } from '../../Organization/actions/actions';
import { confirmMsg, toastMsg } from '../../../Common/Messages';
import _ from "lodash";
import Loader from '../../../Common/Loader';
// getConfigdataByCode



const Dashboard = () => {

  const { t } = useTranslation();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [filter, setFilter] = React.useState('protocolId');
  const [searchValue, setSearchValue] = React.useState('');
  const [first, setFirst] = React.useState(0)
  const dt = useRef(null)
  const [statusValue, setStatusValue] = React.useState('true')
  const { user, allConFigData } = useSelector((state: any) => state.app)
  const { studies, studyPayload, studyDetailsdownload } = useSelector((state: any) => state.study);
  const [pageClick, setpageChange] = React.useState(false);
  const loaded = React.useRef(false);

  console.log(first)

  React.useEffect(() => {
    if (!loaded.current && user.userId > 0) {
      // dispatch(getConfigdataByCode('CONTACT_TYPE'))
      const _payload = { ...studyPayload, userId: user.userId, studyStatus: true, offset: 0, protocolId: '', approvalStatus: '', studyPhase: '', isStudyApprover: true }
      dispatch({ type: Types.STUDY_PAYLOAD, payload: _payload })
      dispatch({ type: Types.INITIATE_NEW_STUDAY, payload: Study });
      dispatch(fetchConfigData('REGION'))
      dispatch(findstudiesByUser(_payload));
      loaded.current = true
    }
  }, [dispatch, user, studyPayload])


  const onDeleteStudy = (rowData: any) => {
    (dispatch as any)(Confirm({
      status: 0,
      message: confirmMsg(messages.commonMessages.delete, rowData.protocolId),
      onOk: () => {
        const deletePayload = { studyId: rowData.id }
        dispatch(deleteStudyById(deletePayload, (data: any) => {
          if (data.status === 500) {
            (dispatch as any)(Alert({
              status: 1,
              message: data.error,
            }))
          }
          else if (!data.errorCode) {
            dispatch(toastAlert({
              status: 1,
              message: toastMsg(messages.study.studyDeletedSuccess, rowData.protocolId),
              open: true
            })
            )
            const payload = { ...studyPayload, offset: 0 }
            dispatch({ type: Types.STUDY_PAYLOAD, payload: payload })
            dispatch(findstudiesByUser(payload))
          }
        }))
      }
    }));
  }
  const onUpdateStudy = (rowData: any) => {
    // console.log("rowdata", rowData)
    dispatch({ type: Types.ON_EXTEND_CLICK, payload: false });
    navigate(`/createStudy/${rowData.id}`);
    sessionStorage.removeItem('extend');
    // console.log('..', first);

  }

  const onExtendStudy = (rowData: any) => {
    dispatch({ type: Types.ON_EXTEND_CLICK, payload: true });
    sessionStorage.setItem('extend', 'true');
    navigate(`/createStudy/${rowData.id}`);
  }

  const onActivateStudy = (rowData: any) => {
    (dispatch as any)(Confirm({
      status: 0,
      message: messages.study.ActivateStudy,
      onOk: () => {
        dispatch(activateByStudyId(rowData.id, (data: any) => {
          if (data) {
            const payload = { ...studyPayload, offset: 0 }
            dispatch({ type: Types.STUDY_PAYLOAD, payload: payload })
            dispatch(findstudiesByUser(payload))
          }
          dispatch(toastAlert({
            status: 1,
            message: toastMsg(messages.study.studyActivatedSuccess, rowData.protocolId),
            open: true
          }))
          // dispatch(Alert({
          //   status: 2, message: messages.study.studyActivatedSuccess, 
          //   onOk: () => {
          //     if (data) {
          //       let payload = { ...studyPayload, offset: 0 }
          //       dispatch({ type: Types.STUDY_PAYLOAD, payload: payload })
          //       dispatch(findstudiesByUser(payload))
          //     }

          //     // if( studyPayload?.offset >= (studies?.totalRecords-1)){
          //     //   let   payload = { ...studyPayload , offset:studyPayload.offset-10}
          //     //   dispatch({ type: Types.STUDY_PAYLOAD, payload: payload })
          //     //   dispatch(findstudiesByUser(payload)) 
          //     // }
          //   }
          // }))
        }))
      }
    }));

  }
  const statusBodyTemplate = (rowData: any) => {
    // const { WF_STATUS_TYPE_DRAFT, WF_STATUS_TYPE_HOLD, WF_STATUS_TYPE_REJECTED } = config;

    return <div className={`${rowData.approvalStatus.code === allConFigData?.Draft ? 'st-draft' :
      rowData.approvalStatus.name === 'In Progress' ? 'st-inprogress' :
        rowData.approvalStatus.code === allConFigData?.Hold ? 'st-hold' :
          rowData.approvalStatus.code === allConFigData?.Rejected ? 'st-rejected' : 'st-completed'
      }`}>{rowData.approvalStatus.name}</div>;
  }

  const titleBodyTemplate = (rowData: any) => {

    // const {  WF_STATUS_TYPE_SUBMIT_RE_APPROVAL } = config;

    return (
      <NavLink to={user?.userRolePrivileges?.data?.StudyApprover ? `../study/${rowData.id}` : (user?.userRolePrivileges?.data?.DevopsApprover || user?.userRolePrivileges?.data?.Provisioner) ? `/devops/${rowData.id}` : '/'}
        className={
          (user?.userRolePrivileges?.data?.DevopsApprover || user?.userRolePrivileges?.data?.Provisioner) ||
            (user?.userRolePrivileges?.data?.StudyApprover && (rowData.approvalStatus.code === allConFigData?.SubmitForApproval || rowData.approvalStatus.code === allConFigData?.SubmitForReApproval || rowData.approvalStatus.code === allConFigData?.Hold)) ? 'enabled' : 'disabled'
        }>{rowData.protocolId}</NavLink>
    )
  }
  const startDateTemplate = (rowData: any) => {
    const startDate = moment(rowData.startDate).format('DD-MM-YYYY');
    return (
      <p>{startDate}</p>
    )
  }

  const endDateTemplate = (rowData: any) => {
    const endDate = moment(rowData.endDate).format('DD-MM-YYYY');
    return (
      <p>{endDate}</p>
    )
  }

  const actionsBodyTemplate = (rowData: any) => {
    // const { WF_STATUS_TYPE_DRAFT, WF_STATUS_TYPE_HOLD,  WF_STATUS_TYPE_SUBMIT_APPROVAL, WF_STATUS_TYPE_REJECTED, WF_STATUS_TYPE_SUBMIT_RE_APPROVAL } = config;
    // const {  WF_STATUS_TYPE_SUBMIT_RE_APPROVAL } = config;
    const { code } = rowData.approvalStatus;

    if (rowData.studyStatus) {
      if (user.role !== 'study approver') {
        if (code === allConFigData?.Approved || code === allConFigData?.Provisioned || code === allConFigData?.Bookmarked) {
          return (<div className='actions d-flex justify-content-center'>
            <CustomizedTooltip title={t("Extend Study")}><CalendarMonthIcon onClick={() => onExtendStudy(rowData)} sx={{ fontSize: 15, opacity: .8 }} /></CustomizedTooltip>
          </div>)
        }
        if (code === allConFigData?.Rejected || code === allConFigData?.SubmitForApproval || code === allConFigData?.SubmitForReApproval || code === allConFigData?.Hold || code === allConFigData?.Draft) {
          return (<React.Fragment>
            <div className='d-flex actions justify-content-center'>
              {user?.userRolePrivileges?.data?.EditStudy && <CustomizedTooltip title={t("Edit Study")}><EditIcon onClick={() => onUpdateStudy(rowData)} sx={{ fontSize: 14, opacity: .8 }} /></CustomizedTooltip>}
              {(user?.userRolePrivileges?.data?.DeleteStudy && user?.userRolePrivileges?.data?.EditStudy) && <span>|</span>}
              {user?.userRolePrivileges?.data?.DeleteStudy && <>  <CustomizedTooltip title={t("Delete Study")}><DeleteIcon onClick={() => { onDeleteStudy(rowData) }} sx={{ fontSize: 14, opacity: .8 }} /></CustomizedTooltip> </>}
            </div>
          </React.Fragment>)
        }
        // if (code === allConFigData?.Hold || code === allConFigData?.Draft) {
        //   return (<React.Fragment>
        //     <div className='actions'>
        //       {user?.userRolePrivileges?.data?.EditStudy && <a onClick={() => onUpdateStudy(rowData)} href='# '>Edit </a>} |
        //       {user?.userRolePrivileges?.data?.DeleteStudy && <a onClick={() => { onDeleteStudy(rowData) }} href='# '>Delete </a>}
        //     </div>
        //   </React.Fragment>)
        // }
      } else {
        return (<div className='d-flex justify-content-center'>-</div>);
      }
    }

    else {
      return (user?.userRolePrivileges?.data?.RestoreStudy && <div className='actions'><a onClick={() =>
        onActivateStudy(rowData)} href='# '>{t("Activate")} </a></div>)

    }
  }

  const onPageClick = (event: any) => {
    setFirst(event.first)
    if ((event.page > 0 || (pageClick && event.page === 0)) && studyPayload.offset !== event.first) {
      const _payload = { ...studyPayload, offset: event.first, userId: user.userId }
      dispatch({ type: Types.STUDY_PAYLOAD, payload: _payload });
      dispatch(findstudiesByUser(_payload))
      setpageChange(true)
    }
  }
  const studyPhaseTemplate = (rowData: any) => {
    return (<p>{rowData.ctPhase.name}</p>)
  }

  const onChangeStudyStatus = (e: any) => {
    setStatusValue(e.target.value === 'true' ? 'true' : 'false')
    setSearchValue('');
    setFirst(0)
    const payload = { ...studyPayload, studyStatus: e.target.value, offset: 0, protocolId: '', approvalStatus: '', studyPhase: '' }
    dispatch({ type: Types.STUDY_PAYLOAD, payload: payload })
    dispatch(findstudiesByUser(payload))
  }

  const downloadFile = (e: any, fileType: any) => {
    const { protocolId, studyPhase, studyStatus, approvalStatus } = studyPayload;
    const _payload = _.cloneDeep(studyDetailsdownload);
    _payload.fileType = fileType
    _payload.searchColumns.userId = user.userId
    _payload.searchColumns.protocolId = protocolId
    _payload.searchColumns.studyPhase = studyPhase
    _payload.searchColumns.studyStatus = studyStatus
    _payload.searchColumns.approvalStatus = approvalStatus
    dispatch(Downloads(_payload))
  }

  const onStudyFilterChange = (e: any) => {
    setSearchValue('');
    setFilter(e.target.value)
    const payload = { ...studyPayload, offset: 0, protocolId: '', studyPhase: '', approvalStatus: '' }
    dispatch({ type: Types.STUDY_PAYLOAD, payload: payload });
    dispatch(findstudiesByUser(payload))
  }
  const onSearchStudty = (e: any) => {
    setSearchValue(e.target.value);
    if (filter === "protocolId") {
      const payload = { ...studyPayload, protocolId: e.target.value, offset: 0, }
      dispatch({ type: Types.STUDY_PAYLOAD, payload: payload });
      dispatch(findstudiesByUser(payload))
    }
    else if (filter === "ctPhase") {
      const payload = { ...studyPayload, studyPhase: e.target.value, offset: 0 }
      dispatch({ type: Types.STUDY_PAYLOAD, payload: payload });
      dispatch(findstudiesByUser(payload))
    }
    else if (filter === "approvalStatus") {
      const payload = { ...studyPayload, approvalStatus: e.target.value, offset: 0 }
      dispatch({ type: Types.STUDY_PAYLOAD, payload: payload });
      dispatch(findstudiesByUser(payload))
    }
  }

  const onClearSearch = () => {
    setSearchValue('');
    const _payload = { ...studyPayload, offset: 0, protocolId: '', studyPhase: '', approvalStatus: '' }
    dispatch({ type: Types.STUDY_PAYLOAD, payload: _payload });
    dispatch(findstudiesByUser(_payload))
  }

  const onCreateStudy = () => {
    dispatch({ type: Types.INITIATE_NEW_STUDAY, payload: Study });
    dispatch({ type: Types.UPDATED_FIELD_VALUES, payload: Study });
    dispatch(backToStudy(false));
    dispatch({ type: Types.DELETED_STUDY_DOCUMENTS, payload: [] });
    dispatch({ type: Types.ON_EXTEND_CLICK, payload: false });
    dispatch({ type: Types.CHANGE_ACTION_TYPE, payload: 'create' });
    sessionStorage.removeItem('extend');
  }

  return (
    <React.Fragment>
      {/* {!studies && <Loader />} */}
      <h2 >{t("All Studies")}</h2>
      <div className='d-flex justify-content-between mb-0'>
        <div className="d-flex align-items-center export-buttons">
          {studies?.totalRecords > 0 && <div className="d-flex align-items-center export-buttons"> {/* <CSVLink {...CSVReport}> <CustomizedTooltip title={t("Download CSV")}><Button type="button" icon="pi pi-file" data-pr-tooltip="CSV" /></CustomizedTooltip></CSVLink> */}
            <CustomizedTooltip title={t("Download CSV")}><Button type="button" icon="pi pi-file" onClick={(e: any) => downloadFile(e, 'Csv')} data-pr-tooltip="CSV" /></CustomizedTooltip>
            <CustomizedTooltip title={t("Download Excel")}><Button type="button" icon="pi pi-file-excel" onClick={(e: any) => downloadFile(e, 'Excel')} className="p-button-success mx-2" data-pr-tooltip="XLS" /></CustomizedTooltip>
            <CustomizedTooltip title={t("Download PDF")}><Button type="button" icon="pi pi-file-pdf" onClick={(e: any) => downloadFile(e, 'PDF')} className="p-button-warning" data-pr-tooltip="PDF" /></CustomizedTooltip>
          </div>}
        </div>
        <div className='d-flex justify-content-end org-filters-section'>
          <div className="search-container align-items-center d-flex">
            <div className=" pe-2 selectBy"  >
              <select className="" onChange={(e) => onStudyFilterChange(e)}>
                <option value="protocolId">{t("Protocol Id")}</option>
                <option value="ctPhase">{t("Study Phase")}</option>
                <option value="approvalStatus">{t("Status")}</option>
              </select>
            </div>
            <div className="ms-2 align-items-center d-flex">
              <input className="form-input" value={searchValue} onChange={(e) => onSearchStudty(e)} placeholder={t("Search by Key")} />
              {searchValue && <span className='clearSearchIcon'><CustomizedTooltip title={t("Clear Search")}><ClearSharpIcon sx={{ fontSize: 15, opacity: .8 }} onClick={() => onClearSearch()} /></CustomizedTooltip></span>}
            </div>
          </div>
          <div className='d-flex justify-content-end'>
            <div className='d-flex  filters'>
              <div>
                {user?.userRolePrivileges?.privilegeGroups?.length <= 1 && user?.userRolePrivileges?.data?.CreateStudy && <NavLink className="" onClick={() => onCreateStudy()} to="../createStudy/0">{"+ " + t("Create Study")}</NavLink>}
              </div>
              {/*below condition for: if delete & restore both privileges true then only show active in active select box */}
              {(user.userRolePrivileges.data.ViewStudy || user.userRolePrivileges.data.RestoreStudy || user.userRolePrivileges.data.DeleteStudy) ?
                <select className='form-select' value={statusValue} onChange={(e) => onChangeStudyStatus(e)} >
                  <option value="true">{t("Active")}</option>
                  <option value="false">{t("InActive")}</option>
                </select> : ''}
            </div>
          </div>
        </div>
      </div>
      <div className="card">

        {studies ? studies.studydetails && <DataTable
          ref={dt}
          lazy
          value={studies?.studydetails}
          paginator={(studies?.totalRecords > studyPayload.limit) ? true : false}
          totalRecords={studies?.totalRecords}
          selectionMode="single"
          rows={studyPayload.limit}
          responsiveLayout="scroll"
          onPage={onPageClick}
          first={studyPayload.offset}
        >
          <Column header={t("Protocol ID")} field="protocolId" body={titleBodyTemplate} ></Column>
          <Column header={t("Sponsor")} field="organization.orgName" ></Column>
          <Column header={t("Study Phase")} field='ctPhase.name' body={studyPhaseTemplate} ></Column>
          <Column header={t("Request By")} field="studyRequestor.name"></Column>
          <Column header={t("Start Date")} field="startDate" body={startDateTemplate} ></Column>
          <Column header={t("End Date")} field="endDate" body={endDateTemplate} ></Column>
          <Column header={t("Status")} field='approvalStatus.name' body={statusBodyTemplate} ></Column>
          {(user?.userRolePrivileges?.data?.EditStudy || user?.userRolePrivileges?.data?.DeleteStudy || user?.userRolePrivileges?.data?.RestoreStudy) &&
            <Column header={t("Actions")} body={actionsBodyTemplate} ></Column>}
        </DataTable> : <Loader />}

      </div>
      <div className='d-flex dashboard-charts'>
        <div className='e-card StudyStatus'>
          <h5 className='border-bottom px-2 py-2'>{t("Study Status")}</h5>
          {studies?.studydetails?.length > 0 ? <StudyStatus /> : <p>There is No Data Available</p>}

        </div>
        <div className='e-card StudyTrend'>
          <h5 className='border-bottom px-2 py-2'>{t("Study Trend by Year")}</h5>

          {studies?.studydetails?.length > 0 ? <StudyTrend /> : <p>There is No Data Available</p>}
        </div>
      </div>
    </React.Fragment>
  )
}

export default Dashboard;