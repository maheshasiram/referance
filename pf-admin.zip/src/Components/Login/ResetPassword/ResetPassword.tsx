import React from 'react';
import * as Yup from 'yup';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import { Formik, Form, Field } from 'formik';
import { useTranslation } from 'react-i18next';


const ResetPassword = () => {
    const { t } = useTranslation();

    const SignupSchema = Yup.object().shape({
        password: Yup.string()
            .required('Please Enter password !')
            .min(2, 'Too Short!')
            .matches(
                /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.{8,})/,
                "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character"
            )
            .max(50, 'Too Long!'),
        conformPassword: Yup.string()
            .required('Please Enter password !')
            .min(2, 'Too Short!')
            .matches(
                /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.{8,})/,
                "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character"
            )
            .max(50, 'Too Long!')
            // .oneOf([Yup.ref('password'), null],)
            .oneOf([Yup.ref('password'), null], 'Passwords must match')
    })

    return (
        <div className='d-flex justify-content-center mt-5'>

            <Card sx={{ width: 500  ,Align:'center'}} elevation={12} >

                <CardContent>
                    <h3  className='text-center'>Reset Password</h3>
                    <Formik
                        initialValues={{
                            password: '',
                            conformPassword:'',
                        }}
                        validationSchema={SignupSchema}
                        onSubmit={() => {
                            // console.log("...values", values)
                        }}
                    >
                        {({ errors, touched, values }) => (
                            < Form >
                                <div className='form-group mt-4 '>
                                    <label > Password: </label>
                                    <Field
                                        className="form-control form-control-lg mt-2"
                                        // type='password'
                                        name="password"
                                        value={values.password}
                                        id='txt-password'
                                        placeholder="Enter The password"
                                    />
                                    {errors.password && touched.password ? (
                                        <div className='text-danger'>{errors.password}</div>
                                    ) : null}
                                </div>
                                <div className='form-group mt-4 '>
                                    <label > Conform Password: </label>
                                    <Field
                                        className="form-control form-control-lg mt-2"
                                        // type='password'
                                        name="conformPassword"
                                        value={values.conformPassword}
                                        id='txt-conformPassword'
                                        placeholder="Enter The Password"
                                    />
                                    {errors.conformPassword && touched.conformPassword ? (
                                        <div className='text-danger'>{errors.conformPassword}</div>
                                    ) : null}
                                </div>
                                <div className='text-end'><button type="submit" className='btn btn-primary mt-4 '>{t("Submit")} </button></div>
                                
                            </Form>
                        )}
                    </Formik>
                </CardContent>
            </Card>
        </div>
    )
}

export default ResetPassword;