import * as Yup from 'yup';
import { Formik, Form, Field } from 'formik';
// import logo from '../../Assets/Images/logo.png';
import React from 'react';
import { useNavigate } from 'react-router-dom';
import '../Styles/Styles.scss'
import { useTranslation } from 'react-i18next';

function SignIn() {
    const { t } = useTranslation();

    const navigate = useNavigate();
    const OnChangeHandler = () => {
        navigate('/forgetpassword')
    }

    const SignInSchema = Yup.object().shape({
        userName: Yup.string()
            .min(2, 'Too Short!')
            .max(50, 'Too Long!')
            .required('Please enter user name'),
        password: Yup.string()
            .required('Please enter password')
            .matches(
                /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.{8,})/,
                "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character"
            ),
    });

    return (
        <React.Fragment>
            <div className='SigninBackGround' >
                <div className='signinCard d-flex ' >
                    <div className="card d-flex" style={{ width: 400, height: 470 }}>
                        <div className="logo">
                        </div>
                        <ul className="list-group list-group-flush">
                        </ul>
                        <div className="card-body">
                            <Formik
                                initialValues={{
                                    userName: '',
                                    password: ''
                                }}
                                validationSchema={SignInSchema}
                                onSubmit={() => {
                                    // console.log("...values", values)
                                }}
                            >
                                {({ errors, touched, values }) => (
                                    <Form>
                                        <div className='username form-group  mb-3'>
                                            <label>User Name: </label>
                                            <Field
                                                className="form-control mt-2"
                                                name="userName"
                                                value={values.userName}
                                                id='txt-crfName'
                                                placeholder="User Name "
                                            />
                                            {errors.userName && touched.userName ? (
                                                <div className='text-danger'>{errors.userName}</div>
                                            ) : null}
                                        </div>
                                        <div className='password form-group mb-4'>
                                            <label> Password:</label>
                                            <Field
                                                className="form-control mt-2"
                                                name="password"
                                                type="password"
                                                value={values.password}
                                                id='txt-crfName'
                                                placeholder="Password"
                                            />
                                            {errors.password && touched.password ? (
                                                <div className='text-danger'>{errors.password}</div>
                                            ) : null}
                                            <div className='forgetPassword' onClick={OnChangeHandler}>
                                                <a href='# '> Forgot Your Pasword ? </a>
                                            </div>
                                        </div>
                                        <div className='SignIn'>
                                            <button type="submit" className=' btn '>{t("Sign In")}</button>
                                        </div>

                                    </Form>
                                )}
                            </Formik>
                        </div>
                        <ul className="list-group list-group-flush">
                        </ul>
                        <div className="card-body_comments d-flex">
                            Create User, Create Study ,
                            Approvals, Create Organaizations and more......
                        </div>
                    </div>

                </div>

            </div>
        </React.Fragment>
    )
}
export default SignIn;