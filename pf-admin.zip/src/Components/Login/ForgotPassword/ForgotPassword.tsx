import React from 'react';
import * as Yup from 'yup';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import { Formik, Form, Field } from 'formik';
import { useTranslation } from 'react-i18next';

const ForgetPassword = () => {
    const { t } = useTranslation();
    const SignupSchema = Yup.object().shape({
        email: Yup.string()
            .required(t("Please Enter Email!"))
            .min(2, t("Too Short"))
            .email(t("Please Enter Your Valid Email Address"))
            .max(50, t("Too Long!")),
    })

    return (
        <div className='d-flex justify-content-center mt-5 ' >

            <Card sx={{ width: 600 ,Align:'center'}} elevation={12} >

                <CardContent>
                    <h3  className='text-center'>Forget Password</h3>
                    <Formik
                        initialValues={{
                            email: '',

                        }}
                        validationSchema={SignupSchema}
                        onSubmit={() => {
                            // console.log("...values", values)
                        }}
                    >
                        {({ errors, touched, values }) => (
                            <Form>
                                <div className='form-group mt-4 '>
                                    <label className='' > Email: </label>
                                    <Field
                                        className="form-control form-control-lg mt-2"
                                        // type='email'
                                        name="email"
                                        value={values.email}
                                        id='txt-email'
                                        placeholder="Enter The Email"
                                    />
                                    {errors.email && touched.email ? (
                                        <div className='text-danger'>{errors.email}</div>
                                    ) : null}
                                </div>
                                <div className='text-end'><button type="submit" className='btn btn-primary mt-4 '>{t("Submit")} </button></div>
                            </Form>
                        )}
                    </Formik>
                </CardContent>
            </Card>
        </div>
    )
}

export default ForgetPassword;