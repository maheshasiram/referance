import React from "react";


const Home = () => {

  return (
    <React.Fragment>
      Welcome to 
    </React.Fragment>
  )

}

export default Home;