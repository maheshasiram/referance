import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import App from './App';
import { Provider } from 'react-redux';
import store from './sagas/main';
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/js/bootstrap.js';
import '../node_modules/primereact/datatable/datatable.min.css';
import '../node_modules/primereact/resources/primereact.min.css';
import "../node_modules/primeicons/primeicons.css";
import '../node_modules/primereact/resources/themes/nova/theme.css';
import '../src/Components/Studies/style.scss';
import './i18n';
const rootElement: any = document.getElementById('root');
const root = createRoot(rootElement);

root.render(
  <React.StrictMode>
    <React.Fragment>
      <Provider store={store}>
        <React.Suspense fallback="Loading...">
          <App />
        </React.Suspense>
      </Provider>
    </React.Fragment>
  </React.StrictMode>
);
