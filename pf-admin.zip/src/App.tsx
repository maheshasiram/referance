import React, { useContext } from 'react';
import './App.scss';
import AlertDialog from './Common/modals/AlertDialog';
import Root from './Routes/Routes';
import { useDispatch, useSelector } from "react-redux";
import { currentUser ,fetchAllConfigData} from './actions/actions';
import Loader from './Common/Loader';
import { AuthContext, AuthProvider, IAuthContext, TAuthConfig } from "react-oauth2-code-pkce"
import '../src/Components/Organization/Styles/Styles.scss'

declare global {
  interface Window {
    env: any
  }
}

const authConfig: TAuthConfig = {
  authorizationEndpoint: window.env.REACT_APP_KEYCLOAK_URL + '/protocol/openid-connect/auth' as string,
  tokenEndpoint: window.env.REACT_APP_KEYCLOAK_URL + '/protocol/openid-connect/token' as string,
  redirectUri: `${window.location.protocol}//${window.location.host}`,
  clientId: window.env.REACT_APP_CLIENT_ID as string,
  logoutEndpoint: window.env.REACT_APP_KEYCLOAK_URL + '/protocol/openid-connect/logout' as string,
  logoutRedirect: `${window.location.protocol}//${window.location.host}`,
  autoLogin: true,
  scope: "openid",
  postLogin: () => {
// did comment to remove warning
  },

  extraAuthParameters: {

  },
  extraTokenParameters: {
    client_secret: ""
  },

}



const UserInfo = (): JSX.Element => {

  const dispatch = useDispatch();
  const { user } = useSelector((state: any) => state.app);
  const { token,  logOut } = useContext<IAuthContext>(AuthContext)
  sessionStorage.setItem('token', token);
  const loaded = React.useRef(false);


  React.useEffect(() => {
    if (!loaded.current) {
      if (token) {
        dispatch(currentUser())
        dispatch(fetchAllConfigData())
        loaded.current = true;
      }
    }
  }, [token,dispatch])

 
  

  const onBackToSign = () => {
   
    logOut()
  }
  return (<React.Fragment>
    {(token && user?.userId && !user.errorMessage) ?
      <Root token={true} authConfig={authConfig} logOut={logOut} /> :
      (token && user && user.errorMessage) ? (
        <div className="container text-center">
          <div className="row">
            <div className="col-md-12">
              <div className="error-template">
                <h3 className='mt-5'>
                  Sorry, you dont have permission for this application.Please approach your administrator
                </h3>
              </div>
              <div>
                <button className='btn btn-primary' onClick={() => onBackToSign()}>Back to signin</button>
              </div>
            </div>
          </div>
        </div>
      ) : ''}
  </React.Fragment>
  )
}


function App() {

  const { isLoader } = useSelector((state: any) => state.app);

  return (
    <div className="App">
        <AuthProvider authConfig={authConfig} >
          {isLoader && <Loader />}
          <UserInfo />
          <AlertDialog />
        </AuthProvider>
    </div>
  );
}

export default App;
