
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Home from '../Components/Home/Home';
import PrivateRoute from './PrivateRoute';
import PublicRoute from './PublicRoute';
import React, { Suspense } from 'react';
import HeaderAppBar from '../Components/Header/HeaderAppBar';
import { useDispatch, useSelector } from 'react-redux';
import { ToastProvider } from 'react-toast-notifications'
import SnackBarToast from '../Common/modals/SnackBarToast';
import NotFound from '../Components/NotFound/NotFound';
import { privateRoutes } from '../Constants/lazyRoutes';
import LazyLoader from '../Common/LazyLoader';
import { getContactDataByTypeCode } from '../Components/Studies/Actions/actions';
// import { publicRoutes } from '../Constants/publicRoute';
// import { publicRoutes } from '../Constants/publicRoute';

function Root(props: any) {
  const dispatch = useDispatch();
  const [isAuthenticated, setIsAuthenticated] = React.useState(false);
  const { user } = useSelector((state: any) => state.app);
  const { authConfig, logOut } = props
  const loaded = React.useRef(false);

  React.useEffect(() => {
    if (!loaded.current) {
      dispatch(getContactDataByTypeCode('CONTACT_TYPE'))
      const tokeninfo = props.token ? true : false;
      setIsAuthenticated(tokeninfo);
      // if(isAuthenticate){
      //   dispatchEvent(currentUser()) 
      // }
      loaded.current = true
    }
  }, [props.token, dispatch]);

  // const publicRouting: any = () => {
  //   const paths: any = []
  //   publicRoutes.map((i: any) => (
  //     (user?.userRolePrivileges?.data?.[i.name] && i?.pathName) ?
  //       paths.push(i.pathName) : paths.push('/')
  //   ))
  //   return paths[0]
  // }

  return (
    <BrowserRouter>
      <div className={`${isAuthenticated ? 'main-container' : ''}`}>
        {isAuthenticated &&
          <HeaderAppBar authConfig={authConfig} logOut={logOut} />
        }
        <div className='main'>
          <div className='Toast-Alert-Container' >
            <ToastProvider>
              <SnackBarToast />
            </ToastProvider>
          </div>
          <Suspense fallback={<LazyLoader />} >
            <Routes>
              <Route
                path="/"
                element={<PublicRoute isAuthenticated={isAuthenticated}
                  // to={publicRouting()}
                  to={"/dashboard"}
                >
                  <Home />
                </PublicRoute>}
              />
              <>
                {
                  privateRoutes && privateRoutes.map((item: any, index: any) => {
                    const userData = user && user.userRolePrivileges && user.userRolePrivileges.data
                    return (userData && item.access in userData && userData[item.access] && <Route key={index} path={item.pathName} element={
                      <PrivateRoute isAuthenticated={isAuthenticated} to="/">
                        <item.Component />
                      </PrivateRoute>
                    } />)
                  })
                }
              </>
              {user.userRolePrivileges && <Route path="*" element={<NotFound />} />}
            </Routes>
          </Suspense>
        </div>
      </div>
    </BrowserRouter>
  )
}

export default Root;