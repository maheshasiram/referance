import React from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import './style.scss';

type Props = {
  title: string,
  children: JSX.Element,
};

function CommonCard({ children }: Props) {
  return (
    <Card className="mt-1 card-div" style={{
      boxShadow: 'none', border: '1px solid #eeeaea',
      padding: 0, paddingBottom: 0
    }}>
      <CardContent className='card-content-div'>
        <Typography component={'div'}>
          {children}
        </Typography>
      </CardContent>
    </Card>
  );
}
export default CommonCard;
