import React from "react";
import CloseIcon from '@mui/icons-material/Close';
import ZoomInIcon from '@mui/icons-material/ZoomIn';

function SearchField(props: any) {
    return (
        <React.Fragment>
            <div className="search-container-common" >
                <input
                    className=""
                    id={props.id}
                    name={props.name}
                    placeholder={props.placeholder}
                    value={props.value}
                    disabled={props.disabled ? true : false}
                    onChange={props.onChange}
                    onMouseEnter={props.onMouseEnter}
                    onMouseLeave={props.onMouseLeave}
                >

                </input>
                {<span onClick={props.onClearSearch} className="del-icon"> <CloseIcon /></span>}
                <span className="search px-1">
                    <ZoomInIcon className="" onClick={props.onSearch} />
                </span>
            </div>
        </React.Fragment>
    )
}
export default SearchField;