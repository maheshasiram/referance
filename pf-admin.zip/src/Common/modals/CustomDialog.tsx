import React from 'react';
import { styled } from '@mui/material/styles';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import '../style.scss'
import { useTranslation } from 'react-i18next';
const BootstrapDialog = styled(Dialog)(({ theme }) => ({
  '& .MuiDialogContent-root': {
    padding: theme.spacing(2),
  },
  '& .MuiDialogActions-root': {
    padding: theme.spacing(2),
  },
  '& .MuiDialog-paperFullWidth': {
    fullWidth: true
  }
}));

const BootstrapDialogTitle = (props: any) => {
  const { children, onClose, ...other } = props;
  return (
    <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
      {children}
      {onClose ? (
        <IconButton
          aria-label="close"
          onClick={onClose}
          sx={{
            position: 'absolute',
            right: 8,
            color: (theme) => theme.palette.grey[500],
          }}
        >
          <CloseIcon />
        </IconButton>
      ) : null}
    </DialogTitle>
  );
};

function CustomDialog(props: any) {

  const onCloseHandler = () => {
    props.onClose();
  }

  const { t } = useTranslation();
  return (
    <React.Fragment>
      <BootstrapDialog
        fullWidth={props.fullWidth === false ? false : true}
        maxWidth={props.maxWidth ? props.maxWidth : 'lg'}
        aria-labelledby="emodal-dialog"
        open={props.open}
        className={`emodal-dialog`}
      >
        <BootstrapDialogTitle className="dialog-header" onClose={onCloseHandler}>
          {props.title}
        </BootstrapDialogTitle>
        <DialogContent className='dialog-content'>
          {props.children}
        </DialogContent>
        {props.hideFooter ? '' : <DialogActions>
          <div className='d-flex justify-content-end'>
            {/* change Cancel button css */}
            {/* <button className={`${props.closeType ? "btn-eprimary me-3" :"btn-esecondary me-3"}`} id="BtnCancel" onClick={() => onCloseHandler()}>{props.closeType ? props.closeType : 'Cancel'}</button> */}
            {props.actionType !== 'Close' ?
              <button className='btn-esecondary me-3' id="BtnCancel" onClick={() => onCloseHandler()}>{t("Cancel")}</button> :
              props.actionType === 'Close' ? <button className='btn-eprimary me-3' id="BtnCancel" onClick={() => onCloseHandler()}>{t("Close")}</button> :
                <button className='btn-eprimary me-3' id="BtnCancel" onClick={() => onCloseHandler()}>{t("OK")}</button>}
            {props.onResetHandler && <button type='reset' form={props.form ? props.form : ''}
              disabled={props.disabled !== undefined ? props.disabled : false}
              className="btn btn-warning me-3"
              onClick={props.onResetHandler}>Reset</button>}
            {(props.onSubmitHandler || props.form) && <button type='submit' form={props.form ? props.form : ''}
              disabled={props.disabled !== undefined ? props.disabled : false}
              className={props.disabled !== undefined ? props.disabled ? "btn-esecondary" : "btn-eprimary" : "btn-eprimary"}
              onClick={props.onSubmitHandler}>
              {props.actionType === 'Submit' ? t("Submit") : props.actionType === 'Update' ? t("Update") : props.actionType}
            </button>}
          </div>
        </DialogActions>}
      </BootstrapDialog>
    </React.Fragment>
  )
}

export default CustomDialog;
