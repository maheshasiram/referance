import * as React from 'react';
import { useTheme } from '@mui/material/styles';
import Box from '@mui/material/Box';
import OutlinedInput from '@mui/material/OutlinedInput';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import Chip from '@mui/material/Chip';
import Checkbox from '@mui/material/Checkbox';

function getStyles(name: any, personName: any, theme: any) {
  return {
    fontWeight:
      personName?.indexOf(name) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
  };
}

export default function SelectField(props: any) {
  const [personName, setPersonName] = React.useState<string[]>([]);
  const [userRole, setUserRole] = React.useState<any[]>([])
  const [options, setOption] = React.useState<any[]>([])
  // let options: any=[];

  React.useEffect(() => {
    const _val = props.value.map((i: any) => {
      return i.label
    })

    setUserRole([...[], _val])
    const _opt = props.options.map((j: any) => {
      return j.label
    })
    // setPersonName(props.value)
    setOption([...[], _opt])

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.options]);

  const theme = useTheme();
  const handleChange = (event: any) => {
    // console.log("event...26",event)
    const { target: { value } } = event;

    setPersonName(
      // On autofill we get a stringified value.
      typeof (value) === 'string' ? value?.split(',') : value,
    );
  };
  props.field.value = personName
  return (
    <div className='common-select '>
      <FormControl sx={{ width: 245, padding: '1px' }}>
        <Select
          labelId="demo-multiple-chip-label"
          id={props.id}
          multiple={props.isMulti}
          value={personName}
          defaultValue={props.defaultValue && props.defaultValue}
          onChange={(e: any) => {
            props.onChange(e)
            handleChange(e)
          }}
          name={props.name}
          disabled={props.isDisabled}
          placeholder={props.placeholder}
          // input={<OutlinedInput id="select-multiple-chip" label="Select role" />}
          input={<OutlinedInput label="Select role" />}
          renderValue={(selected: any) => (
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, }}>
              {selected.map((value: any) => <Chip key={value} label={value} className='mui-chip' />)}
            </Box>
          )}
        >
          {options[0]?.map((item: any, optionIndex:number) => (
            <MenuItem
            key={optionIndex}
              id={item}
              value={item}
              style={getStyles(item, userRole, theme)}
            >
              <Checkbox
                checked={personName.indexOf(item) > -1}
              />
              {item}
            </MenuItem>
          ))}
        </Select>
      </FormControl>

    </div>
  );
}


