export const RoleName = [
    {
        "roleName": "Requestor",
        "id": 12,
        "status": true
    },
    {
        "roleName": "Approver",
        "id": 2,
        "status": false
    },
    {
        "roleName": "Devops Engineer",
        "id": 3,
        "status": false
    },
    {
        "roleName": "Devops Approver",
        "id": 4,
        "status": false
    },
    {
        "roleName": "App Admin",
        "id": 10,
        "status": false
    },
]