import { Types } from "../reducer/Types";
import { fetch} from "../constants/fetch";
import { environment } from "../configs/environment/env";
import Moment from 'moment';

export const searchParam:any=(props:any)=>{
  let searchParam=""
    Object.keys(props).map((key:any)=>{
      if(props[key]!=="" ){
        searchParam=searchParam+key+"="+props[key]+"&" 
      }
      return null
    })
  searchParam=searchParam.substring(0,searchParam.lastIndexOf("&"))
  return searchParam

}
export const fetchTypesOfCenters:any=(props:any)=>{
 
  let filterParams=""
  return((dispatch:any)=>{
    if(props){
      filterParams=searchParam(props)
    }
    dispatch({type:Types.TYPES_OF_CENTERS,payload:null})
    fetch({
      url:(!props)?`${environment.GeneralInshights.typesOfCenters}`:`${environment.GeneralInshights.typesOfCenters}?${filterParams}`,
      method:"GET",
      data:null,
    })
    .then((response:any)=>{
      dispatch({type:Types.TYPES_OF_CENTERS,payload:response.data.result})
     

    }).catch((error:any)=>{
      console.log(error)
     
    })
  })
}

export const fetchRecruitmentCenterDetails:any=(props:any)=>{
  let filterParams=""
  if(props){
    filterParams=searchParam(props)
  }
  return(dispatch:any)=>{
    dispatch({type:Types.RECRUITMENT_CENTER_DETAILS,payload:null})
    fetch({
      url:(!props)?`${environment.Contacts.recruitmentCenterDetails}`:`${environment.Contacts.recruitmentCenterDetails}?${filterParams}`,
      method:"GET",
      data:null,
    })
    .then((response:any)=>{
      let data
      if(response?.data?.result?.length>0){
        data=response.data.result
      }
      else{
        data=[]
        
      }
  
      dispatch({type:Types.RECRUITMENT_CENTER_DETAILS,payload:data})
     
    
    })
    .catch((error:any)=>{
      console.log(error)
     
      
    })
  }
} 
export const fetchStudyInvestigatorDetails:any=(props:any)=>{
  let filterParams=""
  if(props){
    filterParams=searchParam(props)
  }
  return(dispatch:any)=>{
    dispatch({type:Types.STUDY_INVESTIGATOR_DETAILS,payload:null})
    fetch({
      url:(!props)?`${environment.Contacts.studyInvestigatorDetails}`:`${environment.Contacts.studyInvestigatorDetails}?${filterParams}`,
      method:"GET",
      data:null,
    })
    .then((response:any)=>{
      let  data
      if(response.data.result.length>0){
        data=response.data.result
      }
      else{
        data=[]
        
      }
      dispatch({type:Types.STUDY_INVESTIGATOR_DETAILS,payload:data})
     
      
    })
    .catch((error:any)=>{
      console.log(error)
     
      
    })
  }
} 
export const fetchRecritmentCenterConsideredMost:any=(props:any)=>{
  let filterParams=""
  if(props){
    filterParams=searchParam(props)
  }
  return(dispatch:any)=>{
    dispatch({type:Types.RECRUITMENT_CENTER_CONSIDERED_MOST,payload:null})
   
    fetch({
      url:(!props)?`${environment.RecruitmentInfo.centersConsideredMaxTimes}`:`${environment.RecruitmentInfo.centersConsideredMaxTimes}?${filterParams}`,
      method:"GET",
      data:null,
    })
    .then((response:any)=>{
      const sites:any=[];
      const siteName=[response.data.result.sites];
      let responseData=[]

      if(response.data.result.sites!== undefined){
        response.data.result.sites.map((item:any)=>{ 
          if((response.data.result.sites.length>=2 )){
          
            sites.push(item.slice(0,5)+"......")
            }
            else{
              sites.push(item)
            }
          return null
        })
        response.data.result.sites=sites
        responseData.push(response.data.result)
        responseData.push(siteName)
      }
      else{
        responseData=[]
      }
      console.log(responseData,"143...........")

      dispatch({type:Types.RECRUITMENT_CENTER_CONSIDERED_MOST,payload:responseData})
     
     
    })
    .catch((error:any)=>{
      console.log(error)
     
    
    })
  }
}

export const fetchTypesOfStudies:any=(props:any)=>{
  let filterParams=""
  if(props){
    filterParams=searchParam(props)
  }

  return(dispatch:any)=>{
    dispatch({type:Types.TYPES_OF_STUDIES,payload:null})
    fetch({
      url:(!props)?`${environment.GeneralInshights.typeOfStudies}`:`${environment.GeneralInshights.typeOfStudies}?${filterParams}`,
      method:"GET",
      data:null,
    })
    .then((response:any)=>{
      dispatch({type:Types.TYPES_OF_STUDIES,payload:response.data.result})
     
      
    })
    .catch((error:any)=>{
      console.log("98...",error)
    })
  }
}
export const fetchTrailsWrtTrailsStatus:any=(props:any)=>{
  let filterParams=""
  if(props){
    filterParams=searchParam(props)
  }
  return((dispatch:any)=>{
   dispatch({type:Types.TRAILS_WITH_TYPESOF_TRAILSTATUS,payload:null})
    fetch({
      url:(!props)?`${environment.GeneralInshights.trailsWithTypesOfTrailStatus}`:`${environment.GeneralInshights.trailsWithTypesOfTrailStatus}?${filterParams}`,
      method:"GET",
      data:null,
    })
    .then((response:any)=>{
      let   data:any= []
      if(response?.data?.result?.length>0){
        const indexElement= ["TrailType", "Count"]
        data.push(indexElement)
        const responsedata=response.data.result
      responsedata.map((item:any)=>{
        const graphOutput=[]
        graphOutput[0]=item.name
        graphOutput[1]=item.value
        data.push(graphOutput)
        return null
      })
    }
    else{
      data=[]
    }
      dispatch({type:Types.TRAILS_WITH_TYPESOF_TRAILSTATUS,payload:data})
     
   
    })
    .catch((error:any)=>{
      console.log("125..",error)
     
      
    })
  })
}
export const fetchTrailsTypeInRcCenter:any=(props:any)=>{
  let filterParams=""
  if(props){
    Object.keys(props).map((key:any)=>{
      if(props[key]!=="" && key!=='trial_status'){
        filterParams=filterParams+key+"="+props[key]+"&" 
      }
      return null
    })
    filterParams=filterParams.substring(0,filterParams.lastIndexOf("&"))
  }
  return((dispatch:any)=>{
    dispatch({type:Types.TYPE_OF_TRAILS_INRCCENTER,payload:null})
    fetch({
      url:(!props)?`${environment.GeneralInshights.typeOfTrailsInRecruitmentCenter}`:`${environment.GeneralInshights.typeOfTrailsInRecruitmentCenter}?${filterParams}`,
      method:"GET",
      data:null,
    })
    .then((response:any)=>{
      dispatch({type:Types.TYPE_OF_TRAILS_INRCCENTER,payload:response.data.result})
     
    })
    .catch((error:any)=>{
      console.log(error,"152...")
     
    })
  }) 
}
export const fetchTrailsConductedVsStopped:any=(props:any)=>{
  let filterParams=""
  if(props){
    filterParams=searchParam(props)
  }
  return((dispatch:any)=>{
    dispatch({type:Types.TRAILS_CONDUCTED_VS_STOPPED,payload:null})
    fetch({
      url:(!props)?`${environment.GeneralInshights.trailsConductedVsStopped}`:`${environment.GeneralInshights.trailsConductedVsStopped}?${filterParams}`,
      method:"GET",
      data:null,
    })
    .then((response:any)=>{
      const sites:any=[];
      const siteName=[response.data.result.sites];
      let responseData:any=[]
     if(response.data.result.sites!== undefined){
      response.data.result.sites.map((item:any)=>{ 
        if((response.data.result.sites.length>=2 )){
          sites.push(item.slice(0,5)+"......")
          }
          else{
            sites.push(item)
          }
        return null
      })
      response.data.result.sites=sites
      responseData.push(response.data.result)
      responseData.push(siteName)
    }
    else{
      responseData=[response.data.result]
    }
      dispatch({type:Types.TRAILS_CONDUCTED_VS_STOPPED,payload:responseData})
     
    })
    .catch((error:any)=>{
      console.log(error,"264..")
     
    })
  })
}



export const fetchSiteLegacy:any=(props:any)=>{
  let filterParams=""
  if(props){
    filterParams=searchParam(props)
  }
  return((dispatch:any)=>{
    dispatch({type:Types.SITES_ACTIVE_TIMEPERIOD,payload:null})
   
    fetch({
      url:(!props)?`${environment.RecruitmentInfo.siteLegacy}`:`${environment.RecruitmentInfo.siteLegacy}?${filterParams}`,
      method:"GET",
      data:null,
    })
    .then((response:any)=>{
      let dataStructure:any=[]
      if(response.data.result.length!==0){
        const reqDataStruct=response.data.result
      reqDataStruct.map((item:any)=>{
        const data=[]
        data[0]=item.sitename
        data[1]=item.sitename
        data[2]=item.sitename+"Duration"
        data[3]=new Date(Moment(item.startDate).format("YYYY-MM-DD"))
        data[4]=new Date(Moment(item.endDate).format("YYYY-MM-DD"))
        data[5]=null
        data[6]=100
        data[7]=null
        dataStructure.push(data)
        return null 
      })
    }
    else{
      dataStructure=[]
    }
      dispatch({type:Types.SITES_ACTIVE_TIMEPERIOD,payload:dataStructure})
      
      
    })
    .catch((error:any)=>{
      console.log(error,"188..")
     
    })

  })
}
export const fetchCentersCountWithRcStatus:any=(props:any)=>{
  let filterParams=""
  if(props){
    filterParams=searchParam(props)
  }
  return((dispatch:any)=>{
   dispatch({type:Types.CENTERS_BASED_ON_RECRUITMENTSTATUS,payload:null})
    fetch({
      url:(!props)?`${environment.RecruitmentInfo.centersCountWithRcStatus}`:`${environment.RecruitmentInfo.centersCountWithRcStatus}?${filterParams}`,
      method:"GET",
      data:null,
    })
    .then((response:any)=>{
    let responseData:any=[]
      if(response?.data?.message==="Data fetched" ){
        if(response?.data?.result?.length>0){
          
          responseData=[response?.data?.result[0].slice(0,10),response?.data?.result[1].slice(0,10)]
          }
          else{
              responseData=[]
            }
            
          }
          else{
            responseData=[]
          }
      dispatch({type:Types.CENTERS_BASED_ON_RECRUITMENTSTATUS,payload: responseData})
     
    })
    .catch((error:any)=>{
      console.log(error,"206..")
     
    })

  })
}


export const fetchPisPerferdSites:any=(props:any)=>{
  let filterParams=""
  if(props){
    filterParams=searchParam(props)
  }
  return((dispatch:any)=>{
    dispatch({type:Types.SITES_PREFERED_BY_PI,payload:null})
   
    fetch({
      url:(!props)?`${environment.RecruitmentInfo.sitesPreferedByPi}`:`${environment.RecruitmentInfo.sitesPreferedByPi}?${filterParams}`,
      method:"GET",
      data:null,
    })
    .then((response:any)=>{
      let data
      if(response.data.result.length>0){
        data=response.data.result
      }
      else{
        data=[null];
      }
      dispatch({type:Types.SITES_PREFERED_BY_PI,payload:data})
     
    })
    .catch((error:any)=>{
      console.log(error,"226..")
     
    })

  })
}
export const fetchAllSitesCount:any=(props:any)=>{
  let filterParams=""
  if(props){
    filterParams=searchParam(props)
  }
  return((dispatch:any)=>{
    fetch({
      url:(!props)?`${environment.GeneralInshights.allSitesCount}`:`${environment.GeneralInshights.allSitesCount}?${filterParams}`,
      method:"GET",
      data:null,
    })
    .then((response:any)=>{
      dispatch({type:Types.ALL_SITES_COUNT,payload:response.data.result.value})
     
    
     
    })
    .catch((error:any)=>{
     
      console.log(error,"244..")
      
    })

  })
}
export const fetchSitesOfSelectedDuration:any=(props:any)=>{
  let filterParams=""
  if(props){
    filterParams=searchParam(props)
  }
  return((dispatch:any)=>{
    dispatch({type:Types.SITES_OF_SELECTED_YEARS,payload:null})
    fetch({
      url:(!props)?`${environment.GeneralInshights.siteOfSelectedDuration}`:`${environment.GeneralInshights.siteOfSelectedDuration}?${filterParams}`,
      method:"GET",
      data:null,
    })
    .then((response:any)=>{
      let data
      if(response.data.result){
        data=response.data.result
      }
      else{
        data=[];
        
      }
      dispatch({type:Types.SITES_OF_SELECTED_YEARS,payload:data})
      
    })
    .catch((error:any)=>{
     
      console.log(error,"260..")
      
    })

  })
}

export const fetchAllCountriesTrailCount:any=(props:any)=>{
  
  let filterParams=""
  if(props){
    filterParams=searchParam(props)
  }
  return((dispatch:any)=>{
    dispatch({type:Types.ALL_COUNTRIES_TRAIL_COUNT,payload:null})
    fetch({
      url:(!props)?`${environment.GeneralInshights.trailsCountOfAllCountries}`:`${environment.GeneralInshights.trailsCountOfAllCountries}?${filterParams}`,
      method:"GET",
      data:null,
    })
    .then((response:any)=>{
      dispatch({type:Types.ALL_COUNTRIES_TRAIL_COUNT,payload:response.data.result})
    })
    .catch((error:any)=>{
      console.log(error,"485.......")
    })
  })
}
// Filter Values action ---------------
export const fetchCountriesFilterOpt:any=()=>{
  return((dispatch:any)=>{
   
    fetch({
      url:`${environment.Filters.allCountries}`,
      method:"GET",
      data:null,
    })
    .then((response:any)=>{
      const data=response.data.result
      data.sort((a:any, b:any) => a.label.localeCompare(b.label))
      data.shift()
      dispatch({type:Types.COUNTRIES_FILTER_VALUES,payload:data})
    })
    .catch((error:any)=>{
      console.log(error,"277..")
     
    
    })

  })
}
export const fetchSiteFilterOpt:any=(props:any)=>{
  console.log(props,"511")
  let value=props
  return((dispatch:any)=>{
    fetch({
      url:(!props)?`${environment.Filters.siteNames}`:`${environment.Filters.siteNames}?site=${value}`,
      method:"GET",
      data:null,
    })
    .then((response:any)=>{
      const Data=response.data.result
      Data.sort((a:any, b:any) => a.label.localeCompare(b.label))

      dispatch({type:Types.SITEFILTER_VALUES,payload:Data})
     
    
    })
    .catch((error:any)=>{
      console.log(error,"294....")
     
    
    })

  })
}
export const fetchTrailStatusFilterOpt:any=()=>{
  return((dispatch:any)=>{
   
    fetch({
      url:`${environment.Filters.trailStatusValues}`,
      method:"GET",
      data:null,
    })
    .then((response:any)=>{
      const Data=response.data.result
      Data.sort((a:any, b:any) => a.label.localeCompare(b.label))
      
      dispatch({type:Types.TRAILS_STATUS_FILTER_VALUES,payload:Data})
     
      
    })
    .catch((error:any)=>{
      console.log(error,"311....")
     
     
    })

  })
}
export const fetchRecruitmentStatusOpt:any=()=>{
  return((dispatch:any)=>{
   
    fetch({
      url:`${environment.Filters.recruitmentStatusValues}`,
      method:"GET",
      data:null,
    })
    .then((response:any)=>{
      dispatch({type:Types.RECRUIETMENT_STATUS_FILTER_VALUES,payload:response.data.result})
     
     
    })
    .catch((error:any)=>{
      console.log(error,"328..")
     
   
    })

  })
}
export const fetchPiNamesOpt:any=()=>{
  return((dispatch:any)=>{
   
    fetch({
      url:`${environment.Filters.PiNames}`,
      method:"GET",
      data:null,
    })
    .then((response:any)=>{
      const Data=response.data.result
      Data.sort((a:any, b:any) => a.label.localeCompare(b.label))
      dispatch({type:Types.PI_FILTER_VALUES,payload:Data})

     
    })
    .catch((error:any)=>{
      console.log(error,"346....")
     
    })

  })
}
export const fetchCentersWithMaxCount:any=(props:any)=>{
  let filterParams=""
  if(props){
    filterParams=searchParam(props)
  }
  return((dispatch:any)=>{
    dispatch({type:Types.CENTERS_WITH_MAX_CAPACITY,payload:null})
  
    fetch({
      url:(!props)?`${environment.GeneralInshights.centersWithMaxCapacity}`:`${environment.GeneralInshights.centersWithMaxCapacity}?${filterParams}`,
      method:"GET",
      data:null,
    })
    .then((response:any)=>{
      let responseData:any=[]
      console.log("624...",response.data.result)
      if(response.data.result.length!==0){
      responseData=response?.data?.result.slice(0,10)
        console.log("637",responseData)
      }
      else{
        responseData=[]
      }
      dispatch({type:Types.CENTERS_WITH_MAX_CAPACITY,payload:responseData})
    })
    .catch((error:any)=>{
      console.log(error,"627.....")
    })

  })
}
//  tastAlert
export const enableToastAlert:any=(props:any)=>{
  return((dispatch:any)=>{
    dispatch({type:Types.TOAST_ALERT,payload:props})
  })

}
