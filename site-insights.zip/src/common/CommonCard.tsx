import React  from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import './CommonCard.scss';

type Props = {
  children: JSX.Element,
  Height: string,
  title:string,
};

function CommonCard({ children, Height,title}: Props) {
  return (
    <Card className="card-div" style={{
      boxShadow: 'none',
   paddingBottom: 0, height:`${Height}`
    }}>
      <div className='cardTitle'>
       <span> {title} </span>
        </div>
      <CardContent className='card-content-div p-0'>
        <Typography className='content' component={'div'}>
          {children}
        </Typography>
      </CardContent>
    </Card>
  );
}

export default CommonCard;