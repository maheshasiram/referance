import React from 'react';
export const confirmMsg = (msg : string, name : string)=>(
    <span className='d-flex'>{msg}<span className='highlightedText'>{name}</span> ? </span> 
  )

  export const toastMsg = (msg : string, name : string)=>(
    <span className='d-flex'> <span className='highlightedText'>{name}</span> {msg} </span> 
  )