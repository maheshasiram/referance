import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { useToasts } from 'react-toast-notifications';
import { Types } from "../../reducer/Types";
function SnackBarToast() {
  const dispatch = useDispatch();
  const { toastAlert } = useSelector((state: any) => state.application);
  const { addToast } = useToasts();
  
    React.useEffect(() => {
      if(toastAlert.open){
        addToast(toastAlert.message , { appearance: toastAlert.status === 1 ? 'success' : 'error',  autoDismiss: true, autoDismissTimeout:10000 });
        dispatch({
          type: Types.TOAST_ALERT, payload: {
            status: null, message: "", open: false
          }
        });
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [toastAlert])
  
    return (
      <div className="snackBar-Toast">
  
      </div>
    )
  }
  export default SnackBarToast