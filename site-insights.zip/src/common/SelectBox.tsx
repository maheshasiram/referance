
 import React from 'react';

import Select from 'react-select';
import "./SelectBox.scss"
export default function ReactSelect (props:any) {
  const {onChange,options,value,placeHolder,title}=props
  
  return (
    <div className='inshightsSelectBox'> 
    <Select
        className="SelectBoxMainDiv"
        classNamePrefix="select"
        placeholder={placeHolder}
        defaultValue={"selectValue"}
        isClearable={props.isClearable}
        value={value}
        onChange={(selected:any)=>{onChange(selected)}}
        name="color"
        options={options}
        aria-label={title}
      />
    </div>
  );
}