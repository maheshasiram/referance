import * as React from 'react';
export default function AppHeader() {
    return (
        <React.Fragment>
            <div className="header-ribbon">
                <div className="iqa-logo">
                    <div className="logo">
                        <img src="https://inductiveclinicalai.com/wp-content/uploads/2023/05/IQA-Logo-Website-Latest.svg" alt="inductivelogo" />
                    </div>
                    <div className="clip-paht"></div>
                </div>
            </div>
        </React.Fragment>
    )

}