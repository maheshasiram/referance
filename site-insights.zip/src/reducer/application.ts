import { Types } from "./Types";

const initialState={
    isLoader:false,
    recruitmentCenterDetails:null,
    studyInvestigatorDetails:null,
    CenterConsideredMost:null,
    typesOfCenter:null,
    typesOfStudies:null,
    trailsWrtTrailstatus:null,
    typeOfTrails:null,
    CondunctedAndStoppedCount:null,
    siteDuration:null,
    centersCount:null,
    pisDetails:null,
    totalSitesCount:null,
    sitesOfSelectedYears:null,
    allCountriesOpt:null,
    piNamesOpt:null,
    recruitmentStatusOpt:null,
    sitesOpt:null,
    trailStatusOpt:null,
    filterValues:{therapeutic_area:"",trial_status:"",country:"",site:"",from_year:"",to_year:"",recruitment_status_of_site:"",pi_name:""},
    clearFilter:false,
    CentersCapacityVal:null,
    toastAlert:{status: null, message: "", open: false},
    allCountriesTrailCount:null,
    filter_Actions:false
}

export const application =(state=initialState,action:{type:any,payload:any})=>{
    switch(action.type){
        case Types.IS_LOADER:
            return{...state, isLoader:action.payload}
        case Types.RECRUITMENT_CENTER_DETAILS:
            return{...state,recruitmentCenterDetails:action.payload}
        case Types.STUDY_INVESTIGATOR_DETAILS:
            return{...state,studyInvestigatorDetails:action.payload}
        case Types.RECRUITMENT_CENTER_CONSIDERED_MOST:
            return {...state,CenterConsideredMost:action.payload}
        case Types.TYPES_OF_CENTERS:
            return{...state,typesOfCenter:action.payload}
        case Types.TYPES_OF_STUDIES:
            return{...state,typesOfStudies:action.payload}
        case Types.TRAILS_WITH_TYPESOF_TRAILSTATUS:
            return{...state,trailsWrtTrailstatus:action.payload}
        case Types.TYPE_OF_TRAILS_INRCCENTER:
            return{...state,typeOfTrails:action.payload}
        case Types.TRAILS_CONDUCTED_VS_STOPPED:
            return{...state,CondunctedAndStoppedCount:action.payload}
        case Types.SITES_ACTIVE_TIMEPERIOD:
            return{...state,siteDuration:action.payload}
        case Types.CENTERS_BASED_ON_RECRUITMENTSTATUS:
            return{...state,centersCount:action.payload}
        case Types.SITES_PREFERED_BY_PI:
            return{...state,pisDetails:action.payload}
        case Types.ALL_SITES_COUNT:
            return{...state,totalSitesCount:action.payload}
        case Types.SITES_OF_SELECTED_YEARS:
            return{...state,sitesOfSelectedYears:action.payload}
        case Types.PI_FILTER_VALUES:
            return{...state,piNamesOpt:action.payload}
        case Types.COUNTRIES_FILTER_VALUES:
            return{...state,allCountriesOpt:action.payload}
        case Types.RECRUIETMENT_STATUS_FILTER_VALUES:
            return{...state,recruitmentStatusOpt:action.payload}
        case Types.SITEFILTER_VALUES:
            return{...state,sitesOpt:action.payload}
        case Types.TRAILS_STATUS_FILTER_VALUES:
            return {...state,trailStatusOpt:action.payload}
        case Types.FILTER_VALUES:
            return{...state,filterValues:action.payload}
        case Types.CLEAR_FILTER:
            return{...state,clearFilter:action.payload}
        case Types.CENTERS_WITH_MAX_CAPACITY:
            return {...state,CentersCapacityVal:action.payload}
        case Types.TOAST_ALERT:
            return{...state,toastAlert:action.payload}
        case Types.FILTER_ACTIONS:
            return{...state,filter_Actions:action.payload}
        case Types.ALL_COUNTRIES_TRAIL_COUNT:
            return{...state,allCountriesTrailCount:action.payload}
        default:
            return {...state}
            

    }
}