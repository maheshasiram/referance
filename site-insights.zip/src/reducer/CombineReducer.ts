import { combineReducers } from "redux";
import { application } from "./application";
const reducer=combineReducers({
    application
})
export type RootState = ReturnType<typeof reducer>;
export default reducer