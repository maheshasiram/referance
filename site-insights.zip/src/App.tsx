import React from 'react';
import './App.scss';
import StudyCenter from './components/typeofstudycenters/Typesofstudycenter';
import Typesoftrailscount from './components/trailscountinrecruitmentcenters/TrailsCountInRecruitmentCenters';
import Recruitmentcenteres from './components/recruitmentcentersusedmax/RecruitmentCentersUsedMax';
import CentersCountByRecruitmentStatus from './components/centerscountbyrecruitmentstatus/CentersCountByRecruitmentStatus';
import TrailsConductedVsStopped from './components/trailsconductedvsstopped/TrailsConductedVsStopped';
import TrailsCountOnStudyStatus from './components/trailscountonstudystatus/TrailsCountOnStudyStatus';
import RecruitmentSitesPreferedByPi from './components/recruitmentsitespreferedbypi/RecruitmentSitesPreferedByPi';

import DurationOfSitesInvolved from './components/durationofsiteinvolvedinstudy/DuartionOfSiteInvolvedInStudy';

import Studytypes from './components/typesofstudies/TypesOfStuidies';
import Geogrphicmap from './components/mapwithcenterpoints/map';
import StudyInvestigatorDetails from './components/studyinvestigatordetails/StudyInvestigatorDetails'
import RecruitmentcenterDetails from './components/recruitmentcenterdetails/Recruitmentcenterdetails';
import SitesCount from './components/sitescount/SitesCount';
import InshightsFilters from './components/filters/Filters';

import SitesDetailsOfRecentPeriods from './components/trailsinyears/IndexFile';
import AppHeader from './common/header/ApplicationHeader';
import SnackBarToast from './common/messages/ToastMessage';
import { ToastProvider } from 'react-toast-notifications';
import CountriesTrailCount from './components/CountryWiseTrailCount/CountryWiseTrailCount';
import CentersWithMaxCount from './components/centerswithmaxcount/CentersWithMaxCount';

function App() {
  return (
    <div className="App container-fluid">
      <div className='row'>
        <div className='col-12 p-0 header-ribbon'>
          <div className='col-6'>
          <AppHeader/>
           </div>
           <div className='col-6 SitesCount'> 
           <SitesCount/>
           </div>
        </div>
        <div className='toastProvider'>
        <ToastProvider>
          <SnackBarToast/>
        </ToastProvider>

        </div>
        <InshightsFilters/>
          <StudyCenter/>
           <Studytypes />
        <TrailsCountOnStudyStatus />
         <Recruitmentcenteres/>
        <TrailsConductedVsStopped/>
           <DurationOfSitesInvolved/>
           <Typesoftrailscount/> 
       <CentersCountByRecruitmentStatus/>
        <CountriesTrailCount/>
        <CentersWithMaxCount/>
        <StudyInvestigatorDetails/>
        <RecruitmentcenterDetails/>
        <SitesDetailsOfRecentPeriods/>
        <RecruitmentSitesPreferedByPi/>
          
        <Geogrphicmap/>
       </div>
    </div>
  );
}

export default App;
