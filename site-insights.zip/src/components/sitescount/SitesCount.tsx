import  React,{useEffect} from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import { useDispatch, useSelector } from 'react-redux';
import { fetchAllSitesCount } from '../../actions/action';

export default function SitesCount() {
const {totalSitesCount}=useSelector((state:any)=>state.application)
const dispatch=useDispatch()
useEffect(()=>{
dispatch(fetchAllSitesCount())
// eslint-disable-next-line react-hooks/exhaustive-deps
},[])
    const count=totalSitesCount
  return (
    <Card sx={{ minWidth: 275 }}>
      <CardContent>
        <Typography sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
          Sites Involved In Trials :  { count }
        </Typography>
      </CardContent>
    </Card>
  );
}