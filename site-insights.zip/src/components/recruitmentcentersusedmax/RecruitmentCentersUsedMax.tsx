import React,{useEffect} from 'react';
import ReactEcharts from "echarts-for-react"
import CommonCard from '../../common/CommonCard';
import { useDispatch, useSelector } from 'react-redux';
import { fetchRecritmentCenterConsideredMost } from '../../actions/action';
import Loader from '../../common/loader/GraphLoader';

const Recruitmentcenteres=()=>{
    const {CenterConsideredMost}=useSelector((state:any)=>state.application)
    const dispatch=useDispatch()
    useEffect(() => {
        dispatch(fetchRecritmentCenterConsideredMost())
     
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []) 
 const option = {
    color: ['#3398DB'],
    tooltip: {
        trigger: 'axis',
        axisPointer: {           
            type: 'shadow'    
        },
        textStyle: {
            fontSize: 14,
            color:"red",
            
          },
        formatter:function(params:any){
            const siteName=(CenterConsideredMost)?CenterConsideredMost[1]:""
            const index =params[0].dataIndex
            return`
            <div style="width:250px">
            <p  style="white-space: pre-line">
            ${siteName[0][index]}</br>
            ${params[0].seriesName} : ${params[0].data}
            </p>
            </div></br>`
        }
    },
    grid: {
        left: '5%',
        right: '5%',
        bottom: '10%',
        containLabel: true
    },
    xAxis: [
        {
            type: 'category',
            data:(CenterConsideredMost)?CenterConsideredMost[0]?.sites:"",
            axisTick: {
                alignWithLabel: true
            }
        }
    ],
    yAxis: [
        {
            type: 'value'
        }
    ],
    series: [
        {
            name: 'Trial Count',
            type: 'bar',
            barWidth: '25%',
            data: (CenterConsideredMost)?CenterConsideredMost[0]?.count:""
        }
    ]
};
return (
    <div className='col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12 mb-4  TrailsCountContainer'>
        <CommonCard Height={"480px"} title={"Top Recruitment Centers"}>
            {
                CenterConsideredMost?(CenterConsideredMost?.length!==0)?<ReactEcharts option={option}/>:<div><p className='text-center' style={{lineHeight:"400px"}}> No Recruitment Centers to Display </p></div>:<Loader/>
            }
       
        </CommonCard>
    </div>

)

}
export default Recruitmentcenteres
