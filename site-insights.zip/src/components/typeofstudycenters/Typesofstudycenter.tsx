import React,{useEffect} from 'react'
import ReactEcharts from "echarts-for-react"
import CommonCard from '../../common/CommonCard';
import { useDispatch, useSelector } from 'react-redux';
import { fetchTypesOfCenters } from '../../actions/action';
import Loader from '../../common/loader/GraphLoader';

const StudyCenter=()=>{
    const {typesOfCenter}=useSelector((state:any)=>state.application)
    const dispatch=useDispatch()
    useEffect(() => {
        dispatch(fetchTypesOfCenters())
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    const option = {
        title: {
        
            textStyle: {
                fontSize:"14px",
                align:"left",
            }
            
        },
        height:"250px",
        tooltip: {
            trigger: 'item',
            formatter: '{b} <br/> {c} :({d}%)'
        },
        hoverOffset: 60,
        series: [
            {
                name: 'StudyCenter',
                type: 'pie',
                radius: '75%',
                center: ['50%', '50%'],
                data: [typesOfCenter?.[0],typesOfCenter?.[1]].sort(function (a, b) { return a.value - b.value; }),
                roseType: 'radius',
                
                label: {
                    color: 'black',
                    formatter:'{b}: \n {c}',
                    position:"outside"
                },
                itemStyle: {
                     color: '#c23531',
                    shadowBlur: 200,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                },
    
                animationType: 'scale',
                animationEasing: 'elasticOut',
                animationDelay: function () {
                    return Math.random() * 200;
                },
                
            }
        ]
    };
    return (
        <>
        <div className='col-xl-4 col-lg-6 col-md-6 col-sm-6 col-xs-12 mb-4' > 
        <CommonCard Height={"380px"} title={"Percentage Of Study Centers"}>
            <React.Fragment>
            {/* {
                (typesOfCenter && typesOfCenter?.length)? <ReactEcharts option={option}></ReactEcharts>:<div><p className='text-center' style={{lineHeight:"300px"}}>No Study Center to Display</p></div>
            }
            {
                !typesOfCenter && <Loader/>
            } */}


            {
                typesOfCenter ? (typesOfCenter.length>0 ? <ReactEcharts option={option}></ReactEcharts>: <div><p className='text-center' style={{lineHeight:"400px"}}>No Study Center to Display</p></div>): <Loader/>

            }
            </React.Fragment>
            
         
         </CommonCard>
        </div>
    </>
    )

}
export default  StudyCenter
