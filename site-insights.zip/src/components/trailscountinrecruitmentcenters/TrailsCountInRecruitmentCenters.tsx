import React,{useEffect} from 'react';
import ReactEcharts from 'echarts-for-react-typescript';
import CommonCard from '../../common/CommonCard';
import { useDispatch, useSelector } from 'react-redux';
import { fetchTrailsTypeInRcCenter } from '../../actions/action';
import Loader from '../../common/loader/GraphLoader';
const Typesoftrailscount=()=>{
    const {typeOfTrails}=useSelector((state:any)=>state.application)
    const dispatch=useDispatch()
    useEffect(()=>{
        dispatch(fetchTrailsTypeInRcCenter())
        // eslint-disable-next-line react-hooks/exhaustive-deps
    },[])
    const option = {
        
    
        tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b}: {c} ({d}%)'
        },

        legend: {
            orient: 'horizontal',
            top:250,
            data:typeOfTrails?.map((item:any)=>{
                return item.name
            }),
            padding:10
        },
        series: [
            {
                name: 'Types of Trial',
                type: 'pie',
                radius: ['30%', '50%'],
                avoidLabelOverlap: true,
                label: {
                    show: true,
                    position: 'center'
                },
                emphasis: {
                    label: {
                        show: true,
                        fontSize: '10',
                        fontWeight: 'bold'
                    }
                },
                labelLine: {
                    show: true
                },
                data: 
                    typeOfTrails,
                   
                
            }
        ]
    };
    return(
        <>
        <div  className='col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12 mb-4'>
        <CommonCard Height={"380px"} title={"Different Types of Trial Conducted "}>
            {
                typeOfTrails? (typeOfTrails.length!==0)?<ReactEcharts option={option} className='EchartsMainContainer' />:<div> <p className='text-center' style={{lineHeight:"400px"}}> No Trials Types to Display</p></div>:<Loader/>
            }
        </CommonCard>
        </div>
        </>
    ) 

}
export default Typesoftrailscount