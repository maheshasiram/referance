import React,{useEffect} from 'react'
import { Chart } from "react-google-charts";
import CommonCard from '../../common/CommonCard';
import { useDispatch, useSelector } from 'react-redux';
import { fetchTrailsWrtTrailsStatus } from '../../actions/action';
import Loader from '../../common/loader/GraphLoader';

export default function TrailsCountOnStudyStatus() {
  const {trailsWrtTrailstatus}=useSelector((state:any)=>state.application)
  const dispatch=useDispatch()
  useEffect(()=>{
dispatch(fetchTrailsWrtTrailsStatus())
// eslint-disable-next-line react-hooks/exhaustive-deps
  },[])
    const data = trailsWrtTrailstatus?.map((item:any)=>{
      return item
    })
    const options = {
   
      pieHole: 0.4,
      is3D: false,
      };
    return (
      <>
      <div className='col-xl-4 col-lg-6 col-md-6 col-sm-6 col-xs-12 mb-4'>
      <CommonCard Height={"380px"} title={"Percentage Of Trial Status"}>
        {
          trailsWrtTrailstatus?(trailsWrtTrailstatus?.length!==0)?<Chart chartType="PieChart" width="100%" height="330px" data={data} options={options}/>:<div><p className='text-center' style={{lineHeight:"400px"}}>No Trial Status to Display</p></div>:<Loader/>

        }

    </CommonCard>
    </div>
    </>
    );
}
