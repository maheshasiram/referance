import React,{useEffect} from "react";
import CommonCard from "../../common/CommonCard";
import { useDispatch, useSelector } from "react-redux";
import { fetchTypesOfStudies } from "../../actions/action";
import ReactEcharts from "echarts-for-react-typescript";
import Loader from "../../common/loader/GraphLoader";

const Studytypes=()=> {
  const {typesOfStudies}=useSelector((state:any)=>state.application)
  const dispatch=useDispatch()
useEffect(()=>{
  dispatch(fetchTypesOfStudies())
// eslint-disable-next-line react-hooks/exhaustive-deps
},[])
const option = {
  tooltip: {
      trigger: 'item',
      formatter: '{a} <br/>{b} : {c} ({d}%)'
  },
  legend: {
      orient: 'horizontal',
      left: 'left',
      top:"bottom",
      data:typesOfStudies?.map((item:any)=>{
        return item.name
      })
  },
  series: [
      {
          name: 'Types Of Studies',
          type: 'pie',
          radius: '55%',
          center: ['50%', '50%'],
          data: typesOfStudies,
          emphasis: {
              itemStyle: {
                  shadowBlur: 10,
                  shadowOffsetX: 0,
                  shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
          }
      }
  ]
};
        return (
          <>
          <div className='col-xl-4 col-lg-6 col-md-6 col-sm-6 col-xs-12 mb-4'>
            <CommonCard Height={"380px"} title={"Percentage Of Studies"}>
              {
                typesOfStudies?(typesOfStudies?.length!==0)?<ReactEcharts option={option} className="EchartsMainContainer"/>:<div> <p className="text-center" style={{lineHeight:"400px"}}> No Studies to Display </p></div>:<Loader/>
              }
             
          </CommonCard>
          </div>
          </>
        );
    };
export default Studytypes
