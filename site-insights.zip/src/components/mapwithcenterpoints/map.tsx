import React from 'react';
import 'leaflet/dist/leaflet.css'
import { MapContainer,TileLayer } from 'react-leaflet'
import L from 'leaflet'
import MarkerClusterGroup from "react-leaflet-cluster";
import Coordinates from './geojsondetails/cordinates.json';
import CoordinatesArray from './geojsondetails/CoordinatesAbove5k.json'
import CommonCard from '../../common/CommonCard';
import MarkerIcon from './MarkersComponent';
function Geogrphicmap(){
  L.Icon.Default.mergeOptions({
    iconRetinaUrl: require('leaflet/dist/images/marker-icon-2x.png'),
    iconUrl: require('leaflet/dist/images/marker-icon.png'),
    shadowUrl: require('leaflet/dist/images/marker-shadow.png')
  });
  const CoordinatesSet:any=[]
  CoordinatesSet.push(Coordinates?.features)
  CoordinatesSet.push(CoordinatesArray?.features)
  return (
    <div className="col-12 mb-4">
      <CommonCard Height={"600px"} title={"World Wide Sites Details Invloved In Trials "}>
        <MapContainer
          center={[19.55652538396795, 73.03178221031817]}
          zoom={3}
          className={'MapConainer'}
        
          scrollWheelZoom={true}>
          <TileLayer
            attribution='&copy; <a href="https://api.maptiler.com/maps/basic-v2/256/tiles.json?key=qUS13xk4bNEGmhkmNT1i">OpenStreetMap</a> contributors'
            url="https://api.maptiler.com/maps/basic-v2/256/{z}/{x}/{y}.png?key=qUS13xk4bNEGmhkmNT1i"
          />
          <MarkerClusterGroup >
            {
              CoordinatesSet?.map((Coords:any)=>{
                return(

                  Coords?.map((center:any,index:any)=>(
                    <MarkerIcon coordinates={center} key={index}/>
  
                  ))
                )

              })
            }
          </MarkerClusterGroup>
        </MapContainer>
      </CommonCard>
    </div>
  );
}


export default Geogrphicmap;
