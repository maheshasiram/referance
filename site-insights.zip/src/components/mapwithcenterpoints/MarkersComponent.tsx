import React from 'react';
import { Marker, Popup } from 'react-leaflet'
import L from 'leaflet'
const MarkerIcon=(props:any)=>{
    const {properties,geometry}=props.coordinates
    const PopupStyles: any = {

        Catatory: {
          fontWeight: "bold",
          textTransform: "capitalize",
          padding: "0px 10px",
        },
        Heading: {
          fontSize: "20px",
          fontWeight: "bold",
          textAlign: "center"
        }
    
      }
      L.Icon.Default.mergeOptions({
        iconRetinaUrl: require('leaflet/dist/images/marker-icon-2x.png'),
        iconUrl: require('leaflet/dist/images/marker-icon.png'),
        shadowUrl: require('leaflet/dist/images/marker-shadow.png')
      });
    return(
        <>
                <Marker

position={[geometry.coordinates[0],geometry.coordinates[1]]}
eventHandlers={{
  mouseover: (event) => event.target.openPopup(),
}}
>

<Popup>
  <p className='fw-bold text-center '> Recuritment Center Details </p>
  <p className='fw-bold ' style={PopupStyles.Catatory} ><span >Country   :</span><span className='mx-4'>{properties?.country?properties.country : "N/A"}</span></p>
  <p className='fw-bold ' style={PopupStyles.Catatory}><span>State   :</span><span className='mx-4'>{properties?.state?properties.state : "N/A"}</span></p>
  <p className='fw-bold ' style={PopupStyles.Catatory}><span>City   :</span><span className='mx-4'>{properties?.city?properties.city : "N/A"}</span> </p>
  <p className='fw-bold ' style={PopupStyles.Catatory}><span>ZipCode   :</span><span className='mx-4'>{properties?.zip?properties.zip : "N/A"}</span></p>
  <p className='fw-bold ' style={PopupStyles.Catatory}><span>Center Name   :</span><span className='mx-4'>{properties?.name?properties.name : "N/A"}</span></p>
  <p className='fw-bold ' style={PopupStyles.Catatory}><span>Responsible Person   :</span><span className='mx-4'>{(properties?.name_of_responsible_person)?properties.name_of_responsible_person : "N/A"}</span></p>
  <br />

</Popup>

</Marker>
        </>
    )

}
export default MarkerIcon