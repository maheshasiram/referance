
import React, { useEffect } from "react";
import { Chart } from "react-google-charts";
import CommonCard from "../../common/CommonCard";
import { useDispatch, useSelector } from "react-redux";
import { fetchSiteLegacy } from "../../actions/action";
import './SiteLegacyStyles.scss'
import Loader from "../../common/loader/GraphLoader";
const DurationOfSitesInvolved=()=>{
  const dispatch=useDispatch()
  const {siteDuration}=useSelector((state:any)=>state.application)
  useEffect(()=>{
    dispatch(fetchSiteLegacy())

    // eslint-disable-next-line react-hooks/exhaustive-deps
  },[])
const columns = [
  { type: "string", label: "Task ID" },
  { type: "string", label: "Task Name" },
  { type: "string", label: "Resource" },
  { type: "date", label: "Start Date" },
  { type: "date", label: "End Date" },
  { type: "number", label: "Duration" },
 { type: "number", label: "Percent Complete" },
  { type: "string", label: "Dependencies" },
];

const rows = siteDuration?.map((item:any)=>{
  return item
})

const data =(siteDuration?.length>0)? [columns, ...rows]:["nodata available "];

const options = {
  backgroundColor: '#0f375f',
// title:"Duration of sites Involved in Trails ",
  height: 280,
  gantt: {
    trackHeight: 50,
  },
  hAxis: {
    title: "Total Population",
    minValue: 0,
  },
};

  return (
    <>
    <div className='col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 mb-4 mb-4'>
      <CommonCard Height={"380px"} title={"Site Duration"}>
       
        {
          siteDuration?(siteDuration?.length!==0)?<div> <Chart chartType="Gantt" width="auto" height="300" data={data} options={options} className="siteLegacyContainer"/><p style={{marginTop:"10px"}} className="text-center text-danger ">Note : The above chart shows overall duration of sites involved in clinical trials.</p></div>:<div> <p className='text-center' style={{lineHeight:"400px"}}> No Duration of Sites to Display </p></div>:<Loader/>
          
        }
      </CommonCard>
      </div>
      
      </>
  );
  }
export default DurationOfSitesInvolved
