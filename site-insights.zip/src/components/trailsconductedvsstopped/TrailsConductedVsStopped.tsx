import React,{useEffect} from 'react'
import ReactECharts from 'echarts-for-react';
import * as echarts from 'echarts';
import CommonCard from '../../common/CommonCard';
import { useDispatch, useSelector } from 'react-redux';
import { fetchTrailsConductedVsStopped } from '../../actions/action';
import Loader from '../../common/loader/GraphLoader';


export default function TrailsConductedVsStopped() {
    const {CondunctedAndStoppedCount}=useSelector((state:any)=>state.application)
    const dispatch=useDispatch()
    useEffect(()=>{
        dispatch(fetchTrailsConductedVsStopped())

        // eslint-disable-next-line react-hooks/exhaustive-deps
    },[])

  const  option = {
    backgroundColor: '#0f375f',
        tooltip: {
            trigger: 'axis',
            axisPointer: {
                type: 'shadow',
                index:0.4   
            },
            textStyle: {
                fontSize: 14,
                color:"red",
                rich:{
                    "<style_name>":{
                    }
                  
                }
               
              },
            formatter:function(params:any){
                const siteName=CondunctedAndStoppedCount[1]
                const index =params[0].dataIndex
                return`
                <div style="width:250px">
                <p  style="white-space: pre-line">
                ${siteName[0][index].split("(")[0]}</br>
                ${params[0].seriesName} : ${params[0].data}</br>
                ${params[1].seriesName} : ${params[1].data}
                </p>
                </div></br>`
            }
        },
       
        xAxis: {
            data:(CondunctedAndStoppedCount)?CondunctedAndStoppedCount[0].sites:"",
            
            type:"category",
        },
        yAxis: {
            splitLine: {show: false},
            type:"value",
        },
        series: [
            {
            name: 'Conducted',
            type: 'line',
            smooth: true,
            showAllSymbol: true,
            symbol: 'emptyCircle',
            symbolSize: 15,
            data:(CondunctedAndStoppedCount)?CondunctedAndStoppedCount[0].conducted_count:""
         },
         {
            name: 'Stopped',
            type: 'bar',
            barWidth: 10,
            barGap:100,
            itemStyle: {
                barBorderRadius: 5,
                color: new echarts.graphic.LinearGradient(
                    0, 0, 0, 1,
                    [
                        {offset: 0, color: '#14c8d4'},
                        {offset: 1, color: '#43eec6'}
                    ]
                )
            },
            data:(CondunctedAndStoppedCount)?CondunctedAndStoppedCount[0].stopped_count:""
        },
         {
            name: 'Conducted',
            type: 'bar',
            barGap: '-100%',
            barWidth: 10,
            itemStyle: {
                color: new  echarts.graphic.LinearGradient(
                    0, 0, 0, 1,
                    [
                        {offset: 0, color: 'rgba(20,200,212,0.5)'},
                        {offset: 0.2, color: 'rgba(20,200,212,0.2)'},
                        {offset: 1, color: 'rgba(20,200,212,0)'}
                    ]
                )
            },
            z: -12,
            data:(CondunctedAndStoppedCount)?CondunctedAndStoppedCount[0].conducted_count:""
        },
         {
            name: 'Conducted',
            type: 'pictorialBar',
            symbol: 'rect',
            itemStyle: {
                color: '#0f375f'
            },
            symbolRepeat: true,
            symbolSize: [12, 4],
            symbolMargin: 1,
            z: -10,
            data:(CondunctedAndStoppedCount)?CondunctedAndStoppedCount[0].conducted_count:""
        }
    ]
    };
    
    
    return(
        <>
        <div className="col-xl-6 col-lg-12 col-md-12 col-sm-12 col-xs-12 mb-4">
            {/* <div className={(CondunctedAndStoppedCount?.conducted_count?.length>=0)?" d-block":"  d-none"}> */}
            <CommonCard Height={"480px"} title={"Trials Conducted v/s Stopped"} >
                 {
                CondunctedAndStoppedCount? (CondunctedAndStoppedCount[0].sites)? <ReactECharts option={option}/>:<div><p className='text-center' style={{lineHeight:"400px"}}> No Data to Display</p></div>:<Loader/>
              }
               
            </CommonCard>
        </div>
        </>
        ) 
}
