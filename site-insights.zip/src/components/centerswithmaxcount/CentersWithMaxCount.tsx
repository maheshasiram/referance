import React,{useEffect} from 'react'
import ReactECharts from 'echarts-for-react';
import CommonCard from '../../common/CommonCard';
import { useDispatch, useSelector } from 'react-redux';
import { fetchCentersWithMaxCount } from '../../actions/action';
import Loader from '../../common/loader/GraphLoader';
export default function CentersWithMaxCount() {
    const {CentersCapacityVal}=useSelector((state:any)=>state.application)
    const dispatch=useDispatch()
    useEffect(()=>{
        dispatch(fetchCentersWithMaxCount())
        
        // eslint-disable-next-line react-hooks/exhaustive-deps
    },[])
   const option = {

    tooltip: {
        trigger: 'axis',
        axisPointer: {           
            type: 'shadow'    
        },
        textStyle: {
            fontSize: 14,
            color:"black",
            
          },
        
        formatter:function(params:any){
            const siteName=CentersCapacityVal?.map((item:any)=>{
                let SiteNames=`<ol style="width:200px">`
                item?.sites?.map((Name:any)=>{
                    SiteNames+=`<li style="white-space: pre-line">${Name}</li>`
                    return null
                })
                SiteNames+="</ol>"
                return SiteNames

            })
            const index =params[0].dataIndex
            return`
            <div style="width:250px">
            <p>
            Sites Invloved In Trails On</br> Sample Count Of : <span style='text-align:canter'> ${params[0].data}</span></br> ${siteName[index]}
            </p>
            </div></br>`
        }
    },
        xAxis: {
            type: 'category',
            data: CentersCapacityVal?.map((item:any)=>{
                return item.sites[0]
            }),
            axisLabel:{
                formatter:function(value:any){
                    const siteName=CentersCapacityVal?.map((item:any)=>{
                        return item.sites[0]
                    })
                    if(siteName.length>3){
                        return value.slice(0,6)+"...."

                        
                    }
                    else{
                        return value;
                    }
                   
                }
               
            }

        },
        yAxis: {
            type: 'value'
        },
        series: [{
            data:  CentersCapacityVal?.map((item:any)=>{
                return item.size
            }),
            type: 'bar',
             label: {
                    show: true,
                    position: 'inside'
                },
            showBackground: true,
            backgroundStyle: {
                color: 'rgba(220, 220, 220, 0.8)'
            },
            barWidth:(CentersCapacityVal?.length>3)?"60%":"20%"
        }]
    };
    return (
        <>
           <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 mb-4 CentersWithMaxCount">
          <CommonCard Height={"400px"} title={"CentersWithMaxCount"} >
          {
                (CentersCapacityVal)?(CentersCapacityVal?.length!==0 )? <ReactECharts option={option}/>:<div><p className='text-center' style={{lineHeight:"400px"}}> No Centers to Display</p></div>:<Loader/>
              }
        </CommonCard>
        </div>
        </>
    )
    
    
}
