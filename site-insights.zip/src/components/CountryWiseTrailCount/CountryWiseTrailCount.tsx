import React, { useEffect } from 'react'
import ReactEcharts from "echarts-for-react-typescript";
import CommonCard from '../../common/CommonCard';
import { useDispatch, useSelector } from 'react-redux';
import { fetchAllCountriesTrailCount } from '../../actions/action';
import Loader from '../../common/loader/GraphLoader';
const CountriesTrailCount=()=>{
    const dispatch=useDispatch()
    const {allCountriesTrailCount}=useSelector((state:any)=>state.application)
    useEffect(()=>{
        dispatch(fetchAllCountriesTrailCount())

    // eslint-disable-next-line react-hooks/exhaustive-deps
    },[])
    const option = {
        color: ['#3398DB'],
        tooltip: {
            trigger: 'axis',
         
        },
        grid: {
            left: '3%',
            right: '5%',
            bottom: '3%',
            containLabel: true,
            top:30,
        
           
        },
        xAxis: [
            {
                type: 'value',
                axisLabel: {
                
            show: true,
          }, axisTick: {
            show: true,
            interval: 0
          },
            }
        ],
        yAxis: [
            {
                type: 'category',
                data:allCountriesTrailCount?.map((item:any)=>{
                    return item.name
      
                  }),
                  axisLabel: {
                    show: true,
                    interval: 0,
                    rotate:45
                  }, axisTick: {
                    show: true,
                   
                  },
                  inverse:true
            }
        ],
        visualMap: {
            orient: 'horizontal',
            left: 'center',
            min: 0,
            max: allCountriesTrailCount?.length,
            dimension: 0,
            inRange: {
                color: ['#dbcb9a', '#a78ee8']
            },
            show:false
        },
        series: [
            {
                name: 'Trails Count',
                type: 'bar',
                barWidth: '20%',
                data: allCountriesTrailCount?.map((item:any)=>{
                    return item.value
      
                  }),
               
               
            }
        ]
    };
return (
    <>
     <div className='col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 mb-4 CountriesStatsContainer' >
            <CommonCard Height={"430px"} title={"Countries Trial Stats "}>
              {
            (allCountriesTrailCount)?(allCountriesTrailCount?.length!==0) ? <ReactEcharts option={option}  className={(allCountriesTrailCount?.length>10)?"CountriesTrailContainer":"CountriesTrailContainer2"}/>:<div> <p className="text-center" style={{lineHeight:"380px"}}> No Countries Data To Display </p></div>:<Loader/>
           
        }
            
        </CommonCard>
     </div> 
    </>
)
}
export default CountriesTrailCount