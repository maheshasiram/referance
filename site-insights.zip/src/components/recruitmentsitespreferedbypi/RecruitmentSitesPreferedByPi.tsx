import React, { useEffect } from 'react'
import PiDetailsCard from './commoncardofpis/CardOfPiDetails';
import { useDispatch, useSelector } from 'react-redux';
import { fetchPisPerferdSites } from '../../actions/action';
import CommonCard from '../../common/CommonCard';
import Loader from '../../common/loader/GraphLoader';
export default function RecruitmentSitesPreferedByPi() {
    const {pisDetails}=useSelector((state:any)=>state.application)
    const dispatch=useDispatch()
    useEffect(()=>{
        dispatch(fetchPisPerferdSites())
        // eslint-disable-next-line react-hooks/exhaustive-deps
    },[])
    return(
        <>
          <div className='col-12 mb-4'>
        <CommonCard Height='auto'title='Top Principal Investigators'>
            {
                 pisDetails?
          <div style={{"display":"flex","justifyContent":"center","marginTop":"5px"}}>
          
       
        {
            pisDetails?.map((item:any,index:number)=>{
                return(
                    <>  
                    {
                        
                        (pisDetails[0]!==null)?<PiDetailsCard PiName={item.pi_name} Sites={item.sites} Count={item.count} key={index}/>:<div> <p className='text-center' style={{lineHeight:"350px"}}>No PI Details to Display</p></div>
                    }
            
                    </>
                )
            })

        }
        </div>:<Loader/>
}
        </CommonCard>
        </div>
        </>
    )

}
