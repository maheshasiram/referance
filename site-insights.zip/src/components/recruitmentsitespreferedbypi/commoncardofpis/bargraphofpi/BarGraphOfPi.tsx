import React from 'react';
import ReactECharts from 'echarts-for-react';
const BarGraphOfPi=(props:any)=>{
    const {sites ,count,}=props
    const option = {
        
        color: ['#3398DB'],
        tooltip: {
            trigger: 'axis',
            axisPointer: {            
                type: 'shadow',  
            },

            textStyle: {
                fontSize: 14,
                 color:"blue",
              },

              formatter:function(params:any){
                const siteName=sites
                const index =params[0].dataIndex
                return`
                <div style="width:250px">
                <p style="white-space: pre-line">
                ${siteName[index]}</br>
                ${params[0].seriesName}: ${params[0].data}</br>
                </p>
                </div></br>`
            },
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        xAxis: [
            {
                type: 'category',
                data: sites,
                axisTick: {
                    alignWithLabel: true
                },
                axisLabel:{
                    formatter:function(value:any){
                            return value.slice(0,10)+"...."

                    }
                   
                }
            }
        ],
        yAxis: [
            {
                type: 'value'
            }
        ],
        series: [
            {
                name: 'Trials Conducted',
                type: 'bar',
                barWidth: '20%',
                data: count
            }
        ]
    };
    return (
        <>
        <ReactECharts option={option}/>
        </>
    )
    

}
export default BarGraphOfPi