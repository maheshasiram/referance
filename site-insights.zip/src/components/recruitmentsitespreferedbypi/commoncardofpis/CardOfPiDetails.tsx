import React from 'react'
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Pilogo from '../../../assets/PiLogo.jpg'
import './PiCardStyles.scss';
import PiDialogBox from './dialogbox/PiDialogBox';
const PiDetailsCard = (props: any) => {
    const {PiName,Sites,Count}=props
    const [open, setOpen] = React.useState(false);

    const handleClickOpen = () => {
        setOpen(true);
    };
    return (
        <>
            <div className='Picard_Header'>
            <Card>
                <CardMedia
                    sx={{ height: 150 }}
                    image={Pilogo}
                    
                />
                <CardContent>
                    <Typography gutterBottom variant="h5" component="div">
                     {PiName}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                        <ul>
                        {
                            Sites.map((item:any,index:any)=>{
                                if(index<3){
                                return(
                                    <>
                                    <li key={index}> {item} : {Count[index]}</li>
                                    </>
                                )
                                }
                                return null
                            })

                        }
                        </ul>
                    </Typography>
                </CardContent>
                <CardActions>
                <Button size="small"  onClick={handleClickOpen}>View Graph</Button>
                </CardActions>
                </Card>
                {
                    (open)?<PiDialogBox open={open} setOpen={setOpen} sites={Sites} count={Count} Pi={PiName}/>:null
                    
                }
            </div>
        </>
    )

}
export default PiDetailsCard