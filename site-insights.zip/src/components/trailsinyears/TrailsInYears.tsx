import React,{} from 'react'
import ReactEcharts from "echarts-for-react"

const  TrailsInYears=(props:any)=> {
    const {sites,year}=props
const option = {
    title: {
        text: `Site And Trial Count of ${year} `,
        textStyle: {
            fontSize: "12px",
            align: 'center',
        },

    },
    legend: {
        type: 'scroll',
        orient: 'horizontal',
        left:"center",
        top: "bottom",
        data:sites.map((item:any)=>{
            return item.name
        })
    },
    tooltip: {
        trigger: 'item',
        formatter: '{a} <br/>{b}: {c} ({d}%)'
    },
    series: [
        {
            name: year,
            type: 'pie',
            radius: '45%',
            center: ['50%', '40%'],
            data:sites.map((item:any)=>{
                return item
            }),
            emphasis: {
                itemStyle: {
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            }
        }
    ]
};
return (
    <>
    <ReactEcharts option={option}/> 
    </>
)
}
export default TrailsInYears
