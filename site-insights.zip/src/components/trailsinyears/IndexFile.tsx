import React,{useEffect} from 'react';
import CommonCard from '../../common/CommonCard';
import { useDispatch, useSelector } from 'react-redux';
import { fetchSitesOfSelectedDuration } from '../../actions/action';
import './Styles.scss'
import Loader from '../../common/loader/GraphLoader';
import TrailsCountPerYear from './TrailsCountsPerYear';
const SitesDetailsOfRecentPeriods=()=>{
    const {sitesOfSelectedYears}=useSelector((state:any)=>state.application)
    const dispatch=useDispatch()
    useEffect(()=>{
        dispatch(fetchSitesOfSelectedDuration())
        // eslint-disable-next-line react-hooks/exhaustive-deps
    },[])
    return(
        <> 
        <div className='col-12 mb-4 GridContainer '>
        <CommonCard Height="380px" title={"Recent Years Top Site Details"}>
            {
                sitesOfSelectedYears?(sitesOfSelectedYears?.length>0)?<TrailsCountPerYear data={sitesOfSelectedYears}/>:<div> <p className='text-center' style={{lineHeight:"350px"}}>No Sites Are Available  to Display</p></div>:<Loader/>

            }
        </CommonCard>
        </div>
        </>
    )

}
export default SitesDetailsOfRecentPeriods