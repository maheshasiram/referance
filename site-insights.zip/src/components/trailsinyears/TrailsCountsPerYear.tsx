import React from 'react';
import './Styles.scss'
import TrailsInYears from './TrailsInYears';
const TrailsCountPerYear = (props:any)=>{
 const {data}=props
return(
    <>
      <div className='mainContainer'>
        {
          data.map((item:any,index:any)=>{
          return(
              <div key={index} className={ (data.length>1)?"YearlyStats":"YearStat"}>
              {
                <TrailsInYears year={item.year} sites={item.sites}/>
              }
            </div>
            
          )
          })
        }
        </div>
    </>
);
}
export default TrailsCountPerYear ;