import React,{useState,useEffect,useRef} from 'react'
import DatePicker, { DateObject } from "react-multi-date-picker"
import CloseIcon from '@mui/icons-material/Close';
import CalendarMonthOutlinedIcon from '@mui/icons-material/CalendarMonthOutlined';
import { useDispatch, useSelector } from 'react-redux';
import { Types } from '../../reducer/Types';
import { Button } from 'primereact/button';
import "./Year.scss";
const YearsFilter=()=>{
  const fromYear=new DateObject()
  const toYear=new DateObject()
  const [values, setValues] = useState([fromYear,toYear])
    const dispatch=useDispatch()
    const {filterValues,clearFilter,filter_Actions}=useSelector((state:any)=>state.application)
    const calender:any= useRef()
    const  [submitButton,SetSubmitButton]=useState(false)
 
    useEffect(()=>{
      setValues([])
     let _payload={...filterValues,from_year:""}
     _payload={...filterValues,to_year:""}
     dispatch({type:Types.FILTER_VALUES,payload:_payload})
    // eslint-disable-next-line react-hooks/exhaustive-deps
    },[clearFilter])

    const onClearValue = () => {
      setValues([])
      filterValues.from_year=""
      filterValues.to_year=""
      let _payload={...filterValues,from_year:""}
      _payload={...filterValues,to_year:""}
      dispatch({type:Types.FILTER_VALUES,payload:_payload})
      let filterparam=null
        filter_Actions?filterparam=false:filterparam=true
        dispatch({type:Types.FILTER_ACTIONS,payload:filterparam})
      
    };
   
    const YearChangeHandler=(date:any)=>{
      let filterparam=null
      if(date?.length >0){
        setValues(date)
        if(date[0]?.year){
          const _payload={...filterValues,from_year:date[0]?.year}
          dispatch({type:Types.FILTER_VALUES,payload:_payload})
        }
        if(date[1]?.year){
          const _payload={...filterValues,to_year:date[1]?.year}
          dispatch({type:Types.FILTER_VALUES,payload:_payload})
          
        }
      }
        filter_Actions?filterparam=false:filterparam=true
      dispatch({type:Types.FILTER_ACTIONS,payload:filterparam})
    }
  
    


    return(
      <div className='Year_filter'>
       <DatePicker 
       onlyYearPicker
    
       onOpenPickNewDate={false}
       highlightToday={false}
       range
       dateSeparator=" to " 
       placeholder='YYYY to YYYY'
      ref={calender}
      onChange={(date:any)=>YearChangeHandler(date)}
      value={values}
      onOpen={()=>{SetSubmitButton(true)}}
      onClose={()=>{SetSubmitButton(false)}}
   
    /> 
    <div   style={{position:"absolute"}}><CalendarMonthOutlinedIcon onClick={() =>calender.current.openCalendar() } /></div>
    <div  style={{position:"absolute" ,display:(values?.length>0)?"":"none"}}><CloseIcon className="close_btn " onClick={onClearValue}/></div>
    <div className="card flex justify-content-center SubmitButton" style={{display:(submitButton)?"block":"none"}} >
            <Button label="Ok" onClick={()=>  calender?.current?.closeCalendar()}  className='btn btn-primary'/>
        </div>
    </div>
  );
    

 }


export default YearsFilter