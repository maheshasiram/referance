import React,{useState,useEffect} from 'react'
import ReactSelect from '../../common/SelectBox'
import { useDispatch, useSelector } from 'react-redux';
import { Types } from '../../reducer/Types';
import { fetchRecruitmentStatusOpt } from '../../actions/action';
const RecruitmentStatusFilter=()=>{
    const  [recruitmentStatusValue,setRecruitmentStatusValue]=useState([])
    const {filterValues,clearFilter,recruitmentStatusOpt,filter_Actions}=useSelector((state:any)=>state.application)
    const dispatch=useDispatch()
    useEffect(()=>{
        dispatch(fetchRecruitmentStatusOpt())
        
    // eslint-disable-next-line react-hooks/exhaustive-deps
    },[])
    useEffect(()=>{
        if(clearFilter){
            setRecruitmentStatusValue([])
          
        }
    },[clearFilter])
    const recruitmentStatusChageHandler=(value:any)=>{
        let filterparam=null
        if(value){
            setRecruitmentStatusValue(value)
            const _payload={...filterValues,recruitment_status_of_site:value.value}
           dispatch({type:Types.FILTER_VALUES,payload:_payload})
          
        }
        else{
            setRecruitmentStatusValue([])
            const _payload={...filterValues,recruitment_status_of_site:""}
            dispatch({type:Types.FILTER_VALUES,payload:_payload})
           
        }
        filter_Actions?filterparam=false:filterparam=true
        dispatch({type:Types.FILTER_ACTIONS,payload:filterparam})
    }
    return(
        <>
          <ReactSelect 
            onChange={recruitmentStatusChageHandler}
             options={recruitmentStatusOpt} 
             value={(!clearFilter)?recruitmentStatusValue:[]}
             isClearable={true} 
             placeHolder="Recruitment status"
              />
        </>
    )
}
export default RecruitmentStatusFilter