import React,{useState,useEffect} from 'react'
import ReactSelect from '../../common/SelectBox'
import { useDispatch, useSelector } from 'react-redux';
import { Types } from '../../reducer/Types';
import { fetchPiNamesOpt } from '../../actions/action';
const PiNameFilter=()=>{
    const [piFilterValue,setPiFilterValue]=useState([])
    const dispatch=useDispatch()
    const {piNamesOpt,filterValues,clearFilter,filter_Actions}=useSelector((state:any)=>state.application)
    useEffect(()=>{
        dispatch(fetchPiNamesOpt())
           // eslint-disable-next-line react-hooks/exhaustive-deps
    },[])
    useEffect(()=>{
        if(clearFilter){
            setPiFilterValue([])
        }
    },[clearFilter])
    const PiNameChangeHandeler=(value:any)=>{
        let filterparam=null
        if(value){
            setPiFilterValue(value)
            const _payload={...filterValues,pi_name:value.value}
            dispatch({type:Types.FILTER_VALUES,payload:_payload})
           
        }
        else{
            setPiFilterValue([])
            const _payload={...filterValues,pi_name:""}
            dispatch({type:Types.FILTER_VALUES,payload:_payload})
        }
        filter_Actions?filterparam=false:filterparam=true
        dispatch({type:Types.FILTER_ACTIONS,payload:filterparam})
    }
    return(
        
        <ReactSelect 
        onChange={PiNameChangeHandeler}
         options={piNamesOpt}
         isClearable={true} 
         value={(!clearFilter)?piFilterValue:[]}
         placeHolder="Pi-Name"
          />

    )
}
export default PiNameFilter
