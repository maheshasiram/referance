import React,{useState,useEffect,} from 'react'
import ReactSelect from '../../common/SelectBox'
import { useDispatch, useSelector } from 'react-redux';
import { Types } from '../../reducer/Types';
import { fetchCountriesFilterOpt } from '../../actions/action';
const CountryFilter=()=>{
    const {filterValues,clearFilter,allCountriesOpt,filter_Actions}=useSelector((state:any)=>state.application)
    const [countryFilterValue,setCountryFilterValue]=useState([])
    const dispatch=useDispatch()
   
    useEffect(()=>{
        dispatch(fetchCountriesFilterOpt())
          // eslint-disable-next-line react-hooks/exhaustive-deps
    },[])
    useEffect(()=>{
        if(clearFilter){
            setCountryFilterValue([])
          
        }
    },[clearFilter])
    
    const countryChangeHandler=(value:any)=>{
        let filterparam=null
        if(value){
            setCountryFilterValue(value)
            const _payload={...filterValues,country:value.value}
           dispatch({type:Types.FILTER_VALUES,payload:_payload})
        }
        else{
            setCountryFilterValue([])
            const _payload={...filterValues,country:""}
            dispatch({type:Types.FILTER_VALUES,payload:_payload})
        }
        filter_Actions?filterparam=false:filterparam=true
        dispatch({type:Types.FILTER_ACTIONS,payload:filterparam})

    }
    return(
        <>
           <ReactSelect 
            onChange={countryChangeHandler}
             options={allCountriesOpt} 
             isClearable={true} 
             value={(!clearFilter)?countryFilterValue:[]}
             placeHolder="Country"
              />
        </>
    )
}
export default CountryFilter