import  React,{useState,useEffect} from 'react';
// import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import { useDispatch, useSelector } from 'react-redux';
import { Types } from '../../reducer/Types';
import CloseIcon from '@mui/icons-material/Close';
import SearchIcon from '@mui/icons-material/Search';
import "./Year.scss";
const TherapaticAreaFilter1=()=>{
    const  [valuetherapatic,setvaluetherapatic]=useState("")

    const {filterValues,clearFilter,filter_Actions}=useSelector((state:any)=>state.application)
    const dispatch=useDispatch()
    const ALPHA_NUMERIC_DASH_REGEX = /^[A-Z@~`!@#$%^&*()_=+\\\\';:"\\/?>.<,-]*$/i;
    useEffect(()=>{
            setvaluetherapatic("")
            const _payload={...filterValues,therapeutic_area:""}
            dispatch({type:Types.FILTER_VALUES,payload:_payload})
             // eslint-disable-next-line react-hooks/exhaustive-deps
    },[clearFilter])

    const onClearValue = () => {
        setvaluetherapatic("")
        filterValues.therapeutic_area=""
        const _payload={...filterValues,therapeutic_area:""}
        dispatch({type:Types.FILTER_VALUES,payload:_payload})
        let filterparam=null
        filter_Actions?filterparam=false:filterparam=true
        dispatch({type:Types.FILTER_ACTIONS,payload:filterparam})
        
        
      };

    const therapaticAreaChangeHandler=(e:any)=>{
        let filterparam=null
        if(e.target.value){
            setvaluetherapatic(e.target.value)
            const _payload={...filterValues,therapeutic_area:e.target.value}
            dispatch({type:Types.FILTER_VALUES,payload:_payload})
        }
        else{
            setvaluetherapatic("")
            const _payload={...filterValues,therapeutic_area:""}
            dispatch({type:Types.FILTER_VALUES,payload:_payload})
        }
        filter_Actions?filterparam=false:filterparam=true
        dispatch({type:Types.FILTER_ACTIONS,payload:filterparam})
    }
return (
    <div className="TherapaticAreaFilterContainer">
<TextField
         onChange={therapaticAreaChangeHandler}
          id="outlined-size-small"
        placeholder='Search'
          size="small"
          value={valuetherapatic}
          onKeyDown={(event) => {
            if (!ALPHA_NUMERIC_DASH_REGEX.test(event.key)) {
              event.preventDefault();
            }
          }}
        />
           <div><SearchIcon style={{display:(filterValues.therapeutic_area==="")?"":"none"}}  className="search_Btn "/></div>   
           <div><CloseIcon  style={{display:(filterValues.therapeutic_area==="")?"none":""}} className="close_Btn " onClick={onClearValue}/></div>   
    </div>
);
}
export default TherapaticAreaFilter1