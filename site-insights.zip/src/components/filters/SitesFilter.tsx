import React,{useState,useEffect,useRef} from 'react'
// import ReactSelect from '../../common/SelectBox'
import TextField from '@mui/material/TextField';
import Stack from '@mui/material/Stack';
import Autocomplete from '@mui/material/Autocomplete';
import { useDispatch, useSelector } from 'react-redux';
import { Types } from '../../reducer/Types';
import { fetchSiteFilterOpt } from '../../actions/action';
const SitesFilter=()=>{
    const {filterValues,clearFilter,sitesOpt,filter_Actions}=useSelector((state:any)=>state.application)
    const dispatch=useDispatch()
    const sitefilterval:any= useRef()
    const  [siteFilterVal,setSiteFilterVal]=useState(null)
    useEffect(()=>{
        dispatch(fetchSiteFilterOpt())
           // eslint-disable-next-line react-hooks/exhaustive-deps    
    },[])
    useEffect(()=>{
        if(clearFilter){
            setSiteFilterVal(null)
            // sitefilterval.current.value=""

            console.log(sitefilterval.current,"20---")
            dispatch({type:Types.CLEAR_FILTER,payload:false})
           
          
        }
      
          // eslint-disable-next-line react-hooks/exhaustive-deps
    },[clearFilter])
    const siteFilterOptHandler=(value:any)=>{
        console.log(value.target.outerText,"26----")
        let filterparam=null
        if(value.target.outerText){
            setSiteFilterVal(value.target.outerText)
            const _payload={...filterValues,site:value.target.outerText}
            dispatch({type:Types.FILTER_VALUES,payload:_payload})   
        }
        else{
            // setSiteFilterVal([])
            const _payload={...filterValues,site:""}
            dispatch({type:Types.FILTER_VALUES,payload:_payload})
        }
        filter_Actions?filterparam=false:filterparam=true
        dispatch({type:Types.FILTER_ACTIONS,payload:filterparam})
    }
    const inputValue=(e:any)=>{
        console.log(e,"38.....")

    }

    const InputChangeHandler=(e:any)=>{
        let inputvalue=e.target.value
        console.log(inputvalue,"new---44")
        dispatch(fetchSiteFilterOpt(e.target.value))
        
    }
    return(
        <>
        
<Stack  sx={{ width: 170 }}>
       <Autocomplete
        onChange={siteFilterOptHandler}
        onInput={(e:any)=>{InputChangeHandler(e)}}
        // options={sitesOpt.sort((a:any, b:any) => a.label.localeCompare(b.label))} 
        options={sitesOpt} 
        renderInput={(params) => <TextField {...params}  
        placeholder="Site Name"  />}
        // value={siteFilterVal}
        value={siteFilterVal}
        className='siteFilterMainContainer'
       
       />
        </Stack>

        </>
    )
}
export default SitesFilter