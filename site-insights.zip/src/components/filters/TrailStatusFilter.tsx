import React,{useState,useEffect} from 'react'
import ReactSelect from '../../common/SelectBox'
import { useDispatch, useSelector } from 'react-redux';
import { Types } from '../../reducer/Types';
import { fetchTrailStatusFilterOpt } from '../../actions/action';
const TrailStatusFilter=()=>{
    const  [trailStatusVal,setTrailStatusVal]=useState([])
    const {filterValues,clearFilter,trailStatusOpt,filter_Actions}=useSelector((state:any)=>state.application)
    const dispatch=useDispatch()
    useEffect(()=>{
        dispatch(fetchTrailStatusFilterOpt())  
            // eslint-disable-next-line react-hooks/exhaustive-deps
    },[])
    useEffect(()=>{
        if(clearFilter){
            setTrailStatusVal([])

          
        }
    },[clearFilter])
    const TrailChangeHandler=(value:any)=>{
        let filterparam=null
        if(value){
            setTrailStatusVal(value)
            const _payload={...filterValues,trial_status:value.value}
            dispatch({type:Types.FILTER_VALUES,payload:_payload})
        }
        else{
            setTrailStatusVal([])
            const _payload={...filterValues,trial_status:""}
            dispatch({type:Types.FILTER_VALUES,payload:_payload})
          
        }
        filter_Actions?filterparam=false:filterparam=true
        dispatch({type:Types.FILTER_ACTIONS,payload:filterparam})
    }
    return (
        <>
         <ReactSelect 
            onChange={TrailChangeHandler}
             options={trailStatusOpt} 
             isClearable={true} 
             value={(!clearFilter)?trailStatusVal:[]}
             placeHolder="Trial-Status"
              />
        </>
    )
}
export default TrailStatusFilter