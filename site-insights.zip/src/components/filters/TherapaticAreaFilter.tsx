import React,{useState,useEffect} from 'react'
import TextField from '@mui/material/TextField';
import Stack from '@mui/material/Stack';
import Autocomplete from '@mui/material/Autocomplete';
import ReactSelect from '../../common/SelectBox'
import { therapaticAreaOpt} from './StaticOptionObjects';
import { useDispatch, useSelector } from 'react-redux';
import { Types } from '../../reducer/Types';
import CloseIcon from '@mui/icons-material/Close';
import "./Year.scss";
import { fetchSiteFilterOpt } from '../../actions/action';
const TherapaticAreaFilter=()=>{
    // const  [valuetherapatic,setvaluetherapatic]=useState([])
    const  [siteFilterVal,setSiteFilterVal]=useState([])
    const {filterValues,clearFilter,filter_Actions,sitesOpt}=useSelector((state:any)=>state.application)
    const dispatch=useDispatch()
    console.log(filterValues.site,"17--")
    useEffect(()=>{
        dispatch(fetchSiteFilterOpt())
         
             // eslint-disable-next-line react-hooks/exhaustive-deps
    },[])

    useEffect(()=>{
      
            // setvaluetherapatic([])
            setSiteFilterVal([])
            // const _payload={...filterValues,site:""}
            // dispatch({type:Types.FILTER_VALUES,payload:_payload})
        
        // eslint-disable-next-line react-hooks/exhaustive-deps
    },[clearFilter])

    const siteFilterOptHandler=(e:any)=>{
        console.log(e.target.outerText,"26--")
        let filterparam=null
        if(e.target.outerText){
            setSiteFilterVal(e.target.outerText)
            const _payload={...filterValues,site:e.target.outerText}
            dispatch({type:Types.FILTER_VALUES,payload:_payload})   
        }
        else{
            setSiteFilterVal([])
            const _payload={...filterValues,site:""}
            dispatch({type:Types.FILTER_VALUES,payload:_payload})
        }
        filter_Actions?filterparam=false:filterparam=true
        dispatch({type:Types.FILTER_ACTIONS,payload:filterparam})
    }
 
    const InputChangeHandler=(e:any)=>{
        let inputvalue=e.target.value
        console.log(inputvalue,"new---44")
        dispatch(fetchSiteFilterOpt(e.target.value))
        
    }
   
    
return (
<div>
{/* <ReactSelect 
            onChange={therapaticAreaChangeHandler}
             options={therapaticAreaOpt.sort((a:any, b:any) => a.label.localeCompare(b.label))} 
             isClearable={true} 
             placeHolder="Therapeutic-Area"
             value={(!clearFilter)?valuetherapatic:[]}
             title="Therapeutic-Area"
              /> */}

 

       <Stack  sx={{ width: 170 }}>
       <Autocomplete
        onChange={siteFilterOptHandler}
        onInput={(e:any)=>{InputChangeHandler(e)}}
        // options={sitesOpt.sort((a:any, b:any) => a.label.localeCompare(b.label))} 
        options={sitesOpt} 
        renderInput={(params) => <TextField {...params}  placeholder="Site Name"  />}
       
       />
          {/* <div><CloseIcon  style={{display:(filterValues.site==="")?"none":""}}  className="close_Btn "  onClick={onClearValue}/></div>  */}
        </Stack>

</div>
);
}
export default TherapaticAreaFilter