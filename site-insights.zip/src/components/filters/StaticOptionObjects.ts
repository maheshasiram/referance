let startYear=1973
let flag=false
export const  Yearopt:any=[]
while (!flag){
    const opt:any={value:0,label:""}
    opt.value=startYear
    opt.label=startYear.toString()
    startYear+=1
    if(startYear===2090){
        flag=true
    }
    Yearopt.push(opt)
}
export const therapaticAreaOpt:any=[]
const arraysOpt=["Hematology","Immunology","Ophthalmology","Podiatry","Healthy Volunteers","Gastroenterology","Psychiatry/Psychology","Pulmonary/Respiratory Diseases","Hepatology (Liver, Pancreatic, Gall Bladder)",
"Devices",
"Trauma",
"Urology",
"Sleep",
"Infections and Infectious Diseases",
"Plastic Surgery",
"Pharmacology/Toxicology",
"Cardiology/Vascular Diseases",
"Rare Diseases and Disorders",
"Pediatrics/Neonatology",
"Vaccines",
"Neurology",
"Nutrition and Weight Loss",
"Gene Therapy",
"Dermatology",
"Oncology",
"Genetic Disease",
"Rheumatology",
"Nephrology",
"Otolaryngology ",
"Orthopedics/Orthopedic Surgery",
"Endocrinology",
"Obstetrics/Gynecology ",
"Dental and Oral Health",
"Family Medicine",
"Musculoskeletal",
"Internal Medicine"]
arraysOpt.map((item:any)=>{
    const options:any={value:"",label:""}
    options.value=item.toString()
    options.label=item.toString()
    therapaticAreaOpt.push(options)
    return null
})


