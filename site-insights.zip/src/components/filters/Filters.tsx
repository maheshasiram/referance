import React, { useEffect ,useRef,useState} from 'react'
import Button from '@mui/material/Button';
import { Types } from '../../reducer/Types';
import './FiltersStyles.scss';
import { useDispatch, useSelector } from "react-redux";
import { enableToastAlert, fetchAllCountriesTrailCount, fetchAllSitesCount, fetchCentersCountWithRcStatus, fetchCentersWithMaxCount, fetchPisPerferdSites, fetchRecritmentCenterConsideredMost, fetchRecruitmentCenterDetails, fetchSiteLegacy, fetchSitesOfSelectedDuration, fetchStudyInvestigatorDetails, fetchTrailsConductedVsStopped, fetchTrailsTypeInRcCenter, fetchTrailsWrtTrailsStatus, fetchTypesOfCenters, fetchTypesOfStudies} from '../../actions/action';
import TherapaticAreaFilter1 from './TherapaticAreaFilter1';
import TrailStatusFilter from './TrailStatusFilter';
import SitesFilter from './SitesFilter';
import CountryFilter from './CountryFilter';
import YearsFilter from './YearsFilter';
import TherapaticAreaFilter from './TherapaticAreaFilter';
const InshightsFilters=()=>{
    const dispatch=useDispatch()
    const {filterValues ,filter_Actions}=useSelector((state:any)=>state.application)
    const filtersFlag=useRef(false)
    const filtersApplied=useRef(false)
    const [buttoonDisable,setButtonsDisable]=useState(true)
    useEffect(()=>{
        ValidateFilterKeys(filterValues)
      
         // eslint-disable-next-line react-hooks/exhaustive-deps
    },[filter_Actions])
    const ValidateFilterKeys=(props:any)=>{
      
        let count=0
        Object.keys(filterValues)?.map((key:any)=>{
            if(filterValues[key] !==""){
                if(props==="clear"){
                    filterValues[key]=""
                }
                count+=1
            }
            return null
        })
        count>=1?filtersFlag.current=true:filtersFlag.current=false
        filtersFlag.current?setButtonsDisable(false):filtersApplied.current?setButtonsDisable(false):setButtonsDisable(true)
    }
    const InshightsUpdate=(filterValues:any)=>{
        dispatch(fetchTypesOfCenters(filterValues))
        dispatch(fetchRecruitmentCenterDetails(filterValues)) 
        dispatch(fetchStudyInvestigatorDetails(filterValues)) 
        dispatch(fetchRecritmentCenterConsideredMost(filterValues))
        dispatch(fetchTypesOfStudies(filterValues))
        dispatch(fetchTrailsWrtTrailsStatus(filterValues))
        dispatch(fetchTrailsTypeInRcCenter(filterValues))
        dispatch(fetchTrailsConductedVsStopped(filterValues))
        dispatch(fetchSiteLegacy(filterValues))
        dispatch(fetchCentersCountWithRcStatus(filterValues))
        dispatch(fetchPisPerferdSites(filterValues))
        dispatch(fetchAllSitesCount(filterValues))
        dispatch(fetchSitesOfSelectedDuration(filterValues))
        dispatch(fetchAllCountriesTrailCount(filterValues))
        dispatch(fetchCentersWithMaxCount(filterValues))

    }
    const applyFilters=()=>{
        ValidateFilterKeys("apply")
        if(filtersApplied.current || filtersFlag.current){
             InshightsUpdate(filterValues)
        dispatch(enableToastAlert({status:1,message:"Selected  Parameters are Appiled Apply Filter",open:true}))
        filtersApplied.current=true
    }
    else{
        dispatch(enableToastAlert({status:2,message:"No Parameters Were Selected",open:true}))

    }
    }
    const clearFilters=()=>{
        dispatch({type:Types.CLEAR_FILTER,payload:true})
        ValidateFilterKeys("clear")
        if(filtersApplied.current || filterValues.current){
            InshightsUpdate(filterValues)
            dispatch(enableToastAlert({status:1,message:"All filters Parmeters Were Cleared on Insights",open:true}))
            filtersApplied.current=false
            filtersFlag.current=false
            setButtonsDisable(true)
        }
    }
    return(
        <>
        <div className='FiltersMainContaier'>
            {/* <p>Select Filters :</p> */}
            <div  className='filtersContainer'>
                <TherapaticAreaFilter1/>
                <TrailStatusFilter/>
                <YearsFilter/>
                {/* <SitesFilter/> */}
                <CountryFilter/>
                <SitesFilter/>
                {/* <TherapaticAreaFilter/> */}
              {/* <RecruitmentStatusFilter/> */}
              {/* <PiNameFilter/> */}
            </div>
            <div className='submitFilterDiv'>
                <div className={buttoonDisable?"btndisable":""}>
                <Button disabled={buttoonDisable} variant="contained" disableElevation onClick={applyFilters}>Apply Filters</Button>
                <Button disabled={buttoonDisable} variant="outlined" color="error" onClick={clearFilters}> Clear Filters</Button>
                </div>
            </div>
        </div>
        
        </>
    )
}
export default InshightsFilters