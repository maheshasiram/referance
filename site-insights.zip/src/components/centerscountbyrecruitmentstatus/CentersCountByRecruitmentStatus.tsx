import React,{useEffect} from 'react'
import ReactEcharts from "echarts-for-react"
import CommonCard from '../../common/CommonCard';
import { useDispatch, useSelector } from 'react-redux';
import { fetchCentersCountWithRcStatus, } from '../../actions/action';
import Loader from '../../common/loader/GraphLoader';
import './styles.scss';
const CentersCountByRecruitmentStatus=()=>{
  const {centersCount}=useSelector((state:any)=>state.application)
  const dispatch=useDispatch()
  useEffect(()=>{
    dispatch(fetchCentersCountWithRcStatus())
  // eslint-disable-next-line react-hooks/exhaustive-deps
  },[])
const option = {
    tooltip: {},
    xAxis: [{ gridIndex: 0, type:"value" }],
    yAxis: [{ gridIndex: 0, type: "category" ,data:centersCount?centersCount[0]:""}],
    grid: [{ left: "25%" ,right:"15%" }],
    series: [
      {
        type: "bar",
        encode: {
          x: "Centers",
          y: "product"
        },
        data:centersCount?centersCount[1]:"",
        barWidth: '25%',
      },
    ]
  };
  return (
    <div className='col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12 mb-4'>
      <CommonCard Height={"430px"} title={"Centers Recruitment Status"}>
        {
          (centersCount)?(centersCount?.length!==0 )?<ReactEcharts option={option} style={{ height: "330px", width: "100%", marginBottom: "20px" }}  className='CenterCountContainer'/>:<div><p className='text-center' style={{lineHeight:"400px"}}> No Center Details To Display </p> </div>:<Loader/>
        }
      </CommonCard>
    </div>
  );

}
export default CentersCountByRecruitmentStatus