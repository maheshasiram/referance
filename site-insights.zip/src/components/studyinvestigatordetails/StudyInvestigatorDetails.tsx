import React, { useState,useEffect,useRef } from "react";
import { DataTable } from 'primereact/datatable';
import 'primeicons/primeicons.css';
import 'primereact/resources/themes/lara-light-indigo/theme.css';
import 'primereact/resources/primereact.css';
import { Column } from 'primereact/column';
import CommonCard from '../../common/CommonCard'; 
import { useDispatch, useSelector } from "react-redux";
import { fetchStudyInvestigatorDetails } from "../../actions/action";
import Loader from "../../common/loader/GraphLoader";
import { Button } from 'primereact/button';
import "../recruitmentcenterdetails/Style.scss";


function StudyInvestigatorDetails(){
    const dispatch=useDispatch()
    const {studyInvestigatorDetails}=useSelector((state:any)=>state.application)
    useEffect(() => {
      dispatch(fetchStudyInvestigatorDetails())
      // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

   
    const dt = useRef<any>(null);

const exportCSV = (selectionOnly:any) => {
  dt.current.exportCSV({ selectionOnly });
};


const header = (
  <div className="flex align-items-center justify-content-end gap-2 style" >
      <Button type="button" icon="pi pi-file" rounded onClick={() => exportCSV(false)} data-pr-tooltip="CSV" />
  </div>
);
    return (
        <div className='col-12 mb-4' style={{position:"relative"}}>
           <div style={{position:"absolute",right:"20px"}}>{header}</div>
        <CommonCard Height={"auto"} title={"Study Investigator Details"}>
        <>
            {
              (studyInvestigatorDetails)?
            <DataTable
              // header={header}
              ref={dt}
              paginator rows={10} 
              columnResizeMode="expand"
              resizableColumns 
              showGridlines
              tableStyle={{ minWidth: '50rem' }}
              value={studyInvestigatorDetails?studyInvestigatorDetails:[]}
              emptyMessage="No Study Investigator Details To Display."
              className={"DetailsContainer"}
              selectionMode="single"
               
            >
                <Column field="title" header="Title" ></Column>
                <Column field="name_of_responsible_person" header="Responsible Person"  ></Column>
                 <Column field="affiliation" header="Affliated With"></Column> 
                <Column field="country" header="Country" ></Column>
                <Column field="email" header="Email-ID"  ></Column>  
                <Column field="phone" header='Contact No'></Column>
            </DataTable>:<Loader/>
            }
        </>
        </CommonCard>
    </div>
    )
}
export default StudyInvestigatorDetails;