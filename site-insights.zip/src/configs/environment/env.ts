export const baseurl='http://10.22.243.23:5100/iqa/v1/sis'
export const environment={
    Contacts:{
        recruitmentCenterDetails:(baseurl+'/contacts/recruitment_center_details'),
        studyInvestigatorDetails:(baseurl+'/contacts/study_investigator_details'),
    },
    RecruitmentInfo:{
        centersConsideredMaxTimes:(baseurl+'/recruitment_info/center_considered_max_times'),
        siteLegacy:(baseurl+'/recruitment_info/site_legacy'),
        centersCountWithRcStatus:(baseurl+'/recruitment_info/no_of_centers_wrt_recruitment_status'),
        sitesPreferedByPi:(baseurl+'/recruitment_info/top_recruitment_sites_prefered_by_pi')
        
    },
    GeneralInshights:{
        typesOfCenters:(baseurl+'/general_info/center_types'),
        typeOfStudies:(baseurl+"/general_info/study_types"),
        trailsWithTypesOfTrailStatus:(baseurl+"/general_info/trials_wrt_trial_status"),
        typeOfTrailsInRecruitmentCenter:(baseurl+"/general_info/types_of_trials_in_recruitment_center"),
        trailsConductedVsStopped:(baseurl+"/general_info/conducted_vs_stopped_trials"),
        allSitesCount:(baseurl+"/general_info/all_sites"),
        siteOfSelectedDuration:(baseurl+"/general_info/sites_of_selected_duration"),
        centersWithMaxCapacity:(baseurl+"/general_info/centers_with_max_capacity"),
        trailsCountOfAllCountries:(baseurl+"/general_info/countrys_wrt_trials_count")
    },
    Filters:{
        trailStatusValues:(baseurl+"/filters/trial_status"),
        allCountries:(baseurl+"/filters/country_names"),
        siteNames:(baseurl+"/filters/site_names"),
        recruitmentStatusValues:(baseurl+'/filters/rc_status'),
        PiNames:(baseurl+'/filters/SI_names')
    }

}