import thunk from 'redux-thunk';
import reducer from './reducer/CombineReducer';
import { configureStore } from '@reduxjs/toolkit';

const store = configureStore({
  reducer: reducer,
  middleware: [thunk]
})

export default store;