const organizationData = 
    [
        {
    id :"1",
    organization:'iqa',
    bankname:'Hdfc'

},
{
    id :"2",
    organization:'iqa',
    bankname:'Hdfc'

},
    ]

 export default organizationData;

    

