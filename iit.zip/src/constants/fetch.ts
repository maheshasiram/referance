import axios from 'axios';


export const fetch = (request:any) => {
    const options = {
        method: request.method,
        url: request.url,
        data: request.data,
        timeout: (60 * 2 * 1000), 
        headers: request.headers,
        responseType:request.responseType,
    };
    // store.dispatch(Loader(true));
    return axios(options)
        .then((response: any) => {
            // console.log('.......___response', response);
            // store.dispatch(Loader(false));
            return response;
        });
}