
import { Types } from "../constants/Types"
import { request } from "../Config/Environment"
import { fetch } from "../constants/fetch"
import { messages } from "../constants/messages"

export const Alert: any = (data: any) => {
  return (dispatch: any) => {
    dispatch({
      type: Types.ON_OPEN_ALERT_DIALOG,
      payload: {
        ...data,
        header: 'Alert',
        open: true
      }
    })
  }
}

export const Confirm: any = (data: any) => {
  return (dispatch: any) => {
    dispatch({
      type: Types.ON_OPEN_ALERT_DIALOG,
      payload: {
        ...data,
        header: 'Confirm',
        open: true
      }
    })
  }
}

export const Loader = (payload: any) => {
  return (dispatch: any) => {
    dispatch({ type: Types.ON_SET_LOADER, payload })
  }
}


export const toastAlert: any = (payload: any) => {
  return (dispatch: any) => {
    dispatch({
      type: Types.IS_TOAST_ENABLED,
      payload
    })
  }
}

export const errHandler: Function = (reload:any) => {
  return (dispatch: any) => {
    dispatch(Alert({
      status: 3,
      message: messages.apiError,
      onOk: () => { 
        if(reload){
          window.location.reload(); 
        }
      }
    }));
    dispatch(Loader(false));
  }
}

export const rowClassName = (rowData: any) => (rowData.status ? '' : 'rowDisabled');

export const handleClose = (setOpen: any) => {
  setOpen(false);
};

export const getCountries: Function = (callback: Function) => {
  let url = `${request.helpers.countries}`
  return (dispatch: any) => {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: '',
    })
      .then((response: any) => {
        let _countries: { value: any, label: string, phoneCode: any }[] = [{ label: 'Select Country', value: '', phoneCode: 'code' }]
        response.data.result.map((country: { name: string, id: number, phone_extension: number }) => {
          _countries.push({ label: country.name, value: country.id, phoneCode: country.phone_extension })
        });
        dispatch({ type: Types.COUNTRYS_DROPDOWN, payload: _countries });
        dispatch({ type: Types.ALL_COUNTRIES, payload: response.data.result });
        if (callback) {
          callback(response.data.result);
        }
        dispatch(Loader(false));
      })
      .catch((err: any) => {

      })
  }
}

export const getStatesByCountry: Function = (countryId: any, callback: any) => {
  let url = `${request.helpers.states}/${countryId}`
  return (dispatch: any) => {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: '',
    })
      .then((response: any) => {
        let states: { value: any, label: string }[] = [{ label: 'Select State', value: '' }]
        response.data.result.map((state: { name: string, id: number }) => {
          states.push({ label: state.name, value: state.id });
        });
        if (callback) {
          callback(response.data.result);
        }
        dispatch({ type: Types.STATES_BY_COUNTRY, payload: response.data.result });
        dispatch({ type: Types.STATES_DROPDOWN, payload: states });
        dispatch(Loader(false));
      })
      .catch((err: any) => {

      })
  }
}

export const getCitiesByState: Function = (stateId: any, callback: any) => {
  let url = `${request.helpers.cities}/${stateId}`
  return (dispatch: any) => {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: '',
    })
      .then((response: any) => {
        let cities: { value: any, label: string }[] = [{ label: 'Select City', value: '' }]
        response.data.result.map((city: { name: string, id: number }) => {
          cities.push({ label: city.name, value: city.id });
        });
        if (callback) {
          callback(response.data.result);
        }
        dispatch({ type: Types.CITIES_DROPDOWN, payload: cities });
        dispatch({ type: Types.CITIES_BY_STATE, payload: response.data.result });
        dispatch(Loader(false));
      })
      .catch((err: any) => {

      })
  }
}

export const getOrganizationsDropdown: Function = (params: any) => {
  let url = `${request.Porfolio.organizationDropdown}`
  return (dispatch: any) => {
    fetch({
      method: 'GET',
      url: url,
      data: params,
    })
      .then((response: any) => {

        let result = response.data.result
        let orgArr:any = []
        result.forEach((item: any) => {
          orgArr.push({ label: item.name, value: item.id })
      });

        dispatch({ type: Types.ORAGNISATION_DROPDOWN, payload: orgArr })
      })
      .catch((err: any) => {

      })
  }
}

export const getGoodsandServicesDropdown: Function = (params: any) => {

  let url = `${request.masters.goodsandServicesDropdown}`
  return (dispatch: any) => {
    fetch({
      method: 'GET',
      url: url,
      data: params,
    })
      .then((response: any) => {
        let result = response.data.result.data
        let gasArr:any = []
        result.forEach((item: any) => {
            gasArr.push({ label: item.activity, value: item.id })
        });
        dispatch({ type: Types.GOODS_AND_SERVICES_DROPDOWN, payload: gasArr })
        dispatch({ type: Types.GOODS_AND_SERVICES, payload: result })
      })
      .catch((err: any) => {

      })
  }
}

export const allCustomersDropdown: Function = (params: any) => {
  let url = `${request.masters.customersDropdown}`
  return (dispatch: any) => {
    fetch({
      method: 'GET',
      url: url,
      data: params,
    })
      .then((response: any) => {

        let result = response.data.result
        let custArr:any = []
        result.forEach((item: any) => {
          custArr.push({ label: item.name, value: item.id })
      });

        dispatch({ type: Types.CUSTOMERS_DROPDOWN, payload: custArr })
      })
      .catch((err: any) => {

      })
  }
}
export const getUploadedFile:Function=(params:any)=>{
  let url=`${request.helpers.getUploadedFile}/${params}`
  return(dispatch:any)=>{
    fetch({
      method:'GET',
      url:url,
      data:params
    })
    .then((response:any)=>{
      let result=response.data.result
      dispatch({type:Types.UPLOADED_File,payload:result})
    })
    .catch((err:any)=>{
    })
  }
}

export const getInvoiceOrganization: Function = (orgId: any, callback: Function) => {
  let url = `${request.invoice.invoiceOrganizatioin}/${orgId}`
  return (dispatch: any) => {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      // data: { 'id': orgId },
    })
      .then((response: any) => {
        callback(response.data);
        dispatch(Loader(false));
      })
      .catch((err: any) => {
        dispatch(errHandler());
      })
  }
}

export const getInvoiceCustomer: Function = (customerId: any, callback: Function) => {
  let url = `${request.invoice.invoiceCustomer}/${customerId}`
  return (dispatch: any) => {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      // data: { 'id': orgId },
    })
      .then((response: any) => {
        callback(response.data);
        dispatch(Loader(false));
      })
      .catch((err: any) => {
        dispatch(errHandler());
      })
  }
}

export const getInvoiceBank: Function = (bankId: any, callback: Function) => {
  let url = `${request.invoice.invoiceBank}/${bankId}`
  return (dispatch: any) => {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      // data: { 'id': orgId },
    })
      .then((response: any) => {
        callback(response.data);
        dispatch(Loader(false));
      })
      .catch((err: any) => {
        dispatch(errHandler());
      })
  }
}

export const fetchAllInvoices : Function = (params:any) => {
  let url = `${request.invoice.createAndGetInvoice}?offset_filter=${params.offset_filter}&limit_filter=${params.limit_filter}&export=${params.export}`
  return (dispatch:any) => {
    dispatch(Loader(true));

    fetch({
      method: 'GET',
      url: url,
      data:params,
    })
      .then((response:any) => {
       dispatch({type:Types.GET_ALL_INVOICES, payload:response.data.result}); 
       dispatch(Loader(false));
      })
      .catch((err:any)=>{
        dispatch(errHandler('reload'));
      })
  }
}

export const getInvoiceNumber : Function = (params:any,callback:any) => {
  console.log(params)
  let url = `${request.invoice.getInvoiceNumber}`
  return (dispatch:any) => {
    dispatch(Loader(true));

    fetch({
      method: 'Post',
      url: url,
      data:params,
    })
      .then((response:any) => {
        dispatch({type:Types.INVOICE_NUMBER, payload:response.data.result.invoice_number}); 
       dispatch(Loader(false));
      })
      .catch((err:any)=>{
        dispatch(errHandler('reload'));
      })
  }
}

export const createInvoice : Function = (params:any,callback:any) => {
  console.log(params)
  let url = `${request.invoice.createAndGetInvoice}`
  return (dispatch:any) => {
    dispatch(Loader(true));

    fetch({
      method: 'PUT',
      url: url,
      data:params,
    })
      .then((response:any) => {
        // dispatch({type:Types.INVOICE_NUMBER, payload:response.data.result.invoice_number}); 
       callback(response.data)
       dispatch(Loader(false));
      })
      .catch((err:any)=>{
        dispatch(errHandler('reload'));
      })
  }
}


export const addInvoiceItems: Function = (params: any) => {

  let url = `${request.invoice.addInvoiceItems}`
  return (dispatch: any) => {
    dispatch(Loader(true));
    fetch({
      method: 'PUT',
      url: url,
      data: params,
    })
      .then((response: any) => {

       fetchAllInvoices()
        dispatch(Loader(false));

      })
      .catch((err: any) => {

      })
  }
}


export const updateInvoice : Function = (params:any,callback:any) => {
  console.log(params)
  let url = `${request.invoice.createAndGetInvoice}`
  return (dispatch:any) => {
    dispatch(Loader(true));

    fetch({
      method: 'POST',
      url: url,
      data:params,
    })
      .then((response:any) => {
        // dispatch({type:Types.INVOICE_NUMBER, payload:response.data.result.invoice_number}); 
       callback(response.data)
       dispatch(Loader(false));
      })
      .catch((err:any)=>{
        dispatch(errHandler('reload'));
      })
  }
}


export const updateInvoiceItems: Function = (params: any) => {

  let url = `${request.invoice.updateInvoiceItems}`
  return (dispatch: any) => {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: url,
      data: params,
    })
      .then((response: any) => {

       fetchAllInvoices()
        dispatch(Loader(false));

      })
      .catch((err: any) => {

      })
  }
}