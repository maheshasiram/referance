const domain = `${process.env.REACT_APP_DEV_API}iqa/v1/iit/`
//take url from .env

export const request = {
    Porfolio: {
        organizationDetails: (`${domain}portfolio/organization`),
        bankingDetails: (`${domain}portfolio/banking`),
        organizationDropdown: (`${domain}portfolio/organization/dropdown`),
        disableOrganization: (`${domain}portfolio/organization/status`),
        disableBanking: (`${domain}portfolio/banking/status`)
    },
    masters: {
        allCustomerDetails: (`${domain}masters/customer`),
        allVendorDeatails: (`${domain}masters/vendor`),
        activateDeactivateCustomer: (`${domain}masters/customer/status`),
        activateDeactivateVendor: (`${domain}masters/vendor/status`),
        goodsandServicesDropdown: (`${domain}masters/goods_and_services`),
        customersDropdown: (`${domain}masters/customer/dropdown`),
    },
    helpers: {
        countries: (`${domain}helper/countries`),
        states: (`${domain}helper/states`),
        cities: (`${domain}helper/cities`),
        uploadImage: (`${domain}helper/upload_image`),
        uploadFile: (`${domain}helper/upload_file`),
        currency: (`${domain}helper/currency`),
        getUploadedFile: (`${domain}helper/files/id`),
        getUploadedImage: (`${domain}helper/image/id`)
    },
    invoice: {
        invoiceOrganizatioin: (`${domain}portfolio/organization/id`),
        invoiceCustomer: (`${domain}masters/customer/id`),
        invoiceBank: (`${domain}portfolio/banking/id`),
        createAndGetInvoice:(`${domain}invoice`),
        getInvoiceNumber:(`${domain}invoice/number`),
        addInvoiceItems:(`${domain}invoice/item`),
        updateInvoiceItems:(`${domain}invoice/items`)
    },
    quotation: {
        createAndGetQuotation:(`${domain}quotation`),
        getQuotationNumber:(`${domain}quotation/number`),
        addQuotationItems:(`${domain}quotation/item`),
        updateQuotationItems:(`${domain}quotation/items`)
    }
}
