import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import './style.scss';

type Props = {
  children: JSX.Element
};

function CommonCard({ children }: Props) {

  return (
    <Card 
    //  className={(children.props.initialValues.organization_id==undefined)? "Mastercard":"Invoicecard"}  
    >
      <CardContent className='card-content-div'>
        <Typography component={'div'}>
          {children}
        </Typography>
      </CardContent>
    </Card>
  );
}
export default CommonCard;
