import React, { Component } from 'react'
import Select from 'react-select';
import './style.scss';


function SelectComponent(props: any) {
    const { defaultValue, id, isDisabled, onChange, placeholder, name, isMulti, options } = props;
    const customStyles = {
        control: (provided : any , state :any) => ({
          ...provided,
          minHeight: '20px',
          height: '35px'
        }),
        valueContainer: (provided : any , state :any) => ({
          ...provided,
          height: '35px',
          padding: '0px'
        }),
        indicatorsContainer: (provided : any , state :any) => ({
          ...provided,
          height: '35px',
        }),
      };
    return (
        <div className='w-100'>
            <Select
                id={id}
                classNamePrefix="select"
                defaultValue={defaultValue}
                isDisabled={isDisabled}
                name={name}
                isMulti={isMulti}
                onChange={onChange}
                options={options}
                isClearable={true}
                isSearchable={true}
                placeholder={placeholder || 'select option'}
                className="metricSelectComponent"
                styles={customStyles}
            />
        </div>

    )
}
export default SelectComponent;