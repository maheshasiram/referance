import { Types } from '../constants/Types';
import { domesticInvoiceModal } from '../modules/invoice/domastic/constants/modal';
import { internationalInvoiceModal } from '../modules/invoice/international/constants/modal';

const initialState = {
  isLoader: false,
  modal: {
    header: '',
    status: 0,
    open: false,
    message: "",
    disabled: false,
    actionType: '',
    onOk: () => { },
    onCancel: () => { },
  },
  isToast: { status: 0, message: '', open: false },
  currentUser: {
    id: 1,
    userName: "srikanth",
    role: "Admin"
  },
  allCountries: [],
  countriesDropdown: null,
  statesByCountry: [],
  statesDropdown: null,
  citiesByState: [],
  citiesDropdown: null,
  organizationsDropdown: [],
  goodsAndServicesDropdown: [],
  goodsAndServicesDetails: [],
  customersDropdown: [],
  fileUploaded: {},
  InvoiceOrganization: {},
  InvoiceCustomer: {},
  InvoiceBank: {},
  invoiceDetails: {},
  allInvoiceDetails: null,
  invoiceParams: { offset_filter: 0, limit_filter: 5, export: false },
  invoiceNumber: '',
  domesticData: domesticInvoiceModal,
  internationalData:internationalInvoiceModal
}

export const application = (state = initialState, action: { type: any, payload: any }) => {
  switch (action.type) {
    case Types.ON_OPEN_ALERT_DIALOG:
      return { ...state, modal: action.payload }

    case Types.ON_CLOSE_ALERT_DIALOG:
      return { ...state, modal: action.payload }

    case Types.ALL_COUNTRIES:
      return { ...state, allCountries: action.payload }

    case Types.COUNTRYS_DROPDOWN:
      return { ...state, countriesDropdown: action.payload }

    case Types.STATES_BY_COUNTRY:
      return { ...state, statesByCountry: action.payload }

    case Types.STATES_DROPDOWN:
      return { ...state, statesDropdown: action.payload }

    case Types.CITIES_BY_STATE:
      return { ...state, citiesByState: action.payload }

    case Types.CITIES_DROPDOWN:
      return { ...state, citiesDropdown: action.payload }

    case Types.ORAGNISATION_DROPDOWN:
      return { ...state, organizationsDropdown: action.payload }

    case Types.IS_TOAST_ENABLED:
      return { ...state, isToast: action.payload }

    case Types.ON_SET_LOADER:
      return { ...state, isLoader: action.payload }

    case Types.GOODS_AND_SERVICES_DROPDOWN:
      return { ...state, goodsAndServicesDropdown: action.payload }

    case Types.GOODS_AND_SERVICES:
      return { ...state, goodsAndServicesDetails: action.payload }

    case Types.CUSTOMERS_DROPDOWN:
      return { ...state, customersDropdown: action.payload }

    case Types.UPLOADED_File:
      return { ...state, fileUploaded: action.payload }

    case Types.INVOICE_ORGANIZATION:
      return { ...state, InvoiceOrganization: action.payload }

    case Types.INVOICE_CUSTOMER:
      return { ...state, InvoiceCustomer: action.payload }

    case Types.INVOICE_BANK:
      return { ...state, InvoiceBank: action.payload }

    case Types.INVOICE_DETAILS:
      return { ...state, invoiceDetails: action.payload }
    case Types.GET_ALL_INVOICES:
      return { ...state, allInvoiceDetails: action.payload }

    case Types.INVOICE_PARAMS:
      return { ...state, invoiceParams: action.payload }

    case Types.INVOICE_NUMBER:
      return { ...state, invoiceNumber: action.payload }

    case Types.DOMESTIC_INVOICE_DATA:
      return { ...state, domesticData: action.payload }

    case Types.INTERNATIONAL_INVOICE_DATA:
      return { ...state, internationalData: action.payload }

    default:
      return { ...state }
  }
}