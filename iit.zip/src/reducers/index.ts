import { combineReducers } from "redux";
import { application } from "./application";
import { organization } from "../modules/portfolio/oraganisation/reducer/organization";
import { Banking } from "../modules/portfolio/banking/reducers/Banking";
import { customers } from "../modules/masters/customers/reducer/Customers";
import { vendor } from "../modules/masters/vendors/reducer/Vendor";
import { DomesticQuotation } from "../modules/quotation/domestic/reducer/DomesticQuotation";


const reducer = combineReducers({
    application,
    organization,
    Banking,
    customers,
    vendor,
    DomesticQuotation
})

export type RootState = ReturnType<typeof reducer>;

export default reducer;