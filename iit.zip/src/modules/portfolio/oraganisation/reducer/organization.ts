import { organizationModal } from "../constant/modal"
import { Types } from "./Types"


const initialState = {
  allOrganizations: null,
  orgParams: { offset_filter: 0, limit_filter: 10, export: false,search_text:" " },
  organization: organizationModal,
  getuploadedImage:[]
}

export const organization = (state = initialState, action: { type: any, payload: any }) => {
  switch (action.type) {
    case Types.GET_ORGANIZATIONS:
      return { ...state, allOrganizations: action.payload }

    case Types.ORAGANIZATION_DATA:
      return { ...state, organization: action.payload }

    case Types.ORAGANIZATION_PARAMS:
      return { ...state, orgParams: action.payload }
    case Types.GETUPLOADEDIMAGE:
      return{...state,getuploadedImage:action.payload}

    default:
      return { ...state }
  }
}