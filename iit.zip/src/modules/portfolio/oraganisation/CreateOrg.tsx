import React, { useEffect, useState } from 'react';
import * as Yup from 'yup';
import { Formik, Field, Form, FormikHelpers, ErrorMessage } from 'formik';
import { useDispatch, useSelector } from 'react-redux';
import CustomDialog from '../../../common/modals/CustomeDialog';
import { organizationDataTypes } from "./constant/dataTypes"
import SelectComponent from '../../../common/SelectComponent';
import { getCitiesByState, getCountries, getStatesByCountry, handleClose, toastAlert } from '../../../actions/actions';
import { createOrganization, fetchOrganizations, updateOrganization, uploadDocument, getUploadedImage } from './actions/actions';
import EditIcon from '@mui/icons-material/Edit';
import { Types } from "../oraganisation/reducer/Types"
import { organizationModal } from './constant/modal';
import { organizationSchema } from './constant/validate';
import CustomToolTip from '../../../common/CustomToolTip';
import _ from "lodash";
import './style.scss';
import { VscOrganization } from 'react-icons/vsc';
import DeleteIcon from '@mui/icons-material/DeleteOutline';

function CreateOrg(props: any) {

    const dispatch = useDispatch();
    const { organization, orgParams, uploadedImage } = useSelector((state: any) => state.organization);
    const { countriesDropdown, citiesDropdown, statesDropdown } = useSelector((state: any) => state.application);
    const { orgData, id } = props;
    const [open, setOpen] = useState(false);
    const [error, setError] = useState('');
    const [btnDisable, setBtnDisable] = useState(true);
    const [phoneCode, setPhoneCode] = useState('');
    const [uploadImgErr, setUploadImgErr] = useState('');
    const [imageBinaryData, setImageBinaryData] = useState('');
    const [imageUploaded, setImageUploaded] = useState(false);
    const [fileFeild, setFileField] = useState(false)
    function hexToBase64(str: any) {
        return window.btoa(String.fromCharCode.apply(null, str.replace(/\r|\n/g, "").replace(/([\da-fA-F]{2}) ?/g, "0x$1 ").replace(/ +$/, "").split(" ")));
    }
    const onOpenOrganizationForm = (type: string) => {
        dispatch(getCountries(() => {
            if (type == "add") {
                setPhoneCode('');
                dispatch({ type: Types.ORAGANIZATION_DATA, payload: organizationModal });
            } else {
               
                let _orgData = _.cloneDeep(orgData);
                dispatch(getStatesByCountry(orgData.country.id, () => {
                    dispatch(getCitiesByState(orgData.state.id, () => {
                        // if (countriesDropdown && statesDropdown && citiesDropdown) {
                        //     _orgData.country = countriesDropdown && countriesDropdown.find((contry: any) => (contry.value == orgData.country.id));
                        //     _orgData.state = statesDropdown && statesDropdown.find((state: any) => (state.value == orgData.state.id));
                        //     _orgData.city = citiesDropdown && citiesDropdown.find((city: any) => (city.value == orgData.city.id));
                        // }
                    }));
                }));
                setPhoneCode(orgData?.country?.phone_extension ? orgData.country.phone_extension : '');
                _orgData.country = { 'label': orgData.country.name, 'value': orgData.country.id }
                _orgData.country_id = orgData.country.id
                _orgData.state = { 'label': orgData.state.name, 'value': orgData.state.id }
                _orgData.state_id = orgData.state.id
                _orgData.city = { 'label': orgData.city.name, 'value': orgData.city.id }
                _orgData.city_id = orgData.city.id
                dispatch({ type: Types.ORAGANIZATION_DATA, payload: _orgData });
                if (orgData.logo_id !== null) {
                    setFileField(true)
                    dispatch(getUploadedImage(orgData.logo_id, (response: any) => {
                        let binary = response.result[0].file
                        let encoded = hexToBase64(binary)
                        setImageBinaryData(binary)

                    }))
                }else{
                    setFileField(false)
                }
               
                setUploadImgErr('')
            }
            setOpen(true);
        }));
        setBtnDisable(true);
    }

    const onInputChangeHandler = (e: any, setFieldValue: any) => {
        setBtnDisable(false);
        setFieldValue(e.target.name, e.target.value);
        setError('');
    }

    const onCountrySelect = (e: any, setFieldValue: any, setFieldTouched: any) => {
        setBtnDisable(false);
        setFieldValue('country_id', e?.value ? e.value : null);
        setPhoneCode(e?.phoneCode ? e?.phoneCode : '');
        setFieldTouched('country_id', true);
        if (e?.value) {
            dispatch(getStatesByCountry(e.value));
        }
        //setFieldValue('state_id','')
    }

    const onStateSelect = (e: any, setFieldValue: any) => {
        setBtnDisable(false);
        setFieldValue('state_id', e?.value ? e.value : '');
        if (e?.value) {
            dispatch(getCitiesByState(e.value));
        }
    }

    const onCitySelect = (e: any, setFieldValue: any) => {
        setBtnDisable(false);
        setFieldValue('city_id', e?.value ? e.value : '');
    }
    const onFileUpload = (e: any, setFieldValue: any, setFieldTouched: any) => {
        setFieldValue("file", e.currentTarget.files[0]);
        setBtnDisable(false);
        setUploadImgErr('');
        // set
    }


    const DeleteFilename = (values: any) => {

        values.logo_id = ""
        setFileField(false)
    }

    const onSubmitOrganization = (values: any) => {
        let _values = _.cloneDeep(values);

        console.log(values)
        console.log(_values.logo_id)
        var formData = new FormData();
        formData.append("file_type", 'logo');
        formData.append("file", _values.file);

        if (_values.file) {
            dispatch(uploadDocument(formData, (response: any) => {
                if (response.status == "success") {
                    _values.logo_id = response.result.id
                    _values.watermark_id = response.result.id


                }
            }

            ));

        }

        if (!_values.id) {

            delete _values.file;
            dispatch(createOrganization(_values, (response: any) => {
                if (response.status == 'success') {
                    dispatch(fetchOrganizations(orgParams));
                    // handleClose(setOpen);
                    setOpen(false)
                    console.log("created sucessfully-----135")
                    dispatch(toastAlert({
                        status: 1,
                        message: 'Organization Created Successfully',
                        open: true
                    }));
                }
            }));
        } else if (_values.id) {

         
            delete _values.file;

            dispatch(updateOrganization(_values, (response: any) => {
                if (response.status == 'success') {
                    dispatch(fetchOrganizations(orgParams));
                    handleClose(setOpen);
                    console.log("Organization updated successfully")
                    dispatch(toastAlert({
                        status: 1,
                        message: 'Organization Updated Successfully',
                        open: true
                    }));
                    setOpen(false)
                }
            }));

        }


        // if(_values.file && !_values.id){

        //     console.log(_values.logo_id)




        // }else if(_values.id && _values.logo_id !==""){


        // }
        // else if(_values.id && _values.logo_id =="" && _values.file){
        // dispatch(uploadDocument(formData, (response: any) => {
        //     if (response.status == "success") {
        //         _values.logo_id = response.result.id
        //         _values.watermark_id = response.result.id
        //         delete _values.file;
        //          dispatch(updateOrganization(_values, (response: any) => {
        //                 if (response.status == 'success') {
        //                     dispatch(fetchOrganizations(orgParams));
        //                     handleClose(setOpen);
        //                     // setOpen(false)
        //                     console.log("updated successfully----164")
        //                     dispatch(toastAlert({
        //                         status: 1,
        //                         message: 'Organization Updated Successfully',
        //                         open: true
        //                     }));
        //                 }
        //             }));
        //         }
        //     }))

        // }
        // else{
        //     setUploadImgErr('Please Upload Organization Logo');
        // }
    }
    return (
        <React.Fragment>
            <div className='d-flex justify-content-end'>
                {id == 0 ?
                    <button className='btn-eprimary my-2' onClick={() => onOpenOrganizationForm('add')}> Create Organization</button>
                    : <EditIcon sx={{ fontSize: 17, opacity: 0.8 }} onClick={() => onOpenOrganizationForm('edit')} />
                }
            </div>

            <CustomDialog
                title={!organization.id ? 'Create Organization' : 'Update Organization'}
                titleIcon={<VscOrganization />}
                open={open}
                onClose={() => handleClose(setOpen)}
                maxWidth={'md'}
                fullWidth={true}
                actionType={!organization.id ? 'Submit' : 'Update'}
                form={'addOrg'}
                disabled={btnDisable}
            >
                <div className="header-container">
                    <p className="text-center text-danger">{error}</p>
                </div>
                <Formik
                    enableReinitialize={true}
                    initialValues={organization}
                    validationSchema={organizationSchema(organization)}
                    onSubmit={(values: any) => {
                        onSubmitOrganization(values)
                    }}
                >
                    {({ errors, touched, values, setFieldValue, setFieldTouched, setFieldError }) => (
                        <Form id='addOrg'>
                            <section className='d-flex'>
                                <div className='sectionHeader'>Account</div>
                                <div className='field section-contant account'>
                                    <div className='d-flex sectionField'>
                                        <label htmlFor="name"> Organization Name:<span className='text-danger mx-1'>*</span></label>
                                        <Field placeholder='Enter Company Name' className="form-control" name="name"
                                            value={values.name}
                                            onChange={(e: any) => {
                                                onInputChangeHandler(e, setFieldValue);
                                            }}
                                        />
                                    </div>
                                    {errors.name && touched.name ? <div className='errMsg'><ErrorMessage name={`name`} /></div> : <span>&nbsp;</span>}
                                </div>
                            </section>
                            <hr className='m-0'></hr>
                            <section className='mt-1 d-flex'>
                                <div className='sectionHeader'>ID Details</div>
                                <div className='section-contant'>
                                    <div className='d-flex section-Fields'>
                                        <div className='field w-50'>
                                            <div className='d-flex sectionField'>
                                                <label htmlFor="GSTin" className='w-label'> GSTIN :<span className='text-danger mx-1'>*</span></label>
                                                <Field placeholder='Enter GST Number' className="form-control" name="gst"
                                                    value={values.gst}
                                                    onChange={(e: any) => {
                                                        onInputChangeHandler(e, setFieldValue);
                                                    }}
                                                />
                                            </div>
                                            {errors.gst && touched.gst ? <div className='errMsg'><ErrorMessage name={`gst`} /></div> : <span>&nbsp;</span>}
                                        </div>
                                        <div className='field w-50'>
                                            <div className='d-flex sectionField'>
                                                <label htmlFor="PAN" className='w-label'> PAN :<span className='text-danger mx-1'>*</span></label>
                                                <Field placeholder='Enter PAN Number' className="form-control" name="pan"
                                                    value={values.pan}
                                                    onChange={(e: any) => {
                                                        onInputChangeHandler(e, setFieldValue);
                                                    }}
                                                />
                                            </div>
                                            {errors.pan && touched.pan ? <div className='errMsg'><ErrorMessage name={`pan`} /></div> : <span>&nbsp;</span>}
                                        </div>
                                    </div>
                                    <div className='d-flex section-Fields'>
                                        <div className='field w-50'>
                                            <div className='d-flex sectionField'>
                                                <label htmlFor="TIN" className='w-label'> TIN :<span className='text-danger mx-1'></span></label>
                                                <Field placeholder='Enter TIN Number' className="form-control" name="tin"
                                                    value={values.tin}
                                                    onChange={(e: any) => {
                                                        onInputChangeHandler(e, setFieldValue);
                                                    }}
                                                />
                                            </div>
                                            {/* {errors.tin && touched.tin ? <div className='errMsg'><ErrorMessage name={`tin`} /></div> : <span>&nbsp;</span>} */}
                                        </div>
                                        <div className='field w-50'>
                                            <div className='d-flex sectionField'>
                                                <label htmlFor="CIN" className='w-label'> CIN :<span className='text-danger mx-1'></span></label>
                                                <Field placeholder='Enter CIN Number' className="form-control" name="cin"
                                                    value={values.cin}
                                                    onChange={(e: any) => {
                                                        onInputChangeHandler(e, setFieldValue);
                                                    }}
                                                />
                                            </div>
                                            {/* {errors.cin && touched.cin ? <div className='errMsg'><ErrorMessage name={`cin`} /></div> : <span>&nbsp;</span>} */}
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <hr className='m-0'></hr>
                            <section className='mt-1 d-flex'>
                                <div className='sectionHeader'>Address</div>
                                <div className='section-contant'>
                                    <div className='d-flex section-Fields'>
                                        <div className='field w-50'>
                                            <div className='d-flex sectionField'>
                                                <label htmlFor="country" className='w-label'> Country :<span className='text-danger mx-1'>*</span></label>
                                                <SelectComponent
                                                    id={"country"}
                                                    className="form-control"
                                                    defaultValue={values.country}
                                                    isDisabled={false}
                                                    isClearable={true}
                                                    isSearchable={true}
                                                    name={"country"}
                                                    options={countriesDropdown}
                                                    placeholder={"Select Country"}
                                                    onChange={(e: any) => {
                                                        onCountrySelect(e, setFieldValue, setFieldTouched);
                                                        setFieldValue('state_id', '')
                                                    }}
                                                />
                                            </div>
                                            {errors.country_id && !values.country_id && touched.country_id ? <div className='errMsg'>{errors.country_id as string}</div> : <span>&nbsp;</span>}
                                        </div>
                                        <div className='field w-50'>
                                            <div className='d-flex sectionField'>
                                                <label htmlFor="state" className='w-label'> State :<span className='text-danger mx-1'>*</span></label>
                                                <SelectComponent
                                                    id={"state"}
                                                    className="form-control"
                                                    defaultValue={values.state}
                                                    isDisabled={values.country_id ? false : true}
                                                    isClearable={true}
                                                    isSearchable={true}
                                                    name={"state"}
                                                    options={statesDropdown}
                                                    placeholder={"Select State"}
                                                    onChange={(e: any) => onStateSelect(e, setFieldValue)}
                                                />
                                            </div>
                                            {/* {errors.state_id && values.country_id ? <div className='errMsg'>{errors.state_id as string}</div> : <span>&nbsp;</span>} */}
                                            {errors.state_id && touched.state_id ? <div className='errMsg'><ErrorMessage name={`state_id`} /></div> : <span>&nbsp;</span>}
                                        </div>
                                    </div>
                                    <div className='d-flex section-Fields'>
                                        <div className='field w-50'>
                                            <div className='d-flex sectionField'>
                                                <label htmlFor="city" className='w-label'> City :<span className='text-danger mx-1'>*</span></label>
                                                <SelectComponent
                                                    id={"city"}
                                                    className="form-control"
                                                    defaultValue={values.city}
                                                    isDisabled={values.state_id ? false : true}
                                                    isClearable={true}
                                                    isSearchable={true}
                                                    name={"city"}
                                                    options={citiesDropdown}
                                                    placeholder={"Select City"}
                                                    onChange={(e: any) => onCitySelect(e, setFieldValue)}
                                                />
                                            </div>
                                            {/* {errors.city_id && values.state_id ? <div className='errMsg'>{errors.city_id as string}</div> : <span>&nbsp;</span>} */}
                                            {errors.city_id && touched.city_id ? <div className='errMsg'><ErrorMessage name={`city_id`} /></div> : <span>&nbsp;</span>}
                                        </div>
                                        <div className='field w-50'>
                                            <div className='d-flex sectionField'>
                                                <label htmlFor="address" className='w-label'> Address :<span className='text-danger mx-1'>*</span></label>
                                                <Field as='textarea' placeholder='Enter Address' className="form-control" name="address"
                                                    value={values.address}
                                                    onChange={(e: any) => { onInputChangeHandler(e, setFieldValue); }}
                                                />
                                            </div>
                                            {errors.address && touched.address ? <div className='errMsg'><ErrorMessage name={`address`} /></div> : <span>&nbsp;</span>}
                                        </div>
                                    </div>
                                    <div className='d-flex section-Fields'>
                                        <div className='field w-50'>
                                            <div className='d-flex sectionField'>
                                                <label htmlFor="phone" className='w-label'> Phone :<span className='text-danger mx-1'>*</span></label>
                                                <div className='input-group'>
                                                    <span className="input-group-text " id="basic-addon1">{phoneCode ? phoneCode : 'code'}</span>
                                                    <Field placeholder='Enter Phone Number' disabled={values.country_id ? false : true} className="form-control" name="phone"
                                                        value={values.phone}
                                                        onChange={(e: any) => { onInputChangeHandler(e, setFieldValue); }}
                                                    />
                                                </div>
                                            </div>
                                            {errors.phone && touched.phone && values.country_id ? <div className='errMsg'><ErrorMessage name={`phone`} /></div> : <span>&nbsp;</span>}
                                        </div>
                                        <div className='field w-50'>
                                            <div className='d-flex sectionField'>
                                                <label htmlFor="postal code" className='w-label'> Postal Code :<span className='text-danger mx-1'>*</span></label>
                                                <Field placeholder='Enter Postal Code Number' disabled={values.state_id ? false : true} className="form-control" name="postal_code"
                                                    value={values.postal_code}
                                                    onChange={(e: any) => { onInputChangeHandler(e, setFieldValue); }}
                                                />
                                            </div>
                                            {errors.postal_code && touched.postal_code ? <div className='errMsg'><ErrorMessage name={`postal_code`} /></div> : <span>&nbsp;</span>}
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <hr className='m-0'></hr>
                            <section className='mt-1 d-flex'>
                                <div className='sectionHeader'>Upload Logo</div>
                                <div className='field section-contant'>
                                    <div className='d-flex sectionField'>
                                        <label htmlFor="filename"> Upload Logo :</label>
                                        <Field
                                            className="form-control"
                                            type='file'
                                            accept="image/*"
                                            name="fileUpload"
                                            id='filename'
                                            placeholder={"Organization Logo"}
                                            onChange={(event: any) => { onFileUpload(event, setFieldValue, setFieldTouched) }}
                                            disabled={fileFeild}
                                        />
                                    </div>
                                    {/* {(uploadImgErr) ? <div className='errMsg'>{uploadImgErr}</div> : <span>&nbsp;</span>} */}
                                </div>
                                <div>
                                    {fileFeild &&<DeleteIcon onClick={(event: any) => { DeleteFilename(values) }} />}
                                </div>
                            </section>
                        </Form>
                    )}
                </Formik>
            </CustomDialog>

        </React.Fragment>
    );
}



export default CreateOrg;