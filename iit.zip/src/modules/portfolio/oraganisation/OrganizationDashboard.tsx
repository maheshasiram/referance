import React, { useEffect } from 'react'
import { useDispatch, useSelector } from "react-redux";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import CreateOrg from './CreateOrg';
import { activeInactiveOrganization, fetchOrganizations } from './actions/actions';
import { Confirm, getCountries, rowClassName, toastAlert } from '../../../actions/actions';
import Switch from '@mui/material/Switch';
import { messages } from '../../../constants/messages';
import { confirmMsg, toastMsg } from '../../../common/Messages';
import SearchField from '../../../common/SearchField';
import { Types } from './reducer/Types';

function OrganizationDashboard(props: any) {

  const dispatch = useDispatch();
  const { allOrganizations, orgParams } = useSelector((state: any) => state.organization);
  const loaded = React.useRef(false);
  const [searchVal, setSearchVal] = React.useState('');
  const [pageClick, setpageChange] = React.useState(false);

  useEffect(() => {
    if (!loaded.current) {
      dispatch(fetchOrganizations(orgParams));
      loaded.current = true;
    }
  }, []);

  const onActiveInActiveOrg = (rowData: any) => {
    dispatch(Confirm({
      status: 0,
      message: rowData.status ? confirmMsg(messages.inActive, rowData.name) : confirmMsg(messages.active, rowData.name),
      onOk: () => {
        dispatch(activeInactiveOrganization(rowData.id, (response: any) => {
          dispatch(toastAlert({
            status: response.status == "success" ? 1 : 0,
            message: rowData.status ? toastMsg(messages.activated, rowData.name) : toastMsg(messages.inActivated, rowData.name),
            open: true
          }));
          dispatch(fetchOrganizations(orgParams));
        }));
      }
    }));
  }

  const onOrgAction = (rowData: any) => {
    return (
      <div className="d-flex align-items-center">
        <Switch size="small" checked={rowData.status} onClick={() => onActiveInActiveOrg(rowData)} />
        {rowData.status && <><span className="px-1" > |</span> <CreateOrg orgData={rowData} /></>}
      </div>
    )
  }

  const onSearchOrg = (e: any) => {
    setSearchVal(e.target.value);
    let _payload = { ...orgParams,search_text:e.target.value, offset_filter: 0}
    dispatch({ type: Types.ORAGANIZATION_PARAMS, payload: _payload });
    dispatch(fetchOrganizations(_payload));
    
  };

  const onPageChange = (event: any) => {
    if ((event.page > 0 || pageClick && event.page == 0) && orgParams.offset_filter != event.first) {
        let _payload = { ...orgParams, offset_filter: event.first }
        dispatch({ type: Types.ORAGANIZATION_PARAMS, payload: _payload });
        dispatch(fetchOrganizations(_payload));
        setpageChange(true);
    }
  }
  
  const onClearSearch = () => {
    setSearchVal('');
    let _payload = { ...orgParams,search_text:"", offset_filter: 0}
    dispatch({ type: Types.ORAGANIZATION_PARAMS, payload: _payload });
   dispatch(fetchOrganizations(_payload));
  };

  return (
    <div className='organization-Dashboard'>
      <div className='d-flex justify-content-end button-Search-div'>
        <div className='search-field'>
          <SearchField
            value={searchVal}
           // emptyMessage="No Organizations To Display."
            placeholder="Search By Organization Name"
            rows={orgParams.search_text}
            onChange={onSearchOrg}
            onClearSearch={onClearSearch}
          />
        </div>
        <div className='button_search_alignment'> <CreateOrg id={0} /> </div>
      </div>

      {allOrganizations &&
        <DataTable
          value={allOrganizations.data}
          emptyMessage="No Organizations To Display."
          lazy
          scrollable
          rows={orgParams.limit_filter}
          paginator={allOrganizations.total_count > orgParams.limit_filter ? true : false}
          totalRecords={allOrganizations.total_count}
          responsiveLayout="scroll"
          rowClassName={rowClassName}
          stripedRows={true}
          first={orgParams.offset_filter}
          onPage={onPageChange}
        >
          <Column field="name" header="Organization" ></Column>
          <Column field="gst" header="GST" ></Column>
          <Column field="pan" header="PAN" ></Column>
          <Column field="city.name" header="City" ></Column>
          <Column field="state.name" header="State" ></Column>
          <Column field="country.name" header="Country" ></Column>
          <Column body={onOrgAction} header='Update'></Column>
        </DataTable>
      }
    </div>
  )
}

export default OrganizationDashboard;