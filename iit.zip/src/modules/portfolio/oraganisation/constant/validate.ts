import * as Yup from "yup";

export const organizationSchema = (organizationDetails: any) => {
    return Yup.object().shape({
        name: Yup.string().required("Please Enter Organization Name").nullable(),
        gst: Yup.string().required("Please Enter GST Number").nullable().min(15,"min 15 digit").max(15,"max 15 digit"),
        // cin: Yup.string().required("Please Enter CIN Number").nullable(),
        // tin: Yup.string().required("Please Enter TIN Number").nullable(),
        pan: Yup.string().required("Please Enter PAN Number").nullable().min(10,"min 10 digit").max(10,"max 10 digit"),
        country_id: Yup.string().required("Please Select Country"),
        state_id: Yup.string().required("Please Select State" ),
        city_id: Yup.string().required("Please Select City" ),
        address: Yup.string().required("Please Enter Address").nullable(),
        phone: Yup.string().required("Please Enter Phone Number").nullable(),
        postal_code: Yup.string().required("Please Enter Postal Code").nullable(),
    })
}