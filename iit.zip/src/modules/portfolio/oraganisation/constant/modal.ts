import { organizationDataTypes } from "./dataTypes";

export const organizationModal : organizationDataTypes ={
    name: '',
    gst:'',
    cin:'',
    tin:'',
    pan:'',
    city_id:'',
    state_id:'',
    country_id:'',
    logo_id:null,
    watermark_id:null,
    address:'',
    phone:'',
    postal_code:'',
    country: null,
    state: null,
    city: null
}