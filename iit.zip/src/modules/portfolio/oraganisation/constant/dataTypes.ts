export type organizationDataTypes ={
    name: string;
    gst:string;
    cin:string;
    tin:string;
    pan:string;
    city_id:any;
    state_id:any;
    country_id:any;
    logo_id:any;
    watermark_id:any;
    address:string;
    phone:string;
    postal_code:string;
    country : any;
    state: any;
    city: any
}