
import { Alert, errHandler, Loader } from "../../../../actions/actions"
import { request } from "../../../../Config/Environment"
import { fetch } from "../../../../constants/fetch"
import { messages } from "../../../../constants/messages"
import { Types } from "../reducer/Types"


//get all organizations

export const fetchOrganizations: Function = (params: any) => {
  let url = `${request.Porfolio.organizationDetails}?offset_filter=${params.offset_filter}&limit_filter=${params.limit_filter}&export=${params.export}&search_text=${params.search_text}`
  return (dispatch: any) => {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: '',
    })
      .then((response: any) => {
        dispatch({ type: Types.GET_ORGANIZATIONS, payload: response.data.result });
        dispatch(Loader(false));
       // console.log(response.data.result)
      })
      .catch((err: any) => {
        dispatch(errHandler('reload'));
      });
  }
}

export const createOrganization: Function = (payload: any, callback: any) => {
  let url = `${request.Porfolio.organizationDetails}`
  return (dispatch: any) => {
    fetch({
      method: 'PUT',
      url: url,
      data: payload,
    })
      .then((response: any) => {
        callback(response.data);
      })
      .catch((err: any) => {
        // dispatch(errHandler());
      })
  }
}

export const updateOrganization: Function = (payload: any, callback: any) => {
  let url = `${request.Porfolio.organizationDetails}`
  return (dispatch: any) => {
    fetch({
      method: 'POST',
      url: url,
      data: payload,
    })
      .then((response: any) => {
        callback(response.data);
      })
      .catch((err: any) => {
      
        dispatch(errHandler());
      })
  }
}


export const activeInactiveOrganization: Function = (orgId: any, callback: Function) => {
  let url = `${request.Porfolio.disableOrganization}`
  return (dispatch: any) => {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: url,
      data: { 'id': orgId },
    })
      .then((response: any) => {
        callback(response.data);
        dispatch(Loader(false));
      })
      .catch((err: any) => {
        dispatch(errHandler());
      })
  }
}

// this api for  Upload Image 
export const uploadDocument: Function = (payload: any, callback: any) => {
  let url = `${request.helpers.uploadImage}`
  return function (dispatch: any) {
    dispatch(Loader(true))
    fetch({
      method: 'PUT',
      url: url,
      data: payload,
      headers: {
        "Accept": "*/*",
        "Content-Type": "multipart/form-data"
      }
    })
      .then((response: any) => {
        if(callback){
          callback(response.data);
        }
        dispatch(Loader(false))
      }).catch((error) => {
      
      })
  }
}
 export const getUploadedImage:Function=(params:any,callback: any)=>{
  let url=`${request.helpers.getUploadedImage}/${params}`
  return function(dispatch:any){
    fetch({
      method:'GET',
      url:url,
      data:params
    })
    .then((response:any)=>{
      let result=response
      callback(response.data)
      // dispatch({type:Types.UPLOADEDIMAGE,payload:result})
    })
    .catch((err:any)=>{

    })
  }

 }
