import { bankingModal } from "../constants/modal"
import { Types } from "./Types"


const initialState = {
  allBankDetails: null,
  bankParams: { offset_filter: 0, limit_filter: 10, export: false, search_text:" " },
  bankDetails: bankingModal
}

export const Banking = (state = initialState, action: { type: any, payload: any }) => {
  switch (action.type) {
    case Types.GET_BANKING_DETAILS:
      return { ...state, allBankDetails: action.payload }

    case Types.SINGLE_BANK_DATA:
      return { ...state, bankDetails: action.payload }

    case Types.BANKING_PARAMS:
      return { ...state, bankParams: action.payload }

    default:
      return { ...state }
  }
}