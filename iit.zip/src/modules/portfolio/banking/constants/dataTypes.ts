export type bankingDataTypes ={
    organization_id: any;
    name:string;
    account_holder_name:string;
    account_number:string;
    branch_code:string;
    ifsc_code:string;
    swift_code:string;
    other_code:string;
    organization:string

}