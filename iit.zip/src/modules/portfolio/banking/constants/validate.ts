import * as Yup from "yup";

export const BankingSchema = (bankDetails: any) => {
    return Yup.object().shape({
        organization_id: Yup.string().required("Please Select Organization").nullable(),
        name: Yup.string().required("Please Enter Bank Name").nullable().min(6,"mustbe min 6"),
        account_number: Yup.string().required("Please Enter Account Number").nullable(),
        account_holder_name: Yup.string().required("Please Enter Account Holder Name").nullable(),
        // branch_code: Yup.string().required("Please Enter Branch Code").nullable(),
        ifsc_code: Yup.string().required("Please Enter IFSC Code"),
        swift_code: Yup.string().required("Please Enter Swift Code")
    })
}