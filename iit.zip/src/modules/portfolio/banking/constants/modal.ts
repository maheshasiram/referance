import { bankingDataTypes } from "./dataTypes";

export const bankingModal : bankingDataTypes ={
    organization_id:'',
    name:'',
    account_holder_name:'',
    account_number:'',
    branch_code:'',
    ifsc_code:'',
    swift_code:'',
    other_code:'',
    organization:''

}