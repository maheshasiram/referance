
import { errHandler, Loader } from "../../../../actions/actions"
import { request } from "../../../../Config/Environment"
import { fetch } from "../../../../constants/fetch"
import { Types } from "../reducers/Types"

export const fetchBankingDetails : Function = (params:any) => {
    let url = `${request.Porfolio.bankingDetails}?offset_filter=${params.offset_filter}&limit_filter=${params.limit_filter}&export=${params.export}&search_text=${params.search_text}`
    return (dispatch:any) => {
      dispatch(Loader(true));

      fetch({
        method: 'GET',
        url: url,
        data:params,
      })
        .then((response:any) => {
         dispatch({type:Types.GET_BANKING_DETAILS, payload:response.data.result}); 
         dispatch(Loader(false));
        })
        .catch((err:any)=>{
          dispatch(errHandler('reload'));
        })
    }
  }


  export const createBanking: Function = (params:any,callback:any) => {

    let url = `${request.Porfolio.bankingDetails}`
    return (dispatch:any) => {
      fetch({
        method: 'PUT',
        url: url,
        data:params,
      })
        .then((response:any) => {

          //dispatch(fetchBankingDetails())
          callback(response.data)
        })
        .catch((err:any)=>{
         alert(err)
        })
    }
  }

  export const editBanking: Function = (params:any,callback:any) => {

    let url = `${request.Porfolio.bankingDetails}`
    return (dispatch:any) => {
      fetch({
        method: 'POST',
        url: url,
        data:params,
      })
        .then((response:any) => {
          //dispatch(fetchBankingDetails())
          callback(response.data)
        })
        .catch((err:any)=>{
        alert(err)
        })
    }
  }

  export const disableBanking: Function = (bankId: any, callback: Function) => {
    
    let url = `${request.Porfolio.disableBanking}`
    return (dispatch:any) => {
      fetch({
        method: 'POST',
        url: url,
        data:{ 'id': bankId },
      })
        .then((response:any) => {

       callback(response.data)
          
        })
        .catch((err:any)=>{
  
        })
    }
  }