import React, { useEffect } from 'react'
import { useDispatch, useSelector } from "react-redux";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Confirm, getOrganizationsDropdown, toastAlert, rowClassName } from '../../../actions/actions';
import CreateBanking from './CreateBanking';
import { disableBanking, fetchBankingDetails } from './actions/actions';
import Switch from '@mui/material/Switch';
import { Dialog } from 'primereact/dialog';
import { messages } from '../../../constants/messages';
import { toastMsg, confirmMsg } from '../../../common/Messages';
import { Button } from 'primereact/button';
import SearchField from '../../../common/SearchField';
import { Types } from './reducers/Types';

function BankingDashboard(props: any) {

  const dispatch = useDispatch();
  const { allBankDetails, bankParams } = useSelector((state: any) => state.Banking);
  // const [deleteBankDialog, setDeleteBankDialog] = React.useState(false);
  // const [BankStatus, setBankStatus] = React.useState(false)
  // const [bankId, setBankId] = React.useState(null)
  const loaded = React.useRef(false);
  const [searchVal, setSearchVal] = React.useState('');
  const [pageClick, setpageChange] = React.useState(false); 

  useEffect(() => {
    dispatch(getOrganizationsDropdown())
    if (!loaded.current) {
      dispatch(fetchBankingDetails(bankParams));
      loaded.current = true;
    }
  }, []);

  const onSearchBank = (e: any) => {
    setSearchVal(e.target.value);
    let _payload = { ... bankParams,search_text:e.target.value, offset_filter: 0}
    dispatch({ type: Types. BANKING_PARAMS, payload: _payload });
    dispatch(fetchBankingDetails(_payload));
  };

  const onActiveInActiveBank = (rowData: any) => {
    dispatch(Confirm({
      status: 0,
      message: rowData.status ? confirmMsg(messages.inActive, rowData.name) : confirmMsg(messages.active, rowData.name),
      onOk: () => {
        dispatch(disableBanking(rowData.id, (response: any) => {
          dispatch(toastAlert({
            status: response.status == "success" ? 1 : 0,
            message: rowData.status ? toastMsg(messages.activated, rowData.name) : toastMsg(messages.inActivated, rowData.name),
            open: true
          }));
          dispatch(fetchBankingDetails(bankParams));
        }));
      }
    }));
  }

  const bankingAction = (rowData: any) => {
    return (
      <div className="d-flex align-items-center">
        <Switch size="small" checked={rowData.status} onClick={() => onActiveInActiveBank(rowData)} />
        {rowData.status && <><span className="px-1" > |</span> <CreateBanking bankData={rowData} /></>}
      </div>
    )
  }

  const onPageChange = (event: any) => {
    if ((event.page > 0 || pageClick && event.page == 0) && bankParams.offset_filter != event.first) {
        let _payload = { ...bankParams, offset_filter: event.first }
        dispatch({ type: Types.BANKING_PARAMS, payload: _payload });
        dispatch(fetchBankingDetails(_payload));
        setpageChange(true);
    }
  }

  const onClearSearch = () => {
    setSearchVal('');
    let _payload = { ...bankParams,search_text:"", offset_filter: 0}
    dispatch({ type: Types.BANKING_PARAMS, payload: _payload });
   dispatch(fetchBankingDetails(_payload));
  };

  return (
    <div className='organization-Dashboard'>
      <div className='d-flex justify-content-end button-Search-div'>
        <div className='search-field'>
          <SearchField
            value={searchVal}
           // emptyMessage="No Bank Details To Display."
            placeholder="Search By Bank Name"
            onChange={onSearchBank}
            rows={ bankParams.search_text}
            onClearSearch={onClearSearch}
          />
        </div>
        <div className='button_search_alignment'> <CreateBanking id={0} /> </div>
      </div>

      {allBankDetails &&
        <DataTable
          value={allBankDetails.data}
          emptyMessage="No Bank Details To Display."
          lazy
          scrollable
          rows={bankParams.limit_filter}
          paginator={allBankDetails.total_count > bankParams.limit_filter ? true : false}
          totalRecords={allBankDetails.total_count}
          responsiveLayout="scroll"
          rowClassName={rowClassName}
          stripedRows={true}
          first={bankParams.offset_filter}
          onPage={onPageChange}
        >
          <Column field="name" header="Bank Name" ></Column>
          <Column field="account_holder_name" header="Account Name" ></Column>
          <Column field="account_number" header="Account Number" ></Column>
          <Column field="branch_code" header="Branch Code" ></Column>
          <Column field="ifsc_code" header="IFSC Code" ></Column>
          <Column field="swift_code" header="Swift Code" ></Column>
          <Column field="other_code" header="Other Code" ></Column>
          <Column body={bankingAction} header='Update'></Column>
        </DataTable>
      }
    </div>
  )
}

export default BankingDashboard;