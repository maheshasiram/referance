import React, { useEffect, useState } from 'react';
import * as Yup from 'yup';
import { Formik, Field, Form, FormikHelpers, ErrorMessage } from 'formik';
import { useDispatch, useSelector } from 'react-redux';
import CustomDialog from '../../../common/modals/CustomeDialog';
import { bankingDataTypes } from "./constants/dataTypes";
import EditIcon from '@mui/icons-material/Edit';
import SelectComponent from '../../../common/SelectComponent';
import { createBanking, editBanking, fetchBankingDetails } from './actions/actions';
import { Types } from "../banking/reducers/Types"
import { bankingModal } from './constants/modal';
import './style.scss';
import { BsBank } from 'react-icons/bs';
import { handleClose,toastAlert } from '../../../actions/actions';
import _ from 'lodash';
import { BankingSchema } from './constants/validate';

function CreateBanking(props: any) {

    const dispatch = useDispatch();
    const { bankDetails,bankParams } = useSelector((state: any) => state.Banking);
    const { organizationsDropdown } = useSelector((state: any) => state.application);
    const { bankData, id } = props;
    const [error, setError] = useState('');
    const [btnDisable, setBtnDisable] = useState(true);
    const [open, setOpen] = React.useState(false);
    const [organizations, Setorganizations] = React.useState([]);

    // let orgArr: any = []


    const onOrganizationSelect = (e: any, setFieldValue: any, setFieldTouched: any) => {
        setBtnDisable(false)
        setFieldTouched('organization_id', true)
        setFieldValue('organization_id', e?.value)
    };

    const onOpenBankForm = (type: string) => {
      
        if (type == "add") {
           
            dispatch({ type: Types.SINGLE_BANK_DATA, payload: bankingModal })
        }else {
            let _bankData = _.cloneDeep(props.bankData);
            _bankData.organization = { 'label': _bankData.organization, 'value': _bankData.organization_id }
            dispatch({ type: Types.SINGLE_BANK_DATA, payload: _bankData })
        }
        setBtnDisable(true);
        // Setorganizations(orgArr)
        setOpen(true);
    };

    const onInputChangeHandler = (e: any, setFieldValue: any) => {
        setBtnDisable(false);
        setFieldValue(e.target.name, e.target.value);
        // setError('');
    }

    const onSubmitBank = (values: any) => {
        if (props.bankData) {
           values.organization = values.organization.label
            dispatch(editBanking(values,(response:any)=>{
                if(response.status === 'success'){
                    dispatch(fetchBankingDetails(bankParams));
                    console.log("Bank updated successfully")
                    dispatch(toastAlert({
                        status: 1,
                        message: 'Bank Updated Successfully',
                        open: true
                    }));
                }
            })) 
        }  
        
        else {
            dispatch(createBanking(values,(response:any)=>{
                if(response.status === 'success'){
                    dispatch(fetchBankingDetails(bankParams));
                    console.log("bank created successfully")
                    dispatch(toastAlert({
                        status: 1,
                        message: 'Bank Created Successfully',
                        open: true
                    }));
                }
               
            }))
           //dispatch(createBanking(values))
        }
        setOpen(false);
    };

    return (
        <React.Fragment>
            <div className='d-flex justify-content-end'>
                {id == 0 ?
                    <button className='btn-eprimary my-2' onClick={() => onOpenBankForm('add')}> Create Bank</button>
                    : <EditIcon sx={{ fontSize: 17, opacity: 0.8 }} onClick={() => onOpenBankForm('edit')} />
                }
            </div>

            {open && <CustomDialog
                open={open}
                titleIcon={<BsBank style={{ paddingBottom: '0.25rem' }} />}
                maxWidth={'md'}
                fullWidth={true}
                title={!bankData ? 'Create Bank' : 'Update Bank'}
                onClose={() => handleClose(setOpen)}
                actionType={!bankData ? 'Submit' : 'Update'}
                form={'addOrEditbank'}
                disabled={btnDisable}
            >
                <div className="header-container">
                    <p className="text-center text-danger">{error}</p>
                </div>

                <Formik
                    enableReinitialize={true}
                    initialValues={bankDetails}
                    validationSchema={BankingSchema(bankDetails)}
                    onSubmit={(values: any) => {
                        onSubmitBank(values)
                    }}
                >
                    {({ errors, touched, values, setFieldValue, setFieldTouched }) => (
                        <Form id='addOrEditbank'>
                            <section className='d-flex'>
                                <div className='sectionHeader'>Organization</div>
                                <div className='field section-contant account'>
                                    <div className='d-flex sectionField'>
                                        <label htmlFor="organization"> Organization name:<span className='text-danger mx-1'>*</span></label>
                                        <SelectComponent
                                            id={"organization_id"}
                                            className="form-control"
                                            defaultValue={values.organization}
                                            isClearable={true}
                                            isSearchable={true}
                                            name={"organization_id"}
                                            options={organizationsDropdown}
                                            placeholder={"Select Organization"}
                                            onChange={(e: any) => onOrganizationSelect(e, setFieldValue, setFieldTouched)}
                                        />
                                    </div>
                                    {errors.organization_id && touched.organization_id ? <div className='errMsg'><ErrorMessage name={`organization_id`} /></div> : <span>&nbsp;</span>}
                                </div>
                            </section>
                            <hr className='m-0'></hr>
                            <section className='mt-1 d-flex'>
                                <div className='sectionHeader'>Bank Details</div>
                                <div className='section-contant'>
                                    <div className='d-flex section-Fields'>
                                        <div className='field w-50'>
                                            <div className='sectionField'>
                                                <label htmlFor="bank" className='w-label'> Bank Name:<span className='text-danger mx-1'>*</span></label>
                                                <Field placeholder='Enter Bank Name' className="form-control" name="name"
                                                    value={values.name}
                                                    onChange={(e: any) => {
                                                        onInputChangeHandler(e, setFieldValue);
                                                    }}
                                                />
                                            </div>
                                            {errors.name && touched.name ? <div className='errMsg'><ErrorMessage name={`name`} /></div> : <span>&nbsp;</span>}
                                        </div>
                                        <div className='field w-50'>
                                            <div className='sectionField'>
                                                <label htmlFor="account_number" className='w-label'> Account Number :<span className='text-danger mx-1'>*</span></label>
                                                <Field placeholder='Enter Account Number' className="form-control" name="account_number"
                                                    value={values.account_number}
                                                    onChange={(e: any) => {
                                                        onInputChangeHandler(e, setFieldValue);
                                                    }}
                                                />
                                            </div>
                                            {errors.account_number && touched.account_number ? <div className='errMsg'><ErrorMessage name={`account_number`} /></div> : <span>&nbsp;</span>}
                                        </div>
                                    </div>
                                    <div className='d-flex section-Fields'>
                                        <div className='field w-50'>
                                            <div className='sectionField'>
                                                <label htmlFor="account_holder_name" className='w-label'> Account Holder Name :<span className='text-danger mx-1'>*</span></label>
                                                <Field placeholder='Enter Account Holder Name' className="form-control" name="account_holder_name"
                                                    value={values.account_holder_name}
                                                    onChange={(e: any) => {
                                                        onInputChangeHandler(e, setFieldValue);
                                                    }}
                                                />
                                            </div>
                                            {errors.account_holder_name && touched.account_holder_name ? <div className='errMsg'><ErrorMessage name={`account_holder_name`} /></div> : <span>&nbsp;</span>}
                                        </div>
                                        <div className='field w-50'>
                                            <div className='sectionField'>
                                                <label htmlFor="branch_code" className='w-label'> Branch Code :<span className='text-danger mx-1'></span></label>
                                                <Field placeholder='Enter Branch Code' className="form-control" name="branch_code"
                                                    value={values.branch_code}
                                                    onChange={(e: any) => {
                                                        onInputChangeHandler(e, setFieldValue);
                                                    }}
                                                />
                                            </div>
                                            {/* {errors.branch_code && touched.branch_code ? <div className='errMsg'><ErrorMessage name={`branch_code`} /></div> : <span>&nbsp;</span>} */}
                                        </div>
                                    </div>
                                    <div className='d-flex section-Fields'>
                                        <div className='field w-50'>
                                            <div className='sectionField'>
                                                <label htmlFor="ifsc_code" className='w-label'> IFSC Code :<span className='text-danger mx-1'>*</span></label>
                                                <Field placeholder='Enter IFSC Code' className="form-control" name="ifsc_code"
                                                    value={values.ifsc_code}
                                                    onChange={(e: any) => {
                                                        onInputChangeHandler(e, setFieldValue);
                                                    }}
                                                />
                                            </div>
                                            {errors.ifsc_code && touched.ifsc_code ? <div className='errMsg'><ErrorMessage name={`ifsc_code`} /></div> : <span>&nbsp;</span>}
                                        </div>
                                        <div className='field w-50'>
                                            <div className='sectionField'>
                                                <label htmlFor="swift_code" className='w-label'> Swift Code :<span className='text-danger mx-1'>*</span></label>
                                                <Field placeholder='Enter Swift Code' className="form-control" name="swift_code"
                                                    value={values.swift_code}
                                                    onChange={(e: any) => {
                                                        onInputChangeHandler(e, setFieldValue);
                                                    }}
                                                />
                                            </div>
                                            {errors.swift_code && touched.swift_code ? <div className='errMsg'><ErrorMessage name={`swift_code`} /></div> : <span>&nbsp;</span>}
                                        </div>
                                    </div>
                                    <div className='d-flex section-Fields'>
                                        <div className='field w-100 mb-3'>
                                            <div className='sectionField'>
                                                <label htmlFor="other_code" className='w-label'> Other Code :</label>
                                                <Field placeholder='Enter Other Code' className="form-control" name="other_code"
                                                    value={values.other_code}
                                                    onChange={(e: any) => {
                                                        onInputChangeHandler(e, setFieldValue);
                                                    }}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </Form>
                    )}
                </Formik>
            </CustomDialog>}
        </React.Fragment>
    );
}



export default CreateBanking;