import _ from "lodash";
import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useNavigate } from "react-router";
import { getInvoiceCustomer, getInvoiceOrganization,rowClassName  } from "../../../actions/actions";
import { Types } from "../../../constants/Types";
import { fetchAllQuotations } from "./actions/actions";
import { Types as quotationTypes } from "../domestic/reducer/Types";
import FileCopyOutlinedIcon from '@mui/icons-material/FileCopyOutlined';
import EditIcon from '@mui/icons-material/Edit';
import Tooltip from '@mui/material/Tooltip';


function QuotationDasboard() {
    const navigate = useNavigate()
    const dispatch = useDispatch();
    const { allQuotationDetails, quotationParams } = useSelector((state: any) => state.DomesticQuotation)
    const [pageClick, setpageChange] = React.useState(false);


    const onPreviewPdf = (rowData: any) => {
        dispatch(getInvoiceCustomer(rowData.customer.id, (response: any) => {
            dispatch({ type: Types.INVOICE_CUSTOMER, payload: response.result.data[0] });
        }))

        dispatch(getInvoiceOrganization(rowData.organization.id, (response: any) => {
            dispatch({ type: Types.INVOICE_ORGANIZATION, payload: response.result.data[0] });
        }))



        dispatch({ type: quotationTypes.QUOTATION_DETAILS, payload: rowData });

        setTimeout(() => {
            navigate('/viewquotation')
        }, 1000);

    }

    useEffect(() => {
        dispatch(fetchAllQuotations(quotationParams))
    }, []);

    const onPageChange = (event: any) => {
        if ((event.page > 0 || pageClick && event.page == 0) &&  quotationParams.offset_filter != event.first) {
          let _payload = { ... quotationParams, offset_filter: event.first }
          dispatch({ type: quotationTypes.QUOTATION_PARAMS, payload: _payload });
          dispatch(fetchAllQuotations(_payload));
          setpageChange(true);
        }
      }


    const editQuotation = (rowData: any) => {

        console.log(rowData)
        let _rowData = _.cloneDeep(rowData);
        _rowData.organization = { "label": _rowData.organization.name, "value": _rowData.organization.id };
        _rowData.organization_id = rowData.organization.id;
        _rowData.customer = { "label": _rowData.customer.name, "value": _rowData.customer.id };
        _rowData.customer_id = rowData.customer.id;
        // _rowData.bank = {"label":_rowData.banking.name,"value":_rowData.banking.id}
        // _rowData.banking_id = rowData.banking.id

        _rowData.items.map((item: any, index: any) => {
            _rowData.items[index].itemName = { "label": _rowData.items[index].item, "value": 4 }
        })


        dispatch({ type: quotationTypes.DOMESTIC_QUOTATION_DATA, payload: _rowData });
        navigate(`/domesticQuotation/${rowData.id}`)




    }

    const onPreviewAction = (rowData: any) => {
        return (
            <div className="d-flex align-items-center">

                <Tooltip title="Edit">
                    < EditIcon onClick={() => editQuotation(rowData)} />
                </Tooltip>


                <span>|</span>

                <Tooltip title="Preview & Download">
                    <FileCopyOutlinedIcon onClick={() => onPreviewPdf(rowData)} />
                </Tooltip>

            </div>
        )
    }

    return (
        <React.Fragment>
            <div>QUOTATIONS</div>
            {allQuotationDetails &&
            <DataTable
                value={allQuotationDetails.data}
                emptyMessage="No Organizations To Display."
                lazy
                scrollable
                rows={quotationParams.limit_filter}
                paginator={allQuotationDetails.total_count > quotationParams.limit_filter ? true : false}
                totalRecords={allQuotationDetails.total_count}
                first={quotationParams.offset_filter}
                responsiveLayout="scroll"
                 rowClassName={rowClassName}
                stripedRows={true}
                 onPage={onPageChange}

            >
                <Column field="quotation_date" header="Quotation Date" ></Column>
                <Column field="quotation_number" header="Quotation" ></Column>
                <Column field="po_number" header="Order Number" ></Column>
                <Column field="customer.name" header="customer" ></Column>
                <Column field="total_amount" header="Amount" ></Column>
                <Column field="type" header="Type" ></Column>
                <Column body={onPreviewAction} header='Action'></Column>
            </DataTable>
            }
        </React.Fragment>
    )
}

export default QuotationDasboard;