
import { Alert, errHandler, Loader } from "../../../../actions/actions"
import { request } from "../../../../Config/Environment"
import { fetch } from "../../../../constants/fetch"
import { messages } from "../../../../constants/messages"
import { Types } from "../reducer/Types"


export const fetchAllQuotations : Function = (params:any) => {
    let url = `${request.quotation.createAndGetQuotation}?offset_filter=${params.offset_filter}&limit_filter=${params.limit_filter}&export=${params.export}`
    return (dispatch:any) => {
      dispatch(Loader(true));
  
      fetch({
        method: 'GET',
        url: url,
        data:params,
      })
        .then((response:any) => {
         dispatch({type:Types.GET_ALL_QUOTATIONS, payload:response.data.result}); 
         dispatch(Loader(false));
        })
        .catch((err:any)=>{
          dispatch(errHandler('reload'));
        })
    }
  }
  
  export const getQuotationNumber : Function = (params:any,callback:any) => {
    console.log(params)
    let url = `${request.quotation.getQuotationNumber}`
    return (dispatch:any) => {
      dispatch(Loader(true));
  
      fetch({
        method: 'Post',
        url: url,
        data:params,
      })
        .then((response:any) => {
          dispatch({type:Types.QUOTATION_NUMBER, payload:response.data.result.quotation_number}); 
         dispatch(Loader(false));
        })
        .catch((err:any)=>{
          dispatch(errHandler('reload'));
        })
    }
  }
  
  export const createQuotation : Function = (params:any,callback:any) => {
    console.log(params)
    let url = `${request.quotation.createAndGetQuotation}`
    return (dispatch:any) => {
      dispatch(Loader(true));
  
      fetch({
        method: 'PUT',
        url: url,
        data:params,
      })
        .then((response:any) => {
          // dispatch({type:Types.QUOTATION_NUMBER, payload:response.data.result.quotation_number}); 
         callback(response.data)
         dispatch(Loader(false));
        })
        .catch((err:any)=>{
          dispatch(errHandler('reload'));
        })
    }
  }
  
  
  export const addQuotationItems: Function = (params: any) => {
  
    let url = `${request.quotation.addQuotationItems}`
    return (dispatch: any) => {
      dispatch(Loader(true));
      fetch({
        method: 'PUT',
        url: url,
        data: params,
      })
        .then((response: any) => {
  
         fetchAllQuotations()
          dispatch(Loader(false));
  
        })
        .catch((err: any) => {
  
        })
    }
  }
  
  
  export const updateQuotation : Function = (params:any,callback:any) => {
    console.log(params)
    let url = `${request.quotation.createAndGetQuotation}`
    return (dispatch:any) => {
      dispatch(Loader(true));
  
      fetch({
        method: 'POST',
        url: url,
        data:params,
      })
        .then((response:any) => {
          // dispatch({type:Types.QUOTATION_NUMBER, payload:response.data.result.quotation_number}); 
         callback(response.data)
         dispatch(Loader(false));
        })
        .catch((err:any)=>{
          dispatch(errHandler('reload'));
        })
    }
  }
  
  
  export const updateQuotationItems: Function = (params: any) => {
  
    let url = `${request.quotation.updateQuotationItems}`
    return (dispatch: any) => {
      dispatch(Loader(true));
      fetch({
        method: 'POST',
        url: url,
        data: params,
      })
        .then((response: any) => {
  
         fetchAllQuotations()
          dispatch(Loader(false));
  
        })
        .catch((err: any) => {
  
        })
    }
  }

