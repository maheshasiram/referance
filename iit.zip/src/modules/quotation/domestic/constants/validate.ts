import * as Yup from "yup";

export const DomesticQuotationSchema = (DomesticDetails: any) => {
    return Yup.object().shape({
        organization_id: Yup.string().required("Please Select organization Name").nullable(),
        customer_id: Yup.string().required("Please Select Customer ").nullable(),
        po_number: Yup.string().required("Please Enter Purchase Order Number").nullable(),
        po_date: Yup.string().required("Please Enter Purchase Order Date").nullable().max(10,'Invalid Date '),
        quotation_number: Yup.string().required("Please Enter Quotation Number ").nullable(),
        quotation_date: Yup.string().required("Please Select Quotation Number ").nullable().max(10,'Invalid Date '),
        //credit_period: Yup.string().required("Please Enter Credit Period" )   
        items: Yup.array().of(Yup.object().shape({
            item: Yup.string()
                .required('Please Enter Activity').nullable(),
            description: Yup.string()
                .required('Please Enter Description').nullable(),
            quantity: Yup.string()
                .required('Please Enter Quantity').nullable(),
            rate: Yup.string()
                .required('Please Enter Rate').nullable(),
            discount: Yup.string()
                .required('Please Enter Discount').nullable()            
        }))
       
})
}