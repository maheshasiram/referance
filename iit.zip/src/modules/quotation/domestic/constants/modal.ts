import { domesticQuotationDataTypes } from "./dataTypes";
import moment from 'moment';


export const domesticQuotationModal: domesticQuotationDataTypes = {
  organization: "",
  customer: "",
  organization_id: "",
  customer_id: "",
  quotation_number: "",
  po_number: "",
  po_date: "",
  quotation_date: moment().format("YYYY-MM-DD"),
  items: [{
    item: "",
    description: "",
    quantity: "",
    rate: "",
    amount: "",
    hsn_code: "",
    discount: "",
    discount_type: "pct",
    cgst: "",
    sgst: "",
    igst: 0,
    save: false,
    cgst_amount: "",
    sgst_amount: "",
    igst_amount: 0,
    sub_total_amount: ""
  },],
  total_sgst_amount: 0.0,
  total_cgst_amount: 0.0,
  total_igst_amount: 0.0,
  total_amount: 0.0,
  customer_notes: "",
  type: "domestic",
}