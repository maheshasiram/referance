export type domesticQuotationDataTypes ={
    customer: any;
    organization:string,
    organization_id: string;
    customer_id:string;
    quotation_number:string;
    po_number:string;
    po_date:any;
    quotation_date:any;
    items:any;
    total_sgst_amount:any;
    total_cgst_amount:any;
    total_igst_amount:any;
    total_amount:any;
    customer_notes:string;
    type:string
 
   

}