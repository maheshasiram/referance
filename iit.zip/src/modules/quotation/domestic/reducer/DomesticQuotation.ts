import { domesticQuotationModal } from "../constants/modal"
import { Types } from "./Types"

const initialState = {
    quotationDetails:{},
    allQuotationDetails: null,
    quotationParams: { offset_filter: 0, limit_filter: 5, export: false },
    quotationNumber: '',
    domesticQuotationData: domesticQuotationModal,
}

export const DomesticQuotation = (state = initialState, action: { type: any, payload: any }) => {
  switch (action.type) {

    case Types.QUOTATION_DETAILS:
      return { ...state, quotationDetails: action.payload }

    case Types.GET_ALL_QUOTATIONS:
      return { ...state, allQuotationDetails: action.payload }

    case Types.QUOTATION_PARAMS:
      return { ...state, quotationParams: action.payload }

    case Types.QUOTATION_NUMBER:
      return { ...state, quotationNumber: action.payload }

    case Types.DOMESTIC_QUOTATION_DATA:
      return { ...state, domesticQuotationData: action.payload }

    
    default:
      return { ...state }
  }
}