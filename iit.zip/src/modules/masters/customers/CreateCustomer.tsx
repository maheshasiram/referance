import * as React from 'react';
import * as Yup from 'yup';
import  { useEffect } from 'react'
import { Formik, Field, Form, FormikHelpers, ErrorMessage } from 'formik';
import { useDispatch, useSelector } from 'react-redux';
import CustomDialog from '../../../common/modals/CustomeDialog';
import SelectComponent from '../../../common/SelectComponent';
import _ from "lodash";
import { createCustomer, fetchCustomerDetails, getCurrency, updateCustomer, uploadAggrement, } from './actions/CustomerActions';
import { Types } from './reducer/Types';
import { customerModal } from './constants/modal';
import { CustomerSchema } from './constants/validate';
import "./styles.scss";
import { getCitiesByState, getCountries, getStatesByCountry, handleClose,toastAlert } from '../../../actions/actions';
import { NavLink, useNavigate } from 'react-router-dom';
import BreadCrumbs from '../../../common/breadCrumbs/BreadCrumbs';
import CommonCard from '../../../common/CommonCard';
import { customers } from './reducer/Customers';


function CreateCustomer(props: any) {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const { countriesDropdown, citiesDropdown, statesDropdown } = useSelector((state: any) => state.application);
    const { currency, customerParams,customer } = useSelector((state: any) => state.customers);
    const [btnDisabled ,setBtnDisable]=React.useState(true)
    const [uploadImgErr, setUploadImgErr] = React.useState('');
    const [countries, setCountries] = React.useState([]);
    const [currencySymbol, setCurrencySymbol] = React.useState([]);
    const [phoneCode, setPhoneCode] = React.useState('');

    useEffect(() => {
         dispatch(getCountries())
         dispatch(getCurrency())
         if(customer.id){
            setCurrencySymbol(customer.currency.symbol)
            setPhoneCode(customer.phoneCode)

         }
      }, []);
    

    const onSubmitCustomer = (values: any) => {
        let _values = _.cloneDeep(values);
        var formData = new FormData();
        formData.append("file_type", 'aggrement');
        formData.append("file", _values.file);
        console.log(values)
        if (_values.file) {
            dispatch(uploadAggrement(formData, (response: any) => {
              
                if (response.status == "success") {
                    _values.aggrement_id = response.result.id
                   
                }
            }));
        } 
        delete _values.file;
        dispatch((!_values.id ? createCustomer : updateCustomer)(_values, (response: any) => {
            if (response.status == 'success') {
                dispatch(fetchCustomerDetails(customerParams));
                console.log("update customer",response.message)
                var msg=(response.message=="Data Inserted")? 'Customer Created Successfully': 'Customer Updated Successfully'
                dispatch(toastAlert({
                    status: 1,
                    message: msg,
                    open: true
                }));
            }
        }));
        navigate(`/customers`);
    }

    const onFileUpload = (event: any, setFieldValue: any,) => {
        setFieldValue("file", event.currentTarget.files[0]);
        var formData = new FormData();
        formData.append("file_type", 'aggrement');
        formData.append("file", event.currentTarget.files[0]);
        dispatch(uploadAggrement(formData, (aggrement_id: any) => {
            setFieldValue("aggrement_id", aggrement_id);

        }));
    };

    const onCountrySelect = (e: any, setFieldValue: any, setFieldTouched: any) => {
        setBtnDisable(false);
        setFieldValue('country_id', e?.value ? e.value : null);
        setPhoneCode(e?.phoneCode ? e?.phoneCode : '');
        setFieldTouched('country_id', true);
        if (e?.value) {
            dispatch(getStatesByCountry(e.value));
        }
    }

    const onStateSelect = (e: any, setFieldValue: any) => {
        setBtnDisable(false);
        setFieldValue('state_id', e?.value ? e.value : '');
        if (e?.value) {
            dispatch(getCitiesByState(e.value));
        }
    }

    const onCitySelect = (e: any, setFieldValue: any) => {
        setBtnDisable(false);
        setFieldValue('city_id', e?.value ? e.value : '');
    }

    const onCurrencyChangeHandler = (e: any, setFieldValue: any, setFieldTouched: any) => {
        let selectedCurrency = e.target.value;
        let _item = currency.filter((item: any) => item.id == selectedCurrency);
        console.log(_item)
        setCurrencySymbol(_item[0].symbol)
        setBtnDisable(false);
        setFieldTouched('currency_id', true);
        setFieldValue('currency_id', selectedCurrency);
         setPhoneCode(e?.phoneCode ? e?.phoneCode : '');
    }

    const onInputChangeHandler = (e: any, setFieldValue: any) => {
        setBtnDisable(false);
        setFieldValue(e.target.name, e.target.value);
        // setError('');
    }

    const backToCustomers = () => {
        navigate(`/customers`);
    }

    return (
        <React.Fragment>
            <BreadCrumbs crumbs={[{ title: 'Masters' }, { title: 'Customers', path: '/customers' }, { title: 'Create Customers' }]} />
            <CommonCard>
                <Formik
                    initialValues={customer}
                    enableReinitialize={true}
                     validationSchema={ CustomerSchema (customers)}
                    onSubmit={(values: any) => {
                        onSubmitCustomer(values);
                    }}
                >
                    {({ values, errors, touched, setFieldValue, setFieldTouched }) => (
                        <Form id='createCustomer'>
                            <section>
                                <div className='sectionHeader'>Customer Type</div>
                                <hr className='m-0'></hr>
                                <div className='field section-contant account'>
                                    <div className='d-flex mt-2'>
                                        <label htmlFor="trade"> Trade:<span className='text-danger mx-1'>*</span></label>
                                        <div className='form-check form-check-inline ml-2'>
                                            <Field type="radio" id="trade" className='form-check-input' name="trade" value="domestic" />
                                            <label className='form-check-label' htmlFor='trade' >Domestic</label>
                                        </div>
                                        <div className="form-check form-check-inline">
                                            <Field type="radio" name="trade" value="export" id="export" className='form-check-input' />
                                            <label className="form-check-label" htmlFor="export">Export</label>
                                        </div>
                                    </div>
                                    {errors.trade && touched.trade ? <div className='errMsg'><ErrorMessage name={`trade`} /></div> : <span>&nbsp;</span>}
                                </div>
                            </section>

                            <section>
                                <div className='sectionHeader'>Customer Details</div>
                                <hr className='m-0'></hr>
                                <div className='section-contant'>
                                    <div className='d-flex section-Fields'>
                                        <div className='field'>
                                            <div className='sectionField'>
                                                <label htmlFor="name" className='w-label'> Customer name<span className='text-danger mx-1'>*</span></label>
                                                <Field placeholder='Enter Customer Name' className="form-control" name="name"
                                                    value={values.name}
                                                    onChange={(e: any) => {
                                                        onInputChangeHandler(e, setFieldValue);
                                                    }}
                                                />


                                            </div>
                                            {errors.name && touched.name ? <div className='errMsg'><ErrorMessage name={`name`} /></div> : <span>&nbsp;</span>}
                                        </div>
                                        <div className='field'>
                                            <div className='sectionField'>
                                                <label htmlFor="GSTin" className='w-label'> GSTIN<span className='text-danger mx-1'>*</span></label>
                                                <Field placeholder='Enter GSTIN Number' className="form-control" name="gst"
                                                    value={values.gst}
                                                    onChange={(e: any) => {
                                                        onInputChangeHandler(e, setFieldValue);
                                                    }}
                                                />
                                            </div>
                                            {errors.gst && touched.gst ? <div className='errMsg'><ErrorMessage name={`gst`} /></div> : <span>&nbsp;</span>}
                                        </div>
                                        <div className='field'>
                                            <div className='sectionField mb-3'>
                                                <label htmlFor="tin" className='w-label'> TIN<span className='text-danger mx-1'></span></label>
                                                <Field placeholder='Enter TIN Number' className="form-control" name="tin"
                                                    value={values.tin}
                                                    onChange={(e: any) => {
                                                        onInputChangeHandler(e, setFieldValue);
                                                    }}
                                                />
                                            </div>
                                            {/* {errors.tin && touched.tin ? <div className='errMsg'><ErrorMessage name={`tin`} /></div> : <span>&nbsp;</span>} */}
                                        </div>
                                    </div>
                                </div>
                            </section>

                            <section>
                                <div className='sectionHeader'>Credit Details</div>
                                <hr className='m-0'></hr>
                                <div className='section-contant'>
                                    <div className='d-flex section-Fields'>
                                        <div className='field'>
                                            <div className='sectionField'>
                                                <label htmlFor="credit_period" className='w-label'>Credit Period<span className='text-danger mx-1'>*</span></label>
                                                <div className="p-inputgroup">
                                               
                                                <span >
                                                <Field placeholder='Enter Credit Period' className="form-control" name="credit_period"
                                                    value={values.credit_period}
                                                    onChange={(e: any) => {
                                                        onInputChangeHandler(e, setFieldValue);
                                                    }}
                                                />
                                                </span>
                                                <span className="p-inputgroup-addon" style={{width: 'auto',height:"33px"}} > days</span>
                                                </div>
                                            </div>
                                            {errors.credit_period && touched.credit_period ? <div className='errMsg'><ErrorMessage name={`credit_period`} /></div> : <span>&nbsp;</span>}
                                        </div>
                                        <div className='field'>
                                            <div className='sectionField'>
                                                <label className="sr-only" htmlFor="currency_id">Currency <span className='text-danger mx-1'>*</span></label>
                                                <div className="p-inputgroup">
                                                    <span className="p-inputgroup-addon">{currencySymbol}</span>
                                                    <span className="p-inputgroup-addon">
                                                        <select style={{ width: 'auto' }}

                                                            className="form-select form-select-sm"
                                                            aria-label=".form-select-sm example"
                                                            defaultValue={values.currency_id}
                                                            onChange={(e) => {
                                                                onCurrencyChangeHandler(e, setFieldValue, setFieldTouched);
                                                            }} >
                                                            {currency.map((item: any, index: number) => (<option key={index} value={item.id}>{item.code}</option>))}
                                                        </select>
                                                    </span>
                                                </div>

                                            </div>
                                            {errors.currency_id && touched.currency_id ? <div className='errMsg'><ErrorMessage name={`currency_id`} /></div> : <span>&nbsp;</span>}
                                        </div>
                                        <div className='field'>
                                            <div className='sectionField'>
                                                <label htmlFor="aggrement_start_date" className='w-label'> Aggrement Start Date<span className='text-danger mx-1'>*</span></label>
                                                <Field placeholder='Enter GSTIN Number' className="form-control" name="aggrement_start_date"
                                                    type="date"
                                                    value={values.aggrement_start_date}
                                                    onChange={(e: any) => {
                                                        onInputChangeHandler(e, setFieldValue);
                                                    }}
                                                />

                                            </div>
                                            {errors.aggrement_start_date && touched.aggrement_start_date ? <div className='errMsg'><ErrorMessage name={`aggrement_start_date`} /></div> : <span>&nbsp;</span>}
                                        </div>
                                        <div className='field'>
                                            <div className='sectionField'>
                                                <label htmlFor="aggrement_end_date" className='w-label'> Aggrement End Date<span className='text-danger mx-1'>*</span></label>
                                                <Field placeholder='Enter Customer Name' className="form-control" name="aggrement_end_date"
                                                    type="date"
                                                    value={values.aggrement_end_date}
                                                    onChange={(e: any) => {
                                                        onInputChangeHandler(e, setFieldValue);
                                                    }}
                                                />
                                            </div>
                                            {errors.aggrement_end_date && touched.aggrement_end_date ? <div className='errMsg'><ErrorMessage name={`aggrement_end_date`} /></div> : <span>&nbsp;</span>}
                                        </div>
                                    </div>
                                </div>
                            </section>

                            <section>
                                <div className='sectionHeader'>Address</div>
                                <hr className='m-0'></hr>
                                <div className='section-contant'>
                                    <div className='d-flex section-Fields'>
                                        <div className='field'>
                                            <div className='sectionField'>
                                                <label htmlFor="country" className='w-label'> Country :<span className='text-danger mx-1'>*</span></label>
                                                <SelectComponent
                                                    id={"country"}
                                                    className="form-control"
                                                    defaultValue={values.country}
                                                    isDisabled={false}
                                                    isClearable={true}
                                                    isSearchable={true}
                                                    name="country_id"
                                                    options={countriesDropdown}
                                                    placeholder={"Select Country"}
                                                    onChange={(e: any) => {
                                                        onCountrySelect(e, setFieldValue, setFieldTouched);
                                                    }}
                                                />
                                            </div>
                                            {errors.country_id && !values.country_id && touched.country_id ? <div className='errMsg'>{errors.country_id as string}</div> : <span>&nbsp;</span>}
                                        </div>
                                        <div className='field'>
                                            <div className='sectionField'>
                                                <label htmlFor="state" className='w-label'> State :<span className='text-danger mx-1'>*</span></label>
                                                <SelectComponent
                                                    id={"state"}
                                                    className="form-control"
                                                    defaultValue={values.state}
                                                    isDisabled={values.country_id ? false : true}
                                                    isClearable={true}
                                                    isSearchable={true}
                                                    name="state_id"
                                                    options={statesDropdown}
                                                    placeholder={"Select State"}
                                                    onChange={(e: any) => onStateSelect(e, setFieldValue)}
                                                />
                                            </div>
                                            {/* {errors.state_id && values.country_id ? <div className='errMsg'>{errors.state_id as string}</div> : <span>&nbsp;</span>} */}
                                            {errors.state_id && touched.state_id ? <div className='errMsg'><ErrorMessage name={`state_id`} /></div> : <span>&nbsp;</span>}
                                        </div>
                                        <div className='field'>
                                            <div className='sectionField'>
                                                <label htmlFor="city" className='w-label'> City :<span className='text-danger mx-1'>*</span></label>
                                                <SelectComponent
                                                    id={"city"}
                                                    className="form-control"
                                                    defaultValue={values.city}
                                                    isDisabled={values.state_id ? false : true}
                                                    isClearable={true}
                                                    isSearchable={true}
                                                    name="city_id"
                                                    options={citiesDropdown}
                                                    placeholder={"Select City"}
                                                    onChange={(e: any) => onCitySelect(e, setFieldValue)}
                                                />
                                            </div>
                                            {/* {errors.city_id && values.state_id ? <div className='errMsg'>{errors.city_id as string}</div> : <span>&nbsp;</span>} */}
                                            {errors.city_id && touched.city_id ? <div className='errMsg'><ErrorMessage name={`city_id`} /></div> : <span>&nbsp;</span>}
                                        </div>
                                    </div>
                                    <div className='d-flex section-Fields'>
                                        <div className='field'>
                                            <div className='sectionField'>
                                                <label htmlFor="address" className='w-label'> Address :<span className='text-danger mx-1'>*</span></label>
                                                <Field as='textarea' placeholder='Enter Address' className="form-control" name="address"
                                                    value={values.address}
                                                    onChange={(e: any) => { onInputChangeHandler(e, setFieldValue); }}
                                                />
                                            </div>
                                            {errors.address && touched.address ? <div className='errMsg'><ErrorMessage name={`address`} /></div> : <span>&nbsp;</span>}
                                        </div>
                                    </div>
                                    <div className='d-flex section-Fields'>
                                        <div className='field'>
                                            <div className='sectionField mb-3' >
                                                <label htmlFor="mobile" className='w-label'> Phone :<span className='text-danger mx-1'></span></label>
                                                <div className='input-group'>
                                                    <span className="input-group-text" id="basic-addon1">{phoneCode ? phoneCode : 'code'}</span>
                                                    <Field placeholder='Enter Phone Number' disabled={values.country_id ? false : true} className="form-control" name="mobile"
                                                        value={values.mobile}
                                                        onChange={(e: any) => { onInputChangeHandler(e, setFieldValue); }}
                                                    />
                                                </div>
                                            </div>
                                            {/* {errors.mobile && touched.mobile && values.country_id ? <div className='errMsg'><ErrorMessage name={`mobile`} /></div> : <span>&nbsp;</span>} */}
                                        </div>
                                        <div className='field'>
                                            <div className='sectionField'>
                                                <label htmlFor="telephone" className='w-label'> Telephone :<span className='text-danger mx-1'></span></label>
                                                <div className='input-group'>
                                                    {/* <span className="input-group-text" id="basic-addon1">{phoneCode ? phoneCode : 'code'}</span> */}
                                                    <Field placeholder='Enter Telephone Number' disabled={values.country_id ? false : true} className="form-control" name="telephone"
                                                        value={values.telephone}
                                                        onChange={(e: any) => { onInputChangeHandler(e, setFieldValue); }}
                                                    />
                                                </div>
                                            </div>
                                            {errors.telephone && touched.telephone && values.country_id ? <div className='errMsg'><ErrorMessage name={`telephone`} /></div> : <span>&nbsp;</span>}
                                        </div>
                                        <div className='field'>
                                            <div className='sectionField'>
                                                <label htmlFor="postal code" className='w-label'> Postal Code :<span className='text-danger mx-1'>*</span></label>
                                                <Field placeholder='Enter Postal Code Number' disabled={values.state_id ? false : true} className="form-control" name="postal_code"
                                                    value={values.postal_code}
                                                    onChange={(e: any) => { onInputChangeHandler(e, setFieldValue); }}
                                                />
                                            </div>
                                            {errors.postal_code && touched.postal_code && values.city_id ? <div className='errMsg'><ErrorMessage name={`postal_code`} /></div> : <span>&nbsp;</span>}
                                        </div>
                                    </div>
                                </div>
                            </section>

                            <section>
                                <div className='sectionHeader'>Aggrement</div>
                                <hr className='m-0'></hr>
                                <div className='field section-contant'>
                                    <div className='sectionField'>
                                        <label htmlFor="filename"> Upload Aggrement :</label>
                                        <Field
                                            className="form-control p-2 "
                                            type='file'
                                            accept="application/msword, application/pdf"
                                            name="fileUpload"
                                            id='filename'
                                            placeholder={"Organization Logo"}
                                            onChange={(event: { currentTarget: { files: any[]; }; }) => {
                                                setFieldValue("file", event.currentTarget.files[0]);
                                                setBtnDisable(false);
                                                setUploadImgErr('');
                                            }}
                                        />
                                    </div>
                                    {/* {uploadImgErr ? <div className='errMsg'>{uploadImgErr}</div> : <span>&nbsp;</span>} */}
                                </div>
                            </section>
                            <div className='d-flex justify-content-end buttons'>
                            <button type='button' onClick={backToCustomers} className='btn-esecondary px-4 mx-2 mt-3'>Cancel</button>
                            <button type='submit'className={btnDisabled?' mt-3 btn-esecondary px-4':'btn-eprimary px-4 '} disabled={btnDisabled}>
                                {(!customer.id)?"Submit":"Update"}
                            </button>
                            </div>
                        </Form>
                    )}

                </Formik>
            </CommonCard>
        </React.Fragment>
    );
}



export default CreateCustomer;


