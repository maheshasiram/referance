
import { request } from "../../../../Config/Environment"
import { fetch } from "../../../../constants/fetch"
import { Types } from "../reducer/Types"
import { errHandler, Loader } from "../../../../actions/actions"


export const activeInactiveCustomer: Function = (customerId: any, callback: Function) => {
  let url = `${request.masters.activateDeactivateCustomer}`
  return (dispatch: any) => {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: url,
      data: { 'id': customerId },
    })
      .then((response: any) => {
        callback(response.data);
        dispatch(Loader(false));
      })
      .catch((err: any) => {
        dispatch(errHandler());
      })
  }
}

export const fetchCustomerDetails: Function = (params: any) => {

  let url = `${request.masters.allCustomerDetails}?offset_filter=${params.offset_filter}&limit_filter=${params.limit_filter}&export=${params.export}&search_text=${params.search_text}`
  return (dispatch: any) => {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: params,
    })
      .then((response: any) => {



        dispatch({ type: Types.GET_CUSTOMER_DETAILS, payload: response.data.result })
        dispatch(Loader(false));

      })
      .catch((err: any) => {

      })
  }
}


export const createCustomer: Function = (params: any,callback:any) => {

  let url = `${request.masters.allCustomerDetails}`
  return (dispatch: any) => {
    dispatch(Loader(true));
    fetch({
      method: 'PUT',
      url: url,
      data: params,
    })
      .then((response: any) => {

        callback(response.data);
        dispatch(Loader(false));

      })
      .catch((err: any) => {

      })
  }
}

export const updateCustomer: Function = (params: any,callback:any) => {

  let url = `${request.masters.allCustomerDetails}`
  return (dispatch: any) => {
    fetch({
      method: 'POST',
      url: url,
      data: params,
    })
      .then((response: any) => {

        callback(response.data);

      })
      .catch((err: any) => {

      })
  }
}


export const uploadAggrement: Function = (payload: any, callback: any) => {
  let url = `${request.helpers.uploadFile}`
  return function (dispatch: any) {

    fetch({
      method: 'PUT',
      url: url,
      data: payload,
      headers: {
        "Accept": "*/*",
        "Content-Type": "multipart/form-data"
      }
    })
      .then((response: any) => {
        if (callback) {
          callback(response.data);
        }

      }).catch((error) => {

      })
  }
}


export const getCurrency: Function = (params: any, callback: any) => {
  let url = `${request.helpers.currency}`
  return (dispatch: any) => {
    fetch({
      method: 'GET',
      url: url,
      data: params,
    })
      .then((response: any) => {


        console.log(response.data.result)
        dispatch({ type: Types.GET_CURRENCY, payload: response.data.result })

      })
      .catch((err: any) => {

      })
  }
}
