
import React, { useEffect } from 'react'
import { useDispatch, useSelector } from "react-redux";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Confirm, getCountries, toastAlert } from '../../../actions/actions';
import Switch from '@mui/material/Switch';
import { rowClassName } from '../../../actions/actions';
import CreateCustomer from './CreateCustomer';
import EditIcon from '@mui/icons-material/Edit';
import SearchField from '../../../common/SearchField';
import { confirmMsg, toastMsg } from '../../../common/Messages';
import { messages } from '../../../constants/messages';
import { Types } from './reducer/Types';
import { NavLink, useNavigate } from 'react-router-dom';
import { createCustomer, fetchCustomerDetails, activeInactiveCustomer, getCurrency, updateCustomer, uploadAggrement, } from './actions/CustomerActions';
import _ from "lodash";
import { customerModal } from './constants/modal';

function CustomersDashboard(props: any) {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { allCustomerDetails, customerParams } = useSelector((state: any) => state.customers);
  const [deleteCustomerDialog, setDeleteCustomerDialog] = React.useState(false);
  const [customerStatus, setcustomerStatus] = React.useState(false)
  const [customerId, setCustomerId] = React.useState(null)
  const [searchVal, setSearchVal] = React.useState('');
  const [pageClick, setpageChange] = React.useState(false);
  const [states, setStates] = React.useState([]);
  const [cities, setCities] = React.useState([]);
  const [btnDisable, setBtnDisable] = React.useState(true);

  useEffect(() => {

    dispatch(fetchCustomerDetails(customerParams))
    // dispatch(getCountries())
  }, []);

  
  const onConfirmDisable = (rowData: any) => {

    if (rowData.status === true) {
      setcustomerStatus(false)
    } else {
      setcustomerStatus(true)
    }
    setCustomerId(rowData.id)
    setDeleteCustomerDialog(true);
  }

  const onActiveInActiveCustomer = (rowData: any) => {
    dispatch(Confirm({
      status: 0,
      message: rowData.status ? confirmMsg(messages.inActive, rowData.name) : confirmMsg(messages.active, rowData.name),
      onOk: () => {
        dispatch(activeInactiveCustomer(rowData.id, (response: any) => {
          dispatch(toastAlert({
            status: response.status == "success" ? 1 : 0,
            message: rowData.status ? toastMsg(messages.activated, rowData.name) : toastMsg(messages.inActivated, rowData.name),
            open: true
          }));
          dispatch(fetchCustomerDetails(customerParams));
        }));
      }
    }));
  }

  const customerAction = (rowData: any) => {
    return (
      <div className="d-flex align-items-center">
        <Switch size="small" checked={rowData.status} onClick={() => onActiveInActiveCustomer(rowData)} />
        {rowData.status && <><span className="px-1" > |</span> <EditIcon sx={{ fontSize: 17, opacity: 0.8 }} onClick={() => onOpenCustomersForm('edit', rowData)} /></>}
      </div>
    )
  }

  const onOpenCustomersForm = (type: string, customerData:any ) => {
        if (type === "add") {

            // setPhoneCode('');
            dispatch({ type: Types.CUSTOMER_DATA, payload: customerModal });
        } else {
            navigate(`/customers/${customerData.id}`);
             let _customerData = _.cloneDeep(customerData);
            // dispatch(getStatesByCountry(customerData.country.id, () => {
            //     dispatch(getCitiesByState(customerData.state.id, () => {
            //         // if (countriesDropdown && statesDropdown && citiesDropdown) {
            //         //     _customerData.country = countriesDropdown && countriesDropdown.find((contry: any) => (contry.value == customerData.country.id));
            //         //     _customerData.state = statesDropdown && statesDropdown.find((state: any) => (state.value == customerData.state.id));
            //         //     _customerData.city = citiesDropdown && citiesDropdown.find((city: any) => (city.value == customerData.city.id));
            //         // }
            //     }));
            // }));
            // setPhoneCode(customerData?.country?.phone_extension ? customerData.country.phone_extension : '');
            _customerData.phoneCode=customerData?.country?.phone_extension ? customerData.country.phone_extension : ''
            _customerData.country = { 'label': customerData.country.name, 'value': customerData.country.id }
            _customerData.country_id = customerData.country.id
            _customerData.state = { 'label': customerData.state.name, 'value': customerData.state.id }
            _customerData.state_id = customerData.state.id
            _customerData.city = { 'label': customerData.city.name, 'value': customerData.city.id }
            _customerData.city_id = customerData.city.id
            dispatch({ type: Types.CUSTOMER_DATA, payload: _customerData });
        };
    setBtnDisable(true);
}

  const onSearchCustomer= (e: any) => {
    setSearchVal(e.target.value);
    let _payload = { ... customerParams,search_text:e.target.value, offset_filter: 0}
    dispatch({ type: Types.CUSTOMER_PARAMS, payload: _payload });
    dispatch(fetchCustomerDetails(_payload));
    
  };

  const onClearSearch = () => {
    setSearchVal('');
    let _payload = { ... customerParams,search_text:"", offset_filter: 0}
    dispatch({ type: Types.CUSTOMER_PARAMS, payload: _payload });
   dispatch(fetchCustomerDetails(_payload));
 
  };

  const onPageChange = (event: any) => {
    if ((event.page > 0 || pageClick && event.page == 0) && customerParams.offset_filter != event.first) {
        let _payload = { ...customerParams, offset_filter: event.first }
        dispatch({ type: Types.CUSTOMER_PARAMS, payload: _payload });
        dispatch(fetchCustomerDetails(_payload));
        setpageChange(true);
    }
  }
  return (

    <div className='organization-Dashboard'>
      <div className='d-flex justify-content-end button-Search-div'>
        <div className='search-field'>
          <SearchField
            value={searchVal}
            //emptyMessage="No Customers To Display."
            rows={customerParams.search_text}
            placeholder="Search By Customer Name"
            onChange={onSearchCustomer}
            onClearSearch={onClearSearch}
          />
        </div>
        <div className='button_search_alignment'> <NavLink to='../customers/0'><button className='btn-eprimary my-2' onClick={() => onOpenCustomersForm('add', customerModal)}> Create Customer</button></NavLink> </div>
      </div>

      {allCustomerDetails &&
        <DataTable
          value={allCustomerDetails.data}
          emptyMessage="No Customers To Display."
          lazy
          scrollable
          rows={customerParams.limit_filter}
          paginator={allCustomerDetails.total_count > customerParams.limit_filter ? true : false}
          totalRecords={allCustomerDetails.total_count}
          responsiveLayout="scroll"
          rowClassName={rowClassName}
          stripedRows={true}
          first={customerParams.offset_filter}
          onPage={onPageChange}
        >
          <Column field="name" header="Name" ></Column>
          <Column field="gst" header="GST" ></Column>
          <Column field="trade" header="Trade" ></Column>
          <Column field="type" header="Type" ></Column>
          <Column field="state.name" header="State" ></Column>
          <Column field="country.name" header="Country" ></Column>

          <Column body={customerAction} header='Update'></Column>

        </DataTable>
      }
    </div>
  )
}

export default CustomersDashboard;

