
import { customerModal } from "../constants/modal"
import { Types } from "./Types"


const initialState = {
  allCustomerDetails: null,
  customerParams: { offset_filter: 0, limit_filter: 10, export: false,search_text:" " },
  customer: customerModal,
  currency: []
}

export const customers = (state = initialState, action: { type: any, payload: any }) => {
  switch (action.type) {
    case Types.GET_CUSTOMER_DETAILS:
      return { ...state, allCustomerDetails: action.payload }

    case Types.CUSTOMER_DATA:
      return { ...state, customer: action.payload }

    case Types.GET_CURRENCY:
      return { ...state, currency: action.payload }

    case Types.CUSTOMER_PARAMS:
      return { ...state, customerParams: action.payload }


    default:
      return { ...state }
  }
}