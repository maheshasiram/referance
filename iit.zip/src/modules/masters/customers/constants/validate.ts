import * as Yup from "yup";

export const CustomerSchema = (customerDetails: any) => {
    return Yup.object().shape({
        trade: Yup.string().required("Please Select Trade").nullable(),
        name: Yup.string().required("Please Enter Master Name").nullable().min(10, "Min is 10").max(50, "max is 50"),
        gst: Yup.string().required("Please Enter GST Number").nullable().min(15,"min 15 digit").max(15,"max 15 digit"),
        // mobile: Yup.number().typeError("Please enter number value only").required("Please Enter Mobile Number").nullable().max(10,'Invalid Date '),
        // tin: Yup.string().required("Please Enter TIN Number").nullable(),
        address: Yup.string().required("Please Enter Address").nullable(),
        aggrement_start_date: Yup.string().required("Please Select Start Date").max(10,'Invalid Date '),
        aggrement_end_date: Yup.string().required("Please Select End Date" ).max(10,'Invalid Date '),
        country_id: Yup.string().required("Please Select County" ),
        state_id: Yup.string().required("Please Select State").nullable(),
        city_id: Yup.string().required("Please Enter City").nullable(),
        credit_period: Yup.number().typeError("Please enter number value only").required("Please Enter Credit Period").nullable(),
        telephone: Yup.number().typeError("Please enter number value only").notRequired(),
        postal_code: Yup.number().typeError("Please enter number value only").required("Please Enter Postal Code").nullable(),
        currency_id:Yup.string().required("Please Select Currency").nullable(),
        
    })
}