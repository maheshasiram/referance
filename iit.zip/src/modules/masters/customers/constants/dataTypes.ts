export type customerDataTypes ={
    name: string;
    trade:string;
    gst:string;
    tin:string;
    credit_period:any;
    aggrement_start_date:any;
    aggrement_end_date:any;
    state_id:any;
    country_id:any;
    city_id:any;
    currency_id:any;
    aggrement_id:any;
    address:string;
    mobile:string;
    postal_code:string;
    telephone:string;
    country : any;
    state: any;
    city: any;
    currency:any
}