import { customerDataTypes } from "./dataTypes";

export const customerModal : customerDataTypes ={
    name: '',
    trade:'',
    gst:'',
    tin:'',
    credit_period:'',
    aggrement_start_date:'',
    aggrement_end_date:'',
    state_id:'',
    country_id:'',
    city_id:'',
    currency_id:'',
    aggrement_id:null,
    address:'',
    mobile:'',
    postal_code:'',
    telephone:'',
    country:'',
    state:'',
    city: '' ,
    currency:''
}