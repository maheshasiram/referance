import React from 'react'

function GoodsAndServices() {
  return (
    <div>
      Banking
    </div>
  )
}

export default GoodsAndServices;