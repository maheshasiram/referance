import _ from "lodash";
import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useNavigate } from "react-router";
import { fetchAllInvoices, getInvoiceBank, getInvoiceCustomer, getInvoiceOrganization,rowClassName } from "../../actions/actions";
import { Types } from "../../constants/Types";
import { InvoiceDetails } from "../invoice/domastic/invoiceData";
import FileCopyOutlinedIcon from '@mui/icons-material/FileCopyOutlined';
import EditIcon from '@mui/icons-material/Edit';
import Tooltip from '@mui/material/Tooltip';

function InvoiceDasboard() {
    const navigate = useNavigate()
    const dispatch = useDispatch();
    const { allInvoiceDetails, customersDropdown, invoiceParams, organizationsDropdown, goodsAndServicesDropdown } = useSelector((state: any) => state.application)
    const [pageClick, setpageChange] = React.useState(false);


    const onPreviewPdf = (rowData: any) => {
        dispatch(getInvoiceCustomer(rowData.customer.id, (response: any) => {
            dispatch({ type: Types.INVOICE_CUSTOMER, payload: response.result.data[0] });
        }))

        dispatch(getInvoiceOrganization(rowData.organization.id, (response: any) => {
            dispatch({ type: Types.INVOICE_ORGANIZATION, payload: response.result.data[0] });
        }))

        dispatch(getInvoiceBank(rowData.banking.id, (response: any) => {
            dispatch({ type: Types.INVOICE_BANK, payload: response.result.data[0] });
        }))

        dispatch({ type: Types.INVOICE_DETAILS, payload: rowData });

        setTimeout(() => {
            navigate('/viewinvoice')
        }, 1000);

    }

    useEffect(() => {
        dispatch(fetchAllInvoices(invoiceParams))
    }, []);
    const onPageChange = (event: any) => {
        if ((event.page > 0 || pageClick && event.page == 0) && invoiceParams.offset_filter != event.first) {
          let _payload = { ... invoiceParams, offset_filter: event.first }
          dispatch({ type: Types.INVOICE_PARAMS, payload: _payload });
          dispatch(fetchAllInvoices(_payload));
          setpageChange(true);
        }
      }


    const editInvoice = (rowData: any) => {
        let _rowData = _.cloneDeep(rowData);
        _rowData.organization = { "label": _rowData.organization.name, "value": _rowData.organization.id };
        _rowData.organization_id = rowData.organization.id;
        _rowData.customer = { "label": _rowData.customer.name, "value": _rowData.customer.id };
        _rowData.customer_id = rowData.customer.id;
        _rowData.bank = { "label": _rowData.banking.name, "value": _rowData.banking.id }
        _rowData.banking_id = rowData.banking.id

        _rowData.items.map((item: any, index: any) => {
            _rowData.items[index].itemName = { "label": _rowData.items[index].item, "value": 4 }
        })

        if (_rowData.type === 'domestic') {
            dispatch({ type: Types.DOMESTIC_INVOICE_DATA, payload: _rowData });
            navigate(`/domestic/${rowData.id}`)
        }

        if (_rowData.type === 'international') {
            dispatch({ type: Types.INTERNATIONAL_INVOICE_DATA, payload: _rowData });
            navigate(`/international/${rowData.id}`)
        }


    }

    const onPreviewAction = (rowData: any) => {
        return (
            <div className="d-flex align-items-center">
                <Tooltip title="Edit" placement="top">
                    < EditIcon onClick={() => editInvoice(rowData)} />
                </Tooltip>


                <span>|</span>

                <Tooltip title="Preview & Download" placement="top">
                    <FileCopyOutlinedIcon onClick={() => onPreviewPdf(rowData)} />
                </Tooltip>
            </div>
        )
    }

    return (
        <React.Fragment>
            <div>INVOICE</div>
            {allInvoiceDetails &&
            <DataTable
              value={allInvoiceDetails.data}
              emptyMessage="No Organizations To Display."
              lazy
              scrollable
              rows={invoiceParams.limit_filter}
              paginator={allInvoiceDetails.total_count > invoiceParams.limit_filter ? true : false}
              totalRecords={allInvoiceDetails.total_count}
              first={invoiceParams.offset_filter}
              responsiveLayout="scroll"
               rowClassName={rowClassName}
              stripedRows={true}
               onPage={onPageChange}
            >
                <Column field="invoice_date" header="Invoice Date" ></Column>
                <Column field="invoice_number" header="Invoice" ></Column>
                <Column field="po_number" header="Order Number" ></Column>
                <Column field="customer.name" header="customer" ></Column>
                <Column field="due_date" header="Due Date" ></Column>
                <Column field="total_amount" header="Amount" ></Column>
                <Column field="type" header="Type" ></Column>
                <Column body={onPreviewAction} header='Action'></Column>
            </DataTable>
            }
        </React.Fragment>
    )
}

export default InvoiceDasboard;