import React from 'react';
import { PDFViewer, PDFDownloadLink, Page, Text, View, Document, Image, StyleSheet, Font } from '@react-pdf/renderer';
import ReactPDF from '@react-pdf/renderer';
import { useSelector } from 'react-redux';
// import { fontSize } from '@mui/system';
import { useNavigate } from 'react-router-dom';
import { NumToWords } from './NumToWords';
// import {NumToWords} from './NumToWords'



// Create styles
const styles = StyleSheet.create({
    table: {
        display: "flex",
        width: "auto",
    },
    tableRow: {
        margin: "auto",
        flexDirection: "row"

    },
    tableRowHeader: {
        margin: "auto",
        flexDirection: "row",
        backgroundColor: "#dee1e6"

    },


    page: {
        paddingTop: 35,
        paddingBottom: 65,
        paddingHorizontal: 35,
    },
    section: {
        margin: 10,
        padding: 10,
        flexGrow: 1
    },

    invoice: {
        marginTop: "2%",
        marginRight: "2%",
        fontSize: "12",
        flexDirection: "row-reverse",
        display: "flex",
        justifyContent: "space-between"
    },
    image: {
        paddingLeft: "40px"
    },
    taxinvoice: {
        marginTop: "14%",
        display: "flex",
        textAlign: "center",
        width: "100%",
        fontSize: "20",
        fontFamily: "Times-Bold"
    },
    invoicemain: {
        paddingRight: "4%"
    },
    invoicetext: {
        marginTop: "8%",
        paddingLeft: "15px",
        fontSize: "10",
    },
    invoicedate: {
        marginTop: "2%",
        paddingLeft: "15px",
    },
    invoiceNumber: {
        justifyContent: "center",
        fontSize: "9",
        paddingBottom: "3px",
        paddingLeft: "3px",
    },
    fromaddress: {
        margin: "2% 3%"
    },
    address: {
        margin: "0% 3%"
    },
    header: {
        fontSize: "12",
        marginBottom: "3px",
        fontFamily: "Times-Bold"
    },
    content: {
        fontSize: "9",
        marginBottom: "2px",
    },
    tablecontent: {
        margin: "2%",
        fontSize: "8",
    },
    activityColHeader: {
        width: "40%",
        fontSize: "10",
        minHeight: "25px",
        maxHeight: "200px",
        padding: "7px 6px",
    },
    activitytablecol: {
        width: "40%",
        fontSize: "9",
        minHeight: "25px",
        maxHeight: "200px",
        padding: "4px 6px",
    },
    tableColHeader: {
        width: "15%",
        fontSize: "10",
        minHeight: "25px",
        maxHeight: "200px",
        padding: "7px 6px",
    },
    tableFirstHeader: {
        width: "5%",
        fontSize: "10",
        minHeight: "25px",
        maxHeight: "200px",
        padding: "7px 6px",
    },
    tableCol: {
        width: "15%",
        fontSize: "8",
        minHeight: "25px",
        maxHeight: "200px",
        padding: "4px 6px",
        fontFamily: "Times-Bold"
    },
    tableFirstCol: {
        width: "5%",
        fontSize: "8",
        minHeight: "25px",
        maxHeight: "200px",
        padding: "4px 6px",
    },
    descriptioncol: {
        paddingTop: "6px",
        fontSize: "8"
    },
    taxdetails: {
        fontSize: "9",
        flexDirection: "row-reverse",
        textTransform: "uppercase",
        paddingRight: "5%",
        marginTop: "2%"
    },
    taxWords: {
        fontSize: "9",
        flexDirection: "row-reverse",
        textTransform: "uppercase",
        paddingRight: "5%",
        paddingLeft: "55%",
    },
    taxsubdetails: {
        marginBottom: "4px",
        // fontFamily:"Times-Bold"
    },
    taxFinalAmount: {
        marginBottom: "4px",
        fontFamily: "Times-Bold",
        fontSize: "14"
    },
    taxbalance: {
        fontSize: "10",
        fontWeight: "extrabold"
    },
    bankdetails: {
        fontSize: "9",
        margin: "2% 3%",
        textTransform: "uppercase"
    },
    banksubdetails: {
        marginBottom: "4px"
    },
    bankheader: {
        fontSize: "11",
        marginBottom: "5px",
        paddingBottom: "4px",
        borderBottom: "1px solid rgba(0,0,0,0.08)",
        fontWeight: "bold",
        width: "25%"
    },
    alert: {
        width: "70%",
        fontSize: "11",
        display: "flex",
        textAlign: "center",
        margin: "auto",
        // margin: "5% 0%",
        textTransform: "uppercase",
    },
    border: {
        width: "100%"
    },
    info: {
        margin: "8% 3% 3% 3%",
        fontSize: "12",
        flexDirection: "row-reverse",
        display: "flex",
        justifyContent: "space-between"
    },
    personalinfo: {
        fontSize: "10",
        marginBottom: "1%",
    },
    addressinfo: {
        fontSize: "10",
        marginBottom: "1%",

    },
    addresstxt: {
        width: "34%",
        fontSize: "11%",
        fontWeight: "bold"
    }
});

Font.register({
    family: 'Oswald',
    src: 'https://fonts.gstatic.com/s/oswald/v13/Y_TKV6o8WovbUd3m_X9aAA.ttf'
});



const MyDoc = (props: any) => (


    <Document style={{ height: "100%", fontFamily: 'Times-Roman' }}>
        <Page id="pdfPage" size="A4">

            <View fixed>
                <Image src="/Border.jpg" />
            </View>

            <View style={styles.invoice}>
                <View>
                    <View style={styles.invoice}>
                        <View>
                            <Image style={styles.image} src="/MicrosoftTeams-image.png" />
                        </View>
                        <Text style={styles.taxinvoice}>
                            QUOTATION
                        </Text>
                    </View>
                </View>

            </View>
            <View style={styles.invoice}>
                <View style={styles.invoicemain}>
                    <Text style={{ fontFamily: "Times-Bold", color: "#88807B", paddingLeft: "15px" }}>Original for Recipient</Text>
                    <Text style={styles.invoicetext}>
                        <Text style={{ fontFamily: "Times-Bold" }}>QUOTATION NO :</Text><Text style={styles.invoiceNumber}>{props.quotation.quotation_number}</Text>
                    </Text>

                    <Text style={styles.invoicedate}>
                        <Text style={{ fontFamily: "Times-Bold" }}>DATE :</Text><Text style={styles.invoiceNumber}>{props.quotation.quotation_date}</Text>
                    </Text>
                </View>
                <View style={styles.fromaddress}>
                    <Text style={styles.header}>
                        {props.org.name}
                    </Text>
                    <Text style={styles.content}>
                        {props.org.address},
                    </Text>
                    <Text style={styles.content}>
                        {props.org.city.name},{props.org.state.name}-{props.org.postal_code}
                    </Text>
                    <Text style={styles.content}>
                        {props.org.country.name}
                    </Text>
                    <Text style={styles.content}>
                        GSTIN: {props.org.gst}
                    </Text>
                </View>

            </View>
            <View style={styles.address}>
                <Text style={{ fontSize: "14" }}>
                    QUOTE TO
                </Text>
                <Text style={styles.header}>
                    {props.customer.name}
                </Text>
                <Text style={styles.content}>
                    {props.customer.address}
                </Text>
                <Text style={styles.content}>
                    {props.customer.city.name},{props.customer.state.name}-{props.customer.postal_code}
                </Text>
                <Text style={styles.content}>
                    {props.customer.country.name}
                </Text>
                <Text style={styles.content}>
                    GSTIN: {props.customer.gst}
                </Text>
            </View>
            <View style={styles.address}>

                <Text style={styles.header}>
                    Place Of Supply
                </Text>
                <Text style={styles.content}>
                    {props.customer.state.name}
                </Text>

            </View>
            <View style={styles.tablecontent}>
                <View style={styles.tableRowHeader}>
                    <View style={styles.tableFirstHeader}>
                        <Text >NO</Text>
                    </View>
                    <View style={styles.activityColHeader}>
                        <Text >ACTIVITY</Text>
                    </View>
                    <View style={styles.tableColHeader}>
                        <Text >HSN</Text>
                    </View>
                    <View style={styles.tableColHeader}>
                        <Text >QTY</Text>
                    </View>
                    <View style={styles.tableColHeader}>
                        <Text>RATE</Text>
                    </View>
                    <View style={styles.tableColHeader}>
                        <Text>AMOUNT</Text>
                    </View>
                </View>
                <View>

                    {props.quotation.items.map((item: any, index: any) => (

                        <View style={styles.tableRow} key={index}>
                            <View style={styles.tableFirstCol}>
                                <Text>{index + 1}</Text>
                            </View>
                            <View style={styles.activitytablecol}>
                                <Text style={{ fontFamily: "Times-Bold" }}>{item.item}</Text>
                                <Text style={styles.descriptioncol}>{item.description}</Text>
                            </View>
                            <View style={styles.tableCol}>
                                <Text>{item.hsn_code}</Text>
                            </View>
                            <View style={styles.tableCol}>
                                <Text>{item.quantity}</Text>
                            </View>
                            <View style={styles.tableCol}>
                                <Text>{item.rate}</Text>
                            </View>
                            <View style={styles.tableCol}>
                                <Text>{item.amount}</Text>
                            </View>
                        </View>

                    ))}

                    <View style={styles.taxdetails}>
                        <View>
                            {props.quotation.total_cgst_amount > 0 &&
                                <Text style={styles.taxsubdetails}>
                                    CGST : {props.quotation.total_cgst_amount}
                                </Text>}
                            {props.quotation.total_sgst_amount > 0 &&
                                <Text style={styles.taxsubdetails}>
                                    SGST : {props.quotation.total_sgst_amount}
                                </Text>}
                            {props.quotation.total_igst_amount > 0 &&
                                <Text style={styles.taxsubdetails}>
                                    Igst : {props.quotation.total_igst_amount}
                                </Text>}
                            <Text style={styles.taxFinalAmount}>
                                TOTAL : <Text style={styles.taxFinalAmount}>INR {props.quotation.total_amount}</Text>
                            </Text>

                        </View>

                    </View>
                    <Text style={styles.taxWords}>{NumToWords(props.quotation.total_amount)}</Text>

                </View>

            </View>
            {/* <View style={styles.bankdetails}>
                <Text style={styles.bankheader}>
                    Our Banking Partners
                </Text>
                <Text style={styles.banksubdetails}>
                    Benificiary Name   : {props.bank.name},
                </Text>
                <Text style={styles.banksubdetails}>
                    Account number   : {props.bank.account_number},
                </Text>
                <Text style={styles.banksubdetails}>
                    IFSC Code                  : {props.bank.ifsc_code}
                </Text>
            </View> */}
            <Text style={styles.alert}>
                this is computer generated , document signature not required .
            </Text>
            {/* <View style={styles.info}>
                <View style={styles.addresstxt}>
                    <Text style={styles.addressinfo}>
                        Inductive Quotient Analytics India Pvt. Ltd.
                    </Text>
                    <Text style={styles.addressinfo}>
                        Cavery's City Plaza , 2nd Floor , Sundar Nagar , Andhra Bank Building , Hyderbad - 38
                    </Text>
                </View>
                <View>
                    <Text style={styles.personalinfo}>
                        +91 40-2970 4084
                    </Text>
                    <Text style={styles.personalinfo}>
                        info@inductivequotient.com
                    </Text>
                    <Text style={styles.personalinfo}>
                        www.inductivequotient.com
                    </Text>
                </View>

            </View> */}

            <View fixed>
                <Image src="/Border.jpg" />
            </View>

        </Page>
    </Document>
);


function QuotationViewer() {
    const navigate = useNavigate()
    const { InvoiceOrganization, InvoiceCustomer } = useSelector((state: any) => state.application);
    const { quotationDetails } = useSelector((state: any) => state.DomesticQuotation);






    const backToHome = () => {
        navigate("/home")
    }
    return (
        <div>
            <PDFViewer width={"100%"} height={"500px"} showToolbar={false} >
                <MyDoc org={InvoiceOrganization} customer={InvoiceCustomer} quotation={quotationDetails} />
            </PDFViewer>
            <button type='button' style={{ float: "right" }} onClick={backToHome} className='btn-esecondary px-4 mx-2 '>Cancel</button>
            <button className='btn btn-primary px-4 mx-2' type='button' style={{ float: "right" }}>
                <PDFDownloadLink style={{ color: "white" }} document={<MyDoc org={InvoiceOrganization} customer={InvoiceCustomer} quotation={quotationDetails} />} fileName="Tax Invoice.pdf">
                    {({ blob, url, loading, error }) =>
                        loading ? 'Loading document...' : 'Download now!'
                    }
                </PDFDownloadLink>
            </button>
        </div>

    )
}

export default QuotationViewer;