export let InvoiceDetails: any = [
    {
        organization_id: "16",
        bank_id:"16",
        customer_id: "5",
        invoice_number: "241",
        po_number: "234",
        po_date: "2023-04-19",
        credit_period: '30',
        invoice_date: '2023-04-03',
        due_date: '2023-04-19',
        items: [{
            item: "CDM",
            description: "",
            quantity: "2",
            rate: "240",
            amount: "456",
            hsn_code: "",
            discount: "5",
            discount_type: "pct",
            cgst: "9",
            sgst: "9",
            saved: false,
            cgstAmount: "41.04",
            sgstAmount: "41.04",
            subtotal:"480"

        },],
        sgst: "41.04",
        cgst: "41.04",
        total_amount: "538.08",
        customer_notes: "THANK YOU",
    }

]