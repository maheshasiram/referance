import * as React from 'react';
import * as Yup from 'yup';
import { Formik, Field, Form, FormikHelpers, ErrorMessage, FieldArray } from 'formik';
import { useDispatch, useSelector } from 'react-redux';
import CustomDialog from '../../../common/modals/CustomeDialog';
import SelectComponent from '../../../common/SelectComponent';
import _, { values } from "lodash";
import { Alert, Button } from '@mui/material';
import RemoveCircleIcon from '@mui/icons-material/RemoveCircle';
// import AddCircleIcon from '@mui/icons-material/AddCircle';
import { domesticInvoiceDataTypes } from './constants/dataTypes';
import { domesticInvoiceModal } from './constants/modal';
import BreadCrumbs from '../../../common/breadCrumbs/BreadCrumbs';
import { InputNumber } from 'primereact/inputnumber';
import "./styles.scss"
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
import CommonCard from '../../../common/CommonCard';
import AlertDialog from '../../../common/modals/AlertDialog';
import {
    addInvoiceItems, allCustomersDropdown, createInvoice, fetchAllInvoices, getGoodsandServicesDropdown,
    getInvoiceBank, getInvoiceCustomer, getInvoiceNumber, getInvoiceOrganization, getOrganizationsDropdown, toastAlert, updateInvoice, updateInvoiceItems
} from '../../../actions/actions';
import { confirmMsg, toastMsg } from '../../../common/Messages';
import { NavLink, useNavigate } from 'react-router-dom';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import moment from 'moment';
import { totalmem } from 'os';
import { InvoiceDetails } from './invoiceData';
import { DomesticSchema } from './constants/validate';
import { Types } from '../../../constants/Types';




function DomesticInvoice(props: any) {
    const dispatch = useDispatch();
    const navigate = useNavigate()
    // const [totalcgst, setTotalcgst] = React.useState(0);
    // const [totalsgst, setTotalsgst] = React.useState(0);
    // const [totaligst, setTotaligst] = React.useState(0);
    const [organizationState, setOrganizationState] = React.useState("");
    const [addRemoveMsg, setaddRemoveMsg] = React.useState("");
    const [addMsg, setaddMsg] = React.useState("");
    const [btnDisabled, setBtnDisable] = React.useState(true);
    const [organizationBanks, setOrganizationBanks] = React.useState([]);
    const [selectbank, setSelectbank] = React.useState(true);
    const [creditPeriod, SetCreditPeriod] = React.useState("")
    const [sameState, setSameState] = React.useState(false)
    const { customersDropdown, organizationsDropdown, goodsAndServicesDropdown, goodsAndServicesDetails, invoiceNumber, domesticData } = useSelector((state: any) => state.application);

    const updatedDomesticModal = { ...domesticData, invoice_number: `${domesticData.invoice_number == "" ? invoiceNumber : domesticData.invoice_number}` }

    const [totalcgst, setTotalcgst] = React.useState(updatedDomesticModal.total_cgst_amount);
    const [totalsgst, setTotalsgst] = React.useState(updatedDomesticModal.total_sgst_amount);
    const [totaligst, setTotaligst] = React.useState(updatedDomesticModal.total_igst_amount);
    const [totalAmount, setTotalAmount] = React.useState(updatedDomesticModal.total_amount);

    const onSaveInvoice = (values: any) => {
        // console.log(values.total_amount,"62-------")
        //console.log(values.items, "63-------")
        // console.log(values.items[0].save,"64-------")

        let items = values.items
        const data = items.every((item: any) => {
           // console.log(item.save, "68---------")
            return item.save === true;
        })
        console.log("82...", data)

        if (data) {
            delete values.items
            let new_items: any = []
            items.map((item: any) => {
                new_items.push({ ...item, invoice_number: values.invoice_number })
            })
            if (props.create) {
                dispatch(createInvoice(values, (response: any) => {
                    dispatch(addInvoiceItems({ "data": new_items }))
                }))
                // console.log("domestic created----------71")
                dispatch(toastAlert({
                    status: 1,
                    message: 'Invoice Created Successfully',
                    open: true
                }));
            }
            else {
                dispatch(updateInvoice(values, (response: any) => {
                    dispatch(updateInvoiceItems({ "data": new_items }))
                    //console.log("domestic updated----------------82")
                    dispatch(toastAlert({
                        status: 1,
                        message: 'Invoice Updated Successfully',
                        open: true
                    }));
                }))

            }

            // dispatch(fetchAllInvoices())
            navigate("/home")
        }


        else {
            dispatch(toastAlert({
                status: 0,
                message: 'Item Details Not Saved',
                open: true
            }));
        }




    }





    const saveAndDownload = (values: any) => {
        dispatch({ type: Types.INVOICE_DETAILS, payload: values });


        let items = values.items
        let new_items: any = []
        items.map((item: any) => {
            new_items.push({ ...item, invoice_number: values.invoice_number })
        })
        dispatch(createInvoice(values, (response: any) => {
            dispatch(addInvoiceItems({ "data": new_items }))
        }))

        navigate('/viewinvoice')


    }

    const backToHome = () => {
        navigate("/home")
    }

    const onInputChangeHandler = (e: any, setFieldValue: any) => {
        setBtnDisable(false);
        setFieldValue(e.target.name, e.target.value);
    }

    const organizationChangeHandler = (e: any, setFieldValue: any) => {
        setBtnDisable(false);
        dispatch(getInvoiceOrganization(e.value, (response: any) => {
            dispatch({ type: Types.INVOICE_ORGANIZATION, payload: response.result.data[0] });
            setOrganizationState(response.result.data[0].state.name)
            let bankArray: any = []
            response.result.data[0].banking.forEach((item: any) => {
                if (response.result.data[0].banking[0] == null) {
                    setSelectbank(true)
                    dispatch(toastAlert({
                        status: 0,
                        message: 'This organization is not assign to any bank',
                        open: true
                    }));
                }
                else {
                    setSelectbank(false)
                    bankArray.push({ label: item.name, value: item.id })
                    setOrganizationBanks(bankArray)
                }
            });
        }))
        setFieldValue("organization_id", e.value);

    }

    const customerChangeHandler = (e: any, setFieldValue: any) => {
        setBtnDisable(false);
        dispatch(getInvoiceCustomer(e.value, (response: any) => {
            let customerDetails = response.result.data[0]
            dispatch({ type: Types.INVOICE_CUSTOMER, payload: customerDetails });
            if (organizationState == customerDetails.state.name) {
                setSameState(true)
            }
            // SetCreditPeriod(response.result.data[0].credit_period)
            setFieldValue("credit_period", response.result.data[0].credit_period);
            let due_date = moment(updatedDomesticModal.invoice_date, "YYYY-MM-DD").add(response.result.data[0].credit_period, 'days').format("YYYY-MM-DD")
            setFieldValue("due_date", due_date)
        }))
        setFieldValue("customer_id", e.value);
    }

    const bankChangeHandler = (e: any, setFieldValue: any) => {
        setBtnDisable(false);
        dispatch(getInvoiceBank(e.value, (response: any) => {
            dispatch({ type: Types.INVOICE_BANK, payload: response.result.data[0] });
        }))
        setFieldValue("banking_id", e.value);
    }


    //Render

    const onDiscountTypeChange = (e: any, index: any, values: any, setFieldValue: any) => {
        setBtnDisable(false);
        let discount_type = e.target.value
        setFieldValue(`items[${index}].discount_type`, discount_type)
        let discount = 0
        if (discount_type == "amt") {
            discount = values.items[index].discount
        }
        else {
            discount = (values.items[index].sub_total_amount) * (values.items[index].discount / 100)
        }
        let amount = (values.items[index].sub_total_amount) - (discount)
        setFieldValue(`items[${index}].amount`, amount)
    }

    const onSaverecord = (index: any, values: any, setFieldValue: any) => {
        console.log("save record-----182", values)

        setFieldValue(`items[${index}].save`, true)

        let discount_type = values.items[index].discount_type
        setFieldValue(`items[${index}].discount_type`, discount_type)
        let discount = 0

        if (discount_type == "amt") {
            discount = values.items[index].discount
        }
        else {
            discount = (values.items[index].sub_total_amount) * (values.items[index].discount / 100)
        }

        let amount = (values.items[index].sub_total_amount) - (discount)
        setFieldValue(`items[${index}].amount`, amount)


        let cgst_amount = Math.round((values.items[index].cgst / 100) * amount)
        let sgst_amount = Math.round((values.items[index].sgst / 100) * amount)
        let igst_amount = Math.round((values.items[index].igst / 100) * amount)

        setFieldValue(`items[${index}].cgst_amount`, cgst_amount)
        setFieldValue(`items[${index}].sgst_amount`, sgst_amount)
        setFieldValue(`items[${index}].igst_amount`, igst_amount)

        let amountGst = amount + cgst_amount + sgst_amount + igst_amount


        let totalAmount = 0
        let totalcgst = 0
        let totalsgst = 0
        let totaligst = 0

        // values.items[index].amount = amountGst
        values.items[index].cgst_amount = cgst_amount
        values.items[index].sgst_amount = sgst_amount
        values.items[index].igst_amount = igst_amount


        values.items.forEach((item: any) => {

            totalAmount += item.amount + item.cgst_amount + item.sgst_amount + item.igst_amount
            totalcgst += item.cgst_amount
            totalsgst += item.sgst_amount
            totaligst += item.igst_amount
        });


        setTotalAmount(totalAmount)
        setTotalcgst(totalcgst)
        setTotalsgst(totalsgst)
        setTotaligst(totaligst)
        setFieldValue(`total_cgst_amount`, totalcgst)
        setFieldValue(`total_sgst_amount`, totalsgst)
        setFieldValue('total_amount', totalAmount)
        setFieldValue('total_igst_amount', totaligst)


    }


    const onDeleteRecord = (remove: any, index: any, values: any, setFieldValue: any) => {

        setBtnDisable(false);
        setaddRemoveMsg('');
        if (values.items.length > 1) {
            remove(index)
            delete values.items[index]
        }
        else {
            setaddRemoveMsg("You can't remove. Atleast one option required.")
        }





        let totalAmount = 0
        let totalcgst = 0
        let totalsgst = 0
        let totaligst = 0





        values.items.forEach((item: any) => {

            totalAmount += item.amount + item.cgst_amount + item.sgst_amount + item.igst_amount
            totalcgst += item.cgst_amount
            totalsgst += item.sgst_amount
            totaligst += item.igst_amount
        });

        setTotalAmount(totalAmount)
        setTotalcgst(totalcgst)
        setTotalsgst(totalsgst)
        setTotaligst(totaligst)
        setFieldValue(`total_cgst_amount`, totalcgst)
        setFieldValue(`total_sgst_amount`, totalsgst)
        setFieldValue('total_amount', totalAmount)
        setFieldValue('total_igst_amount', totaligst)

    }


    const onEditrecord = (index: any, setFieldValue: any) => {
        setBtnDisable(false);
        console.log("Edit record -----246")

        setFieldValue(`items[${index}].save`, false)


    }

    const onitemChangeHandler = (e: any, index: any, setFieldValue: any, setFieldTouched: any) => {
        setBtnDisable(false);
        let _item = goodsAndServicesDetails.filter((item: any) => item.id == e.value);
        setFieldValue(`items[${index}].item`, _item[0].activity)
        setFieldTouched(`items[${index}].hsn_code`, true)
        setFieldValue(`items[${index}].hsn_code`, _item[0].code)
        if (sameState) {
            setFieldValue(`items[${index}].cgst`, _item[0].tax_rate / 2)
            setFieldValue(`items[${index}].sgst`, _item[0].tax_rate / 2)
            setFieldValue(`items[${index}].igst`, 0)

        }
        else {
            setFieldValue(`items[${index}].cgst`, 0)
            setFieldValue(`items[${index}].sgst`, 0)
            setFieldValue(`items[${index}].igst`, _item[0].tax_rate)
        }

    }
    const onRateChangeHandler = (e: any, index: any, values: any, setFieldValue: any) => {
        setBtnDisable(false);
        setFieldValue(`items[${index}].rate`, e.target.value)
        setFieldValue(`items[${index}].sub_total_amount`, (values.items[index].quantity) * (e.target.value))
    }

    const onQuantityChangeHandler = (e: any, index: any, values: any, setFieldValue: any) => {
        setBtnDisable(false);
        setFieldValue(`items[${index}].quantity`, e.target.value)
        setFieldValue(`items[${index}].sub_total_amount`, (values.items[index].rate) * (e.target.value))
    }

    const onDiscountChangeHandler = (e: any, index: any, values: any, setFieldValue: any) => {
        setBtnDisable(false);
        let discount = 0
        let discount_type = values.items[index].discount_type
        if (discount_type == "amt") {
            discount = e.target.value
        }
        else {
            discount = (values.items[index].sub_total_amount) * (e.target.value / 100)
        }
        setFieldValue(`items[${index}].discount`, e.target.value)
        let amount = (values.items[index].sub_total_amount) - (discount)
        setFieldValue(`items[${index}].amount`, amount)




    }

    React.useEffect(() => {
        dispatch(getInvoiceNumber({ "invoice_type": "domestic" }))
        dispatch(getOrganizationsDropdown())
        dispatch(getGoodsandServicesDropdown())
        dispatch(allCustomersDropdown())
    }, []);


    return (
        <React.Fragment>
            <BreadCrumbs crumbs={[{ title: 'Invoice' }, { title: 'Domestic', path: '' }, { title: 'Create Invoice' }]} />
            <Button variant="contained" className='mb-1' startIcon={<InsertDriveFileIcon />}>Domestic</Button>
            <CommonCard>
                <Formik
                    enableReinitialize={true}
                    initialValues={updatedDomesticModal}
                    validationSchema={DomesticSchema(updatedDomesticModal)}
                    onSubmit={(
                        values: domesticInvoiceDataTypes,
                        { setSubmitting }: FormikHelpers<domesticInvoiceDataTypes>
                    ) => {

                        onSaveInvoice(values)

                    }}
                >
                    {({ errors, touched, values, setFieldValue, setFieldTouched }) => (
                        <Form id='createDomesticInvoice'>
                            <section >
                                <div className='sectionHeader' >Organization</div>
                                <hr className='m-0'></hr>
                                <div className='field section-contant account'>
                                    <div className='d-flex sectionField mt-4  '>
                                        <label className='' htmlFor="organization">  Organization:<span className='text-danger mx-1  '>*</span></label>
                                        <SelectComponent
                                            id={"organization_id"}
                                            className="form-control"
                                            defaultValue={values.organization}
                                            isClearable={true}
                                            isSearchable={true}
                                            name={"organization"}
                                            options={organizationsDropdown}
                                            placeholder={"Select Organization"}
                                            onChange={(e: any) => organizationChangeHandler(e, setFieldValue)}
                                        />
                                    </div>
                                    {errors.organization_id && touched.organization_id ? <div className='errMsg'><ErrorMessage name={`organization_id`} /></div> : <span>&nbsp;</span>}
                                </div>
                            </section>
                            {/* {console.log(values.organization?)} */}

                            <section >
                                <div className='sectionHeader '>Customer</div>
                                <hr className='m-0'></hr>
                                <div className='field section-contant account'>
                                    <div className='d-flex sectionField mt-4 ' >
                                        <label htmlFor="customer"> Customer:<span className='text-danger mx-1  '>*</span></label>
                                        <SelectComponent
                                            id={"customer"}
                                            className="form-control "
                                            defaultValue={values.customer}
                                            isClearable={true}
                                            isSearchable={true}
                                            name={" customer_id"}
                                            options={customersDropdown}
                                            placeholder={"Select Customer"}
                                            onChange={(e: any) => customerChangeHandler(e, setFieldValue)}
                                        />
                                    </div>
                                    {errors.customer_id && touched.customer_id ? <div className='errMsg'><ErrorMessage name={`customer_id`} /></div> : <span>&nbsp;</span>}
                                </div>
                            </section>

                            <section>
                                <div className='sectionHeader '>Invoice Details</div>
                                <hr className='m-0'></hr>
                                <div className='section-contant' >

                                    <div className='d-flex section-Fields mt-4'>
                                        <div className='field w-100 mb-3'>
                                            <div className='sectionField'>
                                                <label htmlFor="invoice_number" className='w-label'> Invoice Number<span className='text-danger mx-1'>*</span></label>
                                                <Field placeholder='Invoice Number' className="form-control" name="invoice_number"
                                                    disabled={true}
                                                    onChange={(e: any) => {
                                                        onInputChangeHandler(e, setFieldValue);
                                                    }}
                                                />
                                            </div>
                                        </div>
                                        {errors.invoice_number && touched.invoice_number ? <div className='errMsg'><ErrorMessage name={`invoice_number`} /></div> : <span>&nbsp;</span>}
                                    </div>
                                    <div className='d-flex section-Fields mt-4'>
                                        <div className='field w-100 mb-3 me'>
                                            <div className='sectionField'>
                                                <label htmlFor="order_number" className='w-label'> Purchase Order Number<span className='text-danger mx-1'>*</span></label>
                                                <Field placeholder='Order Number' className="form-control" name="po_number"
                                                    // value={values.tin}
                                                    onChange={(e: any) => {
                                                        onInputChangeHandler(e, setFieldValue);
                                                    }}
                                                />
                                            </div>
                                            {errors.po_number && touched.po_number ? <div className='errMsg'><ErrorMessage name={`po_number`} /></div> : <span>&nbsp;</span>}
                                        </div>
                                        <div className='field w-100 me'>
                                            <div className='sectionField'>
                                                <label htmlFor="po_date" className='w-label'> Purchase Order Date<span className='text-danger mx-1'>*</span></label>
                                                <Field className="form-control" name="po_date"
                                                    type="date"
                                                    value={values.po_date}

                                                    onChange={(e: any) => {
                                                        onInputChangeHandler(e, setFieldValue);
                                                    }}
                                                />
                                            </div>
                                            {errors.po_date && touched.po_date ? <div className='errMsg'><ErrorMessage name={`po_date`} /></div> : <span>&nbsp;</span>}
                                        </div>
                                    </div>
                                    <div className='d-flex section-Fields mt-4 '>

                                        <div className='field w-50 me'>
                                            <div className='sectionField'>
                                                <label htmlFor="invoice_date" className='w-label'> Invoice Date<span className='text-danger mx-1'>*</span></label>
                                                <Field className="form-control" name="invoice_date"
                                                    type="date"
                                                    value={values.invoice_date}
                                                    onChange={(e: any) => {
                                                        onInputChangeHandler(e, setFieldValue);
                                                    }}
                                                />
                                            </div>
                                            {errors.invoice_date && touched.invoice_date ? <div className='errMsg'><ErrorMessage name={`invoice_date`} /></div> : <span>&nbsp;</span>}

                                        </div>
                                        <div className='field w-50 me'>
                                            <div className='sectionField'>
                                                <label htmlFor="due_date" className='w-label'> Due Date<span className='text-danger mx-1'>*</span></label>
                                                <Field className="form-control" name="due_date"
                                                    type="date"
                                                    value={values.due_date}
                                                    onChange={(e: any) => {
                                                        onInputChangeHandler(e, setFieldValue);
                                                    }}
                                                />
                                            </div>
                                            {errors.due_date && touched.due_date ? <div className='errMsg'><ErrorMessage name={`due_date`} /></div> : <span>&nbsp;</span>}
                                        </div>
                                        <div className='field w-50 me'>
                                            <div className='sectionField'>
                                                <label htmlFor="credit_period" className='w-label'> Credit Period<span className='text-danger mx-1'>*</span></label>
                                                <div className="" style={{ position: "relative" }}>
                                                    <span>
                                                        <Field className="form-control" name="credit_period"
                                                            type="text"
                                                            value={values.credit_period}
                                                            disabled={true}
                                                        // onChange={(e: any) => {
                                                        //     onInputChangeHandler(e, setFieldValue);
                                                        // }}
                                                        />
                                                    </span>
                                                    <span className="p-inputgroup-addon" style={{ width: 'auto', height: "33px", right: "0px", top: "0px", position: "absolute" }} > days</span>

                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                </div>
                            </section>


                            <section className='mt-1 d-flex mt-4'>

                                <div style={{ position: 'relative' }}>
                                    <div className='sectionHeader  mt-1'> Item Details </div>
                                    <hr className='m-0'></hr>
                                    <div className='section-contant'>
                                        <FieldArray
                                            name="items"
                                            render={({ insert, remove, push }) => (
                                                <div>
                                                    {values.items.length > 0 &&
                                                        values.items.map((item: any, index: any) => (
                                                            <div className="  mt-5" key={index} style={{ border: "1px solid", width: '950px', height: "185px", position: 'relative', borderRadius: "10px" }}>

                                                                <div className=' section-Fields Activity d-flex mt-3'>
                                                                    {/* <div className='field  '> */}
                                                                    <div className='Itemfields col-3 mb-3  '>
                                                                        <label htmlFor={`items.${index}.name`} >Activity</label>

                                                                        <SelectComponent

                                                                            id={"item"}
                                                                            className="form-control"
                                                                            defaultValue={values.items[index].itemName}
                                                                            isClearable={true}
                                                                            isSearchable={true}
                                                                            name={`items.${index}.item`}
                                                                            options={goodsAndServicesDropdown}
                                                                            placeholder={"Select Activity"}
                                                                            onChange={(e: any,) => onitemChangeHandler(e, index, setFieldValue, setFieldTouched)}
                                                                        />
                                                                        {errors.items ? <div className='errMsg'><ErrorMessage name={`items.${index}.item`} /></div> : <span>&nbsp;</span>}

                                                                        {/* <ErrorMessage name={`items.${index}.item`} /> */}
                                                                    </div>

                                                                    {/* </div> */}
                                                                    <div className="Itemfields" style={{ marginLeft: "13x", }}>
                                                                        <label htmlFor={`items.${index}.hsn_code`}>
                                                                            Hsn Code
                                                                        </label>
                                                                        <Field
                                                                            name={`items.${index}.hsn_code`}
                                                                            placeholder="Hsn Code"
                                                                            type="textarea"
                                                                            value={values.items[index].hsn_code}
                                                                            onChange={(e: any) => {
                                                                                onInputChangeHandler(e, setFieldValue);
                                                                            }}
                                                                        />

                                                                    </div>
                                                                    <div className=" Itemfields  " style={{ marginLeft: "13x", }}>
                                                                        <label htmlFor={`items.${index}.description`}>
                                                                            Description
                                                                        </label>
                                                                        <Field
                                                                            name={`items.${index}.description`}
                                                                            placeholder=" Description"
                                                                            type="textarea"
                                                                            value={values.items[index].description}
                                                                            onChange={(e: any) => {
                                                                                onInputChangeHandler(e, setFieldValue);
                                                                            }}
                                                                        />

                                                                        {errors.items && values.items[0].item ? <div className='errMsg'><ErrorMessage name={`items.${index}.description`} /></div> : <span>&nbsp;</span>}

                                                                    </div>
                                                                    <div className="Itemfields me-4 " style={{ width: "100px", height: "32px", marginLeft: "13px", }}>
                                                                        <label htmlFor={`items.${index}.quantity`}>
                                                                            Quantity
                                                                        </label>
                                                                        <Field
                                                                            name={`items.${index}.quantity`}
                                                                            placeholder="Quantity"
                                                                            type="number"
                                                                            value={values.items[index].quantity}
                                                                            disabled={values.items[index].save}
                                                                            onChange={(e: any) => { onQuantityChangeHandler(e, index, values, setFieldValue); }}
                                                                        />

                                                                        {errors.items && values.items[0].description ? <div className='errMsg'><ErrorMessage name={`items.${index}.quantity`} /></div> : <span>&nbsp;</span>}

                                                                    </div>
                                                                </div>
                                                                <div className=' section-Fields Activity  mb-5 d-flex '>

                                                                    <div className="Itemfields" style={{ marginLeft: "13x", }}>
                                                                        <label htmlFor={`items.${index}.rate`}>
                                                                            Rate
                                                                        </label>
                                                                        <Field
                                                                            name={`items.${index}.rate`}
                                                                            placeholder="Item rate"
                                                                            value={values.items[index].rate}
                                                                            type="number"
                                                                            disabled={values.items[index].save}
                                                                            onChange={(e: any) => {
                                                                                onRateChangeHandler(e, index, values, setFieldValue);
                                                                            }}

                                                                        // onChange={() => { onRateChangeHandler(index, setFieldValue); }}
                                                                        />

                                                                        {errors.items && values.items[0].quantity ? <div className='errMsg'><ErrorMessage name={`items.${index}.rate`} /></div> : <span>&nbsp;</span>}

                                                                    </div>


                                                                    <div className=' Itemfields ' style={{ marginLeft: "13x", padding: "5px" }}>
                                                                        {/* <div className=""> */}

                                                                        <label htmlFor={`items.${index}.sub_total_amount`}>
                                                                            sub_total_amount
                                                                        </label>
                                                                        <Field
                                                                            name={`items.${index}.sub_total_amount`}
                                                                            placeholder="sub_total_amount"
                                                                            type="textarea"
                                                                            disabled={true}
                                                                            value={values.items[index].sub_total_amount}

                                                                            onChange={(e: any) => { onDiscountChangeHandler(e, index, values, setFieldValue); }}
                                                                        />

                                                                        {/* </div> */}
                                                                    </div>

                                                                    <div className='Itemfields ' style={{ marginLeft: "13x", padding: "5px" }}>

                                                                        <label htmlFor={`items.${index}.discount`}>
                                                                            Discount
                                                                        </label>
                                                                        <div className="InputNumber ">


                                                                            <Field
                                                                                name={`items.${index}.discount`}
                                                                                placeholder="Discount"
                                                                                type="number"
                                                                                disabled={values.items[index].save}
                                                                                onChange={(e: any) => { onDiscountChangeHandler(e, index, values, setFieldValue) }}

                                                                            />

                                                                            <select className="p-inputgroup-addon col-2 D_select" style={{ width: 'auto', height: '31px', left: '148px' }}
                                                                                defaultValue={values.items[index].discount_type}
                                                                                onChange={(e) => {
                                                                                    onDiscountTypeChange(e, index, values, setFieldValue);
                                                                                }}
                                                                            >
                                                                                <option key={1} value="amt">₹</option>
                                                                                <option key={2} value="pct">%</option>
                                                                            </select>

                                                                            {errors.items && values.items[0].rate ? <div className='errMsg'><ErrorMessage name={`items.${index}.discount`} /></div> : <span>&nbsp;</span>}

                                                                        </div>
                                                                    </div>
                                                                    {/* <>{console.log("554", values)}</> */}

                                                                    <div className='Itemfields' style={{ marginLeft: "35px" }} >
                                                                        {/* <div className=""> */}

                                                                        <label htmlFor={`items.${index}.amount`}>
                                                                            Amount
                                                                        </label>
                                                                        <Field
                                                                            name={`items.${index}.amount`}
                                                                            placeholder="Amount"
                                                                            disabled={true}
                                                                        />
                                                                        {/* </div> */}
                                                                    </div>


                                                                </div>


                                                                <div style={{ right: "-25px", top: "38px", position: 'absolute' }}>
                                                                    <div className='mt-4 ' >



                                                                        {!values.items[index].save ?

                                                                            <CheckCircleOutlineIcon onClick={() => onSaverecord(index, values, setFieldValue)} />
                                                                            :
                                                                            <EditIcon onClick={() => onEditrecord(index, setFieldValue)} />
                                                                        }
                                                                    </div>

                                                                    <div className='mt-4 '>
                                                                        <DeleteIcon
                                                                            onClick={() => {
                                                                                onDeleteRecord(remove, index, values, setFieldValue)

                                                                            }}
                                                                        />
                                                                    </div>

                                                                </div>
                                                                <div className='text-danger' style={{ marginLeft: "26%", marginBlockStart: "-23px" }}>{addRemoveMsg}</div>
                                                            </div>




                                                        ))}




                                                    <button

                                                        type="button"
                                                        className="primary ms-4 mt-3 btnAddItem "
                                                        onClick={() => push({
                                                            item: "",
                                                            description: "",
                                                            quantity: "",
                                                            rate: "",
                                                            amount: "",
                                                            hsn_code: "",
                                                            discount: "",
                                                            discount_type: "pct",
                                                            cgst: "",
                                                            sgst: "",
                                                            igst: 0,
                                                            save: false,
                                                            cgst_amount: "",
                                                            sgst_amount: "",
                                                            igst_amount: 0,
                                                            sub_total_amount: ""
                                                        })}
                                                    >
                                                        Add Item  <span><AddCircleIcon /></span>
                                                    </button>
                                                </div>
                                            )}
                                        />
                                        <br />
                                    </div>
                                </div>
                            </section>
                            <section>
                                <div className='sectionHeader'>Bank Details</div>
                                <hr className='m-0'></hr>
                                <div className='field section-contant account' style={{ marginLeft: '135px' }}>
                                    <div className=' sectionField mt-4'>
                                        <div className='d-flex sectionField mt-4' >
                                            <label htmlFor="organization"> Bank:<span className='text-danger mx-1'>*</span></label>
                                            <SelectComponent
                                                id={"banking_id"}
                                                className="form-control"
                                                defaultValue={values.bank}
                                                isDisabled={selectbank}
                                                isClearable={true}
                                                isSearchable={true}
                                                name={"banking_id"}
                                                options={organizationBanks}
                                                placeholder={"Select bank"}
                                                onChange={(e: any) => bankChangeHandler(e, setFieldValue)}
                                            />
                                        </div>
                                    </div>
                                    {/* {errors.banking_id && values.organization_id ?  <div className='errMsg'>{errors.banking_id as string}</div> : <span>&nbsp;</span>} */}
                                    {errors.banking_id ? <div className='errMsg'><ErrorMessage name={`banking_id`} /></div> : <span>&nbsp;</span>}
                                </div>
                            </section>
                            <section className='mt-1 '>
                                {/* <h6 className='sectionHeader'>Customer Notes</h6> */}
                                {/* <hr className='m-0'></hr> */}
                                <div className='field section-contant'>
                                    <div className='d-flex section-Fields mt-4'>
                                        <div className='field w-50 sectionField m-4'>
                                            <label htmlFor="filename" style={{ marginInlineStart: "-40px" }}>Notes</label>
                                            <Field
                                                style={{ height: "120px", marginInlineStart: "-40px" }}
                                                className="form-control p-2 "
                                                as='textarea'
                                                name="customer_notes"
                                                id='filename'
                                                // placeholder={"Thank you note"}
                                                onChange={(e: any) => { onInputChangeHandler(e, setFieldValue); }}
                                            />
                                            {/* {errors.file && touched.file ? <div className='errMsg'><ErrorMessage name={`file`} /></div> : <span>&nbsp;</span>} */}
                                        </div>
                                        <div className='field w-50 sectionCard1' style={{ marginTop: "42px" }}>

                                            {/* <h6 style={{ display: "flex", justifyContent:"space-between" }}><span  className='sub'>sub_total_amount</span><span>0</span></h6> */}

                                            <div>
                                                <label><span>
                                                    sgst(₹)
                                                </span></label>
                                                <span style={{ float: "right" }}>
                                                    {totalsgst}
                                                </span>
                                            </div>

                                            <div>
                                                <label><span>
                                                    csgt(₹)
                                                </span></label>
                                                <span style={{ float: "right" }}>
                                                    {totalcgst}
                                                </span>
                                            </div>

                                            <div>
                                                <label><span>
                                                    igst(₹)
                                                </span></label>
                                                <span style={{ float: "right" }}>
                                                    {totaligst}
                                                </span>
                                            </div>


                                            <div className='mt-3' style={{ display: "flex", justifyContent: "space-between", fontWeight: "bold" }}>
                                                <label><span>
                                                    Total(₹)
                                                </span></label>
                                                <span style={{ float: "right" }}>
                                                    {totalAmount}
                                                </span>
                                            </div>
                                            {/* {errors.total_amount ? <div className='errMsg'><ErrorMessage name={`{errors.total_amount as string}`} /></div> : <span>&nbsp;</span>} */}
                                        </div>
                                    </div>
                                </div>
                            </section>




                            <div className='d-flex justify-content-end buttons'>
                                <button type='button' onClick={backToHome} className='btn-esecondary px-4 mx-2 mt-4'>Cancel</button>
                                {props.create && <button className='btn-eprimary  mx-2 mt-4' onClick={() => saveAndDownload(values)}> save & Download</button>}
                                <button type='submit' className={btnDisabled ? 'btn-esecondary px-4 mt-4' : 'btn-eprimary px-4 mt-4'} disabled={btnDisabled}>
                                    {props.create ? "Save as draft" : "Update"}</button>
                            </div>



                        </Form>
                    )}

                </Formik>
            </CommonCard>

        </React.Fragment >
    );
}



export default DomesticInvoice;







