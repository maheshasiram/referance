import * as Yup from "yup";

export const DomesticSchema = (DomesticDetails: any) => {
    return Yup.object().shape({
        organization_id: Yup.string().required("Please Select organization Name").nullable(),
        customer_id: Yup.string().required("Please Select Customer ").nullable(),
        invoice_number: Yup.string().required("Please Enter Invoice Number").nullable(),
        po_number: Yup.string().required("Please Enter Purchase Order Number").nullable(),
        po_date: Yup.string().required("Please Enter Purchase Order Date").nullable().max(10,'Invalid Date '),
        invoice_date: Yup.string().required("Please Select Invoice Date").max(10,'Invalid Date '),
        due_date: Yup.string().required("Please Select Due Date").max(10,'Invalid Date '),
        banking_id: Yup.string().required("Please Select Bank "),
        //credit_period: Yup.string().required("Please Enter Credit Period" )   
        items: Yup.array().of(Yup.object().shape({
            item: Yup.string()
                .required('Please Enter Activity').nullable(),
            description: Yup.string()
                .required('Please Enter Description').nullable(),
            quantity: Yup.string()
                .required('Please Enter Quantity').nullable(),
            rate: Yup.string()
                .required('Please Enter Rate').nullable(),
            discount: Yup.string()
                .required('Please Enter Discount').nullable()            
        }))
       
})
}