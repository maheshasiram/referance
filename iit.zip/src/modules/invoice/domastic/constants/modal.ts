import { domesticInvoiceDataTypes } from "./dataTypes";
import moment from 'moment';


export const domesticInvoiceModal: domesticInvoiceDataTypes = {
  organization: "",
  customer: "",
  organization_id: "",
  banking_id: "",
  customer_id: "",
  invoice_number: "",
  po_number: "",
  po_date: "",
  credit_period: "",
  invoice_date: moment().format("YYYY-MM-DD"),
  due_date: '',
  items: [{
    item: "",
    description: "",
    quantity: "",
    rate: "",
    amount: "",
    hsn_code: "",
    discount: "",
    discount_type: "pct",
    cgst: "",
    sgst: "",
    igst: 0,
    save: false,
    cgst_amount: "",
    sgst_amount: "",
    igst_amount: 0,
    sub_total_amount: ""
  },],
  total_sgst_amount: 0.0,
  total_cgst_amount: 0.0,
  total_igst_amount: 0.0,
  total_amount: 0.0,
  customer_notes: "",
  type: "domestic",
  bank: "",
}