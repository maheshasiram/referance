export type domesticInvoiceDataTypes ={
    bank: any;
    customer: any;
    organization:string,
    organization_id: string;
    banking_id:string;
    customer_id:string;
    invoice_number:string;
    po_number:string;
    po_date:any;
    credit_period:any;
    invoice_date:any;
    due_date:any;
    items:any;
    total_sgst_amount:any;
    total_cgst_amount:any;
    total_igst_amount:any;
    total_amount:any;
    customer_notes:string;
    type:string
 
   

}