import React from 'react'
import InvoiceDasboard from '../pdf/InvoiceDashboard';
import QuotationDasboard from '../quotation/domestic/QuotationDashboard';

function Home() {
  return (
    <div>
      Home
      <div style={{marginBottom:"30px"}}>
      <InvoiceDasboard  />
      </div>
      <div style={{marginBottom:"30px"}}>
      {/* <QuotationDasboard /> */}
      </div>
    
    </div>
  )
}

export default Home;