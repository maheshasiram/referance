import { useDispatch } from "react-redux";
import { NavLink } from "react-router-dom";
import { Types } from "../../constants/Types";
import { domesticInvoiceModal } from "../../modules/invoice/domastic/constants/modal";
import { internationalInvoiceModal } from "../../modules/invoice/international/constants/modal";
import { domesticQuotationModal } from "../../modules/quotation/domestic/constants/modal";
import { Types as quotationTypes } from "../../modules/quotation/domestic/reducer/Types";

function Navbar() {
  const dispatch = useDispatch();
  return (
    <div className="enav-bar">
      <nav className="container enav-container navbar navbar-expand-lg">
        <div className='nav-elements'>
          <ul>
            <li><NavLink to='/home'>Home</NavLink></li>
            <li className="nav-item dropdown">
              <a className="nav-link dropdown-toggle" href="#" role="button"
                data-bs-toggle="dropdown" aria-expanded="false">Invoice</a>
              <ul className="dropdown-menu">
              <NavLink onClick={()=>{dispatch({type:Types.DOMESTIC_INVOICE_DATA,payload:domesticInvoiceModal})}} className="dropdown-item" to='/domestic' >Domestic</NavLink>
              <NavLink onClick={()=>{dispatch({type:Types.INTERNATIONAL_INVOICE_DATA,payload:internationalInvoiceModal})}}className="dropdown-item" to='/international' >International</NavLink>
          
              </ul>
            </li>
            <li className="nav-item dropdown">
              <a className="nav-link dropdown-toggle" href="#" role="button"
                data-bs-toggle="dropdown" aria-expanded="false">Quotation</a>
              <ul className="dropdown-menu">
              <NavLink onClick={()=>{dispatch({type:quotationTypes.DOMESTIC_QUOTATION_DATA,payload:domesticQuotationModal})}} className="dropdown-item" to='/domesticQuotation' >Domestic</NavLink>
              <NavLink className="dropdown-item" to='/internationalQuotation' >International</NavLink>
          
              </ul>
            </li>
            <li className="nav-item dropdown">
              <a className="nav-link dropdown-toggle" href="#" role="button"
                data-bs-toggle="dropdown" aria-expanded="false">Masters</a>
              <ul className="dropdown-menu">
                <NavLink className="dropdown-item" to='/customers'>Customers</NavLink>
                <NavLink className="dropdown-item" to='/vendors' >Vendors</NavLink>
                <NavLink className="dropdown-item" to='/goodsandservices' >Goods and Services</NavLink>
              </ul>
            </li>
            <li className="nav-item dropdown">
              <a className="nav-link dropdown-toggle" href="#" role="button"
                data-bs-toggle="dropdown" aria-expanded="false">Portfolio</a>
              <ul className="dropdown-menu">
                <NavLink className="dropdown-item" to='/organization' >Organization</NavLink>
                <NavLink className="dropdown-item" to='/banking'>Banking</NavLink>
              </ul>
            </li>
            <li><NavLink to="/userManagement">User Management</NavLink></li>
          </ul>
        </div>
      </nav>
    </div>
  )
}
export default Navbar;