import React from "react";
import logo from "../../assets/MicrosoftTeams-image.png"
import { Carousel } from 'primereact/carousel';
import image1 from "../../assets/login1.png"
import image2 from "../../assets/login2.png"
import image3 from "../../assets/login3.png"
import CommonCard from "../../common/CommonCard";

function Login(props: any) {

    const [isAuth, setIsAuth] = React.useState(false);
    const [formValues, setFormValues] = React.useState({ username: "", password: "" });
    const [formErrors, setFormErrors] = React.useState({ username: false, password: false });
    const responsiveOptions = [
        {
            breakpoint: '1199px',
            numVisible: 1,
            numScroll: 1
        },
        {
            breakpoint: '991px',
            numVisible: 1,
            numScroll: 1
        },
        {
            breakpoint: '767px',
            numVisible: 1,
            numScroll: 1
        }
    ];

    const products: string[] = [image1, image2, image3]

    const productTemplate = (product: any) => {
        return (

            <div className="border-1 surface-border border-round m-2 text-center py-5 px-3">
                <div className="mb-3">
                    <img src={product} className="w-6 shadow-2" />
                </div>
            </div>
        );
    };


    const handleSubmit = (e: any) => {
        e.preventDefault();
        if (validate(formValues)) {
            alert("login Sucess")
        }
    }

    const validate = (values: any) => {
        const errors = {
            username: false,
            password: false
        };
        if (!values.username) {
            errors.username = true
        }
        if (!values.password) {
            errors.password = true
        }
        setFormErrors(errors);
        if (errors.username || errors.password) {
            return false
        }
        return true;
    }

    const handleChange = (e: any) => {
        const { name, value } = e.target;
        setIsAuth(false);
        setFormValues({ ...formValues, [name]: value });
        setFormErrors({ ...formErrors, [name]: value ? false : true })
    }


    return (
        <div className="loginPage">
            <CommonCard>
                <React.Fragment>
                    <div className="loginCard">
                        <div className="loginForm">
                            <img src={logo} />
                            <h2>sign in</h2>
                            <p>to access invoice </p>
                            
                            <form onSubmit={handleSubmit}>
                                <div style={{ width: 300, fontSize: 13, color: '#eee', textAlign: 'center' }}>
                                    {(isAuth) && <span>Please Enter Valid Username / Password!</span>}
                                </div>
                                <div className="form-outline">
                                    <label className="form-label" htmlFor="form3Example3">User Id</label>
                                    <input type="text"
                                        name="username"
                                        className="form-control form-control-lg"
                                        value={formValues.username}
                                        onChange={handleChange}
                                        placeholder="Enter email or phone number" />
                                    <div style={{ width: '100%', padding: 5, fontSize: 13 }}>
                                        {formErrors.username && <span id="usernameError">Please Enter Valid User Name!</span>}&nbsp;
                                    </div>
                                </div>

                                <div className="form-outline ">
                                    <label className="form-label" htmlFor="form3Example4">Password</label>
                                    <input type="password"
                                        className="form-control form-control-lg"
                                        name="password"
                                        value={formValues.password}
                                        onChange={handleChange}
                                        placeholder="Enter password" />
                                    <div style={{ width: '100%', padding: 5, fontSize: 13 }}>
                                        {formErrors.password && <span id="usernameError">Please Enter Valid Password!</span>}&nbsp;
                                    </div>
                                </div>

                                <div className="text-center text-lg-start pt-1">
                                    <button className="btn btn-primary btn-lg"
                                        onClick={handleSubmit}
                                        style={{
                                            paddingLeft: 2.5 + 'rem',
                                            paddingRight: 2.5 + 'rem',
                                            width: '100%'
                                        }}
                                    >Login</button>
                                </div>
                            </form>
                        </div>
                        <div className="card">
                            <Carousel value={products} numVisible={1} numScroll={1} responsiveOptions={responsiveOptions}
                                className="custom-carousel" circular
                                autoplayInterval={2300} itemTemplate={productTemplate} />
                        </div>
                    </div>
                </React.Fragment>
            </CommonCard>
        </div>
    )
}

export default Login;