import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import PublicRoute from "./PublicRoute";
import PrivateRoute from "./PrivateRoute";
import Login from '../components/LOGIN/Login'
import AppHeader from "../components/header/AppHeader";
import Home from "../modules/home/Home";
import Banking from "../modules/portfolio/banking/BankingDashboard";
import OrganizationDashboard from "../modules/portfolio/oraganisation/OrganizationDashboard";
import UserManagement from "../modules/userManagement/UserManagement";
import Customersdashboard from "../modules/masters/customers/CustomersDahboard";
import Vendors from "../modules/masters/vendors/VendorsDashboard";
import GoodsAndServices from "../modules/masters/goodsAndServices/GoodsAndServices";
import Domastic from "../modules/invoice/domastic/Domastic";
import International from "../modules/invoice/international/International";
import { ToastProvider } from "react-toast-notifications";
import SnackBarToast from "../common/modals/SnackBarToast";
import CreateCustomer from "../modules/masters/customers/CreateCustomer";
import CreateVendor from "../modules/masters/vendors/CreateVendor";
import PdfViewer from "../modules/pdf/PdfViewer";
import DomesticQuotation from "../modules/quotation/domestic/DomesticQuotation";
import QuotationViewer from "../modules/pdf/QuotationViewer";


function Root(props: any) {
    const [isAuthenticated, setIsAuthenticated] = React.useState(true);
    return (
        <React.Fragment>
            <BrowserRouter>
                {isAuthenticated && <AppHeader />}
                <div className="container">
                    <div className='Toast-Alert-Container' >
                        <ToastProvider>
                            <SnackBarToast />
                        </ToastProvider>
                    </div>
                    <Routes>
                        <Route path="/" element={
                            <PublicRoute isAuthenticated={isAuthenticated} to="/home" >
                                <Login />
                            </PublicRoute>
                        }>
                        </Route>
                        <Route path="/home" element={
                            <PrivateRoute isAuthenticated={isAuthenticated} to="/">
                                <Home />
                            </PrivateRoute>
                        }></Route>
                        <Route path="/organization" element={
                            <PrivateRoute isAuthenticated={isAuthenticated} to="/">
                                <OrganizationDashboard />
                            </PrivateRoute>
                        }></Route>
                        <Route path="/banking" element={
                            <PrivateRoute isAuthenticated={isAuthenticated} to="/">
                                <Banking />
                            </PrivateRoute>
                        }></Route>
                        <Route path="/userManagement" element={
                            <PrivateRoute isAuthenticated={isAuthenticated} to="/">
                                <UserManagement />
                            </PrivateRoute>
                        }></Route>
                        <Route path="/customers" element={
                            <PrivateRoute isAuthenticated={isAuthenticated} to="/">
                                <Customersdashboard />
                            </PrivateRoute>
                        }></Route>
                        <Route path="/customers/:id" element={
                            <PrivateRoute isAuthenticated={isAuthenticated} to="/">
                                <CreateCustomer />
                            </PrivateRoute>
                        }></Route>
                        <Route path="/vendors" element={
                            <PrivateRoute isAuthenticated={isAuthenticated} to="/">
                                <Vendors />
                            </PrivateRoute>
                        }></Route>
                        <Route path="/vendors/:id" element={
                            <PrivateRoute isAuthenticated={isAuthenticated} to="/">
                                <CreateVendor />
                            </PrivateRoute>
                        }></Route>
                        <Route path="/goodsandservices" element={
                            <PrivateRoute isAuthenticated={isAuthenticated} to="/">
                                <GoodsAndServices />
                            </PrivateRoute>
                        }></Route>
                        <Route path="/domestic" element={
                            <PrivateRoute isAuthenticated={isAuthenticated} to="/">
                                <Domastic create={true} />
                            </PrivateRoute>
                        }></Route>
                        <Route path="/domestic/:id" element={
                            <PrivateRoute isAuthenticated={isAuthenticated} to="/">
                                <Domastic create={false} />
                            </PrivateRoute>
                        }></Route>
                        <Route path="/international" element={
                            <PrivateRoute isAuthenticated={isAuthenticated} to="/">
                                <International create={true} />
                            </PrivateRoute>
                        }></Route>
                        <Route path="/international/:id" element={
                            <PrivateRoute isAuthenticated={isAuthenticated} to="/">
                                <International create={false} />
                            </PrivateRoute>
                        }></Route>

                        <Route path="/domesticQuotation" element={
                            <PrivateRoute isAuthenticated={isAuthenticated} to="/">
                                <DomesticQuotation create={true}/>
                            </PrivateRoute>
                        }></Route>
                          <Route path="/domesticQuotation/:id" element={
                            <PrivateRoute isAuthenticated={isAuthenticated} to="/">
                                <DomesticQuotation create={false}/>
                            </PrivateRoute>
                        }></Route>
                        <Route path="/viewinvoice" element={
                            <PrivateRoute isAuthenticated={isAuthenticated} to="/">
                                <PdfViewer />
                            </PrivateRoute>
                        }></Route>
                         <Route path="/viewquotation" element={
                            <PrivateRoute isAuthenticated={isAuthenticated} to="/">
                                <QuotationViewer />
                            </PrivateRoute>
                        }></Route>
                    </Routes>
                </div>
            </BrowserRouter>
        </React.Fragment>
    )

}
export default Root