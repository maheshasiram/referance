test('renders learn react link', () => {
  const count = 1;
  expect(count).toEqual(1);
});
