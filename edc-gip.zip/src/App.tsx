import React  from 'react';
import { useSelector } from 'react-redux';
import './App.scss';
import Loader from './common/loader/Loader';
import AlertDialog from './common/modals/AlertDialog';
import Root from './routes/Routes';

function App() {
  const {isLoader} = useSelector((state: any) => state.application);
  
  return (
    <div className="App">
     {isLoader && <Loader />}
      <AlertDialog />     
      <Root/>      
    </div>
  );
}

export default App;
