import { styled } from '@mui/material/styles';
import Tooltip, { TooltipProps, tooltipClasses } from '@mui/material/Tooltip';
import React  from 'react';

const BootstrapTooltip = styled(({ className, ...props }: TooltipProps) => (
  <Tooltip {...props} arrow classes={{ popper: className }} />
))(() => ({
  [`& .${tooltipClasses.arrow}`]: {
    color: '#696969fa',
    // color: theme.palette.common.black,
  },
  [`& .${tooltipClasses.tooltip}`]: {
    // backgroundColor: theme.palette.common.black,
    backgroundColor: '#696969fa',
  },
}));

function CustomToolTip(props: any) {
  const { title } = props;
  return (
      <BootstrapTooltip title={title}>
        {props.children}
      </BootstrapTooltip>
  );
}
export default CustomToolTip;