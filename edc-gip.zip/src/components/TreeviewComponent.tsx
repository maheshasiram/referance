import React from 'react'
import { Tree } from 'primereact/tree';
// import ListAltIcon from '@mui/icons-material/ListAlt';
import Loader from '../common/loader/Loader';
// import { useDispatch } from 'react-redux';
// import { classNames } from "primereact/utils";
import SvgIcon from '@mui/material/SvgIcon';
import DisabledByDefaultOutlinedIcon from '@mui/icons-material/DisabledByDefaultOutlined';
// import CustomToolTip from './CustomToolTip';
import { useSelector } from 'react-redux';
import ListCustomToolTip from './ListCustomDialog';

function TreeviewComponent(props: any) {
  const { data, onCheckBoxClick, payload, type } = props;
  const { configCodes } = useSelector((state: any) => state.application);

  const onDragTreeviewNode = (node: any) => {
    props.onDragTreeviewNode(node);
  }
  const ondragEnd = () => {
    // console.log(e)
    props.ondragEnd()
  }

  console.log("...derivation", type);
  const groupFields = (node: any) => {
    let _className = false
    if (type === 'derivatives' && ((node.groupId && node.children) || (node.groupId && !(node.children)))) {
      // console.log('node.............', node)
      _className = true
    }
    return _className
  }

  const renderVisitFields = (node: any) => {
    let _className = true
    if (payload?.visits?.length > 0) {
      if (node.children) {
        let _flag = false
        node?.children?.map((grpEle: any) => {
          let _itemFlag = true
          payload?.visits?.map((item: any) => {
            const _inList = grpEle?.visits?.some((i: any) => i.id === item)
            if (!_inList) {
              _itemFlag = false
            }
            return null;
          })
          if (_itemFlag) {
            _flag = true
          }
          return null;
        })
        if (_flag) {
          _className = true
        } else {
          _className = false
        }

      } else {
        let _inList: any;

        payload?.visits?.map((item: any) => {
          _inList = node?.visits?.some((i: any) => i.id === item)
          if (!_inList) {
            // _className = 'text-danger'
            _className = false
            // setDragNode(false)
          }
          return null;
        })
      }

      payload?.dependentFields?.map((item: any) => {
        if (!item.groupId) {
          // console.log("non group node", node)
          if (node.groupId && !node.children) {
            _className = false
          }
        } else {
          if (node.children || !node.groupId) {
            _className = false
          }
        }
        return null;
      })
    }
    return _className
  }

  const FieldVisitList = (node: any) => {
    let _visitsList = []
    if (!(node.children)) {
      // _visitsList = node?.visits?.map((item: any) => item.visitName)
      _visitsList = node?.visits?.map((item: any) => <div className='tooltip-list'>{item.visitName}</div>)
      // console.log('node.......', node);
    }
    // return _visitsList?.join(' , ')
    return _visitsList
  }

  const nodeTemplate = (node: any, parent: any) => {
    const label = node.label ? node.label : node.text;
    const key = node.key;
    const child = node.children

    // console.log('79...', child);

    return (
      <React.Fragment>
        {props.destinationCheckBox ? (!child && <input checked={node.selected} type="checkbox"
          onChange={(event: any) => onCheckBoxClick(event, node, parent)}
          disabled={node.disabled ? true : false}
        />) : ''}
        {
          props.checkbox ? (<input checked={node.selected} type="checkbox"
            onChange={(event: any) => onCheckBoxClick(event, node, parent)}
            disabled={node.disabled ? true : false}
          />) : ''
        } 

        <span
          // className={`d-flex align-items-center ${renderVisitFields(node) ? 'draggable-label' : 'non-draggable-label'}`}
          className={type === 'fld' ? `d-flex align-items-center ${renderVisitFields(node) ? 'draggable-label' : 'non-draggable-label'}` : type === 'derivatives' ? `d-flex align-items-center ${groupFields(node) ? 'non-draggable-label' : 'draggable-label'}` : ''}
          id={label}
          key={key}
          draggable={type === 'fld' ? (renderVisitFields(node) ? true : false) : true}
          onDragStart={type === 'fld' ? (renderVisitFields(node) ? () => onDragTreeviewNode(node) : () => { return null }) :
            (() => onDragTreeviewNode(node))}
          onDragEnd={type === 'fld' ? (renderVisitFields(node) ? () => ondragEnd() : () => { return null }) : () => ondragEnd()}
        >
          {/* {type === 'fld' ? <CustomToolTip title={FieldVisitList(node)}>{<label className={renderVisitFields(node) ? 'draggable-label' : 'non-draggable-label'} >{label}</label>}</CustomToolTip> :
            type === 'derivatives' ? <CustomToolTip title={FieldVisitList(node)}>{<label className={node.disabled ? 'text-secondary' : ''} >{label}</label>}</CustomToolTip> : <CustomToolTip title={FieldVisitList(node)}>{<label className={node.disabled ? 'text-secondary' : ''} >{label}</label>}</CustomToolTip>
          } */}
          {type === 'fld' ? <ListCustomToolTip title={FieldVisitList(node)}>{<label className={renderVisitFields(node) ? 'draggable-label' : 'non-draggable-label'} >{label}</label>}</ListCustomToolTip> :
            type === 'derivatives' ? <ListCustomToolTip title={FieldVisitList(node)}>{<label className={groupFields(node) ? 'non-draggable-label' : 'draggable-label'} >{label}</label>}</ListCustomToolTip> : <ListCustomToolTip title={FieldVisitList(node)}>{<label className={node.disabled ? 'text-secondary' : ''} >{label}</label>}</ListCustomToolTip>
          }
          {/* <CustomToolTip title={FieldVisitList(node)}>{<label className={groupFields(node) ? 'non-draggable-label' : 'draggable-label'} >{label}</label>}</CustomToolTip> : */}
          {(node.datatype) && (node.responseType && (node.responseType.code === configCodes?.radio || node.responseType.code === configCodes?.checkbox || node.responseType.code === configCodes?.['multi-select'] ||
            node.responseType.code === configCodes?.['single-select'])) ?
            <span > ({node.datatype.name + '/' + node.responseType.name}) </span> :
            (node.datatype) && <span > ({node.responseType.code === configCodes?.textarea ? node.responseType.name : node.datatype.name}) </span>
          }
        </span>
      </React.Fragment >
    );
  };
  const togglerTemplate = (node: any, options: any) => {
    const expanded = options.expanded;
    if (node.children) {
      return (
        <button
          type="button"
          className="p-tree-toggler p-link"
          tabIndex={-1}
          onClick={options.onClick}
        >
          {expanded ?
            <div className='d-flex custom-toogle-icon' >
              <SvgIcon fontSize="inherit" className='close-svg' style={{ width: '12px', height: '12px' }} {...props}>
                <path d="M22.047 22.074v0 0-20.147 0h-20.12v0 20.147 0h20.12zM22.047 24h-20.12q-.803 0-1.365-.562t-.562-1.365v-20.147q0-.776.562-1.351t1.365-.575h20.147q.776 0 1.351.575t.575 1.351v20.147q0 .803-.575 1.365t-1.378.562v0zM17.873 11.023h-11.826q-.375 0-.669.281t-.294.682v0q0 .401.294 .682t.669.281h11.826q.375 0 .669-.281t.294-.682v0q0-.401-.294-.682t-.669-.281z" />
              </SvgIcon>
            </div>
            :
            <div className='d-flex custom-toogle-icon'>
              <SvgIcon fontSize="inherit" className='expand-svg' style={{ width: '12px', height: '12px' }} {...props}>
                <path d="M22.047 22.074v0 0-20.147 0h-20.12v0 20.147 0h20.12zM22.047 24h-20.12q-.803 0-1.365-.562t-.562-1.365v-20.147q0-.776.562-1.351t1.365-.575h20.147q.776 0 1.351.575t.575 1.351v20.147q0 .803-.575 1.365t-1.378.562v0zM17.873 12.977h-4.923v4.896q0 .401-.281.682t-.682.281v0q-.375 0-.669-.281t-.294-.682v-4.896h-4.923q-.401 0-.682-.294t-.281-.669v0q0-.401.281-.682t.682-.281h4.923v-4.896q0-.401.294-.682t.669-.281v0q.401 0 .682.281t.281.682v4.896h4.923q.401 0 .682.281t.281.682v0q0 .375-.281.669t-.682.294z" />
              </SvgIcon>
            </div>
          }
        </button>
      );
    } else {
      return (
        <DisabledByDefaultOutlinedIcon sx={{ width: 16, height: 16, fill: '#91c6ef' }} />
      )
    }
  };
  return (
    <React.Fragment>
      <div className='treeViewComponent'>
        {!data && <Loader />}
        <Tree
          id={props.id}
          value={data}
          filter
          filterMode="lenient"
          filterPlaceholder={props.placeholder}
          nodeTemplate={nodeTemplate}
          contentClassName="custom-tree-container"
          dragdropScope="unique"
          selectionMode='single'
          className="treeData"
          togglerTemplate={togglerTemplate}
        // onSelectionChange={(e: any) => setSelectedKey(e.id)}
        />
      </div>
    </React.Fragment>
  )
}
export default TreeviewComponent