import React from "react";

function SignIn () {
    return(
        <div>
            <h1>Sign IN</h1>
        </div>
    )
}
export default SignIn;