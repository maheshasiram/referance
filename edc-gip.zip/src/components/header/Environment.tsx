import React from 'react'
import AutoAwesomeMotionIcon from '@mui/icons-material/AutoAwesomeMotion';
// import EnvironmentIcon from '../../common/Assests/Images/EnvironmentIcon.png'
import Box from '@mui/material/Box';
// import List from '@mui/material/List';
// import ListItem from '@mui/material/ListItem';
// import ListItemText from '@mui/material/ListItemText';
// import ListItemAvatar from '@mui/material/ListItemAvatar';
import Avatar from '@mui/material/Avatar';
// import Typography from '@mui/material/Typography';
import uat from '../../common/Assests/Images/uat.png'
import MenuItem from '@mui/material/MenuItem';
import Menu from '@mui/material/Menu';
// import Divider from '@mui/material/Divider';
import '../header/styles.scss'
import production from '../../common/Assests/Images/production.png'
import developmentSelected from '../../common/Assests/Images/developmentSelected.png'

function Environment() {
    const [environment, setEnvironment] = React.useState<null | HTMLElement>(null);
    const open = Boolean(environment);
    // const [envAnchorEl, setEnvAnchorEl] = React.useState<null | HTMLElement>(null);

    const handleOpen = (event: React.MouseEvent<HTMLElement>) => {
        setEnvironment(event.currentTarget);
    }

    const handleClose = () => {
        // setEnvAnchorEl(null);
        setEnvironment(null);
    }

    return (
        <React.Fragment>
            <div>
                <React.Fragment>
                    <div onClick={handleOpen}>
                        <AutoAwesomeMotionIcon className='envImage' />
                    </div>
                    {/* <img src={EnvironmentIcon} onClick={onEnvironment} alt="" /> */}
                    <Box sx={{ flexGrow: 1 }} >
                        <div>
                            <Menu
                                anchorEl={environment}
                                id="account-menu"
                                open={open}
                                className="env-icon"
                                onClose={handleClose}
                                onClick={handleClose}
                                PaperProps={{
                                    elevation: 0,
                                    sx: {
                                        overflow: 'visible',
                                        filter: 'drop-shadow(0px 2px 4px rgba(0,0,0,0.22))',
                                        mt: 1,
                                        width: 240,
                                        height: 200,
                                        '& .MuiAvatar-root': {
                                            width: 32,
                                            height: 32,
                                            ml: -0.5,
                                            mr: 1,
                                        },
                                        '&:before': {
                                            content: '""',
                                            display: 'block',
                                            position: 'absolute',
                                            top: 0,
                                            right: 14,
                                            width: 10,
                                            height: 10,
                                            bgcolor: 'background.paper',
                                            transform: 'translateY(-50%) rotate(45deg)',
                                            zIndex: 0,
                                        },
                                    },
                                }}
                                transformOrigin={{ horizontal: 'right', vertical: 'top' }}
                                anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
                            >
                                <MenuItem className='header'>
                                    <div>
                                        <label>Environment</label></div>
                                </MenuItem>
                                <div className='notification-container'>
                                        <MenuItem className='envItems'>
                                            <div className='d-flex item-list'>
                                            <span>
                                                    <Avatar alt="dev" src={developmentSelected} className='devEnv' />
                                            </span>
                                            <span className='envVar'>DEV</span>
                                            </div>
                                    </MenuItem>
                                        <MenuItem className='envItems'>
                                            <div className='d-flex item-list'>
                                            <span>
                                                    <Avatar alt="UTA" src={uat} className='utaEnv' />
                                            </span>
                                            <span className='envVar'>UAT</span>   
                                            </div>
                                    </MenuItem>
                                        <MenuItem className='envItems'>
                                            <div className='d-flex item-list'>
                                            <span>
                                                    <Avatar alt="production" src={production} className='productionEnv' />
                                            </span>
                                            <span className='envVar'>PROD</span>
                                            </div>
                                        </MenuItem>

                                </div>
                            </Menu>
                        </div>

                    </Box>

                </React.Fragment>
            </div>
        </React.Fragment>
    )
}

export default Environment