import * as React from 'react';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import CustomDialog from '../../../common/modals/CustomeDialog'
// import informationObj from '../../constants/informationObj.json'
import information from '../../../constants/information.json'
// import { InformationIcons } from './InformationIcons';
import { ApplicationIcons } from '../../../common/Assests/ApplicationIcons';


function InformationLogo() {
    const [open, setOpen] = React.useState(false)

    const onOpenDialog = () => {
        setOpen(true)
    };
    const onCloseDilog = () => {
        setOpen(false);

    };
    const openInfoIcon = () => {
         setOpen(false);
    };

    return (
        <React.Fragment>
            <CustomDialog
                open={open}
                title={"Legends"}
                fullWidth={true}
                maxWidth='md'
                actionType={"Close"}
                onClose={onCloseDilog}
                onSubmitHandler={openInfoIcon}
            >
                <div className='Information-data-alignment'> {information.map((item: any,index:number) => {
                    const Component = ApplicationIcons[item.icon];
                    if (item.icon && item.icon !== "")
                        {return <div key={index} className='icon-container' >
                            <Component />
                            {item.label}
                        </div>}
                        return null;
                })}
                </div>
            </CustomDialog>

            <InfoOutlinedIcon
            className='info-icon'
                onClick={onOpenDialog}
            />

        </React.Fragment>
    )
}
export default InformationLogo;