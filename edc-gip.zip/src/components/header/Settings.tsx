import * as React from 'react';
import _ from "lodash";
import Drawer from '@mui/material/Drawer';
import Box from '@mui/material/Box';
import Divider from '@mui/material/Divider';
import SettingsIcon from '@mui/icons-material/Settings';
import TabList from '@mui/lab/TabList';
import TabContext from '@mui/lab/TabContext';
import TabPanel from '@mui/lab/TabPanel';
import { Tab } from '@mui/material';
import { Types } from "../../constants/Types"
import SearchField from '../../common/searchField/SearchField';
import CloseIcon from '@mui/icons-material/Close';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import IconButton from '@mui/material/IconButton';
import { useDispatch, useSelector } from "react-redux";
import { RolesData } from '../../constants/RolesData';
import { fetchAllConfigData, getAllStudies, toastAlert } from '../../actions/actions';
import { getCurrentStudyDetails } from '../../modules/studySetup/modules/study/actions/actions';
import { approveOrRejectStudyByAdmin } from '../../modules/userManagement/actions/actions';

function Settings() {
    type Anchor = 'right';
    const dispatch = useDispatch();
    const [value, setValue] = React.useState('1');
    const [searchVal, setSearchVal] = React.useState('');
    const [open, setOpen] = React.useState(false);
    const loaded = React.useRef(false);

    React.useEffect(() => {
        if (!loaded.current) {
            dispatch(getAllStudies())
            let payload = { userName: 'bbade', status: true }
            dispatch(fetchAllConfigData((data: any) => {
                let payload = { userName: 'bbade', status: data?.Approved }
                dispatch(approveOrRejectStudyByAdmin(payload, (data: any) => console.log('36......cl', data)))
            }))
            dispatch(approveOrRejectStudyByAdmin(payload, (data: any) => console.log('36......cl', data)))
            dispatch({ type: Types.FETCH_ROLES, payload: RolesData });
            loaded.current = true;
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const { studies, roles, studiesCopy, rolesCopy } = useSelector((state: any) => state.application);

    const handleChange = (event: React.SyntheticEvent, newValue: string) => {
        setValue(newValue);
        setSearchVal('');
        dispatch({ type: Types.FETCH_STUDIES, payload: studiesCopy });
        dispatch({ type: Types.FETCH_ROLES, payload: rolesCopy });
    };

    const onClearSearch = () => {
        setSearchVal('')
        dispatch({ type: Types.FETCH_STUDIES, payload: studiesCopy });
        dispatch({ type: Types.FETCH_ROLES, payload: rolesCopy });
    };

    const onSearch = (e: any) => {
        setSearchVal(e.target.value);
        const searchVal = e.target.value;
        if (value === "1") {
            const _studies = _.cloneDeep(studiesCopy);
            if (e.target.value !== "") {
                const _studiesData = _studies.filter((value: any) => {
                    return value.protocolId.toLowerCase().includes(searchVal);
                });
                dispatch({ type: Types.SEARCH_STUDY, payload: _studiesData });
            }
            else {
                dispatch({ type: Types.FETCH_STUDIES, payload: studiesCopy });
            }
        }
        else {
            const _roles = _.cloneDeep(rolesCopy);
            if (e.target.value !== "") {
                const _rolesData = _roles.filter((value: any) => {
                    return value.roleName.toLowerCase().includes(searchVal);
                });
                dispatch({ type: Types.SEARCH_ROLES, payload: _rolesData });
            } else {
                dispatch({ type: Types.FETCH_ROLES, payload: rolesCopy });
            }
        }
    };

    const onChangeStudyRadio = (e: any) => {

        const payload = _.cloneDeep(studies)
        studies && studies.map((item: any, index: number) => {
            if (item.id === parseInt(e.target.value)) {
                payload[index].status = true
            } else {
                payload[index].status = false
            }
            return null;
        })
        dispatch({ type: Types.FETCH_STUDIES, payload: payload });
    };

    const onChangeRoleRadio = (e: any) => {
        const _payload = _.cloneDeep(roles)

        roles && roles.map((item: any, index: number) => {
            if (item.roleId === parseInt(e.target.value)) {
                _payload[index].checked = true
            } else {
                _payload[index].checked = false
            }
            return null;
        })
        dispatch({ type: Types.FETCH_ROLES, payload: _payload });
    }

    const toggleDrawer = (open: boolean) => (event: React.KeyboardEvent | React.MouseEvent) => {
        if (event.type === 'keydown' && ((event as React.KeyboardEvent).key === 'Tab' || (event as React.KeyboardEvent).key === 'Shift')) {
            return;
        }
        setOpen(open);
    };
    const onSubmit = () => {
        toggleDrawer(open)
        const val = studies.find((item: any) => item.status === true)
        // dispatch(getCurrentStudyDetails(studyPayload.id))
        dispatch(getCurrentStudyDetails(val.id, (response: any) => {
            dispatch({ type: Types.FETCH_STUDY_DETAILS, payload: response })

            setOpen(false)
            if (!response.errorMessage) {
                dispatch(toastAlert({
                    status: 1,
                    open: true,
                    message: 'Study changed succesfully'
                }))
            } else {
                dispatch(toastAlert({
                    status: 0,
                    open: true,
                    message: response.errorMessage
                }))
            }

        }))
    }

    const list = (anchor: Anchor) => (
        <Box className='settings pl-2' role="presentation">
            <Divider />
            <TabContext value={value} >
                <Box className='' sx={{ borderBottom: 1, borderColor: 'divider' }}>
                    <div className='settings-header'>
                        <h5>Settings</h5>
                        <IconButton onClick={toggleDrawer(false)} aria-label="close" sx={{ position: 'absolute', right: 8, color: (theme) => theme.palette.grey[500] }} >
                            <CloseIcon />
                        </IconButton>
                    </div>
                    <div className='settings-search'>
                        <SearchField
                            value={searchVal}
                            placeholder="Search"
                            onChange={onSearch}
                            onClearSearch={onClearSearch}
                        />
                    </div>
                    <TabList className='tab-List' onChange={handleChange} aria-label="lab API tabs example">
                        <Tab className='tab' label="Study" value="1" />
                        <Tab className='tab' label="Role" value="2" />
                    </TabList>
                </Box>
                <div className='tab-scrolls'>
                    <TabPanel className='tab-panel-study' value="1">
                        <FormControl>
                            <RadioGroup
                                aria-labelledby="demo-radio-buttons-group-label"
                                defaultValue={''}
                                name="radio-buttons-group"
                                onChange={onChangeStudyRadio}>
                                {studies && studies.map((item: any, i: any) => {
                                    return <span className='settings-data ml-2' key={i}>
                                        <FormControlLabel value={item.id}
                                            control={<Radio />}
                                            label={item.protocolId}
                                            checked={item.status} />
                                    </span>
                                })
                                }
                            </RadioGroup>
                        </FormControl>
                    </TabPanel>
                    <TabPanel className='tab-panel-role' value="2" >
                        <FormControl>
                            <RadioGroup
                                aria-labelledby="demo-radio-buttons-group-label"
                                defaultValue={''}
                                name="radio-buttons-group"
                                onChange={onChangeRoleRadio} >

                                {roles && roles.map((item: any, i: any) => {
                                    return <span className='settings-data ml-2' key={i}>
                                        <FormControlLabel
                                            value={item.roleId} control={<Radio />}
                                            label={item.roleName}
                                            checked={item.checked} />
                                    </span>
                                })
                                }
                            </RadioGroup>
                        </FormControl>
                    </TabPanel>
                </div>

                {/* <div className='submitButton-alignmnt'><button className='btn-eprimary' onClick={toggleDrawer(false)}> Submit </button></div> */}
                <div className='submitButton-alignmnt'><button className='btn-eprimary' onClick={() => onSubmit()}> Submit </button></div>
            </TabContext >
        </Box >
    );
    return (
        <React.Fragment>
            <SettingsIcon className='setting-icon' onClick={toggleDrawer(open ? false : true)} color="inherit" />
            <Drawer className='side-drawer' anchor={'right'} open={open} onClose={toggleDrawer(false)} > {list('right')} </Drawer>
        </React.Fragment>
    )
}

export default Settings