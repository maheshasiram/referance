import { NavLink } from "react-router-dom";
import { privateRoutes } from "../../constants/lazyRoutes";
import React from 'react';

function Navbar() {

  return (
    <div className="enav-bar">
      <nav className="container enav-container">
        <div className='nav-elements'>
          <ul>
            {
              privateRoutes && privateRoutes.map((item: any, index: number) => {
                // {console.log('test.......route', item.navigateTo)}

                return (
                  item.children && item.showChild ? <li className="nav-item dropdown" key={index}>
                    <a className="nav-link dropdown-toggle" href="# " role="button"
                      data-bs-toggle="dropdown" aria-expanded="false">{item.name}</a>
                    {<ul className={item.children.length > 8 ? "dropdown-menu scroll-menu-item" : "dropdown-menu"}>
                      {item.children.map((childItem: any, childIndex: number) => {
                        return (
                          <NavLink className="dropdown-item" key={childIndex} to={childItem.navigateTo} >{childItem.name}</NavLink>
                        )
                      })}
                    </ul>}
                  </li> :
                    <li key={index} ><NavLink to={item.navigateTo}>{item.name}</NavLink></li>
                )
              })
            }
          </ul>
        </div>
      </nav>
    </div>
  )
}
export default Navbar;