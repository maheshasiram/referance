import React from "react";
import CloseIcon from '@mui/icons-material/Close';

const DropdownComponent = (props: any) => {

  const { data, selectedOption, values } = props;
  const [value, setValue] = React.useState("");


  React.useEffect(() => {
    if (selectedOption && selectedOption !== "") {
      setValue(selectedOption);
    }
  }, [selectedOption, data]);

  const onChangeHandler = (e: any) => {
    setValue(e.target.value);
    props.onChangeHandler(e.target.value);
  }

  const onClearFilter = () => {
    setValue("");
    props.onChangeHandler("");
  }
  
  return (
    <React.Fragment>
      <label className="text-nowrap">{props.label}</label>
      <select
        className={`form-select ${props.className}`}
        onChange={(e: any) => onChangeHandler(e)}
        value={value}
        disabled={props.disabled ? true : false}
      >
        <option value={values ? values : ''}>{props.defaultValue ? props.defaultValue : '---Select Form---'}</option>
        {
          (data) && data.map((i: any, index: any) => {
          return (
            <option value={i.id} key={index}>{i.formName}</option>)
        })}
      </select>
      {
        (props.isClear && value) && <span className="del-icon" onClick={onClearFilter}>
          <CloseIcon /></span>
      }
    </React.Fragment>
  )
}
export default DropdownComponent;