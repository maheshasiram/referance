import React from 'react'
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import VisibilityIcon from '@mui/icons-material/Visibility';
import FeedIcon from '@mui/icons-material/Feed';
import ViewQuery from '../../../common/viewQueries/ViewQuery';
import CustomToolTip from '../../CustomToolTip';
import { useDispatch, useSelector } from 'react-redux';
import { dataEntryNavigation } from '../../../actions/actions';
import { useNavigate } from 'react-router-dom';
import { Types } from '../../../constants/Types';

function CommonDataTable(props: any) {
    
    const dispatch = useDispatch();
    const navigate = useNavigate();
    // const [rowData, setRowData] = React.useState();
    const { page } = useSelector((state: any) => state.application);

    // const [open, setOpen] = React.useState(false)
    const handleOpenDialog = (rowDataParam: any) => {
        console.log(rowDataParam)
        // props.setOpen(true);
        dispatch({ type: Types.OPEN_CUSTOM_DIALOG, payload: true });
    }
    const handleViewForm = () => {
         navigate('/subjects');
            const _payload = { ...{}, ...page }
            _payload.tabs.map((tab: any) => {
                tab.isActive = (parseInt(tab.index) > _payload.tabs.length) ? false : true;
                return null
              })
              _payload.currentTab = '3'
            dispatch(dataEntryNavigation(_payload));
    }

    const actionBodyTemplate = (rowData: any) => {
        return <div className='d-flex justify-content-start'>
            <CustomToolTip title="View query">
                <VisibilityIcon sx={{ fontSize: '13px' }} onClick={() => handleOpenDialog(rowData)} />
            </CustomToolTip>
            <span> {' '}|{' '} </span>
            <CustomToolTip title="View form">
                <FeedIcon sx={{ fontSize: '13px' }} onClick={handleViewForm} />
            </CustomToolTip>
        </div>
    }

    return (
        <div>
            <DataTable scrollable value={props.data}>
                <Column field="Queryid" header="Query ID" ></Column>
                <Column field="subjectid" header="Subject ID" ></Column>
                <Column field="sitename" header="Site Name" ></Column>
                <Column field="visitId" header="Visit Name"></Column>
                <Column field="username" header="User Name"></Column>
                <Column field="roleName" header="Role Name"></Column>
                <Column field="crfname" header="Form Name"></Column>
                <Column field="days" header="Days"></Column>
                <Column field="status" header="Status"></Column>
                <Column field="querytype" header="Query Type"></Column>
                <Column body={actionBodyTemplate} header="Action"></Column>
            </DataTable>
            {
                props.data && props.data.length && props.data.length > 4 &&
                <div className='d-flex justify-content-end mt-1'>
                    <a href="/" className='text-decoration-none'>View more...</a>
                </div>
            }

            {/* <ViewQuery open={props.open} setOpen={props.setOpen} /> */}
            <ViewQuery />
        </div>
    )
}

export default CommonDataTable;