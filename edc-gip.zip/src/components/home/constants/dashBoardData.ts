export const dashBoardData={
        "pireview": {
            "pireviewcount": 2000,
            "pinotreviewcount": 4905
        },
        "querystatus": {
            "respondedQueries": 53,
            "closedQueries": 343,
            "reopenedQueries": 71,
            "openQueries": 327,
            "total": 674
        },
        "piSignDmReviewSdvStatusCount": {
            "dmReview": 1,
            "sdvStatus": 0,
            "piSign": 0
        },
        "termcountdata": {
            "totalcount": 0,
            "codedcount": 0
        },
        "subjectstatus": {
            "screenFailure": 10,
            "randomized": 25,
            "dropped": 18,
            "enrolled": 48,
            "completed": 5,
            "total": 0,
            "available": 0
        },
        "dmreview": {
            "dmreviewcount": 4001,
            "dmnotreviewcount": 2904
        },
        "eventstatus": [
            {
                "visitName": "UN_3024",
                "visitId": 3757,
                "visitData": [
                    {
                        "count": 50,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 1,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 0,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "CM_6570",
                "visitId": 3758,
                "visitData": [
                    {
                        "count": 48,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 4,
                        "label": "Scheduled"
                    },
                    {
                        "count": 9,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 1,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "Screening (Day -30 to Day -1)",
                "visitId": 21,
                "visitData": [
                    {
                        "count": 0,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 49,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 2,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "Field_Level_Functionality",
                "visitId": 35,
                "visitData": [
                    {
                        "count": 0,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 50,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 1,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "EDC",
                "visitId": 4287,
                "visitData": [
                    {
                        "count": 1,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 47,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "Treatment Visit - Cycle 1 - Week 1-Day 1",
                "visitId": 22,
                "visitData": [
                    {
                        "count": 0,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 1,
                        "label": "Scheduled"
                    },
                    {
                        "count": 48,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 2,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "Treatment Visit - Cycle 1 - Week 1-Day 2",
                "visitId": 23,
                "visitData": [
                    {
                        "count": 0,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 48,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "Treatment Visit - Cycle 1 - Week 1-Day 3",
                "visitId": 24,
                "visitData": [
                    {
                        "count": 0,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 1,
                        "label": "Scheduled"
                    },
                    {
                        "count": 47,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "Treatment Visit - Cycle 1 - Week 2-Day 1",
                "visitId": 25,
                "visitData": [
                    {
                        "count": 1,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 47,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "Treatment Visit - Cycle 1 - Week 3-Day 1",
                "visitId": 26,
                "visitData": [
                    {
                        "count": 1,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 47,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "No Treatment - Cycle 1-Week 7",
                "visitId": 30,
                "visitData": [
                    {
                        "count": 0,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 1,
                        "label": "Scheduled"
                    },
                    {
                        "count": 47,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "Treatment Visit - Cycle 1 - Week 4-Day 1",
                "visitId": 27,
                "visitData": [
                    {
                        "count": 1,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 47,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "Treatment Visit - Cycle 1 - Week 5-Day 1",
                "visitId": 28,
                "visitData": [
                    {
                        "count": 1,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 47,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "Treatment Visit - Cycle 1 - Week 6-Day 1",
                "visitId": 29,
                "visitData": [
                    {
                        "count": 0,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 1,
                        "label": "Scheduled"
                    },
                    {
                        "count": 47,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "End of Study/Early Termination",
                "visitId": 31,
                "visitData": [
                    {
                        "count": 0,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 48,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "Log Forms",
                "visitId": 32,
                "visitData": [
                    {
                        "count": 0,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 1,
                        "label": "Scheduled"
                    },
                    {
                        "count": 48,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 2,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "Additional Visits",
                "visitId": 33,
                "visitData": [
                    {
                        "count": 44,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 6,
                        "label": "Scheduled"
                    },
                    {
                        "count": 2,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 2,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "visit_1",
                "visitId": 3508,
                "visitData": [
                    {
                        "count": 0,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 1,
                        "label": "Scheduled"
                    },
                    {
                        "count": 47,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "visit_3",
                "visitId": 4288,
                "visitData": [
                    {
                        "count": 1,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 47,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "SC_3031",
                "visitId": 3755,
                "visitData": [
                    {
                        "count": 0,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 1,
                        "label": "Scheduled"
                    },
                    {
                        "count": 47,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "SC_4326",
                "visitId": 3756,
                "visitData": [
                    {
                        "count": 1,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 47,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "visit12",
                "visitId": 4289,
                "visitData": [
                    {
                        "count": 1,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 47,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "visit11",
                "visitId": 4292,
                "visitData": [
                    {
                        "count": 51,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 0,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "month23",
                "visitId": 4293,
                "visitData": [
                    {
                        "count": 1,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 47,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "visit_6",
                "visitId": 4299,
                "visitData": [
                    {
                        "count": 1,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 47,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "ClinicalDataVisit",
                "visitId": 4300,
                "visitData": [
                    {
                        "count": 1,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 47,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "visit_7",
                "visitId": 4301,
                "visitData": [
                    {
                        "count": 0,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 1,
                        "label": "Scheduled"
                    },
                    {
                        "count": 47,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "visit13",
                "visitId": 4302,
                "visitData": [
                    {
                        "count": 1,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 47,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "visit_8",
                "visitId": 4358,
                "visitData": [
                    {
                        "count": 1,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 47,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "test",
                "visitId": 6997,
                "visitData": [
                    {
                        "count": 51,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 0,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "test2",
                "visitId": 6998,
                "visitData": [
                    {
                        "count": 51,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 0,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "test323",
                "visitId": 6999,
                "visitData": [
                    {
                        "count": 48,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "test visit",
                "visitId": 7033,
                "visitData": [
                    {
                        "count": 51,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 0,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "SC_393869",
                "visitId": 7265,
                "visitData": [
                    {
                        "count": 48,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "UN_593033",
                "visitId": 7266,
                "visitData": [
                    {
                        "count": 51,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 0,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "CM_747678",
                "visitId": 7267,
                "visitData": [
                    {
                        "count": 51,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 0,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "SR_459780",
                "visitId": 7268,
                "visitData": [
                    {
                        "count": 48,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "UR_616101",
                "visitId": 7269,
                "visitData": [
                    {
                        "count": 51,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 0,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "CR_724700",
                "visitId": 7270,
                "visitData": [
                    {
                        "count": 51,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 0,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "SD_190515",
                "visitId": 7271,
                "visitData": [
                    {
                        "count": 47,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 1,
                        "label": "Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "UD_340339",
                "visitId": 7272,
                "visitData": [
                    {
                        "count": 51,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 0,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "CD_066114",
                "visitId": 7273,
                "visitData": [
                    {
                        "count": 51,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 0,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "Actions_724362",
                "visitId": 7274,
                "visitData": [
                    {
                        "count": 48,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "Approvals_578194",
                "visitId": 7275,
                "visitData": [
                    {
                        "count": 47,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 1,
                        "label": "Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "SHRD_535718",
                "visitId": 7276,
                "visitData": [
                    {
                        "count": 46,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 2,
                        "label": "Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "SC_844275",
                "visitId": 7277,
                "visitData": [
                    {
                        "count": 48,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "UN_239525",
                "visitId": 7278,
                "visitData": [
                    {
                        "count": 51,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 0,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "CM_212339",
                "visitId": 7279,
                "visitData": [
                    {
                        "count": 51,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 0,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "SR_085490",
                "visitId": 7280,
                "visitData": [
                    {
                        "count": 47,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 1,
                        "label": "Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 3,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "UR_169710",
                "visitId": 7281,
                "visitData": [
                    {
                        "count": 51,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 0,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "CR_401686",
                "visitId": 7282,
                "visitData": [
                    {
                        "count": 51,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 0,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "CD_453560",
                "visitId": 7285,
                "visitData": [
                    {
                        "count": 51,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 0,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "Approvals_222",
                "visitId": 7287,
                "visitData": [
                    {
                        "count": 48,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 3,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 0,
                        "label": "Locked"
                    }
                ]
            },
            {
                "visitName": "SHRD_504600",
                "visitId": 7288,
                "visitData": [
                    {
                        "count": 48,
                        "label": "Not Scheduled"
                    },
                    {
                        "count": 0,
                        "label": "Scheduled"
                    },
                    {
                        "count": 3,
                        "label": "Data Entry Started"
                    },
                    {
                        "count": 0,
                        "label": "Completed"
                    },
                    {
                        "count": 0,
                        "label": "Locked"
                    }
                ]
            }
        ],
        "sdvreview": {
            "sdvreviewcount": 1000,
            "sdvnotreviewcount": 5905
        },
        "subjectInfo": [
            {
                "studyName": "FOL-102",
                "studyDescription": "Gita",
                "sitesCount": 1,
                "piName": "NALakshmanDharitri"
            }
        ]
    }