export const visitInfo :any=[
    {
        "visitName": "V1",
        "visitId": 8809,
        "visitData": [
            {
                "count": 27,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 4,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "issue",
        "visitId": 8747,
        "visitData": [
            {
                "count": 15,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 15,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "Ap",
        "visitId": 8804,
        "visitData": [
            {
                "count": 15,
                "label": "Not Scheduled"
            },
            {
                "count": 1,
                "label": "Scheduled"
            },
            {
                "count": 14,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "Kh",
        "visitId": 8772,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "ABCVisit",
        "visitId": 8817,
        "visitData": [
            {
                "count": 16,
                "label": "Not Scheduled"
            },
            {
                "count": 2,
                "label": "Scheduled"
            },
            {
                "count": 12,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "zxy",
        "visitId": 8883,
        "visitData": [
            {
                "count": 21,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 9,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "rulesIss",
        "visitId": 8437,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "Custom scriprt",
        "visitId": 8422,
        "visitData": [
            {
                "count": 17,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 13,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "demo visit",
        "visitId": 8551,
        "visitData": [
            {
                "count": 17,
                "label": "Not Scheduled"
            },
            {
                "count": 2,
                "label": "Scheduled"
            },
            {
                "count": 11,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "dervisit",
        "visitId": 8582,
        "visitData": [
            {
                "count": 18,
                "label": "Not Scheduled"
            },
            {
                "count": 2,
                "label": "Scheduled"
            },
            {
                "count": 10,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "visit_123",
        "visitId": 8577,
        "visitData": [
            {
                "count": 20,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 10,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "Custom Script AM/PM",
        "visitId": 8552,
        "visitData": [
            {
                "count": 10,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 20,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "pregnancy",
        "visitId": 8601,
        "visitData": [
            {
                "count": 16,
                "label": "Not Scheduled"
            },
            {
                "count": 1,
                "label": "Scheduled"
            },
            {
                "count": 13,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "ruleVis",
        "visitId": 8678,
        "visitData": [
            {
                "count": 20,
                "label": "Not Scheduled"
            },
            {
                "count": 1,
                "label": "Scheduled"
            },
            {
                "count": 9,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "erulzvisit",
        "visitId": 8691,
        "visitData": [
            {
                "count": 19,
                "label": "Not Scheduled"
            },
            {
                "count": 1,
                "label": "Scheduled"
            },
            {
                "count": 10,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "sample",
        "visitId": 8706,
        "visitData": [
            {
                "count": 19,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 11,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "General",
        "visitId": 8711,
        "visitData": [
            {
                "count": 19,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 11,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "DR Appoint",
        "visitId": 8740,
        "visitData": [
            {
                "count": 15,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 15,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "alamvisit",
        "visitId": 8741,
        "visitData": [
            {
                "count": 25,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 7,
                "label": "Data Entry Started"
            },
            {
                "count": 1,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "SC_423682",
        "visitId": 8774,
        "visitData": [
            {
                "count": 19,
                "label": "Not Scheduled"
            },
            {
                "count": 1,
                "label": "Scheduled"
            },
            {
                "count": 10,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "UN_907361",
        "visitId": 8775,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "SR_252030",
        "visitId": 8777,
        "visitData": [
            {
                "count": 21,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 9,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "UR_193143",
        "visitId": 8778,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "CR_630311",
        "visitId": 8779,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "SD_542154",
        "visitId": 8780,
        "visitData": [
            {
                "count": 21,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 9,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "UD_871029",
        "visitId": 8781,
        "visitData": [
            {
                "count": 29,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 1,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "CD_100110",
        "visitId": 8782,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "Actions_6626",
        "visitId": 8783,
        "visitData": [
            {
                "count": 21,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 9,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "Approvals_107512",
        "visitId": 8784,
        "visitData": [
            {
                "count": 21,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 9,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "SHRD_099716",
        "visitId": 8785,
        "visitData": [
            {
                "count": 21,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 9,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "v1818",
        "visitId": 8787,
        "visitData": [
            {
                "count": 21,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 9,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "bgfb",
        "visitId": 8789,
        "visitData": [
            {
                "count": 19,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 11,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "gerb",
        "visitId": 8790,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "bfg",
        "visitId": 8791,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "SC_743832",
        "visitId": 8792,
        "visitData": [
            {
                "count": 21,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 9,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "UN_358341",
        "visitId": 8793,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "CM_427714",
        "visitId": 8794,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "SR_008604",
        "visitId": 8795,
        "visitData": [
            {
                "count": 21,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 9,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "UR_613511",
        "visitId": 8796,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "CR_043235",
        "visitId": 8797,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "SD_097624",
        "visitId": 8798,
        "visitData": [
            {
                "count": 21,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 9,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "UD_362503",
        "visitId": 8799,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "CD_251645",
        "visitId": 8800,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "Actions_2690",
        "visitId": 8801,
        "visitData": [
            {
                "count": 21,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 9,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "Approvals_061865",
        "visitId": 8802,
        "visitData": [
            {
                "count": 21,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 9,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "SHRD_901035",
        "visitId": 8803,
        "visitData": [
            {
                "count": 21,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 9,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "V11",
        "visitId": 8816,
        "visitData": [
            {
                "count": 18,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 12,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "Bio Visit",
        "visitId": 8818,
        "visitData": [
            {
                "count": 23,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 12,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "New visit",
        "visitId": 8875,
        "visitData": [
            {
                "count": 28,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 2,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "new Lab Ranger",
        "visitId": 8876,
        "visitData": [
            {
                "count": 23,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 7,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "Submit Button Issue",
        "visitId": 8878,
        "visitData": [
            {
                "count": 22,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 8,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "LVisit",
        "visitId": 8880,
        "visitData": [
            {
                "count": 23,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 7,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "labVisit",
        "visitId": 8881,
        "visitData": [
            {
                "count": 23,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 7,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "DRV Testing",
        "visitId": 8882,
        "visitData": [
            {
                "count": 22,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 8,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "axy",
        "visitId": 8884,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "Illness visit",
        "visitId": 8887,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "z11",
        "visitId": 8888,
        "visitData": [
            {
                "count": 24,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 6,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "kIwW",
        "visitId": 8890,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "AxvP",
        "visitId": 8891,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "VIpg",
        "visitId": 8892,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "qwertyu",
        "visitId": 8893,
        "visitData": [
            {
                "count": 29,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 1,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "TqOK",
        "visitId": 8897,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "yuikl",
        "visitId": 8898,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "vZLI",
        "visitId": 8899,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "ABCvirat",
        "visitId": 8905,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "ABC",
        "visitId": 8906,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "aaaa",
        "visitId": 8907,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "eeee",
        "visitId": 8917,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "tttt",
        "visitId": 8918,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "rrrrttttyyyy",
        "visitId": 8919,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "rrrrddddyyyyrrrrddddyyyyrrrrddddyyyy",
        "visitId": 8920,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "rrrrddddyyyy",
        "visitId": 8921,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "rrrr",
        "visitId": 8922,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "yyyy",
        "visitId": 8923,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "dddd",
        "visitId": 8924,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "visitname",
        "visitId": 8925,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "responcetype",
        "visitId": 8926,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "qqq",
        "visitId": 8927,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "qqqq",
        "visitId": 8928,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "qqqqq",
        "visitId": 8929,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "www",
        "visitId": 8930,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "wwwww",
        "visitId": 8931,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "cc",
        "visitId": 8932,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "ccc",
        "visitId": 8933,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "cccc",
        "visitId": 8934,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "ss",
        "visitId": 8935,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "ssss",
        "visitId": 8936,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "DSC",
        "visitId": 8961,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "sCREENING Day 0( </=90 Days Prior Day 1)",
        "visitId": 8968,
        "visitData": [
            {
                "count": 25,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 5,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "dfghjuikoljhg",
        "visitId": 8975,
        "visitData": [
            {
                "count": 25,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 5,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "Unsheduled Visit",
        "visitId": 8976,
        "visitData": [
            {
                "count": 29,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 1,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "SC_645763",
        "visitId": 8978,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "UN_715464",
        "visitId": 8979,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "CM_720138",
        "visitId": 8980,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "SC_280846",
        "visitId": 8981,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "UN_414393",
        "visitId": 8982,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "CM_531523",
        "visitId": 8983,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "SR_148004",
        "visitId": 8984,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "UR_424877",
        "visitId": 8985,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "CR_792660",
        "visitId": 8986,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "SD_551076",
        "visitId": 8987,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "UD_480450",
        "visitId": 8988,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "CD_757193",
        "visitId": 8989,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "Actions_924022",
        "visitId": 8990,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "Approvals_527861",
        "visitId": 8991,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "SHRD_800599",
        "visitId": 8992,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "SC_160434",
        "visitId": 8993,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "UN_521448",
        "visitId": 8994,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "CM_935388",
        "visitId": 8995,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "SR_915139",
        "visitId": 8996,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "UR_302489",
        "visitId": 8997,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "CR_192909",
        "visitId": 8998,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "SD_188245",
        "visitId": 8999,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "UD_409201",
        "visitId": 9000,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "CD_327054",
        "visitId": 9001,
        "visitData": [
            {
                "count": 29,
                "label": "Not Scheduled"
            },
            {
                "count": 1,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "Actions_7226",
        "visitId": 9002,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "Approvals_992078",
        "visitId": 9003,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "SHRD_758452",
        "visitId": 9004,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "S-068632",
        "visitId": 9005,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "A1S-542637",
        "visitId": 9006,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "SC_973236",
        "visitId": 9007,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "UN_643078",
        "visitId": 9008,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "CM_279558",
        "visitId": 9009,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "SR_984955",
        "visitId": 9010,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "UR_470863",
        "visitId": 9011,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "CR_231561",
        "visitId": 9012,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "SD_295277",
        "visitId": 9013,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "UD_511953",
        "visitId": 9014,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "CD_517721",
        "visitId": 9015,
        "visitData": [
            {
                "count": 29,
                "label": "Not Scheduled"
            },
            {
                "count": 1,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "Actions_9022",
        "visitId": 9016,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "Approvals_701752",
        "visitId": 9017,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "SHRD_969520",
        "visitId": 9018,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "Pepeating",
        "visitId": 8483,
        "visitData": [
            {
                "count": 28,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 2,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "inference",
        "visitId": 9019,
        "visitData": [
            {
                "count": 28,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 2,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "fgdfg",
        "visitId": 9023,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "visit-004",
        "visitId": 9032,
        "visitData": [
            {
                "count": 29,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 1,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "asxdcfgh                 (aaasdfghjklasdfghjjkla)",
        "visitId": 9033,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "Score Issue ",
        "visitId": 9034,
        "visitData": [
            {
                "count": 29,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 1,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "Screening Day 0 (  </=90 Daysprior Day 1)",
        "visitId": 9036,
        "visitData": [
            {
                "count": 29,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 1,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    },
    {
        "visitName": "Score pssue",
        "visitId": 9038,
        "visitData": [
            {
                "count": 30,
                "label": "Not Scheduled"
            },
            {
                "count": 0,
                "label": "Scheduled"
            },
            {
                "count": 0,
                "label": "Data Entry Started"
            },
            {
                "count": 0,
                "label": "Completed"
            },
            {
                "count": 0,
                "label": "Locked"
            }
        ]
    }
]