export const sitesChart = {
    "enddate": "2024-05-25",
    "data": [
        {
            "expectedSubjects": 500,
            "totalEnrolled": 65,
            "siteid": 8,
            "subSiteId": "PH02",
            "siteName": "Manila Doctors Hospital"
        },
        {
            "expectedSubjects": 300,
            "totalEnrolled": 35,
            "siteid": 9,
            "subSiteId": "STH06",
            "siteName": "Site Hospital"
        }
    ],
    "studyName": "EFSA2021_01",
    "startdate": "2022-05-07"
}