import * as React from 'react';
import ReactECharts from 'echarts-for-react';
import '../style.scss'
import { sitesChart } from '../constants/sitesChart';

function Sites() {
    const sName=sitesChart.data.map((item: any) => { return (item.subSiteId) })
    const Draft = sitesChart.data.map((i: any) => { return (i.totalEnrolled) })
    const option = {
        title: {
            text: 'Sites',
        },
        grid: {
            left: '9%',
            right: '8%',
            bottom: '35%',
            containLabel: true
        },
        toolbox: {
            show: true,
            feature: {
                magicType: { show: true, type: ['line', 'bar'] },
                saveAsImage: { show: true }
            }
        },
        tooltip: {
            // trigger: 'item',
            // formatter:
        },
        calculable: true,
        xAxis: [
            {
                name: 'List of Sites ID\'s',
                nameLocation: "middle",
                nameGap: 27,
                axisLine: {
                    lineStyle: {
                        color: '#666'
                    },
                }, splitLine: {
                    lineStyle: {
                        color: '#ddd'
                    }
                },
                type: 'category',
                data: sName
            },
        ],
        yAxis: [
            {
                name: 'percent of enrolment',
                nameLocation: "middle",
                nameGap: 45,
                axisLine: {
                    lineStyle: {
                        color: '#666',
                    },
                }, splitLine: {
                    lineStyle: {
                        color: '#ddd'
                    }
                },
                type: 'value'
            }
        ],
        series: [
            {
                name: sName,
                type: 'bar',
                barWidth: '16%',
                data: Draft
            },
        ]
    };

    return (
        <div className='siteGraph p-3'> <ReactECharts option={option} /></div>
    )
}

export default Sites;