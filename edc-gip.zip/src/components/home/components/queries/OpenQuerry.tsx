import React from 'react'
import { useSelector } from 'react-redux';
import CommonDataTable from '../../helper/CommonDataTable';

function OpenQuery() {
    const [open, setOpen] = React.useState(false)
    const {openQueryData} = useSelector((state:any)=>state.application)
    
    return (
        <div>
            <div className='query-count-container'>Open Query count : <span className='query-counter'>{openQueryData.openQueriesCount}</span> </div>
            <CommonDataTable data = {openQueryData.openQueries} open={open} setOpen={setOpen}/>
        </div>
    )
}

export default OpenQuery