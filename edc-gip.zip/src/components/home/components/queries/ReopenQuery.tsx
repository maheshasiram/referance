import React from 'react'
import { useSelector } from 'react-redux';
import CommonDataTable from '../../helper/CommonDataTable';

function ReopenQuery() {
    const [open, setOpen] = React.useState(false)
    const {reopenQueryData} = useSelector((state:any)=>state.application)
    return (
        <div>
            <div className='query-count-container'>Reopen Query count: <span className='query-counter'>{reopenQueryData.reOpenQueriesCount}</span> </div>
            <CommonDataTable
                data={reopenQueryData.reOpenQueries}
                open={open}
                setOpen={setOpen}
            />
        </div>
    )
}

export default ReopenQuery