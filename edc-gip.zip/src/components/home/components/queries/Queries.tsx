import React from 'react'
import Box from "@mui/material/Box";
import Tab from "@mui/material/Tab";
import TabContext from "@mui/lab/TabContext";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";
import AllSubject from './AllSubject';
import ClosedQuery from './ClosedQuery';
import OpenQuery from './OpenQuerry';
import ReopenQuery from './ReopenQuery';
import RespondedQuery from './RespondedQuery';


function Queries() {
    const [value, setValue] = React.useState("allSubjects");

    const handleChange = (event: React.SyntheticEvent, newValue: string) => {
        setValue(newValue);
    };
    return (
        <div className='m-2'>
            <Box sx={{ width: "100%",fontSize:'13px !important' }}>
                <TabContext value={value}>
                    <Box sx={{ ml: '1.5rem' }}>
                        <TabList onChange={handleChange} aria-label="lab API tabs example">
                            <Tab label="All Subjects" value="allSubjects" />
                            <Tab label="Open Query" value="openQuery" />
                            <Tab label="Responded Query" value="respondedQiery" />
                            <Tab label="closed Query" value="closeQuery" />
                            <Tab label="Reopen Query" value="reopenQuery" />
                        </TabList>
                    </Box>
                    <TabPanel value="allSubjects"><AllSubject /></TabPanel>
                    <TabPanel value="openQuery"><OpenQuery /></TabPanel>
                    <TabPanel value="respondedQiery"><RespondedQuery /></TabPanel>
                    <TabPanel value="closeQuery"><ClosedQuery /></TabPanel>
                    <TabPanel value="reopenQuery"><ReopenQuery /></TabPanel>
                </TabContext>
            </Box>
        </div>
    )
}

export default Queries