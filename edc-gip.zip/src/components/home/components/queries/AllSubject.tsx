import React from 'react'
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import { useSelector } from 'react-redux';


function AllSubject() {
    const {allStudyData} = useSelector((state:any)=>state.application)
    return (
        <div>
            <div className='query-count-container'> All subjects count: <span className='query-counter'>{allStudyData.length}</span> </div>
            <div className='row'>
                {
                    allStudyData.map((subject: any, index: any) => {
                        if (index < 9) {
                            return <div className='col-2 border-bottom border-1 pb-1 ' key={index}>
                                <a href='/'
                                    className='all-subjects-container text-secondary'
                                >
                                    <AccountCircleIcon sx={{ fontSize: '13px', mb: '3px' }} />
                                    {' '}{subject.label && subject.label}
                                </a>
                            </div>
                        }
                        return null;

                    })
                }
            </div>
            {
                allStudyData && allStudyData.length > 9
                && <div className='d-flex justify-content-end mt-1'>
                    <a href="/" className='text-decoration-none'>view more...</a>
                </div>
            }


        </div >
    )
}

export default AllSubject