import React from 'react'
import { useSelector } from 'react-redux';
import CommonDataTable from '../../helper/CommonDataTable';
function RespondedQuery() {
  // const [open, setOpen] = React.useState(false);
  const { respondedQueryData, openCustomDialog } = useSelector((state: any) => state.application);
  return (
    <div>
      <div className='query-count-container'>Respond Query count: <span className='query-counter'>{respondedQueryData.answeredQueriesCount}</span> </div>
      <CommonDataTable
        data={respondedQueryData.answeredQueries}
        open={openCustomDialog}
        // setOpen={setOpen}
      />
    </div>
  )
}

export default RespondedQuery