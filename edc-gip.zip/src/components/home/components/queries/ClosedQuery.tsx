import React from 'react'
import { useSelector } from 'react-redux';
import CommonDataTable from '../../helper/CommonDataTable';

function ClosedQuery() {
    const [open, setOpen] = React.useState(false)
    const {closedQueryData} = useSelector((state:any)=>state.application)

    return (
        <div>
            <div className='query-count-container'>Closed Query count: <span className='query-counter'>{closedQueryData.closedQueriesCount}</span> </div>
            <CommonDataTable
                data={closedQueryData.closedQueries}
                open={open}
                setOpen={setOpen}
            />
        </div>
    )
}

export default ClosedQuery