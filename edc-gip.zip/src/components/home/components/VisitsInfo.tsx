import React from 'react'
import ReactECharts from 'echarts-for-react';
// import { visitInfo } from '../constants/visitData';
import '../style.scss';
import { dashBoardData } from '../constants/dashBoardData';

function VisitsInfo() {
  // const val = dashBoardData.eventstatus.map((i: any) => { return (i) })
  return (
    <div className="Visits-container ">
      {dashBoardData.eventstatus.map((item: any,i:any) => {
        const option = {
          tooltip: {
            trigger: 'item',
          },
          legend: {
            orient: 'vertical',
            icon:'circle',
            right: 35,
            top: 50,
            data: item.visitData.map((data: any) => {
              return data.label
            })
          },
          series: [
            {
              name: item.visitName,
              type: 'pie',
              radius: ['45%', '65%'],
              avoidLabelOverlap: true,
              top:15,
              right:165,
              bottom:140,
              label: {
                show: false,
                position: 'center'
              },
              labelLine: {
                show: false
              },
              data: item.visitData.map((data: any) => {
                return {
                  name: data.label,
                  value: data.count
                }
              })
            }
          ]
        };
        return (
          <div className="subVisits-container col-4" key={i}>
            <h3 className='border-bottom ' >{item.visitName}</h3>
            <ReactECharts option={option} />
          </div>
        )
      }
      )}
    </div>
  )

}

export default VisitsInfo