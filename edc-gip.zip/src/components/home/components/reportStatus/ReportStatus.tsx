import React from 'react'
// import ReactECharts from 'echarts-for-react';
import '../../style.scss'
import MoniterStatus from './MoniterStatus';
import SignStatus from './SignStatus';
import ReviewStatus from './ReviewStatus';

function ReportStatus() {
  return (

    <div className="d-flex donuts">
      <div className='col-4 pt-2 donut-pi '>
        <h3 className=' donut-chart'> Sign Status(PI)</h3>
     <SignStatus/>
      </div>
      <div className='col-4 pt-2 donut-dm'>
        <h3 className='donut-chart'>Review Status(DM)</h3>
       <ReviewStatus/>
      </div>
      <div className='col-4  pt-2 donut-cra'>
        <h3 className=' donut-chart'>Moniter Status(CRA)</h3>
        <MoniterStatus/>
      </div>

    </div>

  )
}

export default ReportStatus