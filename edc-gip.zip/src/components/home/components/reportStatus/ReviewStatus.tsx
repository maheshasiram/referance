import React from 'react'
import ReactECharts from 'echarts-for-react';
import { dashBoardData } from '../../constants/dashBoardData';

function ReviewStatus() {
    const notReviewVal=dashBoardData.dmreview.dmnotreviewcount
    const reviewVal=dashBoardData.dmreview.dmreviewcount

    const reviewStatus ={
      tooltip: {
          trigger: 'item',
      },
      legend: {
          orient: 'vertical',
          icon:'circle',
          right: 45,
          top: 50,
            data: ['Review', 'Not Review']
      },

      series: [
          {
              name: 'DM',
              type: 'pie',
              radius: ['47%', '70%'],
              avoidLabelOverlap: false,
              top:20,
              right:130,
              bottom:170,
              label: {
                  show: false,
                  position: 'center'
              },
              emphasis: {
                  label: {
                      show: true,
                      fontSize: '13',
                      fontWeight: 'bold'
                  }
              },
              labelLine: {
                  show: false
              },
              data: [
                  {value: notReviewVal, name: 'Not Review'},
                  {value: reviewVal, name: 'Review'},
              ]
          }
      ]
  };

  return (
    <ReactECharts option={reviewStatus}/>
  )
}

export default ReviewStatus
