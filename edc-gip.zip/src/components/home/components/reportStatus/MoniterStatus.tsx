import React from 'react'
import ReactECharts from 'echarts-for-react';
import { dashBoardData } from '../../constants/dashBoardData';

function MoniterStatus() {
    const notMoniterVal=dashBoardData.sdvreview.sdvnotreviewcount
    const moniterVal=dashBoardData.sdvreview.sdvreviewcount

    const moniterStatus  = {
        tooltip: {
            trigger: 'item',
        },
  
        legend: {
          icon:'circle',
            orient: 'vertical',
             right: 45,
              top: 50,
              data: ['Moniter', 'Not Moniter']
        },
  
        series: [
            {
                name: 'CRA',
                type: 'pie',
                radius: ['47%', '70%'],
                avoidLabelOverlap: false,
                top:20,
                 right:130,
                 bottom:170,
                label: {
                    show: false,
                    position: 'center'
                },
  
                emphasis: {
                    label: {
                        show: true,
                        fontSize: '13',
                        fontWeight: 'bold'
                    }
                },
  
                labelLine: {
                    show: false
                },
                data: [
                    {value: notMoniterVal, name: 'Not Moniter'},
                    {value: moniterVal, name: 'Moniter'},
                ]
            }
        ]
    };
  
    
  return (
    <ReactECharts option={moniterStatus}/>
  )
}

export default MoniterStatus