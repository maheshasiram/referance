import React from 'react'
import ReactECharts from 'echarts-for-react';
import { dashBoardData } from '../../constants/dashBoardData';

function SignStatus() {
    const signVal = dashBoardData.pireview.pireviewcount
    const notSignVal = dashBoardData.pireview.pinotreviewcount

    const signStatus = {
        tooltip: {
            trigger: 'item',
        },

        legend: {
            icon: 'circle',
            orient: 'vertical',
            right: 65,
            top: 50,
            data: ['sign', 'Not sign']
        },

        series: [
            {
                name: 'PI',
                type: 'pie',
                radius: ['47%', '70%'],
                avoidLabelOverlap: false,
                top: 20,
                right: 130,
                bottom: 170,
                label: {
                    show: false,
                    position: 'center'
                },

                emphasis: {
                    label: {
                        show: true,
                        fontSize: '13',
                        fontWeight: 'bold'
                    }
                },

                labelLine: {
                    show: false
                },
                data: [
                    { value: notSignVal, name: 'Not sign' },
                    { value: signVal, name: 'sign' },
                ]
            }
        ]
    };

    return (
        <ReactECharts option={signStatus} />
    )
}

export default SignStatus
