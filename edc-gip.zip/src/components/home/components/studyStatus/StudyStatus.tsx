import React from 'react'
import '../../style.scss'
import SubjectStatus from './SubjectStatus'
import QueryStatus from './QueryStatus'

function StudyStatus() {
  return (
    <div className='d-flex study-popup' >
      <div className='col-6 Subject-status'>
        <SubjectStatus/>
      </div>
      <div className="col-6 Query-status">
        <QueryStatus/>
      </div>
    </div>
  )
}

export default StudyStatus