import * as React from 'react';
import '../../style.scss'
import StudyStatus from './StudyStatus';
import CustomDialog from '../../../../common/modals/CustomeDialog';

function StudyStatusDetails() {
    const [open, setOpen] = React.useState(false);

    const onOpenStudyStatus = () => {
        setOpen(true);
    }
    const onCloseHandler = () => {
        setOpen(false);
    }
    return (
        <React.Fragment>
            <CustomDialog
                title={"Study Status"}
                onClose={onCloseHandler}
                open={open} 
            >
                < StudyStatus/>
            </CustomDialog>

            <div className='study-data'>
                <h5>Study Name</h5>
                <span>Subject Status</span>
                <p>Indicates the status of the subjects in the study. Following are the different status
                    available: i. Enrolled ii. Completed iii. Screen Failure iv. Randomized v.
                    Dropped / Withdrawn
                </p>
                <span>Query Status </span>
                <p className='pb-0'> Indicates the status of the queries. The following are the different
                    status available.
                </p>
                <div className=' d-flex flex-row view-more '>
                    <a className='text-decoration-none' onClick={onOpenStudyStatus} href='# '>View More...</a>
                </div>
            </div>
        </React.Fragment>
    )
}

export default StudyStatusDetails;