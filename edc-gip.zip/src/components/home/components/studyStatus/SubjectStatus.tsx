import React from 'react'
import ReactECharts from 'echarts-for-react';
import '../../style.scss'
import { dashBoardData } from '../../constants/dashBoardData';

function SubjectStatus() {
    const option = {
        tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b} : {c} ({d}%)'
        },
        legend: {
            orient: 'vertical',
            icon: 'circle',
            left: 170,
            top: 45,
            data: ['Enrolled', 'Completed', 'Screen Failur', 'Randomized', 'Screen Dropped / Withdrawn']
        },
        series: [
            {
                name: 'Study',
                type: 'pie',
                radius: '38%',
                top: 0,
                center: ['15%', '30%'],
                data: [
                    { value: dashBoardData.subjectstatus.randomized, name: 'Randomized' },
                    { value: dashBoardData.subjectstatus.completed, name: 'Completed' },
                    { value: dashBoardData.subjectstatus.enrolled, name: 'Enrolled' },
                    { value: dashBoardData.subjectstatus.screenFailure, name: 'Screen Failur' },
                    { value: dashBoardData.subjectstatus.dropped, name: 'Screen Dropped / Withdrawn' },
                ],
                label: {
                    show: false,

                    labelLine: {
                        show: false
                    },
                },
                emphasis: {
                }
            }
        ]
    };
    return (
        <React.Fragment>
                <h6 className='p-2 status-title'>Subject Status</h6>
            <div className='subject-charts'>
                <ReactECharts option={option} />
            </div>
            <div className='subject-data'>
                <div className='row'>
                    <div className='col-3 text-start'>Enrolled :  </div>
                    <div className='col-9'>When a subject is created it is in Enrolled State.</div>
                </div>
                <div className='row'>
                    <div className='col-3 text-start'>Completed :  </div>
                    <div className='col-9'> When a subject completes all the visits in a study as per protocol.</div>
                </div>
                <div className='row'>
                    <div className='col-3 text-start'>Screen Failure :  </div>
                    <div className='col-9'>Subject who does not meet the study inclusion and exclusion criteria. </div>
                </div>
                <div className='row'>
                    <div className='col-3 text-start'>Randomized :  </div>
                    <div className='col-9'>Subject who is assigned to an arm.</div>
                </div>
                <div className='row'>
                    <div className='col-3 text-start'>Dropped / Withdrawn :  </div>
                    <div className='col-9'> Subject who does not complete the study after assigning to an arm. </div>
                </div>
            </div>
        </React.Fragment>
    )
}

export default SubjectStatus