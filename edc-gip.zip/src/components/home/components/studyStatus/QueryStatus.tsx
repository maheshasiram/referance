import React from 'react'
import ReactECharts from 'echarts-for-react';
import { dashBoardData } from '../../constants/dashBoardData';

function SubjectStatus() {
    const option = {
        tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b} : {c} ({d}%)'
        },
        legend: {
            orient: 'vertical',
            icon: 'circle',
            left: 170,
            top: 60,
            data: ['Open', 'Responded', 'Reopen', 'Closed']
        },
        series: [
            {
                name: 'Query',
                type: 'pie',
                radius: '37%',
                top: 0,
                center: ['15%', '30%'],
                data: [
                    { value: dashBoardData.querystatus.openQueries, name: 'Open' },
                    { value: dashBoardData.querystatus.respondedQueries, name: 'Responded' },
                    { value: dashBoardData.querystatus.reopenedQueries, name: 'Reopen' },
                    { value: dashBoardData.querystatus.closedQueries, name: 'Closed' },
                ],
                label: {
                    show: false,

                    labelLine: {
                        show: false
                    },
                },
                emphasis: {
                }
            }
        ]
    };
    return (
        <React.Fragment>
              <h6 className='p-2 status-title'>Query Status</h6>
            <div className='query-charts'>
                <ReactECharts option={option} />
            </div>
            <div className='query-data '>
                <div className='row'>
                    <div className='col-3 text-start'>Open :  </div>
                    <div className='col-9'>When a query is fired. It may be system query or a manual query raised by either Data Manager or Clinical Research Associate.</div>
                </div>
                <div className='row'>
                    <div className='col-3 text-start'>Responded :  </div>
                    <div className='col-9'>When Site Coordinator provides responses to the fired queries.</div>
                </div>
                <div className='row'>
                    <div className='col-3 text-start'>Reopen :  </div>
                    <div className='col-9'>When the response provided by Site Coordinator is not satisfactory, Data Manager or Clinical Research Associate will Reopen the query.</div>
                </div>
                <div className='row'>
                    <div className='col-3 text-start'>Closed :  </div>
                    <div className='col-9'>When the response provided by Site Coordinator satisfies the query, Data Manager or Clinical Research Associate will close the query.</div>
                </div>
            </div>
        </React.Fragment>
    )
}
export default SubjectStatus