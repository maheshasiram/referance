import * as React from 'react';
import Sites from './components/Sites';
import ReportStatus from './components/reportStatus/ReportStatus';
import VisitsInfo from './components/VisitsInfo';
import CommonCard from '../../common/styleComponents/CommonCard';
import Queries from './components/queries/Queries';

import './style.scss'
import StudyStatusDetails from './components/studyStatus/StudyStatusDetails';

function DashBoard() {
    return (
        <div className='container-fluid home-dashboard container'>
            <h3>Dashboard</h3>
            <div className="row m-0 p-0 mt-1 sites-status">
                <div className="col-sm-7 p-0">
                    <CommonCard><Sites /></CommonCard>
                </div>
                <div className="col-sm-5 studyStatus">
                      <CommonCard><StudyStatusDetails /></CommonCard>
                </div>
            </div>
            <div className="row m-0 p-0 mt-1 Report-status">
                <CommonCard><ReportStatus /></CommonCard>
            </div>
            <div className="row m-0 p-0 mt-1 visits-info">
                <CommonCard><VisitsInfo /></CommonCard>
            </div>
            <div className='row m-0 p-0 mt-1 queries'>
                <CommonCard><Queries/></CommonCard>
            </div>
        </div>
    )
}

export default DashBoard;
