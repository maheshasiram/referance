import { combineReducers } from "redux";
import { application } from "./application";
import { study } from '../modules/studySetup/modules/study/reducer/study';
import { visits } from '../modules/studySetup/modules/visits/reducer/visits';
import { sites } from "../modules/studySetup/modules/sites/reducer/sites";
import { forms } from "../modules/studySetup/modules/forms/reducer/forms";
import { dynamics } from "../modules/studySetup/modules/fieldLevelDynamics/reducers/dynamics";
import { derivations } from "../modules/studySetup/modules/derivations/reducers/derivations";
import { rolesandPermissions } from "../modules/studySetup/modules/rolesandPermissions/reducer/rolesandpermissions";
import { rules } from "../modules/studySetup/modules/rules/reducer/rules";
// import { labranges } from "../modules/studySetup/modules/labranges/reducer/labranges";
import { subjects } from "../modules/subjects/modules/subjectsList/reducers/Subjects";
import { labs } from "../modules/studySetup/modules/labs/reducer/labs";
import { auditLogs } from "../modules/studySetup/modules/auditLogs/reducers/auditLogs";
// import { UserManagement } from "../modules/userManagement";
import { userManagement } from "../modules/userManagement/reducer/userManagement";
import { downloads } from "../modules/downloads/reducer/downloads";
import { casebook } from "../modules/submission/modules/caseBooks/reducer/casebook";
import { dataexport } from "../modules/submission/modules/dataExport/reducers/dataexport";
import { approvals } from "../modules/approvals/reducer/approvals";
import { queriesList } from "../modules/queryListing/reducers/queryList";
import { reports } from "../modules/reports/reducer/Reports";
import { bulkLock } from "../modules/bulkLock/reducers/bulkLock";
import { importData } from "../modules/subjects/modules/importData/reducer/importData";


const reducer = combineReducers({
    application,
    sites,
    study,
    forms,
    visits,
    dynamics,
    rolesandPermissions,
    derivations,
    rules,
    // labranges,
    subjects,
    labs,
    auditLogs,
    userManagement,
    downloads,
    casebook,
    dataexport,
    queriesList,
    reports,
    bulkLock,
    approvals,
    importData
})

export type RootState = ReturnType<typeof reducer>;

export default reducer;