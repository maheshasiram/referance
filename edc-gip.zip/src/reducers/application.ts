import { RolesData } from "../constants/RolesData";
import { Types } from "../constants/Types";
import _ from 'lodash';
import { closedQueriesModal, reOpenQueryModal, respQueriesModal, stickyNotesModal } from "../constants/modal";
import { queryData } from "../constants/queryData";
import { AllStudyData } from "../components/home/constants/allStudiesData";
import { ClosedQueryData } from "../components/home/constants/closedQuery";
import { ReopenQueryData } from "../components/home/constants/reopenQuery";
import { RespondedQueryData } from "../components/home/constants/respondedQuery";
import { OpenQueryData } from "../components/home/constants/openQueryData";
import { pageModal } from "../modules/subjects/modules/subjectsList/constants/modal";
import { addReasonToCloseModal } from "../modules/queryListing/constants/modal";


const initialState = {
  isLoader: false,
  studies: [],
  roles: RolesData,
  rolesCopy: [],
  studiesCopy: [],
  currentStudy: {
    id: 2,
    name: ''
  },
  modal: {
    header: '',
    status: 0,
    open: false,
    message: "",
    disabled: false,
    actionType: '',
    onOk: () => { return null},
    onCancel: () => {  return null},
  },
  isToast: { status: 0, message: '', open: false },
  allStudyData: AllStudyData,
  openQueryData: OpenQueryData,
  closedQueryData: ClosedQueryData,
  reopenQueryData: ReopenQueryData,
  respondedQueryData: RespondedQueryData,
  queriesData: queryData,

  queriesInitialState: {
    closedQuery: closedQueriesModal,
    responseQuery: respQueriesModal,
    reopenQuery: reOpenQueryModal,
    stickyNotes: stickyNotesModal,
  },
  stickyNotesTableData: [],
  page: pageModal,
  currentUser: {
    id: 1,
    userName: "aditya thadikonda",
    role: "study designer"
  },
  allCountries: null,
  allStates: null,
  allCities: null,
  openCustomDialog: false,
  viewQueryData: [],
  configCodes: null,
  //setting subject field id globally so we can pass the subject field is to view,open,close,reopen,respond query
  subjectFieldId: null,
  reasonsToClose: [],
  addReasonToClose: addReasonToCloseModal,
  openAddReasonDialog: false
}

export const application = (state = initialState, action: { type: any, payload: any }) => {
  switch (action.type) {
    case Types.ON_OPEN_ALERT_DIALOG:
      return { ...state, modal: action.payload }
    case Types.ON_CLOSE_ALERT_DIALOG:
      return { ...state, modal: action.payload }
    case Types.ON_SET_LOADER:
      return { ...state, isLoader: action.payload }
    case Types.IS_TOAST_ENABLED:
      return { ...state, isToast: action.payload }
    case Types.FETCH_STUDY_DETAILS:
      return { ...state, currentStudy: action.payload }
    case Types.FETCH_STUDIES:
      return { ...state, studies: action.payload, studiesCopy: _.cloneDeep(action.payload) }
    case Types.FETCH_ROLES:
      return { ...state, roles: action.payload, rolesCopy: _.cloneDeep(action.payload) }
    case Types.SEARCH_STUDY:
      return { ...state, studies: action.payload }
    case Types.VIEW_QUERIES:
      return { ...state, queriesInitialState: action.payload }
    case Types.STICKY_NOTES_TABLE_DATA:
      return { ...state, stickyNotesTableData: action.payload }
    case Types.SEARCH_ROLES:
      return { ...state, roles: action.payload }
    case Types.UPDATE_DATAENTRY_PAGES:
      sessionStorage.setItem('page', JSON.stringify(action.payload));
      console.log("...93reducer", action.payload);
      return { ...state, page: action.payload }
    case Types.FETCH_ALL_COUNTRIES:
      return { ...state, allCountries: action.payload }
    case Types.FETCH_STATES_BY_COUNTRY_ID:
      return { ...state, allStates: action.payload }
    case Types.FETCH_CITIES_BY_STATE_ID:
      return { ...state, allCities: action.payload }
    case Types.OPEN_CUSTOM_DIALOG:
      return { ...state, openCustomDialog: action.payload }
    case Types.GET_VIEW_QUERY_DATA:
      return { ...state, viewQueryData: action.payload } 
      case Types.CONFIG_CODES:
      return { ...state, configCodes: action.payload }
      // collecting subject field id globally
    case Types.SUBJECT_FIELDID:
      return { ...state, subjectFieldId: action.payload }
    // collecting reason to close globally
    case Types.GET_REASON_TO_CLOSE:
      console.log("...111", action.payload);
      return { ...state, reasonsToClose: action.payload }
    case Types.ADD_REASON_TO_CLOSE:
      console.log("...2888", action.payload);
      return { ...state, addReasonToClose: action.payload }
    case Types.OPEN_ADD_REASON_DIALOG:
      return { ...state, openAddReasonDialog: action.payload }
    default:
      return { ...state }
  }
}