export const lockStatusReport = {
    "data": [
        {
            "siteName": "site-1",
            "siteId": "1234",
            "subjectId": "101-001",
            "visitName": "visit-1",
            "formName": "form-1",
            "lockStatus": "Not Locked",
            "userName": "mbhukya",
            "DateAndTime": "12/2/2023-12:30pm"
        },
        {
            "siteName": "site-2",
            "siteId": "4563",
            "subjectId": "101-002",
            "visitName": "visit-2",
            "formName": "form-2",
            "lockStatus": "locked",
            "userName": "amishra",
            "DateAndTime": "24/4/2023-2:30pm"
        },
        {
            "siteName": "site-3",
            "siteId": "45632",
            "subjectId": "101-003",
            "visitName": "visit-3",
            "formName": "form-3",
            "lockStatus": "locked",
            "userName": "amishra",
            "DateAndTime": "24/5/2023-2:30pm"
        },
        
        
    ]
}