export const cleanPatientReport = {
    "data": [
        {
            "siteName": "site-1",
            "subjectId": "101-001",
            "visitName": "visit-1",
            "formName": "form-1",
            "visitStatus": "locked",
            "numberOfForms": "12",
            "notStartedFormCount": "2",
            "openQueries": "2",
            "respondedQueries": "1",
            "closedQueries": "2",
            "reOpenQueries": "3",
            "moniterPending": "4",
            "reviewPending": "5",
            "signPending": "6",
            "lockPending": "2"
        },
        {
            "siteName": "site-2",
            "subjectId": "101-003",
            "visitName": "visit-2",
            "formName": "form-2",
            "visitStatus": "unscheduled",
            "numberOfForms": "12",
            "notStartedFormCount": "2",
            "openQueries": "2",
            "respondedQueries": "1",
            "closedQueries": "2",
            "reOpenQueries": "3",
            "moniterPending": "4",
            "reviewPending": "5",
            "signPending": "6",
            "lockPending": "2"
        }
    ]
}