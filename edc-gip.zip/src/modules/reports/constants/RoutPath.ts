export const routePath = [
    'Lock status report', 'Clean patient report', 'Form status report', 'Monitor report', 'Site listing report',
    'Query details report', 'PI report', 'Audit report', 'Stick notes report', 'Forms status report by subject',
    'Query rate by variable report', 'Form status report by site', 'Query aging report', 'Variable status report',
    'Query rate by form report', 'Query rate by site report', 'Reason for change report', 'Query assigned to report',
    'User details report', 'User login audit details', 'Subject status report', 'Files data report'
]