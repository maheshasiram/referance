import React, { useRef } from 'react'
import { useParams } from 'react-router-dom'
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import Button from '@mui/material/Button';
import ButtonGroup from '@mui/material/ButtonGroup';
import { lockStatusReport } from './constants/LockStatusReport';
import { useDispatch, useSelector } from 'react-redux';
import { Types } from './reducer/types';
import { cleanPatientReport } from './constants/CleanPateintReport';


function Reports() {
  const params: any = useParams()
  const _params: any = Object.values(params).toString();
  const dispatch = useDispatch()
  const { report } = useSelector((state: any) => state.reports)
  const headers: any = useRef([])


  React.useEffect(() => {
    if (_params === 'lockStatusReport') {
      dispatch({ type: Types.GET_ALL_REPORT_TYPES, payload: lockStatusReport })
      // console.log('6....', _params, lockStatusReport, report)
      if (report.data?.length > 0) headers.current = Object?.keys(report?.data[0])
    } else if (_params === 'cleanPatientReport') {
      dispatch({ type: Types.GET_ALL_REPORT_TYPES, payload: cleanPatientReport })
      if (report.data?.length > 0) headers.current = Object.keys(report?.data[0])
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [_params, report])


  const handleDownloadClick = (e: any, para: string) => {
    alert(para)
  }
  const handleChange = (e: any) => {
    console.log('56....', e.target.value)
  }
  const camelToFlat = (camel: any) => {
    const camelCase = camel.replace(/([a-z])([A-Z])/g, '$1 $2').split(" ")
    console.log('')
    let flat = ""

    camelCase.forEach((word: any) => {
      flat = flat + word.charAt(0).toUpperCase() + word.slice(1) + " "
    })
    return flat
  }

  const headerTemplate = (rowData: any, i: any) => {

    return (
      <div>
        <div className=''>
          {camelToFlat(i)}
        </div >
        <div className='mt-2'>
          <input
            type="text"
            className='form-control'
            onChange={(e: any) => handleSearchChange(e, i)}
            placeholder='Search'
          />
        </div>
      </div>
    )
  }
  const handleSearchChange = (e: any, i: any) => {
    console.log('78.....', i, e.target.value)
  }

  return (
    <React.Fragment>
      <div className='row'>
        <div className='col-1' />
        <div className='col-10'>
          <div className='m-3'>{camelToFlat(_params)}</div>
          <hr />
          <div className='d-flex w-50 m-3'>
            <span className='mt-2'>Show :</span>&nbsp;
            <select name="showData" className='form-select w-25' onChange={handleChange}>
              <option value="10" >10</option>
              <option value="25">25</option>
              <option value="50">50</option>
              <option value="100">100</option>
            </select>
            <ButtonGroup variant="contained" aria-label="outlined primary button group" sx={{ ml: '10px', padding: '0px' }}>
              <Button onClick={(e: any) => handleDownloadClick(e, 'pdf')}>PDF</Button>
              <Button onClick={(e: any) => handleDownloadClick(e, 'excel')}>Excel</Button>
            </ButtonGroup>
          </div>
          <>
         { console.log('120...', headers)}
          {/* {console.log('')} */}
          </>
          <DataTable
            value={report && report.data}
            dataKey="id"
            filterDisplay="row"
            emptyMessage="No customers found."
            responsiveLayout="scroll"
            stripedRows={true}
            rows={10}
            scrollable
            paginator={true}
          >
            {
               headers?.current?.map((i: any) => {
                return <Column
                  header={(rowData: any) => headerTemplate(rowData, i)}
                  field={i}
                  // sortable
                  style={{ minWidth: '12rem' }}
                >
                </Column>
              })

            }
          </DataTable>
        </div>
        <div className='col-1' />
      </div>
    </React.Fragment >
  )
}

export default Reports



