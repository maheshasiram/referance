import React from "react";
import { Route, Routes } from "react-router-dom";
import Reports from "../components/Reports";

export function ReportRoutes() {
    return (
        <Routes>
            <Route path='lockStatusReport' element={<Reports />}></Route>
            <Route path='cleanPatientReport' element={<Reports />}></Route>
            <Route path='formStatusReports' element={<Reports />}></Route>
            <Route path='monitorReports' element={<Reports />}></Route>
            <Route path='siteListingReport' element={<Reports />}></Route>
            <Route path='queryDetailsReports' element={<Reports />}></Route>
            <Route path='piReports' element={<Reports />}></Route>
            <Route path='stickyNotesReports' element={<Reports />}></Route>
            <Route path='formStatusReportBySubject' element={<Reports />}></Route>
            <Route path='queryAgingReports' element={<Reports />}></Route>
            <Route path='variableStatusReports' element={<Reports />}></Route>
            <Route path='queryRateByFormReports' element={<Reports />}></Route>
            <Route path='reasonForChangeReport' element={<Reports />}></Route>
            <Route path='queryAssignedToReports' element={<Reports />}></Route>
            <Route path='userDetailsReports' element={<Reports />}></Route>
            <Route path='userLoginAuditReports' element={<Reports />}></Route>
            <Route path='userLoginAuditDetails' element={<Reports />}></Route>
            <Route path='subjectStatusReport' element={<Reports />}></Route>
            <Route path='filesDataReports' element={<Reports />}></Route>
        </Routes>
    )
}
