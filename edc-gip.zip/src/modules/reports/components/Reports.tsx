import React from 'react'
import { ReportRoutes } from '../routes'

function Reports(){
    return(
        // <h1>Reports</h1>
        <ReportRoutes/>
    )
}
export default Reports