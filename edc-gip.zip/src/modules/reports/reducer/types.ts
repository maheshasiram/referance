export const Types = {
    GET_ALL_REPORT_TYPES: 'GET_ALL_REPORT_TYPES',
}