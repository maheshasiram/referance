import { Types } from "./types";
import { lockStatusReport } from "../constants/LockStatusReport";

const initialState = {
    report: {data:[]}
}

export const reports = (state = initialState, action: any) => {
    switch (action.type) {
        case Types.GET_ALL_REPORT_TYPES:
            console.log('10...', action.payload)
            return { ...state, report: action.payload }
        default: return { ...state }
    }
}