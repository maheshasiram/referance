import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import BulkTreeView from '../../approvals/helpers/BulkTreeView';
import { subjectFormBulkLock } from '../actions/actions';
import UserLogin from '../../approvals/helpers/UserLogin';
import '../styles/Styles.scss'

function BulkLock() {
    const [selectedKeys, setSelectedKeys] = React.useState(null);
    const [nodeFormId, setNodeFormId] = React.useState([]);
    const [selectValue, setSelectValue] = React.useState("lock");
    const [open, setOpen] = React.useState(false);
    const dispatch = useDispatch();
    const { treeNode } = useSelector((state: any) => state.bulkLock);
    const [form_Id] = useState<any>([]);
    const [unSelectedForm_Id, setUnselectedForm_Id] = useState<any>([]);

    useEffect(() => {
        const payload = { params: 'getBulkLockData', data: { formIds: [{ formId: 0, comments: "" }] } }
        dispatch(subjectFormBulkLock(payload))
    }, [dispatch]);

    const onSubmitBulkMonitor = () => {
        setOpen(true)
    }

    const setNodeData = (formId: any) => {
        setNodeFormId([]);
        setNodeFormId(formId);
        console.log('...node26',formId);
    }
    console.log('...node2600',nodeFormId);

    const onSelectValue = (e: any) => {
        setSelectValue(e.target.value);
        const payload = { params: `${e.target.value === 'unlock' ? 'getBulkUnlockData' : 'getBulklockData'}`, data: { formIds: [{ formId: 0, comments: "" }] } }
        dispatch(subjectFormBulkLock(payload))
    }
    const onSelcetNode = (node: any) => {
        // if (node) {
            console.log('removedArray', node);

        //     setAllNode([...allNode, node.node])
        // }
        // let removedFormId = onUnselect();

        node?.node?.children?.map((item: any) => {
            item?.children?.map((i: any) => {
                i.children?.map((subi: any) => {
                    if (form_Id.indexOf(subi.subject_form_id) === -1) {  //this if is for avoiding duplicate
                        form_Id.push(subi.subject_form_id);
                    }
                    return null
                })
                return null
            })
            return null
        })
        console.log('form_Id', form_Id);
        if (unSelectedForm_Id.length > 0) {    //this condition for removing unselect node ids
            let removedArray = form_Id.filter(function (el: any) {
                return !unSelectedForm_Id.includes(el);
                // return unSelectedForm_Id.indexOf(el) < 0;
            });
            setUnselectedForm_Id([])
            setNodeData(removedArray);
        } else {
            setNodeData(form_Id);

        }
        // console.log('removedArray', removedArray);
    }
    console.log('removedArray00', form_Id);

    const onUnselect = (node: any) => {
        node?.node?.children?.map((item: any) => {
            item?.children?.map((i: any) => {
                i.children?.map((subi: any) => {
                    // if (form_Id.indexOf(subi.subject_form_id) === -1) {// }
                    unSelectedForm_Id.push(subi.subject_form_id);
                    return null
                })
                return null
            })
            return null
        })
        // console.log('...unSelectedForm_Id00', unSelectedForm_Id);
        // return unSelectedForm_Id
    }

    return (
        <div>
            <div className='container'>
                <h2>Bulk Lock</h2>
                <div className='col-sm-2 my-2'>
                    <select className="form-control form-select" onChange={onSelectValue}>
                        <option value='lock'>Lock</option>
                        <option value='unlock' >Un Lock</option>
                    </select>
                </div>
                <div className='tree-card'>
                    <BulkTreeView
                        value={treeNode}
                        selectionMode="checkbox"
                        filter
                        filterMode="lenient"
                        selectionKeys={selectedKeys}
                        onSelectionChange={(e: any) => setSelectedKeys(e.value)}
                        setNodeData={setNodeData}
                        onUnselect={onUnselect}
                        onSelcetNode={onSelcetNode}
                    />


                </div>
                <div className="d-flex justify-content-end pt-3">
                    <button type="submit" className=" btn btn-primary " onClick={onSubmitBulkMonitor}>Submit</button>
                </div>
            </div>
            <UserLogin setOpen={setOpen} open={open} selectValue={selectValue} nodeFormId={nodeFormId} />
        </div>
    )
}
export default BulkLock
