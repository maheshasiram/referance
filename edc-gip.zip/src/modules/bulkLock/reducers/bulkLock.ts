// import { TreeViewData } from "../helpers/TreeViewData";
import { Types } from "./Types";

const initialState = {
    treeNode: null,
    // bulkLockStatus:{userId:'',lockStatus:'',comments:''}
}

export const bulkLock = (state = initialState, action: any) => {
    switch (action.type) {
        case Types.GET_TREE_NODE:
            console.log('action.payload', action.payload);
            return { ...state, treeNode: action.payload }
            case Types.BULK_LOCK_STATUS:
            return { ...state, bulkLockStatus: action.payload }
        default: return { ...state }
    }

}
