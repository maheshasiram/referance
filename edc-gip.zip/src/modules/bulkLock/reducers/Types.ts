export const Types = {
    GET_TREE_NODE:'GET_TREE_NODE',
    BULK_LOCK_STATUS:'BULK_LOCK_STATUS'
}