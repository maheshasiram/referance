import { TreeViewData } from "../helpers/TreeViewData";
import { Types } from "../reducers/Types";
import { studySetup } from "../../../configs/enivornment/studySetup";
import { fetch } from "../../../constants/fetch";
import { Loader } from "../../../actions/actions";

export const fetchTreeNode: Function = () => {
    return function (dispatch: any) {

        dispatch({ type: Types.GET_TREE_NODE, payload: TreeViewData })
        // dispatch(Loader());
        // fetch({
        //     method: 'GET',
        //     url: '',
        //     data: '',
        // })
        //     .then((response: any) => {
        //         dispatch({ type: Types.GET_TREE_NODE, payload: TreeViewData })
        //         // if (callback) { callback(response) }
        //         dispatch(Loader());
        //     }).catch((error: any) => {
        //         console.log('error', error)
        //     })
    }

}
export const subjectFormBulkLock: any = (payload: any, callback: any) => {
    const url = `${studySetup.bulkLock.subjectFormBulkLock}?action=${payload.params}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload.data
        })
            .then((response: any) => {
                const data: any = response?.data?.data
                data && data?.map((item: any, index: any) => {
                    data[index].key = index
                    if (item.children && item.children.length > 0) {
                        item.children?.map((child: any, ci: any) => {
                            if (data[index].children[ci].children) {
                                data[index].children[ci].key = `${index}-${ci}`;

                                if (child.children && child.children.length > 0) {
                                    child.children.map((subChild: any, subIndx: number) => {
                                        child.children[subIndx].key = `${index}-${ci}-${subIndx}`;
 
                                        if(subChild.children &&  subChild.children.length > 0){
                                            subChild.children.map((subChildren:any,subSindx:number)=>{
                                                subChild.children[subSindx].key = `${index}-${ci}-${subIndx}-${subSindx}`;

                                                if(subChildren.children &&  subChildren.children.length > 0){
                                                    subChildren.children.map((subChi:any,subi:number)=>{
                                                        subChildren.children[subi].key = `${index}-${ci}-${subIndx}-${subSindx}-${subi}`;
                                                        return null
                                                    })
                                                }
                                                return null
                                            })
                                        }
                                        return null
                                    })
                                }
                            }
                            return null
                        });
                    }
                    return null
                })
                dispatch({ type: Types.GET_TREE_NODE, payload: data })
                dispatch(Loader(false))
                callback(response.data);
            })
            .catch((error) => {
                console.log("error....", error)
            })
    }
}
