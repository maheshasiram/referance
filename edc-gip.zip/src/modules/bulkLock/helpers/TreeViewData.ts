export const TreeViewData = {
    data: [
        {
            key: '0',
            label: 'apollo',
            id: 1,
            children: [
                {
                    key: '0-0',
                    label: 'apollo site-1',
                    id: 12,
                    children: [
                        {
                            key: '0-0-0',
                            label: 'subject-1',
                            id: 13,
                            statusId: "",
                        },
                        {
                            key: '0-0-1',
                            label: 'subject-2',
                            id: 14,
                            statusId: "",
                        }
                    ]
                },
                {
                    key: '0-1',
                    label: 'apollo site-2',
                    id: 12,
                    children: [
                        {
                            key: '0-1-0',
                            label: 'subject-1',
                            id: 13,
                            statusId: "",
                        },
                        {
                            key: '0-1-1',
                            label: 'subject-2',
                            id: 14,
                            statusId: "",
                        }
                    ]
                }
            ]
        }
    ]
}

