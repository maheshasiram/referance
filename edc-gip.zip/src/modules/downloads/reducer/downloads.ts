import { Types } from "./Types"

const initialState = {
    downloadAllData: [],
}

export const downloads = (state = initialState, action: { type: any, payload: any }) => {
    switch (action.type) {
        case Types.GET_ALL_DOWNLOAD_DATA:
            return { ...state, downloadAllData: action.payload }
        default:
            return { ...state }
    }
}