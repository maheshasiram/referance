export const Types ={
    GET_ALL_DOWNLOAD_DATA:"GET_ALL_DOWNLOAD_DATA"
}