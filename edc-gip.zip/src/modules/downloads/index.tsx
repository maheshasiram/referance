import React from 'react'
import './styles/Styles.scss'
import DownloadsDashboard from './components/DownloadsDashboard'

function Downloads() {
    return (
        <div className='container' >
            <div className='um-container' >
                <h2>Downloads</h2>
            </div>
            <DownloadsDashboard />
        </div>
    )
}

export default Downloads

