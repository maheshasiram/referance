export const downloadsData = [
    {
        "id": 1,
        "jobName": "CSC-CT-0211687350208338_PendingChangesReport_9",
        "status": "Completed",
        "date&time": "06/21/2023 05:53:39",
    },
    {
        "id": 2,
        "jobName": "CSC-CT-0211687350099890_PendingChangesReport_8",
        "status": "ongoing",
        "date&time": "07/11/2023 01:12:26"
    },
    {
        "id": 3,
        "jobName": "CSC-CT-0211687350081048_PendingChangesReport_7",
        "status": "Completed",
        "date&time": "06/12/2023 05:01:36"
    }, {
        "id": 4,
        "jobName": "CSC-CT-0211687350043808_PendingChangesReport_6",
        "status": "Completed",
        "date&time": "08/24/2023 05:52:43"
    }, {
        "id": 5,
        "jobName": "CSC-CT-0211687350031961_PendingChangesReport_5",
        "status": "Completed",
        "date&time": "05/30/2023 04:32:25"
    }, {
        "id": 6,
        "jobName": "CSC-CT-0211687350006235_PendingChangesReport_4",
        "status": "Ongoing",
        "date&time": "01/1/2023 05:52:29"
    }, {
        "id": 7,
        "jobName": "CSC-CT-0211687349993897_PendingChangesReport_3",
        "status": "Completed",
        "date&time": "06/21/2023 05:52:18"
    }, {
        "id": 8,
        "jobName": "CSC-CT-0211687349974751_PendingChangesReport_10",
        "status": "Ongoing",
        "date&time": "06/21/2023 05:52:06"
    }, {
        "id": 9,
        "jobName": "CSC-CT-0211687350081048_PendingChangesReport_11",
        "status": "Completed",
        "date&time": "06/21/2023 05:52:03"
    }, {
        "id": 10,
        "jobName": "CSC-CT-0211687350087520_PendingChangesReport_12",
        "status": "Ongoing",
        "date&time": "06/21/2023 05:52:14"
    }, {
        "id": 11,
        "jobName": "CSC-CT-021168735001475_PendingChangesReport_13",
        "status": "Completed",
        "date&time": "06/21/2023 05:52:16"
    }, {
        "id": 12,
        "jobName": "CSC-CT-021168735000255_PendingChangesReport_14",
        "status": "Ongoing",
        "date&time": "06/21/2023 05:52:20"
    }
]