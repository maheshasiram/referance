import { fetch } from "../../../constants/fetch";
import { studySetup } from "../../../configs/enivornment/studySetup";
import { Types } from "../reducer/Types";
import { Loader } from "../../../actions/actions";


export const fetchAllDownloadsData: any = () => {
    const url= `${studySetup.downloads.allDownloads}`
    return function (dispatch: any) {
      dispatch(Loader(true));
      fetch({
        method: 'GET',
        url: url
        // data: payload
      })
        .then((response: any) => {
          dispatch({ type: Types.GET_ALL_DOWNLOAD_DATA, payload: response.data });
          
          dispatch(Loader(false));
        })
        .catch(() => {
          dispatch(Loader(false));
        })
    }
  }
export const downloadFile: any = () => {
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: "POST",
            // url:url,
            // responseType:'blob',
        }).then((response: any) => {
            console.log("..44", response);

        })
    }
}