import React from "react";
import { useDispatch, useSelector } from 'react-redux';
import { Column } from 'primereact/column'
import { DataTable } from 'primereact/datatable'
import { fetchAllDownloadsData } from "../actions/actions";
import "../styles/Styles.scss"


function DownloadsDashboard() {
    const dispatch = useDispatch()
    const loaded = React.useRef(false);
    const { downloadAllData } = useSelector((state: any) => state.downloads);

    React.useEffect(() => {
        if (!loaded.current) {
            dispatch(fetchAllDownloadsData())
            console.log("payload", downloadAllData)
            loaded.current = true
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

     const downloadFile=()=>{
        console.log('....24');
        
     }
    const actionTemplate = (rowData: any) => {
        console.log('...rowData',rowData);
        
        return (<React.Fragment>
            {rowData.status === 'Completed' ? <a href='# ' onClick={downloadFile} className="text">Download</a> : ''}
        </React.Fragment>)
    }

    const statusTemplate = (rowData:any) =>{
        return (
            <>
            { rowData.status ==='Completed'? 'Completed': 'Fail'}
            </>
        )
    }


    return (
        <React.Fragment>
            <DataTable
                value={downloadAllData}
                selectionMode="single"
                emptyMessage="No data available to display"
                scrollable
                stripedRows={true}
                responsiveLayout="scroll"
            // rows={}
            // paginator={}
            // first={}
            // totalRecords={}
            // scrollHeight="300px
            // lazy 
            // onPage={} 
            >
                <Column field="fileName" header="FileName" style={{ flexBasis: '50px' }}></Column>
                <Column field="status" header="Status" body={statusTemplate}></Column>
                <Column field="dateCreated" header="Date Time Created "></Column>
                <Column body={actionTemplate} header="Action" ></Column>
            </DataTable>
        </React.Fragment >
    )
}
export default DownloadsDashboard;