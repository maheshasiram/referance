import { studySetup } from "../../../../../configs/enivornment/studySetup";
import { Types } from "../reducer/Types";
import { Loader } from "../../../../../actions/actions";
import { fetch } from "../../../../../constants/fetch";
import _ from 'lodash'

// api for visit table
export const fetchAllVisitsByStudyId: any = (payload: any) => {
    const url = `${studySetup.visits.fetchVisitsAllByStudyId}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload,
        })
            .then((response: any) => {
                dispatch({ type: Types.FETCH_VISITS_DETAILS, payload: response.data })
                dispatch(Loader(false))
            })
    }
}

// api for update,delete ,restore visit
export const updateVist: any = (payload: any, callback: any) => {
    const url = studySetup.visits.updateDeleteRestoreVist
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload,
        })
            .then((response: any) => {
                dispatch(Loader(false))
                if (callback) { callback(response.data) }
            })

    }                                                                               
}

// api for add visit
export const addVisitAction: any = (payload: any, callback: any) => {
    const url = studySetup.visits.addVisit
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload,
        })
            .then((response: any) => {
                dispatch(Loader(false))
                if (callback) { callback(response.data) }
            })

    }
}

//api for search visit name
export const findByVisitName: any = (payload: any, callback: any) => {
    const url = `${studySetup.visits.findByVisitName}?${payload}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
            data: null,
        })
            .then((response: any) => {
                if (callback) { callback(response.data) }
                dispatch(Loader(false))
                // let _response = response.data.content && response.data.content.map((item: any, index: any) => { return item })
                dispatch({ type: Types.FETCH_VISITS_DETAILS, payload: response.data })
            })
    }
}

// api for fetch Rearrange Form Order
export const fetchRearrangeFormOrder: any = (payload: any) => {
    const url = `${studySetup.visits.fetchFormsByVisitId}?visitId=${payload} `
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
            data: null,
        })
            .then((response: any) => {
                dispatch({ type: Types.FETCH_REARRANGE_FORM_ORDER, payload: response.data })
                dispatch(Loader(false))
            })

    }
}

// api for submit rearrange form order
export const saveRearrangeForms: any = (payload: any, callback: any) => {
    const visit_id = payload.map((item: any) => { return (item.visitId) })
    const url = `${studySetup.visits.saveRearrangeForms}?visitId=${visit_id[0]}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload,
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data)
                    dispatch(Loader(false))
                }
            })
    }
}

// api for select forms & variables
export const getAssignedFormFields: any = (payload: any, callback: any) => {
    const url = `${studySetup.visits.getAssignedFormFields}?studyId=${payload.studyId}&visitId=${payload.visitId}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
            data: '',
        })
            .then((response: any) => {
                const _forms: any = []
                response.data.filter((item: any) => {
                    if (item.formFields) {
                        _forms.push(item)
                    }
                    return null
                })
                const _selectedForms: any = []
                response.data.filter((item: any) => {
                    if (item.selected) {
                        _selectedForms.push(item)
                    }
                    return null
                })

                if(callback){callback(_forms)}
                dispatch({ type: Types.GET_SELECT_FORMS, payload: _forms })
                dispatch({ type: Types.GET_PREVIOUS_SELECTED_FORMS, payload: _.cloneDeep(_selectedForms) })
                dispatch(Loader(false))
            })
    }
}

// api for submit select forms and variables
export const updateSelectFormsAndVariables: any = (payload: any,visitId:any, callback: any) => {
    // let url = `${studySetup.visits.saveSelectFormsAndVariables}?visitId=${payload[0].visitForms[0].visitId}`
    const url = `${studySetup.visits.saveSelectFormsAndVariables}?visitId=${visitId}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload,
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data)
                    dispatch(Loader(false))
                }
            })
    }
}

// api for rearrange visits
export const fetchRearrangeVisits: any = (payload: any, callback: any) => {
    const url = `${studySetup.visits.rearrangeVisits}?studyId=${payload}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
            data: null,
        })
            .then((response: any) => {
                if (callback) { callback(response.data) }
                dispatch({ type: Types.GET_REARRANGE_VISITS, payload: response.data })
                dispatch(Loader(false))
            })
    }
}

// api for update rearrange visits
export const updateRearrangeVisits: any = (payload: any, callback: any) => {
    const url = `${studySetup.visits.updateVisitOrdinal}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload,
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data)
                    dispatch(Loader(false))
                }
            })
    }
}

export const deleteOrRestoreVisit: any = (payload: any, callback: any) => {
    const url = `${studySetup.visits.deleteOrRestoreVisit}?visitId=${payload.visitId}&status=${payload.status}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
            data: null,
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data)
                }

            })

    }
}

export const findAllVisitsByStudyId: any = (payload: any, callback: any) => {
    const url = `${studySetup.visits.findAllVisitsByStudyId}?studyId=${payload}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
            data: null,
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data)
                }

            })

    }
}
export const visitDateMapping: any = (payload: any, callback: any) => {
    const url = `${studySetup.visits.visitDateMapping}?visitId=${payload}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
            data: null,
        })
            .then((response: any) => {
                if (callback) { callback(response.data) }
                dispatch({ type: Types.VISIT_DATE_MAPPING, payload: response.data})
        dispatch(Loader(false))
                
            })
    }
}
export const addupdateVisitDateMapping: any = (payload: any, callback: any) => {
    const url = `${studySetup.visits.addupdateVisitDateMapping}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload,
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data)
                }
                dispatch(Loader(false))

            })
    }
}