import { Types } from "./Types";
import { addOrEditVisitModal, lazyParamsModal } from '../constants/modal';

const initialState = {
    visitDetails: null,
    addOrEditVist: addOrEditVisitModal,
    rearrangeFormOrderData: [],
    selectFormsAndVriable: [],
    allSelectFormVariables: [],
    lazyParams: lazyParamsModal,
    rearrangeVisitsData: [],
    previousSelectedForms: [],
    visitMapping : []
}

export const visits = (state = initialState, action: { type: string, payload: any }) => {
    switch (action.type) {
        case Types.FETCH_VISITS_DETAILS:
            console.log('visitDetails...',action.payload)
            return { ...state, visitDetails: action.payload }
        case Types.LAZY_PAGINATION_VISITS:
            return { ...state, lazyParams: action.payload }
        case Types.ADD_OR_EDIT_VISIT:
            console.log("...22", action.payload)
            return { ...state, addOrEditVist: action.payload }
        case Types.FETCH_REARRANGE_FORM_ORDER:
            return { ...state, rearrangeFormOrderData: action.payload }
        case Types.GET_SELECT_FORMS:
            return { ...state, selectFormsAndVriable: action.payload, allSelectFormVariables: action.payload }
            // return { ...state, allSelectFormVariables: action.payload }
        case Types.ON_SELECT_FORMS:
            // return { ...state, selectFormsAndVriable: action.payload, allSelectFormVariables: action.payload }
            return { ...state, selectFormsAndVriable: action.payload }
        case Types.ON_SELECT_FORM_SEARCH:
            return { ...state, allSelectFormVariables: action.payload }
            // return { ...state, selectFormsAndVriable: action.payload }
        case Types.GET_REARRANGE_VISITS:
            return { ...state, rearrangeVisitsData: action.payload }
        case Types.GET_PREVIOUS_SELECTED_FORMS:
            return { ...state, previousSelectedForms: action.payload }
            case Types.VISIT_DATE_MAPPING:
                return { ...state, visitMapping: action.payload }
        default:
            return { ...state }
    }

}