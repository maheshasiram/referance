import React from 'react';
const VisitType = (props: any) => {
    const { values, setFieldValue, enableSubmit } = props

    console.log("..9", values)

    React.useEffect(() => {
        
        props.actionType === 'add' ?
            setFieldValue('visitTypeCode', values.visitRepeat === 'true' ? "VISIT_TYP_UNSCHEDULED" : 'VISIT_TYP_SCHEDULED') :
            setFieldValue('visitTypeCode', values.visitTypeCode)
            // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [values.visitRepeat, setFieldValue])

    const onChangeSelect = (e: any) => {
        setFieldValue('visitTypeCode', e.target.value);
        enableSubmit(false)
    }

    return (
        <React.Fragment>
            <div className="mb-4">
                <label className="pb-1">Type of Visit :</label>
                <select value={values.visitTypeCode} className='form-control form-select' onChange={onChangeSelect}>
                    {(values.visitRepeat === '' || values.visitRepeat === 'false' || values.visitRepeat === false) && <option value='VISIT_TYP_SCHEDULED'>Scheduled</option>}
                    {(values.visitRepeat === '' || values.visitRepeat === 'true' || values.visitRepeat === true) && <option value='VISIT_TYP_UNSCHEDULED'>Unscheduled</option>}
                    {(values.visitRepeat === '' || values.visitRepeat === 'true' || values.visitRepeat === true) && <option value='VISIT_TYP_COMMON'>Common</option>}
                </select>
            </div>
        </React.Fragment>
    );
};

export default VisitType;