import React from "react";
import { useDispatch, useSelector } from "react-redux";
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import { visitDateMapping,addupdateVisitDateMapping } from '../actions/actions';
import CustomDialog from "../../../../../common/modals/CustomeDialog";
import SelectField from "../../../../../common/selectField/SelectField";
import { toastAlert } from "../../../../../actions/actions";
import { Form, Formik } from "formik";
import * as Yup from 'yup';
import CustomToolTip from "../../../../../components/CustomToolTip";


function VisitDateMapping(props: any) {

    const { visitMapping } = useSelector((state: any) => state.visits)

    const dispatch = useDispatch()

    const [open, setOpen] = React.useState(false)
    const [fieldList, setFieldList] = React.useState([]);
    const [dateMappingPayload, setdateMappingPayload] = React.useState({
        "formId": '',
        "fieldId": '',
    });
    const visitDateValidation = Yup.object().shape({
        formId: Yup.string()
            .required("Please select Formname").nullable(),
        fieldId: Yup.string()
            .required("Please select variable ").nullable(),
    });


    const onCloseHandler = () => {
        setOpen(false)
        const payload = { ...dateMappingPayload, fieldId: '', formId: '' }
        setdateMappingPayload(payload)

    }

    const onVisitDate = (rowData: any) => {
        const _dateMappingPayload : any= { ...{}, ...dateMappingPayload }
        dispatch(visitDateMapping(rowData.id, (response: any) => {
            // console.log('50...', response);
            response.map((item: any) => {
                if (item.formStatus) {
                    _dateMappingPayload.formId = {label: item.formName, value: item.formId}
                    item.fieldsList.map((i: any) => {
                        if (i.fieldStatus) {
                            _dateMappingPayload.fieldId = {label: i.variableId, value: i.id}

                        }
                        return null
                    })
                    setdateMappingPayload(_dateMappingPayload)
                }
                return null
            })
            setOpen(true)
        }))

    }
    const onChangeFormHandler = (e: any, setFieldValue: any) => {
        setFieldValue('formId', e)
        setFieldValue('fieldId', '')
        visitMapping.map((item: any) => {
            // console.log('e..63.', item);
            if (item.formId === e.value) {
                // console.log('event', item.fieldsList);
                setFieldList(item.fieldsList)
            }
            return null
        })
    }
    const onChangeVariableHandler = (e: any, setFieldValue: any) => {
        setFieldValue('fieldId', e)
        // console.log('e...', e.value);
    }
    const formOptions = (formsList: any) => {
        const _forms: any = []
        formsList.map((item: any) => {
            const option = {
                label: item.formName,
                value: item.formId
            }
            _forms.push(option)
            return null;
        })
        return _forms
    }
    const variablesOptions = () => {
        const _variable: any = []
        fieldList.map((item: any) => {
            const option = {
                label: item.variableId,
                value: item.id
            }
            _variable.push(option)
            return null;
        })
        return _variable
    }
    const onSubmit = (values: any) => {
        const payload = { ...dateMappingPayload, visitId: props.rowData.id, fieldId: values.fieldId.value, formId: values.formId.value, "status": true }
        dispatch(addupdateVisitDateMapping(payload, (response: any) => {
            if (response.status === true) {
                dispatch(toastAlert({
                    status: 1,
                    open: true,
                    message: 'Visits Date Mapping updated successfully',
                }))
                onCloseHandler()
            } else {
                dispatch(toastAlert({
                    status: 2, message: `${response.errorMessage}`, open: true
                }))
            }
        }))

    }


    return (
        <React.Fragment>
            <CustomToolTip title='Visit Date Mapping'><CalendarMonthIcon className="ms-1" sx={{ fontSize: 14, opacity: .8 }} onClick={() => onVisitDate(props.rowData)} /></CustomToolTip>
            <CustomDialog
                title={`Visit Date Mapping ( ${(props.rowData?.visitName)} )`}
                open={open}
                onClose={onCloseHandler}
                actionType='Submit'
                maxWidth='sm'
                form={'dateMap'}
            >
                <Formik
                    initialValues={dateMappingPayload}
                    validationSchema={visitDateValidation}
                    onSubmit={(values: any) => {
                        onSubmit(values)
                    }}
                >
                    {({ errors, touched, values, setFieldValue }) => (
                        <Form id='dateMap' >
                            {/* <>  {console.log('values.........', values)}</> */}
                            <div>

                                <label>Forms </label> :
                                <SelectField
                                    name={"formId"}
                                    value={values.formId}
                                    onChange={(e: any) => onChangeFormHandler(e, setFieldValue)}
                                    options={formOptions(visitMapping)}
                                    placeholder={'Select Forms'}
                                />
                                {/* {error ? <p className='text-danger'>{error}</p> : <span>&nbsp;</span>} */}


                                {(errors && errors.formId && touched && touched.formId) &&
                                    <span className="text-danger">{errors.formId as string}</span>}
                            </div>
                            <div className="mb-5">
                                <label>Variables </label> :
                                <SelectField
                                    name={"fieldId"}
                                    value={values.fieldId}
                                    onChange={(e: any) => onChangeVariableHandler(e, setFieldValue)}
                                    options={variablesOptions()}
                                    placeholder={'Select Variables'}
                                />
                                {(errors && errors.fieldId && touched && touched.fieldId) &&
                                    <span className="text-danger">{errors.fieldId as string}</span>}
                            </div>
                        </Form>
                    )}
                </Formik>
            </CustomDialog>
        </React.Fragment>
    )
}
export default VisitDateMapping;