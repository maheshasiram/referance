import React from "react";
import CustomDialog from "../../../../../common/modals/CustomeDialog";
import { fetchRearrangeFormOrder, fetchAllVisitsByStudyId, findByVisitName ,saveRearrangeForms} from '../actions/actions'
import { useSelector, useDispatch } from "react-redux";
import { Box } from '@mui/material';
import { List, arrayMove } from "react-movable";
import ListItem from '@mui/material/ListItem';
import ContactPageIcon from '@mui/icons-material/ContactPage';
import {  toastAlert } from "../../../../../actions/actions";

function RearrangeForms(props: any) {

    const dispatch = useDispatch()
    const { rearrangeFormOrderData, lazyParams } = useSelector((state: any) => state.visits)
    const [open, setOpen] = React.useState(false)
    const [btnDisable, setBtnDisable] = React.useState(true)
    const { currentStudy } = useSelector((state: any) => state.application)
    const [items, setItems] = React.useState(rearrangeFormOrderData && rearrangeFormOrderData);
    const { rowData } = props
    const [errorMsg, setErrorMsg] = React.useState('')
    React.useEffect(() => {
        setItems(rearrangeFormOrderData && rearrangeFormOrderData);
    }, [rearrangeFormOrderData])
    const onRearrangeFormOrderClick = () => {
        if (rowData.status) {
            setOpen(true)
            dispatch(fetchRearrangeFormOrder(rowData.id))
        }

    }
    const onCloseHandler = () => {
        setOpen(false)
        setBtnDisable(true)
    }

    const onChangeHandler = (items: any, oldIndex: any, newIndex: any) => {
        setItems(arrayMove(items, oldIndex, newIndex));
        setBtnDisable(false)
    }
    const onSubmitHandler = () => {
        const _data = [...[], ...items]
        const _arr: any = []
        _data.map((item, index) => {
            const _obj = {
                "formId": item.id,
                "visitId": rowData.id,
                "doubleDataEntry": true,
                "repeatStatus": true,
                "repeatMax": 0,
                "formSelected": item.status,
                "ordinal": index + 1
            }
            _arr.push(_obj)
            return null;
        })
        dispatch(saveRearrangeForms(_arr, (data: any) => {
            setOpen(false)
            const _payload = {...lazyParams, studyId: currentStudy.id}
            props.searchVisitVal ? dispatch(findByVisitName(props.searchVisitVal)) : dispatch(fetchAllVisitsByStudyId(_payload))
            if (data.errorMessage) {
                setErrorMsg(data.errorMessage)
            } else {
                dispatch(toastAlert({
                    status: 1,
                    open: true,
                    message: 'Forms order updated successfully'
                }))
            }
        }))
    }
    return (
        <React.Fragment>
            <p className={`${rowData.status ? 'rearrangeForms-active' : 'rearrangeForms-deleted'}`}
                onClick={() => onRearrangeFormOrderClick()}>{rowData.status ? 'Rearrange Form Order' : '-'}</p>
            <CustomDialog
                title={`Rearrange Forms Order (${rowData.visitName})`}
                open={open}
                onClose={onCloseHandler}
                actionType='Submit'
                maxWidth='sm'
                fullWidth={false}
                onSubmitHandler={onSubmitHandler}
                disabled={btnDisable}
            >
                <div className="dialog-body-rearrangeVisits">
                    {
                        (items && items.length > 0 ?
                            <Box sx={{}}>
                                {errorMsg ? <span className="d-flex justify-content-center text-danger">{errorMsg}</span> : <span>&nbsp;</span>}
                                <p className="rearrange-note"> <strong> Note: </strong>Rearranged forms order will appear in the visits in the subject list page</p>
                                <List
                                    values={items}
                                    onChange={({ oldIndex, newIndex }) => {
                                        onChangeHandler(items, oldIndex, newIndex);
                                    }}
                                    renderList={({ children, props, isDragged }) => <ul className={isDragged ? "grabbing list-items-container" : " list-items-container "} id={`VisitElement`} {...props}>{children}</ul>}
                                    renderItem={({ value, props, isDragged}: any) =>
                                        <ListItem className={isDragged ? "grabbing list-item" : "grab list-item"} id={`VisitItem${value.ordinal}`}
                                             {...props}>
                                            <div style={{ zIndex: 9 }} className="draggable-item"></div>
                                            <ContactPageIcon /><p>{value.formName}</p>
                                        </ListItem>
                                    }
                                />
                            </Box> : <p className="no-item-available">No forms available to display</p>)
                    }
                </div>
            </CustomDialog>
        </React.Fragment>
    )
}
export default RearrangeForms;