import React from "react";
import EditIcon from '@mui/icons-material/Edit';
import CustomDialog from "../../../../../common/modals/CustomeDialog";
import { updateVist, addVisitAction, fetchAllVisitsByStudyId, findByVisitName } from '../actions/actions';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from "yup";
import { useSelector, useDispatch } from "react-redux";
import { Types } from "../reducer/Types";
import { toastAlert } from "../../../../../actions/actions";
import VisitType from "../helpers/VisitType";
import CustomToolTip from "../../../../../components/CustomToolTip";

function AddOrEditVisit(props: any) {
    const dispatch = useDispatch()
    const [open, setOpen] = React.useState(false)
    const [submitDisabled, setSubmitDisabled] = React.useState(true)
    const { addOrEditVist, lazyParams } = useSelector((state: any) => state.visits)
    const { currentStudy } = useSelector((state: any) => state.application)
    const { rowData, actionType, Selection, searchVisitVal } = props
    const [errorMsg, setErrorMsg] = React.useState('')

    const visitsValidationSchema = Yup.object().shape({
        visitName: Yup.string()
            .matches(/^[a-zA-Z]/, 'Visit name should start with text')
            .required('Please enter visit name')
            .max(50, 'Visit name should be less than 50 characters'),
        visitRepeat: Yup.string().required('Please select repeating'),
        visitTypeCode: Yup.string().required('Please select type')
    })

    const onCloseHandler = () => {
        setOpen(false)
        setErrorMsg('')
    }
    const onEditVisit = () => {
        const _payload = {
            'id': rowData.id,
            'visitName': rowData.visitName,
            "visitTypeCode": rowData.visitType && rowData.visitType.code,
            "ordinal": rowData.ordinal,
            "visitLockStatus": rowData.visitLockStatus,
            "visitRepeat": rowData.visitRepeat.toString(),
            "status": rowData.status,
            "studyId": currentStudy.id
        }
        dispatch({ type: Types.ADD_OR_EDIT_VISIT, payload: _payload })
        setOpen(true)
        setSubmitDisabled(true)
    }
    const onAddVisit = () => {
        setOpen(true)
        setSubmitDisabled(true)
        dispatch({
            type: Types.ADD_OR_EDIT_VISIT, payload:
            {
                id: '',
                visitName: '',
                visitTypeCode: 'VISIT_TYP_SCHEDULED',
                ordinal: 0,
                visitLockStatus: true,
                visitRepeat: 'false',
                status: true,
                studyId: currentStudy.id
            }
        })
    }
    const onSubmitHandler = (values: any) => {
        dispatch((actionType === 'add' ? addVisitAction : updateVist)(values, (data: any) => {
            if (data.errorMessage) {
                setErrorMsg(data.errorMessage)
            } else {
                setErrorMsg('')
                onCloseHandler()
                const _payload = { ...lazyParams, studyId: currentStudy.id }
                console.log("75...", _payload)
                !searchVisitVal && dispatch(fetchAllVisitsByStudyId(_payload))
                actionType === 'edit' && dispatch(findByVisitName(`${Selection}=${searchVisitVal}`))
                dispatch(toastAlert({
                    status: 1,
                    open: true,
                    message: data.errorMessage ? data.errorMessage : actionType === 'add' ? `${values.visitName} visit added successfuly` : `${values.visitName} visit updated successfully`
                }))
            }
        }))
    }

    return (
        <React.Fragment>
            {actionType === 'add' && <button type="button" className="btn-eoutlined-secondary me-1" onClick={() => onAddVisit()}>Add Visit</button>}
            {actionType === 'edit' && <CustomToolTip title='Edit Visit'><EditIcon sx={{ fontSize: 14, opacity: .8 }} onClick={() => onEditVisit()} /></CustomToolTip>}
            <CustomDialog
                title={props.actionType === 'add' ? 'Add Visit' : 'Update Visit'}
                open={open}
                onClose={onCloseHandler}
                form="addVisit"
                disabled={submitDisabled}
                maxWidth='xs'
                fullWidth={false}
                actionType={props.actionType === 'add' ? 'Submit' : 'Update'}
            >
                <div id='add-edit-visit' className='add-edit-visits mt-3'>
                    <Formik
                        initialValues={addOrEditVist}
                        validationSchema={visitsValidationSchema}
                        onSubmit={(values) => { onSubmitHandler(values) }}
                    >
                        {({ errors, touched, values, setFieldValue, setFieldTouched }) => (
                            <Form id='addVisit' className=' AddEditForm'>
                                <>{console.log("values.....", values)}</>
                                {errorMsg ? <span className="d-flex justify-content-center text-danger">{errorMsg}</span> : <span>&nbsp;</span>}
                                <div className='form-group'>
                                    <label className="pb-1">Visit Name :</label>
                                    <Field
                                        name='visitName'
                                        placeholder="Enter visit name"
                                        value={values.visitName}
                                        className="form-control form-control-lg"
                                        onChange={(e: any) => {
                                            if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
                                                setFieldTouched('visitName', true)
                                                setFieldValue('visitName', e.target.value)
                                                setSubmitDisabled(false)
                                            }
                                        }}
                                    />
                                    {errors.visitName && touched.visitName ? <span className='text-danger'> <ErrorMessage name={`visitName`} /> </span> : <span>&nbsp;</span>}
                                </div>
                                <div className='form-group  repeatingRadioBtns'>
                                    <label className="pb-1">Repeating :</label>
                                    <div role="group" className='d-flex ' aria-labelledby="my-radio-group">
                                        <div className="d-flex form-check form-check-inline">
                                            <Field type="radio" className='' id='visitRepeatingTrue'
                                                name="visitRepeat" value="true"
                                                disabled={actionType === 'edit' ? true : false}
                                                onChange={(event: any) => {
                                                    setSubmitDisabled(false)
                                                    setFieldValue('visitRepeat', event.target.value)
                                                }}
                                            /><p className="pt-3 ps-2" >Yes</p>
                                        </div>
                                        <div className="d-flex form-check form-check-inline">
                                            <Field type="radio" className='' id='visitRepeatingFalse'
                                                name="visitRepeat" value="false"
                                                disabled={actionType === 'edit' ? true : false}
                                                onChange={(event: any) => {
                                                    setSubmitDisabled(false)
                                                    setFieldValue('visitRepeat', event.target.value)
                                                }}
                                            />
                                            <p className="pt-3 ps-2" >No</p>
                                        </div>
                                    </div>
                                    {errors.visitRepeat && touched.visitRepeat ? <span className='text-danger'> <ErrorMessage name={`visitRepeat`} /> </span> : <span>&nbsp;</span>}
                                </div>
                                <VisitType
                                    name='visitTypeCode'
                                    id='visitTypeCode'
                                    values={values}
                                    setFieldValue={setFieldValue}
                                    actionType={props.actionType}
                                    enableSubmit={(value: any) => setSubmitDisabled(value)} />
                            </Form>
                        )}
                    </Formik>
                </div>
            </CustomDialog>
        </React.Fragment>
    )
}
export default AddOrEditVisit;