import React from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { useSelector, useDispatch } from "react-redux";
import ReplayIcon from '@mui/icons-material/Replay';
import DeleteIcon from '@mui/icons-material/Delete';
import { fetchAllVisitsByStudyId, findByVisitName, deleteOrRestoreVisit } from '../actions/actions'
import { Confirm, toastAlert } from '../../../../../actions/actions';
import { messages } from '../../../constants/messages';
import AddOrEditVisit from './AddOrEditVisit';
import RearrangeVisits from './RearrangeVisits';
import RearrangeForms from './RearrangeForms';
import SearchField from '../../../../../common/searchField/SearchField';
import { Types } from '../reducer/Types';
import CustomToolTip from '../../../../../components/CustomToolTip';
import PageCount from '../../../../../common/pagecount/PageCount';
import '../styles/visits.scss';
import { FilterSeachContainer } from '../../../../../common/styleComponents/FilterBy';
import { filterSelection } from '../constants/modal';
import { NavLink } from 'react-router-dom';
import VisitDateMapping from './VisitDateMapping';

function VisitDetails() {
    const dispatch = useDispatch()
    const { visitDetails, lazyParams } = useSelector((state: any) => state.visits)
    const { currentStudy } = useSelector((state: any) => state.application)
    const [first, setFirst] = React.useState(0)
    const [searchVisitVal, setSearchVisitVal] = React.useState('')
    const typeSelection = [...filterSelection]
    const [Selection, setSelection] = React.useState(typeSelection[0].id);
    const [pageClick, setpageChange] = React.useState(false);

    const onPageChange = (e: any) => {
        // if ((e.page > 0) || (pageClick && e.page === 0)) {
        console.log("36...", e.first, e.page)
        setFirst(e.first)
        const _payload = { ...{}, ...lazyParams, studyId: currentStudy.id }
        _payload.pageNo = e.page
        dispatch({ type: Types.LAZY_PAGINATION_VISITS, payload: _payload })
        dispatch(fetchAllVisitsByStudyId(_payload))
        setpageChange(true)
        // }
    }



    const rearrangeFormOrderTempalte = (rowData: any) => {
        return (
            <RearrangeForms rowData={rowData}
                onSearchVisitVal={(value: any) => setSearchVisitVal(value)}
                searchVisitVal={searchVisitVal} />
        )
    }

    const selectFormsAndVariablesTemplate = (rowData: any) => {
        return (
            // <SelectFormVariables rowData={rowData}
            //     onSearchVisitVal={(value: any) => setSearchVisitVal(value)}
            //     searchVisitVal={searchVisitVal}
            //     onSelectFormVariables={() => onSelectFormVariables(rowData)} />
            rowData.status ? <NavLink to={`../visits/assignFormsToVisit/${rowData.id}`} >Select Forms & Variables</NavLink> : '-'
        )
    }


    const onDeleteRestoreVisit = (type: string, rowData: any) => {
        const _payload = {
            'visitId': rowData.id,
            "status": type === 'delete' ? false : type === 'restore' ? true : rowData.status
        }
        dispatch(Confirm({
            status: 0, message: type === 'delete' ? messages.visits.delete : messages.visits.restore,
            onOk: () => {
                dispatch(deleteOrRestoreVisit(_payload, (data: any) => {
                    const _payload = { ...lazyParams, studyId: currentStudy.id }
                    console.log("75...", _payload)
                    !searchVisitVal && dispatch(fetchAllVisitsByStudyId(_payload))
                    searchVisitVal && dispatch(findByVisitName(`${Selection}=${searchVisitVal}`))
                    // dispatch(fetchAllVisitsByStudyId(lazyParams))                 
                    if (data.errorMessage) {
                        dispatch(toastAlert({
                            status: 2,
                            open: true,
                            message: data.errorMessage
                        }))
                    } else {
                        dispatch(toastAlert({
                            status: 1,
                            open: true,
                            message: type === 'delete' ? `${rowData.visitName} deleted successfully` : `${rowData.visitName} restored successfully`
                        }))
                        // setSearchVisitVal("")
                    }
                }))
            }
        }))
    }
    const actionTemplate = (rowData: any) => {

        return (<React.Fragment>
            <div className='actions d-flex'>
                {rowData.status === true ? <React.Fragment>
                    <AddOrEditVisit actionType='edit' rowData={rowData} searchVisitVal={searchVisitVal} Selection={Selection} />
                    <span> |</span>
                    <CustomToolTip title='Delete Visit'><DeleteIcon sx={{ fontSize: 14, opacity: .8 }} className="text-danger" onClick={() => onDeleteRestoreVisit('delete', rowData)} /></CustomToolTip>
                    {rowData.visitDateMappingEnabled === true ? <div><span> |</span><VisitDateMapping rowData={rowData} /></div> : <div></div>}
                    {/* {rowData.visitDateMappingEnabled == true? <div><span> |</span><CalendarMonthIcon  className="ms-1"   sx={{ fontSize: 14, opacity: .8 }} onClick={() => onVisitDate(rowData)}/></div> :<div></div> } */}
                </React.Fragment> :
                    <CustomToolTip title='Restore Visit'><ReplayIcon sx={{ fontSize: 22, opacity: .8 }} onClick={() => onDeleteRestoreVisit('restore', rowData)} /></CustomToolTip>}
            </div>
        </React.Fragment>)
    }



    const onSearchVisitName = (event: any) => {
        const _val = event.target.value
        if (_val === '') {
            setSearchVisitVal('')
            dispatch(fetchAllVisitsByStudyId(lazyParams))

        } else {
            setSearchVisitVal(_val)
            console.log('120....', Selection);

            dispatch(findByVisitName(`${Selection}=${event.target.value}`))
        }
    }

    const onClearSearch = () => {
        setSearchVisitVal('')
        dispatch(fetchAllVisitsByStudyId(lazyParams))

    }

    const onChangePageCount = (e: any) => {
        const _payload = { studyId: currentStudy.id, pageNo: 0, pageSize: parseInt(e.target.value) }
        dispatch({ type: Types.LAZY_PAGINATION_VISITS, payload: _payload })
        dispatch(fetchAllVisitsByStudyId(_payload))
    }

    const onFilterByChange = (e: any) => {
        setSelection(e.target.value)
        onClearSearch();
        console.log('120...', searchVisitVal, e.target.value)
    }
    return (
        <React.Fragment>
            <div className="d-flex justify-content-between pb-2 controls-container">
                <div className="d-flex sites">
                    <div className="left-container">
                        <PageCount value={lazyParams.pageSize} onChange={(e: any) => onChangePageCount(e)} />
                    </div>
                </div>
                <div className="right-panel d-flex">
                    <AddOrEditVisit actionType='add' />
                    <RearrangeVisits />
                    <FilterSeachContainer>
                        <select className='dropdown'
                            onChange={onFilterByChange}
                            value={Selection}>
                            {/* <option value=''>Filter By</option> */}
                            {
                                typeSelection && typeSelection.map((i: any, index: any) => (

                                    <option key={index} value={i.id}>{i.formName}</option>
                                ))

                            }
                        </select>
                        {
                            (Selection === 'visitName' || Selection === "") &&
                            <SearchField
                                placeholder="Search By Visit Name"
                                value={searchVisitVal}
                                onChange={onSearchVisitName}
                                onClearSearch={onClearSearch}
                            />
                        }
                        {
                            (Selection === 'visitForms') &&
                            <SearchField
                                placeholder="Search By  Form Name"
                                value={searchVisitVal}
                                onChange={onSearchVisitName}
                                onClearSearch={onClearSearch}
                            />
                        }

                    </FilterSeachContainer>
                </div>
            </div>
            <DataTable
                scrollable
                value={visitDetails && visitDetails.visits}
                selectionMode="single"
                emptyMessage="No Visits Are Available To Display."
                lazy
                rows={lazyParams.pageSize}
                totalRecords={visitDetails && visitDetails.totalRecords}
                paginator={visitDetails && visitDetails.totalRecords > lazyParams.pageSize ? true : false}
                responsiveLayout="scroll"
                stripedRows={true}
                first={first}
                onPage={onPageChange}>
                <Column field="visitName" header="Visit Name" style={{ width: 'auto', fontWeight: 500 }} ></Column>
                <Column header='Rearrange Form Order' body={rearrangeFormOrderTempalte} style={{ width: 'auto' }}></Column>
                <Column header='Select Forms & Variables' body={selectFormsAndVariablesTemplate} style={{ width: 'auto' }}></Column>
                <Column body={actionTemplate} header='Actions'></Column>
            </DataTable>
        </React.Fragment>
    )
}
export default VisitDetails;