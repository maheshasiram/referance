import React from "react";
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import CustomDialog from "../../../../../common/modals/CustomeDialog";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";

function PreviewRows() {
    const [open, setOpen] = React.useState(false)

    const onCloseHandler = () => {
        setOpen(false)
    }
    const onSubmitHandler = () => {
        return null

    }

    const onPreViewRowClick = () => {
        setOpen(true)
    }
    return (
        <React.Fragment>
            <VisibilityOffIcon onClick={onPreViewRowClick} sx={{ fontSize: "15px" }} />
            <CustomDialog
                title={'Hide Group Rows'}
                onClose={onCloseHandler}
                onSubmitHandler={onSubmitHandler}
                open={open}
                maxWidth="sm"
                actionType={'Submit'}>
                <DataTable>
                    <Column>Row Count</Column>
                    <Column>Hide</Column>

                </DataTable>
            </CustomDialog>
        </React.Fragment>

    )

}
export default PreviewRows