import React from "react";
import CustomDialog from "../../../../../common/modals/CustomeDialog";
import { useSelector, useDispatch } from "react-redux";
import { fetchRearrangeVisits ,updateRearrangeVisits} from '../actions/actions';
import { List, arrayMove } from "react-movable";
import ListItem from '@mui/material/ListItem';
import { Box } from '@mui/material';
import ContactPageIcon from '@mui/icons-material/ContactPage';
import {toastAlert } from "../../../../../actions/actions";
// import { normalize } from "path/win32";

function RearrangeVisits() {

    const dispatch = useDispatch()
    const { currentStudy } = useSelector((state: any) => state.application)
    const [items, setItems] = React.useState([]);
    const [open, setOpen] = React.useState(false);
    const [submitDisable, setSubmitDisable] = React.useState(true);

    const onOpenClickHandler = () => {
        setOpen(true);
        dispatch(fetchRearrangeVisits(currentStudy.id, (data: any) => {
            setItems(data)
        }))
    }

    const onCloseHandler = () => {
        setOpen(false);
    }

    const onSubmitHandler = () => {
        setSubmitDisable(true);
        const _data = [...[], ...items]
        const _arr: any = []
        _data.map((item: any, index: any) => {
            const _obj = {
                'id': item.id,
                "visitName": item.visitName,
                "visitTypeCode": "",
                "ordinal": index + 1,
                "visitLockStatus": item.visitLockStatus,
                "visitRepeat": item.visitRepeat,
                "status": item.status,
                "studyId": currentStudy.id
            }
            _arr.push(_obj)
            return null;
        })
        dispatch(updateRearrangeVisits(_arr, (data: any) => {
            setOpen(false)
            if(!data.errorMessage){
                dispatch(toastAlert({
                    status:1,
                    open:true,
                    message:'Visits order updated successfully',
                }))
            }
        }))
    }
    const onChangeHandler = (items: any, oldIndex: any, newIndex: any) => {
        setItems(arrayMove(items, oldIndex, newIndex));
        setSubmitDisable(false)
    }
    return (
        <React.Fragment>
            <button type="button" className="btn-eoutlined-secondary" onClick={onOpenClickHandler}>Rearrange Visits</button>
            <CustomDialog
                id='RearrangeVisitsDialogue'
                title={"Rearrange Visits"}
                onClose={onCloseHandler}
                onSubmitHandler={onSubmitHandler}
                open={open}
                disabled={submitDisable}
                actionType={'Submit'}
                maxWidth='xs'
            >
                <div className="dialog-body-rearrangeVisits">
                    {
                        (items && items.length > 0 ?
                            <Box sx={{}}>
                                <p className="rearrange-note"> <strong> Note: </strong> Rearranged visits order will appear in the subjects in the subject list page </p>
                                <List
                                    values={items}
                                    onChange={({ oldIndex, newIndex }) => {
                                        onChangeHandler(items, oldIndex, newIndex);
                                    }}
                                    renderList={({ children, props, isDragged }) => <ul className={isDragged ? "grabbing list-items-container" : " list-items-container "} id={`VisitElement`} {...props}>{children}</ul>}
                                    renderItem={({ value, props, isDragged }: any) =>
                                        <ListItem className={isDragged ? "grabbing list-item" : "grab list-item"} id={`VisitItem${value.ordinal}`}
                                            style={{ zIndex: 4 }} {...props}>
                                            <div style={{ zIndex: 9 }} className="draggable-item"></div>
                                            <ContactPageIcon /><p>{value.visitName}</p>
                                        </ListItem>
                                    }
                                />
                            </Box> : <p className="no-item-available">No forms found</p>)
                    }
                </div>
            </CustomDialog>
        </React.Fragment>
    )
}
export default RearrangeVisits;