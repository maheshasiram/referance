import React, { useEffect, useRef, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import KeyboardDoubleArrowLeftIcon from '@mui/icons-material/KeyboardDoubleArrowLeft';
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import _ from 'lodash';
import { Types } from '../reducer/Types';
import SearchField from "../../../../../common/searchField/SearchField";
import { updateSelectFormsAndVariables, fetchAllVisitsByStudyId, findByVisitName, getAssignedFormFields, findAllVisitsByStudyId } from '../actions/actions';
// import { Alert } from "../../../../../actions/actions";
import { toastAlert } from "../../../../../actions/actions";
import { useNavigate, useParams } from "react-router-dom";
import TabList from "@mui/lab/TabList";
import { Tab, Typography } from "@mui/material";
import TabContext from "@mui/lab/TabContext";
import TabPanel from "@mui/lab/TabPanel";
import { Box } from "@mui/system";


function SelectFormVariables(props: any) {
    const dispatch = useDispatch()
    // const [expanded, setExpanded] = React.useState(false);
    const [searchVal, setSearchVal] = React.useState('')
    const [submitDisable, setSubmitDisable] = React.useState(true)
    const [open, setOpen] = React.useState(false)
    const { rowData } = props
    const [emptyVariableForm, setEmptyVariableForm] = React.useState([])
    const [errorMsg, setErrorMsg] = React.useState('')
    const [expanded, setExpanded] = React.useState<string | false>(false);
    // const [btnDisbaled,setBtnDisable] = React.useState(false)

    const loaded = useRef(false)
    // let dispatch = useDispatch()
    const params: any = useParams()
    const navigate = useNavigate()
    const { currentStudy } = useSelector((state: any) => state.application)
    const { selectFormsAndVriable, allSelectFormVariables, previousSelectedForms } = useSelector((state: any) => state.visits)
    const [tabConextValue, setTabConextValue] = React.useState('0');
    const [visitsList, setVisitsList] = useState([])
    const [currentVisit, setCurrentVisit] = useState<any>(null)
    useEffect(() => {
        if (!loaded.current) {
            const _payload = { studyId: currentStudy.id, visitId: params.id }
            dispatch(getAssignedFormFields(_payload, (response: any) => {
                if (response?.length > 0) {
                    setTabConextValue(`${response[0].id}`)
                }
            }))
            dispatch(findAllVisitsByStudyId(currentStudy.id, (_response: any) => {
                setVisitsList(_response)
                if (params.id && params.id > 0 && _response?.length > 0) {
                    setCurrentVisit(_response.find((i: any) => i.id === parseInt(params.id)))
                }
            }))
            loaded.current = true
        }
    }, [params.id, currentStudy.id, dispatch, params])
    const handleChangeForm = (event: React.SyntheticEvent, newValue: number) => {
        setTabConextValue(newValue.toString());
    };
    const onKeyupSearch = (e: any) => {
        if (e.key === 'Backspace' && e.target.value === '') {
            setTabConextValue(`${selectFormsAndVriable[0].id}`)
        } else {
            setTabConextValue(`${allSelectFormVariables[0].id}`)
        }
    }

    // const onSelectFormsVariablesClick = (rowData: any) => {
    //     // rowData.status ? setOpen(true) : setOpen(false)
    //     if (rowData.status) {

    //         setOpen(true)
    //         props.onSelectFormVariables();
    //         dispatch({ type: Types.GET_SELECT_FORMS, payload: [] })
    //         setEmptyVariableForm([])
    //     }
    // }
    const onCloseHandler = () => {
        setOpen(false)
        const _subData = [...[], ...allSelectFormVariables]
        dispatch({ type: Types.ON_SELECT_FORM_SEARCH, payload: _subData })
        setSearchVal('')
        setEmptyVariableForm([])
    }
    const handleChange = (panel: any) => (event: any, isExpanded: any) => {

        setExpanded(isExpanded ? panel : false);
    };


    const onSelectFormHandler = (e: any, element: any) => {
        setSubmitDisable(false)
        const _formChecked = _.cloneDeep(selectFormsAndVriable)
        const index = selectFormsAndVriable.findIndex((item: any) => element.id === item.id)
        _formChecked[index].selected = e.target.checked
        setExpanded(false)
        if (!e.target.checked) {
            _formChecked[index].doubleDataEntry = e.target.checked
            _formChecked[index].repeatStatus = e.target.checked
            _formChecked[index].repeatMax = null
        }
        if (_formChecked[index].formFields) {
            _formChecked[index].formFields.map((item: any, itemIndex: any) => {
                if (_formChecked[index].formFields[itemIndex].field) {
                    _formChecked[index].formFields[itemIndex].field.selected = e.target.checked
                } else if (_formChecked[index].formFields[itemIndex].group) {
                    _formChecked[index].formFields[itemIndex].group.fields.map((grpEle: any, grpEleIndex: number) => {
                        _formChecked[index].formFields[itemIndex].group.fields[grpEleIndex].selected = e.target.checked
                        return null
                    })
                }
                return null;
            })
        }
        // let selectedForm = _formChecked.filter((checkedData: any) => {
        //     if (checkedData.selected == true) {
        //         allSelectFormVariables.map((allData: any) => {
        //             if (checkedData.id === allData.id) {
        //                 allData.selected = true
        //                 // return allSelectFormVariables
        //             }
        //         })
        //         return allSelectFormVariables;
        //     }

        // })
        onFormModified(_formChecked)
        dispatch({ type: Types.ON_SELECT_FORMS, payload: _formChecked, });
        // dispatch({ type: Types.GET_SELECT_FORMS, payload: allSelectFormVariables, });
        onSearchFormName(searchVal, _formChecked)
        // const selectFormAllData = allSelectFormVariables.filter((i:any)=>i)

    }

    const onSelectItemsHandler = (e: any, _formIndex: any, _itemIndex: any, element: any, item: any) => {
        setSubmitDisable(false)
        const _VariableChecked = _.cloneDeep(selectFormsAndVriable)
        const formIndex = selectFormsAndVriable.findIndex((_item: any) => element.id === _item.id)

        const itemIndex = selectFormsAndVriable[formIndex].formFields.findIndex((_i: any) => item.field.id === (_i.field && _i.field.id))

        _VariableChecked[formIndex].formFields[itemIndex].field.selected = e.target.checked
        const _checkedItems: any = []
        _VariableChecked[formIndex].formFields.map((el: any) => {
            if (el.field && el.field.selected) {
                _checkedItems.push(el)
            } else if (el.group && el.group.fields) {
                el.group.fields.map((grpEle: any) => {
                    if (grpEle && grpEle.selected) {
                        _checkedItems.push(grpEle)
                    }
                    return null
                })
            }
            return null
        })
        if (_checkedItems.length <= 0) {
            _VariableChecked[formIndex].selected = false
        } else if (_checkedItems.length >= 1) {
            _VariableChecked[formIndex].selected = true
        }
        dispatch({
            type: Types.ON_SELECT_FORMS,
            payload: _VariableChecked
        });
        onSearchFormName(searchVal, _VariableChecked)
    }
    const onSearchFormName = (e: any, formsList: any) => {
        // let _subData = [...[], ...selectFormsAndVriable]
        const _subData = _.cloneDeep(formsList)
        const selectedValue = e
        setSearchVal(selectedValue)
        const result = _subData.filter((sub: any) => {
            if (
                sub.formName.toLowerCase().includes(selectedValue.toLowerCase())
            ) { return sub; }
            return null
        })

        if (e !== "") {
            // setTabConextValue(result.length > 0 ? `${result[0].id}` : '0')
            dispatch({ type: Types.ON_SELECT_FORM_SEARCH, payload: result })
        }
        else {
            // setTabConextValue(_subData.length > 0 ? `${_subData[0].id}` : '0')
            dispatch({ type: Types.ON_SELECT_FORM_SEARCH, payload: _subData })
        }
    }

    const onDDEchangeHandler = (e: any, _index: any, element: any) => {
        setSubmitDisable(false)
        const index = selectFormsAndVriable.findIndex((item: any) => element.id === item.id)
        const _dddChecked = _.cloneDeep(selectFormsAndVriable)
        // alert("dde")
        _dddChecked[index].doubleDataEntry = e.target.checked;
        dispatch({
            type: Types.ON_SELECT_FORMS,
            payload: _dddChecked
        });
        onSearchFormName(searchVal, _dddChecked)
    }
    const onRepeatFormHandler = (e: any, _index: any, element: any) => {
        setSubmitDisable(false)
        const index = selectFormsAndVriable.findIndex((item: any) => element.id === item.id)
        const _repeatStatus = _.cloneDeep(selectFormsAndVriable)
        _repeatStatus[index].repeatMax = null
        _repeatStatus[index].repeatStatus = e.target.checked;
        dispatch({ type: Types.ON_SELECT_FORMS, payload: _repeatStatus });
        onSearchFormName(searchVal, _repeatStatus)
    }
    const onRepeatingCount = (e: any, _index: any, element: any) => {
        setSubmitDisable(false)
        const index = selectFormsAndVriable.findIndex((item: any) => element.id === item.id)
        const _repeatMax = _.cloneDeep(selectFormsAndVriable)
        _repeatMax[index].repeatMax = e.target.value;
        dispatch({
            type: Types.ON_SELECT_FORMS,
            payload: _repeatMax
        });
        onSearchFormName(searchVal, _repeatMax)
    }
    const onClearSearch = () => {
        // let _subData = [...[], ...allSelectFormVariables]

        // setSearchVal('')
        // dispatch({ type: Types.ON_SELECT_FORM_SEARCH, payload: _subData })
        // dispatch({type: Types.ON_SELECT_FORMS, payload: _subData});
        setTabConextValue(`${selectFormsAndVriable[0].id}`)
        onSearchFormName('', selectFormsAndVriable)

    }
    const onSelectGroupItemHandler = (e: any, _index: any, _itemIndex: any, _groupElIndex: any, element: any, groupEl: any, item: any) => {
        setSubmitDisable(false)
        const index = selectFormsAndVriable.findIndex((_item: any) => element.id === _item.id)
        const itemIndex = selectFormsAndVriable[index].formFields.findIndex((i: any) => item.group.id === i.group?.id)
        const groupElIndex = selectFormsAndVriable[index].formFields[itemIndex].group.fields.findIndex((_i: any) => groupEl.id === _i.id)
        const _VariableChecked = _.cloneDeep(selectFormsAndVriable)
        _VariableChecked[index].formFields[itemIndex].group.fields[groupElIndex].selected = e.target.checked
        const _checkedItems: any = []
        // alert('eeee')
        _VariableChecked[index].formFields.map((el: any) => {
            if (el.field && el.field.selected) {
                _checkedItems.push(el)
            } else if (el.group && el.group.fields) {
                el.group.fields.map((grpEle: any) => {
                    if (grpEle && grpEle.selected) {
                        _checkedItems.push(grpEle)
                    }
                    return null
                })
            }
            return null
        })
        if (_checkedItems.length <= 0) {
            _VariableChecked[index].selected = false
        } else if (_checkedItems.length >= 1) {
            _VariableChecked[index].selected = true
        }
        dispatch({
            type: Types.ON_SELECT_FORMS,
            payload: _VariableChecked
        });
        onSearchFormName(searchVal, _VariableChecked)


    }
    const isValidate = () => {
        let repeatMaxValidate = false
        const _validatePayload: any = []
        selectFormsAndVriable.map((item: any) => {
            if (item.selected) {
                if (item.repeatStatus) {
                    if (!item.repeatMax || item.repeatMax === '' || item.repeatMax <= 0) {
                        repeatMaxValidate = true
                        _validatePayload.push(item.formName)
                    }
                }
            }
            return null
        })
        setEmptyVariableForm(_validatePayload)
        return repeatMaxValidate ? false : true
    }


    const onSubmitHandler = () => {
        const validate = isValidate()
        const _submitPayload = _.cloneDeep(selectFormsAndVriable)
        // const _submitPayload = _.cloneDeep(allSelectFormVariables)
        const payload: any = []

        //  logic for API 
        if (validate) {
            _submitPayload && _submitPayload.map((form: any) => {
                const _formData: any = {
                    "visitForms": [
                        {
                            "formId": form.id,
                            "visitId": params.id,
                            "doubleDataEntry": form.doubleDataEntry,
                            "repeatStatus": form.repeatStatus,
                            "repeatMax": form.repeatMax,
                            "formSelected": form.selected,
                            "ordinal": form.ordinal
                        }
                    ],
                    "fields": [],
                    "groups": []
                }
                const _index = previousSelectedForms.findIndex((i: any) => i.id === form.id)

                if (_index === -1) {
                    if (form.selected) {
                        form && form.formFields && form.formFields.map((field: any) => {
                            if (field.field && field.field.selected === true) {
                                _formData.fields.push({
                                    "fieldId": field.field.id,
                                    "selectedStatus": field.field.selected
                                })
                            } else if (field.group) {
                                if (field.group.fields) {
                                    const grpPaylaod: any = { "groupId": field.group.id, "fields": [] }
                                    field.group.fields.map((grpField: any) => {
                                        if (grpField.selected && grpField.selected) {
                                            grpPaylaod.fields.push({
                                                "fieldId": grpField.id,
                                                "selectedStatus": grpField.selected
                                            })
                                        }
                                        return null
                                    })
                                    if (grpPaylaod.fields && grpPaylaod.fields.length > 0) {
                                        _formData.groups.push(grpPaylaod)
                                    }
                                }
                            }
                            return null
                        })
                        payload.push({
                            ..._formData,
                            fields: _formData.fields.length > 0 ? _formData.fields : null,
                            groups: _formData.groups.length > 0 ? _formData.groups : null
                        })

                    }
                } else {

                    if (!form.selected) {

                        form && form.formFields && form.formFields.map((field: any, fieldIndex: number) => {
                            if (field.field) {
                                const _itemIndex = previousSelectedForms[_index].formFields.findIndex((i: any) => i.field && i.field.id === field.field.id)
                                const _itemObject = previousSelectedForms[_index].formFields[_itemIndex]
                                if (_itemObject.field.selected) {
                                    if (!(field.field.selected)) {
                                        _formData.fields.push({
                                            "fieldId": field.field.id,
                                            "selectedStatus": field.field.selected
                                        })
                                    }
                                }
                            } else {
                                if (field.group) {
                                    const grpPaylaod: any = { "groupId": field.group.id, "fields": [] }
                                    field.group && field.group.fields && field.group.fields.map((grpItem: any) => {
                                        const _itemIndex = previousSelectedForms[_index].formFields[fieldIndex].group.fields.findIndex((i: any) => i.id === grpItem.id)
                                        const _itemObject = previousSelectedForms[_index].formFields[fieldIndex].group.fields[_itemIndex]
                                        if (_itemObject.selected) {
                                            if (!grpItem.selected) {
                                                grpPaylaod.fields.push({
                                                    "fieldId": grpItem.id,
                                                    "selectedStatus": grpItem.selected
                                                })
                                            }
                                        }
                                        return null
                                    })
                                    if (grpPaylaod.fields && grpPaylaod.fields.length > 0) {
                                        _formData.groups.push(grpPaylaod)
                                    }
                                }
                            }
                            return null
                        })
                        payload.push({
                            ..._formData,
                            fields: _formData.fields.length > 0 ? _formData.fields : null,
                            groups: _formData.groups.length > 0 ? _formData.groups : null
                        })
                    } else {
                        // if (previousSelectedForms[_index].doubleDataEntry !== form.doubleDataEntry) {
                        // }
                        form && form.formFields && form.formFields.map((field: any, fieldIndex: number) => {
                            if (field.field) {
                                const _itemIndex = previousSelectedForms[_index].formFields.findIndex((i: any) => i.field && i.field.id === field.field.id)
                                const _itemObject = previousSelectedForms[_index].formFields[_itemIndex]
                                if (_itemObject.field.selected) {
                                    if (!field.field.selected) {
                                        _formData.fields.push({
                                            "fieldId": field.field.id,
                                            "selectedStatus": field.field.selected
                                        })
                                    }
                                } else {
                                    if (field.field.selected) {
                                        _formData.fields.push({
                                            "fieldId": field.field.id,
                                            "selectedStatus": field.field.selected
                                        })
                                    }
                                }
                            } else {
                                if (field.group) {
                                    const grpPaylaod: any = { "groupId": field.group.id, "fields": [] }
                                    field.group && field.group.fields && field.group.fields.map((grpItem: any) => {
                                        const _itemIndex = previousSelectedForms[_index].formFields[fieldIndex].group.fields.findIndex((i: any) => i.id === grpItem.id)
                                        const _itemObject = previousSelectedForms[_index].formFields[fieldIndex].group.fields[_itemIndex]
                                        if (_itemObject.selected) {
                                            if (!grpItem.selected) {
                                                grpPaylaod.fields.push({
                                                    "fieldId": grpItem.id,
                                                    "selectedStatus": grpItem.selected
                                                })
                                            }
                                        } else {
                                            if (grpItem.selected) {
                                                grpPaylaod.fields.push({
                                                    "fieldId": grpItem.id,
                                                    "selectedStatus": grpItem.selected
                                                })
                                            }
                                        }
                                        return null
                                    })
                                    if (grpPaylaod.fields.length > 0) {
                                        _formData.groups.push(grpPaylaod)
                                    }
                                }
                            }
                            return null
                        })
                        if (_formData.groups.length > 0 || _formData.fields.length > 0 ||
                            previousSelectedForms[_index].doubleDataEntry !== form.doubleDataEntry ||
                            previousSelectedForms[_index].repeatStatus !== form.repeatStatus ||
                            previousSelectedForms[_index].formSelected !== form.formSelected ||
                            previousSelectedForms[_index].repeatMax !== form.repeatMax
                        ) {
                            payload.push({
                                ..._formData,
                                fields: _formData.fields.length > 0 ? _formData.fields : null,
                                groups: _formData.groups.length > 0 ? _formData.groups : null
                            })
                        }
                    }
                }
                return null
            })
            // if (payload.length > 0) {
            dispatch(updateSelectFormsAndVariables(payload, params.id, (data: any) => {

                const _payload = { studyId: currentStudy.id, pageNo: 0, pageSize: 10 }
                props.searchVisitVal ? dispatch(findByVisitName(props.searchVisitVal)) : dispatch(fetchAllVisitsByStudyId(_payload))
                if (data.errorMessage) {
                    setErrorMsg(data.errorMessage)
                } else {
                    onCloseHandler()
                    dispatch(toastAlert({
                        status: 1,
                        open: true,
                        message: `Selected forms and variables are assigned Successfully`
                    }))
                }
            }))
            // }
            backToForm()
        }
    }
    const onCancelHandler = () => {
        backToForm()
    }

    const onFormModified = (formChecked: any) => {
        const arr = []
        formChecked.map((item: any) => {
            if (item.selected) {
                arr.push(item)
            }
            return null
        })
        if (arr.length > 0) {
            setSubmitDisable(false)
        }
        else {
            // setSubmitDisable(true)
        }
    }
    const backToForm = () => {
        navigate('/study/visits')
        // dispatch({ type: Types.FORM_DE, payload: {} });
    }
    const onSelectAllNonGrpVariables = (e: any, element: any, index: number) => {
        setSubmitDisable(false)
        const _VariableChecked = _.cloneDeep(selectFormsAndVriable)
        const formIndex = selectFormsAndVriable.findIndex((_item: any) => element.id === _item.id)
        console.log('event.......', e.target.checked, _VariableChecked, selectFormsAndVriable[formIndex])
        selectFormsAndVriable[formIndex]?.formFields?.map((_ele: any, _eleIndex: number) => {
            if (_ele.field) {
                _VariableChecked[formIndex].formFields[_eleIndex].field.selected = e.target.checked
            }
        })
        // const itemIndex = selectFormsAndVriable[formIndex].formFields.findIndex((_i: any) => item.field.id === (_i.field && _i.field.id))

        // _VariableChecked[formIndex].formFields[itemIndex].field.selected = e.target.checked
        const _checkedItems: any = []
        _VariableChecked[formIndex].formFields.map((el: any) => {
            if (el.field && el.field.selected) {
                _checkedItems.push(el)
            } else if (el.group && el.group.fields) {
                el.group.fields.map((grpEle: any) => {
                    if (grpEle && grpEle.selected) {
                        _checkedItems.push(grpEle)
                    }
                    return null
                })
            }
            return null
        })
        if (_checkedItems.length <= 0) {
            _VariableChecked[formIndex].selected = false
        } else if (_checkedItems.length >= 1) {
            _VariableChecked[formIndex].selected = true
        }
        dispatch({
            type: Types.ON_SELECT_FORMS,
            payload: _VariableChecked
        });
        onSearchFormName(searchVal, _VariableChecked)
    }
    const getNonGrpAllSelected = (element: any) => {
        let _flag = true;
        const formIndex = selectFormsAndVriable.findIndex((_item: any) => element.id === _item.id)
        selectFormsAndVriable[formIndex]?.formFields?.map((_ele: any, _eleIndex: number) => {
            if (_ele.field && !_ele.field.selected) {
                _flag = false
            }
        })
        return _flag
    }

    const onSelectAllGrpVariables = (e: any, _index: any, _itemIndex: any, element: any, item: any) => {
        setSubmitDisable(false)
        const index = selectFormsAndVriable.findIndex((_item: any) => element.id === _item.id)
        const itemIndex = selectFormsAndVriable[index].formFields.findIndex((i: any) => item.group.id === i.group?.id)
        const _VariableChecked = _.cloneDeep(selectFormsAndVriable)
        selectFormsAndVriable[index].formFields[itemIndex].group.fields.map((grp: any, grpIndex: number) => {
            _VariableChecked[index].formFields[itemIndex].group.fields[grpIndex].selected = e.target.checked
        })
        const _checkedItems: any = []
        _VariableChecked[index].formFields.map((el: any) => {
            if (el.field && el.field.selected) {
                _checkedItems.push(el)
            } else if (el.group && el.group.fields) {
                el.group.fields.map((grpEle: any) => {
                    if (grpEle && grpEle.selected) {
                        _checkedItems.push(grpEle)
                    }
                    return null
                })
            }
            return null
        })
        if (_checkedItems.length <= 0) {
            _VariableChecked[index].selected = false
        } else if (_checkedItems.length >= 1) {
            _VariableChecked[index].selected = true
        }
        dispatch({
            type: Types.ON_SELECT_FORMS,
            payload: _VariableChecked
        });
        onSearchFormName(searchVal, _VariableChecked)
    }
    const getGrpAllSelected = (group: any) => {
        let _flag = true;
        group?.fields?.map((grpEle: any) => {
            if (!grpEle.selected) {
                _flag = false
            }
        })
        return _flag
    }
    return (
        <React.Fragment >

            <div className="backto-visits">
                <span onClick={backToForm}><KeyboardDoubleArrowLeftIcon /> Back To Visits</span>
            </div>
            <div className="assignForms-container" >
                <div className="header " >
                    <div className="header-buttons mx-3">
                        <h6>Forms</h6>
                    </div>
                    <div className="right-panel d-flex">
                        <SearchField
                            value={searchVal}
                            onClearSearch={onClearSearch}
                            placeholder='Search by form name'
                            onChange={(e: any) => onSearchFormName(e.target.value, selectFormsAndVriable)}
                            onKeyUp={onKeyupSearch}
                        />
                    </div>
                    <div className="d-flex align-items-center me-2">
                        Select Visits :
                        <select value={params.id} onChange={(e: any) => { loaded.current = false; setSearchVal(''); navigate(`../visits/assignFormsToVisit/${e.target.value}`); }} >
                            {visitsList.map((item: any) => (
                                <option value={item.id} key={item.id}>{item.visitName}</option>
                            ))}
                        </select>
                    </div>
                </div>
                {allSelectFormVariables?.length > 0 ?
                    <div className="assignForms-content">
                        <TabContext value={tabConextValue}>
                            {/* <div className="forms-details "> */}
                            <Box sx={{ width: 300, height: 350, overflowY: 'auto' }} className="">
                                <TabList
                                    variant="scrollable"
                                    onChange={handleChangeForm}
                                    orientation='vertical'
                                    aria-label="lab API tabs example">
                                    {allSelectFormVariables.map((element: any, index: any) => {
                                        return (<Tab
                                            key={`${element.id}`}
                                            value={`${element.id}`}
                                            label={<div className="d-flex align-items-center">
                                                <input type='checkbox'
                                                    id={`FormCHKBX${index}`}
                                                    className=''
                                                    onChange={(e) => onSelectFormHandler(e, element)}
                                                    value={element.id}
                                                    checked={element.selected}
                                                />
                                                <p className="ms-2 m-0" >{element.formName}</p>
                                            </div>
                                            }
                                        />
                                        )
                                    })}
                                </TabList>
                            </Box>
                            {
                                allSelectFormVariables.map((element: any, index: any) => {
                                    return (
                                        <TabPanel style={{ width: '100%', height: 350 }} value={`${element.id}`} key={`${element.id}`}>
                                            <div className="content-header" >
                                                <p className="d-flex me-2"> Visit Name :<span className="ms-2">{currentVisit?.visitName as string}</span></p>
                                                <p className="d-flex me-2">  Form Name :<span className="ms-2">{element.formName}</span></p>
                                            </div>
                                            <div className="d-flex align-items-center py-3 px-4" >
                                                <div className='d-flex align-items-center me-4'>
                                                    <input type='checkbox' id={`DDECHKBX${index}`}
                                                        disabled={element.selected ? false : true}
                                                        onChange={(e) => onDDEchangeHandler(e, index, element)}
                                                        value={element.crfId} checked={element.doubleDataEntry && element.doubleDataEntry} ></input>
                                                    <p className="ms-2 m-0">Double Data Entry </p>
                                                </div>
                                                <div className='d-flex align-items-center'>
                                                    <input type='checkbox'
                                                        id={`repeatingCHKBX${index}`}
                                                        disabled={element.selected ? false : true}
                                                        onChange={(e) => onRepeatFormHandler(e, index, element)}
                                                        value={element.crfId} checked={element.repeatStatus} ></input>
                                                    <p className="mx-2 m-0">Repeating</p>
                                                    {element.repeatStatus && <div className='d-flex align-items-center'>
                                                        <label className=' mx-2'>Repeat Max :</label>
                                                        <div className="d-block">
                                                            <input
                                                                type="number"
                                                                min='1'
                                                                id={`repeatMaxInp${index}`}
                                                                name="quantity"
                                                                value={element.repeatMax}
                                                                onKeyDown={(e: any) => {
                                                                    if (e.key === "-" || e.key === "+" || e.key === "e" || e.key === ".") {
                                                                        e.preventDefault();
                                                                    }
                                                                }}
                                                                onChange={(e) => onRepeatingCount(e, index, element)}
                                                                className='form-control w-auto' />
                                                            {!element.repeatMax || element.repeatMax === 0 ? <span className="text-danger">Please enter repeat max value </span> : null}
                                                        </div>
                                                    </div>
                                                    }
                                                </div>
                                            </div>
                                            <Accordion expanded={expanded === 'panelNon-Grp'} onChange={handleChange('panelNon-Grp')}>
                                                <AccordionSummary
                                                    expandIcon={<ExpandMoreIcon />}
                                                    aria-controls="panel1bh-content"
                                                    id="panel1bh-header"
                                                >
                                                    {/* <Typography sx={{ width: '70%'}}> */}
                                                    <div className="d-flex justify-content-between w-100" >
                                                        <div>
                                                            Non Group Variables
                                                        </div>
                                                        <div className="d-flex align-items-center me-2" onClick={(e: any) => { e.stopPropagation() }}>
                                                            <input type="checkbox" id={'nonGrp-selectAll'}
                                                                checked={getNonGrpAllSelected(element)}
                                                                onClick={(e) => onSelectAllNonGrpVariables(e, element, index)}
                                                            />
                                                            <label htmlFor={'nonGrp-selectAll'} >Select All</label>
                                                        </div>
                                                    </div>
                                                    {/* </Typography> */}
                                                </AccordionSummary>
                                                <AccordionDetails>
                                                    {
                                                        element.formFields?.map((item: any, itemIndex: number) => {
                                                            if (item && item.field) {

                                                                return (
                                                                    <div className=" input-fields d-flex align-items-center mt-1" key={item.field.id}>
                                                                        <input type={'checkbox'}
                                                                            id={'input_' + item.field.id}
                                                                            value={item.field.id}
                                                                            checked={item.field.selected}
                                                                            onChange={(e) => onSelectItemsHandler(e, index, itemIndex, element, item)}
                                                                        ></input> <label htmlFor={'input_' + item.field.id} className="ps-1"> {`${item.field.variableText}`}</label><span className="variable-font">{`( ${item.field.variableId} )`}</span>
                                                                    </div>
                                                                )
                                                            }
                                                            return null
                                                        })
                                                    }
                                                    {
                                                        !(element.formFields.find((i: any) => i.field)) && <p className="defalt-text">No Variables Avaliable To Display</p>
                                                    }
                                                </AccordionDetails>
                                            </Accordion>
                                            <div className="d-flex justify-content-between w-100" >
                                                <h4 >Group Variables</h4>
                                            </div>
                                            {
                                                element.formFields?.map((item: any, itemIndex: number) => {
                                                    if (item && item.group) {
                                                        return (
                                                            <Accordion expanded={expanded === 'panel' + itemIndex} onChange={handleChange('panel' + itemIndex)} key={itemIndex}>
                                                                <AccordionSummary
                                                                    expandIcon={<ExpandMoreIcon />}
                                                                    aria-controls={`panel2bh-header${itemIndex}`}
                                                                    id={`panel2bh-header${itemIndex}`}
                                                                >
                                                                    {/* <Typography sx={{ width: '33%', flexShrink: 0 }}>{item.group.name}</Typography> */}
                                                                    <div className="d-flex justify-content-between w-100" >
                                                                        <div>
                                                                            {item.group.name}
                                                                        </div>
                                                                        <div className="d-flex align-items-center me-2" onClick={(e: any) => { e.stopPropagation() }}>
                                                                            <input type="checkbox" id={'Grp-selectAll'+itemIndex}
                                                                                checked={getGrpAllSelected(item.group)}
                                                                                onClick={(e) => onSelectAllGrpVariables(e, index, itemIndex, element, item)}
                                                                            />
                                                                            <label htmlFor={"Grp-selectAll"+itemIndex} >Select All</label>
                                                                        </div>
                                                                    </div>
                                                                </AccordionSummary>
                                                                <AccordionDetails>
                                                                    {
                                                                        item.group.fields?.map((groupEl: any, groupElIndex: any) => {
                                                                            return (
                                                                                <div className=" input-fields d-flex align-items-center mt-1" key={groupEl.id}>
                                                                                    <input value={groupEl.id}
                                                                                        id={'input_' + groupEl.id}
                                                                                        checked={groupEl.selected}
                                                                                        type={'checkbox'}
                                                                                        onChange={(e) => onSelectGroupItemHandler(e, index, itemIndex, groupElIndex, element, groupEl, item)}
                                                                                    >
                                                                                    </input><label className="ps-1"> {groupEl.variableText}</label><span className="variable-font">{`( ${groupEl.variableId} )`}</span>
                                                                                </div>
                                                                            )
                                                                        })
                                                                    }
                                                                </AccordionDetails>
                                                            </Accordion>
                                                        )
                                                    }
                                                    return null
                                                })}
                                            {
                                                !(element.formFields.find((i: any) => i.group)) && <p className="defalt-text">No Group Variables Avaliable To Display </p>
                                            }

                                        </TabPanel>
                                    )
                                })
                            }
                        </TabContext>
                    </div> : <div className="alert-message"> <h4>No Forms available to display </h4> </div>
                }

            </div>
            <div className=" mt-2 d-flex justify-content-end">
                <button className="btn-esecondary me-2 mb-2" onClick={onCancelHandler}>Cancel</button>
                <button className="btn-eprimary" onClick={onSubmitHandler} disabled={submitDisable}>Submit</button>
            </div>
        </React.Fragment >
    )
}
export default SelectFormVariables