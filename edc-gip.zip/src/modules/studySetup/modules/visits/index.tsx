import React from "react";
import { fetchAllVisitsByStudyId } from './actions/actions';
import { useDispatch, useSelector } from "react-redux";
import VisitDetails from "./components/VisitsDetails";
import './styles/visits.scss'
import { Types } from "./reducer/Types";
function Visits() {

    const dispatch = useDispatch()
    const loaded = React.useRef(false);
    const { currentStudy } = useSelector((state: any) => state.application)

    React.useEffect(() => {
        if (!loaded.current) {
        const _payload = {studyId: currentStudy.id,pageNo: 0,pageSize: 10}
        dispatch({ type: Types.LAZY_PAGINATION_VISITS, payload: _payload })
            dispatch(fetchAllVisitsByStudyId(_payload))
            loaded.current = true
        }
    }, [currentStudy.id,dispatch]);
    return (
        <React.Fragment>
            <VisitDetails />
        </React.Fragment>
    )
}
export default Visits;