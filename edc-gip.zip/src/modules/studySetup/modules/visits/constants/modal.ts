
import { addOrEditVisit, lazyParams } from "./dataTypes"


export const addOrEditVisitModal: addOrEditVisit = {
    id: '',
    visitName: '',
    visitTypeCode: '',
    ordinal: '',
    visitLockStatus: true,
    visitRepeat: 'false',
    status: true,
    studyId: ''
}

export const lazyParamsModal: lazyParams = {
    studyId: '',
    pageNo: 0,
    pageSize: 10
}

export const filterSelection = [
    { id: 'visitName', formName: 'Visit Name' },
    { id: 'visitForms', formName: ' Forms Name' },
]