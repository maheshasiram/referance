export type addOrEditVisit = {
    id?: any
    visitName?: string
    visitTypeCode?: string
    ordinal?: any
    visitLockStatus?: boolean
    visitRepeat?: any
    status?: boolean,
    studyId?: any
}

export type lazyParams = {
    studyId?: any
    pageNo?: any
    pageSize?: any
}