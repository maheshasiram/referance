export const logDetails = [
    {
        sno: 1,
        name: 'Lalitha',
        auditDate: '04-11-2023',
        auditTime: '14:06'
    },
    {
        sno: 2,
        name: 'Kishore',
        auditDate: '16-01-2022',
        auditTime: '23:30'
    },
    {
        sno: 3,
        name: 'Naveen',
        auditDate: '14-05-2022',
        auditTime: '12:00'
    },
    {
        sno: 4,
        name: 'Aishwarya',
        auditDate: '16-12-2023',
        auditTime: '20:00'
    },
    {
        sno: 5,
        name: 'Aboli',
        auditDate: '04-11-2022',
        auditTime: '21:22'
    }
]