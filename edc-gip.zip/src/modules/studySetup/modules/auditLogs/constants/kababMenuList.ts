export const kababMenuList = [{
    'name': 'Previous 12 Months',
    'value': '12'
}, {
    'name': 'Previous 6 Months',
    'value': '6'
},
{
    'name': 'Previous 3 Months',
    'value': '3'
},
{
    'name': 'Previous 1 Months',
    'value': '1'
}
]