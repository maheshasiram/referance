
export type auditLog = {
    studyId?: number,
    userId?: number,
    auditTableListCode?: string,
    auditActionTypeCode?: string,
    auditTableColumn?: string,
    limit?: number,
    offset?: number,
    startDate?: string,
    endDate?: string
}