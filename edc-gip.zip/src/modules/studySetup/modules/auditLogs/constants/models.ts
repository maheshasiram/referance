import { auditLog } from "./dataType";

export const auditLogModal: auditLog =
{
    "studyId": 0,
    "userId": 0,
    "auditTableListCode": "",
    "auditActionTypeCode": "",
    "auditTableColumn": "",
    "limit": 10,
    "offset": 0,
    "startDate": "",
    "endDate": ""
  }