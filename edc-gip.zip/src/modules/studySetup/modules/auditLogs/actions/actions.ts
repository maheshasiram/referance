import { Loader } from "../../../../../actions/actions";
import { studySetup } from "../../../../../configs/enivornment/studySetup";
import { fetch } from "../../../../../constants/fetch";
import { Types } from "../reducers/Types";


export const fetchAuditLogsByStudyId: any = (payload: any, callback: any) => {
  // console.log("....8",payload)
  const url = `${studySetup.auditLogs.fetchAuditLogsByStudyId}`
  return (dispatch: any) => {
    dispatch(Loader(true))
    fetch({
      method: 'POST',
      url: url,
      data: payload
    })
      .then((response: any) => {
        if (callback) { callback(response.data) }
        dispatch({ type: Types.AUDIT_LOGS_BY_STUDYID, payload: response.data })
        dispatch(Loader(false));
        console.log("203", response)
      })
  }
}

