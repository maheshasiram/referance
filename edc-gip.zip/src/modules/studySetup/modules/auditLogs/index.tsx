import React from "react";
import AuditLogsDashBoard from "./components/AuditLogsDashBoard";

function AuditLogs() {
    return (
        <React.Fragment>
            <div>
                <AuditLogsDashBoard />
            </div>
        </React.Fragment>
    )

}
export default AuditLogs;