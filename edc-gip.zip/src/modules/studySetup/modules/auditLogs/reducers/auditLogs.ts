import { Types } from "./Types";
import { auditLogModal } from "../constants/models";

const initialState = {
    auditLogPayload: auditLogModal,
    auditLogs: [],
    actionType: [],
    objList: []
}

export const auditLogs = (state = initialState, action: any) => {
    switch (action.type) {
        case Types.AUDIT_LOG_PAYLOAD:
            console.log("reducer.....AUDIT_LOG_PAYLOAD",action.payload)
            return { ...state, auditLogPayload: action.payload }
        case Types.AUDIT_LOGS_BY_STUDYID:
            return { ...state, auditLogs: action.payload }
        case Types.CONFIG_ACTION_TYPE:
            return { ...state, actionType: action.payload }
        case Types.ONJECT_LIST:
            console.log("reducer obj list...", action.payload)
            return { ...state, objList: action.payload }
        default: return { ...state }

    }
}