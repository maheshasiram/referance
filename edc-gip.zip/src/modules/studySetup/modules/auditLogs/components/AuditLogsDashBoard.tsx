import React from "react";
import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import AuditLogKababMenu from "./AuditLogKababMenu";
import { fetchAuditLogsByStudyId } from "../actions/actions";
import { useSelector, useDispatch } from "react-redux";
import moment from "moment";
import { configDataType } from "../../../../../actions/actions";
import { Types } from "../reducers/Types";
import Loader from "../../../../../common/loader/Loader";
import PageCount from "../../../../../common/pagecount/PageCount";

function AuditLogsDashBoard() {
    const { auditLogs, actionType, objList, auditLogPayload } = useSelector((state: any) => state.auditLogs)
    const { currentStudy, isLoader,currentUser } = useSelector((state: any) => state.application);
    const dispatch = useDispatch();
    const loaded = React.useRef(false);
    const [auditTable, setAuditTable] = React.useState('')
    const [currentDate, setCurrentDate] = React.useState('')
    
    const [selectedAction, setSelectedAction] = React.useState('')
    const [pageClick, setpageChange] = React.useState(false);

    React.useEffect(() => {
        const today = new Date()
        const date = today.getFullYear() + '-' + ("0" + (today.getMonth() + 1)).slice(-2) + '-' + today.getDate();
        setCurrentDate(date)
        console.log("....28", moment().subtract(6, 'months').format('DD-MM-YYYY'))
        console.log("....29", moment().subtract(12, 'months').format('DD-MM-YYYY'))
        console.log("....30", moment().subtract(3, 'months').format('DD-MM-YYYY'))

    }, [])

    // React.useEffect(() => {
    //     if (objList?.length) {
    //         dispatch(fetchAuditLogsByStudyId({
    //             ...auditLogPayload,
    //             // studyId: currentStudy.id, userId: 1, auditTableListCode: objList[0].code, auditActionTypeCode: '', auditTableColumn: '', startDate: moment().format('YYYY-MM-DD'), endDate: moment().format('YYYY-MM-DD')
    //             studyId: currentStudy.id, userId: 1, auditTableListCode: '', auditActionTypeCode: '', auditTableColumn: '', startDate: moment().format('YYYY-MM-DD'), endDate: moment().format('YYYY-MM-DD')
    //         }))
    //         loaded.current = true
    //     }
    //     }, [objList])


    React.useEffect(() => {
        if (!loaded.current) {
            console.log("loaded.current..", !loaded.current)
            dispatch(configDataType('ACTION_TYP', (data: any) => {
                dispatch({ type: Types.CONFIG_ACTION_TYPE, payload: data.ACTION_TYP })
            }))
            dispatch(configDataType('OBJ_LIST', (data: any) => {
                dispatch({ type: Types.ONJECT_LIST, payload: data.OBJ_LIST })
            }))
            dispatch(fetchAuditLogsByStudyId({
                ...auditLogPayload,
                studyId: currentStudy.id, userId: currentUser.id, auditTableListCode: '', auditActionTypeCode: '', limit: 10, auditTableColumn: '', startDate: moment().format('YYYY-MM-DD'), endDate: moment().format('YYYY-MM-DD')
            }))
            loaded.current = true
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const actionTimeTemplate = (rowData: any) => {
        const auditTime = moment(rowData.auditDate).format(' h:mm:ss a')
        return (
            <div>
                {auditTime}
            </div>
        )
    }

    const onModuleChange = (e: any) => {
        const _payload = {
            studyId: currentStudy.id,
            userId:currentUser.id,
            auditTableListCode: e.target.value,
            auditActionTypeCode: '',
            auditTableColumn: '',
            limit: 10,
            // offset: auditLogPayload.offset,
            offset: 0,
            startDate: moment().format('YYYY-MM-DD'),
            endDate: moment().format('YYYY-MM-DD')
        }
        dispatch({ type: Types.AUDIT_LOG_PAYLOAD, payload: _payload })
        console.log("86....",_payload)
        dispatch(fetchAuditLogsByStudyId(_payload))
        setSelectedAction('')
        setAuditTable(e.target.value)
    }

    const onActionChange = (e: any) => {
        const _payload = {
            studyId: currentStudy.id,
            userId: currentUser.id,
            auditTableListCode: auditTable,
            auditActionTypeCode: e.target.value,
            auditTableColumn: '',
            limit: 10,
            offset: auditLogPayload.offset,
            startDate: moment().format('YYYY-MM-DD'),
            endDate: moment().format('YYYY-MM-DD')
        }
        dispatch({ type: Types.AUDIT_LOG_PAYLOAD, payload: _payload })
        dispatch(fetchAuditLogsByStudyId(_payload))
        setSelectedAction(e.target.value)
    }
    console.log('auditLogs', auditLogs);

    const onPageChange = (e: any) => {
        console.log("first....100", e)
        if (((e.page > 0 )||(pageClick && e.page === 0)) && auditLogPayload.offset !== e.first) {
            // if ((e.page > 0 || pageClick && e.page == 0)) {
            const _payload = {
                ...auditLogPayload, offset: e.first, studyId: currentStudy.id,
                userId: currentUser.id, startDate: moment().format('YYYY-MM-DD'),
                endDate: moment().format('YYYY-MM-DD')
            }
            console.log("....103 _payload", _payload, "....auditLogPayload", auditLogPayload)
            dispatch({ type: Types.AUDIT_LOG_PAYLOAD, payload: _payload })
            dispatch(fetchAuditLogsByStudyId(_payload))
            setpageChange(true)
        }
    }
    const onChangePageCount = (e: any) => {
        // let _payload = { ...auditLogPayload,    }
        const _payload = {
            ...auditLogPayload, offset: e.first, studyId: currentStudy.id, limit: parseInt(e.target.value),
            userId: currentUser.id, startDate: moment().format('YYYY-MM-DD'),
            endDate: moment().format('YYYY-MM-DD')
        }
        dispatch({ type: Types.AUDIT_LOG_PAYLOAD, payload: _payload })
        dispatch(fetchAuditLogsByStudyId({ ..._payload, }))
        console.log('..129', _payload);

    }

    console.log("..auditLogs", auditLogs)
    return (
        <React.Fragment>
            {isLoader && <Loader />}
            <div className="d-flex justify-content-between pb-2 controls-container">
                <PageCount onChange={(e: any) => onChangePageCount(e)} />
                <div className="d-flex sites">
                    <div className="left-container"></div>
                </div>
                <div className="right-panel d-flex">
                    <AuditLogKababMenu setCurrentDate={setCurrentDate} currentDate={currentDate} selectedAction={selectedAction} auditTable={auditTable} />
                    <select className="form-select form-control-lg"
                        onChange={(e: any) => onModuleChange(e)}
                        value={auditTable}
                    >
                        <option value="">Select Module</option>
                        {
                            objList && objList.map((i: any, index: any) => (
                                <option key={index} value={i.code}>{i.name}</option>
                            ))
                        }
                    </select>
                    <select className='form-select form-control-lg'
                        onChange={(e: any) => onActionChange(e)}
                        value={selectedAction}
                    >
                        <option value=''>Select Action</option>
                        {actionType && actionType.map((i: any, index: any) => (
                            <option key={index} value={i.code}>{i.name}</option>
                        ))
                        }
                    </select>
                </div>
            </div>
            <div>
                <DataTable
                    value={auditLogs.auditLogs}
                    rows={auditLogPayload.limit}
                    lazy
                    scrollable
                    paginator={(auditLogs && auditLogs.totalRecords && auditLogs.totalRecords > auditLogPayload.limit) ? true : false}
                    first={auditLogs && auditLogs.offSet}
                    totalRecords={auditLogs.totalRecords}
                    onPage={(e: any) => onPageChange(e)}
                    responsiveLayout="scroll"
                >
                    <Column header="Module"  field="module"></Column>
                    <Column header='Field' field="auditTableColumn"></Column>
                    <Column header='New Value' field="newValue"></Column>
                    <Column header='Old Value' field="oldValue"></Column>
                    <Column header="Date" field="auditLocalDate"></Column>
                    <Column header="Time" body={actionTimeTemplate}></Column>
                    <Column header='User Name' field="userName"></Column>
                </DataTable>
            </div>
        </React.Fragment>
    )
}
export default AuditLogsDashBoard;