import * as React from 'react';
import IconButton from '@mui/material/IconButton';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { Popover } from '@mui/material';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import { kababMenuList } from '../constants/kababMenuList';
import '../../auditLogs/styles/Styles.scss'
import { useSelector, useDispatch } from "react-redux";
import { fetchAuditLogsByStudyId } from '../actions/actions';
import { auditLogModal } from '../constants/models';
import moment from "moment";


function AuditLogKababMenu(props: any) {
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const { currentStudy,currentUser } = useSelector((state: any) => state.application);
  const dispatch = useDispatch();
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = (e: any, option: any) => {
    console.log(e,option)
    setAnchorEl(null)
  };

  const onHandleChange = (e: any, value: any) => {
    console.log("...24", value)
    setAnchorEl(null)
    const _startDate = moment().subtract(value, 'months').format('YYYY-MM-DD')
    console.log("....38", _startDate)
    dispatch(fetchAuditLogsByStudyId({
      ...auditLogModal, studyId: currentStudy.id, userId: currentUser.id, auditTableListCode: props.auditTable, auditActionTypeCode: props.selectedAction, auditTableColumn: '', startDate: _startDate, endDate: moment().format('YYYY-MM-DD')
    }))
  }
  console.log("45....", props.auditTable)
  return (
    <div className='kabab-menu'>
      <IconButton
        aria-label="more"
        id="long-button"
        aria-controls={open ? 'long-menu' : undefined}
        aria-expanded={open ? 'true' : undefined}
        aria-haspopup="true"
        onClick={handleClick}
      >
        <MoreVertIcon />
      </IconButton>
      <Popover
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
      >
       
        {
          kababMenuList.map((item, index) => (
            <nav key={index} aria-label="secondary mailbox folders">
              <List className='kabab-menu-list'>
                <ListItem disablePadding className='kabab-menu-listItem'>
                  <ListItemButton className='kabab-menu-ItemBtn'
                    id={item.value}
                    onClick={(e: any) => onHandleChange(e, item.value)}>
                    <ListItemText primary={item.name} />
                  </ListItemButton>
                </ListItem>
              </List>
            </nav>
          ))
        }

      </Popover>
    </div>
  );
}
export default AuditLogKababMenu;
