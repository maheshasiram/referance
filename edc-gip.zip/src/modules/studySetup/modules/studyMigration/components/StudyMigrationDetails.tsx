import React from 'react'
// import { Formik, Form, Field, ErrorMessage } from 'formik';
import '../styles/Style.scss'
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import FileDownloadOutlinedIcon from '@mui/icons-material/FileDownloadOutlined';
import { Alert } from '../../../../../actions/actions';
import { useDispatch } from 'react-redux';
import DeployChangesProductionEnv from './DeployChangesProductionEnv';
import { Types } from '../reducers/Types';
import PageCount from '../../../../../common/pagecount/PageCount';
import { data ,data2} from '../constants/deploymentData';

function StudyMigrationDetails() {
  const [selectVal, setSelectVal] = React.useState('')
  const [open, setOpen] = React.useState(false);
  const [pageClick, setpageChange] = React.useState(false);
  const [first, setFirst] = React.useState(0);
  const [rows, setRows] = React.useState(8);


  const dispatch = useDispatch()

  const onPage = (event: any) => {
    setFirst(event.first);
    setRows(event.rows);
    if ((event.page > 0) || (pageClick && event.page === 0)) {
      setpageChange(true)
    }
  }
  const onChangeHandler = (e: any) => {
    setFirst(0);
    setSelectVal(e.target.value)
  }
  const actionsBodyTemplate = () => {
    return <div className='actions d-flex align-items-center' >
      <React.Fragment>
        <FileDownloadOutlinedIcon sx={{ fontSize: 14, opacity: .8 }} />
      </React.Fragment>

    </div>
  }
  const onDownloadStudyData = () => {
    dispatch(Alert({
      status: 2,
      message: 'Downloading of study data dictionary has started. you will get confirmation mail on completion.',
      onOk: () => {
        return null;
      }
    }))
  }
  const onDeploymentChange = () => {
    dispatch(Alert({
      status: 2,
      message: 'Creating development changes report job. You will get confirmation mail on completion.',
      onOk: () => {
        return null;
      }
    }))
  }


  

  const onOpenDeployChangesModal = () => {
    setOpen(true);
    dispatch({ type: Types.REASON_FOR_MIGRATION, payload: true });
  }
  const onChangePageCount = (e: any) => {
    console.log('jip', e);

  }

  return (
    <React.Fragment>
      {open && <DeployChangesProductionEnv setOpen={setOpen} />}
      <div className=' '>
        <div className='row mt-3 '>
          <div className='col-sm-4 form-group'>
            <label>From :</label>
            <select name='fromInstance' className="form-select" aria-label="Default select example"
              onChange={(e: any) => {
                onChangeHandler(e)
              }}
            >
              <option value="">--Select One--</option>
              <option value="DevInstance"> Development</option>
              <option value="UATInsatance">UAT</option>
            </select>
          </div>

          <div className='col-sm-4 form-group'>
            <label>To :</label>
            <select name="to" id="toInstance" className={selectVal !== '' ? "form-select pe-none" : "form-select pe-all"}  >
              {selectVal === "UATInsatance" ? (<option value="Production">Prduction</option>)
                : (selectVal === "DevInstance") ? (<option value="UAT">UAT</option>)
                  : (<>
                    <option value="">--Select One--</option>
                    <option value="Production">Prduction</option>
                    <option value="DevInstance">UAT</option></>)
              }
            </select>
          </div>
          <div className={selectVal !== '' ? "col-sm-4 mt-3" : 'd-none'} id='dataDictionary'
            onClick={() => { onDownloadStudyData() }}
          >State Data dictionary</div>
        </div>
      </div>
      <hr />
      <div className={selectVal === '' ? "alert alert-info" : 'd-none'} >Please Select Instance</div>

      <div className='d-flex deployTitle'
      >
        <div className={selectVal !== '' ? "col-sm-3 d-flex recentDevTitle" : 'd-none'} >
          <PageCount onChange={(e: any) => onChangePageCount(e)} />
        </div>
        <div className={selectVal !== '' ? "col-sm-4 d-flex recentDevTitle" : 'd-none'} >Recent Deployment
          {`${selectVal === 'DevInstance' ? (" ( UAT Environment )") : ("( Production Environment )")}`}
        </div>
        <div className={(selectVal === 'DevInstance') ? 'col-sm-5 d-flex download' : 'text-p col-sm-8   download pe-none'}
        >
          <span className={selectVal !== '' ? "text-p" : 'd-none'} id='pendingReport' onClick={() => { onDeploymentChange() }}>
            Development Changes</span>
          <span className={selectVal !== '' ? "text-p" : 'd-none'} id='deployChanges' onClick={onOpenDeployChangesModal}> Deploy Changes
            {`${selectVal === 'DevInstance' ? (" ( UAT Environment )") : ("( Production Environment )")}`}
          </span>
        </div>
      </div>

      {selectVal && <div >
        <DataTable
          scrollable
          value={selectVal === "DevInstance" ? data2 : data}
          responsiveLayout="scroll"
          rows={rows}
          paginator={true}
          first={first}
          totalRecords={selectVal === "DevInstance" ? data2.length : data.length}
          // lazy
           onPage={(e: any) => onPage(e)}
        >
          <Column field="DeploymentID" header="Deployment ID"></Column>
          <Column field="User_Name" header="User Name"></Column>
          <Column field="Date" header="Date"></Column>
          <Column field="Comments" header="Comments"></Column>
          {<Column body={actionsBodyTemplate} header="Action"></Column>}

        </DataTable>
      </div>}
    </React.Fragment>
  )
}

export default StudyMigrationDetails;