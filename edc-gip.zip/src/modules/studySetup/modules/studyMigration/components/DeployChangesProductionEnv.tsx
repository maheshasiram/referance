import React from 'react'
import CustomDialog from '../../../../../common/modals/CustomeDialog'
import { Formik, Form, Field } from 'formik';
import '../styles/Style.scss'
import * as Yup from 'yup';

function DeployChangesProductionEnv(props: any) {
    // const [btnDisable, setBtnDisable] = React.useState(true);
    const { setOpen } = props;
    const onCloseHandler = () => {
        setOpen(false)
    }
    const studyMigrationSchema = Yup.object().shape({
        reasonText: Yup.string()
            .required('Please enter reason for migration'),
    })


    const onSubmitDeployChanges = (values: any) => {
        console.log(values)
        //   setOpen(false)

    }
    return (
        <React.Fragment>
            <CustomDialog
                title={'Reason for Migration'}
                onClose={onCloseHandler}
                onSubmitHandler={() => { return null}}
                open={true}
                maxWidth='xs'
                fullWidth={false}
                actionType={'Submit'}
                form="site-submit"
            >
                <Formik
                    enableReinitialize={true}
                    initialValues={{ reasonText: '' }}
                    validationSchema={studyMigrationSchema}
                    onSubmit={values => {
                        onSubmitDeployChanges(values);
                    }}
                >

                    {({ errors, touched, values }) => (
                        <Form id="site-submit" className='sites-form'>
                            <div className='text-danger text-center m-2 p-2'> {errors.reasonText && touched.reasonText && errors.reasonText}</div>

                            <Field
                                name="reasonText"
                                className='textar'
                                value={values.reasonText}
                                as='textarea'
                            ></Field>
                        </Form>
                    )}
                </Formik>

            </CustomDialog>

        </React.Fragment>
    )
}

export default DeployChangesProductionEnv