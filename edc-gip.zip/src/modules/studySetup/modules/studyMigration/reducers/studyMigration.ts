// import { Types } from "./Types"


const initialState = {
}

export const studyMigration = (state = initialState, action: { type: string, payload: any }) => {
  switch (action.type) {
    default:
      return { ...state }
  }
}