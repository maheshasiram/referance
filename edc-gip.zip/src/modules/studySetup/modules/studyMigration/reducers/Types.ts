export const Types = {

    REASON_FOR_MIGRATION:"REASON_FOR_MIGRATION"
}