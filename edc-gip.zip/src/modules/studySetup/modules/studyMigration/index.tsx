import React from 'react'
import StudyMigrationDetails from './components/StudyMigrationDetails';
function StudyMigration() {
    
    return (
        <React.Fragment>          
            
           <StudyMigrationDetails />
           
        </React.Fragment>
    )
}
export default StudyMigration;