import * as Yup from 'yup';

export const StudySchema = () => {
    return Yup.object().shape({
        protocolId: Yup.string()
            .required(' Please enter protocol id'),
        sponsorName: Yup.string()
            .required(' Please enter organization name')
            .matches(/^[^\s]/, "Organization name should not start with space")
            // .matches(/^[^\d]+$/, "Organization Name Should Not Contain Numbers")
            .matches(/^[^*|":<>[\]{}`\\()';@&$#!%]/, 'Organization name should not start with special characters'),
        protocolTitle: Yup.string()
            .required(' Please enter study description')
            .matches(/^[^\s]/, "Study description should not start with space")
            .matches(/^[^\d]/, "Study description should not start with numbers")
            .matches(/^[^*|":<>[\]{}`\\()';@&$#!%]/, 'Study description should not start with special characters'),
        startDate: Yup.string()
            .required(' Please select start date'),
        endDate: Yup.string()
            .required(' Please select end date'),
        totalSubEnrollCount: Yup.number()
            .required(' Please enter total subject enroll count')
            .min(1, 'Please enter total subject enroll count should be greater than zero'),
        subIdFormat: Yup.object().shape({
            length: Yup.string().matches(/^[1-9][0-9]*$/, ("Should not start with 0")).required(' Please enter subject id length')
        }),
        subjectSampleSize: Yup.string()
            .required('Please enter sample size.')
            .min(1, 'Please enter sample size greater than zero.'),
        visitsCount: Yup.number()
            .required('Please enter visits')
            .min(1, 'Please enter visits count greater than 1'),
        subIdCreation: Yup.string()
            .required(' Please enter subject id creation'),
    })
}