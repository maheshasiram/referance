import React, { useState } from 'react'
import { useDispatch, useSelector } from "react-redux";
import { Formik, Form, Field, ErrorMessage, } from 'formik';
import CustomDialog from '../../../../../common/modals/CustomeDialog';
import { StudySchema } from '../helpers/Validation'
import { getCurrentStudyDetails, saveOrUpdateStudy } from '../actions/actions';
import { toastAlert, configDataType } from '../../../../../actions/actions';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorIcon from '@mui/icons-material/Error';
import CustomToolTip from '../../../../../components/CustomToolTip';
import { Types } from '../reducer/Types';


function StudyDetails(props: any) {
  const dispatch = useDispatch();
  const { study, subjectIdTypes, dateFormat, timeFormat } = useSelector((state: any) => state.study);
  const [btnDisable, setBtnDisable] = React.useState(true)
  const [subIdvalidations, setSubIdValidation] = React.useState('')
  const [preview, setPreview] = React.useState('')
  const [validateReg, setValidateRegex] = useState('')
  const loaded = React.useRef(false);

  const onCancelHandler = () => {
    props.onOpen(false)
    setBtnDisable(true)
    setValidateRegex('')
  }
  React.useEffect(() => {
    if (!loaded.current) {
      dispatch(configDataType('DATE_FORMAT', (data: any) => {
        dispatch({ type: Types.CONFIG_DATE_FORMAT, payload: data.DATE_FORMAT })
      }))
      dispatch(configDataType('TIME_FORMAT', (data: any) => {
        dispatch({ type: Types.CONFIG_TIME_FORMAT, payload: data.TIME_FORMAT })
      }))
      loaded.current = true
    }
    study?.subIdFormat?.alphabet ? setSubIdValidation('[A-Z][0-9]') : setSubIdValidation('[0-9]')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dispatch])

  const onChangeHandler = (e: any, setFieldValue: any, setFieldTouched: any, fieldName: any, values: any) => {
    console.log(values)
    setFieldTouched(fieldName, true)
    setFieldValue(fieldName, e.target.value)
    setBtnDisable(false)

  }

  const Preview = (values: any) => {
    const arr: any = [];
    for (let i = 1; i <= values.subIdFormat.length; i++) {
      if (values.subIdFormat.alphabet) {

        if (i > 0 && i < 10 && i < values.subIdFormat.length) {
          if (i === values.subIdFormat.length - 1) {
            arr.push(1)
          } else {
            arr.push(0)
          }
        }
      } else {
        if (i > 0 && i < 10) {
          if (i === values.subIdFormat.length) {
            arr.push(1)
          } else {

            arr.push(0)
          }
        }
      }
    }
    if (values.subIdFormat.alphabet) {
      setPreview(`A${arr.join('')}`)
    } else {
      setPreview(arr.join(''))
    }
    return preview
  }
  const validateRegex = (values: any) => {
    const matches = values && values.subIdValidation && values.subIdFormat.alphabet ? values.subIdValidation.match(/\[(.*?)\]\[(.*?)\]/) : values.subIdValidation.match(/\[(.*?)\]/);
    if (matches) {
      const submatch = matches[0];
      const _regex = new RegExp(`^${submatch}{${values.subIdFormat.alphabet ? values.subIdFormat.length - 1 : values.subIdFormat.length}}$`)
      const validated = _regex.test(validateReg)
      return validated
    }
  }
  const onChangeValidateReg = (e: any) => {
    setValidateRegex(e.target.value.toUpperCase())
  }
  const onSubmitHandler = (values: any) => {
    const { ...studyPayload } = values;
    studyPayload.subIdValidation = `^${subIdvalidations}{${values.subIdFormat.length}}$`
    studyPayload.subIdFormat.preview = preview
    studyPayload.subIdCount = values.subIdFormat.length
    dispatch(saveOrUpdateStudy(studyPayload, (data: any) => {
      if (data.status === "error") {
        props.onOpen(true)
        dispatch(toastAlert({
          status: 2, message: `${data.errorMessage}`, open: true,
        }))
      } else {
        dispatch(getCurrentStudyDetails(studyPayload.id))
        props.onOpen(false)
        dispatch(toastAlert({
          status: 1, message: 'Study updated successfully', open: true
        }))
        setValidateRegex('')
      }
    }))
  }

  return (
    <CustomDialog
      open={props.open}
      onClose={onCancelHandler}
      actionType='Update'
      form='EditStudyId'
      title='Edit Study'
      disabled={btnDisable}
    >
      <Formik
        initialValues={study}
        validationSchema={StudySchema()}
        onSubmit={(values) => { onSubmitHandler(values) }}
      >{({ values, setFieldValue, setFieldTouched }) => (
        <Form id='EditStudyId'>
          <div className='row'>
            <div className='col-sm-4'>
              <div className='form-group me-4 mb-1'>
                <label>Sponsor:</label>
                <Field
                  name='sponsorName'
                  className="form-control form-control-lg text-Field"
                  id="orgNsponsorNameame"
                  disabled
                />
                <span className='text-danger'><ErrorMessage name='sponsorName' /></span>
              </div>
            </div>
            <div className='col-sm-4'>
              <div className='form-group me-4 mb-1'>
                <label>Therapeutic Area:</label>
                <Field
                  name='therapeuticArea'
                  className="form-control form-control-lg text-Field"
                  id="therapeuticAreaId"
                  disabled
                />
                <span className='text-danger'><ErrorMessage name='therapeuticArea' /></span>
              </div>
            </div>
            <div className='col-sm-4'>
              <div className='form-group me-4 mb-1'>
                <label>Protocol ID:</label>
                <Field
                  name='protocolId'
                  className="form-control form-control-lg text-Field"
                  id="protocolId"
                  disabled
                />
                <span className='text-danger'><ErrorMessage name='protocolIdprotocolTitle' /></span>
              </div>
            </div>
          </div>
          <div className='row'>
            <div className='col-sm-12'>
              <div className='form-group me-4 mb-1'>
                <label>Protocol Title:</label>
                <Field
                  name='protocolTitle'
                  className="form-control form-control-lg text-Field"
                  id="protocolTitle"
                  disabled
                />
                <span className='text-danger'><ErrorMessage name='protocolTitle' /></span>
              </div>
            </div>
          </div>
          <div className='row'>
            <div className='col-sm-4'>
              <div className='form-group me-4 mb-1'>
                <label>Study type:</label>
                <Field
                  name='studyType'
                  className="form-control form-control-lg text-Field"
                  disabled
                />
                <span className='text-danger'><ErrorMessage name='studyType' /></span>
              </div>
              <div className='form-group me-4 mb-1'>
                <label>Indications:</label>
                <Field
                  name='indications'
                  className="form-control form-control-lg text-Field"
                  disabled
                />
                <span className='text-danger'><ErrorMessage name='indications' /></span>
              </div>
              <div className='form-group me-4 mb-1'>
                <label>Investigation:</label>
                <Field
                  name='investigation'
                  className="form-control form-control-lg text-Field"
                  disabled
                />
                <span className='text-danger'><ErrorMessage name='investigation' /></span>
              </div>
              <div className='form-group me-4 mb-1'>
                <label>Date format: <span className='text-danger'>*</span></label>
                <Field
                  as='select'
                  name='dateFormat'
                  id='dateFormatId'
                  className="form-select form-control-lg"
                  value={values.dateFormat}
                  onChange={(e: any) => { onChangeHandler(e, setFieldValue, setFieldTouched, 'dateFormat', values) }}
                >
                  {
                    dateFormat.map((i: any, index: any) => {
                      return <option key={index} value={i.name}>{i.name}</option>
                    })
                  }

                </Field>
                <span className='text-danger'><ErrorMessage name='dateFormat' /></span>
              </div>
              <div className='form-group me-4 mb-2'>
                <label>Expected Enrollment Count:<span className='text-danger'>*</span></label>
                <Field
                  type='number'
                  name='totalSubEnrollCount'
                  className="form-control form-control-lg text-Field"
                  id="totalSubEnrollCount"
                  onKeyPress={(e: any) => {
                    if (e.key === "-" || e.key === "+" || e.key === "e" || e.key === ".") {
                      e.preventDefault();
                    }
                  }}
                  onChange={(e: any) => { onChangeHandler(e, setFieldValue, setFieldTouched, 'totalSubEnrollCount', values) }}
                />
                <span className='text-danger'><ErrorMessage name='totalSubEnrollCount' /></span>
              </div>
              <div className='form-group me-4 mb-1 mt-2 '>
                <label>Subject ID Format:<span className='text-danger'>*</span></label>
                <br />
                <div className='d-flex'>
                  <Field
                    type="checkbox"
                    name="subIdFormat.alphabet"
                    checked={values.subIdFormat.alphabet}
                    value={'A-Z'}
                    onChange={(e: any) => {
                      setFieldValue('subIdFormat.alphabet', e.target.checked)
                      setBtnDisable(false)
                      if (e.target.checked) {
                        setFieldValue('subIdValidation', values.subIdFormat.numeric ? `[A-Z][0-9]` : `[A-Z]`)
                        setSubIdValidation(values.subIdFormat.numeric ? `[A-Z][0-9]` : `[A-Z]`)
                      } else {
                        setFieldValue('subIdValidation', values?.subIdFormat?.numeric ? `[0-9]` : '')
                        setSubIdValidation(values?.subIdFormat?.numeric ? `[0-9]` : '')
                      }
                    }}
                  /><label htmlFor='subIdFormat.alphabet' className='mt-2 me-3 ms-1'>Alphabet</label>
                  <Field
                    type="checkbox"
                    name="subIdFormat.numeric"
                    onChange={(e: any) => {
                      setFieldValue('subIdFormat.numeric', e.target.checked)
                      setBtnDisable(false)
                      if (e.target.checked) {
                        setFieldValue('subIdValidation', values?.subIdFormat?.alphabet ? `[A-Z][0-9]` : `[0-9]`)
                        setSubIdValidation(values?.subIdFormat?.alphabet ? `[A-Z][0-9]` : `[0-9]`)
                      } else {
                        setFieldValue('subIdValidation', values?.subIdFormat?.alphabet ? `[A-Z]` : '')
                        setSubIdValidation(values?.subIdFormat?.alphabet ? `[A-Z]` : '')
                      }
                    }}
                    checked={values.subIdFormat && values.subIdFormat.numeric}
                    value={'0-9'}
                    disabled
                  />
                  <label htmlFor='subIdFormat.numeric' className='mt-2 me-1 ms-1'>Numeric</label>
                </div>
              </div>
            </div>
            <div className='col-sm-4'>
              <div className='form-group me-4 mb-1'>
                <label>Study Phase:</label>
                <Field
                  name='studyPhase'
                  className="form-control form-control-lg text-Field"
                  disabled
                />
                <span className='text-danger'><ErrorMessage name='studyPhase' /></span>
              </div>

              <div className='form-group me-4 mb-1'>
                <label>Population:</label>
                <Field
                  name='population'
                  className="form-control form-control-lg text-Field"
                  disabled
                />
                <span className='text-danger'><ErrorMessage name='population' /></span>
              </div>
              <div className='form-group me-4 mb-1'>
                <label>Start Date:</label>
                <Field
                  type='date'
                  name='startDate'
                  className="form-control form-control-lg text-Field"
                  disabled
                />
                <span className='text-danger'><ErrorMessage name='startDate' /></span>
              </div>
              <div className='form-group me-4 mb-1'>
                <label>Time format:<span className='text-danger'>*</span></label>
                <Field
                  as='select'
                  name='timeFormat'
                  className="form-select form-control-lg "
                  id="timeFormat"
                  value={values.timeFormat}
                  onChange={(e: any) => { onChangeHandler(e, setFieldValue, setFieldTouched, 'timeFormat', values) }}
                >
                  {
                    timeFormat.map((i: any, index: any) => {
                      return <option key={index} value={i.name}>{i.name}</option>
                    })
                  }
                </Field>
              </div>
              <div className='form-group me-4 mb-1'>
                <label>Sample size :<span className='text-danger'>*</span></label>
                <Field
                  type='number'
                  min="1"
                  name='subjectSampleSize'
                  className="form-control form-control-lg text-Field"
                  id="sampleSizeId"
                  placeholder="Enter sample size"
                  onKeyPress={(e: any) => {
                    if (e.key === "-" || e.key === "+" || e.key === "e" || e.key === ".") {
                      e.preventDefault();
                    }
                  }}
                  onChange={(e: any) => { onChangeHandler(e, setFieldValue, setFieldTouched, 'subjectSampleSize', values) }}
                />
                <span className='text-danger'><ErrorMessage name='subjectSampleSize' /></span>
              </div>
              <div className='form-group me-4 mb-1 '>
                <label>Subject Id Format Length:<span className='text-danger'>*</span></label>
                <div className='d-flex justify-content-around'>
                  <Field
                    min='1'
                    type='number'
                    name='subIdFormat.length'
                    className="form-control form-control-lg text-Field w-50"
                    id="subIdFormat"
                    onKeyPress={(e: any) => {
                      if (e.key === "-" || e.key === "+" || e.key === "e" || e.key === ".") {
                        e.preventDefault();
                      }
                    }}
                    onChange={(e: any) => {
                      props.subIFormatePreview()
                      if (e.target.value.length < 2) {
                        onChangeHandler(e, setFieldValue, setFieldTouched, 'subIdFormat.length', values)
                      }
                    }}
                  />
                  <div className='w-50 ms-3'>Preview : {Preview(values)}</div>
                </div>
              </div>
              <span className='text-danger '><ErrorMessage name='subIdFormat.length' /></span>
            </div>
            <div className='col-sm-4'>
              <div className='form-group me-4 mb-1'>
                <label>Study Design:</label>
                <Field
                  name='studyDesign'
                  className="form-control form-control-lg text-Field"
                  disabled
                />
                <span className='text-danger'><ErrorMessage name='Phase' /></span>
              </div>
              <div className='form-group me-4 mb-1'>
                <label>Regularitory:</label>
                <Field
                  name='regulatory'
                  className="form-control form-control-lg text-Field"
                  disabled
                />
                <span className='text-danger'><ErrorMessage name='regularitory' /></span>
              </div>
              <div className='form-group me-4 mb-1'>
                <label>End Date:</label>
                <Field
                  type='date'
                  name='endDate'
                  className="form-control form-control-lg text-Field"
                  disabled
                />
                <span className='text-danger'><ErrorMessage name='endDate' /></span>
              </div>
              <div className='form-group me-4 mb-1'>
                <label>Subject ID Type:</label>
                <Field
                  as='select'
                  name='subIdCreation'
                  className="form-select form-control-lg "
                  id="subIdCreationId"
                  value={values.subIdCreation}
                  disabled={values && values.configData && values.configData.name === 'manual' ? true : false}
                  onChange={(e: any) => { onChangeHandler(e, setFieldValue, setFieldTouched, 'subIdCreation', values) }}
                >
                  {
                    subjectIdTypes && subjectIdTypes.map((item: any, index: any) => {
                      return (
                        <option key={`subIdCreation_${index}`} value={item.id}>{item.name}</option>
                      )
                    })
                  }
                </Field>
              </div>
              <div className='form-group me-4 mb-1'>
                <label>Visits:<span className='text-danger'>*</span></label>
                <Field
                  type='number'
                  min="1"
                  name='visitsCount'
                  className="form-control form-control-lg text-Field"
                  id="visitsCountID"
                  onKeyPress={(e: any) => {
                    if (e.key === "-" || e.key === "+" || e.key === "e" || e.key === ".") {
                      e.preventDefault();
                    }
                  }}
                  onChange={(e: any) => { onChangeHandler(e, setFieldValue, setFieldTouched, 'visitsCount', values) }}
                />
                <span className='text-danger'><ErrorMessage name='visitsCount' /></span>
              </div>
              <div className='form-group me-4 mb-1'>
                <label>Sub Id Format :(Test)</label>
                <div className='d-flex align-items-center' >
                  <Field
                    type='string'
                    name='subValidMsg'
                    value={validateReg}
                    className="form-control form-control-lg text-Field"
                    id="validateReg"
                    onChange={onChangeValidateReg}
                  />


                  {
                    //changes in validations for sub id validations -Akshay
                    validateReg !== "" ? <div className='ms-2' >
                      {(validateRegex(values) ?
                        <CustomToolTip
                          title={'Validated'}
                        >
                          <CheckCircleIcon sx={{ color: 'green' }} />
                        </CustomToolTip> :
                        <CustomToolTip
                          title={validateReg ? validateReg.length !== values.subIdFormat.length ? 'Please check the Format Length' :
                            (!values.subIdFormat.alphabet && values.subIdFormat.numeric) ? 'Only Numeric values are accepted' : '' : 'Please enter string'
                          }
                        >
                          <ErrorIcon sx={{ color: 'tomato' }} />
                        </CustomToolTip>

                      )}
                    </div> : null
                  }

                </div>
              </div>
            </div>
          </div>
        </Form>
      )}
      </Formik>
    </CustomDialog>
  )
}
export default StudyDetails