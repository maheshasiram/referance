import { Types } from "./Types"
import { StudyModal } from '../constants/modal';

const initialState = {
  study: StudyModal,
  allStudies: [],
  subjectIdTypes: [],
  subIdFormatPreview:'',
  timeFormat:[],
  dateFormat:[],
}

export const study = (state = initialState, action: { type: string, payload: any }) => {
  switch (action.type) {
    case Types.GET_STUDY_DETAILS:
      return { ...state, study: action.payload }
    case Types.GET_ALL_STUDIES:
      return { ...state, allStudies: action.payload }
    case Types.SUBJECT_ID_CREATION_CONFIG:
      return { ...state, subjectIdTypes: action.payload }
    case Types.SUBJECT_ID_FORMAT_PREVIEW:
      return {...state, subIdFormatPreview:action.payload}
    case Types.CONFIG_TIME_FORMAT:
      return {...state, timeFormat:action.payload}
    case Types.CONFIG_DATE_FORMAT:
      return {...state, dateFormat:action.payload}
    default:
      return { ...state }
  }
}