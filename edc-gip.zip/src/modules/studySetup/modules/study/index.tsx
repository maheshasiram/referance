import React from "react";
import { useDispatch, useSelector } from "react-redux";
import EditIcon from '@mui/icons-material/Edit';
import StudyDetails from "./components/StudyDetails";
import './styles/study.scss';
import { configDataType } from '../../../../actions/actions';
import { Types } from './reducer/Types'
import moment from "moment";
import CustomToolTip from "../../../../components/CustomToolTip";

function Study() {
  const [open, setOpen] = React.useState(false)
  const [subIdFormat, setSubIdFormat] = React.useState('')
  const { currentStudy } = useSelector((state: any) => state.application)
  const dispatch = useDispatch()
  // const { study } = useSelector((state: any) => state.study);
  const loaded = React.useRef(false);

  const onUpdateStudy = () => {
    setOpen(true)
  }

  React.useEffect(() => {
    if (!loaded.current) {
      dispatch(configDataType('SUB_ID_CREATION', (data: any) => {
        dispatch({ type: Types.SUBJECT_ID_CREATION_CONFIG, payload: data.SUB_ID_CREATION })
      }))
      loaded.current = true
    }
  }, [dispatch])

  const subIFormatePreview :any = () => {
    const arr: any = [];
    for (let i = 1; i <= currentStudy.subIdFormat?.length; i++) {
      if (currentStudy.subIdFormat.alphabet) {

        if (i > 0 && i < 10 && i < currentStudy.subIdFormat.length) {
          if (i === currentStudy.subIdFormat.length - 1) {
            arr.push(1)
          } else {
            arr.push(0)
          }
        }
      } else {
        if (i > 0 && i < 10) {
          if (i === currentStudy.subIdFormat.length) {
            arr.push(1)
          } else {
            arr.push(0)
          }
        }
      }
    }
    if (currentStudy.subIdFormat?.alphabet) {
      setSubIdFormat(`A${arr.join('')}`)
    } else {
      setSubIdFormat(arr.join(''))
    }
    return subIdFormat
  }
  React.useEffect(() => {
    subIFormatePreview()
     // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentStudy])


  return (
    <React.Fragment>
      <StudyDetails open={open} onOpen={(value: any) => setOpen(value)} subIFormatePreview={subIFormatePreview} />
      <div className="">
        <div className="Study-details d-flex">{currentStudy && currentStudy.protocolId}
          <div className="edit-icon mx-2">
            <CustomToolTip title='Edit Study'><EditIcon onClick={onUpdateStudy} /></CustomToolTip>
          </div>
        </div>
        <div className="study-desc">{<div>{currentStudy && currentStudy.protocolTitle}</div>}
        </div>
        <div className="card study-info-container">
          <div className="card-header d-flex justify-content-between">
            <div className="d-flex">
              <span >Start Date : </span>
              <span>{currentStudy?.startDate && moment(currentStudy.startDate).format('DD-MM-YYYY')}</span>
            </div>
            <div className="d-flex">
              <span className="d-flex"> End Date : </span>
              <span className="endDate mx-2">{currentStudy?.endDate && moment(currentStudy.endDate).format('DD-MM-YYYY')}</span>
            </div>
            <div className="d-flex">
              <span>Expected Enrollment : </span>
              <span>{currentStudy && currentStudy.totalSubEnrollCount}</span>
            </div>
          </div>
          <div className="d-flex  card-body">
            <div className="col-sm-6">
              <div className="d-flex">
                <span>Sponsor : </span>
                <span>&nbsp;&nbsp;{currentStudy && currentStudy.sponsorName}</span>
              </div>
              <div className="d-flex">
                <span>Protocol ID : </span>
                <span>&nbsp;&nbsp;{currentStudy && currentStudy.protocolId}</span>
              </div>
              <div className="d-flex">
                <span>Therapeutic Area : </span>
                <span>&nbsp;&nbsp;{currentStudy && currentStudy.therapeuticArea}</span>
              </div>
              <div className="d-flex">
                <span>Study Phase : </span>
                <span>&nbsp;&nbsp;{currentStudy && currentStudy.studyPhase}</span>
              </div>
              <div className="d-flex">
                <span>Regularitory Type : </span>
                <span>&nbsp;&nbsp;{currentStudy && currentStudy.regulatory}</span>
              </div>
              <div className="d-flex">
                <span>Population : </span>
                <span>&nbsp;&nbsp;{currentStudy && currentStudy.population}</span>
              </div>
              <div className="d-flex">
                <span>Protocol Title : </span>
                <span>&nbsp;&nbsp;{currentStudy && currentStudy.protocolTitle}</span>
              </div>
              <div className="d-flex">
                <span>Indications : </span>
                <span>&nbsp;&nbsp;{currentStudy && currentStudy.indications}</span>
              </div>
            </div>
            <div className="col-sm-6">
              <div className="d-flex">
                <span>Study Design : </span>
                <span>&nbsp;&nbsp;{currentStudy && currentStudy.studyDesign}</span>
              </div>

              <div className="d-flex">
                <span>Investigation : </span>
                <span>&nbsp;&nbsp;{currentStudy && currentStudy.investigation}</span>
              </div>
              <div className="d-flex">
                <span>Date Format : </span>
                <span>&nbsp;&nbsp;{currentStudy && currentStudy.dateFormat}</span>
              </div>
              <div className="d-flex">
                <span>Time Format : </span>
                <span>&nbsp;&nbsp;{currentStudy && currentStudy.timeFormat}</span>
              </div>
              <div className="d-flex">
                <span>Subject Id Type: </span>
                <span>&nbsp;&nbsp;{currentStudy && currentStudy.configData && currentStudy.configData.name}</span>
              </div>
              <div className="d-flex">
                <span>Subject Id Format: </span>
                <span>&nbsp;&nbsp;{subIdFormat}</span>
              </div>
              <div className="d-flex">
                <span>Sample size : </span>
                <span>&nbsp;&nbsp;{currentStudy && currentStudy.subjectSampleSize}</span>
              </div>
              <div className="d-flex">
                <span>Visits : </span>
                <span>&nbsp;&nbsp;{currentStudy && currentStudy.visitsCount}</span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </React.Fragment>
  )
}

export default Study;