import { Study } from "./dataTypes"

export const StudyModal: Study = {
    id: 0,
    orgId: 0,
    sponsorName: "",
    protocolId: "",
    protocolTitle: "",
    startDate: "",
    endDate: "",
    totalSubEnrollCount: 0,
    subIdCreation: 0,
    subIdValidation: "",
    status: true,
    investigation: "",
    regularitory: "",
    studyDesign: "",
    studyPhase: "",
    studyType: "",
    therapeuticArea: "",
    indications: "",
    population: "",
    subIdFormat: {
        alphabet: false,
        numeric: true,
        preview: "",
        length: 0
    },
    subjectSampleSize:'',
    visitsCount:NaN,

}