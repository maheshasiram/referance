import styled from "styled-components";

export const RowContainer = styled.div` 

 font-size:13px;
 line-height:24px;
 width: 100%;
 display: flex;
 align-items: center;
 color: black;
 padding:0px;
`;

export const LabelCell = styled.div` 
 font-size:13px;
 font-weight: bolder;
 line-height:24px;
 width: 25%;
 display: block;
 padding: 5px 10px;
 align-items: center;
 height: 100% !important;

`;

export const RightLabelCell = styled.div` 
 font-size:13px;
 font-weight: bolder;
 line-height:24px;
 width: 25%;
 display: block;
 padding: 5px 10px;
 align-items: center;
 height: 100% !important;

`;


export const ValueCell = styled.div`-
font-size:13px;
font-weight:500;
line-height:24px;
width: 50%;
color: #252525;
display: block;
padding: 5px 15px;
align-items: center;
height: 100% !important;
 &:before{
    content:":";
     position:absolute;
 }
 div{
     padding-left:25px;
     word-break: break-all;
 }
`;
export const ValueSeparation = styled.div`
content:":";
`;