import { Types } from '../reducer/Types';
import { fetch } from "../../../../../constants/fetch";
import { getAllStudies, Loader } from '../../../../../actions/actions';
import { studySetup } from "../../../../../configs/enivornment/studySetup";

export const getCurrentStudyDetails: any = (payload: number,callback:any) => {
    const url = `${studySetup.study.findByStudyId}?studyId=${payload}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
            data: null,
        })
            .then((response: any) => {
                dispatch({ type: Types.GET_STUDY_DETAILS, payload: response.data })
                if(callback){
                    callback(response.data)
                    dispatch(Loader(false))
                }
            })

    }
}

// api for edit study and update study
export const saveOrUpdateStudy: any = (payload: any, callback: any) => {
    const url = studySetup.study.editStudy
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload,
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data)
                    dispatch(Loader(false))
                    dispatch(getAllStudies())
                }
            })

    }
}


