import { Types } from "./types";
import { ruleModal,rulesParams } from "../constants/rules-modals";


const initialStates = {
    rulesParams: rulesParams,
    rulesList: {},
    allForms: [],
    treeViewData: null,
    nodeElement: null,
    dependentVariableVal: null,
    actionValues: {
        message: '',
        email: '',
        subStatus: ''
    },
    validations: { target: "", logic: "",ruleName: "", message:"", ruleSubjectStatusAction: "", toEmail:"", ccEmail:"" },
    destinationTreeeData: [],
    ruleInitialData: ruleModal,
    desinationTreeView: [],
    logicContainerSelectedValue: false,
    rule: ruleModal,    // create rule payload
    ruleActionTypes: [],
    ruleActions: [],
    // treeViewData:[]
    formsList: [],
    selectedAction: '',
    selectedValue: '',
    destinationForms: 0,
    subjectStatus: null,
    ruleCondition: null,
    ruleOperator: null,
    ruleStatus: null,
    ruleType: null,
    ruleSubFieldType: null,
    ruleSubDateType: null,
    ruleSubTimeType: null,
    destinatonVists: []
}

export const rules = (state = initialStates, action: { type: any, payload: any }) => {
    switch (action.type) {

        case Types.ON_SELECTED_FORM_NAME:
            return { ...state, selectedValue: action.payload }

        //Rule Params
        case Types.GET_RULES_PARAMS:
            return { ...state, rulesParams: action.payload }

        //Fetched TableData
        case Types.GET_ALL_TABLE_DATA:
            return { ...state, rulesList: action.payload }

        //Forms List 
        case Types.GET_ALL_FORMS_FOR_RULES:
            return { ...state, formsList: action.payload }

        //All Actions List
        case Types.GET_ACTION_DATA:
            return { ...state, selectedAction: action.payload }

        case Types.GET_ALL_FORM_BY_STUDYID:
            return { ...state, allForms: action.payload }

        case Types.SET_RULE_PAYLOAD:
            return { ...state, ruleInitialData: action.payload }

        case Types.GET_TREE_VIEW_DATA:
            return { ...state, treeViewData: action.payload }

        case Types.SAVE_NODE_VALUE_FOR_RULES:
            return { ...state, nodeElement: action.payload }

        case Types.SET_VALUE_FOR_DEPENDENT_VARIABLE:
            return { ...state, dependentVariableVal: action.payload }

        case Types.LOGIC_CONTAINER_DROPDOWN_VALUE:
            return { ...state, logicContainerSelectedValue: action.payload }

        //Action DropDown Values in Create
        case Types.FETCH_RULES_ACTION_TYPE:
            return { ...state, ruleActionTypes: action.payload }
        // update rule payload
        case Types.GET_CREATE_RULE_PAYLAOD:
            return { ...state, rule: action.payload }

        case Types.RULE_ACTION_BY_DATA:
            return { ...state, ruleActions: action.payload }

        //Validation for rules action and logic
        case Types.VALIDATE_RULE:
            return { ...state, validations: action.payload }
        case Types.SELECTED_DESTINATION_FORM:
            return { ...state, destinationForms: action.payload }

        case Types.GET_VISIT_TREE_DATA:
            return { ...state, destinationTreeeData: action.payload }
        case Types.GET_SUBJECT_STATUS:
            return { ...state, subjectStatus: action.payload }
        // config for all the operators in create rule
        case Types.GET_RUL_CONDITION:
            return { ...state, ruleCondition: action.payload }
        case Types.GET_RUL_OPERATOR:
            return { ...state, ruleOperator: action.payload }
        case Types.GET_RUL_STATUS:
            return { ...state, ruleStatus: action.payload }
        case Types.GET_RUL_TYPE:
            return { ...state, ruleType: action.payload }
        case Types.GET_RUL_SUB_FIELD_TYPE:
            return { ...state, ruleSubFieldType: action.payload }
        case Types.GET_RUL_SUB_DATE_TYPE:
            return { ...state, ruleSubDateType: action.payload }
        case Types.GET_RUL_SUB_TIME_TYPE:
            return { ...state, ruleSubTimeType: action.payload }
        case Types.GET_VISIT_ASSIGNED_TOFORM:
            return { ...state, destinatonVists: action.payload }
        default:
            return { ...state }
    }
}