import _ from "lodash";
import { Loader } from "../../../../../actions/actions";
import { studySetup } from "../../../../../configs/enivornment/studySetup";
import { fetch } from "../../../../../constants/fetch";
import { Types } from "../reducer/types";

//Fetch All Table Data
export const fetchAllRulesByCriteria: any = (payload: any, callback: any) => {
    const _payload = payload
    delete _payload.first
    return function (dispatch: any) {
        fetch({
            method: 'POST',
            url: studySetup.rules.fetchAllByCriteria,
            data: _payload
        }).then((response: any) => {
            let _data = { ...{}, ...response.data }
            _data?.rules?.map((item: any) => {
                if (item.status === false) {
                    item["disable"] = true
                } else {
                    item["disable"] = false
                }
                item["checked"] = false
            })
            if (callback) { callback(_data) }
            dispatch({ type: Types.GET_ALL_TABLE_DATA, payload: _data })
            dispatch(Loader(false));
        })
    }
}

//Fetching All Forms Assigned To Rules
export const fetchAllFormsForRulesDefined: any = (payload: any) => {
    return function (dispatch: any) {
        // dispatch(Loader(true));
        fetch({
            method: "GET",
            url: `${studySetup.rules.fetchAllFormsForRulesDefined}?studyId=${payload}`,
            data: ''
        }).then((response: any) => {
            const values: any = []
            response.data.map((item: any) => {
                const _index = values.findIndex((_item: any) => item.id === _item.id)
                if (_index === -1) {
                    values.push(item)
                }
                return null
            })
            dispatch({ type: Types.GET_ALL_FORMS_FOR_RULES, payload: values })
            // dispatch(Loader(false));
        })
    }
}

export const fetchRulesByActionId: any = (payload: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: "POST",
            url: `${studySetup.rules.fetchRulesByActionId}?actionId=${payload}`,
            data: ''
        }).then((response: any) => {
            console.log("response in action", response)
        })
    }
}



//Delete Rules 
export const deleteRules: any = (payload: any, callback: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: "POST",
            url: studySetup.rules.deleteRule,
            data: payload
        }).then((response: any) => {
            if (callback) { callback(response) }
            // if (response.data.errorMessage) {
            //     dispatch(Loader(false));
            // }
        }).catch((error) => {
            dispatch(Loader(false))
            callback(error.response.data);
        })
    }
}


// api for fetch tree view
export const getTreeViewData: any = (studyId: any) => {
    const url = `${studySetup.treeViewData}?studyId=${studyId}`
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'GET',
            url: url,
            data: ''
        })
            .then((response: any) => {
                const _response = [...[], ...response.data.data];
                _response.map((item, index) => {
                    _response[index].key = index
                    if (item.children && item.children.length > 0) {
                        item.children.map((child: any, ci: any) => {
                            child && child.children && child.children.map((grpChild: any, grpChldIndex: number) => {
                                return _response[index].children[ci].children[grpChldIndex].repeatMax = child.repeatMax;
                            })
                            if (_response[index].children[ci].children) {
                                return _response[index].children[ci].key = `${index}-${ci}`;
                            }
                            return null
                        });
                    }
                    return null
                })
                const _data: any = []
                _response.map((item: any) => {
                    if (item.children.length > 0) {
                        _data.push(item)
                    }
                    return null
                })

                dispatch({ type: Types.GET_TREE_VIEW_DATA, payload: _data })
                dispatch(Loader(false));
            })
    }
}

export const saveOrUpdateRule: any = (payload: any, callback: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: "POST",
            url: studySetup.rules.saveOrUpdateRule,
            data: payload
        }).then((response: any) => {
            if (callback) { callback(response.data) }
            dispatch(Loader(false));
        }).catch((error) => {
            dispatch(Loader(false))
            callback(error.response.data);
        })
    }
}

export const VisitFormTreeView: any = (studyId: any, rule: any,callback: any) => {
    const url = `${studySetup.rules.fetchVisitFormTreeViewByStudyId}?studyId=${studyId}`
    return (dispatch: any) => {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
        })
            .then((response: any) => {
                const _response = [...[], ...response.data.data];
                _response.map((item, index) => {
                    _response[index].key = index
                    if (item.children && item.children.length > 0) {
                        item.children.map((child: any, ci: any) => {
                            child && child.children && child.children.map((grpChild: any, grpChldIndex: number) => {
                                return _response[index].children[ci].children[grpChldIndex].repeatMax = child.repeatMax;
                            })
                            if (_response[index].children[ci].children) {
                                return _response[index].children[ci].key = `${index}-${ci}`;
                            }
                            return null
                        });
                    }
                    return null
                })
                const _data: any = []
                _response.map((item: any) => {
                    if (item.children.length > 0) {
                        _data.push(item)
                    }
                    return null
                })
                const _destinationTree = _.cloneDeep(_data)
                if (rule?.ruleFormActions?.length > 0) {
                    rule?.ruleFormActions?.map((item: any) => {
                        _data.map((treeItem: any, treeIndex: number) => {
                            if (treeItem.visitId === item.visitId) {
                                treeItem?.children?.map((child: any, childIndex: number) => {
                                    item?.formIds?.map((formId: any) => {
                                        if (child.id === formId) {
                                            _destinationTree[treeIndex].children[childIndex].selected = true
                                        } else {
                                            _destinationTree[treeIndex].children[childIndex].selected = false
                                        }
                                        return null;
                                    })
                                    return null;
                                })
                            }
                            return null;
                        })
                        return null;
                    })
                } else {
                    _data.map((treeItem: any, treeIndex: number) => {
                        treeItem?.children?.map((child: any, childIndex: number) => {
                            _destinationTree[treeIndex].children[childIndex].selected = false
                            return null;
                        })
                        return null;
                    })
                }
                if (callback) { callback(response.data.data) }
                dispatch({ type: Types.GET_VISIT_TREE_DATA, payload: _destinationTree })
                dispatch(Loader(false));
            })

    }
}

export const fetchVisitsAssignedToForm: any = (payload: any, rule: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: "GET",
            url: `${studySetup.visits.fetchVisitsAssignedToFormByStudyId}?studyId=${payload}`,
            data: ''
        }).then((response: any) => {
            const _data = [...[], ...response.data]
            if (rule?.ruleVisitAction?.visitIds?.length > 0) {
                rule?.ruleVisitAction?.visitIds?.map((item: any) => {
                    response.data?.map((treeItem: any, treeIndex: number) => {
                        if (item === treeItem.id) {
                            _data[treeIndex].status = true
                        }
                        return null;
                    })
                    return null;
                })
            } else {
                response.data?.map((treeItem: any, treeIndex: number) => {
                    _data[treeIndex].status = false
                    return null;
                })
            }

            dispatch({ type: Types.GET_VISIT_ASSIGNED_TOFORM, payload: _data })
            dispatch(Loader(false));
        })
    }
}

export const editRuleByRuleId: any = (ruleId: number, callback: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: "GET",
            url: `${studySetup.rules.editRule}?ruleId=${ruleId}`,
            data: ''
        }).then((response: any) => {
            if (callback) {
                callback(response.data)
            }
            dispatch(Loader(false));
        })
    }
}

export const deleteAndRestoreRule: Function = (payload: any, callback: any) => {
    return function (dispatch: any) {
        fetch({
            method: "POST",
            url: `${studySetup.rules.deleteAndRestoreRule}`,
            data: payload
        }).then((response: any) => {
            if (callback) {
                callback(response.data)
            }
        })
    }
}