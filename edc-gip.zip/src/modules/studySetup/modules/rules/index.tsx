import React, { useEffect } from "react";
import { useDispatch} from "react-redux";
import { fetchAllRulesByCriteria } from "./actions/actions";
import { components, rulesParams } from "./constants/rules-modals";
import { Types } from "./reducer/types";

function RulesModule() {

    const dispatch = useDispatch();

    useEffect(() => {
        return () => {
            dispatch({ type: Types.GET_RULES_PARAMS, payload: rulesParams })
            dispatch(fetchAllRulesByCriteria(rulesParams))
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    return (
        <React.Fragment>
            <React.Suspense  >
                <components.Main />
            </React.Suspense>
        </React.Fragment>
    )
}

export default RulesModule;