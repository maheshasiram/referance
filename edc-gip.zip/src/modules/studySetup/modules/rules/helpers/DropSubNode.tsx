import React from "react";

function DropSubNode(props: any) {
    return (
        <div
            className={`dropSubNode-Container ${props.className}`}
            onDragOver={(e: any) => { e.preventDefault() }}
            onDrop = {props.onDropSubNode}
        >
            <p>{props.content}</p>
        </div>
    )
}
export default DropSubNode