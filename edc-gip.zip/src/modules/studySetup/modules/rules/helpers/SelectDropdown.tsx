import React from "react";

function SelectDropdown(props: any) {
    return (
        <React.Fragment>
            <select
                className={`${props.className} selectSSA mx-2`}
                id={props.id}
                onChange={props.onChange}
                disabled={props.disabled}
                value={props.value}
            >
                {props.defaultOption && <option value='' >{props.defaultOption}</option>}
                {props.options && props.options.map((item:any,index:any) => {
                    return <option value={item.value} key={index}
                        >{item.label}</option>
                })}
            </select>
        </React.Fragment>
    )
}
export default SelectDropdown