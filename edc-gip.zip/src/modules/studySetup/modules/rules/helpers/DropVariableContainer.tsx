import React from "react";

function DropVariableContainer(props: any) {
    return (
        <div
            className={`dropVariable-Container ${props.className}`}
            onDragOver={(e: any) => { e.preventDefault() }}
            onDrop={props.onDropHandler}
        >
            <span className="m-0 text-center p-2">Drag a variable here</span>
        </div>
    )
}
export default DropVariableContainer