import React from "react";
import { params, ruleType } from "./dataTypes";

export const rulesParams: params = {
    "formId": null,
    "actionId": null,
    "ruleName": "",
    "limit": 10,
    "offset": 0,
    "first": 0,
    "status": true
}

export const rulePayload: ruleType = {
    "id": 0,
    "configAction": {
        "id": 0,
        "name": "",
        "code": "",
        "description": "",
        "configDataType": {
            "id": 0,
            "name": "",
            "code": "",
            "description": ""
        }
    },
    "ruleName": "",
    "message": "",
    "logic": {
        "itemsList": [

        ],
        "condition": ""
    },
    "status": true,
    "dependentFormFieldId": 0,
    "toEmail": "",
    "fromEmail": "",
    "ccEmail": "",
    "bccEmail": "",
    "configSubjectStatusId": '',
    "dependentVisits": [],
    "destinationForms": []
}

export const components = {
    Main: React.lazy(() => import("../components/rulesDashboard/RuleActions"))
}

export const ruleModal = {
    "id": 0,
    "actionType": null,
    "ruleName": "",
    "message": "",
    "status": true,
    "hardDeleteStatus": true,
    "targetField": null,
    "ruleLogic": {
        "queryGrids": []
    },
    "ruleEmailAction": {
        id: 0,
        toEmail: '',
        ccEmail: ''
    },
    "ruleFormActions": null,
    "ruleSubjectStatusAction": null,
    "ruleVisitAction": null
}
