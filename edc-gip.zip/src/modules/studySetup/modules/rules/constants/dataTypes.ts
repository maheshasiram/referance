export type ruleExpression = {
    "itemsList": Array<[]>,
    "condition": string
}

export type params = {
    "limit": number,
    "offset": number,
    "formId": any,
    "actionId": any,
    "ruleName": string
    "first": number,
    "status": boolean
}

export type ruleType = {
    "id": number,
    "configAction":  {
        "id": number,
        "name": string,
        "code": string,
        "description": string,
        "configDataType": {
            "id": number,
            "name": string,
            "code": string,
            "description": string
        }
    },
    "ruleName": string,
    "message": string,
    "logic": any,
    "status": true,
    "dependentFormFieldId": number,
    "toEmail": string,
    "fromEmail": string,
    "ccEmail": string,
    "bccEmail": string,
    "configSubjectStatusId": any,
    "dependentVisits": any,
    "destinationForms": any
}