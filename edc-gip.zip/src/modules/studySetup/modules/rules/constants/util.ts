import _ from "lodash";
import { Types } from "../reducer/types";
import store from "../../../../../store/store";
import { editRuleByRuleId } from "../actions/actions";
export const bulkOptionsData: any = ['All', 'Saved', 'Completed']

const _configCodes: any = store.getState().application.configCodes;
export const extractOptions = (items: any) => {
    // console.log('visitsList...9...', items.length >1  && groupId)
    const options: any = []
    // if (items.length > 1 /*&& groupId*/) {
    //     options.push({
    //         value: 'all',
    //         label: "All Visits"
    //     })
    // }
    items?.map((item: any) => {
        const option = {
            label: item.visitName,
            value: item.id
        }
        options.push(option)
        return null;
    });
    console.log('options.24....', items)
    return options
}

export const extractRowCountOption = (count: number) => {
    const options: any = []
    // if (count > 1 && type ==0) {
    //     options.push({
    //         value: 'all',
    //         label: "All Rows"
    //     })
    // }
    for (let i = 1; i <= count; i++) {
        options.push({
            value: i,
            label: i
        })
    }
    return options
}

export const responseOptions = (items: any) => {
    const options: any = []
    items != null && items.map((item: any) => {
        const option = {
            label: item.response,
            value: item.response
        }
        options.push(option)
        return null;
    });
    return options
}



export const onDropLogicVariable: any = (rule: any, nodeElement: any) => {
    return (dispatch: any) => {
        const _rule = _.cloneDeep(rule)
        const ruleStore = store.getState().rules;
        // ondropGridNumber = ondropGridNumber +1;
        console.log('nodeElement........11', nodeElement, ruleStore.ruleSubFieldType, _rule, rule?.ruleLogic?.queryGrids.length);
        const _condition = ruleStore?.ruleCondition?.find((i: any) => i.code === _configCodes?.AND)
        const _queryGrids: any = { "gridNumber": 1, "ruleFields": [], "condition": _condition, id: 0 }
        rule.ruleLogic?.queryGrids?.map((item: any, index: any) => {
            _queryGrids.gridNumber = index + 2
            return null
        })
        const _valueSubFieldId = ruleStore.ruleSubFieldType?.find((i: any) => i.code === _configCodes?.Value)
        console.log("_configCodes?.AND", _configCodes, _configCodes?.AND, ruleStore.ruleSubFieldType)
        const _target = {
            "id": 0,
            "fieldId": nodeElement.id,
            "fieldName": nodeElement.variableId,
            "formId": nodeElement.formId,
            "visitIds": [],
            "targetFieldGroup": nodeElement.groupId ? {
                "targetGroupId": nodeElement.groupId,
                "targetGroupName": "",
                "targetGroupRows": []
            } : null,
            "visits": nodeElement.visits,
            "repeatMax": nodeElement.groupId ? nodeElement.repeatMax : null
        }
        const _logic: any = {
            "id": null,
            "fieldId": nodeElement.id,
            "formId": nodeElement.formId,
            "fieldName": nodeElement.variableId,
            "visitIds": [],
            "datatype": nodeElement.datatype,
            "responseType": nodeElement.responseType,
            "visits": nodeElement.visits,
            "fieldGroup": nodeElement.groupId ? {
                "groupId": nodeElement.groupId,
                "groupName": "",
                "groupRows": []
            } : null,
            "configOperatorId": 0,
            "configRuleTypeId": _valueSubFieldId?.id,
            "ruleTypeValue": "",
            "ruleTypeField": null,
            "fieldOrdinal": 1,
            "configConditionId": _condition?.id,
            "condition": _condition,
            "responseOptions": nodeElement.responseOptions,
            "repeatMax": nodeElement.groupId ? nodeElement.repeatMax : null
        }

        _queryGrids?.ruleFields?.push(_logic)
        _rule.ruleLogic?.queryGrids?.push(_queryGrids)
        if (_rule?.actionType?.code !== _configCodes?.QueryAction) {
            _rule.targetField = _target
        }

        console.log('query grids........', _queryGrids, rule, _rule);
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
    }
}

export const extractResponseOption: any = (val: any) => {
    const options: any = []
    val.map((i: any) => {
        const option = {
            label: i.response,
            value: i.response
        }
        options.push(option)
        return null;
    });
    return options
}

export const dependentTabs = [
    { id: 0, label: 'Dependent variable / Logic' },
    { id: 1, label: 'Destination' }
]
export const dateOptions = [{
    label: 'Current Date',
    value: '_CURRENT_DATE'
},
{
    label: 'Other',
    value: 'other'
}]

export const timeOptions = [{
    label: 'Current Time',
    value: '_CURRENT_TIME'
},
{
    label: 'Other',
    value: 'other'
}]

export const extractStrExpressions = (expressions: any) => {
    const _string = expressions?.filter((item: any) => (item.code === "RUL_OPERATOR_=" || item.code === "RUL_OPERATOR_!="))
    return _string.map((item: any) => ({
        label: item.name,
        value: item.id
    }))
}

export const extractDateTimeExpression = (expressions: any) => {
    const _expression = expressions?.filter((item: any) => (item.code === "RUL_OPERATOR_+" || item.code === "RUL_OPERATOR_-"))
    return _expression.map((item: any) => ({
        label: item.name,
        value: item.id
    }))
}
export const extractExpressions = (expressions: any) => {
    const _expression = expressions?.filter((item: any) => (item.code !== "RUL_OPERATOR_+" && item.code !== "RUL_OPERATOR_-"))
    return _expression.map((item: any) => ({
        label: item.name,
        value: item.id
    }))
}

export const extractSubField = (list: any) => {
    return list?.map((item: any) => ({
        "label": item.name,
        "value": item.id
    }))
}


export const onActionTypeHandler = (_configObj: any, ruleModal: any) => {
    const _payload = { ...{}, ...ruleModal }
    _payload.ruleName = ""
    _payload.actionType = _configObj ? _configObj : ruleModal.actionType
    // if (_configObj.code === "RUL_ACT_TYP_EMAIL_ACTION") {
    _payload.ruleEmailAction = {
        "id": 0,
        "toEmail": "",
        "ccEmail": ""
    }
    // }
    // console.log("189....",_configObj)
    if (_configObj?.code === _configCodes?.FormAction) {
        _payload.ruleFormActions = [];
    }
    else if (_configObj?.code === _configCodes?.VisitAction) {
        _payload.ruleVisitAction = {
            "visitIds": []
        };
    }
    else if (_configObj?.code === _configCodes?.SubjectStatusAction) {
        _payload.ruleSubjectStatusAction = {
            "id": 0,
            "subjectStatus": {}
        }
    }
    return _payload
}

export const onVisitChangeHandler = (e: any, index: number, itemIndex: number, rule: any, validations: any, dispatch: any) => {
    const _rule = _.cloneDeep(rule);
    _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].visitIds = e
    dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule });
    dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: "" } })
}

export const editPayload = (dispatch: any, rule: any, params: any, treeViewData: any) => {
    if (parseInt(params.id) > 0 && treeViewData) {
        console.log("vhsdfjkn")
        dispatch(editRuleByRuleId(parseInt(params.id), (response: any) => {
            // dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: response })
            const payload = { ...{}, ...response }
            const _targetFields = payload.targetField
            const _ruleLogic = payload.ruleLogic
            console.log("_targetFields...", _targetFields, treeViewData)

            treeViewData?.map((node: any) => {
                node?.children?.map((nodee: any) => {
                    if (nodee.children) {
                        nodee?.children?.map((nodeee: any) => {
                            if (nodeee.id === payload?.targetField?.fieldId) {
                                console.log("inside children")
                                payload.targetField.visits = nodeee.visits
                                payload.targetField.repeatMax = nodeee.repeatMax

                                let _targetGroupRows: any = []
                                response.targetField.targetFieldGroup.targetGroupRows.map((item: any) => {
                                    console.log("271..", item)
                                    // if (_targetGroupRows.indexOf(item) === -1) {
                                    _targetGroupRows.push({ "value": item, "label": item })
                                    // }
                                })
                                payload.targetField.targetFieldGroup.targetGroupRows = _targetGroupRows
                                console.log("_rows...", _targetGroupRows)

                                const _visitIds: any = []
                                response.targetField?.visitIds?.map((item: any) => {
                                    response.targetField?.visits?.map((visit: any) => {
                                        if (item === visit.id) {
                                            _visitIds.push({ "value": visit.id, "label": visit.visitName })
                                        }
                                    })
                                })
                                payload.targetField.visitIds = _visitIds
                            }
                        })
                    } else {
                        // console.log("...271", nodee.id, payload)
                        if (nodee.id === response?.targetField?.fieldId) {
                            payload.targetField.visits = nodee.visits
                            payload.targetField.repeatMax = null
                            const _visitIds: any = []
                            response?.targetField?.visitIds.map((item: any) => {
                                response?.targetField?.visits.map((visit: any) => {
                                    if (item === visit.id) {
                                        _visitIds.push({ "value": visit.id, "label": visit.visitName })
                                    }
                                })
                            })
                            payload.targetField.visitIds = _visitIds
                        }
                    }
                    return null
                })
                return null
            })


            // rule logic
            // const _ruleFieldVists: any = []
            response?.ruleLogic?.queryGrids?.map((queryGrid: any, gridIndex: number) => {
                queryGrid?.ruleFields?.map((ruleField: any, fieldIndex: number) => {
                    treeViewData?.map((node: any) => (
                        node?.children.map((nodee: any) => {
                            if (nodee.children) {
                                console.warn("inside children")
                                nodee.children.map((nodeee: any) => {
                                    if (nodeee.id === ruleField.fieldId) {
                                        console.log("334")
                                        payload.ruleLogic.queryGrids[gridIndex].ruleFields[fieldIndex] = {
                                            ...ruleField,
                                            visits: nodeee.visits,
                                            datatype: nodeee.datatype,
                                            responseType: nodeee.responseType,
                                            responseOptions: nodeee.responseOptions,
                                            repeatMax: nodeee.groupId ? nodeee.repeatMax : null
                                        }
                                        const _visitIds: any = []
                                        response.ruleLogic?.queryGrids[gridIndex]?.ruleFields[fieldIndex].visitIds.map((item: any) => {
                                            response.ruleLogic?.queryGrids[gridIndex]?.ruleFields[fieldIndex].visits.map((visit: any) => {
                                                if (item === visit.id) {
                                                    _visitIds.push({ "value": visit.id, "label": visit.visitName })
                                                }
                                            })
                                        })
                                        console.log("_visitIds", _visitIds)
                                        payload.ruleLogic.queryGrids[gridIndex].ruleFields[fieldIndex].visitIds = _visitIds

                                        const _groupRows: any = []
                                        response?.ruleLogic?.queryGrids[gridIndex]?.ruleFields[fieldIndex]?.fieldGroup?.groupRows?.map((item: any) => {
                                            // if (_groupRows.indexOf(item) === -1) {
                                            _groupRows.push({ "value": item, "label": item })
                                            // }
                                        })
                                        payload.ruleLogic.queryGrids[gridIndex].ruleFields[fieldIndex].fieldGroup.groupRows = _groupRows
                                    }

                                    if (nodeee.id === ruleField?.ruleTypeField?.fieldId) {
                                        console.log("354.....", nodeee)
                                        payload.ruleLogic.queryGrids[gridIndex].ruleFields[fieldIndex].ruleTypeField.visits = nodeee.visits
                                        payload.ruleLogic.queryGrids[gridIndex].ruleFields[fieldIndex].ruleTypeField.repeatMax = nodeee.groupId ? nodeee.repeatMax : null

                                        const _ruleTypeFieldVisitIds: any = []
                                        response.ruleLogic?.queryGrids[gridIndex]?.ruleFields[fieldIndex]?.ruleTypeField.visitIds?.map((item: any) => {
                                            response.ruleLogic?.queryGrids[gridIndex]?.ruleFields[fieldIndex]?.ruleTypeField.visits?.map((visit: any) => {
                                                if (item === visit.id) {
                                                    _ruleTypeFieldVisitIds.push({ "value": visit.id, "label": visit.visitName })
                                                }
                                            })
                                        })
                                        payload.ruleLogic.queryGrids[gridIndex].ruleFields[fieldIndex].ruleTypeField.visitIds = _ruleTypeFieldVisitIds
                                        response?.ruleLogic?.queryGrids[gridIndex]?.ruleFields[fieldIndex]?.ruleTypeField?.fieldGroup?.groupRows?.map((item: any) => {
                                            payload.ruleLogic.queryGrids[gridIndex].ruleFields[fieldIndex].ruleTypeField.fieldGroup.groupRows = []
                                            if (_ruleTypeFieldgroupRows.indexOf(item) !== -1) {
                                                payload.ruleLogic.queryGrids[gridIndex].ruleFields[fieldIndex].ruleTypeField.fieldGroup.groupRows.push({ "value": item, "label": item })
                                            }
                                            return null

                                        })

                                        const _ruleTypeFieldgroupRows: any = []
                                        response?.ruleLogic?.queryGrids[gridIndex]?.ruleFields[fieldIndex]?.ruleTypeField?.fieldGroup?.groupRows?.map((item: any) => {
                                            // if (_groupRows.indexOf(item) === -1) {
                                            _ruleTypeFieldgroupRows.push({ "value": item, "label": item })
                                            // }
                                        })
                                        payload.ruleLogic.queryGrids[gridIndex].ruleFields[fieldIndex].ruleTypeField.fieldGroup.groupRows = _ruleTypeFieldgroupRows
                                        return null
                                    }
                                    return null
                                })

                            } else {
                                if (nodee.id === ruleField.fieldId) {
                                    payload.ruleLogic.queryGrids[gridIndex].ruleFields[fieldIndex] = {
                                        ...ruleField,
                                        visits: nodee.visits,
                                        datatype: nodee.datatype,
                                        responseType: nodee.responseType,
                                        responseOptions: nodee.responseOptions,
                                        repeatMax: nodee.groupId ? nodee.repeatMax : null
                                    }
                                    const _visitIds: any = []
                                    response.ruleLogic?.queryGrids[gridIndex]?.ruleFields[fieldIndex].visitIds.map((item: any) => {
                                        response.ruleLogic?.queryGrids[gridIndex]?.ruleFields[fieldIndex].visits.map((visit: any) => {
                                            if (item === visit.id) {
                                                _visitIds.push({ "value": visit.id, "label": visit.visitName })
                                            }
                                        })
                                    })
                                    payload.ruleLogic.queryGrids[gridIndex].ruleFields[fieldIndex].visitIds = _visitIds
                                    console.log("equal nodee..", nodee.visits)
                                }
                            }
                            return null
                        })
                    ))
                    return null
                })
                return null
            })
            console.log("_findVist", _ruleLogic)

            console.log("_ruleFieldVists...", treeViewData, payload)
            dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: payload })
            // return payload
        }))
    }
}
