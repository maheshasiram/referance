import { Alert } from "../../../../../actions/actions";
import { Types } from "../reducer/types";
import store from "../../../../../store/store";

const _configCodes: any = store.getState().application.configCodes;
export const validateRule = (rule: any, dispatch: any, validations: any, destinatonVists: any, ruleSubFieldType: any) => {
    let validate;
    const _validateDependent = rule?.targetField?.visitIds.length <= 0
    const _validateRowCount = rule?.targetField?.targetFieldGroup?.targetGroupRows.length <= 0
    if ((rule?.ruleName === '' || rule?.message === '') ||
        (rule?.actionType?.code === _configCodes?.EmailAction && rule?.ruleEmailAction.toEmail === '') ||
        (rule?.actionType?.code === _configCodes?.SubjectStatusAction && rule?.ruleSubjectStatusAction === '')) {
        if (rule?.actionType?.code === _configCodes?.EmailAction && rule?.ruleEmailAction.toEmail === '') {
            if (rule?.message === '' && rule?.ruleName === '') {
                dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, ruleName: "Please enter rule name", message: "Please enter message", toEmail: "Please enter mail" } })
            }
            else if (rule?.ruleName === '') {
                dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, ruleName: "Please enter rule name", toEmail: "Please enter mail" } })
            }
            else if (rule?.message === '') {
                dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, message: "Please enter message", toEmail: "Please enter mail" } })
            }
            else {
                dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, toEmail: "Please enter mail" } })
                // return true;
            }
        }
        else if (rule?.actionType?.code === _configCodes?.SubjectStatusAction && !rule?.ruleSubjectStatusAction) {
            if (rule?.message === '' && rule?.ruleName === '') {
                dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, ruleName: "Please enter rule name", message: "Please enter message", ruleSubjectStatusAction: "Please select subject status" } })
            }
            else if (rule?.ruleName === '') {
                dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, ruleName: "Please enter rule name", ruleSubjectStatusAction: "Please select subject status" } })
            }
            else if (rule?.message === '') {
                dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, message: "Please enter message", ruleSubjectStatusAction: "Please select subject status" } })
            }
            else {
                dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, ruleSubjectStatusAction: "Please select subject status" } })
                // return true;
            }
        }
        else if (rule?.ruleName === '' && rule?.message === '') {
            dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, ruleName: "Please enter rule name", message: "Please enter message" } })
        }
        else if (rule?.ruleName === '') {
            dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, ruleName: "Please enter rule name" } })
        }
        else if (rule?.message === '') {
            dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, message: "Please enter message" } })
        }
        else {
            dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, ruleName: "", message: "", ruleSubjectStatusAction: "", toEmail: "" } })
            // return true;
        }
    }
    else if (/*rule?.targetField?.fieldId && !_validateDependent && !_validateRowCount &&*/ rule?.ruleLogic?.queryGrids.length > 0) {
        if (validations && validations.target === '' /*&& validations.logic == ''*/) {
            if (rule?.actionType?.code === _configCodes?.QueryAction) {
                validate = validateQueryDefinition(_validateDependent, _validateRowCount, validations, rule, dispatch, ruleSubFieldType)
            }
            else if (rule?.actionType?.code === _configCodes?.FormAction || rule?.actionType?.code === _configCodes?.VisitAction) {

                validate = validateFormAction(_validateDependent, _validateRowCount, destinatonVists, validations, rule, dispatch)
            }
            else if (rule?.actionType?.code === _configCodes?.EmailAction) {
                validate = validateEmailAction(_validateDependent, _validateRowCount, validations, rule, dispatch)
            }
            else if (rule?.actionType?.code === _configCodes?.SubjectStatusAction) {
                validate = validateSubjectStatusAction(_validateDependent, _validateRowCount, validations, rule, dispatch)
            }
        }
    } else {
        if (rule?.actionType?.code === _configCodes?.QueryAction && !_validateDependent && !_validateRowCount) {
            dispatch({
                type: Types.VALIDATE_RULE, payload: {
                    ...validations,
                    target: (!rule?.targetField) ? 'Please drag a target variable' :
                        _validateDependent ? 'Please select visit in target variable' :
                            _validateRowCount ? 'Please select row count in target variable'
                                : '',
                    logic: rule?.ruleLogic?.queryGrids.length <= 0 ? "Please drag a variable in Logic" : ''
                }
            })
        }
        else {
            dispatch({
                type: Types.VALIDATE_RULE, payload: {
                    ...validations, logic: rule?.ruleLogic?.queryGrids.length <= 0 ? "Please drag a variable in Logic" : ''
                }
            })
        }
    }
    return validate
}

const validateFormAction = (_validateDependent: any, _validateRowCount: any, destinatonVists: any, validations: any, rule: any, dispatch: any) => {
    let validateLogic = false;
    // let _validateDestination = false;
    const _validateValue: any = null;
    rule?.ruleLogic?.queryGrids?.map((queryGrid: any) => {
        queryGrid?.ruleFields?.map((ruleField: any) => {
            if (ruleField?.visitIds.length <= 0 || ruleField?.fieldGroup?.groupRows?.length <= 0 || ruleField?.configOperatorId === 0 || ruleField?.ruleTypeValue === "") {
                validateLogic = true
            }
            else {
                const selectedVisits = destinatonVists?.filter((visits: any) => visits?.status === true)
                if (rule?.actionType?.code === _configCodes?.FormAction && rule?.ruleFormActions.length <= 0) {
                    validateLogic = true
                    // _validateDestination = true
                    dispatch(Alert({
                        status: 0, message: "Forms are not selected in destination field.Please click on destination tab and select forms",
                        onOk: () => { return null }
                    }));
                }
                else if (rule?.actionType?.code === _configCodes?.VisitAction && selectedVisits.length <= 0) {
                    validateLogic = true
                    // _validateDestination = true
                    dispatch(Alert({
                        status: 0, message: "Visits are not selected in destination field.Please click on destination tab and select visits",
                        onOk: () => { return null }
                    }));
                }
            }
            return null
        }
        )
        return null
    })
    if (validateLogic) {
        dispatch({
            type: Types.VALIDATE_RULE,
            payload: {
                ...validations, logic: _validateValue ? _validateValue : validateLogic ? "Invalid logic,please give valid logic" : ''
            }
        })
        return false
    }
    else {
        dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: "", ruleName: "", message: '' } })
        return true
    }
}

const validateQueryDefinition = (_validateDependent: any, _validateRowCount: any, validations: any, rule: any, dispatch: any, ruleSubFieldType: any) => {
    let validateLogic = false
    let _validateValue: any = null
    rule?.ruleLogic?.queryGrids?.map((queryGrid: any) => {
        queryGrid?.ruleFields?.map((ruleField: any) => {
            const subFieldType = (ruleField?.datatype?.code === _configCodes?.integer || ruleField?.datatype?.code ===  _configCodes?.real) && (ruleSubFieldType.find((item: any) => item.id === parseInt(ruleField?.configRuleTypeId)))?.code
            if (ruleField?.visitIds.length <= 0 || ruleField?.fieldGroup?.groupRows?.length <= 0 || ruleField?.configOperatorId === 0 /*|| (ruleField?.datatype?.code !== _configCodes?.file && ruleField?.datatype?.code !== _configCodes?.date && ruleField?.ruleTypeValue === "" && subFieldType !== _configCodes?.Field)*/) {
                validateLogic = true
            }
            else if (!(ruleField?.responseOptions?.length > 0) && (subFieldType !== _configCodes?.Field)) {
                if (ruleField?.datatype?.code === _configCodes?.integer && ruleField?.ruleTypeValue?.trim() !== '' && !(/(?<![.\d])\d+(?![.\d])/.test(ruleField?.ruleTypeValue))) {
                    validateLogic = true
                    _validateValue = `${ruleField?.fieldName} , Please enter real numbers as 12, 5`
                } else if (ruleField?.datatype?.code === _configCodes?.real && (ruleField?.ruleTypeValue?.trim() !== '') && !(/^[\d]+(\.)[\d]{1,6}$/.test(ruleField?.ruleTypeValue))) {
                    validateLogic = true
                    _validateValue = `${ruleField?.fieldName} , Please enter real numbers as 12.5, 5.2`
                }
            }
            else if (!(ruleField?.responseOptions?.length > 0) && (subFieldType === _configCodes?.Field)) {
                if (!ruleField?.ruleTypeField) {
                    validateLogic = true
                    _validateValue = `Drag ${ruleField?.datatype?.name} field`
                }
                else if (ruleField?.ruleTypeField) {
                    if (ruleField?.ruleTypeField?.visitIds?.length === 0) {
                        validateLogic = true
                        _validateValue = `Select ${ruleField?.ruleTypeField?.fieldName} visit`
                    }
                }
            }
            return null
        })
        return null
    })
    if (validateLogic || _validateDependent || _validateRowCount) {
        dispatch({
            type: Types.VALIDATE_RULE,
            payload: {
                ...validations,
                target: _validateDependent ? 'Please select visit in dependent variable' : _validateRowCount ? "please select row count in dependent variable" : '',
                logic: _validateValue ? _validateValue : validateLogic ? "Invalid logic,please give valid logic" : ''
            }
        })
        return false
    }
    else {
        dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: "" } })
        return true
    }
}

const validateEmailAction = (_validateDependent: any, _validateRowCount: any, validations: any, rule: any, dispatch: any) => {
    let validateLogic = false;
    const _validateValue: any = null;
    rule?.ruleLogic?.queryGrids?.map((queryGrid: any) => {
        queryGrid?.ruleFields?.map((ruleField: any) => {
            if (ruleField?.visitIds.length <= 0 || ruleField?.fieldGroup?.groupRows?.length <= 0 || ruleField?.configOperatorId === 0 || ruleField?.ruleTypeValue === "") {
                validateLogic = true
            }
            return null
        }
        )
        return null
    })
    if (validateLogic) {
        dispatch({
            type: Types.VALIDATE_RULE,
            payload: {
                ...validations, logic: _validateValue ? _validateValue : validateLogic ? "Invalid logic,please give valid logic" : ''
            }
        })
        return false
    }
    else {
        dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: "", ruleName: "", message: '' } })
        return true
    }
}

const validateSubjectStatusAction = (_validateDependent: any, _validateRowCount: any, validations: any, rule: any, dispatch: any) => {
    let validateLogic = false;
    const _validateValue: any = null;

    rule?.ruleLogic?.queryGrids?.map((queryGrid: any) => {
        queryGrid?.ruleFields?.map((ruleField: any) => {
            if (ruleField?.visitIds.length <= 0 || ruleField?.fieldGroup?.groupRows?.length <= 0 || (ruleField?.configOperatorId === 0 || !ruleField?.configOperatorId) || ruleField?.ruleTypeValue === "") {
                validateLogic = true
            }
            return null
        }
        )
        return null
    })
    if (validateLogic) {
        dispatch({
            type: Types.VALIDATE_RULE,
            payload: {
                ...validations, logic: _validateValue ? _validateValue : validateLogic ? "Invalid logic,please give valid logic" : ''
            }
        })
        return false
    }
    else {
        dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: "", ruleName: "", message: '' } })
        return true
    }
}