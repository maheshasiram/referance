import React from "react";
import _ from "lodash";
import DropVariableContainer from "../../../../helpers/DropVariableContainer";
import { extractExpressions, extractOptions, extractResponseOption, extractRowCountOption, extractStrExpressions, onDropLogicVariable, onVisitChangeHandler } from "../../../../constants/util";
import { useDispatch, useSelector } from "react-redux";
import SelectDropdown from "../../../../helpers/SelectDropdown";
import CancelIcon from '@mui/icons-material/Cancel';
import { Types } from "../../../../reducer/types";
import SelectField from "../../../../../../../../common/selectField/SelectField";

function FormActionLogic() {
    const dispatch = useDispatch()
    const { rule, nodeElement, validations, ruleCondition, ruleOperator } = useSelector((state: any) => state.rules);

    const oneExpressionChange = (e: any, index: number, itemIndex: number) => {
        const _rule = _.cloneDeep(rule)
        _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].configOperatorId = parseInt(e.target.value)
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
    }
    const onValueChangeHandler = (e: any, index: number, itemIndex: number) => {
        const _rule = _.cloneDeep(rule)
        _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].ruleTypeValue = e.target.value
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
    }
    const onRowCountChange = (e: any, index: number, itemIndex: number) => {
        const _rule = _.cloneDeep(rule)
        _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].fieldGroup.groupRows = e
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
    }

    const onRemoveItemListHandler = (index: any) => {
        const _rule = _.cloneDeep(rule)
        _rule.ruleLogic.queryGrids.splice(index, 1)
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
        dispatch({ type: Types.VALIDATE_RULE, payload: { target: "", logic: "" } })
    }

    const onItemListConditionChange = (event: any, index: number) => {
        const _rule = _.cloneDeep(rule)
        const _condition = ruleCondition?.find((i: any) => i.id === parseInt(event.target.value))
        _rule.ruleLogic.queryGrids[index].condition = _condition
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
    }
    const onItemConditionChange = (e: any, index: number, itemIndex: number) => {
        const _rule = _.cloneDeep(rule)
        _rule.logic.itemsList[index].items[itemIndex].condition = e.target.value
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
    }
    return (
        <React.Fragment>
            <div className='py-2'>
                Logic: <span className="text-danger ">{validations.logic}</span>
            </div>
            <div className="droped-elements">
                <div className="">
                    {rule && rule.ruleLogic && rule.ruleLogic.queryGrids.length > 0 && rule.ruleLogic.queryGrids.map((itemList: any, index: number) => (
                        <React.Fragment key={index}>
                            <div key={index} className="itemList-Container">
                                {
                                    itemList.ruleFields.map((item: any, itemIndex: number) => {
                                        return (
                                            <>
                                                {item.fieldName}
                                                <SelectField
                                                    id={item.fieldId}
                                                    className={'QDselect-visits'}
                                                    isDisabled={false}
                                                    isClearable={true}
                                                    isMulti={true}
                                                    value={item.visitIds}
                                                    onChange={(e: any) => onVisitChangeHandler(e, index, itemIndex, rule, validations, dispatch)}
                                                    options={extractOptions(item.visits)}
                                                />
                                                {item.fieldGroup?.groupId && <SelectField
                                                    id={item.fieldId}
                                                    className={'QDrowCount-Select'}
                                                    isDisabled={false}
                                                    isClearable={true}
                                                    isMulti={true}
                                                    value={item.fieldGroup.groupRows}
                                                    onChange={(e: any) => onRowCountChange(e, index, itemIndex)}
                                                    options={extractRowCountOption(item.repeatMax)}
                                                    placeholder='Select Row Count'
                                                />}
                                                <SelectDropdown
                                                    className={`dependentvar-visits`}
                                                    id={''}
                                                    onChange={(e: any) => oneExpressionChange(e, index, itemIndex)}
                                                    disabled={false}
                                                    value={item.configOperatorId}
                                                    defaultOption={'Select Expression'}
                                                    options={item?.datatype?.name === "string" ? extractStrExpressions(ruleOperator) : extractExpressions(ruleOperator)}
                                                />
                                                {item.responseOptions && item.responseOptions?.length > 0 && <SelectDropdown
                                                    className={`dependentvar-visits`}
                                                    id={''}
                                                    onChange={(e: any) => onValueChangeHandler(e, index, itemIndex)}
                                                    disabled={false}
                                                    value={item.ruleTypeValue}
                                                    defaultOption={'Select'}
                                                    options={extractResponseOption(item.responseOptions)}
                                                />}
                                                {(itemList.ruleFields.length - 1) !== itemIndex &&
                                                    <select
                                                        value={item.condition}
                                                        onChange={(e: any) => onItemConditionChange(e, index, itemIndex)}
                                                    >
                                                        <option value={'and'}>And</option>
                                                        <option value={'or'} >Or</option>
                                                    </select>
                                                }
                                            </>
                                        )
                                    })
                                }
                                <div>
                                    <CancelIcon onClick={() => onRemoveItemListHandler(index)} />
                                </div>
                            </div>
                            {(rule.ruleLogic.queryGrids.length !== (index + 1)) && <div>
                                <select
                                    value={itemList.condition?.id}
                                    onChange={(event: any) => onItemListConditionChange(event, index)}
                                >
                                    {
                                        ruleCondition?.map((condition: any) => (
                                            <option key={condition.id} value={condition.id} >{condition.name}</option>
                                        ))
                                    }
                                </select>
                            </div>}
                        </React.Fragment>
                    ))}
                    {rule?.ruleLogic?.queryGrids?.length === 0 && <div className="mt-3">
                        <DropVariableContainer
                            className={''}
                            onDropHandler={() => {
                                console.log("228....", nodeElement)
                                if (nodeElement && nodeElement.responseOptions && nodeElement.responseOptions.length > 0) {
                                    dispatch(onDropLogicVariable(rule, nodeElement))
                                    dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: '' } })
                                } else {
                                    // validate here
                                    dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: 'Please drag Optional Variable' } })
                                }
                            }}
                        />
                    </div>}
                </div>
            </div>
        </React.Fragment>
    )
}
export default FormActionLogic