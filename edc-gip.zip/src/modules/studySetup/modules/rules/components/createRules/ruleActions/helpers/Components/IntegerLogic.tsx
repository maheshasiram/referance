import _ from "lodash";
import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { extractOptions, extractResponseOption, extractStrExpressions, extractExpressions, extractRowCountOption } from "../../../../../constants/util";
import DropSubNode from "../../../../../helpers/DropSubNode";
import SelectDropdown from "../../../../../helpers/SelectDropdown";
import { Types } from "../../../../../reducer/types";
import CancelIcon from '@mui/icons-material/Cancel';
import SelectField from "../../../../../../../../../common/selectField/SelectField";


function IntegerLogic(props: any) {
    const dispatch = useDispatch()
    const { item, itemIndex, index } = props
    const { rule, nodeElement, validations, ruleSubFieldType, ruleOperator } = useSelector((state: any) => state.rules);
    const { configCodes } = useSelector((state: any) => state.application);

    const onDropSubNodeHandler = () => {
        const _rule = _.cloneDeep(rule)
        const _variable = _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex]
        if (_variable.datatype.code === nodeElement.datatype.code && _variable.fieldId !== nodeElement.id) {
            const _subField = {
                "id": 0,
                "fieldId": nodeElement.id,
                "fieldName": nodeElement.variableId,
                "groupId": nodeElement.groupId,
                "groupRowId": NaN,
                "visitIds": [],
                "visits": nodeElement.visits,
                "fieldGroup": nodeElement.groupId ? {
                    "groupId": nodeElement.groupId,
                    "groupRows": []
                } : null,
                "repeatMax": nodeElement.groupId ? nodeElement.repeatMax : null,
            }
            _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].ruleTypeField = _subField
            dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
            dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: "" } })
        } else {
            if (_variable.fieldId === nodeElement.id) {
                dispatch({
                    type: Types.VALIDATE_RULE, payload: {
                        ...validations,
                        logic: `Same variable can not drag`
                    }
                })
            } else {
                dispatch({
                    type: Types.VALIDATE_RULE, payload: {
                        ...validations,
                        logic: `${nodeElement.label}  variable is not related to ${_variable.datatype.name} variable.`
                    }
                })
            }
        }
    }
    const onDateGruoupNumberChange = (e: any) => {
        const _rule = _.cloneDeep(rule)
        _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].ruleTypeField.fieldGroup.groupRows = e
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
    }
    const onDateVisitChange = (e: any) => {
        const _rule = _.cloneDeep(rule)
        _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].ruleTypeField.visitIds = e
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
    }
    const onTextValueChange = (e: any) => {
        const _rule = _.cloneDeep(rule)
        _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].configRuleTypeId = e.target.value
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
    }
    const onRemoveSubNode = () => {
        const _rule = _.cloneDeep(rule)
        _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].ruleTypeField = null
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
    }

    return (
        <React.Fragment>
            <div className="item-container align-items-center">
                <div className="d-flex">
                    <span className="Variable-Label">{item.fieldName}</span>
                    <div className="d-flex">
                        <SelectField
                            id={item.fieldId}
                            className={'QDselect-visits'}
                            isDisabled={false}
                            isClearable={true}
                            isMulti={true}
                            value={item.visitIds}
                            onChange={props.onVisitChangeHandler}
                            options={extractOptions(item.visits)}
                        />
                        {item.fieldGroup?.groupId && <SelectField
                            id={item.fieldId}
                            className={'QDrowCount-Select'}
                            isDisabled={false}
                            isClearable={true}
                            isMulti={true}
                            value={item.fieldGroup.groupRows}
                            onChange={props.onRowCountChange}
                            options={extractRowCountOption(item.repeatMax)}
                            placeholder='Select Row Count'
                        />}

                        <SelectDropdown
                            className={`logic-visits`}
                            id={''}
                            onChange={props.oneExpressionChange}
                            disabled={false}
                            value={item.configOperatorId}
                            defaultOption={'Select Expression'}
                            options={(item.datatype.name === 'integer' || item.datatype.name === 'string') &&
                                (item.responseType.name === 'radio' || item.responseType.name === 'checkbox' ||
                                    item.responseType.name === 'single-select' || item.responseType.name === 'multi-select')
                                ? extractStrExpressions(ruleOperator) : extractExpressions(ruleOperator)}
                        />
                        {item.responseOptions && item.responseOptions?.length > 0 && <SelectDropdown
                            id={''}
                            onChange={props.onValueChangeHandler}
                            disabled={false}
                            value={item.ruleTypeValue}
                            defaultOption={'Select response'}
                            options={extractResponseOption(item.responseOptions)}
                        />}
                        <>{console.log("155...", ruleSubFieldType)}</>
                        {!(item.responseOptions && item.responseOptions.length > 0) &&
                            !(rule.actionType.code === configCodes?.SubjectStatusAction && item.datatype.name === 'real') &&
                            <SelectDropdown
                                className={`currentDate`}
                                id={''}
                                onChange={onTextValueChange}
                                disabled={false}
                                value={item.configRuleTypeId}
                                options={ruleSubFieldType?.map((item: any) => ({
                                    "label": item.name,
                                    "value": item.id
                                }))}
                            />}
                        {
                            !(item.responseOptions && item.responseOptions.length > 0) &&
                            !(item.configRuleTypeId && (ruleSubFieldType.find((i: any) => i.id === parseInt(item.configRuleTypeId)))?.code === 'RUL_SUB_FIELD_TYPE_FIELD') &&
                            <input placeholder={item.datatype.name === "integer" ? "Ex : 12, 5" : "Ex : 12.5, 5.2"}
                                type={'number'} value={item.ruleTypeValue} onChange={props.onValueChangeHandler} />
                        }
                        {item.configRuleTypeId &&
                            !item.ruleTypeField &&
                            (ruleSubFieldType.find((i: any) => i.id === parseInt(item.configRuleTypeId)))?.code === 'RUL_SUB_FIELD_TYPE_FIELD' &&
                            <DropSubNode
                                onDropSubNode={onDropSubNodeHandler}
                                className=''
                                content={`Drag ${item.datatype.name} field`}
                            />}
                    </div>
                </div>
                {
                    item.ruleTypeField?.fieldName && (ruleSubFieldType.find((i: any) => i.id === parseInt(item.configRuleTypeId)))?.code === 'RUL_SUB_FIELD_TYPE_FIELD' &&
                    <div className="p-1 border d-flex justify-content-center">
                        <p className="Variable-Label">{item.ruleTypeField.fieldName}</p>
                        <SelectField
                            id={""}
                            className={'QDselect-visits'}
                            isDisabled={false}
                            isClearable={true}
                            isMulti={true}
                            value={item.ruleTypeField.visitIds}
                            onChange={onDateVisitChange}
                            options={extractOptions(item.ruleTypeField.visits)}
                            placeholder='Select Visits'
                        />
                        {item.ruleTypeField?.fieldGroup?.groupId &&
                            <SelectField
                                id={""}
                                className={'QDrowCount-Select'}
                                isDisabled={false}
                                isClearable={true}
                                isMulti={true}
                                value={item.ruleTypeField.fieldGroup.groupRows}
                                onChange={onDateGruoupNumberChange}
                                options={extractRowCountOption(item.ruleTypeField.repeatMax)}
                                placeholder='Select Row Count'
                            />
                        }
                        <div>
                            <CancelIcon onClick={() => onRemoveSubNode()}/>
                        </div>
                    </div>
                }
            </div>
        </React.Fragment>
    )
}
export default IntegerLogic