import React from "react";
import QueryDefinitionOrSSALogic from "../helpers/QueryDefinitionOrSSALogic";

function SubjectStatusAction() {
    return (
        <React.Fragment>
            <div>
                <QueryDefinitionOrSSALogic />
            </div>
        </React.Fragment>
    )
}
export default SubjectStatusAction