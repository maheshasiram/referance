import _ from "lodash";
import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { onDropLogicVariable } from "../../../../constants/util";
import DropSubNode from "../../../../helpers/DropSubNode";
import DropVariableContainer from "../../../../helpers/DropVariableContainer";
import { Types } from "../../../../reducer/types";
import DateOrTimeDataType from "./Components/DateOrTimeDataType";
import CancelIcon from '@mui/icons-material/Cancel';
import IntegerLogic from "./Components/IntegerLogic";
import StringDataType from "./Components/StringDataType";
import PartialDateType from "./Components/PartialDateType";
import FileDataType from "./Components/FileDataType";

function QueryDefinitionOrSSALogic() {
    const dispatch = useDispatch()
    const { rule, nodeElement, validations, ruleSubFieldType, ruleCondition } = useSelector((state: any) => state.rules);
    const { configCodes } = useSelector((state: any) => state.application);

    const onVisitChangeHandler = (e: any, index: number, itemIndex: number) => {
        const _rule = _.cloneDeep(rule)
        _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].visitIds = e
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
        dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: '' } })
    }
    const oneExpressionChange = (e: any, index: number, itemIndex: number) => {
        const _rule = _.cloneDeep(rule)
        _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].configOperatorId = parseInt(e.target.value)
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
        dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: "" } })
    }

    const onValueChangeHandler = (e: any, index: number, itemIndex: number) => {
        const _rule = _.cloneDeep(rule)
        const _dataType = _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].datatype.code
        const _variable = _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex]
        if (_dataType === configCodes?.integer) {
            const _regex = /(?<![.\d])\d+(?![.\d])/
            if (e.target.value && !_regex.test(e.target.value)) {
                dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: 'Please enter numbers as 12 , 2' } })
            } else {
                dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: '' } });
            }
        } else if (_dataType === configCodes?.real) {
            const _regex = /^[\d]+(\.)[\d]{1,6}$/
            if (e.target.value && !_regex.test(e.target.value)) {
                dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: `${_variable.label} Please enter real numbers as 12.4 , 0.2` } })
            } else {
                dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: '' } });
            }
        } else if (_dataType === configCodes?.partialdate) {
            const partial_year = /^(0?[1-9]|[12][0-9]|3[01])[\-](0?[1-9]|1[012])[\-]\d{4}$/
            const datemonth = /^(0?[1-9]|[12][0-9]|3[01])[\-](0?[1-9]|1[012])$/
            const yearReg = /^\d{4}$/
            const month_year = /(0[1-9]|1[0-2])-([12]\d{3})/
            if (partial_year.test(e.target.value) || datemonth.test(e.target.value) || yearReg.test(e.target.value) || month_year.test(e.target.value)) {
                dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: '' } });
            } else {
                dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: 'Please enter partial date as 25-04-2019 Or 01-12 or 10-2022 or 2023' } });
            }
        }
        if (_dataType === configCodes?.file) {
            if (e.target.value === "") {
                dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: '' } })
            }
        }
        _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].ruleTypeValue = e.target.value
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
    }

    const onRowCountChange = (e: any, index: number, itemIndex: number) => {
        const _rule = _.cloneDeep(rule)
        _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].fieldGroup.groupRows = e
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
        dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: '' } })
    }
    const onRemoveItemListHandler = (index: any) => {
        const _rule = _.cloneDeep(rule)
        _rule.ruleLogic.queryGrids.map((item: any) => {
            item.gridNumber = item.gridNumber - 1
            return null
        })
        _rule.ruleLogic.queryGrids.splice(index, 1)
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
        dispatch({ type: Types.VALIDATE_RULE, payload: { target: "", logic: "" } })//Clear Validation Messages
    }
    const onDropSubNode = (index: number) => {
        const _rule = _.cloneDeep(rule)
        const _valueSubFieldId = ruleSubFieldType?.find((i: any) => i.code === configCodes?.Value)
        const _condition = ruleCondition?.find((i: any) => i.code === configCodes?.AND)
        const _logic: any = {
            "id": 0,
            "fieldId": nodeElement.id,
            "formId": nodeElement.formId,
            "fieldName": nodeElement.variableId,
            "visitIds": [],
            "datatype": nodeElement.datatype,
            "responseType": nodeElement.responseType,
            "visits": nodeElement.visits,
            "fieldGroup": nodeElement.groupId ? {
                "groupId": nodeElement.groupId,
                "groupName": "",
                "groupRows": []
            } : null,
            "configOperatorId": 0,
            "configRuleTypeId": _valueSubFieldId.id,
            "ruleTypeValue": "",
            "ruleTypeField": null,
            "fieldOrdinal": 1,
            "configConditionId": _condition?.id,
            "condition": _condition,
            "responseOptions": nodeElement.responseOptions,
            "repeatMax": nodeElement.groupId ? nodeElement.repeatMax : null
        }
        _rule?.ruleLogic?.queryGrids[index]?.ruleFields.push(_logic)
        if (rule.actionType?.code === configCodes?.SubjectStatusAction) {
            if (nodeElement && nodeElement.responseOptions && nodeElement.responseOptions.length > 0) {
                dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
                dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: '' } })
            } else {
                dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: 'Please drag Optional Variable' } })
            }
        } else if (rule.actionType?.code === configCodes?.QueryAction) {
            dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
            dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: "" } })
        }
    }
    const onItemListConditionChange = (event: any, index: number) => {
        const _rule = _.cloneDeep(rule)
        const _condition = ruleCondition?.find((i: any) => i.id === parseInt(event.target.value))
        _rule.ruleLogic.queryGrids[index].condition = _condition
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
    }
    const onItemConditionChange = (e: any, index: number, itemIndex: number) => {
        const _rule = _.cloneDeep(rule)
        const _condition = ruleCondition?.find((i: any) => i.id === parseInt(e.target.value))
        _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].configConditionId = parseInt(e.target.value)
        _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].condition = _condition
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
    }
    const renderBody = (itemList: any, index: number, item: any, itemIndex: number) => {
        switch (item.datatype?.code) {
            case configCodes?.date:
                return <DateOrTimeDataType
                    item={item}
                    index={index}
                    itemIndex={itemIndex}
                    itemsList={itemList}
                    onVisitChangeHandler={(e: any) => onVisitChangeHandler(e, index, itemIndex)}
                    oneExpressionChange={(e: any) => oneExpressionChange(e, index, itemIndex)}
                    onValueChangeHandler={(e: any) => onValueChangeHandler(e, index, itemIndex)}
                    onRowCountChange={(e: any) => onRowCountChange(e, index, itemIndex)}
                />

            case configCodes?.integer:
                return <IntegerLogic
                    item={item}
                    index={index}
                    itemIndex={itemIndex}
                    itemsList={itemList}
                    onVisitChangeHandler={(e: any) => onVisitChangeHandler(e, index, itemIndex)}
                    oneExpressionChange={(e: any) => oneExpressionChange(e, index, itemIndex)}
                    onValueChangeHandler={(e: any) => onValueChangeHandler(e, index, itemIndex)}
                    onRowCountChange={(e: any) => onRowCountChange(e, index, itemIndex)}
                />

            case configCodes?.real:
                return <IntegerLogic
                    item={item}
                    index={index}
                    itemIndex={itemIndex}
                    itemsList={itemList}
                    onVisitChangeHandler={(e: any) => onVisitChangeHandler(e, index, itemIndex)}
                    oneExpressionChange={(e: any) => oneExpressionChange(e, index, itemIndex)}
                    onValueChangeHandler={(e: any) => onValueChangeHandler(e, index, itemIndex)}
                    onRowCountChange={(e: any) => onRowCountChange(e, index, itemIndex)}
                />

            case configCodes?.string:
                return <StringDataType
                    item={item}
                    index={index}
                    itemIndex={itemIndex}
                    itemsList={itemList}
                    onVisitChangeHandler={(e: any) => onVisitChangeHandler(e, index, itemIndex)}
                    oneExpressionChange={(e: any) => oneExpressionChange(e, index, itemIndex)}
                    onValueChangeHandler={(e: any) => onValueChangeHandler(e, index, itemIndex)}
                    onRowCountChange={(e: any) => onRowCountChange(e, index, itemIndex)}
                />

            case configCodes?.time:
                return <DateOrTimeDataType
                    item={item}
                    index={index}
                    itemIndex={itemIndex}
                    itemsList={itemList}
                    onVisitChangeHandler={(e: any) => onVisitChangeHandler(e, index, itemIndex)}
                    oneExpressionChange={(e: any) => oneExpressionChange(e, index, itemIndex)}
                    onValueChangeHandler={(e: any) => onValueChangeHandler(e, index, itemIndex)}
                    onRowCountChange={(e: any) => onRowCountChange(e, index, itemIndex)}
                />

            case configCodes?.partialdate:
                return <PartialDateType
                    item={item}
                    index={index}
                    itemIndex={itemIndex}
                    itemsList={itemList}
                    onVisitChangeHandler={(e: any) => onVisitChangeHandler(e, index, itemIndex)}
                    oneExpressionChange={(e: any) => oneExpressionChange(e, index, itemIndex)}
                    onValueChangeHandler={(e: any) => onValueChangeHandler(e, index, itemIndex)}
                    onRowCountChange={(e: any) => onRowCountChange(e, index, itemIndex)}
                />

            case configCodes?.PartialTime:
                return <PartialDateType
                    item={item}
                    index={index}
                    itemIndex={itemIndex}
                    itemsList={itemList}
                    onVisitChangeHandler={(e: any) => onVisitChangeHandler(e, index, itemIndex)}
                    oneExpressionChange={(e: any) => oneExpressionChange(e, index, itemIndex)}
                    onValueChangeHandler={(e: any) => onValueChangeHandler(e, index, itemIndex)}
                    onRowCountChange={(e: any) => onRowCountChange(e, index, itemIndex)}
                />

            case configCodes?.file:
                return <FileDataType
                    item={item}
                    index={index}
                    itemIndex={itemIndex}
                    itemsList={itemList}
                    onVisitChangeHandler={(e: any) => onVisitChangeHandler(e, index, itemIndex)}
                    oneExpressionChange={(e: any) => oneExpressionChange(e, index, itemIndex)}
                    onValueChangeHandler={(e: any) => onValueChangeHandler(e, index, itemIndex)}
                    onRowCountChange={(e: any) => onRowCountChange(e, index, itemIndex)}
                />
            default:
                return <></>
        }
    }
    const onDropMainLogicCointainer = () => {
        if (!nodeElement.children) {
            if (rule.actionType?.code === configCodes?.SubjectStatusAction) {
                if (nodeElement && nodeElement.responseOptions && nodeElement.responseOptions.length > 0) {
                    dispatch(onDropLogicVariable(rule, nodeElement))
                    dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: '' } })
                } else {
                    // validate here
                    dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: 'Please drag Optional Variable' } })
                }
            } else if (rule.actionType?.code === configCodes?.QueryAction) {
                dispatch(onDropLogicVariable(rule, nodeElement))
                dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: "" } })
            }
        }
    }
   
    return (<React.Fragment>
        <div className='py-2'>
            Logic: <span className="text-danger ">{validations.logic}</span>
        </div>
        <div className="droped-elements">
            <div>
                {rule && rule.ruleLogic && rule.ruleLogic.queryGrids.length > 0 && rule.ruleLogic.queryGrids.map((itemList: any, index: number) => (
                    <React.Fragment key={index}>
                        <div key={index} className='itemList-Container'>
                            <>{console.log("itemList...", itemList)}</>
                            {
                                itemList?.ruleFields?.map((item: any, itemIndex: number) => (
                                    <div className="" key={itemIndex}>
                                        {renderBody(itemList, index, item, itemIndex)}
                                        {(itemList.ruleFields.length - 1) !== itemIndex &&
                                            <select
                                                value={item?.condition?.id}
                                                onChange={(e: any) => onItemConditionChange(e, index, itemIndex)}
                                            >
                                                {
                                                    ruleCondition?.map((condition: any) => (
                                                        <option key={condition.id} value={condition.id} >{condition.name}</option>
                                                    ))
                                                }
                                            </select>
                                        }
                                    </div>
                                ))
                            }
                            {
                                <div className="d-flex">
                                    {rule.actionType.code === configCodes?.QueryAction && <div className="col-sm-11">
                                        <DropSubNode
                                            onDropSubNode={() => onDropSubNode(index)}
                                            className=''
                                            content='Drag a variable'
                                        />
                                    </div>}
                                    <CancelIcon onClick={() => onRemoveItemListHandler(index)} />
                                </div>
                            }
                        </div>
                        {(rule.ruleLogic.queryGrids.length !== (index + 1)) && <div>
                            <select
                                value={itemList.condition?.id}
                                onChange={(event: any) => onItemListConditionChange(event, index)}
                            >
                                {
                                    ruleCondition?.map((condition: any) => (
                                        <option key={condition.id} value={condition.id} >{condition.name}</option>
                                    ))
                                }
                            </select>
                        </div>}
                    </React.Fragment>
                ))}
            </div>
            {
                (rule.actionType.code == configCodes.SubjectStatusAction && rule?.ruleLogic?.queryGrids?.length === 0) && <DropVariableContainer
                    className={''}
                    onDropHandler={() => onDropMainLogicCointainer()}
                />
            }
            {
                rule.actionType.code == configCodes?.QueryAction && <DropVariableContainer
                    className={''}
                    onDropHandler={() => onDropMainLogicCointainer()}
                />
            }
        </div>
    </React.Fragment>)
}
export default QueryDefinitionOrSSALogic