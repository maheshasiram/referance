import _ from "lodash";
import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { extractDateTimeExpression, extractExpressions, extractOptions, extractRowCountOption, extractSubField } from "../../../../../constants/util";
import DropSubNode from "../../../../../helpers/DropSubNode";
import SelectDropdown from "../../../../../helpers/SelectDropdown";
import { Types } from "../../../../../reducer/types";
import CancelIcon from '@mui/icons-material/Cancel';
import SelectField from "../../../../../../../../../common/selectField/SelectField";

function DateOrTimeDataType(props: any) {
    const dispatch = useDispatch()
    const { item, itemIndex, index } = props
    const { rule, nodeElement, validations, ruleOperator, ruleSubDateType, ruleSubTimeType } = useSelector((state: any) => state.rules);
    const onDropSubNodeHandler = () => {
        const _rule = _.cloneDeep(rule)
        const _variable = _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex]
        if (_variable.datatype.code === nodeElement.datatype.code) {
            const _subField = {
                "id": 0,
                "fieldId": nodeElement.id,
                "fieldName": nodeElement.variableId,
                "groupId": nodeElement.groupId,
                "groupRowId": NaN,
                "visitIds": [],
                "visits": nodeElement.visits,
                "fieldGroup": nodeElement.groupId ? {
                    "groupId": nodeElement.groupId,
                    "groupRows": []
                } : null,
                "repeatMax": nodeElement.groupId ? nodeElement.repeatMax : null,
                "configOperatorId": 0
            }
            _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].ruleTypeField = _subField
            dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
            dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: "" } })
        } else {
            dispatch({
                type: Types.VALIDATE_RULE, payload: {
                    ...validations,
                    logic: `${nodeElement.label} variable is not related to ${_variable.datatype.name} variable.`
                }
            })

        }
    }
    const onDateGruoupNumberChange = (e: any) => {
        const _rule = _.cloneDeep(rule)
        _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].ruleTypeField.fieldGroup.groupRows = e
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
        dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: "" } })
    }
    const onDateVisitChange = (e: any) => {
        const _rule = _.cloneDeep(rule)
        _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].ruleTypeField.visitIds = e
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
        dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: "" } })
    }
    const onDateCountChange = (e: any) => {
        const _rule = _.cloneDeep(rule)
        _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].ruleTypeValue = e.target.value
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
        dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: "" } })
    }
    const onRemoveSubNode = () => {
        const _rule = _.cloneDeep(rule)
        _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].ruleTypeField = null
        _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].ruleTypeValue = null
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
        dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: "" } })
    }
    const onTextValueChange = (e: any) => {
        const _rule = _.cloneDeep(rule)
        _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].configRuleTypeId = parseInt(e.target.value)
        _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].ruleTypeField = null
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
    }

    const onExpressionChangeHanlder = (e: any) => {
        const _rule = _.cloneDeep(rule)
        _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].ruleTypeField.configOperatorId = parseInt(e.target.value)
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
    }
    return (
        <React.Fragment>
            <div className="item-container align-items-center">
                <div className="d-flex">
                    <span className="Variable-Label">{item.fieldName}</span>
                    <div className="d-flex">
                        <SelectField
                            id={item.fieldId}
                            className={'QDselect-visits'}
                            isDisabled={false}
                            isClearable={true}
                            isMulti={true}
                            value={item.visitIds}
                            onChange={props.onVisitChangeHandler}
                            options={extractOptions(item.visits)}
                        />
                        {item.fieldGroup?.groupId && <SelectField
                            id={item.fieldId}
                            className={'QDrowCount-Select'}
                            isDisabled={false}
                            isClearable={true}
                            isMulti={true}
                            value={item.fieldGroup.groupRows}
                            onChange={props.onRowCountChange}
                            options={extractRowCountOption(item.repeatMax)}
                            placeholder='Select Row Count'

                        />}
                        <SelectDropdown
                            className={`logic-visits`}
                            id={''}
                            onChange={props.oneExpressionChange}
                            disabled={false}
                            value={item.configOperatorId}
                            defaultOption={'Select Expression'}
                            options={extractExpressions(ruleOperator)}
                        />
                        <SelectDropdown
                            className={`currentDate`}
                            id={''}
                            onChange={onTextValueChange}
                            disabled={false}
                            value={item.configRuleTypeId}
                            defaultOption={'Select'}
                            options={
                                item.datatype.code === 'DATA_TYP_DATE' ?
                                    extractSubField(ruleSubDateType) : extractSubField(ruleSubTimeType)}
                        />
                        {
                            item.configRuleTypeId && !item.ruleTypeField &&
                            ((ruleSubDateType.find((i: any) => i.id === item.configRuleTypeId))?.code === 'RUL_SUB_DATE_TYPE_OTHER' ||
                                (ruleSubTimeType.find((i: any) => i.id === item.configRuleTypeId))?.code === 'RUL_SUB_TIME_TYPE_OTHER')
                            && <DropSubNode
                                onDropSubNode={onDropSubNodeHandler}
                                className=''
                                content={`Drag ${item.datatype.name} field`}
                            />}
                    </div>
                </div>
                {
                    item.ruleTypeField?.fieldName && ((ruleSubDateType.find((i: any) => i.id === item.configRuleTypeId))?.code === 'RUL_SUB_DATE_TYPE_OTHER' ||
                        (ruleSubTimeType.find((i: any) => i.id === item.configRuleTypeId))?.code === 'RUL_SUB_TIME_TYPE_OTHER')
                    && <div className="p-1 border d-flex justify-content-center">
                        <p className="Variable-Label">{item.ruleTypeField.fieldName}</p>
                        <SelectField
                            id={""}
                            className={'QDselect-visits'}
                            isDisabled={false}
                            isClearable={true}
                            isMulti={true}
                            value={item.ruleTypeField.visitIds}
                            onChange={onDateVisitChange}
                            options={extractOptions(item.ruleTypeField.visits)}
                            placeholder='Select Visits'
                        />
                        {item.ruleTypeField?.fieldGroup?.groupId &&
                            <SelectField
                                id={""}
                                className={'QDrowCount-Select'}
                                isDisabled={false}
                                isClearable={true}
                                isMulti={true}
                                value={item.ruleTypeField.fieldGroup.groupRows}
                                onChange={onDateGruoupNumberChange}
                                options={extractRowCountOption(item.ruleTypeField.repeatMax)}
                                placeholder='Select Row Count'
                            />
                        }
                        <SelectDropdown
                            className={`logic-visits`}
                            id={''}
                            onChange={onExpressionChangeHanlder}
                            disabled={false}
                            value={item.ruleTypeField.configOperatorId}
                            defaultOption={'Select Expression'}
                            options={extractDateTimeExpression(ruleOperator)}
                        />
                        <input placeholder="Enter date count" value={props.item.dateCount} onChange={onDateCountChange} ></input>
                        <div>
                            <CancelIcon onClick={() => onRemoveSubNode()}/>
                        </div>
                    </div>
                }
            </div>
        </React.Fragment>
    )
}
export default DateOrTimeDataType