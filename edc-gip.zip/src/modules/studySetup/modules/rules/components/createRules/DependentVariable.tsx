import _ from "lodash";
import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { Types } from "../../reducer/types";
import CancelIcon from '@mui/icons-material/Cancel';
import { extractOptions, extractRowCountOption } from "../../constants/util";
import SelectField from "../../../../../../common/selectField/SelectField";

function DependentVariable(props: any) {
    const dispatch = useDispatch()
    const { rule, validations } = useSelector((state: any) => state.rules);
    const { node } = props

    const onDropdependentVariable = () => {
        const _rule = _.cloneDeep(rule)
        if (node.id) {
            dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, target: "" } })
            const _target = {
                "id": 0,
                "fieldId": node.id,
                "fieldName": node.variableId,
                "formId": node.formId,
                "visitIds": [],
                "targetFieldGroup": node.groupId ? {
                    "targetGroupId": node.groupId,
                    "targetGroupName": "",
                    "targetGroupRows": []
                } : null,
                "visits": node.visits,
                "repeatMax": node.groupId ? node.repeatMax : null
            }
            dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: { ..._rule, targetField: _target } })
        }
    }

    const onVisitChangeHandler = (e: any) => {
        const _rule = _.cloneDeep(rule)
        _rule.targetField.visitIds = e
        if (e.length === 0) {
            dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, target: 'Please Select Visit in Dependent Variable' } })
        }
        else {
            dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, target: '' } })
        }
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
    }
    const onRowCountChangeHandler = (e: any) => {
        const _rule = _.cloneDeep(rule)
        _rule.targetField.targetFieldGroup.targetGroupRows = e
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
        if (e === '') {
            dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, target: 'Please select row count in dependent variable' } })
        }
        else {
            dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, target: '' } })
        }
    }

    const onRemoveDependentVariable = () => {
        const _rule = _.cloneDeep(rule)
        _rule.targetField = null
        _rule.ruleLogic = { "queryGrids": [] }
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: { ..._rule } })
        dispatch({ type: Types.VALIDATE_RULE, payload: { target: "", logic: "" } }) //clear validation
    }
    return (
        <React.Fragment>
            <div>
                <label>Target Variable :</label><span className="text-danger ">{validations.target}</span>
                {<div className="DependentCropContainer w-100 border border-dashed " >
                    {
                        rule && rule.targetField ? <div className="p-2">
                            <div className="d-flex align-items-center">
                                <p className="Variable-Label" >{rule.targetField?.fieldName as string}</p>
                                <div>
                                    {rule.targetField.visits &&
                                        <SelectField
                                            className={'dependentvar-visits'}
                                            isDisabled={rule.id > 0 ? true : false}
                                            isClearable={true}
                                            isMulti={true}
                                            value={rule.targetField.visitIds}
                                            onChange={(e: any) => onVisitChangeHandler(e)}
                                            options={extractOptions(rule.targetField.visits)}
                                        />
                                    }
                                </div>
                                {<div>
                                    {rule.targetField.repeatMax && rule.targetField?.targetFieldGroup?.targetGroupId &&
                                        <SelectField
                                            className={'Target-rowCount-Select'}
                                            isDisabled={false}
                                            isClearable={true}
                                            isMulti={true}
                                            value={rule.targetField.targetFieldGroup.targetGroupRows}
                                            onChange={(e: any) => onRowCountChangeHandler(e)}
                                            options={extractRowCountOption(rule.targetField.repeatMax)}
                                            placeholder='Select Row Count'
                                        />
                                    }
                                </div>}
                                {rule && !(rule.id > 0) && <div>
                                    {<CancelIcon onClick={() => onRemoveDependentVariable()} />}
                                </div>}
                            </div>
                        </div> : <div className="d-flex justify-content-center p-2"
                            onDragOver={(e: any) => { e.preventDefault() }}
                            onDrop={onDropdependentVariable}
                        >
                            <span className="m-0 text-center p-2">Drag a variable here</span>
                        </div>
                    }
                </div>
                }
            </div>
        </React.Fragment>
    )
}
export default DependentVariable