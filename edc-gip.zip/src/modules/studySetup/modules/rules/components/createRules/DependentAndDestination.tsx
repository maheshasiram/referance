import React, { useState } from 'react'
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import { useDispatch, useSelector } from "react-redux";
import DestinationForm from './DestinationForm';
import { Types } from '../../reducer/types';
import '../../styles/Styles.scss';
import TreeviewComponent from '../../../../../../components/TreeviewComponent';
import DependentVariable from './DependentVariable';
import EmailActionLogic from './ruleActions/EmailAction/EmailActionLogic';
import FormActionLogic from './ruleActions/FormAction/FormActionLogic';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import QueryDefinition from './ruleActions/QueryDefinition/QueryDefinition';
import SubjectStatusAction from './ruleActions/SubjectStatusAction/SubjectStatusAction';
import DestinationVisit from './DestinationVisit';

function DependentAndDestination(props: any) {
    const dispatch = useDispatch();
    const { setTabValue, tabValue } = props
    const { treeViewData, rule } = useSelector((state: any) => state.rules);
    const { configCodes } = useSelector((state: any) => state.application);
    const [node, setNode] = useState({})
    const onDragTreeviewNode = (node: any) => {
        dispatch({ type: Types.SAVE_NODE_VALUE_FOR_RULES, payload: node });
        setNode(node)
    }
    const handleChange = (event: any, newValue: number) => {
        setTabValue(newValue)
    };
    const ondragEnd = () => {
        setNode({})
        dispatch({ type: Types.SAVE_NODE_VALUE_FOR_RULES, payload: null });
    }
    const { currentStudy } = useSelector((state: any) => state.application)
    console.log("35....", currentStudy?.id);

    return (
        <div>
            <Box sx={{ width: '100%', typography: 'body1' }}>
                <TabContext value={tabValue}>
                    <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                        <TabList onChange={handleChange} aria-label="lab API tabs example">
                            <Tab label={rule.actionType?.code === configCodes?.QueryAction ? "Target variable / Logic" : "Logic"}
                                value="0" />
                            {rule && (rule.actionType?.code === configCodes?.FormAction || rule.actionType?.code === configCodes?.VisitAction) &&
                                <Tab label={`Destination ${rule.actionType?.code === configCodes?.VisitAction ? "Visit" : "form"}`} value="1"
                                    // disabled={rule.targetField?.visitIds.length > 0 && rule.targetField.visitIds.length > 0 ? false : true}
                                    disabled={rule?.ruleLogic?.queryGrids[0]?.ruleFields[0]?.visitIds?.length > 0 ? false : true}
                                />}
                        </TabList>
                    </Box>
                    <TabPanel value="0">
                        <div className='tabPanel-container d-flex col-sm-12' >
                            <div className='col-sm-8'>
                                {(rule.actionType?.code === configCodes?.QueryAction) && <DependentVariable node={node} />}
                                {/* {rule && rule.targetField &&  */}
                                <div>
                                    {/* <div className='py-2'>
                                        Logic: <span className="text-danger ">{validations.logic}</span>
                                    </div> */}
                                    {rule && rule.targetField && rule.actionType?.code === configCodes?.QueryAction && <QueryDefinition />}
                                    {rule.actionType?.code === configCodes?.EmailAction && <EmailActionLogic />}
                                    {rule.actionType?.code === configCodes?.FormAction && <FormActionLogic />}
                                    {rule.actionType?.code === configCodes?.VisitAction && <FormActionLogic />}
                                    {rule.actionType?.code === configCodes?.SubjectStatusAction && <SubjectStatusAction />}
                                </div>
                                {/* } */}
                            </div>
                            <div className='col-sm-4'>
                                {rule && rule.actionType !== 0 && <div className=''>
                                    <div className="drag-variable-header">Drag a variables from here </div>
                                    <div className='card scroll'>
                                        <TreeviewComponent
                                            data={treeViewData}
                                            onDragTreeviewNode={onDragTreeviewNode}
                                            ondragEnd={ondragEnd}
                                        />
                                    </div>
                                </div>}
                            </div>
                        </div>
                    </TabPanel>
                    <TabPanel value="1">
                        <div>
                            {rule.actionType?.code === configCodes?.VisitAction ? <DestinationVisit /> : <DestinationForm />}
                        </div>
                    </TabPanel>
                </TabContext>
            </Box>
        </div>
    );
}

export default DependentAndDestination