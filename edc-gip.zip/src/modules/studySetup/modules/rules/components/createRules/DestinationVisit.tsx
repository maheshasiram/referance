import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Types } from "../../reducer/types";
import { fetchVisitsAssignedToForm } from "../../actions/actions";

function DestinationVisit() {
    const dispatch = useDispatch()
    const { currentStudy } = useSelector((state: any) => state.application);
    const { destinatonVists, rule } = useSelector((state: any) => state.rules)

    const onSlectVisit = (event: any, index: any) => {
        const _data = [...[], ...destinatonVists];
        _data[index].status = event.target.checked;

        dispatch({ type: Types.GET_VISIT_ASSIGNED_TOFORM, payload: _data })
    }
    useEffect(() => {
        dispatch(fetchVisitsAssignedToForm(currentStudy.id, rule))
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    
    return (
        <React.Fragment>
            <div className="destinationVisit">
                <ul className="list-items">
                    {
                        destinatonVists && destinatonVists?.length > 0 && destinatonVists?.map((item: any, index: number) => {
                            return (
                                <li key={item.id}>
                                    <input id={`chkbx-variable-${item.id}`} type="checkbox"
                                        checked={item?.status} onChange={(e) => onSlectVisit(e, index)} />
                                    <label htmlFor={`chkbx-variable-${item.id}`} >{item?.visitName}</label>
                                </li>
                            )
                        }
                        )
                    }
                </ul>
            </div>
        </React.Fragment>
    )
}

export default DestinationVisit;