import React from "react";
import { useSelector } from "react-redux";
import { extractOptions, extractRowCountOption, extractStrExpressions } from "../../../../../constants/util";
import SelectDropdown from "../../../../../helpers/SelectDropdown";
import SelectField from "../../../../../../../../../common/selectField/SelectField";

function PartialDateType(props: any) {
    const { item } = props
    const { ruleOperator } = useSelector((state: any) => state.rules);
    return (
        <React.Fragment>
            <div className="item-container align-items-center">
                <div className="d-flex">
                    <span className="Variable-Label">{item.fieldName}</span>
                    <div className="d-flex">
                        <SelectField
                            id={item.fieldId}
                            className={'QDselect-visits'}
                            isDisabled={false}
                            isClearable={true}
                            isMulti={true}
                            value={item.visitIds}
                            onChange={props.onVisitChangeHandler}
                            options={extractOptions(item.visits)}
                        />

                        {item.fieldGroup?.groupId && <SelectField
                            id={item.fieldId}
                            className={'QDrowCount-Select'}
                            isDisabled={false}
                            isClearable={true}
                            isMulti={true}
                            value={item.fieldGroup.groupRows}
                            onChange={props.onRowCountChange}
                            options={extractRowCountOption(item.repeatMax)}
                            placeholder='Select Row Count'

                        />}

                        <SelectDropdown
                            className={`logic-visits`}
                            id={''}
                            onChange={props.oneExpressionChange}
                            disabled={false}
                            value={item.expression}
                            defaultOption={'Select Expression'}
                            options={extractStrExpressions(ruleOperator)}
                        />
                        {
                            <input placeholder={item?.datatype?.code === 'DATA_TYP_PARTIAL_DATE' ? "Ex:25-04-2019 or 31-12 or 2019" : "Ex:12:00,12"}
                            value={item.ruleTypeValue} onChange={props.onValueChangeHandler} />
                        }
                    </div>
                </div>
            </div>
        </React.Fragment>
    )
}
export default PartialDateType