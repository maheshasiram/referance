import React from "react";
import { useDispatch, useSelector } from "react-redux";
import _ from "lodash";
import DropVariableContainer from "../../../../helpers/DropVariableContainer";
import { Types } from "../../../../reducer/types";
import { extractExpressions, extractOptions, extractRowCountOption, extractStrExpressions, onDropLogicVariable, responseOptions, onVisitChangeHandler } from "../../../../constants/util";
import SelectDropdown from "../../../../helpers/SelectDropdown";
import CancelIcon from '@mui/icons-material/Cancel';
import SelectField from "../../../../../../../../common/selectField/SelectField";

function EmailActionLogic() {
    const dispatch = useDispatch();
    const { rule, nodeElement, validations, ruleCondition, ruleOperator, ruleSubFieldType } = useSelector((state: any) => state.rules)
    const { configCodes } = useSelector((state: any) => state.application);
    const onItemListConditionChange = (event: any, index: number) => {
        const _rule = _.cloneDeep(rule)
        const _condition = ruleCondition?.find((i: any) => i.id === event.target.value)
        _rule.ruleLogic.queryGrids[index].condition = _condition
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
    }
    const onExpressionChange = (e: any, index: number, itemIndex: number) => {
        const _rule = _.cloneDeep(rule)
        _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].configOperatorId = parseInt(e.target.value)
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
        dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: "" } })
    }

    const onRowCountChange = (e: any, index: number, itemIndex: number) => {
        const _rule = _.cloneDeep(rule)
        _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].fieldGroup.groupRows = e
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
        dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: '' } })
    }

    const onValueChangeHandler = (e: any, index: number, itemIndex: number) => {
        const _rule = _.cloneDeep(rule)
        _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].ruleTypeValue = e.target.value
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
        dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: "" } })
    }

    const onRemoveItemListHandler = (index: any) => {
        const _rule = _.cloneDeep(rule)
        _rule.ruleLogic.queryGrids.splice(index, 1)
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
        dispatch({ type: Types.VALIDATE_RULE, payload: { target: "", logic: "" } })
    }

    const onDropMainLogicCointainer = () => {
        if ((nodeElement?.responseOptions?.length > 0) || (nodeElement?.datatype?.code === configCodes?.file)) {
            dispatch(onDropLogicVariable(rule, nodeElement))
            dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: "" } })
        }
        else {
            dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, logic: "Please drag optional variable or file type" } })
        }
    }

    const onItemConditionChange = (e: any, index: number, itemIndex: number) => {
        const _rule = _.cloneDeep(rule)
        const _condition = ruleCondition?.find((i: any) => i.id === parseInt(e.target.value))
        _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].configConditionId = e.target.value
        _rule.ruleLogic.queryGrids[index].ruleFields[itemIndex].condition = _condition
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: _rule })
    }

    return (
        <React.Fragment>
            <div className='py-2'>
                Logic: <span className="text-danger ">{validations.logic}</span>
            </div>
            <div className="droped-elements">
                <div>
                    {rule && rule.ruleLogic && rule.ruleLogic.queryGrids.length > 0 && rule.ruleLogic.queryGrids.map((itemList: any, index: number) => (
                        <React.Fragment key={index}>
                            <div key={index} className='itemList-Container'>
                                {
                                    itemList?.ruleFields?.map((item: any, itemIndex: number) => (
                                        <div key={itemIndex} className="">
                                            <div className="d-flex">
                                                {item.fieldName}
                                                <SelectField
                                                    id={item.fieldId}
                                                    className={'QDselect-visits'}
                                                    isDisabled={false}
                                                    isClearable={true}
                                                    isMulti={true}
                                                    value={item.visitIds}
                                                    onChange={(e: any) => onVisitChangeHandler(e, index, itemIndex, rule, validations, dispatch)}
                                                    options={extractOptions(item.visits)}
                                                />
                                                {item.fieldGroup?.groupId && <SelectField
                                                    id={item.fieldId}
                                                    className={'QDrowCount-Select'}
                                                    isDisabled={false}
                                                    isClearable={true}
                                                    isMulti={true}
                                                    value={item.fieldGroup.groupRows}
                                                    onChange={(e: any) => onRowCountChange(e, index, itemIndex)}
                                                    options={extractRowCountOption(item.repeatMax)}
                                                    placeholder='Select Row Count'

                                                />}
                                                <SelectDropdown
                                                    className={`dependentvar-visits`}
                                                    id={''}
                                                    onChange={(e: any) => onExpressionChange(e, index, itemIndex)}
                                                    disabled={false}
                                                    value={item.configOperatorId}
                                                    defaultOption={'Select Expression'}
                                                    options={(item?.datatype?.code === configCodes?.string || item?.datatype?.code === configCodes?.file) ? extractStrExpressions(ruleOperator) : extractExpressions(ruleOperator)}
                                                />

                                                {item?.datatype?.code !== configCodes?.file ?
                                                    <SelectDropdown
                                                        className={`dependentvar-visits`}
                                                        id={''}
                                                        onChange={(e: any) => onValueChangeHandler(e, index, itemIndex)}
                                                        disabled={false}
                                                        value={item.ruleTypeValue}
                                                        defaultOption={'Select'}
                                                        options={responseOptions(item.responseOptions)}
                                                    />
                                                    : ''
                                                }
                                            </div>
                                            {(itemList.ruleFields.length - 1) !== itemIndex &&
                                                <select
                                                    value={item.condition}
                                                    onChange={(e: any) => onItemConditionChange(e, index, itemIndex)}
                                                >
                                                    {
                                                        ruleCondition?.map((condition: any) => (
                                                            <option key={condition.id} value={condition.id} >{condition.name}</option>
                                                        ))
                                                    }
                                                </select>
                                            }
                                        </div>
                                    ))
                                }
                                <CancelIcon onClick={() => onRemoveItemListHandler(index)} />
                            </div>
                            {(rule.ruleLogic.queryGrids.length !== (index + 1)) && <div>
                                <select
                                    value={itemList.condition?.id}
                                    onChange={(event: any) => onItemListConditionChange(event, index)}
                                >
                                    {
                                        ruleCondition?.map((condition: any) => (
                                            <option key={condition.id} value={condition.id} >{condition.name}</option>
                                        ))
                                    }
                                </select>
                            </div>}
                        </React.Fragment>
                    ))}
                    {rule?.ruleLogic?.queryGrids?.length === 0 && <DropVariableContainer
                        onDropHandler={() => onDropMainLogicCointainer()} />}
                </div>
            </div>
        </React.Fragment>
    )
}
export default EmailActionLogic