import React from "react";
import QueryDefinitionOrSSALogic from "../helpers/QueryDefinitionOrSSALogic";

function QueryDefinition() {
    return(
        <div>
            <QueryDefinitionOrSSALogic />
        </div>
    )
}
export default QueryDefinition