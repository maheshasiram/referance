import React from 'react'
import { Types } from '../../reducer/types'
import { useDispatch, useSelector } from 'react-redux'
import TreeviewComponent from '../../../../../../components/TreeviewComponent'
import _ from 'lodash'

function DestinationForm() {
    const dispatch = useDispatch();
    const { rule, destinationTreeeData } = useSelector((state: any) => state.rules);

    const onCheckBoxClick = (event: any, node: any, parent: any) => {
        const payload = { ...{}, ...rule }
        if (event.target.checked) {//logic for selectform
            const checkId = payload?.ruleFormActions?.length > 0 && payload?.ruleFormActions?.find((form: any) => form.visitId === parent.props.parent.visitId)
            if (checkId?.visitId === parent.props.parent.visitId) {//if same visit push to that form
                checkId?.formIds.push(node.id)
            } else {//else push new object with new visitId and form
                payload.ruleFormActions.push({
                    id: 0,
                    visitId: parent.props.parent.visitId,
                    formIds: [node.id]
                });
            }
        } else {//Logic to unselect
            payload?.ruleFormActions?.map((item: any, index: any) => {
                const fieldIndex = item?.formIds?.findIndex((ele: any) => ele === node.id)
                if (item.visitId === parent.props.parent.visitId) {
                    if (item?.formIds?.length === 1) {
                        payload?.ruleFormActions.splice(index, 1)
                    }
                    else {
                        item?.formIds?.splice(fieldIndex, 1)
                    }
                }
                return null
            })
        }

        
        const _treeViewData = _.cloneDeep(destinationTreeeData)
        const _parent = parent.props.parent
        _treeViewData?.map((item: any, index: any) => {
            if (item.visitId === _parent.visitId) {
                item.children.map((child: any, ci: any) => {
                    if (child.children) {
                        child.children.map((subchild: any, sci: any) => {
                            if (subchild.id === node.id) {
                                _treeViewData[index].children[ci].children[sci].selected = event.target.checked
                            }
                            return null
                        })
                    } else {
                        if (child.id === node.id) {
                            _treeViewData[index].children[ci].selected = event.target.checked
                        }
                    }
                    return null
                })
            }
            return null
        })
        dispatch({ type: Types.GET_VISIT_TREE_DATA, payload: _treeViewData });
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: payload });
    }

    //Logic for selected forms
    let totalFormLength = 0;
    rule?.ruleFormActions?.map((item: any) => {
        totalFormLength = totalFormLength + item?.formIds?.length;
        return null
    })

    return (
        <React.Fragment>
            <div className="row">
                <div className='col-sm-10'>
                    <div className="d-flex drag-variable-header justify-content-between">
                        <div className='col-sm-3'>Select Forms from here</div>
                        <div className='col-sm-3'>Selected Forms : <span>{totalFormLength}</span> </div>
                    </div>
                    <div className='scroll'>
                        <TreeviewComponent
                            data={destinationTreeeData}
                            destinationCheckBox={true}
                            onCheckBoxClick={onCheckBoxClick}
                        />
                    </div>
                </div>
            </div>
        </React.Fragment>
    )
}

export default DestinationForm;
