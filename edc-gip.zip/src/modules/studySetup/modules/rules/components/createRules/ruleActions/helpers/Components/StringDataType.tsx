import React from "react";
import { extractOptions, extractResponseOption, extractRowCountOption, extractStrExpressions } from "../../../../../constants/util";
import SelectDropdown from "../../../../../helpers/SelectDropdown";
import SelectField from "../../../../../../../../../common/selectField/SelectField";
import { useSelector } from "react-redux";

function StringDataType(props: any) {
    const { item } = props
    const { ruleOperator } = useSelector((state: any) => state.rules);
    
    return (
        <React.Fragment>
            <div className="item-container align-items-center">
                <div className="d-flex">
                    <span className="Variable-Label">{item.fieldName}</span>
                    <div className="d-flex" onDrop={(e: any) => { e.preventDefault() }}>
                        <SelectField
                            id={item.fieldId}
                            className={'QDselect-visits'}
                            isDisabled={false}
                            isClearable={true}
                            isMulti={true}
                            value={item.visitIds}
                            onChange={props.onVisitChangeHandler}
                            options={extractOptions(item.visits)}
                        />
                        {item.fieldGroup?.groupId && <SelectField
                            id={item.fieldId}
                            className={'QDrowCount-Select'}
                            isDisabled={false}
                            isClearable={true}
                            isMulti={true}
                            value={item.fieldGroup.groupRows}
                            onChange={props.onRowCountChange}
                            options={extractRowCountOption(item.repeatMax)}
                            placeholder='Select Row Count'
                        />}
                        <SelectDropdown
                            className={`logic-visits`} id={''}
                            onChange={props.oneExpressionChange}
                            disabled={false}
                            value={item.configOperatorId}
                            defaultOption={'Select Expression'}
                            options={extractStrExpressions(ruleOperator)}
                        />
                        {item.responseOptions && item.responseOptions.length > 0 && <SelectDropdown
                            className={``}
                            id={''}
                            onChange={props.onValueChangeHandler}
                            disabled={false}
                            value={item.ruleTypeValue}
                            defaultOption={'Select response'}
                            options={extractResponseOption(item.responseOptions)}
                        />}
                        {!(item.responseOptions && item.responseOptions.length > 0) &&
                            <input placeholder={item.datatype.name === "integer" ? "Ex : 12, 5" : "Ex : na, 1, 1na"}
                                type={'text'} value={item.ruleTypeValue} onChange={props.onValueChangeHandler} />}
                    </div>
                </div>
            </div>
        </React.Fragment>
    )
}
export default StringDataType