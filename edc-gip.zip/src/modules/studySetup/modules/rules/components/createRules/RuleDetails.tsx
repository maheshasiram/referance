import React from "react";
import { useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { Types } from "../../reducer/types";
import _ from 'lodash';
import { ruleModal } from "../../constants/rules-modals";
import { fetchAllRulesByCriteria } from "../../actions/actions";
import { onActionTypeHandler } from "../../constants/util";

function RuleDetails(props: any) {
    const dispatch = useDispatch();
    const navigate = useNavigate()
    const { setTabValue } = props;
    const { ruleActionTypes, rule, rulesParams, validations, subjectStatus } = useSelector((state: any) => state.rules)

    const BackToAllRules = () => {
        navigate('/study/rules/')
        const _payload = { ...rulesParams, ruleName: '', formId: null ,status:true,offset: 0,first: 1,}
        dispatch({ type: Types.GET_RULES_PARAMS, payload: _payload })
        dispatch(fetchAllRulesByCriteria(_payload))
        dispatch({ type: Types.VALIDATE_RULE, payload: { target: "", logic: "" } })
    }

    const onActionChangeHandler = (e: any) => {
        const _configObj = ruleActionTypes.find((item: any) => item.id === parseInt(e.target.value))
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: onActionTypeHandler(_configObj ? _configObj : ruleModal.actionType, ruleModal) })
        dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, target: "", logic: "", ruleName: "", message: "", ruleSubjectStatusAction: "", toEmail: "" } })
    }
    const onSubjectStatusChange = (event: any,) => {
        const _subjectStatus = subjectStatus.find((item: any) => item.id === parseInt(event.target.value))
        const _subjectStatusPayload: any = _.cloneDeep(rule)
        _subjectStatusPayload.ruleSubjectStatusAction.subjectStatus = _subjectStatus;
        dispatch({
            type: Types.GET_CREATE_RULE_PAYLAOD, payload: {
                ...rule, ruleSubjectStatusAction: _subjectStatusPayload?.ruleSubjectStatusAction
            }
        })
        if (_subjectStatus) {
            dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, ruleSubjectStatusAction: "" } })
        } else {
            dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, ruleSubjectStatusAction: "Please select subject status" } })
        }
    }

    const onRuleNameChange = (e: any) => {
        const ruleName = e.target.value.toUpperCase();
        const _alphaRegex = (/^[a-zA-Z]+$/).test(e.target.value)
        const _alphaLength = (/^[a-zA-Z]{1,8}$/).test(e.target.value)
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: { ...rule, ruleName: ruleName } })
        if (ruleName) {
            if (!_alphaRegex) {
                dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, ruleName: "Rule Name must should contain only alphabets" } })
            } else if (!_alphaLength) {
                dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, ruleName: "Rule Name Allows Maximum 8 Characters" } })
            }
            else {
                dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, ruleName: "" } })
            }
        } else {
            dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, ruleName: "Please enter rule name" } })
        }
    }

    const onMessageChange = (e: any) => {
        if ((e.target.value.length <= 1 && !e.target.value.includes(' ')) || (e.target.value.length > 1 && !e.target.value.includes('  '))) {
            dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: { ...rule, message: e.target.value } })
        }
        const _msgRegex = (/^[a-zA-Z]/).test(e.target.value)
        if (e.target.value) {
            if (!_msgRegex) {
                dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, message: "Message should start with only text" } })
            } else {
                dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, message: "" } })
            }
        }
        else {
            dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, message: "Please enter message" } })
        }
    }
    const onToEmailChange = (e: any, type: string) => {
        const regex = /^[\W]*([\w+\-.%]+@[\w\-.]+\.[A-Za-z]{2,4}[\W]*,{1}[\W]*)*([\w+\-.%]+@[\w\-.]+\.[A-Za-z]{2,4})[\W]*$/
        const result = regex.test(e.target.value)
        const payload = { ...{}, ...rule }
        if (type === "to") {
            payload.ruleEmailAction.toEmail = e.target.value
            if (e.target.value) {
                if (!result) {
                    dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, toEmail: "Please enter correct email format" } })
                }
                else {
                    dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, toEmail: "" } })
                }
            }
            else {
                dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, toEmail: "Please enter email" } })
            }
        } else if (type === "cc") {
            payload.ruleEmailAction.ccEmail = e.target.value
            if (e.target.value && !result) {
                dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, ccEmail: "Please enter correct email format" } })
            }
            else {
                dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, ccEmail: "" } })
            }
        }
        dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: payload })
    }

    return (
        <React.Fragment>
            <div className="d-flex justify-content-between">
                <div className="left-container">
                    <span>Create Rules</span>
                </div>
                <div className="d-flex justify-content-end">
                    <div>
                        <button className="btn-eoutlined-secondary" onClick={BackToAllRules}>← Back To Rule</button>
                    </div>
                </div>
            </div>
            <div>
                <div className='row'>
                    <div className='form-group col' id=''>
                        <label htmlFor='txt-action' className="fontbold">Action :</label>
                        <select className="form-select form-control-lg"
                            value={rule?.actionType?.id}
                            disabled={rule?.id > 0 ? true : false}
                            onChange={(e) => onActionChangeHandler(e)}>
                            <option value="">-- Select Action --</option>
                            {ruleActionTypes && ruleActionTypes.map((item: any, index: number) => {
                                return (<option key={index} value={item.id}>{item.name}</option>)
                            })}
                        </select>
                    </div>
                    <div className='form-group col' id='' onDrop={(e: any) => { e.preventDefault() }}>
                        <label htmlFor='txt-roleDescription' className="fontbold">Rule Name :</label>
                        <input className="form-control"
                            value={rule?.ruleName.toUpperCase()}
                            disabled={rule?.id > 0 ? true : false}
                            placeholder="Rule name"
                            onChange={(e) => onRuleNameChange(e)} />
                        <div className='text-danger' >{validations.ruleName}</div>
                    </div>
                    {rule && rule.actionType?.code !== '' && <div>
                        <label className="">Message</label>
                        <div className="form-group " onDrop={(e: any) => { e.preventDefault() }}>
                            <textarea
                                className="form-control"
                                placeholder="Enter message"
                                value={rule?.message}
                                onChange={(e) => onMessageChange(e)}>
                            </textarea>
                        </div>
                        <div className='text-danger'>{validations.message}</div>
                    </div>}
                    {rule && rule.actionType?.code === "RUL_ACT_TYP_EMAIL_ACTION" &&
                        <div className='form-group'>
                            <label className="fontinfo">To</label>
                            <textarea className="form-control"
                                value={rule?.ruleEmailAction?.toEmail}
                                onChange={(e) => onToEmailChange(e, "to")}>

                            </textarea>
                            <div className='text-danger' >{validations.toEmail}</div>
                            <label className="fontinfo">CC</label>
                            <textarea
                                className="form-control"
                                value={rule?.ruleEmailAction?.ccEmail}
                                onChange={(e) => onToEmailChange(e, "cc")}>
                            </textarea>
                            <div className='text-danger'>{validations.ccEmail}</div>
                        </div>
                    }
                    {rule && rule.actionType?.code === "RUL_ACT_TYP_SUBJECT_STATUS_ACTION" && <div>
                        <label className="fontbold">Subject Status</label>
                        <select
                            className="form-select form-control-lg"
                            value={rule.ruleSubjectStatusAction?.subjectStatus?.id}
                            onChange={(e: any) => onSubjectStatusChange(e)}
                        >
                            <option value=''>--Select Subject Status--</option>
                            {subjectStatus && subjectStatus.map((item: any, index: number) => {
                                return (<option value={item.id} key={index}>{item.name}</option>)
                            })}

                        </select>
                        <div className='text-danger' >{validations.ruleSubjectStatusAction}</div>
                    </div>}
                </div>
            </div >
        </React.Fragment >
    )
}
export default RuleDetails;