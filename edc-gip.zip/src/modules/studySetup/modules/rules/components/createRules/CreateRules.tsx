import React, { useEffect, useRef } from "react";
import { useNavigate, useParams } from "react-router-dom";
import RuleDetails from "./RuleDetails";
import DependentAndDestination from "./DependentAndDestination";
import { useSelector, useDispatch } from "react-redux";
import { Types } from "../../reducer/types";
import { getTreeViewData, VisitFormTreeView, saveOrUpdateRule } from "../../actions/actions";
import { configDataType, toastAlert } from "../../../../../../actions/actions";
import CommonCard from "../../../../../../common/styleComponents/CommonCard";
import { editPayload } from "../../constants/util";
import { validateRule } from "../../constants/validet";
import _ from 'lodash';
import { ruleModal } from "../../constants/rules-modals";

function CreateRules() {
    const navigate = useNavigate()
    const dispatch = useDispatch()
    const params: any = useParams()
    const isLoading = useRef(false)
    const { rule, treeViewData, validations, destinatonVists, rulesParams, ruleSubFieldType } = useSelector((state: any) => state.rules);
    const { currentStudy, configCodes } = useSelector((state: any) => state.application);
    const [tabValue, setTabValue] = React.useState("0");
    useEffect(() => {
        if (!isLoading.current) {
            dispatch(getTreeViewData(currentStudy.id))
            dispatch(configDataType("RUL_ACT_TYP", (response: any) => {
                dispatch({ type: Types.FETCH_RULES_ACTION_TYPE, payload: response.RUL_ACT_TYP })
            }))
            dispatch(configDataType("SUB_STATUS", (response: any) => {
                dispatch({ type: Types.GET_SUBJECT_STATUS, payload: response.SUB_STATUS })
            }))
            dispatch(configDataType("RUL_CONDITION", (response: any) => {
                dispatch({ type: Types.GET_RUL_CONDITION, payload: response.RUL_CONDITION })
            }))
            dispatch(configDataType("RUL_OPERATOR", (response: any) => {
                dispatch({ type: Types.GET_RUL_OPERATOR, payload: response.RUL_OPERATOR })
            }))
            dispatch(configDataType("RUL_STATUS", (response: any) => {
                dispatch({ type: Types.GET_RUL_STATUS, payload: response.RUL_STATUS })
            }))
            dispatch(configDataType("RUL_TYPE", (response: any) => {
                dispatch({ type: Types.GET_RUL_TYPE, payload: response.RUL_TYPE })
            }))
            dispatch(configDataType("RUL_SUB_FIELD_TYPE", (response: any) => {
                dispatch({ type: Types.GET_RUL_SUB_FIELD_TYPE, payload: response.RUL_SUB_FIELD_TYPE })
            }))
            dispatch(configDataType("RUL_SUB_DATE_TYPE", (response: any) => {
                dispatch({ type: Types.GET_RUL_SUB_DATE_TYPE, payload: response.RUL_SUB_DATE_TYPE })
            }))
            dispatch(configDataType("RUL_SUB_TIME_TYPE", (response: any) => {
                dispatch({ type: Types.GET_RUL_SUB_TIME_TYPE, payload: response.RUL_SUB_TIME_TYPE })
            }))
            dispatch(VisitFormTreeView(currentStudy.id, rule));
            isLoading.current = true
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
   
    React.useEffect(() => {
        if (parseInt(params.id) > 0) {
            editPayload(dispatch, rule, params, treeViewData)
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [treeViewData]);

    const onCancel = () => {
        navigate('/study/rules')
        dispatch({ type: Types.VALIDATE_RULE, payload: { target: "", logic: "" } })
    }

    const onSubmitHandler = () => {
        const ValidateRule = validateRule(rule, dispatch, validations, destinatonVists, ruleSubFieldType)
        const payload: any = _.cloneDeep(rule)
        payload.id = rule.id > 0 ? rule.id : null
        payload.ruleEmailAction = (rule?.actionType?.code === "RUL_ACT_TYP_EMAIL_ACTION") ? rule?.ruleEmailAction : null
        //modifying Target as per PaYload
        let _target: any = { ...payload.targetField, visitIds: [] }
        _target.visitIds = payload.targetField?.visitIds.map((item: any) => item.value)
        _target.targetFieldGroup && (_target.targetFieldGroup.targetGroupRows = payload?.targetField?.targetFieldGroup?.targetGroupRows?.map((i: any) => i.value))
        _target = _.omit(_target, ['visits', 'repeatMax'])   // removing extra keys from the target
        payload.targetField = _target
        
        // Logic - removing Extra Keys from payload
        payload.ruleLogic.queryGrids.map((queryGrid: any, index: number) => {
            queryGrid.ruleFields.map((field: any, fieldIndex: number) => {
                field.visitIds = field.visitIds.map((i: any) => i.value)
                field.fieldGroup && field.fieldGroup.groupRows && (field.fieldGroup.groupRows = field?.fieldGroup?.groupRows.map((i: any) => i.value))
                field.fieldOrdinal = fieldIndex + 1
                field = _.omit(field, ['visits', 'repeatMax', 'responseType', 'responseOptions', 'datatype'])
                if ((payload.ruleLogic.queryGrids[index].ruleFields.length - 1) === fieldIndex) {
                    field.condition = null
                }
                if (field.ruleTypeField) {
                    field.ruleTypeField.visitIds = field.ruleTypeField.visitIds.map((i: any) => i.value)
                    field.ruleTypeField && field.ruleTypeField.fieldGroup && field.ruleTypeField.fieldGroup.groupRows && (field.ruleTypeField.fieldGroup.groupRows = field.ruleTypeField.fieldGroup.groupRows.map((i: any) => i.value))
                    field.ruleTypeField = _.omit(field.ruleTypeField, ['visits', 'repeatMax'])
                }
                payload.ruleLogic.queryGrids[index].ruleFields[fieldIndex] = field
                return null
            })
            if ((payload.ruleLogic.queryGrids.length - 1) === index) {
                payload.ruleLogic.queryGrids[index].condition = null
            }
            return null
        })
        //modifying payload for selected destination visit
        const selectedVisits = destinatonVists?.filter((visits: any) => visits?.status === true)
        selectedVisits?.map((selectedVisitIds: any) => {
            payload?.ruleVisitAction?.visitIds.push(selectedVisitIds.id)
            return null
        })
        if (ValidateRule) {
            dispatch(saveOrUpdateRule(payload, (response: any) => {
                if (response.status === 'error') {
                    dispatch(toastAlert({ status: 0, message: response.errorMessage, open: true }))
                }
                else if (!response.error) {
                    navigate('/study/rules')
                    dispatch({ type: Types.VALIDATE_RULE, payload: { ...validations, target: '', logic: "" } })
                    dispatch(toastAlert({ status: 1, message: !payload.id ? 'Rule Created Successfully' : 'Rule Updated Successfully', open: true }))
                    dispatch({ type: Types.GET_RULES_PARAMS, payload: { ...rulesParams, offset: 0, first: 1, ruleName: '', formId: null } })
                    dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: ruleModal })
                    dispatch({ type: Types.GET_VISIT_ASSIGNED_TOFORM, payload: [] })
                }
            }))
        }
    }
    return (
        <React.Fragment>
            <RuleDetails setTabValue={setTabValue} />
            <CommonCard>
                <div>
                    {rule && rule.actionType && rule.actionType?.code !== '' ? <DependentAndDestination
                        tabValue={tabValue}
                        setTabValue={setTabValue}
                    /> : <div className="alert alert-info" >Please Select Action from above Dropdown</div>}
                    {
                        (rule?.actionType) && <div className="ruleSubmitBtn">
                            <button className="btn-esecondary mx-2" type="button" onClick={onCancel}>Cancel</button>
                            <button className='btn-eprimary mt-3' type="submit" form='form-submit' onClick={onSubmitHandler}>Submit</button>
                        </div>
                    }
                </div>
            </CommonCard>
        </React.Fragment>
    )
}
export default CreateRules;