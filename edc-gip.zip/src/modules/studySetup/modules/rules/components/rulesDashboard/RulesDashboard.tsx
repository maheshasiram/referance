import React from "react";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { useSelector, useDispatch } from "react-redux";
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import { Confirm, toastAlert } from "../../../../../../actions/actions";
import { fetchAllFormsForRulesDefined, fetchAllRulesByCriteria, deleteRules, deleteAndRestoreRule } from "../../actions/actions";
import { NavLink } from "react-router-dom";
import { Types } from "../../reducer/types";
import CustomToolTip from "../../../../../../components/CustomToolTip";
import ReplayIcon from '@mui/icons-material/Replay';

function RulesDashboard(props: any) {
    const dispatch = useDispatch();
    const { selectedRule, setSelectedRule, setSelectdValue, onCheckedRule, setSearchByRule, setSelectForm } = props
    const { currentStudy } = useSelector((state: any) => state.application)
    const { rulesList, rulesParams } = useSelector((state: any) => state.rules)
    const [pageChange, setpageChange] = React.useState(false);

    //Single  Rule Delete
    const onDeleteRestoreRule = (rowData: any, type: string) => {
        let _id = (rowData.ruleId).toString()
        dispatch(Confirm({
            status: 0,
            message: type === "delete" ? "Are you sure you want to delete this rule ?" : "Are you sure you want to restore this rule?",
            onOk: () => {
                setSelectdValue({"rules": []})
                setSearchByRule("")
                setSelectForm("")
                const deleteRuleData: any = {}
                deleteRuleData[`${rowData.ruleId}`] = true
                let _payload = {
                    "rules": [
                        {
                            ruleId: rowData.ruleId,
                            status: type === "delete" ? false : true,
                            hardDeleteStatus: type === "hardDelete" ? true : false
                        }
                    ]
                }
                dispatch(deleteAndRestoreRule(_payload, (response: any) => {
                    const payload = { ...rulesParams, ruleName: "", formId: null, actionId: null }
                    dispatch(fetchAllRulesByCriteria(payload))
                    const _currentStudyPayload = currentStudy.id
                    dispatch(fetchAllFormsForRulesDefined(_currentStudyPayload))
                    dispatch({ type: Types.GET_RULES_PARAMS, payload: payload })
                    dispatch(toastAlert({
                        status: 1,
                        message: response,
                        open: true
                    }))
                }))
            }
        }));
    }

    //on Pagination Change
    const onPageChange = (event: any) => {
        setSelectdValue({"rules": []});
        setSelectedRule(null)
        if (((event.page > 0) || (pageChange && event.page === 0)) && (rulesParams.offset !== event.page)) {
            const _payload = { ...rulesParams, offset: event.first, first: event.page }
            dispatch({ type: Types.GET_RULES_PARAMS, payload: _payload })
            dispatch(fetchAllRulesByCriteria(_payload))
            setpageChange(true)
        }
    }

    const actionTemplate = (rowData: any) => {
        return (
            rowData.status ? <div className="d-flex align-items-center"
                onClick={(e) => e.stopPropagation()}>
                <CustomToolTip title="Edit Rule"><NavLink
                    to={`../createRules/${rowData.ruleId}`}><EditIcon sx={{ fontSize: 14, opacity: .8 }} />
                </NavLink>
                </CustomToolTip>
                <span> | </span>
                <CustomToolTip title="Delete Rule"><DeleteIcon sx={{ fontSize: 14, opacity: .8 }} className="text-danger" onClick={() => onDeleteRestoreRule(rowData, 'delete')} /></CustomToolTip>
            </div> : <div className="d-flex align-items-center">
                <CustomToolTip title="Restore Rule">
                    <ReplayIcon sx={{ fontSize: 20, opacity: .8 }} onClick={() => onDeleteRestoreRule(rowData, 'restore')} /></CustomToolTip>
                {rowData.status === false && <div>
                    <span> | </span>
                    <CustomToolTip title="Hard Delete Rule"><DeleteIcon sx={{ fontSize: 14, opacity: .8 }} className="text-danger" onClick={() => onDeleteRestoreRule(rowData, 'hardDelete')} /></CustomToolTip>
                </div>}
            </div>
        )
    }

    //onSelection of CheckBox in DataTable
    const onSelectionCheckbox = (e: any) => {
        setSelectedRule(e.value)
        onCheckedRule(e.value)
    }

    return (
        <React.Fragment>
            {rulesList &&
                <DataTable
                    scrollable
                    value={rulesList.rules}
                    selectionMode="multiple" selection={selectedRule} onSelectionChange={(e: any) => { onSelectionCheckbox(e) }}
                    emptyMessage="No Rules Are Available To Display."
                    lazy rows={rulesParams.limit}
                    paginator={(rulesList.rules && rulesList.totalRecords > 10) ? true : false}
                    totalRecords={rulesList && rulesList.totalRecords}
                    onPage={(e: any) => onPageChange(e)}
                    first={rulesParams.offset}
                    paginatorClassName="justify-content-end"
                    paginatorLeft
                    responsiveLayout="scroll"
                    stripedRows={true}
                >
                    {rulesParams.status && <Column selectionMode="multiple" headerStyle={{ width: '3em' }}></Column>}
                    <Column field="ruleName" header="Rule Name"></Column>
                    <Column field="actionName" header="Action Name" ></Column>
                    <Column field="description" header="Description" ></Column>
                    <Column body={actionTemplate} header="Action"></Column>
                </DataTable>}
        </React.Fragment >
    )
}
export default RulesDashboard;