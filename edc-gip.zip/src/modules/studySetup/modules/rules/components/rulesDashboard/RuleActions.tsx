import React from "react";
import { Types } from "../../reducer/types";
import { useSelector, useDispatch } from "react-redux";
import { NavLink } from "react-router-dom";
import { Confirm, configDataType, toastAlert } from "../../../../../../actions/actions";
import { fetchAllRulesByCriteria, fetchAllFormsForRulesDefined, deleteRules, deleteAndRestoreRule } from "../../actions/actions";
import SearchField from "../../../../../../common/searchField/SearchField";
import RulesDashboard from "./RulesDashboard";
import '../../styles/Styles.scss'
import { ruleModal } from "../../constants/rules-modals";
import PageCount from "../../../../../../common/pagecount/PageCount";

function RuleActions() {
    const dispatch = useDispatch();
    const loaded = React.useRef(false);
    const { currentStudy } = useSelector((state: any) => state.application)
    const { rulesParams, formsList, ruleActionTypes, ruleActions, rulesList } = useSelector((state: any) => state.rules)
    const [selectedRule, setSelectedRule] = React.useState(null);
    const [searchByRule, setSearchByRule] = React.useState("")
    const [selectdValue, setSelectdValue]: any = React.useState({"rules": []});
    const [selectForm, setSelectForm] = React.useState("")
    const [selectActionForm, setSelectActionForm] = React.useState("")
    const [disableClearButton, setDisableButton] = React.useState(true)

    React.useEffect(() => {
        if (!loaded.current) {
            const rulePayload = { ...rulesParams }
            dispatch(fetchAllRulesByCriteria(rulePayload))
            const currentStudyPayload = currentStudy.id
            dispatch(fetchAllFormsForRulesDefined(currentStudyPayload))
            dispatch(configDataType("RUL_ACT_TYP", (response: any) => {
                dispatch({ type: Types.FETCH_RULES_ACTION_TYPE, payload: response.RUL_ACT_TYP })
            }))
            loaded.current = true
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    //FormsList Dropdown Functionality
    const onformNameChange = (value: any) => {
        const rulespayload = { ...rulesParams }
        setSelectForm(value.target.value);
        setDisableButton(false)
        setSelectActionForm("")
        setSelectedRule(null)
        setSearchByRule("")
        setSelectdValue({"rules": []})
        const _payload = { ...rulesParams, offset: 0, formId: value.target.value, actionId: null, ruleName: "" }
        dispatch({ type: Types.GET_RULES_PARAMS, payload: _payload })
        const _rulesAction: any = [];
        dispatch(fetchAllRulesByCriteria(_payload, (response: any) => {
            ruleActionTypes.map((ele: any) => {
                if (response.rules && response.rules.findIndex((item: any) => item.actionName === ele.name) !== -1) {
                    _rulesAction.push(ele);
                }
                return null
            });
            dispatch({ type: Types.GET_ALL_TABLE_DATA, payload: response.data })
        }));
        dispatch({ type: Types.RULE_ACTION_BY_DATA, payload: _rulesAction })
    }

    //Action Dropdown functionality
    const onActionChange = (e: any) => {
        setSelectActionForm(e.target.value)
        const _payload = { ...rulesParams, offset: 0, actionId: e.target.value }
        dispatch(fetchAllRulesByCriteria(_payload))
        dispatch({ type: Types.GET_RULES_PARAMS, payload: _payload })
    }

    //on Rule Name Search
    const onRuleNameSearch = (e: any) => {
        setSearchByRule(e.target.value)
        if (e.target.value) {
            setSelectActionForm("")
            setSelectForm("")
        }
        const _payload = { ...rulesParams, ruleName: e.target.value, offset: 0, formId: null, actionId: null }
        dispatch({ type: Types.GET_RULES_PARAMS, payload: _payload })
        dispatch(fetchAllRulesByCriteria(_payload))
    }

    //Rule Name Clear
    const onClearRuleName = () => {
        setSearchByRule("")
        setSelectedRule(null)
        const _payload = { ...{}, ...rulesParams, ruleName: '', offset: 0 }
        dispatch({ type: Types.GET_RULES_PARAMS, payload: _payload })
        dispatch(fetchAllRulesByCriteria(_payload))
    }

    //On Checked on CheckBox on Each Rule and All Rules
    const onCheckedRule = (value: any) => {
        const idsList: any = {"rules": []};
        value.map((ele: any) => {
            idsList.rules.push(
                {
                    ruleId: ele.ruleId,
                    status: false,
                    hardDeleteStatus: false
                }
            )
        })
        setSelectdValue(idsList)
    }

    //FormName ActionName Dropdown Clears
    const onClearFormAndActionValue = () => {
        setSelectForm("")
        setSelectedRule(null)
        setDisableButton(true)
        setSelectActionForm("")
        const _payload = { ...{}, ...rulesParams, offset: 0, actionId: null, formId: null, ruleName: "" }
        dispatch({ type: Types.GET_RULES_PARAMS, payload: _payload })
        dispatch(fetchAllRulesByCriteria(_payload))
    }

    //Multiple Rules Delete
    const onMultipleDeleteRules = () => {
        dispatch(Confirm({
            status: 0,
            message: "Are you sure you want to delete all this rules ?",
            onOk: () => {
                setSelectdValue({"rules": []})
                setSearchByRule("")
                setSelectForm("")
                dispatch(deleteAndRestoreRule(selectdValue, (response: any) => {
                    const payload = { ...rulesParams, ruleName: "", offset: 0, formId: null, actionId: null }
                    setSelectedRule(null)
                    dispatch(fetchAllRulesByCriteria(payload))
                    const _currentStudyPayload = currentStudy.id
                    dispatch(fetchAllFormsForRulesDefined(_currentStudyPayload))
                    dispatch({ type: Types.GET_RULES_PARAMS, payload: payload })
                    dispatch(toastAlert({
                        status: 1,
                        message: response,
                        open: true
                    }))
                }))
            }
        }));
    }
    const onChangePageCount = (e: any) => {
        const payload = { ...rulesParams, ruleName: "", formId: null, actionId: null, limit: parseInt(e.target.value) }
        dispatch({ type: Types.GET_RULES_PARAMS, payload: payload })
        dispatch(fetchAllRulesByCriteria(payload))
    }

    const onActiveInactiveFilterHandler = (e: any) => {
        const payload = { ...rulesParams, status: e.target.value === "active" ? true : false, offset: 0 }
        dispatch({ type: Types.GET_RULES_PARAMS, payload: payload })
        dispatch(fetchAllRulesByCriteria(payload))
    }

    return (
        <React.Fragment>
            <div className="d-flex justify-content-between pb-2 controls-container ruleContainer">
                <div className=" d-flex">
                    <div className="left-container">
                        <span>All Rules</span>
                    </div>
                </div>
                <div className="right-panel d-flex">
                    <NavLink className="btn-eoutlined-secondary me-1"
                        onClick={() => { dispatch({ type: Types.GET_CREATE_RULE_PAYLAOD, payload: ruleModal }) }}
                        to={`../createRules/0`}>Create Rule
                    </NavLink>
                    <SearchField
                        value={searchByRule.toUpperCase()}
                        placeholder="Search by rule name"
                        onChange={onRuleNameSearch}
                        onClearSearch={onClearRuleName}
                    />
                </div>
            </div>
            <div className="row">
                <div className="col-4 align-item-start d-inline-flex">
                    <PageCount onChange={(e: any) => onChangePageCount(e)} />
                </div>
                <div className="col-8 d-flex flex-row-reverse">
                    <div className=" mt-2">
                        <div className="d-flex justify-content-between ">
                            <div className="d-flex">
                                <div className="d-flex">
                                    <span className="mt-1 me-3">Form :</span>
                                    <select
                                        className="form-select-box"
                                        onChange={onformNameChange}
                                        value={selectForm}
                                    >
                                        <option value=''>--Select Form Name--</option>
                                        {formsList && formsList.map((item: any, index: number) => {
                                            return (<option key={index} value={item.id}>{item.formName}</option>)
                                        })}
                                    </select>
                                </div>
                                <div className="d-flex justify-content-center actionContainer">
                                    <div className="action-select-field">
                                        <select
                                            className="select select-box"
                                            onChange={onActionChange}
                                            value={selectActionForm}
                                            disabled={!selectForm ? true : false}
                                        >
                                            <option value='' >--Select Action--</option>
                                            {ruleActions && ruleActions.map((item: any, index: number) => {
                                                return (<option key={index} value={item.id}>{item.name}</option>)
                                            })}
                                        </select>
                                    </div>
                                </div>
                                <div className="ms-2" onChange={onActiveInactiveFilterHandler}>
                                    <select>
                                        <option value="active">Active</option>
                                        <option value="inActive">In active</option>
                                    </select>
                                </div>
                                <div>
                                    <button disabled={disableClearButton} className="btn-eoutlined-secondary mx-1" onClick={onClearFormAndActionValue}>Clear</button>
                                </div>
                                <div>
                                    {selectdValue?.rules.length > 0 ? <button className="btn-eoutlined-danger ms-3" onClick={onMultipleDeleteRules}>Delete Rule</button> : null}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="mt-2">
                <RulesDashboard
                    onCheckedRule={onCheckedRule}
                    selectedRule={selectedRule}
                    setSelectedRule={setSelectedRule}
                    setSelectdValue={setSelectdValue}
                    setSearchByRule={setSearchByRule}
                    setSelectForm={setSelectForm}
                />
            </div>
        </React.Fragment>
    )
}
export default RuleActions;