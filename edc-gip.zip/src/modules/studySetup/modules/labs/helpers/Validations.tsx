import * as Yup from 'yup';

export const createLabSchema = Yup.object().shape({
    name: Yup.string()
        .required("Enter the lab name"),
    shortName: Yup.string()
        .required("Enter the lab short name"),
    region: Yup.string()
        .required("Select the region"),
    countryId: Yup.string()
        .required("Select the country"),
    stateId: Yup.string()
        .required("Select the state"),
    cityId: Yup.string()
        .required("Select the city"),
    categoryName: Yup.string()
        .required("Select the category"),
    testName: Yup.string()
        .required("Please select test name"),

})

export const labTestValidation = Yup.object().shape({
    categoryId: Yup.string()
        .required('Select category name'),
    testName: Yup.string()
        .required('Enter test name'),
    testDescription: Yup.string()
        .required('Enter test description')
})



export const categoryValidation = Yup.object().shape({
    name: Yup.string()
        .required("Enter category name"),
    // .matches(/^[^\s]/, "Group Name Should Not Start With Space"),

    description: Yup.string()
        .required("Enter description")
    // .matches(/^[^\s]/, "Description Should Not Start With Space")\
})

export const createUnitValidation = () => Yup.object().shape({
    testId: Yup.string().required("Select test"),
    categoryId: Yup.string().required("Select group name"),
    unitName: Yup.string().required("Enter unit name").matches(/^[^\s]/, "Unit name Should Not Start With Space")

})


export const labRangeValidation = () => {
    return Yup.object().shape({
        labRange: Yup.array().of(Yup.object({
            refUpperRange: Yup.string()
                .required('Enter upper limit')
            //     .min(1, 'Upper limit should be greater than zero')
            //     .max(100, 'Upper limit can not be more than 100')
            //     .typeError('Enter upper limit')
            ,
            refLowerRange: Yup.string()
                .required('Enter Lower Limit'),
            // typeError('Enter Lower limit')
            //     .min(1, 'Lower limit should be greater than zero')
            // .max(100, 'Lower limit can not be more than 100'),
            ageMin: Yup.number()
                .required('Enter Minimum Age').typeError('Enter Minimum Age')
                .min(1, 'Minimum age limit should be greater than zero')
                .max(100, 'Minimum age limit can not be more than 100'),
            ageMax: Yup.number()
                .required('Enter Maximum limit').typeError('Enter Maximum limit')
                .min(1, 'Maximum age limit should be greater than zero')
                .max(100, 'Maximum limit can not be more than 100'),
            gender: Yup.string().required('Enter the gender')
        }))
    })
}

