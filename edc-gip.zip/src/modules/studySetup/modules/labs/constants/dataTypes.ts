

export type labDataType = {
    labId?: number,
    name?: string,
    shortName?: string,
    region?: string,
    countryId?: string,
    stateId?: string,
    cityId?: string,
    status?: boolean,
    categoryName?: string,
    testName?: string
}


export type testDataType = {
    testId?: number,
    categoryId?: string,
    testDescription?: string,
    testName?: string
}

export type categoryDataType = {
    id?: number,
    name?: string,
    description?: any
}

export type unitDataType = {
    unitId?: number,
    categoryId?: string,
    testId?: string,
    unitName?: any,
}

export type labRangeDataType = {
    labRange: [{
        refUpperRange?: string,
        refLowerRange?: string,
        ageMin?: number,
        ageMax?: number,
        gender?: string,
        labId?: number,
        id?: number
    }]
}

export type fetchLabRangeDataType = {
    labId?: number,
    limit?: number,
    offset?: number
}