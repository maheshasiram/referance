export const labRangeData = {
    data: [
        {
            id: 1,
            upperLimit: 3453,
            lowerLimit: 345,
            minAge: 24,
            maxAge: 75,
            gender: 'female'
        },
        {
            id: 1,
            upperLimit: 5453,
            lowerLimit: 245,
            minAge: 25,
            maxAge: 65,
            gender: 'male'
        },
        {
            id: 3,
            upperLimit: 6453,
            lowerLimit: 445,
            minAge: 26,
            maxAge: 85,
            gender: 'female'
        },
        {
            id: 4,
            upperLimit: 8453,
            lowerLimit: 345,
            minAge: 14,
            maxAge: 75,
            gender: 'male'
        },
        {
            id: 5,
            upperLimit: 9453,
            lowerLimit: 145,
            minAge: 34,
            maxAge: 85,
            gender: 'female'
        },
    ]
}