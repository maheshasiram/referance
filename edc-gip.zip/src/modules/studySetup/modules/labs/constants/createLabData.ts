export const createLabData = {
    totalRecords: 14,
    "LabData":
        [
            {
                name: 'Lab Name',
                shortName: 'lbname',
                region: {
                    id: 1,
                    name: '(UTC-12:00) International Date Line West'
                },
                country: {
                    "id": 1,
                    "name": "AfghanistaN",
                    "countryCode": "Af",
                    "phoneCode": 11
                },
                city: {
                    "id": 5909,
                    "name": "Eshkashem",
                    "state": {
                        "id": 42,
                        "name": "Badakhshan",
                        "country": {
                            "id": 1,
                            "name": "AfghanistaN",
                            "countryCode": "Af",
                            "phoneCode": 11
                        }
                    }
                },
                state: {
                    "id": 42,
                    "name": "Badakhshan",
                    "country": {
                        "id": 1,
                        "name": "AfghanistaN",
                        "countryCode": "Af",
                        "phoneCode": 11
                    }
                },
                group: {
                    "id": 71,
                    "name": "newcategory",
                    "description": "category",
                    "status": true
                }
                // group: 'Hemotology',
                // testName:'Sample Test',
                // units:'01-10'
            },

            {
                name: 'Lab Name',
                shortName: 'lbname',
                // region: 'USA',
                region: {
                    id: 1,
                    name: '(UTC-11:00) Coordinated Universal Time-11'
                },
                country: {
                    "id": 3,
                    "name": "Algeria",
                    "countryCode": "DZ",
                    "phoneCode": 213
                },
                city: {
                    "id": 5910,
                    "name": "Fayzabad",
                    "state": {
                        "id": 42,
                        "name": "Badakhshan",
                        "country": {
                            "id": 1,
                            "name": "AfghanistaN",
                            "countryCode": "Af",
                            "phoneCode": 11
                        }
                    }
                },
                state: {
                    "id": 43,
                    "name": "Badgis",
                    "country": {
                        "id": 1,
                        "name": "AfghanistaN",
                        "countryCode": "Af",
                        "phoneCode": 11
                    }
                },
                group: {
                    "id": 70,
                    "name": "blab",
                    "description": "alab",
                    "status": true
                }
                // testName:'Sample Test',
                // units:'01-10'
            },

            {
                name: 'Lab Name',
                shortName: 'lbname',
                // region: 'East Asia',
                region: {
                    id: 1,
                    name: '(UTC-10:00) Hawaii	'
                },
                country: {
                    "id": 5,
                    "name": "Andorra",
                    "countryCode": "AD",
                    "phoneCode": 376
                },
                city: {
                    "id": 5911,
                    "name": "Jurm",
                    "state": {
                        "id": 42,
                        "name": "Badakhshan",
                        "country": {
                            "id": 1,
                            "name": "AfghanistaN",
                            "countryCode": "Af",
                            "phoneCode": 11
                        }
                    }
                },
                state: {
                    "id": 44,
                    "name": "Baglan",
                    "country": {
                        "id": 1,
                        "name": "AfghanistaN",
                        "countryCode": "Af",
                        "phoneCode": 11
                    }
                },
                group: {

                    "id": 2,
                    "name": "Hematology",
                    "description": "BloodTest",
                    "status": true
                }
                // testName:'Sample Test',
                // units:'01-10'
            },

            {
                name: 'Lab Name',
                shortName: 'lbname',
                // region: 'South Asia'
                region: {
                    id: 1,
                    name: '(UTC-09:00) Alaska	'
                },
                country: {
                    "id": 7,
                    "name": "Anguilla",
                    "countryCode": "AI",
                    "phoneCode": 1264
                },
                city: {
                    "id": 5912,
                    "name": "Khandud",
                    "state": {
                        "id": 42,
                        "name": "Badakhshan",
                        "country": {
                            "id": 1,
                            "name": "AfghanistaN",
                            "countryCode": "Af",
                            "phoneCode": 11
                        }
                    }
                },
                state: {
                    "id": 45,
                    "name": "Balkh",
                    "country": {
                        "id": 1,
                        "name": "AfghanistaN",
                        "countryCode": "Af",
                        "phoneCode": 11
                    }
                },
                group: {
                    "id": 3,
                    "name": "BioChemistry",
                    "description": "BioTestForm",
                    "status": true
                }
                // testName:'Sample Test',
                // units:'01-10'
            },

            {
                name: 'Lab Name',
                shortName: 'lbname',
                // region: 'North US'
                region: {
                    id: 1,
                    name: '(UTC-08:00) Baja California	'
                },
                country: {
                    "id": 9,
                    "name": "Antigua And Barbuda",
                    "countryCode": "AG",
                    "phoneCode": 1268
                },
                city: {
                    "id": 5913,
                    "name": "Qal'eh-ye Panjeh",
                    "state": {
                        "id": 42,
                        "name": "Badakhshan",
                        "country": {
                            "id": 1,
                            "name": "AfghanistaN",
                            "countryCode": "Af",
                            "phoneCode": 11
                        }
                    }
                },
                state: {
                    "id": 46,
                    "name": "Bamiyan",
                    "country": {
                        "id": 1,
                        "name": "AfghanistaN",
                        "countryCode": "Af",
                        "phoneCode": 11
                    }
                },
                group: {
                    "id": 4,
                    "name": "Labcategorytest",
                    "description": "Lab",
                    "status": true
                }
                // testName:'Sample Test',
                // units:'01-10'
            },
            {
                name: 'Lab Name',
                shortName: 'lbname',
                // region: 'South US'
                region: {
                    id: 1,
                    name: '(UTC-08:00) Pacific Time (US and Canada)'
                },
                country: {
                    "id": 11,
                    "name": "Armenia",
                    "countryCode": "AM",
                    "phoneCode": 374
                },
                city: 'Hyderabad',
                state: {
                    "id": 47,
                    "name": "Farah",
                    "country": {
                        "id": 1,
                        "name": "AfghanistaN",
                        "countryCode": "Af",
                        "phoneCode": 11
                    }
                },
                group: {
                    "id": 30,
                    "name": "ptest",
                    "description": "Lab",
                    "status": true
                }
                // testName:'Sample Test',
                // units:'01-10'
            },
            {
                name: 'Lab Name',
                shortName: 'lbname',
                region: {
                    id: 1,
                    name: '(UTC-07:00) Chihuahua, La Paz, Mazatlan'
                },
                country: {
                    "id": 13,
                    "name": "Australia",
                    "countryCode": "AU",
                    "phoneCode": 61
                },
                city: 'Hyderabad',
                state: {
                    "id": 48,
                    "name": "Faryab",
                    "country": {
                        "id": 1,
                        "name": "AfghanistaN",
                        "countryCode": "Af",
                        "phoneCode": 11
                    }
                },
                group: {
                    "id": 22,
                    "name": "#$%^DF",
                    "description": "#$%^&fvd",
                    "status": true
                }
                // testName:'Sample Test',
                // units:'01-10'
            },
            {
                name: 'Lab Name',
                shortName: 'lbname',
                region: {
                    id: 1,
                    name: '(UTC-07:00) Arizona	America/Phoenix'
                },
                country: {
                    "id": 15,
                    "name": "Azerbaijan",
                    "countryCode": "AZ",
                    "phoneCode": 994
                },
                city: 'Hyderabad',
                state: {
                    "id": 49,
                    "name": "Gawr",
                    "country": {
                        "id": 1,
                        "name": "AfghanistaN",
                        "countryCode": "Af",
                        "phoneCode": 11
                    }
                },
                group: {
                    "id": 63,
                    "name": "s",
                    "description": "s",
                    "status": true
                }
                // testName:'Sample Test',
                // units:'01-10'
            },
            {
                name: 'Lab Name',
                shortName: 'lbname',
                region: {
                    id: 1,
                    name: '(UTC-07:00) Mountain Time (US and Canada)	'
                },
                country: {
                    "id": 17,
                    "name": "Bahrain",
                    "countryCode": "BH",
                    "phoneCode": 973
                },
                city: 'Hyderabad',
                state: {
                    "id": 50,
                    "name": "Gazni",
                    "country": {
                        "id": 1,
                        "name": "AfghanistaN",
                        "countryCode": "Af",
                        "phoneCode": 11
                    }
                },
                group: {
                    "id": 6,
                    "name": "CBP",
                    "description": "Lab",
                    "status": true
                }
                // testName:'Sample Test',
                // units:'01-10'
            },
            {
                name: 'Lab Name',
                shortName: 'lbname',
                region: {
                    id: 1,
                    name: '(UTC-06:00) Central America	'
                },
                country: {
                    "id": 19,
                    "name": "Barbados",
                    "countryCode": "BB",
                    "phoneCode": 1246
                },
                city: 'Hyderabad',
                state: {
                    "id": 51,
                    "name": "Herat",
                    "country": {
                        "id": 1,
                        "name": "AfghanistaN",
                        "countryCode": "Af",
                        "phoneCode": 11
                    }
                },
                group: {
                    "id": 14,
                    "name": "ups1",
                    "description": "desved",
                    "status": true
                }
                // testName:'Sample Test',
                // units:'01-10'
            },
            {
                name: 'Lab Name',
                shortName: 'lbname',
                region: {
                    id: 1,
                    name: '(UTC-06:00) Central Time (US and Canada)'
                },
                country: {
                    "id": 21,
                    "name": "Belgium",
                    "countryCode": "BE",
                    "phoneCode": 32
                },
                city: 'Hyderabad',
                state: {
                    "id": 52,
                    "name": "Hilmand",
                    "country": {
                        "id": 1,
                        "name": "AfghanistaN",
                        "countryCode": "Af",
                        "phoneCode": 11
                    }
                },
                group: {
                    "id": 9,
                    "name": "Test",
                    "description": "Lab",
                    "status": true
                }
                // testName:'Sample Test',
                // units:'01-10'
            },
            {
                name: 'Lab Name',
                shortName: 'lbname',
                // region: 'Asia'
                region: {
                    id: 1,
                    name: '(UTC-06:00) Saskatchewan'
                },
                country: {
                    "id": 23,
                    "name": "Benin",
                    "countryCode": "BJ",
                    "phoneCode": 229
                },
                city: 'Hyderabad',
                state: {
                    "id": 53,
                    "name": "Jawzjan",
                    "country": {
                        "id": 1,
                        "name": "AfghanistaN",
                        "countryCode": "Af",
                        "phoneCode": 11
                    }
                },
                group: {
                    "id": 15,
                    "name": "Testing",
                    "description": "Labs",
                    "status": true
                }
                // testName:'Sample Test',
                // units:'01-10'
            },
            {
                name: 'Lab Name',
                shortName: 'lbname',
                // region: 'Asia'
                region: {
                    id: 1,
                    name: '(UTC-06:00) Guadalajara, Mexico City, Monterey America'
                },
                country: {
                    "id": 25,
                    "name": "Bhutan",
                    "countryCode": "BT",
                    "phoneCode": 975
                },
                city: 'Hyderabad',
                state: {
                    "id": 54,
                    "name": "Kabul",
                    "country": {
                        "id": 1,
                        "name": "AfghanistaN",
                        "countryCode": "Af",
                        "phoneCode": 11
                    }
                },
                group: {
                    "id": 51,
                    "name": "Testy",
                    "description": "Lab",
                    "status": true
                }
                // testName:'Sample Test',
                // units:'01-10'
            },
            {
                name: 'Lab Name',
                shortName: 'lbname',
                // region: 'Asia'
                region: {
                    id: 1,
                    name: '(UTC-05:00) Bogota, Lima'
                },
                country: {
                    "id": 27,
                    "name": "Bosnia and Herzegovina",
                    "countryCode": "BA",
                    "phoneCode": 387
                },
                city: 'Hyderabad',
                state: {
                    "id": 55,
                    "name": "Kapisa",
                    "country": {
                        "id": 1,
                        "name": "AfghanistaN",
                        "countryCode": "Af",
                        "phoneCode": 11
                    }
                },
                group: {
                    "id": 12,
                    "name": "Diabetes",
                    "description": "Lab",
                    "status": true
                }
                // testName:'Sample Test',
                // units:'01-10'
            }

        ]
}