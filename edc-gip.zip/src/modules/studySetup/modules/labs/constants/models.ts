import { labDataType, unitDataType, testDataType, categoryDataType, labRangeDataType, fetchLabRangeDataType } from './dataTypes'

export const labModel: labDataType = {
    labId: 0,
    name: "",
    shortName: "",
    region: "",
    countryId: "",
    stateId: "",
    cityId: "",
    status: true,
    categoryName: "",
    testName: ""
}


export const testModel: testDataType = {
    testId: 0,
    categoryId: '',
    testDescription: '',
    testName: ''
}
export const categoryModel: categoryDataType = {
    id: 0,
    name: '',
    description: ''
}
export const unitModel: unitDataType = {
    unitId: 0,
    testId: '',
    categoryId: '',
    unitName: ['']
}

export const searchBy = [
    { id: 'testName', name: 'Test Name' },
    { id: 'category', name: 'Category Name' },
]

export const genderValues = [
    { id: 'female', name: 'Female' },
    { id: 'male', name: 'Male' },
    { id: 'other', name: 'Other' }
]

export const labRangeModel: labRangeDataType = {
    labRange: [{
        refUpperRange: '',
        refLowerRange: '',
        ageMin: NaN,
        ageMax: NaN,
        gender: '',
        labId: NaN,
        id: 0
    }]
}

export const fetchlabRangeModel: fetchLabRangeDataType = {
    "labId": 0,
    "limit": 10,
    "offset": 0
}

