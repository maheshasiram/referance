import React from "react";
import CustomDialog from "../../../../../../common/modals/CustomeDialog";
import { ErrorMessage, Field, Form, Formik } from "formik";
import { useDispatch, useSelector } from "react-redux";
import { Types } from "../../../../../../constants/Types";
import { createLabSchema } from "../../helpers/Validations";
import { labModel } from "../../constants/models";
import { findCitiesByStateId, findStateByCountryId, toastAlert, } from "../../../../../../actions/actions";
import { timeZone } from "../../constants/timeZone";
import { Types as LabTypes } from "../../reducer/Types";
import { createLab, fetchAllLabs, getAllCategoriesList, getTestNameByCategoryId, updateLab } from "../../actions/actions";
import CustomToolTip from "../../../../../../components/CustomToolTip";
import EditIcon from '@mui/icons-material/Edit';

function AddEditLab(props: any) {
    const dispatch = useDispatch()
    const [btnDisable, setBtnDisable] = React.useState(true)
    const [open, setOpen] = React.useState(false);
    const { lab, categoriesList, testByCatoegoryId, tableparams } = useSelector((state: any) => state.labs);
    const { allCountries, allStates, allCities } = useSelector((state: any) => state.application)
    const { rowData } = props;
    const [erroeMsg, setErroeMsg] = React.useState('');


    const onCloseHandle = () => {
        setOpen(false)
        setErroeMsg('');
        setBtnDisable(true)
        dispatch({ type: LabTypes.CREATE_LAB, payload: labModel });
        dispatch({ type: LabTypes.TESTS_LIST_DATA, payload: null })
    }


    const onLabNameChange = (e: any, setFieldValue: any, setFieldTouched: any) => {
        if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
            setFieldTouched('name', true)
            setFieldValue('name', e.target.value)
            setBtnDisable(false)
        }
    }

    const onCountryChange = (e: any, setFieldTouched: any, setFieldValue: any) => {
        dispatch(findStateByCountryId(e.target.value))
        setFieldValue('countryId', e.target.value);
        dispatch({ type: Types.FETCH_STATES_BY_COUNTRY_ID, payload: [] })
        dispatch({ type: Types.FETCH_CITIES_BY_STATE_ID, payload: [] })
        setBtnDisable(false)
    }

    const onCategoryChange = (e: any, setFieldValue: any, setFieldTouched: any) => {
        const _category = categoriesList.data.find((item: any) => item.name === e.target.value);
        setFieldTouched('categoryName', true)
        setFieldValue('categoryName', _category.name)
        setBtnDisable(false)
        if (e.target.value !== "") {
            dispatch(getTestNameByCategoryId(_category.id, (response: any) => {
                if (response.status === "error") {
                    setErroeMsg(response.errorMessage);
                    dispatch({ type: LabTypes.TESTS_LIST_DATA, payload: [] })
                } else {
                    setErroeMsg('');
                }
            }))
        } else {
            dispatch({ type: LabTypes.TESTS_LIST_DATA, payload: [] })
        }
    }

    const onTestChange = (e: any, setFieldValue: any, setFieldTouched: any) => {
        setFieldTouched('testName', true)
        setFieldValue('testName', e.target.value)
        setBtnDisable(false)
    }

    const onShortLabNameChange = (e: any, setFieldValue: any, setFieldTouched: any) => {
        if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
            setFieldTouched('shortName', true)
            setFieldValue('shortName', e.target.value)
            setBtnDisable(false)
        }
    }

    const onStateNameChange = (e: any, setFieldValue: any, setFieldTouched: any) => {
        console.log("83----------------",setFieldTouched)
        setFieldValue('stateId', e.target.value)
        dispatch(findCitiesByStateId(e.target.value))
        setBtnDisable(false)
    }

    const onRegionChange = (e: any, setFieldValue: any, setFieldTouched: any) => {
        setFieldValue('region', e.target.value)
        setFieldTouched('region', true)
        setBtnDisable(false)
    }

    const onCityChange = (e: any, setFieldValue: any, setFieldTouched: any) => {
        console.log(setFieldTouched)
        setFieldValue('cityId', e.target.value)
        setBtnDisable(false)
    }

    const onSubmitHandler = (values: any) => {
        const _payload = {
            ...values,
            cityId: parseInt(values.cityId),
            countryId: parseInt(values.countryId),
            stateId: parseInt(values.stateId),
        }
        dispatch((!_payload.labId ? createLab : updateLab)(_payload, (response: any) => {
            if (response.status === "error") {
                setErroeMsg(response.errorMessage);
            } else {
                setErroeMsg('');
                onCloseHandle();
                dispatch(toastAlert({ status: 1, message: `${values.name}${response}`, open: true }))
                dispatch((!_payload.unitId ? fetchAllLabs({ ...tableparams, limit: 10, offset: 0 }) : fetchAllLabs({ ...tableparams, limit: 10, offset: 0 })))
                setOpen(false)
            }
        }));
    }

    const onOpenLabDialog = (type: any) => {
        setOpen(true);
        setBtnDisable(true);
        if (type === 'add') {
            dispatch(getAllCategoriesList())
            dispatch({ type: LabTypes.CREATE_LAB, payload: labModel })
            dispatch({ type: Types.FETCH_STATES_BY_COUNTRY_ID, payload: [] })
            dispatch({ type: Types.FETCH_CITIES_BY_STATE_ID, payload: [] })
        } else {
            console.log("rowData 117", rowData)
            dispatch(getAllCategoriesList())
            dispatch(findStateByCountryId(rowData.countryId))
            dispatch(findCitiesByStateId(rowData.stateId))
            dispatch(getTestNameByCategoryId(rowData.categoryId))
            dispatch({ type: LabTypes.CREATE_LAB, payload: rowData ? rowData : labModel })
        }
    }

    return (
        <React.Fragment>
            {rowData && rowData.id !== 0 ?
                <CustomToolTip title='Edit Lab'><EditIcon sx={{ fontSize: 14, opacity: .8 }} onClick={() => onOpenLabDialog('edit')} /></CustomToolTip> :
                <button className="btn-eoutlined-secondary me-1" onClick={() => onOpenLabDialog('add')} >Create Lab</button>
            }
            <CustomDialog
                title={rowData && rowData.id !== 0 ? 'Update Lab' : 'Create Lab'}
                open={open}
                form='createLabForm'
                onClose={onCloseHandle}
                actionType={rowData && rowData.id !== 0 ? 'Update' : 'Create'}
                maxWidth="md"
                fullWidth={true}
                disabled={btnDisable}
            >
                <Formik
                    enableReinitialize={true}
                    validateOnBlur={false}
                    initialValues={lab}
                    onSubmit={(values) => { onSubmitHandler(values) }}
                    validationSchema={createLabSchema}>
                    {({  values, setFieldValue, setFieldTouched }) => (
                        <Form id='createLabForm'>
                            {erroeMsg ? <span className="d-flex justify-content-center text-danger">{erroeMsg}</span> : <span>&nbsp;</span>}
                            <div className='row'>
                                <div className='col-sm-4'>
                                    <div className='form-group me-4 mb-1'>
                                        <label>Name: </label>
                                        <Field
                                            name='name'
                                            className="form-control form-control-lg"
                                            placeholder='Name'
                                            value={values.name}
                                            onChange={(e: any) => onLabNameChange(e, setFieldValue, setFieldTouched)}
                                        />
                                        <span className='text-danger'><ErrorMessage name='name' /></span>
                                    </div>

                                    <div className='form-group me-4 mb-1'>
                                        <label>Country: </label>
                                        <Field
                                            as='select'
                                            name='countryId'
                                            className="form-select form-control-lg"
                                            value={values.countryId}
                                            onChange={(e: any) => onCountryChange(e, setFieldTouched, setFieldValue)}
                                        >
                                            <option value=''>Select Country</option>
                                            {
                                                allCountries && allCountries.map((country: any, index: any) => (
                                                    <option key={index} value={country.id}>{country.name}</option>
                                                ))
                                            }
                                        </Field>
                                        {/* {errors.countryId && touched.countryId ? <div className='text-danger'> <ErrorMessage name={`countryId`} /></div> : <span>&nbsp;</span>} */}
                                        <span className='text-danger'><ErrorMessage name='countryId' /></span>
                                    </div>
                                    <div className='form-group me-4 mb-3'>
                                        <label>Test: </label>
                                        <Field
                                            name='testName'
                                            as='select'
                                            className="form-select form-control-lg"
                                            value={values.testName}
                                            onChange={(e: any) => onTestChange(e, setFieldValue, setFieldTouched)}
                                        >
                                            <option value=''>Select Test</option>
                                            {
                                                testByCatoegoryId && testByCatoegoryId.map((test: any, index: any) => (
                                                    <option key={index} value={test.testName}>{test.testName}</option>
                                                ))
                                            }
                                        </Field>
                                        <span className='text-danger'><ErrorMessage name='testName' /></span>
                                    </div>

                                </div>
                                <div className='col-sm-4'>
                                    <div className='form-group me-4 mb-1'>
                                        <label>Short Name: </label>
                                        <Field
                                            name='shortName'
                                            className="form-control form-control-lg"
                                            placeholder='Short name'
                                            value={values.shortName}
                                            onChange={(e: any) => onShortLabNameChange(e, setFieldValue, setFieldTouched)}
                                        />
                                        <span className='text-danger'><ErrorMessage name='shortName' /></span>
                                    </div>
                                    <div className='form-group me-4 mb-1'>
                                        <label>State: </label>
                                        <Field
                                            as='select'
                                            name='stateId'
                                            className="form-select form-control-lg"
                                            value={values.stateId}
                                            onChange={(e: any) => onStateNameChange(e, setFieldValue, setFieldTouched)}
                                        >
                                            <option value=''>Select State</option>
                                            {
                                                allStates && allStates.map((state: any, index: any) => (
                                                    <option key={index} value={state.id}>{state.name}</option>
                                                ))
                                            }

                                        </Field>
                                        <span className='text-danger'><ErrorMessage name='stateId' /></span>
                                    </div>
                                    <div className='form-group me-4 mb-3'>
                                        <label>Category: </label>
                                        <Field
                                            name='categoryName'
                                            as='select'
                                            className="form-select form-control-lg"
                                            value={values.categoryName}
                                            onChange={(e: any) => onCategoryChange(e, setFieldValue, setFieldTouched)}
                                        >
                                            <option value=''>Select Category</option>
                                            {
                                                categoriesList && categoriesList.data.map((category: any, index: any) => (
                                                    <option key={index} value={category.name}>{category.name}</option>
                                                ))
                                            }
                                        </Field>
                                        <span className='text-danger'><ErrorMessage name='categoryName' /></span>
                                    </div>
                                </div>

                                <div className='col-sm-4'>
                                    <div className='form-group me-4 mb-1'>
                                        <label>Region: </label>
                                        <Field
                                            name='region'
                                            as='select'
                                            className="form-select form-control-lg"
                                            value={values.region}
                                            onChange={(e: any) => onRegionChange(e, setFieldValue, setFieldTouched)}
                                        >
                                            <option value=''>Select Time Region</option>
                                            {
                                                timeZone && timeZone.map((item: any, index: any) => (
                                                    <option key={index} value={item}>{item}</option>
                                                ))
                                            }
                                        </Field>
                                        <span className='text-danger'><ErrorMessage name='region' /></span>
                                    </div>

                                    <div className='form-group me-4 mb-1'>
                                        <label>City: </label>
                                        <Field
                                            as='select'
                                            name='cityId'
                                            className="form-select form-control-lg"
                                            value={values.cityId}
                                            onChange={(e: any) => {
                                                onCityChange(e, setFieldValue, setFieldTouched)
                                                setBtnDisable(false)
                                            }}
                                        >
                                            <option value=''>Select City</option>
                                            {
                                                allCities && allCities.map((city: any, index: any) => (
                                                    <option key={index} value={city.id}>{city.name}</option>
                                                ))
                                            }
                                        </Field>
                                        <span className='text-danger'><ErrorMessage name='cityId' /></span>
                                    </div>


                                </div>
                            </div>
                        </Form>
                    )}

                </Formik>
            </CustomDialog>
        </React.Fragment>
    )
}

export default AddEditLab;