import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { Types } from "../../../reducer/Types";
import PageCount from "../../../../../../../common/pagecount/PageCount";
import { FilterSeachContainer } from "../../../../../../../common/styleComponents/FilterBy";
import { searchBy } from "../../../constants/models";
import SearchField from "../../../../../../../common/searchField/SearchField";
import AddEditiTest from "./AddEditiTest";
import TestDashboard from "./TestDashboard";
import { fetchTests } from "../../../actions/actions";
import "../../../styles/labStyles.scss"


function Test() {
    const navigate = useNavigate();
    const dispatch = useDispatch()
    const { searchParams } = useSelector((state: any) => state.labs);
    const loaded = React.useRef(false);
    const [searchByName, setSearchName] = React.useState('testName')
    const [searchTestName, setSearchTestName] = React.useState('')
    const [searchCategory, setSearchCategory] = React.useState('')

    React.useEffect(() => {
        if (!loaded.current) {
            const searchPayload = { ...searchParams, term: '', searchValue: '', limit: 10, offset: 0 }
            dispatch(fetchTests(searchPayload))
            loaded.current = true
        }
              // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const onBackToLabs = () => {
        navigate('/study/labs')
        const _searchPayload = { ...searchParams, term: '', searchValue: '', limit: 10, offset: 0 }
        dispatch({ type: Types.SEARCH_PARAMS, payload: _searchPayload })
    }

    //On Page Drop down 
    const onPageCountChange = (e: any) => {
        const _payload = { ...searchParams,limit: parseInt(e.target.value) ,offset: 0}
        dispatch({ type: Types.SEARCH_PARAMS, payload: _payload })
        dispatch(fetchTests(_payload))
    }

    // Search with Category
    const onCategorySearch = (e: any) => {
        setSearchCategory(e.target.value)
        if (e.target.value) {
            const payload = { ...searchParams, term: searchByName, searchValue: e.target.value, limit: 10, offset: 0 }
            dispatch({ type: Types.SEARCH_PARAMS, payload: payload })
            dispatch(fetchTests(payload))
        } else {
            const _payload = { ...searchParams, term: '', searchValue: '', limit: 10, offset: 0 }
            dispatch({ type: Types.SEARCH_PARAMS, payload: _payload })
            dispatch(fetchTests(_payload))
        }
    }

    //Search With Catagory
    const onTestNameSearch = (e: any) => {
        setSearchTestName(e.target.value)
        if (e.target.value) {
            const payload = { ...searchParams, term: searchByName, searchValue: e.target.value, limit: 10, offset: 0 }
            dispatch({ type: Types.SEARCH_PARAMS, payload: payload })
            dispatch(fetchTests(payload))
        } else {
            const _payload = { ...searchParams, term: '', searchValue: '', limit: 10, offset: 0 }
            dispatch({ type: Types.SEARCH_PARAMS, payload: _payload })
            dispatch(fetchTests(_payload))
        }
    }

    //Select Drop Down for Term Change
    const onSelectTermChange = (e: any) => {
        setSearchName(e.target.value)
        setSearchCategory('')
        setSearchTestName('')
        onClearTestNameSearch()
    }

    //Clear Search Value of Test
    const onClearTestNameSearch = () => {
        setSearchTestName('')
        const _payload = { ...{}, ...searchParams, term: '', searchValue: '', limit: 10, offset: 0 }
        dispatch({ type: Types.SEARCH_PARAMS, payload: _payload })
        dispatch(fetchTests(_payload))
    }

    //Clear Searched value of Catagory
    const onClearSearchCategory = () => {
        setSearchCategory("")
        const _payload = { ...{}, ...searchParams, term: '', searchValue: '', limit: 10, offset: 0 }
        dispatch({ type: Types.SEARCH_PARAMS, payload: _payload })
        dispatch(fetchTests(_payload))
    }

    return (
        <React.Fragment>
            <div className=" d-flex justify-content-between">
                <div className="d-flex align-items-center page-vcount">
                    <PageCount onChange={(e: any) => onPageCountChange(e)} />
                    <div className="ms-2">
                        <AddEditiTest />
                    </div>
                </div>
                <div className="d-flex justify-content-end">
                    <div className="me-2">
                        <FilterSeachContainer>
                            <select className='dropdown'
                                onChange={onSelectTermChange}
                                value={searchByName}
                            > {/* <option value=''>Filter By</option> */}

                                {searchBy && searchBy.map((i: any, index: any) => (
                                    <option key={index} value={i.id}>{i.name}</option>))}
                            </select>
                            {(searchByName === 'testName' || searchByName === "") && <SearchField
                                value={searchTestName}
                                onChange={onTestNameSearch}
                                placeholder="Search by test name"
                                onClearSearch={onClearTestNameSearch}
                            />}
                            {searchByName === 'category' && <SearchField
                                value={searchCategory}
                                onChange={onCategorySearch}
                                // disabled={searchByName === "" ? true : false}
                                placeholder={'Search By Category Name'}
                                onClearSearch={onClearSearchCategory}
                            />}
                        </FilterSeachContainer>
                    </div>
                    <button className="btn-eoutlined-secondary" onClick={onBackToLabs} >← Back To Labs</button>
                </div>
            </div>
            <div className=" mt-2">
                <TestDashboard
                    searchCategory={searchCategory}
                    searchTestName={searchTestName}
                    searchByName={searchByName}
                    setSearchTestName={setSearchTestName}
                    setSearchCategory={setSearchCategory} />
            </div>
        </React.Fragment>
    )
}

export default Test;