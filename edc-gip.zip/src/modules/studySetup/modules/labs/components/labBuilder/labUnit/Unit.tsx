import React from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from "react-router-dom";
import PageCount from '../../../../../../../common/pagecount/PageCount';
import SearchField from '../../../../../../../common/searchField/SearchField';
import { FilterSeachContainer } from '../../../../../../../common/styleComponents/FilterBy';
import { fetchUnits } from '../../../actions/actions';
// import KeyboardDoubleArrowLeftIcon from '@mui/icons-material/KeyboardDoubleArrowLeft';
import { searchBy } from '../../../constants/models';
import { Types } from '../../../reducer/Types';
import AddEditUnit from './AddEditUnit';
import UnitDashboard from './UnitDashboard';


function Unit() {
    const dispatch = useDispatch()
    const navigate = useNavigate();
    const loaded = React.useRef(false);
    const { searchParams } = useSelector((state: any) => state.labs);
    const [searchByName, setSearchName] = React.useState('testName')
    const [searchTestName, setSearchTestName] = React.useState('')
    const [searchCategory, setSearchCategory] = React.useState('')

    React.useEffect(() => {
        if (!loaded.current) {
            const _payload = { ...searchParams, limit: 10, offset: 0, term: '', searchValue: '' }
            dispatch(fetchUnits(_payload))
            loaded.current = true
        }
          // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const onChangePageCount = (event: any) => {
        const _payload = { ...searchParams, limit: event.target.value,offset: 0 }
        dispatch({ type: Types.SEARCH_PARAMS, payload: _payload })
        dispatch(fetchUnits(_payload))
    }

    const onBackToLabs = () => {
        navigate('/study/labs')
        const _searchPayload = { ...searchParams, term: '', searchValue: '', limit: 10, offset: 0 }
        dispatch({ type: Types.SEARCH_PARAMS, payload: _searchPayload })
    }

    const onCategorySearch = (e: any) => {
        setSearchCategory(e.target.value)
        if (e.target.value) {
            const payload = { ...searchParams, term: searchByName, searchValue: e.target.value, limit: 10, offset: 0 }
            dispatch({ type: Types.SEARCH_PARAMS, payload: payload })
            dispatch(fetchUnits(payload))
        } else {
            const _payload = { ...searchParams, term: '', searchValue: '', limit: 10, offset: 0 }
            dispatch({ type: Types.SEARCH_PARAMS, payload: _payload })
            dispatch(fetchUnits(_payload))
        }
    }

    const onTestNameSearch = (e: any) => {
        setSearchTestName(e.target.value)
        if (e.target.value) {
            const payload = { ...searchParams, term: searchByName, searchValue: e.target.value, limit: 10, offset: 0 }
            dispatch({ type: Types.SEARCH_PARAMS, payload: payload })
            dispatch(fetchUnits(payload))
        } else {
            const _payload = { ...searchParams, term: '', searchValue: '', limit: 10, offset: 0 }
            dispatch({ type: Types.SEARCH_PARAMS, payload: _payload })
            dispatch(fetchUnits(_payload))
        }
    }

    const onClearCategorySearch = () => {
        setSearchCategory("")
        const searchPayload = { ...searchParams, offset: 0, searchValue: '', term: '', limit: 10 }
        dispatch({ type: Types.SEARCH_PARAMS, payload: searchPayload })
        dispatch(fetchUnits(searchPayload))
    }

    const onClearTestNameSearch = () => {
        setSearchTestName('')
        const _payload = { ...searchParams, offset: 0, searchValue: '', term: '', limit: 10 }
        dispatch({ type: Types.SEARCH_PARAMS, payload: _payload })
        dispatch(fetchUnits(_payload))
    }

    const onSelectChange = (e: any) => {
        setSearchName(e.target.value)
        setSearchCategory('')
        setSearchTestName('')
        onClearTestNameSearch()
    }

    return (
        <React.Fragment>
            <div className=" d-flex justify-content-between pb-2 controls-container">
                <div className=" d-flex page-vcount">
                    <PageCount onChange={(e: any) => onChangePageCount(e)} />
                    <div className="ms-2">
                        <AddEditUnit />
                    </div>
                </div>
                <div className="d-flex justify-content-end">
                    <div className="me-2">
                        <FilterSeachContainer>
                            <select className='dropdown'
                                onChange={onSelectChange}
                                value={searchByName}
                            >
                                {
                                    searchBy && searchBy.map((i: any, index: any) => (
                                        <option key={index} value={i.id}>{i.name}</option>
                                    ))
                                }
                            </select>
                            {(searchByName === 'testName' || searchByName === "") && <SearchField
                                value={searchTestName}
                                onChange={onTestNameSearch}
                                placeholder="Search by test name"
                                onClearSearch={onClearTestNameSearch}
                            />}
                            {(searchByName === 'category' || searchByName === "") && <SearchField
                                value={searchCategory}
                                onChange={onCategorySearch}
                                placeholder={'Search By category name'}
                                onClearSearch={onClearCategorySearch}
                            />}
                        </FilterSeachContainer>
                    </div>
                    <button className="btn-eoutlined-secondary" onClick={onBackToLabs} >← Back To Labs</button>
                </div>
            </div>
            <div className="mt-2">
                <UnitDashboard
                    searchTestName={searchTestName}
                    searchCategory={searchCategory}
                    searchByName={searchByName}
                    setSearchTestName={setSearchTestName}
                    setSearchCategory={setSearchCategory} />
            </div>
        </React.Fragment>
    )
}

export default Unit