import React from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { fetchCategories } from "../../../actions/actions";
import { Types } from "../../../reducer/Types";
import PageCount from "../../../../../../../common/pagecount/PageCount";
import SearchField from "../../../../../../../common/searchField/SearchField";
import AddEditCategory from "./AddEditCategory";
import CategoryDashboard from "./CategoryDashboard";

function Category() {
    const navigate = useNavigate();
    const dispatch = useDispatch()
    const { categoryParams } = useSelector((state: any) => state.labs);
    const [searchCategory, setSearchCategory] = React.useState("")
    // const [value, setValue] = React.useState()

    // useEffect(() => {
    //     let _payload = { ...categoryParams, limit: categoryParams.limit, offset: 0, searchValue: '' }
    //     // dispatch({ type: Types.DATATABLE_PARAMS, payload: _payload })
    //     dispatch(fetchCategories(_payload))
    // }, [])

    const onBackToLabs = () => {
        navigate('/study/labs')
        const _payload = { ...categoryParams, limit: categoryParams.limit, offset: 0, searchValue: '' }
        dispatch({ type: Types.CATEGORY_PARAMS, payload: _payload })
    }

    const onPageCountChange = (e: any) => {
        const _payload = { ...categoryParams, limit: parseInt(e.target.value), offset: 0 }
        dispatch({ type: Types.CATEGORY_PARAMS, payload: _payload })
        dispatch(fetchCategories(_payload))
    }

    const onSearchCategory = (e: any) => {
        setSearchCategory(e.target.value)
        if (e.target.value) {
            const payload = { ...categoryParams, searchValue: e.target.value, limit: 10, offset: 0 }
            dispatch({ type: Types.CATEGORY_PARAMS, payload: payload })
            dispatch(fetchCategories(payload))

        } else {
            const _payload = { ...categoryParams, offset: 0, limit: 10, searchValue: '' }
            dispatch({ type: Types.CATEGORY_PARAMS, payload: _payload })
            dispatch(fetchCategories(_payload))
        }
    }

    const onClearSearch = () => {
        // setValue(10)
        setSearchCategory("")
        const clearPayload = { ...categoryParams, offset: 0, limit: 10, searchValue: '' }
        dispatch({ type: Types.CATEGORY_PARAMS, payload: clearPayload })
        dispatch(fetchCategories(clearPayload))
    }

    return (
        <React.Fragment>
            <div className=" d-flex justify-content-between pb-2 controls-container">
                <div className=" d-flex">
                    <PageCount onChange={(e: any) => onPageCountChange(e)} />
                    <div className="ms-2">
                        <AddEditCategory />
                    </div>
                </div>
                <div className="d-flex justify-content-end">
                    <div className="me-2">
                        <SearchField
                            value={searchCategory}
                            placeholder="Search by category name"
                            onChange={onSearchCategory}
                            onClearSearch={onClearSearch}
                        />
                    </div>
                    <button className="btn-eoutlined-secondary" onClick={onBackToLabs} >← Back To Labs</button>
                </div>
            </div>

            <div className=" mt-2">
                <CategoryDashboard
                    searchCategory={searchCategory}
                    setSearchCategory={setSearchCategory} />
            </div>
        </React.Fragment>
    )
}
export default Category