import React from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import DeleteIcon from '@mui/icons-material/Delete';
import { useDispatch, useSelector } from "react-redux";
import ReplayIcon from '@mui/icons-material/Replay';
import AddEditCategory from "./AddEditCategory";
import { Confirm, toastAlert } from "../../../../../../../actions/actions";
import { messages } from "../../../../../constants/messages";
import { deleteCategory, fetchCategories, restoreCategory} from "../../../actions/actions";
import CustomToolTip from "../../../../../../../components/CustomToolTip";
import { Types } from "../../../reducer/Types";

export default function CategoryDashboard(props: any) {
    const dispatch = useDispatch()
    const { categories, categoryParams } = useSelector((state: any) => state.labs);
    const [pageClick, setpageChange] = React.useState(false);
    const loaded = React.useRef(false);
    const { searchCategory, setSearchCategory } = props

    React.useEffect(() => {
        if (!loaded.current) {
            const _payload = { ...categoryParams, offset: categoryParams.offset, limit: categoryParams.limit, searchValue: '' }
            dispatch(fetchCategories(_payload))
            loaded.current = true
        }
          // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const onDeleteRestoreGroup = (type: any, rowData: any) => {
        dispatch(Confirm({
            status: 0, message: type === 'delete' ? messages.labs.deleteGroup : messages.labs.restoreGroup,
            onOk: () => {
                setSearchCategory('')
                dispatch((type === 'delete' ? deleteCategory : restoreCategory)(rowData.id, (response: any) => {
                    dispatch(toastAlert({
                        status: 1, message: `${rowData.name} ${response}`, open: true
                    }))
                    const _data = { ...categoryParams, limit: categoryParams.limit, offset: categoryParams.offset, searchValue: categoryParams.searchValue }
                    dispatch(fetchCategories(_data))
                }))
            }
        }))
    }

    const actionsTemplate = (rowData: any) => {
        return (<React.Fragment>
            <div className="d-flex align-items-center" onClick={(e) => e.stopPropagation()}>
                {rowData.status === true ? <React.Fragment>
                    <AddEditCategory rowData={rowData} />
                    <span> | </span>
                    <CustomToolTip title="Delete Group"><DeleteIcon sx={{ fontSize: 14, opacity: .8 }} className="text-danger" onClick={() => onDeleteRestoreGroup('delete', rowData)} /></CustomToolTip>
                </React.Fragment> : <CustomToolTip title='Restore Group'><ReplayIcon sx={{ fontSize: 22, opacity: .8 }} onClick={() => onDeleteRestoreGroup('restore', rowData)} /></CustomToolTip>}
            </div>
        </React.Fragment>)
    }

    const onPage = (event: any) => {
        if ((event.page > 0 || (pageClick && event.page) === 0) && categoryParams.offset !== event.first) {
            if (searchCategory !== '') {
                const _payload = { ...categoryParams, offset: event.first, searchValue: searchCategory, limit: 10 }
                dispatch({ type: Types.CATEGORY_PARAMS, payload: _payload })
                dispatch(fetchCategories(_payload))
                setpageChange(true)
            } else {
                const clearPayload = { ...categoryParams, offset: event.first }
                dispatch({ type: Types.CATEGORY_PARAMS, payload: clearPayload })
                dispatch(fetchCategories(clearPayload))
                setpageChange(true)
            }
        }
    }

    return (
        <React.Fragment>
            <div>
                <DataTable
                    value={categories && categories.labCategory}
                    scrollHeight="300px"
                    responsiveLayout="scroll"
                    selectionMode="single"
                    lazy
                    emptyMessage="No Categories Are Available To Display"
                    rows={categoryParams?.limit}
                    paginator={categories && categories.totalRecords > categoryParams?.limit ? true : false}
                    totalRecords={categories && categories.totalRecords}
                    first={categoryParams?.offset}
                    stripedRows={true}
                    onPage={onPage}
                >
                    <Column header='Category' field='name'></Column>
                    <Column header='Description' field="description"></Column>
                    <Column header='Action' body={actionsTemplate}></Column>

                </DataTable>
            </div>
        </React.Fragment>
    )
}