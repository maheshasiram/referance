import React from "react";
import { Formik, Form, Field } from 'formik';
import { useDispatch, useSelector } from "react-redux";
import EditIcon from '@mui/icons-material/Edit';
import { Types } from "../../../reducer/Types";
import { categoryModel } from "../../../constants/models";
import { createCategory, fetchCategories, updateCategory } from "../../../actions/actions";
import { toastAlert } from "../../../../../../../actions/actions";
import CustomToolTip from "../../../../../../../components/CustomToolTip";
import CustomDialog from "../../../../../../../common/modals/CustomeDialog";
import { categoryValidation } from "../../../helpers/Validations";

export default function AddEditCategory(props: any) {
    const [open, setOpen] = React.useState(false)
    const [btnDisable, setBtnDisable] = React.useState(true);
    const { category, tableparams } = useSelector((state: any) => state.labs);
    const dispatch = useDispatch();
    const [erroeMsg, setErroeMsg] = React.useState('');
    const { rowData } = props;

    const onClose = () => {
        setOpen(false)
        setBtnDisable(true)
        dispatch({ type: Types.CREATE_GROUP, payload: categoryModel })
        setErroeMsg('')
    }

    const onSubmitHandler = (values: any) => {
        const _values = { ...{}, ...values }
        dispatch((!_values.id ? createCategory : updateCategory)(_values, (response: any) => {
            console.log("...response", response)
            if (response.status === "error") {
                setErroeMsg(response.errorMessage);
            } else {
                onClose();
                dispatch(toastAlert({ status: 1, message: `${values.name} ${response}`, open: true }))
                dispatch((!_values.id ? fetchCategories({ ...tableparams, limit: 10, offset: 0 }) : fetchCategories({ ...tableparams, limit: tableparams.limit, offset: tableparams.offset })))
                setErroeMsg('');
            }
        }));
    }

    const onNameHandler = (e: any, setFieldValue: any) => {
        if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
            // setFieldTouched('name', true)
            setFieldValue('name', e.target.value)
            setBtnDisable(false)
        }
    }

    const onDescriptionHandler = (e: any, setFieldValue: any) => {
        if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
            // setFieldTouched('description', true)
            setFieldValue('description', e.target.value)
            setBtnDisable(false)
        }
    }

    const onOpenCategoryDialog = (type: any) => {
        if (type === 'add') {
            dispatch({ type: Types.CREATE_GROUP, payload: categoryModel })
        } else {
            dispatch({ type: Types.CREATE_GROUP, payload: rowData ? rowData : categoryModel });
        }
        setOpen(true);
        setBtnDisable(true);
    }

    return (
        <React.Fragment>
            {rowData && rowData.id !== 0 ?
                <CustomToolTip title='Edit Group'>
                    <EditIcon sx={{ fontSize: 14, opacity: .8 }} onClick={() => onOpenCategoryDialog('edit')} />
                </CustomToolTip> :
                <button className="btn-eoutlined-secondary" onClick={() => onOpenCategoryDialog('add')}>Create Category</button>
            }

            <div>
                <CustomDialog
                    title={rowData && rowData.id !== 0 ? 'Update Category' : 'Create Category'}
                    open={open}
                    onClose={onClose}
                    actionType={rowData && rowData.id !== 0 ? 'Update' : 'Submit'}
                    maxWidth="xs"
                    form={'labCategoryForm'}
                    fullWidth={true}
                    disabled={btnDisable}
                >
                    <Formik
                        enableReinitialize={true}
                        initialValues={category}
                        validationSchema={categoryValidation}
                        onSubmit={(values: any) => {
                            onSubmitHandler(values);
                        }}
                    >
                        {({ errors, touched, values, setFieldValue }) => (
                            <Form id="labCategoryForm">
                                {erroeMsg ? <span className="d-flex justify-content-center text-danger">{erroeMsg}</span> : <span>&nbsp;</span>}
                                <div className="pb-2">
                                    <label htmlFor="txt-groupName">Category Name: </label>
                                    <Field
                                        name='name'
                                        id="txt-groupName"
                                        value={values.name}
                                        className="form-control form-control-lg"
                                        onChange={(e: any) => {
                                            onNameHandler(e, setFieldValue)
                                        }}
                                    />
                                    {(errors && errors.name && touched && touched.name) &&
                                        <span className="text-danger">{errors.name as string}</span>}
                                </div>

                                <div className="pb-1">
                                    <label>Description: </label>
                                    <Field
                                        name='description'
                                        as="textarea"
                                        value={values.description}
                                        className="form-control form-control-lg"
                                        onChange={(e: any) => {
                                            onDescriptionHandler(e, setFieldValue)
                                        }}
                                    />
                                    {(errors && errors.description && touched && touched.description) &&
                                        <span className="text-danger">{errors.description as string}</span>}
                                </div>
                            </Form>
                        )}
                    </Formik>
                </CustomDialog>
            </div>
        </React.Fragment>
    )
}

