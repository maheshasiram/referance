import React from "react";
import { Field, Form, Formik, ErrorMessage } from "formik";
import { useDispatch, useSelector } from "react-redux";
import EditIcon from '@mui/icons-material/Edit';
import { Types } from "../../../reducer/Types";
import { testModel } from "../../../constants/models";
import { createTest, fetchTests, getAllCategoriesList, updateTest } from "../../../actions/actions";
import { toastAlert } from "../../../../../../../actions/actions";
import CustomToolTip from "../../../../../../../components/CustomToolTip";
import CustomDialog from "../../../../../../../common/modals/CustomeDialog";
import { labTestValidation } from "../../../helpers/Validations";


function AddEditiTest(props: any) {
    const dispatch = useDispatch()
    const [open, setOpen] = React.useState(false);
    const { tableparams, test, categoriesList } = useSelector((state: any) => state.labs);
    const { rowData } = props;
    const [erroeMsg, setErroeMsg] = React.useState('');
    const [btnDisable, setBtnDisable] = React.useState(true)


    const onCloseTest = () => {
        setOpen(false)
        dispatch({ type: Types.CREATE_TEST, payload: testModel })
        setErroeMsg('')
    }

    const onCategoryChangeHandle = (e: any, setFieldValue: any) => {
        setFieldValue("labGroup", e.target.value)
        dispatch({ type: Types.CREATE_TEST, payload: { ...test, categoryId: parseInt(e.target.value) } })
        setBtnDisable(false)
        setErroeMsg('')
    }

    const onTestNameHandle = (e: any, setFieldValue: any) => {
        if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
            setFieldValue('testName', e.target.value)
            setBtnDisable(false)
            setErroeMsg('')
        }
    }

    const onTestDescriptionHandle = (e: any, setFieldValue: any) => {
        if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
            setFieldValue('testDescription', e.target.value)
            setBtnDisable(false)
            setErroeMsg('')
        }
    }

    const onCreateLabTest = (values: any, errors: any) => {
        console.log("53----",errors)
        const _values = { ...{}, ...values }
        dispatch((!_values.testId ? createTest : updateTest)(_values, (response: any) => {
            if (response.status === "error") {
                setErroeMsg(response.errorMessage);
            } else {
                console.log("values.testName", values.testName)
                setErroeMsg('');
                onCloseTest();
                dispatch((!_values.testId ? fetchTests({ ...tableparams, limit: 10, offset: 0 }) : fetchTests({ ...tableparams, limit: tableparams.limit, offset: tableparams.offset })))
                dispatch(toastAlert({ status: 1, message: `${values.testName} ${response}`, open: true }))
                setOpen(false)
            }
        }));
    }

    const onOpenTestDialog = (type: any) => {
        setOpen(true);
        setBtnDisable(true);
        dispatch(getAllCategoriesList())
        if (type === 'add') {
            dispatch({ type: Types.CREATE_TEST, payload: testModel });
        } else {
            dispatch({ type: Types.CREATE_TEST, payload: rowData ? rowData : testModel });
        }
    }

    return (
        <React.Fragment>
            {rowData && rowData.id !== 0 ?
                <CustomToolTip title="Edit Test"><EditIcon sx={{ fontSize: 14, opacity: .8 }} onClick={() => onOpenTestDialog('edit')} /></CustomToolTip> :
                <button className="btn-eoutlined-secondary me-1" onClick={() => onOpenTestDialog('add')}> Create Test</button>}
            <div>
                <CustomDialog
                    title={rowData && rowData.id !== 0 ? 'Update Test' : 'Create Test'}
                    open={open}
                    onClose={onCloseTest}
                    actionType={rowData && rowData.id !== 0 ? 'Update' : 'Submit'}
                    maxWidth="xs"
                    fullWidth={true}
                    form={'labTestForm'}
                    disabled={btnDisable}
                >
                    <Formik
                        enableReinitialize={true}
                        initialValues={test}
                        validationSchema={labTestValidation}
                        onSubmit={(values: any, errors: any) => {
                            onCreateLabTest(values, errors)
                        }}
                    >
                        {({ errors, touched, values, setFieldValue }) => (
                            <Form id='labTestForm' >
                                {erroeMsg ? <span className="d-flex justify-content-center text-danger">{erroeMsg}</span> : <span>&nbsp;</span>}
                                <div className="pb-2">
                                    <label htmlFor="txt-labgroup">Category:</label>
                                    <Field as='select'
                                        name='categoryId'
                                        id="txt-labgroup"
                                        className="form-select mt-1"
                                        value={values.categoryId}
                                        onChange={(e: any) => onCategoryChangeHandle(e, setFieldValue)}
                                    >
                                        <option value="">--Select Category--</option>
                                        {
                                            categoriesList && categoriesList.data && categoriesList.data.map((opt: any, i: any) => (
                                                <option key={i} value={opt.id}>{opt.name}</option>
                                            ))
                                        }
                                    </Field>
                                    <div className="text-danger"><ErrorMessage name='categoryId' /></div>
                                </div>
                                <div className="pb-2">
                                    <label htmlFor="text-testName">Test Name: </label>
                                    <Field
                                        id="text-testName"
                                        name='testName'
                                        value={values.testName}
                                        className="form-control mt-1"
                                        onChange={(e: any) => onTestNameHandle(e, setFieldValue)}
                                    />
                                    {(errors && errors.testName && touched && touched.testName) &&
                                        <span className="text-danger">{errors.testName as string}</span>}
                                </div>
                                <div className="pb-2">
                                    <label htmlFor="text-testDescription">Description: </label>
                                    <Field
                                        as='textarea'
                                        id="text-testDescription"
                                        name='testDescription'
                                        value={values.testDescription}
                                        className="form-control mt-1"
                                        onChange={(e: any) => onTestDescriptionHandle(e, setFieldValue)}
                                    />
                                    {(errors && errors.testDescription && touched && touched.testDescription) &&
                                        <span className="text-danger">{errors.testDescription as string}</span>}
                                </div>
                            </Form>
                        )}
                    </Formik>
                </CustomDialog>

            </div>
        </React.Fragment>
    )

}

export default AddEditiTest;
