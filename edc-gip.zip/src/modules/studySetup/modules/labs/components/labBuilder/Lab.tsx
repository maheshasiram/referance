import React from "react";
import { NavLink } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { Types } from "../../reducer/Types";
import { categoryModel, testModel, unitModel } from "../../constants/models";
import LabDashBoard from "./LabDashBoard";
import AddEditLab from "./AddEditLab";
import PageCount from "../../../../../../common/pagecount/PageCount";
import { fetchAllLabs } from "../../actions/actions";

function Lab() {
    const dispatch = useDispatch()
    const { tableparams } = useSelector((state: any) => state.labs);

    const onChangePageCount = (event: any) => {
        const _payload = { ...tableparams, limit: parseInt(event.target.value) }
        dispatch({ type: Types.DATATABLE_PARAMS, payload: _payload })
        dispatch(fetchAllLabs(_payload))
    }

    return (
        <React.Fragment>
            <div className="d-flex justify-content-between pb-2 controls-container">
                <div className=" d-flex left-container">
                    <PageCount onChange={(e: any) => onChangePageCount(e)} />
                    <div className="ms-2">
                        <AddEditLab />
                    </div>
                </div>
                <div className="right-panel d-flex">
                    <NavLink className="btn-eoutlined-secondary me-1" style={{ marginRight: 'auto' }} to={`../labUnit/0`}
                        onClick={() => { dispatch({ type: Types.CREATE_UNIT, payload: unitModel }) }}>Unit</NavLink>

                    <NavLink className="btn-eoutlined-secondary me-1" style={{ marginRight: 'auto' }} to={`../labTest/0`}
                        onClick={() => { dispatch({ type: Types.CREATE_TEST, payload: testModel }) }}>Test</NavLink>

                    <NavLink className="btn-eoutlined-secondary me-1" style={{ marginRight: 'auto' }} to={`../labCategory/0`}
                        onClick={() => { dispatch({ type: Types.CREATE_GROUP, payload: categoryModel }) }}>Category</NavLink>
                </div>
            </div>
            <div className=" mt-2">
                <LabDashBoard />
            </div>
        </React.Fragment>
    )
}

export default Lab;