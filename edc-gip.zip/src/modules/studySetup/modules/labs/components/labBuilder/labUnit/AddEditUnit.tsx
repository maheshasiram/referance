import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { Formik, Form, Field, FieldArray, ErrorMessage, } from "formik";
import RemoveCircleOutlineIcon from '@mui/icons-material/RemoveCircleOutline';
import AddCircleOutlineOutlined from "@mui/icons-material/AddCircleOutlineOutlined";
import EditIcon from '@mui/icons-material/Edit';
import { Types } from "../../../reducer/Types";
import { unitModel } from "../../../constants/models";
import { createUnit, fetchUnits, getAllCategoriesList, getTestNameByCategoryId, updateUnit } from "../../../actions/actions";
import { toastAlert } from "../../../../../../../actions/actions";
import CustomToolTip from "../../../../../../../components/CustomToolTip";
import CustomDialog from "../../../../../../../common/modals/CustomeDialog";
import { createUnitValidation } from "../../../helpers/Validations";

function AddEditUnit(props: any) {
    const dispatch = useDispatch();
    const { testByCatoegoryId, unit, categoriesList, tableparams } = useSelector((state: any) => state.labs);
    const [btnDisable, setBtnDisable] = React.useState(true);
    const { rowData } = props;
    const [unitName, setUnitName] = React.useState('');
    const [addRemoveMsg, setaddRemoveMsg] = React.useState('');
    const [erroeMsg, setErroeMsg] = React.useState('');
    const [open, setOpen] = React.useState(false);

    const onCloseHandler = () => {
        setOpen(false)
        setBtnDisable(true)
        dispatch({ type: Types.CREATE_UNITS, payload: unitModel })
        setErroeMsg('')
        setaddRemoveMsg("")
    }

    const onGroupNameChange = (e: any, setFieldValue: any) => {
        setFieldValue("categoryId", e.target.value)
        setBtnDisable(false)
        if (e.target.value !== "") {
            dispatch(getTestNameByCategoryId(e.target.value, (response: any) => {
                if (response.status === "error") {
                    setErroeMsg(response.errorMessage);
                    dispatch({ type: Types.TESTS_LIST_DATA, payload: [] })
                } else {
                    setErroeMsg('');
                }
            }))
        } else {
            dispatch({ type: Types.TESTS_LIST_DATA, payload: [] })
        }
    }

    const onTestNameChange = (e: any, setFieldValue: any) => {
        setFieldValue('testId', e.target.value);
        setBtnDisable(false)
    }

    const onVlidateUnitName = (values: any, arrayHelpers: any, type: any) => {
        let emptyField = false;
        const sameUnitName: any = [];
        values.unitName.map((item: any) => {
            emptyField = item !== '' ? false : true;
            console.log("item === unitName", item, emptyField)
            if (item === unitName) {
                sameUnitName.push(item)
            }
            return null;
        })
        if (!emptyField) {
            if (sameUnitName.length > 1) {
                setaddRemoveMsg("Unit name can't be same");

            } else {
                setaddRemoveMsg("");
                type === 'addField' ? arrayHelpers.push("") : onSubmitHandler(values);
            }
        } else {
            setaddRemoveMsg("Unit name can't be empty");

        }
    }

    const onSubmitHandler = (values: any) => {
        const _payload = {
            ...values, testId: parseInt(values.testId),
            categoryId: parseInt(values.categoryId),
            unitName: values.unitName.toString()
        }
        dispatch((!_payload.unitId ? createUnit : updateUnit)(_payload, (response: any) => {
            if (response.status === "error") {
                setErroeMsg(response.errorMessage);
            } else {
                setErroeMsg('');
                onCloseHandler();
                dispatch(toastAlert({ status: 1, message: `${values.unitName} ${response}`, open: true }))
                dispatch((!_payload.unitId ? fetchUnits({ ...tableparams, limit: 10, offset: 0 }) : fetchUnits({ ...tableparams, limit: tableparams.limit, offset: tableparams.offset })))
                setOpen(false)
            }
        }));
    }

    const onOpenUnitDialog = (type: any) => {
        setOpen(true);
        setBtnDisable(true);
        dispatch(getAllCategoriesList())
        if (type === 'add') {
            dispatch({ type: Types.CREATE_UNITS, payload: unitModel });
        } else {
            const editData = { ...rowData, unitName: rowData.unitName.split(',') }
            dispatch(getTestNameByCategoryId(rowData.categoryId))
            dispatch({ type: Types.CREATE_UNITS, payload: editData ? editData : unitModel });
        }
    }

    const onUnitNameChange = (e: any, setFieldValue: any, setFieldTouched: any, index: any) => {
        if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
            setUnitName(e.target.value);
            setFieldTouched(`unitName.${index}`, true)
            setFieldValue(`unitName.${index}`, e.target.value)
            setBtnDisable(false)
            setaddRemoveMsg("")
        }
    }

    const onRemoveUnitField = (e: any, arrayHelpers: any, index: any) => {
        arrayHelpers.remove(index)
        setaddRemoveMsg("")
        setBtnDisable(false)
    }

    return (
        <React.Fragment>
            {rowData && rowData.id !== 0 ?
                <CustomToolTip title="Edit Unit"><EditIcon sx={{ fontSize: 14, opacity: .8 }} onClick={() => onOpenUnitDialog('edit')} /></CustomToolTip> :
                <button className="btn-eoutlined-secondary me-1" onClick={() => onOpenUnitDialog('add')}>Create Unit</button>
            }

            <div>
                <CustomDialog
                    title={rowData && rowData.id !== 0 ? 'Update Unit' : 'Create Unit'}
                    maxWidth="xs"
                    open={open}
                    onClose={onCloseHandler}
                    actionType={rowData && rowData.id !== 0 ? 'Update' : 'Submit'}
                    form='createUnitForm'
                    disabled={btnDisable}
                >
                    <Formik
                        enableReinitialize={true}
                        initialValues={unit}
                        validationSchema={createUnitValidation}
                        onSubmit={(values: any) => {
                            onVlidateUnitName(values, '', '');
                        }}
                    >
                        {({ values, setFieldTouched, setFieldValue, errors }) => (
                            <Form id='createUnitForm'>
                                {erroeMsg ? <span className="d-flex justify-content-center text-danger">{erroeMsg}</span> : <span>&nbsp;</span>}
                                <div className=''>
                                    <div className='form-group  m-1'>
                                        <>{console.log("errors", errors)}</>
                                        <label htmlFor="sel-categoryId ">Category :</label>
                                        <Field
                                            as='select'
                                            name='categoryId'
                                            id='sel-categoryId'
                                            disabled={rowData && rowData.id !== 0 ? true : false}
                                            className='form-select form-control-lg'
                                            value={values.categoryId}
                                            onChange={(e: any) =>
                                                onGroupNameChange(e, setFieldValue)}
                                        >
                                            <option value="">--Select GroupName--</option>
                                            {
                                                categoriesList && categoriesList.data.map((opt: any, index: any) => (
                                                    <option key={index} value={opt.id}>{opt.name}</option>
                                                ))
                                            }
                                        </Field>
                                        <div className="text-danger"><ErrorMessage name='categoryId' /></div>
                                    </div>
                                    <div className='form-group  m-1'>
                                        <label htmlFor="testName">Test Name : </label>
                                        <Field
                                            as='select'
                                            className='form-select form-control-lg'
                                            name='testId'
                                            id='sel-testId'
                                            value={values.testId}
                                            onChange={(e: any) => {
                                                onTestNameChange(e, setFieldValue)
                                            }}
                                        >
                                            <option value=''>--Select TestName--</option>
                                            {
                                                testByCatoegoryId && testByCatoegoryId.map((item: any, index: number) => {
                                                    return (<option key={index} value={item.testId}>{item.testName}</option>)
                                                })
                                            }
                                        </Field>
                                        <div className="text-danger"><ErrorMessage name='testId' /></div>
                                    </div>
                                    <FieldArray
                                        name="unitName"
                                        render={(arrayHelpers) => {
                                            const allUnitNames = values.unitName
                                            return (
                                                <div className="mx-1">
                                                    <div className="d-flex">
                                                        <label id='label'>Unit Name</label>
                                                        <AddCircleOutlineOutlined
                                                            className='text-primary mx-2 mb-1'
                                                            fontSize='small'
                                                            onClick={() => {
                                                                onVlidateUnitName(values, arrayHelpers, 'addField')
                                                            }} />
                                                        <div>
                                                            {addRemoveMsg && <span className="" style={{ color: 'red', marginLeft: 10 }}>{addRemoveMsg}</span>}</div>
                                                    </div>

                                                    {allUnitNames &&
                                                        allUnitNames.map((data: any, index: number) => (
                                                            <div key={index} className="d-flex mb-2">
                                                                <div className="col-12">
                                                                    <Field
                                                                        name={`unitName.${index}`}
                                                                        value={values.unitName[index]}
                                                                        className="form-control"
                                                                        placeholder={"Unit name"}
                                                                        onChange={(e: any) => onUnitNameChange(e, setFieldValue, setFieldTouched, index)}
                                                                    >
                                                                    </Field>
                                                                    {!addRemoveMsg &&
                                                                        <div className="text-danger"><ErrorMessage name='unitName' /></div>
                                                                    }
                                                                </div>
                                                                <div>
                                                                    {allUnitNames.length > 1 && <RemoveCircleOutlineIcon
                                                                        sx={{ cursor: 'pointer' }}
                                                                        color='error'
                                                                        className="mt-1"
                                                                        onClick={(e: any) => onRemoveUnitField(e, arrayHelpers, index)}
                                                                    />}
                                                                </div>
                                                            </div>
                                                        ))
                                                    }
                                                </div>
                                            )
                                        }}
                                    ></FieldArray>

                                </div>
                            </Form>
                        )}
                    </Formik>
                </CustomDialog>
            </div>
        </React.Fragment>
    )
}
export default AddEditUnit