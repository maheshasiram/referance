import React from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { useDispatch, useSelector } from "react-redux";
import DeleteIcon from '@mui/icons-material/Delete';
import ReplayIcon from '@mui/icons-material/Replay';
import AddEditiTest from "./AddEditiTest";
import { Confirm, toastAlert } from "../../../../../../../actions/actions";
import { messages } from "../../../../../constants/messages";
import { deleteTest, fetchTests, restoreTest} from "../../../actions/actions";
import CustomToolTip from "../../../../../../../components/CustomToolTip";
import { Types } from "../../../reducer/Types";

function TestDashboard(props: any) {
    const dispatch = useDispatch();
    const { tests, searchParams } = useSelector((state: any) => state.labs);
    const [pageClick, setPageClick] = React.useState(false);

    const { searchTestName, searchByName, searchCategory, setSearchTestName, setSearchCategory } = props

    const onDeleteRestoreTest = (type: any, rowData: any) => {
        dispatch(Confirm({
            status: 0, message: type === 'delete' ? messages.labs.deleteTestData : messages.labs.restoreTestData,
            onOk: () => {
                setSearchTestName('')
                setSearchCategory('')
                dispatch((type === 'delete' ? deleteTest : restoreTest)(rowData.testId, (response: any) => {
                    dispatch(toastAlert({
                        status: 1, message: `${rowData.testName}${response}`, open: true
                    }))
                    const _data = { ...searchParams, limit: searchParams.limit, offset: searchParams.offset, searchValue: searchParams.searchValue }
                    dispatch({ type: Types.SEARCH_PARAMS, payload: _data })
                    dispatch(fetchTests(_data))
                }))
            }
        }))
    }

    const actionsTemplate = (rowData: any) => {
        return (<React.Fragment>
            <div className="d-flex align-items-center" onClick={(e) => e.stopPropagation()}>
                {rowData.status === true ? <React.Fragment>
                    <AddEditiTest rowData={rowData} />
                    <span> | </span>
                    <CustomToolTip title="Delete Test"><DeleteIcon sx={{ fontSize: 14, opacity: .8 }} className="text-danger" onClick={() => onDeleteRestoreTest('delete', rowData)} /></CustomToolTip>
                </React.Fragment> : <CustomToolTip title='Restore Test'><ReplayIcon sx={{ fontSize: 22, opacity: .8 }} onClick={() => onDeleteRestoreTest('restore', rowData)} /></CustomToolTip>}
            </div>
        </React.Fragment>)
    }

    const onPage = (event: any) => {
        if (((event.page > 0) || (pageClick && event.page === 0)) && searchParams.offset !== event.first) {
            if (searchTestName !== '') {
                const searchPayload = { ...searchParams, offset: event.first, searchValue: searchTestName, term: searchByName, limit: 10 }
                dispatch({ type: Types.SEARCH_PARAMS, payload: searchPayload })
                dispatch(fetchTests(searchPayload))
                setPageClick(true)
            } else if (searchCategory !== '') {
                const _searchPayload = { ...searchParams, offset: event.first, searchValue: searchCategory, term: searchByName, limit: 10 }
                dispatch({ type: Types.SEARCH_PARAMS, payload: _searchPayload })
                dispatch(fetchTests(_searchPayload))
                setPageClick(true)

            } else {
                const _payload = { ...searchParams, offset: event.first }
                dispatch({ type: Types.SEARCH_PARAMS, payload: _payload })
                dispatch(fetchTests(_payload))
                setPageClick(true)
            }
        }
    }


    return (
        <React.Fragment>
            <div>
                <DataTable
                    value={tests && tests.labCategory}
                    scrollHeight="300px"
                    responsiveLayout="scroll"
                    selectionMode="single"
                    lazy
                    rows={searchParams?.limit}
                    paginator={tests && tests.totalRecords > searchParams?.limit ? true : false}
                    totalRecords={tests && tests.totalRecords}
                    first={searchParams?.offset}
                    stripedRows={true}
                    onPage={onPage}
                >
                    <Column header='Test' field="testName" />
                    <Column header='Category' field="categoryName"></Column>
                    <Column header='Test Description' field="testDescription"></Column>
                    <Column header='Action' body={actionsTemplate}></Column>

                </DataTable>
            </div>
        </React.Fragment>
    )
}

export default TestDashboard;