import { DataTable } from "primereact/datatable";
import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { Column } from "primereact/column";
import CustomToolTip from "../../../../../../components/CustomToolTip";
import DeleteIcon from '@mui/icons-material/Delete';
import ReplayIcon from '@mui/icons-material/Replay';
import { Confirm, toastAlert } from "../../../../../../actions/actions";
import { NavLink } from "react-router-dom";
import AddEditLab from "./AddEditLab";
import { fetchAllLabs, deleteLabs, restoreLabs } from "../../actions/actions";
import { Types } from "../../reducer/Types";
import { messages } from "../../../../../../constants/messages";
import { confirmMsg, toastMsg } from "../../../../../../common/messages";


function LabDashBoard() {
    const dispatch = useDispatch();
    const loaded = React.useRef(false);
    const { tableparams, labs } = useSelector((state: any) => state.labs);
    const [pageClick, setpageChange] = React.useState(false);

    React.useEffect(() => {
        if (!loaded.current) {
            const _payload = { ...{}, ...tableparams, limit: tableparams.limit, offset: tableparams.offset }
            dispatch(fetchAllLabs(_payload))
            loaded.current = true
        }
          // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const onDeleteRestoreLabs = (type: any, rowData: any) => {
        dispatch(Confirm({
            status: 0,
            // message: type === 'delete' ? messages.labs.deleteLab : messages.labs.restoreLab,
            message: rowData.status ? confirmMsg(messages.delete, rowData.name) : confirmMsg(messages.restore, rowData.name),
            onOk: () => {
                dispatch((type === 'delete' ? deleteLabs : restoreLabs)(rowData.labId, () => {
                    dispatch(toastAlert({
                        status: 1,
                        message: rowData.status ? toastMsg(messages.deleted, rowData.name) : toastMsg(messages.restored, rowData.name),
                        open: true
                    }))
                    const _payload = { ...tableparams, limit: tableparams.limit, offset: tableparams.offset }
                    dispatch(fetchAllLabs(_payload))
                    dispatch({ type: Types.DATATABLE_PARAMS, payload: _payload })
                }))
            }
        }))
    }

    const actionsTemplate = (rowData: any) => {
        return (
            <React.Fragment>
                <div className='actions d-flex' onClick={(e) => e.stopPropagation()}>
                    {rowData.status === true ?
                        <React.Fragment>
                            <AddEditLab rowData={rowData} />
                            <span> |</span>
                            <CustomToolTip title='Delete Lab'><DeleteIcon sx={{ fontSize: 14, opacity: .8 }} className="text-danger" onClick={() => onDeleteRestoreLabs('delete', rowData)} /></CustomToolTip>
                        </React.Fragment> :
                        <CustomToolTip title='Restore Lab'><ReplayIcon sx={{ fontSize: 22, opacity: .8 }} onClick={() => onDeleteRestoreLabs('restore', rowData)} /></CustomToolTip>}
                </div>
            </React.Fragment>
        )
    }
    const HandleLabRange = (rowData: any) => {
        dispatch({ type: Types.LAB_ROWDATA, payload: rowData });
    }

    const renderLabName = (rowData: any) => {
        return (
            <div>
                <NavLink
                    className="" style={{ marginRight: 'auto' }}
                    to={`../labRange/${rowData.labId}`}
                    onClick={() => HandleLabRange(rowData)}
                >
                    {rowData && rowData.name}
                </NavLink>
            </div>
        )
    }

    const onPageChange = (event: any) => {
        if (((event.page > 0) || (pageClick && event.page === 0)) && tableparams.offset !== event.first) {
            const _payload = { ...tableparams, offset: event.first }
            dispatch({ type: Types.DATATABLE_PARAMS, payload: _payload })
            dispatch(fetchAllLabs(_payload))
            setpageChange(true)
        }
    }

    return (
        <React.Fragment>
            <div>
                <DataTable
                    value={labs?.lab}
                    scrollHeight="330px"
                    responsiveLayout="scroll"
                    selectionMode="single"
                    emptyMessage="No labs are available to display"
                    lazy
                    rows={tableparams.limit}
                    paginator={labs && labs.totalRecords > tableparams.limit ? true : false}
                    totalRecords={labs && labs.totalRecords}
                    first={tableparams.offset}
                    stripedRows={true}
                    onPage={onPageChange}
                >
                    <Column header='Name' body={renderLabName}></Column>
                    <Column header='Short Name' field="shortName"></Column>
                    <Column header='Region' field='region'></Column>
                    <Column header='Country' field="countryName"></Column>
                    <Column header='City' field="cityName"></Column>
                    <Column header='State' field="stateName"></Column>
                    <Column header='Category' field="categoryName"></Column>
                    <Column header='Test Name' field="testName"></Column>
                    <Column header="Actions" body={actionsTemplate}></Column>
                </DataTable>
            </div>
        </React.Fragment>
    )
}
export default LabDashBoard