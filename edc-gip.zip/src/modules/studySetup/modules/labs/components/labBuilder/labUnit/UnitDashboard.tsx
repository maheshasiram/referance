import React from "react";
import { useSelector, useDispatch } from 'react-redux';
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import DeleteIcon from '@mui/icons-material/Delete';
import ReplayIcon from '@mui/icons-material/Replay';
import { deleteUnit, fetchUnits, restoreUnit } from "../../../actions/actions";
import { Confirm, toastAlert } from "../../../../../../../actions/actions";
import { messages } from "../../../../../constants/messages";
import { Types } from "../../../reducer/Types";
import AddEditUnit from "./AddEditUnit";
import CustomToolTip from "../../../../../../../components/CustomToolTip";

function UnitDashboard(props: any) {

    const dispatch = useDispatch();
    // const loaded = React.useRef(false);
    const [pageClick, setPageClick] = React.useState(false);
    const { units, searchParams } = useSelector((state: any) => state.labs);
    const { searchTestName, searchByName, searchCategory, setSearchTestName, setSearchCategory } = props

    // React.useEffect(() => {
    //     if (!loaded.current) {
    //         let _payload = { ...{}, ...searchParams, limit: searchParams.limit, offset: searchParams.offset, term: '', searchValue: '' }
    //         dispatch(fetchUnits(_payload))
    //         loaded.current = true
    //     }
    // }, [])


    const onDeleteRestoreUnit = (type: any, rowData: any) => {
        dispatch(Confirm({
            status: 0,
            message: type === 'delete' ? messages.labs.deleteUnit : messages.labs.restoreUnit,
            onOk: () => {
                setSearchTestName('')
                setSearchCategory('')
                dispatch((type === 'delete' ? deleteUnit : restoreUnit)(rowData.unitId, (response: any) => {
                    dispatch(toastAlert({
                        status: 1, message: `${rowData.unitName}  ${response}`, open: true
                    }))
                    const _payload = { ...searchParams, limit: searchParams.limit, offset: searchParams.offset, searchValue: searchParams.searchValue }
                    dispatch({ type: Types.SEARCH_PARAMS, payload: _payload })
                    dispatch(fetchUnits(_payload))
                }))
            }
        }))
    }

    const actionsTemplate = (rowData: any) => {
        return (
            <React.Fragment>
                <div className="d-flex align-items-center" onClick={(e) => e.stopPropagation()}>
                    {rowData.status === true ? <React.Fragment>
                        <AddEditUnit rowData={rowData} />
                        <span> | </span>
                        <CustomToolTip title="Delete Unit"><DeleteIcon sx={{ fontSize: 14, opacity: .8 }} className="text-danger" onClick={() => onDeleteRestoreUnit('delete', rowData)} /></CustomToolTip>
                    </React.Fragment> : <CustomToolTip title='Restore Unit'><ReplayIcon sx={{ fontSize: 18, opacity: .8 }} onClick={() => onDeleteRestoreUnit('restore', rowData)} /></CustomToolTip>}
                </div>
            </React.Fragment>
        )
    }

    const onPageChange = (event: any) => {
        if (((event.page > 0) || (pageClick && event.page === 0)) && searchParams.offset !== event.first) {
            if (searchTestName !== '') {
                const searchPayload = { ...searchParams, offset: event.first, searchValue: searchTestName, term: searchByName, limit: 10 }
                dispatch({ type: Types.SEARCH_PARAMS, payload: searchPayload })
                dispatch(fetchUnits(searchPayload))
                setPageClick(true)
            } else if (searchCategory !== '') {
                const _searchPayload = { ...searchParams, offset: event.first, searchValue: searchCategory, term: searchByName, limit: 10 }
                dispatch({ type: Types.SEARCH_PARAMS, payload: _searchPayload })
                dispatch(fetchUnits(_searchPayload))
                setPageClick(true)
            } else {
                const _payload = { ...searchParams, offset: event.first }
                dispatch({ type: Types.SEARCH_PARAMS, payload: _payload })
                dispatch(fetchUnits(_payload))
                setPageClick(true)
            }
        }
    }

    return (
        <React.Fragment>
            <div>
                <DataTable
                    value={units?.labCategory}
                    scrollHeight='300px'
                    responsiveLayout='scroll'
                    selectionMode="single"
                    emptyMessage="No units are available to display"
                    lazy
                    rows={searchParams?.limit}
                    totalRecords={units && units.totalRecords}
                    paginator={units && units.totalRecords > searchParams?.limit ? true : false}
                    first={searchParams?.offset}
                    stripedRows={true}
                    onPage={onPageChange}
                >
                    <Column header='Unit' field='unitName'></Column>
                    <Column header='Test' field="testName"></Column>
                    <Column header='Category' field="categoryName"></Column>
                    <Column header='Action' body={actionsTemplate}></Column>
                </DataTable>
            </div>
        </React.Fragment>
    )
}

export default UnitDashboard