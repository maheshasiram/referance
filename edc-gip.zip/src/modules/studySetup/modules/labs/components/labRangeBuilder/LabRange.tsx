import React from "react";
import PageCount from "../../../../../../common/pagecount/PageCount";
import { Types } from "../../reducer/Types";
import AddEditLabRange from "./AddEditLabRange";
import { useNavigate, useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import LabRangeDashBoard from "./LabRangeDashBoard";
import { getAllLabRangesByLabId } from "../../actions/actions";
// import { labRangeData } from "../../constants/labRangeData";

function LabRange() {
    const navigate = useNavigate();
    const dispatch = useDispatch()
    const params = useParams()
    const { tableparams, labRowData, labRangesParams } = useSelector((state: any) => state.labs);

    const onBackToLabs = () => {
        navigate('/study/labs')
        const _payload = { ...tableparams, limit: tableparams.limit, offset: 0 }
        dispatch({ type: Types.DATATABLE_PARAMS, payload: _payload })
        const _fetchLabRange = { ...{}, ...labRangesParams, labId: params.id, offset: 0 }
        dispatch(getAllLabRangesByLabId(_fetchLabRange));
    }

    React.useEffect(() => {
    
        const payload = { ...labRangesParams, labId: params.id,  limit: 10, offset: 0  }
        dispatch(getAllLabRangesByLabId(payload, (response: any) => {
            dispatch({ type: Types.LAB_RANGES_DATA, payload: response });
        }))
        dispatch({ type: Types.LABRANGE_PARAMS, payload: payload })
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [labRowData])


    const onChangePageCount = (event: any) => {
        const _payload = { ...labRangesParams, limit: parseInt(event.target.value) }
        dispatch({ type: Types.LABRANGE_PARAMS, payload: _payload })
        dispatch(getAllLabRangesByLabId(_payload))
    }

    return (
        <React.Fragment>
            <div className=" d-flex justify-content-between">
                <div className=" d-flex">
                    <PageCount onChange={(e: any) => onChangePageCount(e)}/>
                    <div className="ms-2">
                        <AddEditLabRange actionType={0} />
                    </div>
                </div>
                <div className="d-flex justify-content-end">
                    <button className="btn-eoutlined-secondary" onClick={onBackToLabs} >← Back To Labs</button>
                </div>
            </div>
            <div className=" mt-2">
                <LabRangeDashBoard />
            </div>
        </React.Fragment>
    )
}

export default LabRange;