import React from "react";
import { useDispatch, useSelector } from "react-redux";
import CustomDialog from "../../../../../../common/modals/CustomeDialog";
import { Formik, Form, Field, FieldArray, ErrorMessage, } from "formik";
import AddCircleOutlineOutlined from "@mui/icons-material/AddCircleOutlineOutlined";
import RemoveCircleOutlineIcon from '@mui/icons-material/RemoveCircleOutline';
import { labRangeValidation } from "../../helpers/Validations";
import { genderValues, labRangeModel } from "../../constants/models";
import CustomToolTip from "../../../../../../components/CustomToolTip";
import EditIcon from '@mui/icons-material/Edit';
import { Types } from "../../reducer/Types";
import '../../../../styles.scss';
import { useParams } from "react-router-dom";
import { createLabRange, getAllLabRangesByLabId, updateLabRange } from "../../actions/actions";
import { toastAlert } from "../../../../../../actions/actions";
// import { labRangeData } from "../../constants/labRangeData";


function AddEditLabRange(props: any) {
    const dispatch = useDispatch();
    const [btnDisable, setBtnDisable] = React.useState(true);
    const { labRange, fetchLabRange } = useSelector((state: any) => state.labs);
    const [open, setOpen] = React.useState(false)
    const [errorMessage, setErrorMessage] = React.useState('');
    const { rowData } = props
    const [ageLimit, setAgeLimit] = React.useState(0);
    // const [limits, setLimits] = React.useState(0);
    const params = useParams()


    const onLabRangeCloseHandle = () => {
        setOpen(false)
        setBtnDisable(true)
    }

    const validateMinAge = (value: any) => {
        setAgeLimit(value)
    }

    const validateMaxAge = (value: any) => {
        let error;
        if (value < ageLimit) {
            error = "Maximum age limit should be greater than Minimum age limit"
        }
        return error;
    }

    const onSubmitHandler = (values: any) => {
        let payload;
        if (props.actionType === 1) {
            const updatepayload = [...[], ...values.labRange]
            payload = updatepayload[0]
        } else {
            payload = [...[], ...values.labRange]
        }
        dispatch((props.actionType === 1 ? updateLabRange : createLabRange)(payload, (response: any) => {
            if (!response.error) {
                // let payload = { ...labRangeData, labid: params.id }
                dispatch(toastAlert({
                    status: 1,
                    message: `Lab Range  ${props.actionType === 1 ? 'updated' : 'created'} Successfully`,
                    open: true
                }))
                const _fetchLabRange = { ...{}, ...fetchLabRange, labId: params.id }
                dispatch(getAllLabRangesByLabId(_fetchLabRange));
                setOpen(false);
            }
        }))
    }

    const onVlidateLabRange = (values: any, helper: any, type: any) => {
        console.warn('values in add......', values.labRange[values.labRange.length - 1]);
        const _lastRecord = values.labRange[values.labRange.length - 1]
        if ((_lastRecord.upperLimit === '' || _lastRecord.loweLimit === '' || _lastRecord.minAge === '' || _lastRecord.maxAge === '' || _lastRecord.gender === '')) {
            setErrorMessage("Enter the all fields value");
        } else {
            type === 'addField' ? helper.push(labRangeModel.labRange[0]) : onSubmitHandler(values);
        }
    }

    const onOpenLabRangeDialog = (type: any) => {
        const arr = [];
        setOpen(true)
        setErrorMessage('')
        if (type === 'add') {
            dispatch({ type: Types.CREATE_LAB_RANGE, payload: labRangeModel })
        } else {
            const payload = { ...{}, ...labRange }
            // payload.labRange.push(rowData)
            arr.push(rowData)
            payload.labRange = arr;
            // let _payload = { labRange: [rowData] }
            // console.log("123..", labRowData,_payload)            
            // dispatch({ type: Types.CREATE_LAB_RANGE, payload: rowData ? _payload : labRangeModel })
            dispatch({ type: Types.CREATE_LAB_RANGE, payload: payload })

        }
        setBtnDisable(true)
    }

    // const validateLowerLimit = (value: any) => {
    //     setLimits(value)
    // }

    // const validateUpperLimit = (value: any) => {
    //     let error;
    //     if (value < limits) {
    //         error = "Upper limit should be greater then Lower limit"
    //     }
    //     return error;
    // }
    const onUpperLimitChange = (e: any, setFieldValue: any, index: any) => {
        if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
            setFieldValue(`labRange.${index}.refUpperRange`, e.target.value)
            setBtnDisable(false)
            setErrorMessage("")
        }
      
    }

    const onLoweLimitChange = (e: any, setFieldValue: any, index: any) => {
        if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
            setFieldValue(`labRange.${index}.refLowerRange`, e.target.value)
            setErrorMessage("")
            setBtnDisable(false)
        }
    }

    const onLoweAgeLimitChange = (e: any, setFieldValue: any, index: any) => {
        setFieldValue(`labRange.${index}.ageMin`, parseInt(e.target.value))
        setBtnDisable(false)
        setErrorMessage("")
    }

    const onUpperAgeLimitChange = (e: any, setFieldValue: any, index: any) => {
        setFieldValue(`labRange.${index}.ageMax`, parseInt(e.target.value))
        setBtnDisable(false)
        setErrorMessage("")
    }

    const onGenderValueChange = (e: any, setFieldValue: any, index: any, values: any) => {
        setFieldValue(`labRange.${index}.gender`, e.target.value)
        values.labRange.map((i: any) => i.labId = params.id)
        setBtnDisable(false)
        console.log("..112", values);
        setErrorMessage("")
    }

    const onRemoveLabRangeField = (e: any, helper: any, index: any) => {
        helper.remove(index)
        setErrorMessage("")
        setBtnDisable(false)
    }

    return (
        <React.Fragment>
            {props.actionType === 1 ?
                <CustomToolTip title='Edit Lab Range'><EditIcon sx={{ fontSize: 14, opacity: .8 }} onClick={() => onOpenLabRangeDialog('edit')} /></CustomToolTip> :
                < button className="btn-eoutlined-secondary" onClick={() => onOpenLabRangeDialog('add')}>Create Lab-Range</button>}
            <div>
                <CustomDialog
                    title={props.actionType === 1 ? 'Update Lab Range' : 'Create Lab Range'}
                    open={open}
                    onClose={onLabRangeCloseHandle}
                    actionType={props.actionType === 1 ? 'Update' : 'Submit'}
                    maxWidth="md"
                    form={'labRangesForm'}
                    fullWidth={true}
                    disabled={btnDisable}

                >
                    <div>
                        <Formik
                            enableReinitialize={true}
                            initialValues={labRange}
                            validationSchema={labRangeValidation}
                            onSubmit={(values: any) => {
                                onSubmitHandler(values);
                            }}
                        >
                            {({ values,setFieldValue}) => (
                                <Form id='labRangesForm'>
                                    <div className='add-labrange'>
                                        <FieldArray
                                            name="labRange"
                                            render={(helper) => {
                                                const _labRange = values.labRange
                                                return (
                                                    <div className="">
                                                        <div className="d-flex ">
                                                            <label id='label' className="addLabRange">Add Lab-Range</label>
                                                            <AddCircleOutlineOutlined
                                                                className='text-primary addRangeFields'
                                                                fontSize='small'
                                                                onClick={() => { onVlidateLabRange(values, helper, 'addField') }}
                                                            />
                                                        </div>
                                                        {errorMessage &&
                                                            <span className="" style={{ color: 'red', marginLeft: 10 }}>{errorMessage}</span>}
                                                        {_labRange &&
                                                            _labRange.map((data: any, index: number) => (
                                                                <div key={index} className="d-flex ranges">
                                                                    <div className=" form-group ranges-inputs ">
                                                                        <label id='upperL'>Upper Limit : </label>
                                                                        <Field
                                                                            name={`labRange.${index}.refUpperRange`}
                                                                            value={values.labRange[index].refUpperRange}
                                                                            className="form-control form-control-lg"
                                                                            // type='number'
                                                                            placeholder={"Upper Range"}
                                                                            // min="0"
                                                                            // max="100"
                                                                            // validate={(value: any) => validateUpperLimit(value)}
                                                                            // onKeyPress={(e: any) => {
                                                                            //     if (e.key === "-" || e.key === "+" || e.key === "e" || e.key == ".") {
                                                                            //         e.preventDefault();
                                                                            //     }
                                                                            // }}
                                                                            onChange={(e: any) => onUpperLimitChange(e, setFieldValue, index)}
                                                                        >
                                                                        </Field>
                                                                        <div className="text-danger error-message"><ErrorMessage name={`labRange.${index}.refUpperRange`} /></div>

                                                                    </div>
                                                                    <div className="form-group ranges-inputs">
                                                                        <label id='lowerL'>Lower Limit : </label>
                                                                        <Field
                                                                            name={`labRange.${index}.refLowerRange`}
                                                                            value={values.labRange[index].refLowerRange}
                                                                            className="form-control form-control-lg"
                                                                            // type='number'
                                                                            placeholder={"Lower Range"}
                                                                            // min="0" 
                                                                            // max="100" 
                                                                            // validate={(value: any) => validateLowerLimit(value)} 
                                                                            // onKeyPress={(e: any) => { 
                                                                            //     if (e.key === "-" || e.key === "+" || e.key === "e" || e.key == ".") { 
                                                                            //         e.preventDefault(); 
                                                                            //     } 
                                                                            // }} 
                                                                            onChange={(e: any) =>
                                                                                onLoweLimitChange(e, setFieldValue, index)}
                                                                        >
                                                                        </Field>
                                                                        <div className="text-danger"><ErrorMessage name={`labRange.${index}.refLowerRange`} /></div>

                                                                    </div>
                                                                    <div className="form-group ranges-inputs">
                                                                        <label id='ageMin'>Min Age : </label>
                                                                        <Field
                                                                            name={`labRange.${index}.ageMin`}
                                                                            value={values.labRange[index].ageMin}
                                                                            className="form-control form-control-lg"
                                                                            type='number'
                                                                            min="0"
                                                                            max="100"
                                                                            placeholder={"Min age"}
                                                                            validate={(value: any) => validateMinAge(value)}
                                                                            onKeyPress={(e: any) => {
                                                                                if (e.key === "-" || e.key === "+" || e.key === "e" || e.key === ".") {
                                                                                    e.preventDefault();
                                                                                }
                                                                            }}
                                                                            onChange={(e: any) => onLoweAgeLimitChange(e, setFieldValue, index)}
                                                                        >
                                                                        </Field>
                                                                        <div className="text-danger"><ErrorMessage name={`labRange.${index}.ageMin`} /></div>
                                                                    </div>
                                                                    <div className="form-group ranges-inputs">
                                                                        <label id='ageMax'>Max Age : </label>
                                                                        <Field
                                                                            name={`labRange.${index}.ageMax`}
                                                                            value={values.labRange[index].ageMax}
                                                                            className="form-control form-control-lg"
                                                                            placeholder={"Max age"}
                                                                            type='number'
                                                                            min="0"
                                                                            max="100"
                                                                            validate={(value: any) => validateMaxAge(value)}
                                                                            onKeyPress={(e: any) => {
                                                                                if (e.key === "-" || e.key === "+" || e.key === "e" || e.key === ".") {
                                                                                    e.preventDefault();
                                                                                }
                                                                            }}
                                                                            onChange={(e: any) => onUpperAgeLimitChange(e, setFieldValue, index)}
                                                                        >
                                                                        </Field>
                                                                        <>
                                                                        {console.log('289...',values)}
                                                                        </>
                                                                        <div className="text-danger"><ErrorMessage name={`labRange.${index}.ageMax`} /></div>
                                                                    </div>
                                                                    <div className="form-group ranges-inputs">
                                                                        <label id='gender'>Gender : </label>
                                                                        <Field
                                                                            name={`labRange.${index}.gender`}
                                                                            as='select'
                                                                            value={values.labRange[index].gender}
                                                                            className="form-select form-control-lg"
                                                                            placeholder={"Gender"}
                                                                            onChange={(e: any) => onGenderValueChange(e, setFieldValue, index, values)}
                                                                        >
                                                                            <option value=''>Select Gender</option>
                                                                            {
                                                                                genderValues && genderValues.map((category: any, index: any) => (
                                                                                    <option key={index} value={category.id}>{category.name}</option>
                                                                                ))
                                                                            }
                                                                        </Field>
                                                                        <div className="text-danger"><ErrorMessage name={`labRange.${index}.gender`} /></div>
                                                                    </div>
                                                                    <div className="mt-4">
                                                                        {_labRange.length > 1 && <RemoveCircleOutlineIcon
                                                                            sx={{ cursor: 'pointer' }}
                                                                            color='error'
                                                                            className=""
                                                                            onClick={(e: any) => onRemoveLabRangeField(e, helper, index)}
                                                                        />}
                                                                    </div>
                                                                </div>
                                                            ))
                                                        }
                                                    </div>
                                                )
                                            }}
                                        ></FieldArray>
                                    </div>
                                </Form>
                            )}

                        </Formik>
                    </div>
                </CustomDialog>
            </div >
        </React.Fragment>
    )
}

export default AddEditLabRange;