import React from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import DeleteIcon from '@mui/icons-material/Delete';
import CustomToolTip from "../../../../../../components/CustomToolTip";
// import { labRangeData } from "../../constants/labRangeData";
import AddEditLabRange from "./AddEditLabRange";
import { useDispatch, useSelector } from "react-redux";
import ReplayIcon from '@mui/icons-material/Replay';
import { Confirm, toastAlert } from "../../../../../../actions/actions";
import { deleteLabRange, getAllLabRangesByLabId, restoreLabRange } from "../../actions/actions";
import { useParams } from "react-router-dom";
import { messages } from "../../../../constants/messages";
import { Types } from "../../reducer/Types";

function LabRangeDashBoard() {
    const dispatch = useDispatch();
    const [pageClick, setpageChange] = React.useState(false);
    const { labRangeData,labRangesParams } = useSelector((state: any) => state.labs);
    const params = useParams()

    
    const onPageChange = (event: any) => {
        if (((event.page > 0) || (pageClick && event.page === 0)) && labRangesParams.offset !== event.first) {
            const _payload = { ...labRangesParams, offset: event.first ,labId:params.id}
            dispatch({ type: Types.LABRANGE_PARAMS, payload: _payload })
            dispatch(getAllLabRangesByLabId(_payload))
            setpageChange(true)
        }
    }

    const onDeleteRestoreLabRange = (type: any, rowData: any) => {
        dispatch(Confirm({
            status: 0, 
            message: type === 'delete' ? messages.labs.deleteLabRange : messages.labs.restoreLabRange,

            onOk: () => {
                dispatch((type === 'delete' ? deleteLabRange : restoreLabRange)(rowData.id, () => {
                    // dispatch(toastAlert({
                    //     status: 1, message: response, open: true
                    // }))
                    dispatch(toastAlert({
                        status: 1,
                        message: `Lab Range  ${type === 'delete' ? 'deleted' : 'restored'} Successfully`,
                        open: true
                    }))
                    // let payload = { ...labRangeData, labid: params.id }
                    const _fetchLabRange = { ...{}, ...labRangesParams, labId: params.id,offset:0 }
                    dispatch(getAllLabRangesByLabId(_fetchLabRange));
                    // let _data = { ...tableparams, limit: tableparams.limit, offset: tableparams.offset }
                }))
            }
        }))
    }

    const actionsTemplate = (rowData: any) => {
        return (
            <React.Fragment>
                <div className='actions d-flex'>
                    {
                        rowData.status === true ? <React.Fragment>
                            <AddEditLabRange actionType={1} rowData={rowData} />
                            <span> | </span>
                            <CustomToolTip title="Delete Lab Range"><DeleteIcon sx={{ fontSize: 14, opacity: .8 }} className="text-danger" onClick={() => onDeleteRestoreLabRange('delete', rowData)} /></CustomToolTip>
                        </React.Fragment> : <React.Fragment><CustomToolTip title='Restore Lab Range'><ReplayIcon sx={{ fontSize: 22, opacity: .8 }} onClick={() => onDeleteRestoreLabRange('restore', rowData)} /></CustomToolTip></React.Fragment>
                    }

                    {/* {rowData.status === true ? <React.Fragment>
                        <AddEditLabRange actionType={1} />
                        <span> | </span>
                        <CustomToolTip title="Delete Group"><DeleteIcon sx={{ fontSize: 14, opacity: .8 }} className="text-danger" onClick={() => onDeleteRestoreLabRange('delete', rowData)} /></CustomToolTip>
                    </React.Fragment> : <CustomToolTip title='Restore Group'><ReplayIcon sx={{ fontSize: 22, opacity: .8 }} onClick={() => onDeleteRestoreLabRange('restore', rowData)} /></CustomToolTip>} */}
                </div>
            </React.Fragment>
        )
    }

    return (
        <React.Fragment>
            <div>
                <DataTable
                    value={labRangeData?.labRanges}
                    scrollHeight="300px"
                    responsiveLayout="scroll"
                    // scrollable
                    // value={labRangeData && labRangeData.visits}
                    selectionMode="single"
                    emptyMessage="No Lab Ranges Are Available To Display."
                    lazy
                    rows={labRangesParams.limit}
                    totalRecords={labRangeData && labRangeData.totalRecords}
                    paginator={labRangeData && labRangeData.totalRecords > labRangesParams.limit ? true : false}
                    first={labRangesParams.offset}
                     stripedRows={true}
                    onPage={onPageChange}

                >
                    <Column header='Upper-Limit' field="refUpperRange"></Column>
                    <Column header='Lower-Limit' field='refLowerRange'></Column>
                    <Column header='Max-Age' field="ageMax"></Column>
                    <Column header='Min-Age' field="ageMin"></Column>
                    <Column header='Gender' field="gender"></Column>
                    <Column header='Action' body={actionsTemplate}></Column>

                </DataTable>
            </div>
        </React.Fragment>
    )
}

export default LabRangeDashBoard;