import React from "react";
import Lab from "./components/labBuilder/Lab";

function Labs() {
    return (
        <React.Fragment>
            <div>
                <Lab />
            </div>
        </React.Fragment>
    )

}
export default Labs;    