import { labModel, testModel, categoryModel, unitModel, labRangeModel, fetchlabRangeModel } from "../constants/models";
import { Types } from "./Types";

const initialState = {
    lab: labModel,  // create lab
    test: testModel, // create test
    category: categoryModel, // create category
    unit: unitModel, // create unit
    fetchLabRange: fetchlabRangeModel,
    labRange: labRangeModel,//create lab range
    labRangeData: null,
    labRangesParams: {
        labId: 0,
        limit: 10,
        offset: 0,
    },
    categories: null,//for table 
    categoriesList: null, //all categories without params(dropdown)
    testByCatoegoryId: null, // test for dropdown
    tests: null, //for table
    units: null, // for table
    labs: null,//for table
    tableparams: {
        limit: 10,
        offset: 0,
    },
    searchParams: {
        limit: 10,
        offset: 0,
        term: "",
        searchValue: ""
    },
    categoryParams: {
        limit: 10,
        offset: 0,
        searchValue: ''
    },
    labRowData: null
}

export const labs = (state = initialState, action: { type: any, payload: any }) => {
    switch (action.type) {
        case Types.CREATE_LAB:
            return { ...state, lab: action.payload }
        case Types.DATATABLE_PARAMS:
            return { ...state, tableparams: action.payload }
        case Types.CATEGORY_PARAMS:
            return { ...state, categoryParams: action.payload }
        case Types.GET_ALL_GROUPS:
            return { ...state, categories: action.payload }
        case Types.CREATE_TEST:
            return { ...state, test: action.payload }
        case Types.CREATE_GROUP:
            return { ...state, category: action.payload }
        case Types.LAB_GROUPS:
            return { ...state, categoriesList: action.payload }
        case Types.FETCH_ALL_TEST_RECORDS:
            return { ...state, tests: action.payload }
        case Types.TESTS_LIST_DATA:
            return { ...state, testByCatoegoryId: action.payload }
        case Types.CREATE_UNITS:
            return { ...state, unit: action.payload }
        case Types.ALL_UNITS_DATA:
            return { ...state, units: action.payload }
        case Types.CREATE_LAB_RANGE:
            return { ...state, labRange: action.payload }
        case Types.FETCH_LABS_DATA:
            return { ...state, labs: action.payload }
        case Types.SEARCH_PARAMS:
            return { ...state, searchParams: action.payload }
        case Types.FETCH_LAB_RANGE:
            return { ...state, fetchLabRange: action.payload }
        case Types.LAB_RANGES_DATA:
            return { ...state, labRangeData: action.payload }
        case Types.LAB_ROWDATA:
            return { ...state, labRowData: action.payload }
        case Types.LABRANGE_PARAMS:
            return { ...state, labRangesParams: action.payload }
        default:
            return { ...state }
    }
}