import { studySetup } from "../../../../../configs/enivornment/studySetup";
import { fetch } from "../../../../../constants/fetch";
import { Types } from "../reducer/Types";
import { Loader } from "../../../../../actions/actions";

//all categories for data table
export const fetchCategories: any = (payload: any) => {
    const url = `${studySetup.labs.categoriesList}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload
        })
            .then((response: any) => {
                dispatch({ type: Types.GET_ALL_GROUPS, payload: response.data })
                dispatch(Loader(false))
            })
    }
}


//all test for data table
export const fetchTests: any = (payload: any) => {
    const url = `${studySetup.labs.getAllTests}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload
        })
            .then((response: any) => {
                dispatch({ type: Types.FETCH_ALL_TEST_RECORDS, payload: response.data })
                dispatch(Loader(false))
            })
    }
}

//fetch All Units for data table
export const fetchUnits: any = (payload: any) => {
    const url = `${studySetup.labs.getAllUnits}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload
        }).then((response) => {
            dispatch({ type: Types.ALL_UNITS_DATA, payload: response.data })
            dispatch(Loader(false))
        })
    }
}

//fetch all labs for data table
export const fetchAllLabs: any = (payload: any) => {
    const url = `${studySetup.labs.fetchAllLabs}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload
        }).then((response) => {
            dispatch({ type: Types.FETCH_LABS_DATA, payload: response.data })
            dispatch(Loader(false))
        })
    }
}

//fetching all lab range data
export const getAllLabRangesByLabId: any = (payload: any, callback: any) => {
    // let url = `${studySetup.labs.getAllLabRangesByLabId}?labId=${labId}`
    const url = studySetup.labs.getAllLabRangesByLabId
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload
        }).then((response) => {
            dispatch({ type: Types.LAB_RANGES_DATA, payload: response.data })
            if (callback) { callback(response.data) }
            dispatch(Loader(false))
        }
        )
    }
}

//create test
export const createTest: any = (payload: any, callback: any) => {
    const url = `${studySetup.labs.createTest}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data)
                    dispatch(Loader(false))
                }
            })
    }
}

//create category
export const createCategory: any = (payload: any, callback: any) => {
    const url = `${studySetup.labs.createCategory}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data)
                    dispatch(Loader(false))
                }
            })
    }
}
// Create Unit
export const createUnit: any = (payload: any, callback: any) => {
    const url = `${studySetup.labs.createUnit}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data)
                }
                dispatch(Loader(false))
            })
    }
}

//create lab
export const createLab: any = (payload: any, callback: any) => {
    const url = `${studySetup.labs.createLab}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload
        }).then((response: any) => {
            if (callback) {
                callback(response.data)
            } dispatch(Loader(false))
        })
    }
}

// create lab-range
export const createLabRange: any = (payload: any, callback: any) => {
    const url = `${studySetup.labs.createLabRange}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload
        }).then((response: any) => {
            if (callback) {
                callback(response.data)
            } dispatch(Loader(false))
        })
    }
}

//update unit
export const updateUnit: any = (payload: any, callback: any) => {
    const url = `${studySetup.labs.updateUnit}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data)
                }
                dispatch(Loader(false))
            })
    }
}

//update category
export const updateCategory: any = (payload: any, callback: any) => {
    const url = `${studySetup.labs.updateCategory}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data)
                    dispatch(Loader(false))
                }
            })
    }
}

// update Lab Range
export const updateLabRange: any = (payload: any, callback: any) => {
    const url = `${studySetup.labs.updateLabRange}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data)
                    dispatch(Loader(false))
                }
            })
    }
}

// update test
export const updateTest: any = (payload: any, callback: any) => {
    const url = `${studySetup.labs.updateTest}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data)
                    dispatch(Loader(false))
                }
            })
    }
}

//update lab
export const updateLab: any = (payload: any, callback: any) => {
    const url = `${studySetup.labs.updateLab}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data)
                    dispatch(Loader(false))
                }
            })
    }
}

//delete unit
export const deleteUnit: any = (labUnitId: any, callback: any) => {
    const url = `${studySetup.labs.deleteUnit}?labUnitId=${labUnitId}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: ''
        }).then((response) => {
            if (callback) { callback(response.data) }
            dispatch(Loader(false))
        }
        )
    }
}

//delete category
export const deleteCategory: any = (labId: any, callback: any) => {
    const url = `${studySetup.labs.deleteCategory}?labId=${labId}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: ''
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data)
                    dispatch(Loader(false))
                }
            })
    }
}

//delete lab range
export const deleteLabRange: any = (labRangeId: any, callback: any) => {
    const url = `${studySetup.labs.deleteLabRange}?labRangeId=${labRangeId}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: ''
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data)
                    dispatch(Loader(false))
                }
            })
    }
}

//delete test
export const deleteTest: any = (labTestId: any, callback: any) => {
    const url = `${studySetup.labs.deleteTest}?labTestId=${labTestId}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: ''
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data)
                    dispatch(Loader(false))
                }
            })
    }
}

//delete lab
export const deleteLabs: any = (labId: any, callback: any) => {
    const url = `${studySetup.labs.deleteLabs}?labId=${labId}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
        }).then((response: any) => {
            if (callback) {
                callback(response.data)
                dispatch(Loader(false))
            }
        })
    }
}

//restore unit
export const restoreUnit: any = (labUnitId: any, callback: any) => {
    const url = `${studySetup.labs.restoreUnit}?labUnitId=${labUnitId}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: '',
        }).then((response) => {
            if (callback) {
                callback(response.data)
            }
            dispatch(Loader(false))
        })
    }
}

//restore category
export const restoreCategory: any = (labCategoryId: any, callback: any) => {
    const url = `${studySetup.labs.restoreCategory}?labCategoryId=${labCategoryId}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: ''
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data)
                    dispatch(Loader(false))
                }
            })
    }
}

//restore test
export const restoreTest: any = (labTestId: any, callback: any) => {
    const url = `${studySetup.labs.restoreTest}?labTestId=${labTestId}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: ''
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data)
                    dispatch(Loader(false))
                }
            })
    }
}

// Restore lab
export const restoreLabs: any = (labId: any, callback: any) => {
    const url = `${studySetup.labs.restoreLabs}?labId=${labId}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            url: url,
            method: 'POST',
        }).then((response: any) => {
            if (callback) {
                callback(response.data)
                dispatch(Loader(false))
            }
        })
    }
}

//restore lab Range
export const restoreLabRange: any = (labRangeId: any, callback: any) => {
    const url = `${studySetup.labs.restoreLabRange}?labRangeId=${labRangeId}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            url: url,
            method: 'POST',
        }).then((response: any) => {
            if (callback) {
                callback(response.data)
                dispatch(Loader(false))
            }
        })
    }
}

//search test
export const searchByTestName: any = (payload: string) => {
    const Url = `${studySetup.labs.fetchByTestName}?testName=${payload}`
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'GET',
            url: Url,
        })
            .then((response: any) => {
                // let _response = _.cloneDeep(response.data);
                // _response.test = labCategory;
                // console.log("338...", _response)
                dispatch({ type: Types.FETCH_ALL_TEST_RECORDS, payload: response.data });
                dispatch(Loader(false));
            })
    }
}

//search unit
export const searchByUnitName: any = (payload: string) => {
    const Url = `${studySetup.labs.fetchByUnitName}?unitName=${payload}`
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'GET',
            url: Url,
        })
            .then((response: any) => {
                dispatch({ type: Types.ALL_UNITS_DATA, payload: response.data })
                // dispatch({ type: Types.UNIT_TOTAL_RECORDS, payload: response.data.totalRecords })
                dispatch(Loader(false));
            })
    }
}


//search category
export const fetchByCategoryName: any = (payload: string) => {
    const Url = `${studySetup.labs.fetchByCategoryName}?cateogoryName=${payload}`
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'GET',
            url: Url,
        })
            .then((response: any) => {
                dispatch({ type: Types.GET_ALL_GROUPS, payload: response.data });
                dispatch(Loader(false));
            })
    }
}

//fetchByCategoryorTestName
export const fetchByCategoryorTestName: any = (payload: any) => {
    const url = `${studySetup.labs.fetchByCategoryorTestName}`
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'POST',
            url: url,
            data: payload
        }).then((response: any) => {
            dispatch({ type: Types.FETCH_ALL_TEST_RECORDS, payload: response.data })
            dispatch({ type: Types.ALL_UNITS_DATA, payload: response.data })
            dispatch(Loader(false));
        })
    }
}

// created category list 
export const getAllCategoriesList: any = () => {
    const url = `${studySetup.labs.getAllCategoriesList}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: ''
        })
            .then((response: any) => {
                dispatch({ type: Types.LAB_GROUPS, payload: response.data })
                dispatch(Loader(false))
            })
    }
}

//created test list
export const getTestNameByCategoryId: any = (categoryId: any, callback: any) => {
    const url = `${studySetup.labs.testsList}?categoryId=${categoryId}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
        }).then((response: any) => {
            dispatch({ type: Types.TESTS_LIST_DATA, payload: response.data })
            if (callback) {
                callback(response.data)
            }
            dispatch(Loader(false))
        })
    }
}






