export type configDataType = {
    "id": number,
    "name": string,
    "description": string,
    "code": string,
}

export type role = {
    name?: string,
    id?: number,
    description?: string,
    studyId?: any,
    status?: boolean,
    staticRole?: boolean
}

export type privilegesAssigneToRole = {
    privilegeGroups?: [],
    role?: role
}

export type privilegeGroup = {
    id?: any,
    name?: string
}

export type privilesWithGroup = {
    privilegeGroup?: privilegeGroup,
    privilegeNames?: any
}


//cerate role
export type createRole = {
    name?: string,
    id?: number,
    description?: string,
    studyId?: number,
    status?: boolean,
    staticRole?: boolean
    // code: string,
    // configDataType: configDataType
}