export const rolesGridData: any = [

    {
        "id": 1410,
        "name": "Role Test",
        "code": "USER_ROLE_TYPE_ROLE_TEST",
        "description": "Role Test",
        "configDataType": {
            "id": 6,
            "name": "User Role",
            "code": "USER_ROLE_TYPE",
            "description": "describes the role of user"
        }
    },
    {
        "id": 1442,
        "name": "infonewone",
        "code": "USER_ROLE_TYPE_INFONEWONE",
        "description": "infonewone",
        "configDataType": {
            "id": 6,
            "name": "User Role",
            "code": "USER_ROLE_TYPE",
            "description": "describes the role of user"
        }
    },
    {
        "id": 1378,
        "name": "studyDev",
        "code": "USER_ROLE_TYPE_STUDYDEV",
        "description": "studyDev",
        "configDataType": {
            "id": 6,
            "name": "User Role",
            "code": "USER_ROLE_TYPE",
            "description": "describes the role of user"
        }
    },
    {
        "id": 1043,
        "name": "Approver",
        "code": "USER_ROLE_TYPE_APPROVER",
        "description": "Approval",
        "configDataType": {
            "id": 6,
            "name": "User Role",
            "code": "USER_ROLE_TYPE",
            "description": "describes the role of user"
        }
    },
    {
        "id": 731,
        "name": "admin",
        "code": "USER_ROLE_TYPE_ADMIN",
        "description": "Admin",
        "configDataType": {
            "id": 6,
            "name": "User Role",
            "code": "USER_ROLE_TYPE",
            "description": "describes the role of user"
        }
    },
    {
        "id": 1429,
        "name": "role new test",
        "code": "USER_ROLE_TYPE_ROLE_NEW_TEST",
        "description": "role new test",
        "configDataType": {
            "id": 6,
            "name": "User Role",
            "code": "USER_ROLE_TYPE",
            "description": "describes the role of user"
        }
    },
    {
        "id": 1399,
        "name": "test role",
        "code": "USER_ROLE_TYPE_TEST_ROLE",
        "description": "test role",
        "configDataType": {
            "id": 6,
            "name": "User Role",
            "code": "USER_ROLE_TYPE",
            "description": "describes the role of user"
        }
    },
    {
        "id": 1416,
        "name": "information Role",
        "code": "USER_ROLE_TYPE_INFORMATION_ROLE",
        "description": "information Role",
        "configDataType": {
            "id": 6,
            "name": "User Role",
            "code": "USER_ROLE_TYPE",
            "description": "describes the role of user"
        }
    },
    {
        "id": 1062,
        "name": "Clinical data analyst",
        "code": "USER_ROLE_TYPE_CLINICAL_DATA_ANALYST",
        "description": "Clinical data analyst",
        "configDataType": {
            "id": 6,
            "name": "User Role",
            "code": "USER_ROLE_TYPE",
            "description": "describes the role of user"
        }
    },
    {
        "id": 972,
        "name": "study approver",
        "code": "USER_ROLE_TYPE_STUDY_APPROVER",
        "description": "study approver1",
        "configDataType": {
            "id": 6,
            "name": "User Role",
            "code": "USER_ROLE_TYPE",
            "description": "describes the role of user"
        }
    },
    {
        "id": 1424,
        "name": "Test new Role",
        "code": "USER_ROLE_TYPE_TEST_NEW_ROLE",
        "description": "Test new Role",
        "configDataType": {
            "id": 6,
            "name": "User Role",
            "code": "USER_ROLE_TYPE",
            "description": "describes the role of user"
        }
    },
    {
        "id": 1484,
        "name": "testing new role 1",
        "code": "USER_ROLE_TYPE_TESTING_NEW_ROLE_1",
        "description": "testing new role",
        "configDataType": {
            "id": 6,
            "name": "User Role",
            "code": "USER_ROLE_TYPE",
            "description": "describes the role of user"
        }
    },
    {
        "id": 1485,
        "name": "demo",
        "code": "USER_ROLE_TYPE_DEMO",
        "description": "demo",
        "configDataType": {
            "id": 6,
            "name": "User Role",
            "code": "USER_ROLE_TYPE",
            "description": "describes the role of user"
        }
    },
    {
        "id": 1247,
        "name": "CRC",
        "code": "USER_ROLE_TYPE_CRC",
        "description": "CRC",
        "configDataType": {
            "id": 6,
            "name": "User Role",
            "code": "USER_ROLE_TYPE",
            "description": "describes the role of user"
        }
    },
    {
        "id": 1248,
        "name": "Data Manager",
        "code": "USER_ROLE_TYPE_DATA_MANAGER",
        "description": "Data Manager",
        "configDataType": {
            "id": 6,
            "name": "User Role",
            "code": "USER_ROLE_TYPE",
            "description": "describes the role of user"
        }
    },
    {
        "id": 1249,
        "name": "Monitor",
        "code": "USER_ROLE_TYPE_MONITOR",
        "description": "Monitor",
        "configDataType": {
            "id": 6,
            "name": "User Role",
            "code": "USER_ROLE_TYPE",
            "description": "describes the role of user"
        }
    },
    {
        "id": 1425,
        "name": "New Test Role",
        "code": "USER_ROLE_TYPE_NEW_TEST_ROLE",
        "description": "New Test Role",
        "configDataType": {
            "id": 6,
            "name": "User Role",
            "code": "USER_ROLE_TYPE",
            "description": "describes the role of user"
        }
    },
    {
        "id": 1363,
        "name": "DevRole",
        "code": "USER_ROLE_TYPE_DEVROLE",
        "description": "DevRole",
        "configDataType": {
            "id": 6,
            "name": "User Role",
            "code": "USER_ROLE_TYPE",
            "description": "describes the role of user"
        }
    }
]