import { privilesWithGroup, privilegesAssigneToRole } from "./dataTypes";

export const configDataType = {
    id: 0,
    name: "",
    code: "",
    description: ""
}

export const privilegesAssignedToRoleModel: privilegesAssigneToRole = {
    privilegeGroups: [],
    role: {
        id: 0,
        studyId: '',
        name: "",
        description: "",
        status: true,
        staticRole: false
    }
}


export const addPrivilegesToGroupModel: privilesWithGroup = {
    privilegeGroup: {
        name: '',
        id: 0
    },
    privilegeNames: ['']

}

//create Role
export type createRole =
    {
        "id": 0,
        "studyId": '',
        "name": "",
        "description": "",
        "status": true,
        "staticRole": false
    }
