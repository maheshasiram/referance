import React from 'react'
import RolesDashboard from './components/RolesDashboard';
import "./styles/styles.scss"
function RolesandPermissions() {
  return(
    <React.Fragment>
    <RolesDashboard />
    </React.Fragment>
  )
}

export default RolesandPermissions;
