import * as Yup from 'yup';

export const rolesPrivilegesValidation = (privilegesAssignedToRole: any) => {
    const items = privilegesAssignedToRole.privilegeGroups.filter((ele: any) => ele.privilegeGroup.groupLevelStatus === true);

    const errors: any = false;
    if (!privilegesAssignedToRole.role.name) {
        return  { 
            role : "Please enter the role name",
            privilege: ''
        }
    }

    if(items.length === 0){
        return { 
            role: '',
            privilege: "Please select at least one privilege"
        }
    }
  
    return errors;
}

export const privilegesSchema = Yup.object().shape({
    privilegeGroup: Yup.object().shape({
      name: Yup.string()
        .required('Please Enter Group Name')
        .matches(/^[^\s]/, "Group name should not start with space"),
    }),
    privilegeNames: Yup.array().of(
      Yup.string()
        .required('Please Enter Privilege Name')
        .matches(/^[^\s]/, "Privilege name should not start with space")
    )
  });