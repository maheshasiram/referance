import _ from "lodash";
import React from "react";
import { useDispatch, useSelector } from "react-redux";
import CustomDialog from "../../../../../common/modals/CustomeDialog";
import { fetchRolePrivilegeForms } from "../actions/actions";
import { RadioButton } from 'primereact/radiobutton';
import { Types } from "../reducer/Types";


function PrivilegeForms(props: any) {
    const dispatch = useDispatch();
    const [open, setOpen] = React.useState(false);
    const { currentStudy } = useSelector((state: any) => state.application);
    const { privilegeForms , updatePrivilegeForms} = useSelector((state: any) => state.rolesandPermissions); 
    const loaded = React.useRef(false);
    const { setBtnDisable } = props;
    React.useEffect(() => {
        if(!loaded.current){
        const payload = {
            studyId:currentStudy.id,
            roleId:props.roleId
        }
        dispatch(fetchRolePrivilegeForms(payload));
        loaded.current = true;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const onOpenAllForms = () => {
        setOpen(true);
    }
    
    const onCloseHandler = () => {
        dispatch({ type: Types.UPDATE_PRIVILEGE_FORMS, payload: privilegeForms });
        setOpen(false);
    }

    const onRadioChange = (e: any, index: any) => {
        setBtnDisable(false);
        const _payload = _.cloneDeep(updatePrivilegeForms);
        _payload[index].hideForm = 0;
        _payload[index].readWrite = 0;
        _payload[index].readOnly = 0;
        console.log('e.target.id',typeof(e.target.id))
        if (e.target.id === "readWrite") {
            _payload[index].readWrite = 1;
        }
        else if (e.target.id === "readOnly") {
            _payload[index].readOnly = 2;
        }
        else {
            _payload[index].hideForm = 3;
        }
        dispatch({ type: Types.UPDATE_PRIVILEGE_FORMS, payload: _payload });
    }

    const onSubmit = () => {
        setOpen(false);
    }

    return (
        <React.Fragment>
            <span className="ms-2" onClick={onOpenAllForms}><a href="#/">All Forms</a></span>
            <CustomDialog
                title={'All Forms'}
                onSubmitHandler={onSubmit}
                open={open}
                onClose={onCloseHandler}
                maxWidth='sm'
                actionType={'Ok'}
                fullWidth={true}
                cssName="privileges-forms"
            >
                <div className="forms-data">
                    <div className="d-flex mt-2 mb-2">
                        <div className="col-sm-6"> Form</div>
                        <div className="col-sm-6 d-flex justify-content-between" >
                            <p>Read & Write</p>
                            <p>Read Only</p>
                            <p>Hide Forms</p>
                        </div>
                    </div>
                    {
                        updatePrivilegeForms && updatePrivilegeForms.map((item: any, index: number) => {
                            console.log('84itm',item)
                            return <div className="d-flex justify-content-between" key={index}>
                                <p>{item.formName}</p>
                                <div className="col-sm-6 d-flex justify-content-between">
                                    
                                    <RadioButton inputId="1" id="readWrite" name="rd" value={item.readWrite} onChange={(e: any) => onRadioChange(e, index)} checked={item.readWrite === 1} />
                                    <RadioButton inputId="2" id="readOnly" name="rd" value={item.readOnly} onChange={(e: any) => onRadioChange(e, index)} checked={item.readOnly === 2} />
                                    <RadioButton inputId="3" id="hideForm" name="rd" value={item.hideForm} onChange={(e: any) => onRadioChange(e, index)} checked={item.hideForm === 3} />
                                </div>
                            </div>
                        })
                    }
                </div>

            </CustomDialog>
        </React.Fragment >
    )
}
export default PrivilegeForms;