import React, { useEffect } from 'react'
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import DeleteIcon from '@mui/icons-material/Delete';
import { Confirm, toastAlert } from '../../../../../actions/actions';
import { messages } from '../../../constants/messages';
import { useDispatch, useSelector } from "react-redux";
import CreateRolesandPermissions from './CreateRolesandPermissions';
import CustomToolTip from '../../../../../components/CustomToolTip';
import { fetchRoles, restoreRole,deleteRoleByRoleId } from '../actions/actions';
import SearchField from '../../../../../common/searchField/SearchField';
import { Types } from '../reducer/Types';
import ReplayIcon from '@mui/icons-material/Replay';
import PageCount from '../../../../../common/pagecount/PageCount';

function RolesDashboard() {
    const dispatch = useDispatch();
    const [searchVal, setSearchVal] = React.useState('');
    const { roleParams, roles } = useSelector((state: any) => state.rolesandPermissions);
    const { currentStudy } = useSelector((state: any) => state.application);
    const loaded = React.useRef(false);
    const [pageClick, setpageChange] = React.useState(false);

    useEffect(() => {
        if (!loaded.current) {
            onClearSearch();
            loaded.current = true
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);


    const deleteRestoreRole = (rowData: any, type:string) => {
        console.log('rowData35..',rowData)
        dispatch(Confirm({
            status: 0,
            message: type === 'delete' ? messages.rolesandpermissions.deleteRole : messages.rolesandpermissions.restoreRole,
            onOk: () => {
                dispatch((type=== 'delete' ? deleteRoleByRoleId : restoreRole) (rowData.id, (response: any) => {
                    if(response.status !== "error")
                    {dispatch(fetchRoles(roleParams))
                    dispatch(toastAlert({
                        status: 1,
                        message: `${rowData.name} ${response}`,
                        open: true
                    }));}
                    else{
                        dispatch(toastAlert({
                            status: 2,
                            message: `${response.errorMessage}`,
                            open: true
                        })); 
                    }
                }));
            }
        }));
    }

    const onFilterRole = (e: any) => {
        setSearchVal(e.target.value);
        const _payload = { ...roleParams, roleName: e.target.value }
        dispatch({ type: Types.ROLE_PARAMS, payload: _payload });
        dispatch(fetchRoles(_payload));
    };

    const onClearSearch = () => {
        setSearchVal('');
        const payload = { ...roleParams, studyId: currentStudy.id, roleName: '', offset: 0, limit: 10 }
        dispatch({ type: Types.ROLE_PARAMS, payload: payload });
        dispatch(fetchRoles(payload));
    };

    const onPageChange = (event: any) => {
        if (((event.page > 0)||(pageClick && event.page === 0)) && (roleParams.offset !== event.first)) {
            const _payload = { ...roleParams, offset: event.first, studyId: currentStudy.id }
            dispatch({ type: Types.ROLE_PARAMS, payload: _payload });
            dispatch(fetchRoles(_payload));
            setpageChange(true);
        }
    } 
    

    const actionTemplate = (rowData: any) => {
        return (
            rowData.status ? <React.Fragment>
                <div className="d-flex align-items-center">
                    <CreateRolesandPermissions rowData={rowData} />
                    <span className="px-1" > |</span>
                    <CustomToolTip title='Delete Role'><DeleteIcon sx={{ fontSize: 14, opacity: .8 }} className='text-danger' onClick={() => deleteRestoreRole(rowData, 'delete')} /></CustomToolTip>
                </div>
            </React.Fragment> : <div className="d-flex align-items-center">
                <CustomToolTip title='Restore Role'><ReplayIcon sx={{ fontSize: 20, opacity: .8 }} onClick={() => deleteRestoreRole(rowData, 'restore')} /></CustomToolTip>
            </div>
        )
    }
    const  onChangePageCount = (e: any) => {
        const payload = { ...roleParams,  limit: parseInt(e.target.value)  }
        dispatch({ type: Types.ROLE_PARAMS, payload: payload });
        dispatch(fetchRoles(payload));
      }

    return (
        <React.Fragment>
            <div className='row'>
                <div className='col-4 d-inline-flex'><PageCount onChange={(e: any) =>  onChangePageCount(e)} /></div>
                <div className='col-8'> 
            <div className='d-flex justify-content-end roles-dashboard'>
                <div className='button_search_alignment'> <CreateRolesandPermissions id={0} /> </div>
                <div className='search-field'>
                    <SearchField
                        value={searchVal}
                        placeholder="Search by role name"
                        onChange={onFilterRole}
                        onClearSearch={onClearSearch}
                    />
                </div>
            </div>
            </div>
            </div>
            <div>
                {roles && <DataTable
                    value={roles.roles}
                    selectionMode="single"
                    emptyMessage="No Data To Display."
                    lazy
                    scrollable
                    rows={roleParams.limit}
                    paginator={roles.totalRecords > roleParams.limit? true : false}
                    totalRecords={roles && roles.totalRecords}
                    responsiveLayout="scroll"
                    stripedRows={true}
                    first={roleParams.offset}
                    onPage={onPageChange}>
                    <Column field='name' header="Role Name"></Column>
                    <Column body={actionTemplate} header="Actions"></Column>
                </DataTable>}
            </div>
        </React.Fragment>
    )
}

export default RolesDashboard;
