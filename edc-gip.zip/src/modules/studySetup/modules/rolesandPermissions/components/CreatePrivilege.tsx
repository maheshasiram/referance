import React, { useState } from "react";
import _ from "lodash";
import { Types } from '../reducer/Types';
import { Formik, Form, Field, FieldArray, ErrorMessage } from 'formik';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import RemoveCircleOutlineIcon from '@mui/icons-material/RemoveCircleOutline';
import CustomDialog from '../../../../../common/modals/CustomeDialog'
import { useSelector, useDispatch } from "react-redux";
import { privilegesSchema } from "../helpers/Validate";
import { createPrivileges } from "../actions/actions";
import EditIcon from '@mui/icons-material/Edit';
import CustomToolTip from '../../../../../components/CustomToolTip';
import { addPrivilegesToGroupModel } from "../constants/model";
import WorkspacesSharpIcon from '@mui/icons-material/WorkspacesSharp';

function CreatePrivilege(props: any) {
    const { id, rowData } = props;
    const [open, setOpen] = React.useState(false);
    const [btnDisable, setBtnDisable] = useState(false);
    const [errorMsg, setErrorMsg] = React.useState('');
    const { addPrivilegesToGroup } = useSelector((state: any) => state.rolesandPermissions);
    const [addRemoveMsg, setaddRemoveMsg] = useState("");
    const dispatch = useDispatch();

    const onOpenDialog = (type: any) => {
        if (type === 'add') {
            dispatch({ type: Types.UPDATE_PRIVILEGES_ROLE, payload: addPrivilegesToGroupModel });
        } else {
            const payload = _.cloneDeep(rowData);
            rowData.privileges.map((item: any) => {
                payload.privilegeNames.push(item.name);
                return null
            });
            dispatch({ type: Types.UPDATE_PRIVILEGES_ROLE, payload: payload });
        }
        setOpen(true)
        setaddRemoveMsg('')
        setBtnDisable(true);

    }

    const onCloseprivilege = () => {
        setOpen(false)
        setErrorMsg('')
    }

    const validatePrivilegeNames = (values: any) => {
        let isDuplicate;
        let isEmpty = [];
        if (values.privilegeNames) {
            const valueArr = values.privilegeNames.map((item: any) => item);
            isEmpty = values.privilegeNames.filter((item: any) => item === "");
            isDuplicate = valueArr.some(function (item: any, idx: number) {
                return valueArr.indexOf(item) !== idx
            });
        }
        if (isDuplicate) {
            setaddRemoveMsg("Privilege name can't be same");
            return false;
        } else if (isEmpty.length > 0) {
            setaddRemoveMsg("Privilege can't be empty");
            return false;
        } else {
            return true;
        }
    }

    const onSubmithandler = (values: any) => {
        const validate = validatePrivilegeNames(values);
        if (validate) {
            dispatch(createPrivileges(values, (response: any) => {
                if (response.status === "error") {
                    setErrorMsg(response.errorMessage);
                } else {
                    setErrorMsg('');
                    onCloseprivilege();
                }
            }));
        }
    }

    return (
        <React.Fragment>
            {id === 0 ?
                <a href="#/" onClick={() => onOpenDialog('add')} className='e-btn-outline'>
                    <WorkspacesSharpIcon onClick={() => onOpenDialog('add')} /> <span>create Privilege</span></a>     :
                <CustomToolTip title='Edit Privilege'>
                    <EditIcon sx={{ fontSize: 14, opacity: .8 }} onClick={() => onOpenDialog('edit')} />
                </CustomToolTip>
            }
            <CustomDialog
                title={id === 0 ? 'Create privilege' : 'Edit privilege'}
                open={open}
                // className="create-privilege"
                onClose={onCloseprivilege}
                maxWidth={'500'}
                fullWidth={false}
                padding={true}
                actionType={id === 0 ? 'Submit' : 'update'}
                form={'privilege'}
                disabled={btnDisable}
            >
                <Formik
                    enableReinitialize={true}
                    initialValues={addPrivilegesToGroup}
                    validationSchema={privilegesSchema}
                    onSubmit={(values: any) => { onSubmithandler(values) }}
                >
                    {({ errors, touched, values, setFieldValue }) => (
                        <Form id='privilege' className="create-privilege">
                            {errorMsg ? <div className="text-danger mx-4 mt-1">{errorMsg}</div> : <span>&nbsp;</span>}
                            <div className="group-name col-sm-9">
                                <label htmlFor="text-formName">Group Name :</label>
                                <Field
                                    className="form-control mt-2"
                                    id="text-formName"
                                    name="privilegeGroup.name"
                                    placeholder='Group name'
                                    onChange={(e: any) => {
                                        setFieldValue('privilegeGroup.name', e.target.value);
                                        setBtnDisable(false);
                                    }}
                                />
                                {/* <div className='text-danger'> <ErrorMessage name={`privilegeGroup.name`} /> </div> */}
                                {errors.privilegeGroup && touched.privilegeGroup ? <div className='text-danger'> <ErrorMessage name={`privilegeGroup.name`} /></div> : <span>&nbsp;</span>}
                            </div>
                            <div className="row privileges">
                                <FieldArray
                                    name="privilegeNames"
                                    render={(arrayHelpers) => {
                                        const privilegeNames = values.privilegeNames
                                        return (
                                            <div>
                                                <div className="d-flex my-2">
                                                    <label id='label' className="d-flex align-items-center">Privileges
                                                        <span className="text-danger">* :</span>
                                                        <AddCircleIcon color="primary"
                                                            onClick={() => {
                                                                const _validate: any = validatePrivilegeNames(values);
                                                                if (_validate) {
                                                                    setaddRemoveMsg("");
                                                                    arrayHelpers.push('');
                                                                }
                                                            }}
                                                        />
                                                        {addRemoveMsg ? <span className="text-danger ms-1 d-flex">{addRemoveMsg}</span> : <span>&nbsp;</span>}
                                                    </label>
                                                </div>
                                                <div className="privilege-names">
                                                    {privilegeNames && privilegeNames.map((data: any, index: any) => (
                                                        <div className="d-flex privilege-inputs py-1" key={index}>
                                                            <div className="d-block col-sm-8" >
                                                                <Field
                                                                    name={`privilegeNames.${index}`}
                                                                    aria-label="privileges"
                                                                    className='form-control'
                                                                    value={values.privilegeNames[index]}
                                                                    placeholder="Privilege"
                                                                    onChange={(e: any) => {
                                                                        setFieldValue(`privilegeNames.${index}`, e.target.value.replace(/\s\s+/g, ' '))
                                                                        setBtnDisable(false);
                                                                    }}
                                                                >
                                                                </Field>
                                                                <span className='text-danger'> <ErrorMessage name={`privilegeNames.${index}`} /> </span>
                                                            </div>
                                                            <div className="">
                                                                {index > 0 && <RemoveCircleOutlineIcon
                                                                    color="error"
                                                                    className="mx-2 mt-2"
                                                                    onClick={() => {
                                                                        arrayHelpers.remove(index)
                                                                    }} />}
                                                            </div>
                                                        </div>
                                                    ))
                                                    }
                                                </div>
                                            </div>
                                        )
                                    }}
                                ></FieldArray>
                            </div>
                        </Form>
                    )}
                </Formik>
            </CustomDialog >
        </React.Fragment >
    )
}
export default CreatePrivilege;