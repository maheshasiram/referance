import React from "react";
import { useDispatch, useSelector } from 'react-redux';
import Accordion from '@mui/material/Accordion';
import AccordionDetails from '@mui/material/AccordionDetails';
import AccordionSummary from '@mui/material/AccordionSummary';
import Typography from '@mui/material/Typography';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import _ from 'lodash';
import { Types } from '../reducer/Types';
import PrivilegeForms from "./PrivilegeForms";

function Privileges(props: any) {
    const [expanded, setExpanded] = React.useState<string | false>(false);
    const dispatch = useDispatch();
    const { privilegesAssignedToRole, privileges } = useSelector((state: any) => state.rolesandPermissions);
    const { configCodes } = useSelector((state: any) => state.application);
    const { setBtnDisable, setValidations } = props;

    console.log("privilegesAssignedToRole...",privilegesAssignedToRole)

    const handleChange = (panel: string) => (event: React.SyntheticEvent, isExpanded: boolean) => {
        setExpanded(isExpanded ? panel : false);
    };

    const onSelectPrivilege = (e: any, item: any, index: any, subItem: any, subIndex: any, itemtype: any) => {
        const _priviliges: any = _.cloneDeep(privileges);
        const privilegesData = _priviliges[index]
        privilegesData.privileges[subIndex] = { ...subItem, status: e.target.checked }
        privilegesData.privilegeGroup.selectAllStatus = true;
        privilegesData.privilegeGroup.groupLevelStatus = false
        privilegesData.privileges.map((itm: any) => {
            if (itm.status === true) {
                privilegesData.privilegeGroup.groupLevelStatus = true
            } else {
                privilegesData.privilegeGroup.selectAllStatus = false;
            }
            return null;
        });
        setBtnDisable(false);
        renderPayload(e, index, itemtype, item, subItem);
        dispatch({ type: Types.GET_ALL_PRIVILEGES, payload: _priviliges });

    }

    const renderPayload = (e: any, index: any, itemtype: any, item: any, subItem: any) => {
        const payload: any = _.cloneDeep(privilegesAssignedToRole);
        console.log(".....47",payload)
        const pgindex = payload.privilegeGroups.findIndex((ele: any) => ele.privilegeGroup.id === item.privilegeGroup.id);
        if (pgindex === -1) {
            payload.privilegeGroups.push({ privilegeGroup: item.privilegeGroup, privileges: [] });
        }

        payload.privilegeGroups.map((gitem: any, gindx: number) => {
            payload.privilegeGroups[gindx].privilegeGroup.groupLevelStatus = true
            const pindex = gitem.privileges.findIndex((ele: any) => ele.id === subItem.id);
            if (pindex > -1 && !e.target.checked) {
                if (payload.role.id === 0) {
                    payload.privilegeGroups[gindx].privileges.splice(pindex, 1);
                } else {
                    payload.privilegeGroups[gindx].privileges[pindex].status = false;
                }
                if (payload.privilegeGroups[gindx].privileges.length === 0 && payload.role.id === 0) {
                    payload.privilegeGroups[gindx].privilegeGroup.groupLevelStatus = false
                    payload.privilegeGroups.splice(gindx, 1);
                } else {
                    const _pitem = payload.privilegeGroups[gindx].privileges.filter((item: any) => item.status === true)
                    if (_pitem.length > 0) {
                        payload.privilegeGroups[gindx].privilegeGroup.groupLevelStatus = true;
                    } else {
                        payload.privilegeGroups[gindx].privilegeGroup.groupLevelStatus = false;
                    }
                }
            } else if (e.target.checked && gitem.privilegeGroup.id === item.privilegeGroup.id) {
                const _subItem = _.cloneDeep(subItem);
                _subItem.status = true;
                if (pindex === -1) {
                    payload.privilegeGroups[gindx].privileges.push(_subItem);
                }
            }
            return null
        });

        dispatch({ type: Types.UPDATE_PRIVILEGES_ASSIGNED_TO_ROLE, payload: payload });
        setValidations({ role: '', privilege: '' });
    }

    const selectAllHandler = (index: any, item: any) => {
        const _priviliges: any = _.cloneDeep(privileges);
        const privilegesData = _priviliges[index];
        const payload: any = _.cloneDeep(privilegesAssignedToRole);
        const pgindex = payload.privilegeGroups.findIndex((ele: any) => ele.privilegeGroup.id === item.privilegeGroup.id);

        if ((item.privileges.filter((i: any) => i.status === true)).length === item.privileges.length) {
            privilegesData.privilegeGroup.selectAllStatus = false;
            privilegesData.privilegeGroup.groupLevelStatus = false;
            if (payload.role.id === 0) {
                payload.privilegeGroups.splice(pgindex, 1);
            } else {
                payload.privilegeGroups[pgindex].privilegeGroup.groupLevelStatus = false;
            }
        } else {
            privilegesData.privilegeGroup.selectAllStatus = true;
            privilegesData.privilegeGroup.groupLevelStatus = true;
            const _item = _.cloneDeep(item);
            _item.privilegeGroup.groupLevelStatus = true;
            if (pgindex === -1) {
                payload.privilegeGroups.push(_item);
            } else {
                payload.privilegeGroups[pgindex].privilegeGroup.groupLevelStatus = true;
                payload.privilegeGroups[pgindex].privileges = _item.privileges
            }
        }

        privilegesData && privilegesData.privileges.map((item: any, index: any) => privilegesData.privileges[index].status = privilegesData.privilegeGroup.selectAllStatus);

        payload.privilegeGroups.map((gitem: any, gindex: number) =>
            gitem.privileges.map((pitem: any, pindex: any) =>
                payload.privilegeGroups[gindex].privileges[pindex].status = payload.privilegeGroups[gindex].privilegeGroup.groupLevelStatus
            ));

        dispatch({ type: Types.GET_ALL_PRIVILEGES, payload: _priviliges });
        setBtnDisable(false);
        dispatch({ type: Types.UPDATE_PRIVILEGES_ASSIGNED_TO_ROLE, payload: payload });
        setValidations({ role: '', privilege: '' });
    }

    return (
        <React.Fragment>
            <div className='privilegeAccGrp'>
                {privileges && privileges.map((item: any, index: number) => {
                    if (item.privileges.length > 0) {
                        return (
                            <div key={index}>
                                <Accordion expanded={expanded === 'panel' + index} onChange={handleChange('panel' + index)} >
                                    <AccordionSummary className={item.privilegeGroup.groupLevelStatus ? "accordianHeader" : ""}
                                        expandIcon={<ExpandMoreIcon />}
                                        aria-controls="panel1bh-content"
                                        id="panel1bh-header" >
                                        {/* {item.privilegeGroup.groupLevelStatus && <input className="select-all-role" type={'checkbox'} disabled={true} checked={item.privilegeGroup.groupLevelStatus ? item.privilegeGroup.groupLevelStatus : false} onChange={(e: any) => onSelectPrivilege(e, item, index, '', '', 'parent')} /> } */}
                                        <Typography component={'div'} sx={{ width: '33%', flexShrink: 0, fontSize: '13px' }}>
                                            {item.privilegeGroup.name}
                                        </Typography>
                                    </AccordionSummary>
                                    <AccordionDetails>
                                        <Typography component={'div'} className="privilege-container" >
                                            {privileges.length > 0 &&
                                                // <div className="select-all mb-1" onClick={() => selectAllHandler(index,item)}>{!item.privilegeGroup.selectAllStatus ? "Select All" : "Deselect All"}
                                                <div className="select-all mb-1" onClick={() => selectAllHandler(index, item)}>{(item.privileges.filter((i: any) => i.status === true)).length === item.privileges.length ? "Deselect All" : "Select All"}
                                                </div>}
                                            <div className="d-flex flex-wrap">
                                                {item.privileges.map((subItem: any, subIndex: any) => {
                                                    return (
                                                        <div key={subIndex} className={"mx-1 mb-1 check-container"}>
                                                            <input type='checkbox' id={`chk_${index}_${subIndex}`} checked={subItem.status ? subItem.status : false} className="btn-check ms-2" onChange={(e: any) => onSelectPrivilege(e, item, index, subItem, subIndex, 'child')} />
                                                            <label htmlFor={`chk_${index}_${subIndex}`} className="btn btn-outline-primary">
                                                                <span>{subItem.name}</span> </label>
                                                            {subItem.code === configCodes?.FormData && subItem.status && <PrivilegeForms roleId={item.roleId} setBtnDisable={setBtnDisable} />}
                                                        </div>
                                                    )
                                                })}
                                            </div>
                                        </Typography>
                                    </AccordionDetails>
                                </Accordion>
                            </div>
                        )
                    }
                    return null
                })}
            </div>
        </React.Fragment>
    )
}

export default Privileges;