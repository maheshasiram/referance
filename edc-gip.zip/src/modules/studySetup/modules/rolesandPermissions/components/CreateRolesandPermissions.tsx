import React, { useState } from 'react'
import { Types } from '../reducer/Types';
import { useSelector, useDispatch } from "react-redux";
import _ from 'lodash';
import EditIcon from '@mui/icons-material/Edit';
import CustomDialog from '../../../../../common/modals/CustomeDialog'
import Privileges from './Privileges';
import { toastAlert } from '../../../../../actions/actions';
import { rolesPrivilegesValidation } from '../helpers/Validate';
import { privilegesAssignedToRoleModel } from '../constants/model';
import CustomToolTip from '../../../../../components/CustomToolTip';
import { assignPrivilegesToRole, createRole, fetchRoles, getPrivileges, updateRole, updateRolePrivilegeForms } from '../actions/actions';

function CreateRolesandPermissions(props: any) {
    const dispatch = useDispatch();
    const { id, rowData } = props;
    const [open, setopen] = React.useState(false);
    const [error, setError] = useState('');
    const [btnDisable, setBtnDisable] = React.useState(true);
    const [validations, setValidations] = React.useState({ role: '', privilege: '' });
    const { currentStudy, configCodes } = useSelector((state: any) => state.application);
    const { privilegesAssignedToRole, roleParams, updatePrivilegeForms } = useSelector((state: any) => state.rolesandPermissions);

    console.log("privilegesAssignedToRole...24", privilegesAssignedToRole)

    const onOpenDialog = (type: any) => {
        if (type === 'add') {
            dispatch(getPrivileges(0, currentStudy.id));
            dispatch({ type: Types.GET_PRIVILEGE_FORMS, payload: [] });
            dispatch({ type: Types.UPDATE_PRIVILEGES_ASSIGNED_TO_ROLE, payload: privilegesAssignedToRoleModel });
        } else {
            dispatch({ type: Types.GET_PRIVILEGE_FORMS, payload: [] });
            dispatch(getPrivileges(rowData.id, currentStudy.id, (response: any) => {
                const _payload = _.cloneDeep(privilegesAssignedToRole);
                _payload.privilegeGroups = []
                _payload.role = rowData;
                response.map((item: any) => {
                    if (item.privilegeGroup.groupLevelStatus) {
                        _payload.privilegeGroups.push({ "privilegeGroup": item.privilegeGroup, "privileges": item.privileges.filter((item: any) => item.status === true), "roleId": item.roleId });
                        _payload.privilegeGroups.map((pgroup: any, gindex: any) => {
                            _payload.privilegeGroups[gindex].privilegeGroup.selectAllStatus = true;
                            item.privileges.map((pItem: any) => {
                                if (!pItem.status) {
                                    _payload.privilegeGroups[gindex].privilegeGroup.selectAllStatus = false;
                                }
                                return null
                            });
                            return null
                        });
                    }
                    return null
                });
                dispatch({ type: Types.UPDATE_PRIVILEGES_ASSIGNED_TO_ROLE, payload: _payload });
            }));
        }
        setError('');
        setopen(true);
        setBtnDisable(true);
        setValidations({ role: '', privilege: '' });
    }

    const onCloseRole = () => {
        setopen(false)
    }

    const onInputChangeHandler = (e: any) => {
        const payload: any = _.cloneDeep(privilegesAssignedToRole);
        setError('');
        payload.role.name = e.target.value;
        dispatch({ type: Types.UPDATE_PRIVILEGES_ASSIGNED_TO_ROLE, payload: payload });
        setValidations({ role: '', privilege: '' });
    }

    const OnSubmitRole = (param: any) => {
        const error: any = rolesPrivilegesValidation(privilegesAssignedToRole);
        setValidations({ role: '', privilege: '' });
        const _payload = { ...privilegesAssignedToRole.role, studyId: currentStudy.id }
        if (error) {
            setValidations(error)
        } else {
            dispatch((id === 0 ? createRole : updateRole)(_payload, (response: any) => {
                const payload = _.cloneDeep(privilegesAssignedToRole);
                console.log("....84", payload)
                payload.role.id = response.id;
                payload.role.studyId = currentStudy.id;
                payload.privilegeGroups.map((items: any, index: number) => {
                    items.roleId = response.id;
                    const _itemStatus = items.privileges.filter((item: any) => item.status === true)
                    if (_itemStatus.length <= 0) {
                        items.privilegeGroup.groupLevelStatus = false;
                    }
                    else {
                        items.privilegeGroup.groupLevelStatus = true;
                    }
                    if (items.privilegeGroup.code === "USER_PREV_TYPE_STANDARD_REPORTS") {
                        payload.privilegeGroups[index].reportPrivileges = items.privileges.length === 0 ? [] : items.privileges
                        payload.privilegeGroups[index].privileges = [];
                    } else if (items.privilegeGroup.code === configCodes?.DataImport) {
                        payload.privilegeGroups[index].dataImportPrivileges = items.privileges.length === 0 ? [] : items.privileges
                        payload.privilegeGroups[index].privileges = [];
                    } else {
                        // payload.privilegeGroups[index].reportPrivileges = [];
                        // payload.privilegeGroups[index].dataImportPrivileges = [];
                    }
                    return null
                })
                console.log("100....", payload)
                if (response.status === "error") {
                    setError(response.errorMessage);
                } else {
                    dispatch(assignPrivilegesToRole(payload, () => {
                        const _formData = privilegesAssignedToRole.privilegeGroups.filter((item: any) => item.privilegeGroup.code === configCodes?.FormData)

                        if (_formData.length > 0) {
                            const _privilegeForms = _.cloneDeep(updatePrivilegeForms);
                            _privilegeForms.map((forms: any, index: number) => _privilegeForms[index].roleId = response.id)
                            dispatch(updateRolePrivilegeForms(_privilegeForms, () => {
                                onCloseRole()
                                dispatch(fetchRoles(roleParams));
                                dispatch(toastAlert({
                                    status: 1,
                                    message: `${id === 0 ? 'Created' : 'Updated'} Successfully`,
                                    open: true
                                }));
                            }))
                        } else {
                            onCloseRole()
                            dispatch(fetchRoles(roleParams));
                            dispatch(toastAlert({
                                status: 1,
                                message: `${privilegesAssignedToRole.role.name} Role ${id === 0 ? 'Created' : 'Updated'} Successfully`,
                                open: true
                            }));
                        }
                    }));
                }
            }));
        }
    }
    return (
        <React.Fragment>
            {id === 0 ?
                <button className="btn-eprimary" onClick={() => onOpenDialog('add')}>Create Role</button> :
                <CustomToolTip title='Edit Role'>
                    <EditIcon sx={{ fontSize: 14, opacity: .8 }} onClick={() => onOpenDialog('edit')} />
                </CustomToolTip>
            }
            <CustomDialog
                title={id === 0 ? 'Create Role' : 'Edit Role'}
                open={open}
                onClose={onCloseRole}
                fullWidth={true}
                maxWidth='sm'
                actionType={id === 0 ? 'Submit' : 'update'}
                onSubmitHandler={OnSubmitRole}
                disabled={btnDisable}
            >
                <div className='create-role rp-container'>
                    <div className='text-center mt-1'>{error ? <span className='text-danger'>{error}</span> : <span>&nbsp;</span>}</div>
                    <div className=' col-sm-5 pt-2'>
                        <label className="form-label roleNameLabel font-weight-bold">Role Name :<span className='text-danger mx-1'>*</span></label>
                        <input className='form-control'
                            value={privilegesAssignedToRole.role.name}
                            placeholder="Role name"
                            name='RoleName'
                            onChange={(e) => {
                                if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
                                    onInputChangeHandler(e);
                                    setBtnDisable(false);
                                }
                            }} />
                        <div className='text-danger'>{validations.role}</div>
                    </div>
                    <div className="d-flex align-content-start flex-wrap previligeGrps privilegeAccGrp pt-2">
                        <h6 className='m-0 py-2'>Privileges :<span className='text-danger'>{validations.privilege}</span></h6>
                        <div className='create-privilegesGrp'>
                            <Privileges rowData={rowData} setBtnDisable={setBtnDisable} setValidations={setValidations} />
                        </div>
                    </div>
                </div>
            </CustomDialog>
        </React.Fragment>
    )
}
export default CreateRolesandPermissions;