
import { Loader } from '../../../../../actions/actions';
import { studySetup } from '../../../../../configs/enivornment/studySetup';
import { fetch } from '../../../../../constants/fetch';
import { Types } from '../reducer/Types';


export const fetchPrivileges: any = () => {
    const url = studySetup.roles.fetchAllPrivileges
    return (dispatch: any) => {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
        }).then((response: any) => {
            dispatch({ type: Types.FETCH_PRIVILEGES_ASSIGNED_TO_GROUP, payload: response.data })
            dispatch(Loader(false))
        }).catch((err) => {
            console.log("...err", err)
        })
    }
}


export const fetchRoles: any = (payload: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: studySetup.roles.fetchAllRolesByStudyId,
            data: payload
        })
            .then((response: any) => {
                dispatch({ type: Types.FETCH_ALL_ROLES, payload: response.data })
                dispatch(Loader(false))
            }).catch((err) => {
                console.log("...err", err)
            })
    }
}

export const assignPrivilegesToRole: any = (payload: any, callback: any) => {
    const url = studySetup.roles.assignPrivilegesToUserRole
    return (dispatch: any) => {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload
        }).then((response: any) => {
            dispatch(Loader(false));
            callback(response.data);
        }).catch((err) => {
            console.log("...err", err)
        })
    }
}

export const createPrivileges: any = (payload: any, callback: any) => {
    const url = studySetup.roles.insertNewPrivilegesToGroup
    return (dispatch: any) => {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload
        }).then((response: any) => {
            dispatch(Loader(false))
            callback(response.data);
        }).catch((err) => {
            console.log("...err", err)
        })
    }
}

export const deleteRoleByRoleId: any = (id: number, callback: any) => {
    const url = studySetup.roles.deleteRoleByRoleId
    return () => {
        fetch({
            method: "delete",
            url: `${url}?roleId=${id}`,
        }).then((response: any) => {
            callback(response.data);
            console.log("delete response", response)
        })
    }
}

export const createRole: any = (payload: any, callback: any) => {
    const url = studySetup.roles.createRole
    return (dispatch: any) => {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload
        }).then((response: any) => {
            dispatch({ type: Types.CREATE_ROLE, payload: response.data })
            callback(response.data);
            dispatch(Loader(false))
        }).catch((err) => {
            console.log("...err", err)
        })
    }
}

export const updateRole: any = (payload: any, callback: any) => {
    const url = studySetup.roles.updateRole
    return (dispatch: any) => {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload
        }).then((response: any) => {
            dispatch({ type: Types.CREATE_ROLE, payload: response.data })
            dispatch(Loader(false));
            callback(response.data);
        }).catch((err) => {
            console.log("...err", err)
        })
    }
}
export const restoreRole: any = (payload: any, callback: any) => {
    const url = `${studySetup.roles.restoreRole}?roleId=${payload}`
    return (dispatch: any) => {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
        }).then((response: any) => {
            console.log('resp121..', response.data)
            dispatch(Loader(false));
            callback(response.data)
        }).catch((err) => {
            console.log("...err", err)
        })
    }
}

export const getPrivileges: any = (roleId: any, studyId:any, callback: any) => {
    const url = `${studySetup.roles.fetchRolePrivilegesByRoleIdGroupWise}/${roleId}/${studyId}`
    return (dispatch: any) => {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
        }).then((response: any) => {
            dispatch({ type: Types.GET_ALL_PRIVILEGES, payload: response.data })
           if(callback){
            callback(response.data);
        }
            dispatch(Loader(false));
        }).catch((err) => {
            console.log("...err", err)
        })
    }
}

//Fetch RolePrivilege Forms
export const fetchRolePrivilegeForms: any = (payload: any) => {
    const url = `${studySetup.roles.fetchRolePrivilegeFormData}?studyId=${payload.studyId}&roleId=${payload.roleId}`
    return (dispatch: any) => {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url
        }).then((response: any) => {
            dispatch({ type: Types.GET_PRIVILEGE_FORMS, payload: response.data });
            dispatch({ type: Types.UPDATE_PRIVILEGE_FORMS, payload: response.data });
            dispatch(Loader(false))
        })
    }
}

//Save Role Privilege Forms
export const updateRolePrivilegeForms: any = (payload: any, callback:any) => {
    const url = studySetup.roles.updateRolePrivilegeFormData
    return (dispatch: any) => {
        dispatch(Loader(true))
        fetch({
            method: "POST",
            url: url,
            data: payload
        }).then((response: any) => {
            callback(response.data)
            dispatch(Loader(false))
        }).catch((err) => {
            console.log("...err", err)
        })
    }

}