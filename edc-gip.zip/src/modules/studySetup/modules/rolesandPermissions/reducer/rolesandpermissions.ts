import { Types } from "../reducer/Types"
import { privilegesAssignedToRoleModel, addPrivilegesToGroupModel } from "../constants/model";

const initialState = {
    privilegesAssignedToGroup: null,
    privilegesAssignedToRole: privilegesAssignedToRoleModel,
    addPrivilegesToGroup: addPrivilegesToGroupModel,
    roles: null,
    createrole: "",
    roleParams: { "limit": 10, "offset": 0, "studyId": 0, "roleName": "" },
    privileges: [],
    privilegeForms: [],
    updatePrivilegeForms: []
}

export const rolesandPermissions = (state = initialState, action: { type: any, payload: any }) => {

    switch (action.type) {

        case Types.UPDATE_PRIVILEGES_ASSIGNED_TO_ROLE:
            return { ...state, privilegesAssignedToRole: action.payload }

        case Types.FETCH_ALL_ROLES:
            return { ...state, roles: action.payload }

        case Types.ROLE_PARAMS:
            return { ...state, roleParams: action.payload }

        case Types.CREATE_ROLE:
            return { ...state, createrole: action.payload }

        case Types.GET_ALL_PRIVILEGES:
            return { ...state, privileges: action.payload }

        case Types.GET_PRIVILEGE_FORMS:
            return { ...state, privilegeForms: action.payload }

        case Types.UPDATE_PRIVILEGE_FORMS:
            return { ...state, updatePrivilegeForms: action.payload }

        default:
            return { ...state }
    }

} 
