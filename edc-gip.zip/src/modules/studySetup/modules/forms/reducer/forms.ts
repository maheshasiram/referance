import { Types } from "./Types"
import { AddFormPayload, formParam, Variable, Group, importForm } from "../helpers/form-modal"

const initialState = {
    activeFormsList: [],
    formList: {},
    addForm: AddFormPayload,
    formParams: formParam,
    allStudies: [],
    formDetails: {},
    formVariables: null,
    variableDetails: Variable,
    fieldResponseTypes: null,
    fieldDataTypes: null,
    layoutTypes: null,
    groupDetails: Group,
    variables: null,
    importFormParams: importForm,
    allGroups: null,
    hideGroupRowsData: [],
    defaultValues: null,
    
    allFormsList: [],
    visitAssignedToForms:[],
    allUnits:[],
    uploadFileType:[], // For file type field -Akshay
    fieldFormat:[],
}
export const forms = (state = initialState, action: { type: any, payload: any }) => {
    switch (action.type) {
        case Types.INITIALIAZE_GROUP:
            return { ...state, groupDetails: Group }
        case Types.INITIALIAZE_VARIABLED:
            return { ...state, variableDetails: Variable }
        case Types.GET_ACTIVE_FORM_LIST:
            return { ...state, activeFormsList: action.payload }
        case Types.GET_ALL_FORM_LIST:
            return { ...state, formList: action.payload }
        case Types.GET_ADD_UPDATE_FORM:
            return { ...state, addForm: action.payload }
        case Types.GET_FORM_PARAMS:
            return { ...state, formParams: action.payload }
        case Types.GET_ALL_STUDIES:
            return { ...state, allStudies: action.payload }
        case Types.FORM_DETAILS_BY_ID:
            return { ...state, formDetails: action.payload }
        case Types.GET_FIELDS_BY_FORMID:
            return { ...state, formVariables: action.payload }
        case Types.UPDATE_VARIABLE_DEATILS:
            return { ...state, variableDetails: action.payload }
        case Types.FIELD_RESPONSE_TYPES:
            return { ...state, fieldResponseTypes: action.payload }
        case Types.FIELD_DATA_TYPES:
            return { ...state, fieldDataTypes: action.payload }
        case Types.FIELD_RESPONSE_LAYOUTS:
            return { ...state, layoutTypes: action.payload }
        case Types.UPDATE_GROUP_DEATILS:
            return { ...state, groupDetails: action.payload }
        case Types.ADD_DEFAULT_VALUES_TO_GROUP:
            return { ...state, variables: action.payload }
        case Types.ALL_GROUP_DEATILS:
            return { ...state, allGroups: action.payload }
        case Types.HIDE_GROUP_ROWS:
            return { ...state, hideGroupRowsData: action.payload }
        case Types.GET_FIELD_DEFAULT_VALUES:
            return { ...state, defaultValues: action.payload }
        case Types.GET_FORMS_BY_STUDYID:
            return { ...state, allFormsList: action.payload }
        case Types.VISIT_ASSIGNED_TO_FORM:
            return { ...state, visitAssignedToForms: action.payload }
        case Types.GET_ALL_UNITS:
            return { ...state, allUnits: action.payload }
        case Types.VARIABLE_FIELD_FORMAT:
            return { ...state, fieldFormat: action.payload }
        case Types.UPLOAD_FILE_TYPE:
            return {...state, uploadFileType:action.payload}
        default:
            return { ...state }
    }
}
