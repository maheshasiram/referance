import { fetch } from '../../../../../constants/fetch';
import { studySetup } from '../../../../../configs/enivornment/studySetup';
import { Types } from '../reducer/Types';
import { Loader } from '../../../../../actions/actions';
import _ from 'lodash'

export const fetchAllActiveForm: any = () => {
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: studySetup.forms.fetchAllActive,
    })
      .then((response: any) => {
        dispatch({ type: Types.GET_ACTIVE_FORM_LIST, payload: response.data });
        dispatch(Loader(false));
      })
  }
}

export const fetchAllFormsByCriteria: any = (payload: any, callback: any) => {
  return function (dispatch: any) {
    // dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: studySetup.forms.fetchAllByCriteria,
      data: payload
    })
      .then((response: any) => {
        dispatch({ type: Types.GET_ALL_FORM_LIST, payload: response.data });
        // dispatch(Loader(false));
        if (callback) { callback(response) }
      })
      .catch(() => {
        dispatch(Loader(false));
      })
  }
}

export const activeOrDeActiveForms: any = (payload: any, callback: any) => {
  const url = `${studySetup.forms.activeOrDeActive}/${payload.id}?status=${payload.status}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: url
    })
      .then((response: any) => {
        if (callback) { callback(response) }
        dispatch(Loader(false));
      })
  }
}

export const createNewForm: any = (payload: any, callback: any) => {
  const url = `${studySetup.forms.create}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: url,
      data: payload
    })
      .then((response: any) => {
        if (callback) { callback(response) }
        dispatch(Loader(false));
      })
  }
}



export const editOrUpdateForm: any = (payload: any, callback: any) => {
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: studySetup.forms.edit,
      data: payload
    })
      .then((response: any) => {
        if (callback) { callback(response) }
        dispatch(Loader(false));
      })
  }
}

export const getFormsDetailsId: any = (payload: string, callback: any) => {
  const url = `${studySetup.forms.getFormsDetailsId}/${payload}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        dispatch(Loader(false));
        dispatch({ type: Types.FORM_DETAILS_BY_ID, payload: response.data });
        if (callback) { callback(response) }
      })
  }
}
// import Variables
export const importFieldsToForm: any = (payload: any, callback: any) => {
  const url = `${studySetup.forms.field.importFieldsToForm}/${payload.formId}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: url,
      data: payload.Fields
    })
      .then((response: any) => {
        if (callback) {
          callback(response)
        }
        dispatch(Loader(false));
      })
  }
}

export const fetchFieldsByFormId: any = (payload: string) => {
  const url = `${studySetup.forms.field.fetchFieldsByFormId}/${payload}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        const _data = { ...{}, ...response }
        const _fields: any = []
        response && response.data && response.data.length > 0 && response.data.map((item: any, index: number) => {
          // _data.data[index] = { ...item, status: false }
          if (item.status) {
            _fields.push({ ...item, checked: false })
          }
          _data.data[index] = { ...item, checked: false }
          return null;
        })
        dispatch({ type: Types.GET_FIELDS_BY_FORMID, payload: _fields });
        dispatch(Loader(false));
      })
  }
}

export const deleteFields: any = (payload: number, callback: any) => {
  const url = `${studySetup.forms.field.deleteFields}/${payload}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        if (callback) { callback(response) }
        dispatch(Loader(false));
      })
  }
}
export const restoreFields: any = (payload: number, callback: any) => {
  const url = `${studySetup.forms.field.restoreFields}/${payload}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        if (callback) { callback(response) }
        dispatch(Loader(false));
      })
  }
}

export const createUnits: any = (payload: any, callback: any) => {
  const url = `${studySetup.forms.field.createUnits}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: url,
      data: payload
    })
      .then((response: any) => {
        if (callback) {
          callback(response)
        }
        dispatch(Loader(false));
      })
  }
}
export const fetchAllUnits: any = (payload: any, callback: any) => {
  const url = `${studySetup.forms.field.fetchAllUnits}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: url,
    })
      .then((response: any) => {
        if (callback) {
          callback(response)
        }
        dispatch({ type: Types.GET_ALL_UNITS, payload: response.data.data });
        dispatch(Loader(false));
      })
  }
}

export const importUngroupedToGroup: any = (payload: number, params: any, callback: any) => {
  const url = `${studySetup.forms.group.importUngroupedFields}/${payload}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: url,
      data: params
    })
      .then((response: any) => {
        if (callback) { callback(response) }
      })
  }
}

//Add Variable
export const addUpdateVariable: any = (payload: any, callback: any) => {
  const url = payload.id === 0 ? studySetup.forms.field.addVariable : studySetup.forms.field.updateVariable
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: url,
      data: payload
    })
      .then((response: any) => {
        if (callback) { callback(response.data) }
        dispatch(Loader(false));
      })
  }
}

// getVariable by id
export const getFieldDetailsById: any = (id: number, callback: any) => {
  const url = `${studySetup.forms.field.getVariableById}/${id}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        // response.data.isValueUpperCase = response.data?.isValueUpperCase?.toString();
        if (response.data.responseOptions == null) {
          response.data.responseOptions = []
          dispatch({ type: Types.UPDATE_VARIABLE_DEATILS, payload: response.data });
        } else {
          dispatch({ type: Types.UPDATE_VARIABLE_DEATILS, payload: response.data });
        }
        if (callback) { callback(response.data) }
        dispatch(Loader(false));
      })
  }
}

//Fetchfieldformat
export const fetchFieldsFormat: any = (id: number, callback: any) => {
  const url = `${studySetup.forms.field.fetchVariableFieldsFormat}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        dispatch({ type: Types.VARIABLE_FIELD_FORMAT, payload: response.data });
        if (callback) { callback(response.data) }
        dispatch(Loader(false));
      })
  }
}


//Add Variable
export const addUpdateGroup: any = (payload: any, callback: any) => {
  const url = (payload.id && payload.id > 0) ? studySetup.forms.group.updateGrpoup : studySetup.forms.group.addGrpoup

  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: url,
      data: payload
    })
      .then((response: any) => {
        if (callback) { callback(response.data) }
        dispatch(Loader(false));
      })
  }
}

// getVariable by id
export const getGroupDeatilsById: any = (id: number, callback: any) => {
  const url = `${studySetup.forms.group.getGroupbyId}/${id}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        dispatch({ type: Types.UPDATE_GROUP_DEATILS, payload: response.data });
        if (callback) { callback(response.data) }
        dispatch(Loader(false));
      })
  }
}

export const getFormsByStudyId: any = (payload: any, callback: any) => {
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: `${studySetup.forms.getFormsByStudyId}?studyId=${payload}`,
      data: ''
    })
      .then((response: any) => {
        if (callback) { callback(response) }
        dispatch({ type: Types.GET_FORMS_BY_STUDYID, payload: response.data });
        dispatch(Loader(false));
      })
  }
}
export const deleteGroup: any = (payload: number, callback: any) => {
  const url = `${studySetup.forms.group.deleteGroup}/${payload}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        dispatch({ type: Types.UPDATE_GROUP_DEATILS, payload: response.data });
        if (callback) { callback(response.data) }
        if (callback) { callback(response) }
        dispatch(Loader(false));
      })
  }
}

export const restoreGroup: any = (payload: number, callback: any) => {
  const url = `${studySetup.forms.group.restoreGroup}/${payload}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        if (callback) { callback(response) }
        dispatch(Loader(false));
      })
  }
}

//get all default values
export const getAllDefaultValues: any = (payload: any, callback: any) => {
  const url = `${studySetup.forms.group.getAllDefaultValues}/${payload.id ? payload.id : payload}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
    })
      .then((response: any) => {
        const _response = _.cloneDeep(response)
        const grpRepeatNum = payload.repeatNumber
        response.data.map((item: any, index: number) => {
          if (grpRepeatNum > response.data[index].groupDefaultValues.length) {
            const _array: any = []
            for (let i = 0; i < (payload.repeatNumber - response.data[index].groupDefaultValues.length); i++) {
              _array.push({
                "id": 0,
                "rowId": 0,
                "defaultValue": '',
                "readOnly": false,
                "hide": false,
                "status": true,
              })
            }
            _response.data[index].groupDefaultValues = [...response.data[index].groupDefaultValues, ..._array]
          }
          // values split for partial Date
          if (item.fieldDataTypeCode === "DATA_TYP_PARTIAL_DATE") {
            console.log('partial........', item)
            item.groupDefaultValues.map((subItem: any, subIndex: number) => {
              if (subItem.defaultValue && subItem.defaultValue !== '') {
                const _values = subItem.defaultValue.split("@")
                console.warn('_values......', _values)
                _response.data[index].groupDefaultValues[subIndex] = { ...subItem, defaultValue: _values[0], dateValue: _values[1] }
              }
              return null
            })
          }
          return null
        })

        // console.warn('group.........', _response)
        dispatch({ type: Types.ADD_DEFAULT_VALUES_TO_GROUP, payload: _response.data });
        if (callback) { callback(_response.data) }
        dispatch(Loader(false));
      })
  }
}

export const exportGroupedToUngrouped: any = (payload: number, params: any, callback: any) => {
  const url = `${studySetup.forms.group.exportGroupedToUngrouped}/${payload}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: url,
      data: params
    })
      .then((response: any) => {
        if (callback) { callback(response) }
        // dispatch(Loader(false));
      })
  }
}

export const updateFieldsOrder: any = (payload: any, callback: any) => {
  const url = `${studySetup.forms.field.updateFieldsOrder}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: url,
      data: payload
    })
      .then((response: any) => {
        if (callback) { callback(response) }
        dispatch(Loader(false));
      })
  }
}

export const getImportForm: any = (payload: any, callback: any) => {
  const url = studySetup.forms.importForm
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: url,
      data: payload
    })
      .then((response: any) => {
        if (callback) { callback(response.data) }
        dispatch(Loader(false));
      })
  }
}


// get all groups by formId
export const fetchAllGroupsByFormId: any = (id: number) => {
  const url = `${studySetup.forms.group.getAllGroups}/${id}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        dispatch({ type: Types.ALL_GROUP_DEATILS, payload: response.data });
        dispatch(Loader(false));
      })
  }
}

// Delete Default Values
export const deleteDefaultValues: any = (payload: any, callback: any) => {
  const url = `${studySetup.forms.group.deleteDefaultValues}/${payload.groupId}/${payload.fieldId}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        if (callback) { callback(response) }
        dispatch(Loader(false));
      })
      .catch(() => {
        dispatch(Loader(false));

      })
  }
}
export const getGroupRows: any = (groupId: any, callback: any) => {
  const url = `${studySetup.forms.group.getGroupRows}/${groupId}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        if (response.data.status === "error") {
          dispatch({ type: Types.HIDE_GROUP_ROWS, payload: null });
        } else {
          dispatch({ type: Types.HIDE_GROUP_ROWS, payload: response.data });
        }
        dispatch(Loader(false));
        if (callback) { callback(response) }
      })
      .catch(() => {
        dispatch(Loader(false));

      })
  }
}

export const updateGroupRows: any = (payload: any, callback: any) => {
  const url = `${studySetup.forms.group.updateGroupRows}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: url,
      data: payload
    })
      .then((response: any) => {
        if (callback) { callback(response) }
        dispatch(Loader(false));
      })
      .catch(() => {
        dispatch(Loader(false));
      })
  }
}



export const getFieldsForDefaultValues: any = (group: any, callback: any) => {
  const url = `${studySetup.forms.group.getFieldsForDefaultValues}/${group.id}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        // console.log('group.........', group)
        if (callback) { callback(response) }
        dispatch(Loader(false));
      })
  }
}

export const addDefaultValue: any = (payload: any, callback: any) => {
  const url = `${studySetup.forms.group.addDefaultValue}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: url,
      data: payload
    })
      .then((response: any) => {
        if (callback) { callback(response) }
        dispatch(Loader(false));
      })
  }
}

export const updateDefaultValues: any = (payload: any, callback: any) => {
  const url = `${studySetup.forms.group.updateDefaultValues}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: url,
      data: payload
    })
      .then((response: any) => {
        if (callback) { callback(response) }
        dispatch(Loader(false));
      })
  }
}

export const fetchVisitsAssignedToFormId: any = (payload: any, callback: any) => {
  console.log("542....", payload)
  const url = `${studySetup.visits.fetchVisitsAssignedToFormId}?formId=${payload}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
    })
      .then((response: any) => {
        dispatch({ type: Types.VISIT_ASSIGNED_TO_FORM, payload: response.data });
        if (callback) { callback(response.data) }
        dispatch(Loader(false));
      })
  }
}

