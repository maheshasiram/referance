export const MenuItems = [
{
    icon: "BackupOutlinedIcon",
    label: 'Export',
    page: 1.
},
{
    icon: "CloudDownloadOutlinedIcon",
    label: 'Import',
    page: 2
},
{
    icon: "ViewColumnOutlinedIcon",
    label: 'Column Indexing',
    page: 3,
},
{
    icon: "CodeOffIcon",
    label: 'Add Default Values',
    page: 4
},
{
    icon: "VisibilityOffIcon",
    label: 'Hide Group Rows',
    page: 5
}
]