import * as Yup from "yup";
import store from "../../../../../store/store";

const _configCodes: any = store.getState().application.configCodes;

export const AddorEditFormValidation = Yup.object().shape({
    formName: Yup.string().max(20, 'Too Long!')
    .required("Please enter form name")
    .matches(/^[a-zA-Z0-9]/, 'Form name should not start with special characters'),
    // .matches(/^[ A-Za-z0-9]$/, 'form name should start with text only'),
    exportName: Yup.string()
    .required("Please enter export name")
    .matches(/^[a-zA-Z]/, 'Export name should start with only text'),
    category: Yup.string().when('labForm', (labForm, schema) => {
        if (labForm) {
            return schema.test({
                test: (labForm: any) => labForm,
                message: "Please select category"
            })
        }
    })
    
})

export const variableSchema = (responseTypeVal: any, variableData: any, dataTypeValue: any) => {
    return Yup.object().shape({
        variableId: Yup.string()
        .required('Please enter variable id')
        .matches(/^[a-zA-Z][a-zA-Z0-9]*$/, 'Variable id should start with characters and will not allow any special characters')
        // .matches(/^[a-zA-Z0-9]+$/, 'Variable id should start with characters and will not allow any special characters')
        // .matches(/[^0-9]/, "Variable ID should start with characters and will not allow any special characters")
        .max(8, 'Please enter maximum 8 characters only'),
        variableText: Yup.string()
        .required('Please enter Variable Text')
        .matches(/[^\s*]/g, '* This variable cannot contain only blankspaces'),
        responseType: Yup.object().shape({
            name: Yup.string()
            .required('Please select response type')
        }),
        // maxValueLength: Yup.number().when('minValueLength', (minValueLength, schema) => {
            //     if (minValueLength) return schema.test({
                //         test: (maxValueLength: any) => maxValueLength > minValueLength,
                //         // message: "Max value must be greater than min value"
                //     })
                // }).nullable(),
                // maxValueLength: Yup.number()
                //     .min(1, 'Maximum value length should be greater than zero').nullable()
                //     .max(100, 'Maximum value length can not be more than 100').nullable(),
                
                datatype: responseTypeVal !== '' ? Yup.object().shape({
                    name: Yup.string().required('Please select dataType')
                }) : Yup.object().nullable(),
                layoutId: (responseTypeVal === _configCodes?.radio || responseTypeVal === _configCodes?.checkbox) ? Yup.object().shape({
                    name: Yup.string().required('Please select response layout')
                }) : Yup.object().nullable(),
        defaultValue: variableData?.datatype?.code === _configCodes?.real ? Yup.string().matches(/^[0-9]*\./, 'Please Enter Decimal Value') : Yup.string(),
        responseOptions: (responseTypeVal === _configCodes?.radio || responseTypeVal === _configCodes?.checkbox || responseTypeVal === _configCodes?.['single-select'] || responseTypeVal === _configCodes?.['multi-select']) ? Yup.array()
            .of(
                Yup.object().shape({
                    response: Yup.string().required('Please enter Response Text')
                    .matches(/[^\s*]/g, "Please enter integer values in each response options text")
                })
                ) : Yup.array().nullable(),
                variableFieldFormat: (responseTypeVal === _configCodes?.text && dataTypeValue === _configCodes?.string) ? Yup.object().shape({
                    label: Yup.string().required("Please Select Field Format")
                }) : Yup.object().nullable(),
                // placeholder: (responseTypeVal === _configCodes?.text || responseTypeVal === _configCodes?.textarea) ? Yup.string()
                //     .required('Please enter placeholder'):Yup.object().nullable(),
                // isValueUpperCase: (responseTypeVal === _configCodes?.text && dataTypeValue === _configCodes?.string) ? Yup.string()
                // .required('Please select case').nullable() : Yup.string().nullable(),
                uploadFileType: (responseTypeVal === "RES_TYP_FILE") ? Yup.object().shape({
                    code: Yup.string().required('Please select file type')
                }) : Yup.object().nullable(),
            })
        }

export const importFormValidation = Yup.object().shape({
    existingFormId: Yup.string().required("Please select form name").nullable(),
    studyId: Yup.string().required("Please select study").nullable(),
})

export const groupSchema = Yup.object().shape({
    name: Yup.string()
        .required('Please enter group name'),
    // .matches(/^[a-zA-Z0-9]+$/, 'Group name should start with text and will not allow any special characters & spaces'),
    repeatMax: Yup.number()
        .required('Please enter repeat max'),
    repeatNumber: Yup.number().required('Please enter repeat number')
        .when('repeatMax', (repeatMax, schema) => {
            if (repeatMax) {
                return schema.test({
                    test: (repeatNumber: any) => repeatNumber <= repeatMax,
                    message: "Repeat number should be lessthan (or) equal to repeat max"
                })
            }
        }),
})


export const DefaultValuesSchema = (dataType: any) => {
    switch (dataType) {
        case _configCodes?.string:
            return Yup.object().shape({
                groupDefaultValues: Yup.array()
                    .of(
                        Yup.object().shape({
                            defaultValue: Yup.string()
                                .matches(/^\S+(?: \S+)*$/, 'Variable default values should not start with white spaces')
                        })
                    )
            });
        case 'DATA_TYP_INTEGER':
            return Yup.object().shape({
                groupDefaultValues: Yup.array()
                    .of(
                        Yup.object().shape({
                            defaultValue: Yup.string()
                                //.matches(/^(0|[1-9][0-9]+)$/gm, 'please enter integer value')
                                .min(0, 'Please enter positive numbers only')
                                .matches(/^\S+(?: \S+)*$/, 'Variable default values should not start with white spaces')
                        })
                    )
            });
        case 'DATA_TYP_REAL':
            return Yup.object().shape({
                groupDefaultValues: Yup.array()
                    .of(
                        Yup.object().shape({
                            defaultValue: Yup.string()
                                .matches(/^[\d]+(\.)[\d]{1,6}$/, 'Please enter decimal value')
                                .matches(/^\S+(?: \S+)*$/, 'Variable default values should not start with white spaces')
                        })
                    )
            });
        case 'DATA_TYP_DATE':
            return Yup.object().shape({
                groupDefaultValues: Yup.array()
                    .of(
                        Yup.object().shape({
                            defaultValue: Yup.date()
                            // .matches(/^[\d]+(\.)[\d]{1,6}$/, 'Please Enter Real Type')
                        })
                    )
            });
        case 'DATA_TYP_TIME':
            return Yup.object().shape({
                groupDefaultValues: Yup.array()
                    .of(
                        Yup.object().shape({
                            defaultValue: Yup.string()
                        })
                    )
            });
        case 'DATA_TYP_PARTIAL_DATE':
            return Yup.object().shape({
                groupDefaultValues: Yup.array()
                    .of(
                        Yup.object().shape({
                            defaultValue: Yup.string()
                            // .matches(/^\S+(?: \S+)*$/, 'Variable Default Values Should Not Start With White Spaces')
                        })
                    )
            });
    }
}
