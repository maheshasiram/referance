import {
  NewForm, Params, Field, ImaportVariable, Groups, ImportForm, AddUnits
} from "./form-types"


export const AddFormPayload: NewForm = {
  id: 0,
  formName: '',
  exportName: '',
  ordinal: 0,
  status: true,
  noOfFields: 0,
  studyId: 0,
  labForm: false,
  category: ''
}


export const formParam: Params = {
  limit: 10,
  offset: 0,
  nameCriteria: '',
  studyId: 0
}

export const Variable: Field = {
  id: 0,
  formId: 0,
  groupId: '',
  variableId: "",
  variableText: "",
  ordinal: 0,
  // description: "",
  units: "",
  onAirInstruction: "",
  status: true,
  maxValueLength: NaN,
  minValueLength: NaN,
  placeholder:"", //Adding new key for placeholder -Akshay
  missingCheck: false,
  isValueUpperCase: false,
  isValueLowerCase:false,
  isValueCapitalisation:false,
  variableFieldFormat: {
    id: 0,
    label: "",
    value: "",
    errorMessage: ""
  },
  spellCheck: false,
  isFutureDate: true,//changing key as per backend requirement-Nitish
  isPastDateEnable: true,//Adding new key-Nitish
  uploadFileType: {
    id: 0,
    name: "",
    code: "",
    description: "",
    configDataType: {
      id: 0,
      name: "",
      code: "",
      description: ""
    }
  }, // File type added -Akshay
    responseType: {
      id: 0,
      name: "",
      code: "",
      description: "",
      configDataType: {
        id: 0,
        name: "",
        code: "",
        description: ""
      }
    },
    reason: '',
    datatype: {
      id: 0,
      name: "",
      code: "",
      description: "",
      configDataType: {
        id: 0,
        name: "",
        code: "",
        description: ""
      }
    },
    defaultValue: "",
    header: "",
    note: "",
    questionNumber: "",
    readOnly: false,
    responseOptionExist: true,
    layoutId: {
      id: 0,
      name: "",
      code: "",
      description: "",
      configDataType: {
        id: 0,
        name: "",
        code: "",
        description: ""
      }
    },
    responseOptions: [
      {
        id: 0,
        response: "",
        status: true
      }
    ]

  }

export const importUngroupedParam: ImaportVariable =
  {
    id: 0,
    formId: 0,
    groupId: 0,
    variableId: "",
    variableText: "",
    ordinal: 0
  }

export const Group: Groups =
  {
    name: '',
    status: true,
    repeatNumber: '',
    repeatMax: '',
    rowStartNumber: '',
    formId: '',
    header: '',
    note: ''
  }

export const importForm: ImportForm = {
    formName: "",
    exportName: "",
    existingFormId: '',
    currentStudyId: 0,
    fields: []
  }

export const addUnits: AddUnits = {
    units: [
      {
        id: 0,
        units: ""
      }
    ]
  }