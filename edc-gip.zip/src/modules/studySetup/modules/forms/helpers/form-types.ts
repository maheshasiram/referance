export type NewForm = {
  id: number,
  formName: string,
  exportName: string,
  ordinal: number,
  status: boolean,
  noOfFields: number,
  studyId: number
  labForm: boolean,
  category: string
}

export type Params = {
  offset: number,
  limit: number,
  nameCriteria: string,
  studyId: number
}

type configDataType = {
  id?: number,
  name?: string,
  code?: string,
  description?: string
}

type responseType = {
  id?: number,
  name?: string,
  code?: string,
  description?: string,
  configDataType?: configDataType
}

type datatype = {
  id?: number,
  name?: string,
  code?: string,
  description?: string,
  configDataType?: configDataType
}
type uploadFile = {
  id?: number,
  name?: string,
  code?: string,
  description?: string,
  configDataType?: configDataType
}

type responseOptions = [
  {
    id?: number,
    response?: string,
    status?: boolean
  }
]

type layoutId = {
  id?: number,
  name?: string,
  code?: string,
  description?: string,
  configDataType?: configDataType
}

export type Field = {
  id?: number,
  formId?: number,
  groupId?: any,
  variableId?: string,
  variableText?: string,
  ordinal?: number,
  // description?: string,

  units?: string,
  maxValueLength?: number,
  minValueLength?: number,
  placeholder?:string,
  missingCheck?: boolean,
  isValueUpperCase?: boolean,
  isValueLowerCase?:boolean,
  isValueCapitalisation?:boolean,
  variableFieldFormat?: any,
  spellCheck?: boolean,
  isFutureDate?: boolean,//changing key as per backend requirement-Nitish
  isPastDateEnable?: boolean,//Adding new key-Nitish
  uploadFileType?: uploadFile, // Added file type field - Akshay
  onAirInstruction?: string,
  status?: boolean,
  responseType?: responseType,
  reason?: string,
  datatype?: datatype,
  defaultValue?: string,
  header?: string,
  note?: string,
  questionNumber?: any,
  readOnly?: boolean,
  responseOptionExist?: boolean,
  layoutId?: layoutId,
  responseOptions?: responseOptions
}

export type ImaportVariable =
  {
    id?: number,
    formId?: number,
    groupId?: any,
    variableId?: string,
    variableText?: string,
    ordinal?: number
  }

export type Groups = {
  name?: string,
  status?: boolean,
  repeatNumber?: any,
  repeatMax?: any,
  rowStartNumber?: any,
  formId?: any,
  header?: string,
  note?: string
}

export type ImportForm = {
  formName: string,
  exportName: string,
  existingFormId: string,
  currentStudyId: number,
  fields: any
}

export type AddUnits = {
  units: [
    {
      id: number,
      units: string
    }
  ]
}
