
export const ResponseTypes: any = {
    "": [
        {
            "value": "",
            "text": "Select Data Type"
        }
    ],
    "text": [
        {
            "value": "",
            "text": "Select Data Type"
        },
        {
            "value": "DATA_TYP_STRING",
            "text": "String"
        },
        {
            "value": "DATA_TYP_INTEGER",
            "text": "Integer"
        },
        {
            "value": "DATA_TYP_REAL",
            "text": "Real"
        },
        {
            "value": "DATA_TYP_DATE",
            "text": "Date"
        },
        {
            "value": "DATA_TYP_TIME",
            "text": "Time"
        },
        {
            "value": "DATA_TYP_PARTIAL_DATE",
            "text": "Partial Date"
        },
        {
            "value": "DATA_TYP_PARTIAL_TIME",
            "text": "Partial Time"
        }
    ],
    "textarea": [
        {
            "value": "DATA_TYP_STRING",
            "text": "String"
        }
    ],
    "single-select": [
        {
            "value": "",
            "text": "Select Data Type"
        },
        {
            "value": "DATA_TYP_STRING",
            "text": "String"
        },
        {
            "value": "DATA_TYP_INTEGER",
            "text": "Integer"
        }
    ],
    "radio": [
        {
            "value": "",
            "text": "Select Data Type"
        },
        {
            "value": "DATA_TYP_STRING",
            "text": "String"
        },
        {
            "value": "DATA_TYP_INTEGER",
            "text": "Integer"
        }
    ],
    "multi-select": [
        {
            "value": "",
            "text": "Select Data Type"
        },
        {
            "value": "DATA_TYP_STRING",
            "text": "String"
        },
        {
            "value": "DATA_TYP_INTEGER",
            "text": "Integer"
        }
    ],
    "checkbox": [
        {
            "value": "",
            "text": "Select Data Type"
        },
        {
            "value": "DATA_TYP_STRING",
            "text": "String"
        },
        {
            "value": "DATA_TYP_INTEGER",
            "text": "Integer"
        }
    ],
    "file": [
        {
            "value": "DATA_TYP_FILE",
            "text": "File"
        }
    ]
};