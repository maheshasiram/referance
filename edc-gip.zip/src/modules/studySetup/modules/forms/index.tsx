import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Loader } from "../../../../actions/actions";
import { fetchAllFormsByCriteria } from "./actions/actions";
import FormsDashboard from "./components/formDetails/FormsDashboard";
import { Types } from "./reducer/Types";
import './styles/forms.scss'

function Forms() {
    const dispatch:any = useDispatch()
    const { formParams } = useSelector((state: any) => state.forms);
    const { currentStudy } = useSelector((state: any) => state.application)
    const loaded = React.useRef(false);

    useEffect(() => {
        if (!loaded.current) {
            // alert('skdjasjdn')
            dispatch(Loader(true));
            const fetchAllFormPayload = { ...formParams, studyId: currentStudy.id, offset: 0, nameCriteria: '',limit:10 }
            dispatch(fetchAllFormsByCriteria(fetchAllFormPayload, (response: any) => {
                if (response && response.data) {
                    console.log('respinse.....', response);

                    dispatch(Loader(false))
                }
            }));
            dispatch({ type: Types.GET_FORM_PARAMS, payload: fetchAllFormPayload });
            dispatch({ type: Types.FORM_DETAILS_BY_ID, payload: {} });
            loaded.current = true
        }
        // return () => {
        //     let _payload = { ...formParams, studyId: currentStudy.id, offset: 0 }
        //     dispatch({ type: Types.GET_FORM_PARAMS, payload: _payload });
        // };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    return (
        <React.Fragment>
            <FormsDashboard />
        </React.Fragment>
    )
}
export default Forms;