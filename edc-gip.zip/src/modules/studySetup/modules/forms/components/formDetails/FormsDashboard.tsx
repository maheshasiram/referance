import React from "react";
import SearchField from "../../../../../../common/searchField/SearchField";
import FormsDataGrid from "./FormsDataGrid";
// import '../../styles/forms.scss'
import { useDispatch, useSelector } from "react-redux";
import { fetchAllFormsByCriteria } from "../../actions/actions";
import AddForm from "./AddForm";
import ImportForm from "./ImportForm";
import { Types } from "../../reducer/Types";
import PageCount from "../../../../../../common/pagecount/PageCount";

function FormsDashboard() {
  const dispatch = useDispatch();
  const [formSearch, setFormSearch] = React.useState('')
  const { formParams } = useSelector((state: any) => state.forms);

  const OnFindForms = (event: any) => {
    setFormSearch(event.target.value)
    const _payload = { ...formParams, nameCriteria: event.target.value, offset: 0 }
    dispatch({ type: Types.GET_FORM_PARAMS, payload: _payload })
    dispatch(fetchAllFormsByCriteria({ ..._payload }))
  }

  const onClearSearch = () => {
    setFormSearch('')
    const _payload = { ...{}, ...formParams, nameCriteria: '', offset: 0 }
    dispatch({ type: Types.GET_FORM_PARAMS, payload: _payload })
    dispatch(fetchAllFormsByCriteria({ ..._payload }));
  }
  const onChangePageCount = (e: any) => {
    const fetchAllFormPayload = { ...formParams, limit: parseInt(e.target.value) }
    dispatch({ type: Types.GET_FORM_PARAMS, payload: fetchAllFormPayload });
    dispatch(fetchAllFormsByCriteria(fetchAllFormPayload));
  }
  return (
    <React.Fragment>
      <div className="position-relative" >
        <div className="d-flex justify-content-between pb-2 controls-container">
          <PageCount onChange={(e: any) => onChangePageCount(e)} />
          <div className="right-panel d-flex">
            <div className="left-container">
              <AddForm form={{ id: 0 }} />
              <ImportForm />
            </div>
            <SearchField value={formSearch}
              placeholder="Search by form name"
              onChange={OnFindForms} onClearSearch={onClearSearch} />
          </div>
        </div>
        <FormsDataGrid />
      </div>
    </React.Fragment>
  )
}

export default FormsDashboard;