import { Field, Form, Formik } from "formik";
import React, { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import EditIcon from '@mui/icons-material/Edit';
import { AddFormPayload } from "../../helpers/form-modal";
import CustomDialog from "../../../../../../common/modals/CustomeDialog";
import { AddorEditFormValidation } from "../../helpers/Validate";
import { Types } from "../../reducer/Types";
import { createNewForm, editOrUpdateForm, fetchAllFormsByCriteria } from "../../actions/actions";
import { toastAlert } from "../../../../../../actions/actions";
import CustomToolTip from "../../../../../../components/CustomToolTip";
import Switch from "@mui/material/Switch";
import { getAllCategoriesList } from "../../../labs/actions/actions";

function AddForm(props: any) {
  const dispatch = useDispatch()
  const { form } = props;
  const [open, setOpen] = useState(false)
  const [erroeMsg, setErroeMsg] = useState('');
  const [btnDisable, setBtnDisable] = useState(false);
  const { addForm, formParams } = useSelector((state: any) => state.forms);
  const { categoriesList } = useSelector((state: any) => state.labs)
  const { currentStudy } = useSelector((state: any) => state.application);
  // const loaded = React.useRef(false);

  const onOpenAddForm = () => {
    setOpen(true);
    setBtnDisable(true);
    dispatch(getAllCategoriesList())
  }
  const onCloseAddEdit = () => {
    setOpen(false)
    setErroeMsg('')
    dispatch({ type: Types.GET_ADD_UPDATE_FORM, payload: AddFormPayload })
  }
  // React.useEffect(() => {
  //   if (!loaded.current){
  //     dispatch(getAllCategoriesList())
  //     loaded.current = true
  //   }
  // }, [])
  // console.log("42...", categoriesList)

  const onUpdateForm = (values: any) => {
    dispatch(editOrUpdateForm(values, (response: any) => {
      if (!response.data.errorMessage) {
        onCloseAddEdit()
        dispatch(fetchAllFormsByCriteria({ ...formParams, studyId: currentStudy.id }))
        dispatch(toastAlert({
          status: 1,
          open: true,
          message: `${values.formName} form updated successfully!`
        }))
      } else {
        setErroeMsg(response.data.errorMessage)
      }
    }))
  }
  const onSubmitHandler = (values: any) => {
    if (form.id === 0) {
      dispatch(createNewForm({ ...values, studyId: currentStudy.id }, (response: any) => {
        if (!response.data.errorMessage) {
          onCloseAddEdit()
          dispatch(fetchAllFormsByCriteria({ ...formParams, studyId: currentStudy.id }))
          dispatch(toastAlert({
            status: 1,
            open: true,
            message: `${values.formName} form created successfully!`
          }))
        } else {
          setErroeMsg(response.data.errorMessage)
        }
      }))
    }
    else {
      onUpdateForm(values);
    }
  }
  return (
    <React.Fragment>
      {
        (form && form.id === 0) ?
          <button className="btn-eprimary" onClick={onOpenAddForm}> Add Form </button> :
          <CustomToolTip title="Edit Form">
            <EditIcon sx={{ fontSize: 14, opacity: .8 }}
              onClick={() => props.onUpdateForm(onOpenAddForm)}
            />
          </CustomToolTip>
      }
      <CustomDialog
        title={addForm.id === 0 ? 'Add Form' : "Edit Form"}
        open={open}
        onClose={onCloseAddEdit}
        maxWidth="xs"
        fullWidth={true}
        cssName={`sm-container`}
        actionType={addForm.id === 0 ? 'Submit' : "Update"}
        form={'AddEditForm'}
        disabled={btnDisable}
      >
        <Formik
          enableReinitialize={true}
          initialValues={addForm}
          validationSchema={AddorEditFormValidation}
          onSubmit={(values: any) => {
            onSubmitHandler(values);
          }}
        >
          {({ errors, touched, values, setFieldValue }) => (
            <Form id='AddEditForm' className="mt-2">
              {erroeMsg && <p className="text-danger">{erroeMsg}</p>}

              <div>
                <label htmlFor="text-formName">Form Name :<span className="text-danger">*</span></label>
                <Field
                  id="text-formName"
                  name='formName'
                  placeholder="Enter form name"
                  className="form-control mt-1"
                  onChange={(e: any) => {
                    if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
                      if (e.target.value) { setBtnDisable(false); }
                      setFieldValue('formName', e.target.value);
                      setErroeMsg('')
                    }
                  }}
                />
                {(errors && errors.formName && touched && touched.formName) &&
                  <span className="text-danger">{errors.formName as string}</span>}
              </div>
              <div className="mt-3">
                <label htmlFor="txt-exportName">Export Name :<span className="text-danger">*</span></label>
                <Field
                  type="text"
                  id="txt-exportName"
                  name='exportName'
                  placeholder="Enter export name"
                  className="form-control mt-1"
                  onKeyPress={(e: any) => {
                    if (e.target.value.length > 7) {
                      e.preventDefault();
                    }
                  }}
                  onChange={(e: any) => {
                    if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
                      setBtnDisable(false);
                      setErroeMsg('');
                      setFieldValue('exportName', e.target.value);
                    }
                  }}
                />
                {(errors && errors.exportName && touched && touched.exportName) &&
                  <span className="text-danger">{errors.exportName as string}</span>}
              </div>
              {/* <div className='mt-3'>
                <div>
                  <label htmlFor="labForm">Lab Form: </label>

                  <Switch
                    checked={values.status}
                    onChange={(e: any) => {
                      setFieldValue("labForm", e.target.checked)
                    }}
                    name="labForm"
                  ></Switch>
                </div>
              </div>
              {values.status &&
                <div className="mt-3">
                  <label htmlFor="txt-existingFormId">Category:</label>
                  <Field as='select'
                    name='category'
                    className="form-select mt-1 "
                    id="select-category"
                    onChange={(e: any) => {
                      setBtnDisable(false);
                      setFieldValue('category', e.target.value);
                    }}
                  >
                    <>{console.log("102....", values, categoriesList)}</>
                    <option value="">Select Category</option>
                    {
                      categoriesList && categoriesList.data.map((i: any) => {
                        return <option value={i.id} key={i.id}>{i.name}</option>
                      })
                    }
                  </Field>
                  {(errors && errors.category && touched && touched.category) &&
                    (<span className="text-danger">{errors.category as string}</span>)}
                </div>
              } */}
            </Form>
          )}
        </Formik>
      </CustomDialog>
    </React.Fragment>
  )
}
export default AddForm