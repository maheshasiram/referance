import { Form, Formik } from "formik";
import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { toastAlert } from "../../../../../../actions/actions";
import CustomDialog from "../../../../../../common/modals/CustomeDialog";
import { fetchAllFormsByCriteria, getFormsByStudyId, getImportForm } from "../../actions/actions";
import { AddFormPayload } from "../../helpers/form-modal";
import { importFormValidation } from "../../helpers/Validate";
import { Types } from "../../reducer/Types";
import SelectField from "../../../../../../common/selectField/SelectField";

function ImportForm() {
  const dispatch = useDispatch()
  const [open, setOpen] = useState(false)
  const [erroeMsg, setErroeMsg] = useState('')
  const [formsList, setFormsList] = useState([]);
  const [btnDisable, setBtnDisable] = useState(false);
  const { formParams, importFormParams } = useSelector((state: any) => state.forms)
  const { currentStudy, studies } = useSelector((state: any) => state.application)

  const studiesOption = (studies: any) => {
    const options: any = []
    studies.map((item: any) => {
      const option = {
        label: item.protocolId,
        value: item.id
      }
      options.push(option)
      return null;
    })
    return options
  }
  const formOptions = (formsList: any) => {
    console.log("34....",formsList)
    const options: any = []
    formsList.map((item: any) => {
      const option = {
        label: item.formName,
        value: item.id
      }
      options.push(option)
      return null;
    })
    return options
  }
  const onOpenAddForm = () => {
    setOpen(true);
    setBtnDisable(true);
  }
  const onCloseAddEdit = () => {
    setOpen(false)
    setErroeMsg('')
    setFormsList([])
    dispatch({ type: Types.GET_ADD_UPDATE_FORM, payload: AddFormPayload })
  }
  const onSubmitImportForm = (values: any) => {

    const _payload: any = []
    values.existingFormId.map((existingForm: any) => {
      const _form: any = formsList.find((ele: any) => ele.id === parseInt(existingForm.value))
      const payload: any = {
        "formName": _form.formName,
        "exportName": _form.exportName,
        "existingFormId": _form.id,
        "currentStudyId": currentStudy.id,
        "fields": []
      }
      _form.formFields && _form.formFields.length > 0 && _form.formFields.map((item: any) => {
        if (item.group) {
          if (item.group.fields && item.group.fields.length > 0) {
            item.group.fields.map((grpItem: any) => {
              payload.fields.push({
                "id": grpItem.id,
                "formId": grpItem.formId,
                "groupId": grpItem.groupId,
                "variableId": grpItem.variableId,
                "variableText": grpItem.variableText,
                "ordinal": grpItem.ordinal
              })
              return null;
            })
          }
        } else {
          payload.fields.push({
            "id": item.field.id,
            "formId": item.field.formId,
            "groupId": item.field.groupId,
            "variableId": item.field.variableId,
            "variableText": item.field.variableText,
            "ordinal": item.field.ordinal
          })
        }
        return null;
      })
      _payload.push(payload)
      return null;
    })
    dispatch(getImportForm(_payload, (response: any) => {
      console.log("response..66", response)
      if (response.status === 'error') {
        setErroeMsg(response.errorMessage)
      } else {
        dispatch(fetchAllFormsByCriteria({ ...formParams, studyId: currentStudy.id, offset: 0 }))
        onCloseAddEdit()
        dispatch(toastAlert({ status: 1, message: 'Forms imported successfully.', open: true, }))
      }
    }))
  }

  return (
    <React.Fragment>

      {
        <button className="btn-eprimary mx-2" onClick={onOpenAddForm} > Import Form </button>
      }

      <CustomDialog
        title={'Import Form'}
        open={open}
        onClose={onCloseAddEdit}
        maxWidth="xs"
        fullWidth={true}
        actionType={'Submit'}
        form={'importForm'}
        cssName={`sm-container import-form-container`}
        disabled={btnDisable}
      >
        <div className="header-container">
          <h6 className="text-center importForm-note">Import a Form from another Study</h6>
          <p className="text-center text-danger">{erroeMsg ? erroeMsg : ""}</p>
        </div>
        <Formik
          initialValues={{ ...importFormParams, studyId: '' }}
          validationSchema={importFormValidation}
          onSubmit={(values: any) => {
            onSubmitImportForm(values)
          }}
        >
          {({ errors, touched, values, setFieldValue }) => (
            <Form id='importForm' >
              <div>
                <label htmlFor="studyId">Study Name :<span className="text-danger">*</span></label>
                <SelectField
                  id={"studyName"}
                  className="importForm"
                  classNamePrefix="importForm-studyName"
                  defaultValue={"Select Your Study"}
                  isDisabled={false}
                  isClearable={true}
                  isSearchable={true}
                  placeholder={"Select Study"}
                  name={"studyId"}
                  value={values.studyId}
                  onChange={(e: any) => {
                    if (e) {
                      if (e.value !== "") {
                        dispatch(getFormsByStudyId(e.value, (callback: any) => {
                          setFormsList(callback.data)
                        }))
                      } else {
                        setFieldValue('existingFormId', '');
                      }
                    }
                    setFormsList([]);
                    setFieldValue('existingFormId', '')
                    setFieldValue('studyId', e);
                    setBtnDisable(false)
                  }}
                  options={studiesOption(studies)}

                />
                {(errors && errors.studyId && touched && touched.studyId) &&
                  <span className="text-danger">{errors.studyId as string}</span>}
              </div>
              <div className="mt-3">
                <label htmlFor="existingFormId">Form Name :<span className="text-danger">*</span></label>
                <SelectField
                  id={"formName"}
                  className="importForm"
                  classNamePrefix="importForm-FomName"
                  defaultValue={"Select your Form"}
                  isDisabled={false}
                  isClearable={true}
                  isSearchable={true}
                  placeholder={"Select Form"}
                  name={"existingFormId"}
                  value={values.existingFormId}
                  onChange={(e: any) => {
                    console.log('e.val222', e)
                    setBtnDisable(false);
                    // setFieldValue('existingFormId', e.map((i: any) => i.value))
                    setFieldValue('existingFormId', e)
                  }}
                  options={formOptions(formsList)}
                  isMulti={true}
                />
                {(errors && errors.existingFormId && touched && touched.existingFormId) &&
                  (<span className="text-danger">{errors.existingFormId as string}</span>)}
              </div>
            </Form>
          )}
        </Formik>
      </CustomDialog>
    </React.Fragment>
  )
}
export default ImportForm

