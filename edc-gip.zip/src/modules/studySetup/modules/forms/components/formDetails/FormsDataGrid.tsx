import React, { useState } from "react";
import { Column } from 'primereact/column';
import { DataTable } from 'primereact/datatable';
import { useDispatch, useSelector } from "react-redux";
import { activeOrDeActiveForms, fetchAllFormsByCriteria, fetchVisitsAssignedToFormId } from "../../actions/actions";
import DeleteIcon from '@mui/icons-material/Delete';
import { Confirm, toastAlert } from "../../../../../../actions/actions";
import ReplayIcon from '@mui/icons-material/Replay';
import { Types } from "../../reducer/Types";
import { NavLink } from "react-router-dom";
import AddForm from "./AddForm";
import ImportContactsIcon from '@mui/icons-material/ImportContacts';
import CustomToolTip from "../../../../../../components/CustomToolTip";

import BookIcon from '@mui/icons-material/Book';
import ActionDialog from "./ActionDialog";

function FormsDataGrid() {
  const dispatch = useDispatch();
  const { formList, formParams, visitAssignedToForms } = useSelector((state: any) => state.forms);
  const { currentStudy } = useSelector((state: any) => state.application)
  const [open, setOpen] = React.useState(false)
  const [actionType, setActionType] = useState('')
  const [pageClick, setpageChange] = useState(false);
  const [formNames, setFormNames] = useState('')

  const onUpdateForm = (rowData: any, onOpenAddForm: any) => {
    dispatch({ type: Types.GET_ADD_UPDATE_FORM, payload: rowData })
    onOpenAddForm()
  }

  const onDeleteForm = (rowData: any) => {

    dispatch(Confirm({
      status: 0, message: "Are you sure you want to delete this form?",
      onOk: () => {
        const deletePayload = { id: rowData.id, status: false }
        dispatch(activeOrDeActiveForms(deletePayload, (response: any) => {
          if (response.data.status === "error") {
            dispatch(toastAlert({
              status: 0, message: response.data.errorMessage, open: true
            }))
          } else {
            dispatch(toastAlert({
              status: 1, message: `${rowData.formName} ${response.data}`, open: true
            }))
            dispatch(fetchAllFormsByCriteria({ ...formParams, studyId: currentStudy.id }));
          }

        }))
      }
    }));
  }
  const onActivate = (rowData: any) => {
    dispatch(Confirm({
      status: 0, message: "Are you sure you want to activate?",
      onOk: () => {
        const deletePayload = { id: rowData.id, status: true }
        dispatch(activeOrDeActiveForms(deletePayload, (response: any) => {
          if (response.data.status === "error") {
            dispatch(toastAlert({
              status: 0, message: response.data.errorMessage, open: true
            }))
          } else {
            dispatch(toastAlert({
              status: 1, message: `${rowData.formName} ${response.data}`, open: true
            }))
            dispatch(fetchAllFormsByCriteria({ ...formParams, studyId: currentStudy.id }));
          }
        }))
      }
    }));
  }

  const renderFormNames = (rowData: any) => {
    return (
      <div className="form-title-temp">
        {rowData.status === false ? <span className='list-items deletedItem'> {rowData.formName} <span className="ms-1" >({rowData.noOfFields})</span></span> :
          (<span className="form-title-link">
            <NavLink to={`../EditForm/${rowData.id}`}>{rowData.formName}</NavLink>
            <span>({rowData.noOfFields})</span></span>)}
      </div>
    )
  }

  const renderExportNames = (rowData: any) => {
    return (
      <div className={rowData.status ? "" : "deletedItem"}>
        {rowData.exportName}
      </div>
    )
  }

  const renderActions = (rowData: any) => {
    return (
      <React.Fragment>
        <div className="actions">
          {rowData.status &&
            <div className="d-flex align-items-center">
              <AddForm
                form={rowData}
                actionType={'edit'}
                onUpdateForm={(onOpenAddForm: any) => onUpdateForm(rowData, onOpenAddForm)}
              />
              <span className="px-1" > |</span>
              <CustomToolTip title='Delete Form'>
                <DeleteIcon
                  sx={{ fontSize: 14, opacity: .8 }}
                  className='text-danger'
                  onClick={() => onDeleteForm(rowData)}
                />
              </CustomToolTip>
              <span className="px-1" > |</span>
              <CustomToolTip title='Open visit'>
                <ImportContactsIcon
                  sx={{ fontSize: 14, opacity: .8 }}
                  onClick={() => onOpenVisit(rowData)}
                />
              </CustomToolTip>
              {/* <span className="px-1" > |</span>
              <CustomToolTip title='Open Tests'>
                <BookIcon
                  sx={{ fontSize: 14, opacity: .8 }}
                  onClick={() => onOpenTests(rowData)}
                />
              </CustomToolTip> */}
            </div>}
          {!rowData.status &&
            <div>
              <CustomToolTip title='Restore Form'>
                <ReplayIcon sx={{ fontSize: 22, opacity: .8 }}
                  onClick={() => onActivate(rowData)} />
              </CustomToolTip>
            </div>
          }
        </div>
      </React.Fragment>
    )
  };

  const onOpenVisit = (rowData: any) => {
    setFormNames(rowData.formName)
    dispatch(fetchVisitsAssignedToFormId(rowData.id))
    setOpen(true)
    setActionType('visit')
  }
  const onOpenTests = (rowData: any) => {
    setOpen(true)
    setActionType('lab')
  }

  const onPage = (event: any) => {
    if ((event.page > 0) || (pageClick && event.page === 0)) {
      const _payload = { ...formParams, studyId: currentStudy.id, offset: event.first }
      dispatch(fetchAllFormsByCriteria(_payload));
      dispatch({ type: Types.GET_FORM_PARAMS, payload: _payload })
      setpageChange(true)
    }
  }
  return (
    <React.Fragment>
      {formList && <DataTable
        scrollable
        value={!formList.forms ? [] : formList.forms}
        emptyMessage="No forms are available to display"
        rows={formParams.limit}
        paginator={(formList.forms && formList.totalRecords > formParams.limit) ? true : false}
        first={formParams.offset}
        totalRecords={formList && formList.totalRecords}
        lazy onPage={(e: any) => onPage(e)} responsiveLayout="scroll">
        <Column body={renderFormNames} header="Form Name" style={{ width: 'auto' }} />
        <Column body={renderExportNames} header="Export Name" style={{ width: 'auto' }} />
        <Column body={renderActions} header="Actions" style={{ width: '30%' }} />
      </DataTable>}
      <ActionDialog
        formNames={formNames}
        actionType={actionType}
        visitAssignedToForms={visitAssignedToForms}
        setOpen={setOpen}
        open={open}
      />
    </React.Fragment>
  )
}

export default FormsDataGrid;
