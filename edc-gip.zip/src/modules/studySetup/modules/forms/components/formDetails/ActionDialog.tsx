import React from 'react'
import CustomDialog from '../../../../../../common/modals/CustomeDialog'
import LabTestData from './LabTestData';


function ActionDialog(props: any) {
    const { formNames } = props;
    const onCloseHandler = () => {
        props.setOpen(false)
    }

    return (
        <div>
            <CustomDialog
                title={props.actionType === "visit" ? `Visits(${formNames})` : 'Tests'}
                onClose={onCloseHandler}
                onSubmitHandler={() => { return null }}
                open={props.open}
                maxWidth={"xs"}
            // cssName={`sm-container`}

            >
                <div className="dialog-body-rearrangeVisits">
                    {props.actionType === "visit" ?
                        <div className='list-items-container'>
                            {props.visitAssignedToForms && props.visitAssignedToForms.length > 0 ? props.visitAssignedToForms.map((visitData: any, index: number) => {
                                return (
                                    <div className="visit-name" key={index}>
                                        {visitData.visitName}
                                    </div>
                                )
                            }) :
                                // <div className="d-flex justify-content-center align-items-center">
                                //     No visits available to display.
                                // </div>
                                <p className="no-item-available">No visits available to display</p>
                            }
                        </div> :
                        <div>
                            <LabTestData />
                        </div>
                    }
                </div>
            </CustomDialog>
        </div>
    )
}

export default ActionDialog