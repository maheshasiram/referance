
import React, { useState } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';

export default function LabTestData() {
    const [selectedProducts, setSelectedProducts] = useState(null);

   const labs = [
    {
        "id": 491,
        "test": "Medical",
        "units": "MHistory",
    },
    {
        "id": 492,
        "test": "Clinical1",
        "units": "Clinical_1",
    },
    {
        "id": 491,
        "test": "Medical1",
        "units": "MHistory1",
    },
    {
        "id": 492,
        "test": "Clinical2",
        "units": "Clinical_2",
    },
    
]
       
    return (
        <div className="Lab-Datatable mt-2 mb-2 ps-4">
            <DataTable scrollable value={labs} selectionMode={'checkbox'} selection={selectedProducts} onSelectionChange={(e) => setSelectedProducts(e.value)} dataKey="id" tableStyle={{ minWidth: '75rem' }}>
                <Column selectionMode="multiple" headerStyle={{width:'10rem'}} ></Column>
                <Column field="test" header="Test" ></Column>
                <Column field="units" header="Units"></Column>
                <Column header="Actions" ></Column>
            </DataTable>
        </div>
    );
}
        