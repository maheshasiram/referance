import React, { useState } from "react";
import CustomDialog from "../../../../../../../common/modals/CustomeDialog";
import EditIcon from '@mui/icons-material/Edit';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import { useDispatch, useSelector } from "react-redux";
import { groupSchema } from "../../../helpers/Validate";
import { addUpdateGroup, getFormsDetailsId, getGroupDeatilsById } from "../../../actions/actions";
import { toastAlert } from "../../../../../../../actions/actions";
import GroupsIcon from '@mui/icons-material/Groups';
import { Types } from "../../../reducer/Types";
import { useParams } from "react-router-dom";
// import { messages } from "../../../../../constants/messages";
import CustomToolTip from "../../../../../../../components/CustomToolTip";
// import { toastAlert } from "../../../../../../../../actions/actions";

function GroupVariable(props: any) {
  const { groupDetails } = useSelector((state: any) => state.forms);
  const { groupId } = props;
  const params = useParams();
  const [error, setError] = useState('');
  const [btnDisable, setBtnDisable] = useState(false);
  const [isGroup, setIsGroup] = useState(false);
  const dispatch = useDispatch();
  React.useEffect(() => {
    if (props.page === 0) {
      setIsGroup(true);
      if (props.groupId && props.groupId > 0) {
        dispatch(getGroupDeatilsById(props.groupId));
      }
    }
  }, [dispatch, props.groupId, props.page]);

  const onOpen = () => {
    setIsGroup(true);
    setBtnDisable(true);
    if (groupId > 0) {
      dispatch(getGroupDeatilsById(groupId));
    } else {
      dispatch({ type: Types.INITIALIAZE_GROUP })
    }
  }
  const onCloseHandler = () => {
    setIsGroup(false);
    setError("");
    if (props.onCloseHandler) {
      props.onCloseHandler();
    }
  }

  const onResetHandler = () => {
    dispatch({ type: Types.INITIALIAZE_GROUP })
  }

  const onSubmitGroupDetails = (values: any) => {
    const _values = { ...values, formId: params.id }
    dispatch(addUpdateGroup(_values, (data: any) => {
      if (data.status !== 'error'  /*data*/) {
        // (dispatch as any)(Alert({
        //   status: 2, message: values.id ? messages.forms.group.update : messages.forms.group.success,
        //   onOk: () => {
        //     dispatch(getFormsDetailsId(params.id));
        //   }
        // }));
        dispatch(toastAlert({ status: 1, message: `Group ${props.type === 1 ? ' updated ' : 'added '} successfully`, open: true }))
        dispatch(getFormsDetailsId(params.id));
        onCloseHandler();
        // props.setToastOpen(true)
      } else {
        setError(data.errorMessage);
      }
    }))
  }
  const validateRepeatMax = (value: any) => {
    let error;
    const _groupDetails: any = { ...{}, ...groupDetails };
    if (value < _groupDetails.repeatNumber) {
      error = 'Repeat max must not be decreased the existing value';
    }
    return error;
  }
  const validateRepeatNumber = (values: any) => {
    let error;
    const _groupDetails: any = { ...{}, ...groupDetails };
    if (values < _groupDetails.repeatNumber) {
      error = 'Repeat number must not be decreased the existing value';
    }
    return error;
  }

  return (
    <React.Fragment>
      {(props.type === 1) ?
        (<CustomToolTip title='Edit Group'><EditIcon onClick={() => onOpen()} sx={{ fontSize: 14, opacity: .8 }} /></CustomToolTip>) :
        (props.type === 0) && (<li className="list-group-item" onClick={() => onOpen()} >
          <span className="icons"><GroupsIcon /></span>Add Group</li>)
      }
      <CustomDialog
        title={groupDetails.id ? 'Update Group' : 'Add Group'}
        onClose={onCloseHandler}
        onSubmitHandler={() => { return null }}
        open={isGroup}
        onResetHandler={groupDetails.id ? null : () => onResetHandler()}
        maxWidth={"xs"}
        actionType={groupDetails.id ? 'Update' : 'Submit'}
        form="addGroup"
        cssName={`sm-container`}
        disabled={btnDisable}
      >
        <Formik
          enableReinitialize={true}
          initialValues={groupDetails}
          validationSchema={groupSchema}
          onSubmit={values => {
            onSubmitGroupDetails(values);
          }}
        >
          {({ errors, touched, values, setFieldValue }) => (
            <Form id="addGroup" className="form-container p-0">
              <div className="d-flex justify-content-center">
                {error ? <p className='text-danger '>{error}</p> : <span>&nbsp;</span>}
              </div>
              <div className='form-group' id="div-addGroup">
                <label htmlFor="txt-groupLabel"> Group Name : <span className="text-danger">*</span></label>
                <Field
                  className="form-control form-control-lg "
                  name="name"
                  value={values.name}
                  placeholder="Enter group name"
                  onChange={(e: any) => {
                    if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
                      setFieldValue("name", e.target.value);
                      setBtnDisable(false);
                    }
                  }}
                  id='txt-groupLabel' />
                {errors.name && touched.name ? <span className="text-danger"><ErrorMessage name={`name`} /></span> : <span>&nbsp;</span>}
              </div>
              <div className="row" >
                <div className='form-group col'>
                  <label htmlFor="txt-groupRepeatMax"> Repeat Max : <span className="text-danger">*</span></label>
                  <Field
                    className="form-control form-control-lg "
                    name="repeatMax"
                    value={values.repeatMax}
                    placeholder="Enter repeat max"
                    id='txt-groupRepeatMax'
                    validate={(value: any) => validateRepeatMax(value)}
                    type='number'
                    onKeyPress={(e: any) => {
                      if (e.key === "-" || e.key === "+" || e.key === "e" || e.key === ".") {
                        e.preventDefault();
                      }
                    }}
                    onChange={(e: any) => {
                      console.log('155...', e.target.value)
                      if (e.target.value.length <= 10) {
                        e.preventDefault();
                        setBtnDisable(false)
                        const { value } = e.target;
                        const regex = /^(0*[1-9][0-9]*(\.[0-9]*)?|0*\.[0-9]*[1-9][0-9]*)$/;
                        if (!value || regex.test(value.toString())) {
                          setFieldValue("repeatMax", value);
                        }
                      } else {
                        e.preventDefault()
                      }
                    }}
                  />
                  <div className="text-danger"><ErrorMessage name={`repeatMax`} /></div>
                </div>
                <div className='form-group col'>
                  <label htmlFor="txt-groupRepeatNumber">
                    Repeat Number : <span className="text-danger">*</span></label>
                  <Field
                    className="form-control form-control-lg "
                    name="repeatNumber"
                    value={values.repeatNumber}
                    placeholder="Enter repeat number"
                    id='txt-groupRepeatNumber'
                    type='number'
                    validate={(value: any) => validateRepeatNumber(value)}
                    onKeyPress={(e: any) => {
                      if (e.key === "-" || e.key === "+" || e.key === "e" || e.key === ".") {
                        e.preventDefault();
                      }
                    }}
                    onChange={(e: any) => {
                      if (e.target.value.length <= 10) {
                        e.preventDefault();
                        setBtnDisable(false)
                        const { value } = e.target;
                        const regex = /^(0*[1-9][0-9]*(\.[0-9]*)?|0*\.[0-9]*[1-9][0-9]*)$/;
                        if (!value || regex.test(value.toString())) {
                          setFieldValue("repeatNumber", value);
                        }
                      } else {
                        e.preventDefault()
                      }
                    }}
                  />
                  {errors.repeatNumber && touched.repeatNumber ? <span className="text-danger"><ErrorMessage name={`repeatNumber`} /></span> : <span>&nbsp;</span>}
                </div>

              </div>
              <div className='form-group '>
                <label htmlFor="txt-groupHeader"> Header :</label>
                <Field
                  as="textarea"
                  className="form-control form-control-lg "
                  name="header"
                  value={values.header}
                  placeholder="Enter header"
                  onChange={(e: any) => {
                    setFieldValue('header', e.target.value)
                    setBtnDisable(false)
                  }}
                  id='txt-groupHeader' />

              </div>
              <div className='form-group mt-3'>
                <label htmlFor="txt-groupNote"> Note :</label>
                <Field
                  as="textarea"
                  className="form-control form-control-lg "
                  name="note"
                  value={values.note}
                  placeholder="Enter note"
                  onChange={(e: any) => {
                    setFieldValue('note', e.target.value)
                    setBtnDisable(false)
                  }}
                  id='txt-groupNote' />

              </div>

            </Form>
          )}
        </Formik>
      </CustomDialog>
    </React.Fragment>
  )
}
export default GroupVariable
