import React, { useState } from "react";
import { useSelector } from "react-redux";

function PartialTime(props:any) {
    const {index,item,setFieldValue,setDisableSubmit,setErroeMsg} = props;

    const { currentStudy } = useSelector((state: any) => state.application);
    const [timeFields, setTimeFields] = useState([
        { label: 'hh', value: '' },
        { label: 'mm', value: '' },
        { label: 'ss', value: '' },
    ])
    return (
        <React.Fragment>
            {
                timeFields?.map((timeItem: any, fieldIndex: any) => (
                    <>
                        {fieldIndex !== 0 && <span>:</span>}
                        <input className={`form-control me-1 mb-2  ${item.validate && `border border-danger`}`}
                            type='text'
                            placeholder={timeItem.label}
                            style={{ width: "54.5px" }}
                            name={`groupDefaultValues[${index}].id`}
                            // value={timeItem?.value}
                            onChange={(e) => {
                                const _time = [...[], ...timeFields]
                                _time[fieldIndex].value = e.target.value
                                let _partialTime: any = null
                                if (currentStudy?.timeFormat === '12 Hrs') {
                                    let _timeArray: string = _time.map((_item: any) => _item.value ? _item.value : 'un').join(':')
                                    _partialTime = _timeArray
                                } else {
                                    _partialTime = _time.map((_item: any) => _item.value ? _item.value : 'un').join(':')
                                }
                                console.log("392....", item, _partialTime, timeItem);
                                setErroeMsg('')
                                setDisableSubmit(false)
                                setFieldValue(`groupDefaultValues[${index}].defaultValue`, _partialTime);
                            }}
                            // value={item.defaultValue}
                        value={timeItem?.value}
                        />
                    </>
                ))}

        </React.Fragment>
    )
}

export default PartialTime;