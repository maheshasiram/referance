import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {  useNavigate, useParams } from "react-router-dom";
import { getFormsDetailsId, getFormsByStudyId } from "../../actions/actions";
// import '../../styles/forms.scss'
import { configDataType } from "../../../../../../actions/actions";
import { Types } from "../../reducer/Types";
import FormBuilderContent from "./components/FormBuilderContent";
import FormBuilderMenu from "./components/FormBuilderMenu";
import KeyboardDoubleArrowLeftIcon from '@mui/icons-material/KeyboardDoubleArrowLeft';
import '../../styles/forms.scss'
// import '../../styles/mixins.scss'
import '../../styles/style'

function Layout() {
  const params = useParams()
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const { formDetails, allFormsList } = useSelector((state: any) => state.forms);
  const { currentStudy } = useSelector((state: any) => state.application)
  const loaded = React.useRef(false);
  const [selectedForm, setSelectedForm] = React.useState(params.id);

  useEffect(() => {
    if (!loaded.current) {
      dispatch(getFormsDetailsId(params.id));
      dispatch(getFormsByStudyId(currentStudy.id));
      dispatch(configDataType('RES_TYP', (data: any) => {
        dispatch({ type: Types.FIELD_RESPONSE_TYPES, payload: data.RES_TYP })
      }))
      dispatch(configDataType('DATA_TYP', (data: any) => {
        dispatch({ type: Types.FIELD_DATA_TYPES, payload: data.DATA_TYP })
      }))
      //for file type field -Akshay
      dispatch(configDataType('UPLOAD_FILE_TYPE', (data: any) => {
        console.log('29...',data)
        dispatch({ type: Types.UPLOAD_FILE_TYPE, payload: data.UPLOAD_FILE_TYPE })
      }))
      dispatch(configDataType('LAY', (data: any) => {
        dispatch({ type: Types.FIELD_RESPONSE_LAYOUTS, payload: data.LAY })
      }))
      loaded.current = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params]);

  const backToForm = () => {
    navigate('/study/forms')
    dispatch({ type: Types.FORM_DETAILS_BY_ID, payload: {} });
  }
  const onformChangeHandler = (e: any) => {
    loaded.current = false;
    setSelectedForm(e.target.value);
    navigate(`../EditForm/${e.target.value}`);
  }

  return (
    <React.Fragment>
      <div className="position-relative" >
        <div className="form-header">
          <div className="form-name">
            <span >{formDetails.formName}</span>
          </div>
          <div className="d-flex align-items-center " >
            { allFormsList.length > 0 && <label className="form-name-label text-secondary mx-1 ">  form : </label>}
            {allFormsList && allFormsList.length > 0 && <div className="me-2">
              <select className=' dropdown-container' value={selectedForm} onChange={onformChangeHandler}>
                {allFormsList.map((item: any) => (
                  <option value={item.id} key={item.id} >{item.formName}</option>
                ))}
              </select>
            </div>}
            <div className="backto-form">
              <span onClick={backToForm}><KeyboardDoubleArrowLeftIcon /> Back To Forms</span>
            </div>
          </div>
        </div>
        <div className="fb-container d-flex">
          <div className={formDetails.formFields &&
            formDetails.formFields.length > 0 ? "left-container" : "left-container noFields"}>
            <FormBuilderContent />
          </div>
          <div className="right-container">
            <FormBuilderMenu currentFormName={formDetails.formName} />
          </div>
        </div>
      </div>
    </React.Fragment>
  )
}
export default Layout