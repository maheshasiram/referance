import React from "react";
import CommonCard from "../../../../../../../common/styleComponents/CommonCard";
import DeleteIcon from '@mui/icons-material/Delete';
import ReplayIcon from '@mui/icons-material/Replay';
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import { Confirm, toastAlert } from "../../../../../../../actions/actions";
import { deleteFields, deleteGroup, getFormsDetailsId, restoreFields, restoreGroup } from "../../../actions/actions";
import GroupLevelMenu from "./groupActivity/GroupLevelMenu";
import AddVariable from "./AddVariable";
import GroupVariable from "./GroupVariable";
import { styled } from '@mui/material/styles';
import ArrowForwardIosSharpIcon from '@mui/icons-material/ArrowForwardIosSharp';
import MuiAccordion, { AccordionProps } from '@mui/material/Accordion';
import MuiAccordionSummary, { AccordionSummaryProps, } from '@mui/material/AccordionSummary';
import MuiAccordionDetails from '@mui/material/AccordionDetails';
import Loader from "../../../../../../../common/loader/Loader";
import CustomToolTip from "../../../../../../../components/CustomToolTip";
import ImportVariables from "./ImportVariables";

const Accordion = styled((props: AccordionProps) => (
  <MuiAccordion disableGutters elevation={0} square {...props} />
))(() => ({

}));

const AccordionSummary = styled((props: AccordionSummaryProps) => (
  <MuiAccordionSummary
    expandIcon={<ArrowForwardIosSharpIcon sx={{ fontSize: '0.8rem' }} />}
    {...props}
  />
))(({ theme }) => ({
  flexDirection: 'row-reverse',
  '& .MuiAccordionSummary-expandIconWrapper.Mui-expanded': {
    transform: 'rotate(90deg)',
  },
  '& .MuiAccordionSummary-content': {
    marginLeft: theme.spacing(1),
  },
}));

const AccordionDetails = styled(MuiAccordionDetails)(({ theme }) => ({
  padding: theme.spacing(2),
  borderBottom: '1px solid rgba(0, 0, 0, .125)',
}));


function FormBuilderContent(props: any) {
  const { formDetails } = useSelector((state: any) => state.forms);
  const [expanded, setExpanded] = React.useState<string | false>('panel');
  const params = useParams()
  const dispatch = useDispatch()
  const { setToastOpen } = props

  const handleChange =
    (panel: string) => (event: React.SyntheticEvent, newExpanded: boolean) => {
      setExpanded(newExpanded ? panel : false);
    };


  const deleteRestoreField = (fieldId: number, type: string) => {
    dispatch(Confirm({
      status: 0,
      message: `${type === 'delete' ? "If you delete this variable associated rules, field level dynamics,derivations and data will be" : "Are you sure you want to"} 
      ${type === 'delete' ? 'Delete ? ' : 'Restore ? '}`,
      onOk: () => {

        dispatch((type === 'delete' ? deleteFields : restoreFields)(fieldId, (response: any) => {
          // dispatch(Alert({
          //   status: 2, message: `Form ${type === 'delete' ? 'deleted ' : 'restored '} successfully`, onOk: () => {
          //   }
          // }))
          console.log('response..........', response);
          if (!(response?.data?.errorMessage)) {
            dispatch(getFormsDetailsId(params.id))
          }
          dispatch(toastAlert({
            status: response?.data?.errorMessage ? 0 : 1,
            open: true,
            // message: `Field ${type === 'delete' ? 'deleted ' : 'restored '} successfully`
            message: response?.data?.errorMessage ? response.data.errorMessage : response.data
          }))
        }))
      }
    }));
  }

  const deleteRestoreGroup = (groupId: any, type: string) => {
    dispatch(Confirm({
      status: 0, message: `Are you sure you want to ${type === 'delete' ? 'Delete ? ' : 'Restore ? '}`,
      onOk: () => {
        dispatch((type === 'delete' ? deleteGroup : restoreGroup)(groupId, (response: any) => {
          // dispatch(Alert({
          //   status: 2, message: `Form ${type === 'delete' ? 'deleted ' : 'restored '} successfully`, onOk: () => {
          dispatch(getFormsDetailsId(params.id))
          //   }
          // }))
          dispatch(toastAlert({
            status: 1,
            open: true,
            message: response.data
            // message: `Form ${type === 'delete' ? 'deleted ' : 'restored '} successfully`
          }))
        }))
      }
    }));
  }

  return (
    <CommonCard>
      {formDetails && formDetails.formName ? <div className="variablesContainer px-3">
        {formDetails.formFields &&
          formDetails.formFields.length > 0 ? formDetails.formFields.map((item: any, index: any) => {
            return (
              <div key={`element-key${index + 1}`} className={item.field ? "element ng-element" : "element"}>
                {
                  item.field ? <div key={index} className="d-flex">
                    <span className={item.field.status ? "flex-grow-1 variableName" : "flex-grow-1 deletedItem"}>{item.field.variableText}{` ( ${item.field.variableId} )`} </span>
                    {item.field.status ? <div className="d-flex align-items-center">
                      <AddVariable params={item.field} type={1} />
                      <span className="px-1" > |</span>
                      <CustomToolTip title='Delete'>
                        <DeleteIcon sx={{ fontSize: 14, opacity: .8 }}
                          className='text-danger mx-1'
                          onClick={() => deleteRestoreField(item.field.id, 'delete')} />
                      </CustomToolTip>
                    </div> :
                      <CustomToolTip title='Restore'><ReplayIcon sx={{ fontSize: 17, opacity: .8 }} className="mx-1" onClick={() => deleteRestoreField(item.field.id, 'restore')} /></CustomToolTip>}
                  </div>
                    :
                    <Accordion expanded={expanded === `panel${index}`} onChange={handleChange(`panel${index}`)} >
                      <AccordionSummary aria-controls={`panel${index}d-content`} id={`panel${index}d-header`} className="element ng-element">
                        <div className={item.group.status ? "flex-grow-1 groupName" : "flex-grow-1 deletedItem"}>{item.group.name}</div>
                        {item.group.status ? <div className="d-flex align-items-center">
                          <span onClick={(e: any) => e.stopPropagation()}> <GroupVariable setToastOpen={setToastOpen} type={1} groupId={item.group.id} /></span>
                          <span className="px-1" > |</span>
                          <span onClick={(e: any) => e.stopPropagation()}>  <CustomToolTip title='Delete Group'>
                            <DeleteIcon sx={{ fontSize: 17, opacity: .8 }}
                              className='text-danger'
                              onClick={() => deleteRestoreGroup(item.group.id, 'delete')} />
                          </CustomToolTip></span>
                          <span className="px-1" > |</span>
                          <span onClick={(e: any) => e.stopPropagation()}><GroupLevelMenu group={item.group} groupId={item.group.id} groupIndex={index} params={params} setToastOpen={setToastOpen} /></span></div> :
                          <span onClick={(e: any) => e.stopPropagation()}><CustomToolTip title='Restore Group'><ReplayIcon sx={{ fontSize: 22, opacity: .8 }} className='text-danger' onClick={() => deleteRestoreGroup(item.group.id, 'restore')} /></CustomToolTip></span>}
                      </AccordionSummary>
                      {item.group && item.group.fields && item.group.fields.length > 0 ?
                        item.group.fields.map((fieldData: any, i: number) => {
                          return (
                            <AccordionDetails key={i} className={item.group.status ? "d-flex element g-element" : "d-flex element g-element deletedGroup"}>
                              <span className={fieldData.status ? "flex-grow-1 variableName m-0" : "flex-grow-1 deletedItem m-0"}> {fieldData.variableText}{` ( ${fieldData?.variableId} )`}</span>
                              {item.group.status ?
                                <div>
                                  {fieldData.status ? <span className='edit-icon'>
                                    <AddVariable type={1} params={fieldData} />
                                    <span className="px-1" > |</span>
                                    <DeleteIcon sx={{ fontSize: 17, opacity: .8 }}
                                      className='text-danger'
                                      onClick={() => deleteRestoreField(fieldData.id, 'delete')} /></span> :
                                    <span><ReplayIcon sx={{ fontSize: 17, opacity: .8 }}
                                      onClick={() => deleteRestoreField(fieldData.id, 'restore')} /></span>}
                                </div> : <div>
                                  <span>-</span>
                                </div>}
                            </AccordionDetails>
                          )
                        }) : <AccordionDetails >
                          <div>
                            Group variables are not available to display
                          </div>
                        </AccordionDetails>}
                    </Accordion>
                }
              </div>
            )
          }) :
          <div className="e-alert-info w-100" role="alert">
            <h6>This form doesn&apos;t have any variables! </h6>
            Please add {/* <a href="">New Varialbe</a> */} <AddVariable params={{ id: 0 }} /> Or {/*<a href="">Import Variables</a>*/}<ImportVariables />
          </div>
        }
      </div> : <Loader />}
    </CommonCard>
  )
}

export default FormBuilderContent;