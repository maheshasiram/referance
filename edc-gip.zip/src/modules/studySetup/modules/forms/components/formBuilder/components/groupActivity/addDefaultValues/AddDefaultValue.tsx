import React, { useState } from "react";
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import CustomDialog from "../../../../../../../../../common/modals/CustomeDialog";
import { useDispatch } from "react-redux";
import { Formik, Form } from 'formik';
import { addDefaultValue, getAllDefaultValues, getFieldsForDefaultValues } from "../../../../../actions/actions";
import ScriptRow from "./ScriptRow";
import { Types } from "../../../../../reducer/Types";
import _ from 'lodash'
import { DefaultValuesSchema } from "../../../../../helpers/Validate";
import { toastAlert } from "../../../../../../../../../actions/actions";
import CustomToolTip from "../../../../../../../../../components/CustomToolTip";

function AddDefaultValue(props: any) {
    const dispatch = useDispatch()
    const [open, setOPen] = React.useState(false);
    const [unscriptedFields, setUnscriptedFields] = useState<any>(null)
    const [erroeMsg, setErroeMsg] = useState('')
    const [selectedField, setSelectedField] = useState<any>('')
    const [disableSubmit, setDisableSubmit] = useState(true);
    const [defaultVariables, setDefaultVariables] = React.useState({
        groupDefaultValues: [],
        variableId: "",
        fieldId: 0,
        fieldDataTypeCode: ''
    });

    React.useEffect(() => {
        setDefaultVariables({
            groupDefaultValues: [],
            variableId: "",
            fieldId: 0,
            fieldDataTypeCode: ''
        });
    }, [])
    const onCloseHandler = () => {
        setOPen(false);
        setSelectedField('')
        setDefaultVariables({
            groupDefaultValues: [],
            variableId: "",
            fieldId: 0,
            fieldDataTypeCode: ''
        })
    }

    const onOpenDefaultValuesModal = () => {
        dispatch(getFieldsForDefaultValues(props.group, (response: any) => {
            setOPen(true)
            dispatch({ type: Types.GET_FIELD_DEFAULT_VALUES, payload: null })
            setUnscriptedFields(response.data)
        }));
        setDisableSubmit(true);
        props.setErroeMsg('');
    }

    const onChangeHanlder = (e: any) => {
        setSelectedField(e.target.value)
        const _field = unscriptedFields.fields.find((i: any) => i.id === parseInt(e.target.value));
        let defaultVariables: any;
        if (e.target.value !== '') {
            defaultVariables = {
                "fieldId": _field.id,
                "groupId": _field.groupId,
                "variableId": _field.variableId,
                "fieldDataTypeCode": _field.datatype.code,
                "fieldResponseType": _field.responseType.code,
                "groupDefaultValues": []
            }

            for (let i = 0; i < unscriptedFields.repeatNumber; i++) {
                defaultVariables.groupDefaultValues.push({
                    "id": 0,
                    "rowId": 0,
                    "defaultValue": '',
                    "readOnly": false,
                    "hide": false,
                    "status": true,
                    "validate": false,
                })
            }
            setErroeMsg('')
        } else {
            defaultVariables = {
                "fieldId": 0,
                "groupId": 0,
                "variableId": '',
                "fieldDataTypeCode": 0,
                "fieldResponseType": 0,
                "groupDefaultValues": []
            }

            setErroeMsg('Please Select Your Variable')
        }
        setDefaultVariables(defaultVariables);
        dispatch({ type: Types.GET_FIELD_DEFAULT_VALUES, payload: defaultVariables })
    }


    const onvalidateHandler = (values: any) => {
        let itemValid = 0
        if (values.variableId !== '') {
            if (values.fieldDataTypeCode === "DATA_TYP_PARTIAL_DATE") {
                let dateValidate = false
                values.groupDefaultValues.map((item: any) => {
                    if ((item.defaultValue && item.defaultValue.trim() !== '' && item.dateValue && item.dateValue.trim() !== '') || (item.readOnly)) {
                        itemValid = itemValid + 1
                    } else {
                        if ((item.defaultValue && item.defaultValue.trim() !== '' && (item.dateValue && (item.dateValue.trim() === '' || !item.dateValue)))) {
                            dateValidate = true
                        }
                    }
                    return null
                })
                if (dateValidate) { itemValid = 0 }
            } else {
                values.groupDefaultValues.map((item: any) => {
                    if ((item.defaultValue && item.defaultValue.trim() !== '') || (item.readOnly)) {
                        itemValid = itemValid + 1
                    }
                    return null
                })
            }
            if (itemValid > 0) {
                setErroeMsg('')
                return true
            } else {
                setErroeMsg('Please enter value in input field or select read only')
                return false
            }
        }
    }

    const onSubmitHandler = (values: any) => {
        const _payload = _.cloneDeep(values)
        const validate = onvalidateHandler(_payload);
        if (validate) {
            // adding row count for the default variable
            values?.groupDefaultValues?.map((item: any, index: number) => _payload.groupDefaultValues[index].rowId = index + 1)

            if (values.fieldDataTypeCode === "DATA_TYP_PARTIAL_DATE") {
                values.groupDefaultValues.map((item: any, index: number) => {
                    if ((item.defaultValue && item.defaultValue.trim() !== '' && item.dateValue && item.dateValue.trim() !== '')) {
                        _payload.groupDefaultValues[index].defaultValue = item.defaultValue + '@' + item.dateValue
                    }
                    return null
                })
            }
            if (values && values.groupDefaultValues.length > 0) {
                dispatch(addDefaultValue(_payload, (_response: any) => {
                    console.log('_response....', _response)
                    if (_response?.data?.status == "error") {
                        dispatch(toastAlert({
                            status: 0,
                            open: true,
                            message: _response?.data?.errorMessage
                          }))
                        // props.setIsToast({ status: 1, message: _response?.data?.errorMessage, open: true })
                    } else {
                        dispatch(getAllDefaultValues(props.group.id, (response: any) => {
                            onCloseHandler();
                            props.setDefaultVariables(response[0]);
                            // dispatch(toastAlert({ status: 1, message: response.data, open: true }))
                            props.setIsToast({ status: 1, message: _response?.data, open: true })
                        }))
                    }
                }))
            }
        }
    }

    return (
        <React.Fragment>
            <div className="main-item"><i>Add Default Variable</i>
            <CustomToolTip title='Add Default Variable'><AddCircleOutlineIcon onClick={onOpenDefaultValuesModal} /></CustomToolTip>
            </div>
            <CustomDialog
                title={'Add Default Values'}
                onClose={onCloseHandler}
                onSubmitHandler={() => { return null }}
                open={open}
                maxWidth="xs"
                padding={true}
                disabled={disableSubmit}
                cssName={'dialog-custom-container addDefaultPopUP'}
                actionType={'Submit'}
                form="add_default_values"
                className='addDefaultPopUP'
            >
                <React.Fragment>
                    <Formik
                        enableReinitialize={true}
                        initialValues={defaultVariables}
                        validationSchema={DefaultValuesSchema(defaultVariables && defaultVariables.fieldDataTypeCode)}
                        onSubmit={(values: any) => {
                            onSubmitHandler(values);
                        }}
                    >
                        {({ errors, touched, values, setFieldValue }) => (
                            <Form id="add_default_values">
                                <div className="default-values-container">
                                    <div className="ig-header">
                                        <label>Form Variables :</label>
                                        <select
                                            className="form-select"
                                            value={selectedField}
                                            onChange={onChangeHanlder}
                                        >
                                            <option value={''}>Select Your Variable</option>
                                            {
                                                unscriptedFields && unscriptedFields.fields &&
                                                unscriptedFields.fields.map((field: any, index: number) => {
                                                    if (field.status && (field.responseType.name === 'text' || field.responseType.name === 'textarea')) {
                                                        return <option value={field.id} key={index}>{field.variableText as string}</option>
                                                    }
                                                    return null
                                                })
                                            }
                                        </select>
                                    </div>
                                    <div>{erroeMsg && <p className="text-danger text-center">{erroeMsg}</p>}</div>
                                    <div className="content-panel add-default-values">
                                        <ScriptRow
                                            id={'default_add'}
                                            errors={errors}
                                            values={values}
                                            setFieldValue={setFieldValue}
                                            touched={touched}
                                            setErroeMsg={setErroeMsg}
                                            setDisableSubmit={setDisableSubmit}
                                            disableSubmit={disableSubmit}
                                        />
                                    </div>
                                </div>
                            </Form>
                        )}
                    </Formik>
                </React.Fragment>
            </CustomDialog>
        </React.Fragment>
    )
}
export default AddDefaultValue