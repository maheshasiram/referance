import React from "react";
import CustomDialog from "../../../../../../../common/modals/CustomeDialog";
import PreviewFormImg from "../../../../../../../common/Assests/Images/PreviewFormImg.png"
import { useSelector } from "react-redux";
import InstructionsHelper from "../../../../../../subjects/modules/subjectsList/components/dynamicForms/helpers/InstructionsHelper";

function PreviewForm(props: any) {
    const [open, setOpen] = React.useState(false);
    const { currentFormName } = props;
    const { formDetails } = useSelector((state: any) => state.forms);
    const onCloseHandler = () => {
        setOpen(false);
    }
    const onClickPreview = () => {
        setOpen(true);
    }
    // console.log('formDetails........', formDetails)
    return (
        <div className="">
            <div className="d-flex" >
                <div className="header ">
                    <span className="title-link"> {currentFormName} Preview</span>
                </div >
                <div className="preview-icon" onClick={onClickPreview}>
                    <img src={PreviewFormImg} alt="" />
                </div>
            </div>
            <CustomDialog
                title={'Preview Form'}
                onClose={onCloseHandler}
                onSubmitHandler={onCloseHandler}
                open={open}
                maxWidth="lg"
                actionType={'Close'}
                form="PreviewForm"
            >
                <div className="preview-form">
                    {formDetails && formDetails.formFields && formDetails.formFields.length > 0 ?
                        formDetails.formFields.map((item: any, index: any) => {
                            <>{console.log("...41", item)}</>
                            if (item.field && item.field.status) {
                                const defaultValue = item.field.defaultValue
                                switch (item && item.field && item.field.responseType && item.field.responseType.name) {
                                    case 'text':
                                        switch (item && item.field && item.field.datatype && item.field.datatype.name) {
                                            case 'date':
                                                return (<React.Fragment>
                                                    <div className="non-groupHeader">{item.field.header && <span className="ms-4">Header:{item.field.header}</span>}</div>
                                                    <div className="nonGrp-Element d-flex align-items-stretch">
                                                        <div className="label-container d-flex justify-content-end align-items-center">
                                                            <label className="preview-label">{item.field.variableText}</label>
                                                        </div>
                                                        <div className="input-container"><input type="date" /></div>
                                                        {item.field.onAirInstruction && <InstructionsHelper title={item.field.onAirInstruction} />}
                                                    </div>
                                                    {item.field.note && <div className="groupNote">
                                                        <span className="me-1">Note:</span>{item.field.note}
                                                    </div>}
                                                </React.Fragment>)
                                            case 'partial date':
                                                return (<React.Fragment>
                                                    <div className="non-groupHeader">{item.field.header && <span className="ms-4">Header:{item.field.header}</span>}</div>
                                                    <div className="nonGrp-Element d-flex align-items-stretch">
                                                        <div className="label-container d-flex justify-content-end align-items-center">
                                                            <label className="preview-label">{item.field.variableText}</label>
                                                        </div>
                                                        <div className="d-flex input-container">
                                                            <select name="select" > <option selected>Select date format</option></select><span className="ms-2"><input type="date" placeholder={item.field.placeholder} /></span>
                                                        </div>
                                                        {item.field.onAirInstruction && <InstructionsHelper title={item.field.onAirInstruction} />}
                                                    </div>
                                                    {item.field.note && <div className="groupNote">
                                                        <span className="me-1">Note:</span>{item.field.note}
                                                    </div>}
                                                </React.Fragment>)
                                            case 'time':
                                                return (<React.Fragment>
                                                    <div className="non-groupHeader">{item.field.header && <span className="ms-4">Header:{item.field.header}</span>}</div>
                                                    <div className="nonGrp-Element d-flex align-items-stretch">
                                                        <div className="label-container d-flex justify-content-end align-items-center">
                                                            <label className="preview-label">{item.field.variableText}</label>
                                                        </div>
                                                        <div className="input-container"><input type="time" value={defaultValue} id="appt" name="appt" /></div>
                                                        {item.field.onAirInstruction && <InstructionsHelper title={item.field.onAirInstruction} />}
                                                    </div>
                                                    {item.field.note && <div className="groupNote">
                                                        <span className="me-1">Note:</span>{item.field.note}
                                                    </div>}
                                                </React.Fragment>)
                                            default:
                                                return (<React.Fragment>
                                                    <div className="non-groupHeader">{item.field.header && <span className="ms-4">Header:{item.field.header}</span>}</div>
                                                    <div className="nonGrp-Element d-flex align-items-stretch">
                                                        <div className="label-container d-flex justify-content-end align-items-center">
                                                            <label className="preview-label">{item.field.variableText}</label>
                                                        </div>
                                                        <div className="input-container"> <input type="text" value={defaultValue} placeholder={item.field.placeholder} /></div>
                                                        {item.field.onAirInstruction && <InstructionsHelper title={item.field.onAirInstruction} />}
                                                    </div>
                                                    {item.field.note && <div className="groupNote">
                                                        <span className="me-1">Note:</span>{item.field.note}
                                                    </div>}
                                                </React.Fragment>)
                                        }

                                    case 'textarea':
                                        return (<React.Fragment>
                                            <div className="non-groupHeader">{item.field.header && <span className="ms-4">Header:{item.field.header}</span>}</div>
                                            <div className="nonGrp-Element d-flex align-items-stretch">
                                                <div className=" label-container d-flex justify-content-end align-items-center">
                                                    <label className="preview-label">{item.field.variableText}</label>
                                                </div>
                                                <div className="input-container"><textarea name="textarea" placeholder={item.field.placeholder} /></div>
                                                {item.field.onAirInstruction && <InstructionsHelper title={item.field.onAirInstruction} />}
                                            </div>
                                            {item.field.note && <div className="groupNote">
                                                <span className="me-1">Note:</span>{item.field.note}
                                            </div>}
                                        </React.Fragment>)
                                    case 'radio':
                                        return (<React.Fragment>
                                            <div className="non-groupHeader">{item.field.header && <span className="ms-4">Header:{item.field.header}</span>}</div>
                                            <div className="nonGrp-Element d-flex align-items-stretch">
                                                <div className="label-container d-flex justify-content-end align-items-center">
                                                    <label className="preview-label">{item.field.variableText}</label>
                                                </div>
                                                <div className={`${item.field.layoutId && item.field.layoutId.name === "vertical" ? "" : "input-container"} `}>
                                                    {item.field.responseOptions && item.field.responseOptions.map((responseData: any, index: any) => {
                                                        return (
                                                            <div className="d-flex justify-content-center align-items-center ms-2" key={index}>
                                                                <input type="radio" /><span className="me-2">{responseData.response}</span>
                                                            </div>
                                                        )
                                                    })}
                                                </div>
                                                {item.field.onAirInstruction && <InstructionsHelper title={item.field.onAirInstruction} />}
                                            </div>
                                            {item.field.note && <div className="groupNote">
                                                <span className="me-1">Note:</span>{item.field.note}
                                            </div>}
                                        </React.Fragment>)
                                    case 'checkbox':
                                        return (<React.Fragment>
                                            <div className="non-groupHeader">{item.field.header && <span className="ms-4">Header:{item.field.header}</span>}</div>
                                            <div className="nonGrp-Element d-flex align-items-stretch">
                                                <div className="label-container d-flex justify-content-end align-items-center">
                                                    <label className="preview-label">{item.field.variableText}</label>
                                                </div>
                                                <div className={`${item.field.layoutId && item.field.layoutId.name === "vertical" ? "" : "input-container"} `}>
                                                    {item.field.responseOptions && item.field.responseOptions.map((responseData: any, index: any) => {
                                                        return (
                                                            <div className="d-flex justify-content-center align-items-center ms-2" key={index} >
                                                                <input type="checkbox" />
                                                                <span className="me-2">{responseData.response}</span>
                                                            </div>
                                                        )
                                                    })}
                                                </div>
                                                {item.field.onAirInstruction && <InstructionsHelper title={item.field.onAirInstruction} />}
                                            </div>
                                            {item.field.note && <div className="groupNote">
                                                <span className="me-1">Note:</span>{item.field.note}
                                            </div>}
                                        </React.Fragment>)
                                    case 'single-select':
                                        return (<React.Fragment>
                                            <div className="non-groupHeader">{item.field.header && <span className="ms-4">Header:{item.field.header}</span>}</div>
                                            <div className="nonGrp-Element d-flex align-items-stretch">
                                                <div className="label-container d-flex justify-content-end align-items-center">
                                                    <label className="preview-label">{item.field.variableText}</label>
                                                </div>
                                                <div className="input-container"><select name="select" > </select></div>
                                                {item.field.onAirInstruction && <InstructionsHelper title={item.field.onAirInstruction} />}
                                            </div>
                                            {item.field.note && <div className="groupNote">
                                                <span className="me-1">Note:</span>{item.field.note}
                                            </div>}
                                        </React.Fragment>)
                                    case 'multi-select':
                                        return (<React.Fragment>
                                            <div className="non-groupHeader">{item.field.header && <span className="ms-4">Header:{item.field.header}</span>}</div>
                                            <div className="nonGrp-Element d-flex align-items-stretch">
                                                <div className="label-container d-flex justify-content-end align-items-center">
                                                    <label className="preview-label">{item.field.variableText}</label>
                                                </div>
                                                <div className="input-container"><select name="select" > </select></div>
                                                {item.field.onAirInstruction && <InstructionsHelper title={item.field.onAirInstruction} />}
                                            </div>
                                            {item.field.note && <div className="groupNote">
                                                <span className="me-1">Note:</span>{item.field.note}
                                            </div>}
                                        </React.Fragment>)
                                }
                            }
                            else if (item.group && item.group.status) {
                                return (
                                    <div key={index}>
                                        {<div className="groupHeader">
                                            {item.group.name && <span className="me-2">Group Name : {item.group.name}</span>}
                                            {item.group.header && <span className="me-1">Header:{item.group.header}</span>}
                                        </div>}
                                        <div className="d-flex flex-wrap group">
                                            <div className="container text-center">
                                                <div className="d-flex group-container">
                                                    {item.group && item.group.fields &&
                                                        item.group.fields.map((groupData: any) => {
                                                            { console.log("170....", groupData); }
                                                            const defaultValue = groupData.defaultValue
                                                            switch (groupData && groupData.status && groupData.responseType && groupData.responseType.name) {
                                                                case 'text':
                                                                    switch (groupData && groupData.datatype && groupData.datatype.name) {
                                                                        case 'date':
                                                                            return (<React.Fragment>
                                                                                <div className="Group-element">
                                                                                    <label >{groupData.variableText}</label>
                                                                                    <div className="d-flex">
                                                                                        <input type="date" className="group-field" />
                                                                                        {groupData.onAirInstruction && <InstructionsHelper title={groupData.onAirInstruction} />}
                                                                                    </div>
                                                                                </div>
                                                                            </React.Fragment>)
                                                                        case 'partial date':
                                                                            return (<React.Fragment>
                                                                                <div className="Group-element">
                                                                                    <label >{groupData.variableText}</label>
                                                                                    <div className="d-flex">
                                                                                        <select name="select" className="group-field"><option selected>Select date format</option> </select>
                                                                                        <div className="d-flex">
                                                                                            <input type="date" className="group-field" placeholder={groupData.placeholder} />
                                                                                            {groupData.onAirInstruction && <InstructionsHelper title={groupData.onAirInstruction} />}
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </React.Fragment>)
                                                                        case 'time':
                                                                            return (<React.Fragment>
                                                                                <div className="Group-element">
                                                                                    <label >{groupData.variableText}</label>
                                                                                    <div className="d-flex"><input type="time" className="group-field" value={defaultValue} />
                                                                                        {groupData.onAirInstruction && <InstructionsHelper title={groupData.onAirInstruction} />}</div>
                                                                                </div>
                                                                            </React.Fragment>)
                                                                        default:
                                                                            return (<React.Fragment>
                                                                                <div className="Group-element">
                                                                                    <label>{groupData.variableText}</label>
                                                                                    <div className="d-flex"><input type="text" className="group-field" value={defaultValue} placeholder={groupData.placeholder} />
                                                                                        {groupData.onAirInstruction && <InstructionsHelper title={groupData.onAirInstruction} />}
                                                                                    </div>
                                                                                </div>
                                                                                {/* <span>
                                                                                    {groupData.onAirInstruction && <InstructionsHelper title={groupData.onAirInstruction} />}
                                                                                </span> */}
                                                                            </React.Fragment>)
                                                                    }
                                                                case 'textarea':
                                                                    return (<React.Fragment>
                                                                        <div className="Group-element ">
                                                                            <label>{groupData.variableText}</label> <br />
                                                                            <div className="d-flex">
                                                                                <textarea className="group-field" name="textarea" placeholder={groupData.placeholder} />
                                                                                {groupData.onAirInstruction && <InstructionsHelper title={groupData.onAirInstruction} />}
                                                                            </div>
                                                                        </div>
                                                                    </React.Fragment>)
                                                                case 'radio': return (<React.Fragment>
                                                                    <div className="Group-element">
                                                                        <label>{groupData.variableText}</label><br />
                                                                        <div className={`${groupData.layoutId && groupData.layoutId.name === "vertical" ? "" : "d-flex"} `}>
                                                                            {groupData.responseOptions && groupData.responseOptions.map((responseData: any, index: any) => {
                                                                                return (
                                                                                    <div className="checkbox-radio-container d-flex justify-content-center align-items-center" key={index}>
                                                                                        <div className="d-flex">
                                                                                            <span className="ms-2">{responseData.response}</span> <input type="radio" className="group-field" />
                                                                                            {groupData.onAirInstruction && <InstructionsHelper title={groupData.onAirInstruction} />}
                                                                                        </div>
                                                                                    </div>)
                                                                            })}
                                                                        </div>
                                                                    </div>
                                                                </React.Fragment>)
                                                                case 'checkbox':
                                                                    return (<React.Fragment>
                                                                        <div className="Group-element">
                                                                            <label>{groupData.variableText}</label><br />
                                                                            <div className={`${groupData.layoutId && groupData.layoutId.name === "vertical" ? "" : "d-flex"} `}>
                                                                                {groupData.responseOptions && groupData.responseOptions.map((responseData: any, index: any) => {
                                                                                    return (
                                                                                        <div className="checkbox-radio-container d-flex justify-content-center align-items-center" key={index}>
                                                                                            <div className="d-flex">
                                                                                                <span className="ms-1">{responseData.response}</span>
                                                                                                <input type="checkbox" className="group-field" />
                                                                                                {groupData.onAirInstruction && <InstructionsHelper title={groupData.onAirInstruction} />}
                                                                                            </div>
                                                                                        </div>)

                                                                                })}
                                                                            </div>
                                                                        </div>
                                                                    </React.Fragment>)
                                                                case 'single-select':
                                                                    return (<React.Fragment>
                                                                        <div className="Group-element">
                                                                            <label>{groupData.variableText}</label>
                                                                            <div className="d-flex">
                                                                                <select name="select" className="group-field"> </select>
                                                                                {groupData.onAirInstruction && <InstructionsHelper title={groupData.onAirInstruction} />}
                                                                            </div>
                                                                        </div>
                                                                    </React.Fragment>)
                                                                case 'multi-select':
                                                                    return (<React.Fragment>
                                                                        <div className="Group-element">
                                                                            <label>{groupData.variableText}</label>
                                                                            <div className="d-flex">
                                                                                <select name="select" className="group-field"> </select>
                                                                                {groupData.onAirInstruction && <InstructionsHelper title={groupData.onAirInstruction} />}
                                                                            </div>
                                                                        </div>
                                                                    </React.Fragment>)
                                                            }
                                                            return null
                                                        })}
                                                </div>
                                            </div>
                                        </div>
                                        {item.group.note && <div className="groupNote">
                                            <span className="me-1">Note:</span>{item.group.note}
                                        </div>}
                                    </div>)
                            }
                            return null
                        }) : <div className="d-flex justify-content-center align-items-center mt-2">
                            <span className="NoFields">Fields are not available to show</span>
                        </div>}
                </div>
            </CustomDialog>
        </div>
    )
}
export default PreviewForm