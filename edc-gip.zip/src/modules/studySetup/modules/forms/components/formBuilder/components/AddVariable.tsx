import React, { useState } from "react";
import CustomDialog from "../../../../../../../common/modals/CustomeDialog";
import { Formik, Form, Field, ErrorMessage, FieldArray } from 'formik';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import RemoveCircleIcon from '@mui/icons-material/RemoveCircle';
import { useDispatch, useSelector } from "react-redux";
import { ResponseTypes } from "../../../helpers/responseTypes";
import EditIcon from '@mui/icons-material/Edit';
import { addUpdateVariable, getFormsDetailsId, getFieldDetailsById, fetchAllGroupsByFormId, fetchAllUnits, fetchFieldsFormat } from "../../../actions/actions";
import { Variable } from "../../../helpers/form-modal";
import { variableSchema } from "../../../helpers/Validate";
import { Alert, Confirm } from "../../../../../../../actions/actions";
import { messages } from "../../../../../constants/messages";
import AddVariableImg from "../../../../../../../common/Assests/Images/AddVariableImg.png"
import { useParams } from "react-router-dom";
import { Types } from "../../../reducer/Types";
// import AddIcon from '@mui/icons-material/Add';
import CustomToolTip from "../../../../../../../components/CustomToolTip";
import UnitDialog from "./UnitDialog";

function AddVariable(props: any) {
  const dispatch = useDispatch();
  const { variableDetails, fieldDataTypes,
    fieldResponseTypes, layoutTypes, allGroups, formDetails, allUnits, fieldFormat, uploadFileType } = useSelector((state: any) => state.forms);
  const { configCodes } = useSelector((state: any) => state.application);

  const routeParams = useParams();
  const [responseTypeVal, setResponseTypeVal] = useState('');
  const [dataTypeValue, setDataTypeValue] = useState('');
  const [variableData, setVariableData] = useState('');
  const [open, setOpen] = useState(false);
  const [btnDisable, setBtnDisable] = useState(false);
  const [reasonBtnDisable, setReasonBtnDisable] = useState(true)
  const [error, setError] = useState("");
  const [openUnit, setOpenUnit] = useState(false)
  const [openReason, setOpenReason] = useState(false)
  const [addRemoveMsg, setaddRemoveMsg] = useState("");

  const onClickHandler = () => {
    setBtnDisable(true);
    if (props.params && props.params.id > 0) {
      dispatch(getFieldDetailsById(props.params.id, (data: any) => {
        setResponseTypeVal(data.responseType.code);
        setDataTypeValue(data.datatype.code)
      }))
    } else {
      dispatch({ type: Types.INITIALIAZE_VARIABLED })
    }
    dispatch(fetchAllGroupsByFormId(routeParams.id));
    dispatch(fetchAllUnits())
    dispatch(fetchFieldsFormat())
    setOpen(true);
    setError("");
  }

  const onCloseHandler = () => {
    setOpen(false);
    dispatch({ type: Types.INITIALIAZE_VARIABLED })
  }
  const onChangeDataType = (e: any, type: any, setFieldValue: any, values: any) => {

    if (type === 'dataType') {
      // let _val = fieldDataTypes.find((item: any) => item.name === e.target.value)
      const _val = fieldDataTypes.find((item: any) => item.code === e.target.value)
      console.log('fieldDataTypes....', fieldDataTypes, _val, e.target.value)
      setFieldValue("responseOptions", [{ id: 0, response: "", status: true }]);
      setFieldValue('datatype', _val ? _val : Variable.datatype)
      setFieldValue('defaultValue', "");
      if (variableDetails.id > 0) {
        // setError('If you update the response options respected variable Filed Level Dynamics and Rules will be updated');
        setError('If you update the Data type respected variable Filed Level Dynamics and Rules will be updated');
      }
    } else {
      setResponseTypeVal(e.target.value)
      const _val = fieldDataTypes.find((item: any) => e.target.value === configCodes?.textarea ? item.code === configCodes?.string : e.target.value === 'RES_TYP_FILE' ? item.code === configCodes?.file : '')
      // console.log('73.......',e.target.value,values,_val,Variable.datatype)
      setFieldValue('datatype', _val ? _val : Variable.datatype);
      setFieldValue('readOnly', false);
      setFieldValue('layoutId', "");
      setFieldValue('defaultValue', "");
    }
    setBtnDisable(false);
    setaddRemoveMsg("");

  }

  const validateResponseOptions = (values: any) => {
    let isDuplicate;
    let isEmpty = [];
    if (values.responseOptions) {
      const valueArr = values.responseOptions.map(function (item: any) { return item.response });
      isEmpty = values.responseOptions.filter((item: any) => item.response === "");
      isDuplicate = valueArr.some(function (item: any, idx: number) {
        return valueArr.indexOf(item) !== idx
      });
    }
    if (isDuplicate) {
      setaddRemoveMsg("Response option text can't be same");
      return false;
    } else if (isEmpty.length > 0) {
      setaddRemoveMsg("Response option text can't be empty");
      return false;
    } else {
      return true;
    }
  }
  const validateVariableText = (e: any) => {

    let error;
    if (formDetails.formName === e || formDetails.exportName === e) {
      error = formDetails.formName === e ? 'Variable Text & Form name should not be same' :
        "Variable Text & Export Name should not be same"
    }
    return error;
  }
  const validateVariableId = (e: any) => {
    console.log('106...', e, formDetails.formName)
    let error;
    if ((formDetails.formName)?.toUpperCase() === e?.toUpperCase() || (formDetails.exportName)?.toUpperCase() === e?.toUpperCase()) {
      error = formDetails.formName === e ? 'Variable Id & Form name should not be same' :
        "Variable ID & Export Name should not be same"
    }
    return error;
  }
  const onResetHandler = () => {
    dispatch({ type: Types.INITIALIAZE_VARIABLED })
  }


  const validateMaxValue = (value: any, values: any) => {
    let error;
    if (value && value < values.minValueLength) {
      error = "Max value must be greater than min value"
    }
    return error;
  }


  const onSubmitHandler = (values: any) => {

    if (variableDetails.id !== 0 && (variableDetails.responseType.name !== values.responseType.name || variableDetails.datatype.name !== values.datatype.name) && !values.reason) {
      setOpenReason(true)
    } else {
      const _responseType = values.responseType.name
      const validate = validateResponseOptions(values);
      if (validate || _responseType === 'text' || _responseType === 'textarea' || _responseType === 'file') {
        const _values = {
          ...values, layoutId: ((values.layoutId && values.layoutId.id) ? values.layoutId : null),
          formId: routeParams.id, groupId: values.groupId ? values.groupId : null,
          responseOptions: (values?.responseOptions && values?.responseOptions[0]?.response) ? values?.responseOptions : null,
          responseOptionExist: (values?.responseOptions && values?.responseOptions[0]?.response) ? true : false,
          // isValueUpperCase: values?.isValueUpperCase === '' ? false : values?.isValueUpperCase
        }
        console.log('154...', _values)

        dispatch(addUpdateVariable(_values, (data: any) => {
          if (data.status !== 'error') {
            onCloseHandler();
            dispatch(getFormsDetailsId(routeParams.id));
            (dispatch as any)((_values.id === 0 ? Confirm : Alert)({
              status: 2, message: (_values.id > 0 ?
                messages.forms.updateVariable : messages.forms.addVariable),
              onOk: () => {
                _values.id === 0 ? onClickHandler() : onCloseHandler();
              }
            }));
          } else {
            setError(data.errorMessage);
          }
        }))
      }
    }
  }
  const handleUnitDialog = (groupId: any) => {
    !groupId && setOpenUnit(true)
  }
  const handleReasonSubmit = (values: any) => {
    console.log(values, "eslint")
    setOpenReason(false)
  }
  const onReasonCloseHandler = (values: any) => {
    values.responseType = variableDetails.responseType
    values.datatype = variableDetails.datatype
    if (variableDetails.responseType.name === 'radio' || variableDetails.responseType.name === 'checkbox' || variableDetails.responseType.name === 'single-select' || variableDetails.responseType.name === 'multi-select') {
      values.responseOptions = variableDetails.responseOptions
    }
    values.reason = ''
    setOpenReason(false)
  }

  const onDisableMaxMinFld = (values: any) => {
    console.log("...67", values);
    if ((values.responseType.code === configCodes?.text && values.datatype.code === configCodes?.string)
      || (values.responseType.code === configCodes?.text && values.datatype.code === configCodes?.integer)
      || (values.responseType.code === configCodes?.text && values.datatype.code === configCodes?.real)
      || (values.responseType.code === configCodes?.textarea && values.datatype.code === configCodes?.string)) {
      return false
    } else {
      return true
    }
  }
  return (
    <React.Fragment>
      {(props.type === 1) ?
        (<CustomToolTip title='Edit'>
          <EditIcon
            onClick={() => onClickHandler()}
            sx={{ fontSize: 14, opacity: .8 }} className="" />
        </CustomToolTip>) : (props.type === 0) ?
          (<li className="list-group-item" onClick={() => onClickHandler()} >
            <span className="icons"><img src={AddVariableImg} alt="" /></span>Add Variable</li>) :
          <a href="#/" onClick={() => onClickHandler()}>New Variable</a>
      }

      <CustomDialog
        title={variableDetails.id === 0 ? "Add Variable" : "Update Variable"}
        onClose={onCloseHandler}
        onSubmitHandler={() => { return null }}
        open={open}
        form={variableDetails.id === 0 ? "addVariable" : "editVariable"}
        disabled={btnDisable}
        onResetHandler={variableDetails.id === 0 ? () => onResetHandler() : null}
        actionType={variableDetails.id === 0 ? 'Submit' : 'Update'}
      >
        <Formik
          enableReinitialize={true}
          initialValues={variableDetails}
          validationSchema={variableSchema(responseTypeVal, variableData, dataTypeValue)}
          onSubmit={(values) => onSubmitHandler(values)}
        >
          {({ errors, touched, values, setFieldTouched, setFieldValue }: any) => (

            <Form id={variableDetails.id !== 0 ? "editVariable" : "addVariable"}>
              <div className="d-flex justify-content-center">

                {error ? <p className='text-danger'>{error}</p> : <span>&nbsp;</span>}
              </div>
              <div className='d-flex'>
                <div className="addVarWidth w-75">
                  <div className={values.responseType.code === configCodes?.radio || values.responseType.code === configCodes?.checkbox ||
                    values.responseType.code === configCodes?.['single-select'] || values.responseType.code === configCodes?.['multi-select'] ?
                    'p-0' : "container p-0"} id="div-addVariable">
                    <div className=" row">
                      <div className='col-12 col-md-4'>
                        <label htmlFor="text-variableId"> Variable Name: <span className="text-danger">*</span> </label>
                        <div className="align-items-center">
                          <Field
                            className="form-control form-control-lg mt-1"
                            name="variableId"
                            value={values.variableId?.toUpperCase()}
                            id='text-variableId'
                            placeholder="Enter variable name"
                            // disabled={variableDetails.id !== 0 ? true : false}
                            // validate={(e: any) => validateVariableId(e)}
                            onChange={(e: any) => {
                              setFieldTouched('variableId', true)
                              setBtnDisable(false);
                              setFieldValue("variableId", e.target.value.toUpperCase());
                              setError('');
                            }}
                            onKeyPress={(e: any) => {
                              if (e.target.value.length > 7) {
                                e.preventDefault();
                              }
                            }}
                          />
                          {errors.variableId && touched.variableId ? <span className='text-danger'> <ErrorMessage name={`variableId`} /> </span> : <span>&nbsp;</span>}
                        </div>
                      </div>
                      <div className=' col-12 col-md-4'>
                        {/* <label htmlFor="text-description"> Description Label: <span className="text-danger">*</span></label>
                        <div className="align-items-center">
                          <Field
                            className="form-control form-control-lg mt-1"
                            name="description"
                            value={values.description}
                            id='text-description'
                            placeholder="Enter Description Label"
                            disabled={variableDetails.id !== 0 ? true : false}
                            onChange={(e: any) => {
                              if ((e.target.value.length <= 1 && !e.target.value.includes(' ')) || e.target.value.length > 1 && !e.target.value.includes('  ')) {
                                setBtnDisable(false);
                                setFieldValue('description', e.target.value)
                              }
                            }}
                          />
                          {errors.description && touched.description ? <span className='text-danger'> <ErrorMessage name={`description`} /> </span> : <span>&nbsp;</span>}
                        </div> */}
                        <>
                          {console.log('276...', values, errors)}
                        </>
                        <label htmlFor="text-onAirInstruction"> On Air Instructions: </label>
                        <Field
                          className="form-control form-control-lg mt-1 "
                          name="onAirInstruction"
                          value={values.onAirInstruction}
                          id='text-onAirInstruction'
                          placeholder="Enter instructions"
                          onChange={(e: any) => {
                            if ((e.target.value.length <= 1 && !e.target.value.includes(' ')) || (e.target.value.length > 1 && !e.target.value.includes('  '))) {
                              setBtnDisable(false); setFieldValue('onAirInstruction', e.target.value)
                            }
                          }}
                        />
                      </div>
                      <div className=' col-12 col-md-4'>
                        <label htmlFor="text-header"> Header: </label>
                        <Field
                          className="form-control form-control-lg mt-1"
                          name="header"
                          value={values.header}
                          id='text-header'
                          placeholder="Enter header"
                          disabled={!values.groupId ? false : true}
                          onChange={(e: any) => {
                            if ((e.target.value.length <= 1 && !e.target.value.includes(' ')) || (e.target.value.length > 1 && !e.target.value.includes('  '))) {
                              setBtnDisable(false); setFieldValue("header", e.target.value)
                            }
                          }}
                        />
                      </div>
                    </div>
                    <div className="row">
                      <div className='col-12 col-md-4'>
                        <label htmlFor="text-variableText"> Variable Text: <span className="text-danger">*</span></label>
                        <div className="align-items-center">
                          <Field
                            className="form-control form-control-lg mt-1"
                            as="textarea"
                            rows="4"
                            name="variableText"
                            value={values.variableText}
                            id='text-variableText'
                            placeholder="Enter variable text"
                            validate={(e: any) => validateVariableText(e)}
                            onChange={(e: any) => {
                              if ((e.target.value.length <= 1 && !e.target.value.includes(' ')) || (e.target.value.length > 1 && !e.target.value.includes('  '))) {
                                setFieldTouched('variableText', true)
                                setBtnDisable(false); setFieldValue("variableText", e.target.value)
                              }
                            }}
                          />
                          {errors.variableText && touched.variableText ? <span className='text-danger'> <ErrorMessage name={`variableText`} /> </span> : <span>&nbsp;</span>}
                        </div>
                      </div>

                      <div className='col-12 col-md-4'>
                        <div className="row ms-0">
                          <div className='col-12 p-0 col-md-12'>
                            <label htmlFor="text-note"> Note: </label>
                            <Field
                              className="form-control form-control-lg mt-1"
                              as="textarea"
                              rows="1"
                              name="note"
                              value={values.note}
                              id='text-note'
                              placeholder="Enter note"
                              disabled={!values.groupId ? false : true}
                              onChange={(e: any) => {
                                if ((e.target.value.length <= 1 && !e.target.value.includes(' ')) || (e.target.value.length > 1 && !e.target.value.includes('  '))) {
                                  setBtnDisable(false); setFieldValue('note', e.target.value)
                                }
                              }}
                            />
                          </div>
                          <label htmlFor="text-groupId" className="p-0">Groups: </label>
                          <Field
                            as="select"
                            className="form-select form-control mt-1"
                            name="groupId"
                            value={values.groupId ? values.groupId : ''}
                            id='text-groupId'
                            disabled={variableDetails.id !== 0 ? true : false}
                            onChange={(e: any) => {
                              setBtnDisable(false);
                              setFieldValue('groupId', e.target.value ? e.target.value : '');
                              setFieldValue('readOnly', false);
                              setFieldValue('defaultValue', "");
                              setFieldValue('units', "");
                              setFieldValue('note', '');
                              setFieldValue('header', '')
                            }}
                          >
                            <option value="">Select Group</option>
                            {allGroups != null && allGroups.length > 0 && allGroups.map((item: any, index: any) => (
                              <option key={index} value={item.id} >{item.name}</option>
                            ))}
                          </Field>
                        </div>
                      </div>
                      <div className='  col-12 col-md-4'>
                        <label htmlFor="text-questionNumber">Question Number: </label>
                        <Field
                          type="number"
                          className="form-control form-control-lg mt-1"
                          name="questionNumber"
                          min="1"
                          value={values.questionNumber ? values.questionNumber : ""}
                          id='text-questionNumber'
                          placeholder="Enter question number"
                          onKeyPress={(e: any) => {
                            if (e.key === "-" || e.key === "+" || e.key === "e" || e.key === "." || e.key === "0") {
                              e.preventDefault();
                            }
                          }}
                          onChange={(e: any) => { setBtnDisable(false); setFieldValue('questionNumber', e.target.value) }}
                        />
                        {<div className="row mt-2 ms-0">
                          <div className=' col-12 ps-0 col-md-12'>
                            <label htmlFor="textunits"> Units: {(values?.datatype?.code === configCodes?.integer || values?.datatype?.code === configCodes?.real) && !values.groupId ?
                              <CustomToolTip title='add units'>
                                <AddCircleIcon color="primary"
                                  onClick={() => handleUnitDialog(values.groupId)}
                                  sx={{ fontSize: '16px', cursor: 'pointer' }}
                                  className={(values?.datatype?.code === configCodes?.integer || values?.datatype?.code === configCodes?.real) ? "" : 'add-unit-disabled'}
                                />
                              </CustomToolTip>
                              : ""}
                            </label>
                            <Field
                              as="select"
                              className="form-select form-control form-control-lg mt-1"
                              name="units"
                              value={values.units}
                              id='sel-responseType'
                              disabled={(values?.datatype?.code === configCodes?.integer || values?.datatype?.code === configCodes?.real) ? false : true}
                              // disabled={variableDetails.id !== 0 ? true : false}
                              onChange={(e: any) => {
                                if ((e.target.value.length <= 1 && !e.target.value.includes(' ')) || (e.target.value.length > 1 && !e.target.value.includes('  '))) {
                                  setBtnDisable(false); setFieldValue('units', e.target.value)
                                }
                              }}
                            >
                              <option value="" id="sel-opt-0">Select Units</option>

                              {allUnits != null && allUnits.length > 0 && allUnits && allUnits.map((item: any, index: any) => {
                                return <option key={index} value={item.units} id="sel-optrestype-1">{item.units}</option>
                              })}
                            </Field>
                          </div>
                        </div>}
                      </div>

                    </div>

                    <div className=" row">
                      <div className='col-12 col-md-4'>
                        <label htmlFor="sel-responseType">Response Type:
                          <span className="text-danger">*</span></label>
                        <div className="align-items-center">
                          <Field
                            as="select"
                            className="form-select form-control form-control-lg mt-1"
                            name="responseType.code"
                            value={values.responseType.code}
                            id='sel-responseType'
                            // disabled={variableDetails.id !== 0 ? true : false}
                            onChange={(e: any) => {
                              setFieldValue('placeholder', '')
                              setFieldValue('units', "");
                              setFieldValue('minValueLength', '')
                              setFieldValue('maxValueLength', '')
                              setFieldValue("uploadFileType", Variable.uploadFileType);
                              onChangeDataType(e, 'resType', setFieldValue, values);
                              const _val = fieldResponseTypes.find((item: any) => item.code === e.target.value);
                              setFieldValue("responseType", _val ? _val : Variable.responseType);
                            }}
                          >
                            <option value="" id="sel-opt-0">Select Response Type</option>
                            {fieldResponseTypes.map((item: any, index: any) => {
                              return <option key={index} value={item.code} id="sel-optrestype-1">{item.name}</option>
                            })}

                          </Field>
                          {errors.responseType && touched.responseType ? <span className='text-danger'> <ErrorMessage name={`responseType.name`} /> </span> : <span>&nbsp;</span>}
                        </div>
                      </div>
                      <div className='col-12 col-md-4 '>
                        <label htmlFor="sel-datatype">Data Type: <span className="text-danger">*</span> </label>
                        <div className="align-items-center">
                          <Field
                            as="select"
                            className="form-select form-control form-control-lg mt-1"
                            name="datatype.code"
                            value={values.datatype.code}
                            id='sel-datatype'
                            disabled={(values.responseType.name === '' ||
                              values.responseType.code === configCodes?.textarea
                              || values.responseType.code === "RES_TYP_FILE") ? true : false}
                            onChange={(e: any) => {
                              setFieldValue('readOnly', false)
                              setFieldValue('spellCheck', false)
                              setFieldValue('variableFieldFormat', Variable.variableFieldFormat)
                              setFieldValue('units', "");
                              setFieldValue('minValueLength', '')
                              setFieldValue('maxValueLength', '')
                              setDataTypeValue(e.target.value)
                              onChangeDataType(e, 'dataType', setFieldValue, values);

                            }}
                          >
                            {ResponseTypes[values.responseType.name] &&
                              ResponseTypes[values.responseType.name].map((item: any, index: any) => {
                                return <option key={index} value={item.value} id="sel-optrestype-1">{item.text}</option>
                              })}
                          </Field>
                          {errors.datatype && touched.datatype && !values.datatype.name ? <span className='text-danger'> <ErrorMessage name={`datatype.name`} /> </span> : <span>&nbsp;</span>}
                        </div>
                      </div>

                      <div className='col-12 col-md-4'>
                        <label>Min value length :</label>
                        <Field
                          type={"number"}
                          min="1"
                          className="form-control form-control-lg"
                          name="minValueLength"
                          value={values.minValueLength}
                          id='minLength'
                          max="100"
                          disabled={onDisableMaxMinFld(values)}
                          placeholder="Enter min length value"
                          onKeyPress={(e: any) => {
                            if (e.key === "-" || e.key === "+" || e.key === "e" || e.key === ".") {
                              e.preventDefault();
                            }
                          }}
                          onChange={(e: any) => {
                            if (parseInt(e.target.value) === 0) {
                              setFieldValue('minValueLength', '')
                            }
                            else {
                              setFieldValue('minValueLength', parseInt(e.target.value))
                            }
                            setBtnDisable(false);
                          }
                          }
                        />
                      </div>
                    </div>
                    <div className="row">

                      <div className="col-12 col-md-4">
                        <label>Max value length :</label>
                        <Field
                          type={"number"}
                          className="form-control form-control-lg"
                          name="maxValueLength"
                          value={values.maxValueLength}
                          id='maxLength'
                          placeholder="Enter max length value"
                          disabled={onDisableMaxMinFld(values)}
                          // disabled={(((values.responseType.code === configCodes?.text && (values.datatype.name !== "string" || values.datatype.name !== "integer" || values.datatype.name !== "real")))) ? true : false}
                          min="1"
                          max="100"
                          validate={(value: any) => validateMaxValue(value, values)}
                          onKeyPress={(e: any) => {
                            if (e.key === "-" || e.key === "+" || e.key === "e" || e.key === ".") {
                              e.preventDefault();
                            }
                          }}
                          onChange={(e: any) => {
                            if (parseInt(e.target.value) === 0) {
                              setFieldValue('maxValueLength', NaN)
                            }
                            else {
                              setFieldValue('maxValueLength', parseInt(e.target.value))
                            }
                            setBtnDisable(false);
                          }}
                        />
                        {errors.maxValueLength && touched.maxValueLength ? <span className='text-danger'> <ErrorMessage name={`maxValueLength`} /> </span> : <span>&nbsp;</span>}
                      </div>
                      <div className="col-12 col-md-4">
                        <label>Placeholder:</label>
                        <Field
                          type={"text"}
                          className="form-control form-control-lg"
                          name="placeholder"
                          value={values.placeholder}
                          id='placeholder'
                          placeholder="Enter placeholder"
                          disabled={values.responseType.code === configCodes?.text || values.responseType.code === configCodes?.textarea ? false : true}
                          onChange={(e: any) => {
                            if ((e.target.value.length <= 1 && !e.target.value.includes(' ')) || (e.target.value.length > 1 && !e.target.value.includes('  '))) {
                              setBtnDisable(false); setFieldValue("placeholder", e.target.value)
                            }
                          }}
                        />
                        {(values.responseType.code === configCodes?.text || values.responseType.code === configCodes?.textarea) && errors.placeholder && touched.placeholder ? <span className='text-danger'> <ErrorMessage name={`placeholder`} /> </span> : <span>&nbsp;</span>}
                      </div>
                      <div className={!values.groupId && ((values.responseType.code === configCodes?.text && (values.datatype.code === configCodes?.string || values.datatype.code === configCodes?.integer || values.datatype.code === configCodes?.real)) || values.responseType.code === configCodes?.textarea
                      /*||values.responseType.name === "file"*/) ? "col-12 col-md-4" :
                        " d-none"}>
                        <label htmlFor="text-defaultValue">Default Value: </label>
                        <Field
                          className="form-control form-control-lg mt-1"
                          name="defaultValue"
                          value={values.defaultValue}
                          id='text-defaultValue'
                          type={(values.datatype.code === configCodes?.real || values.datatype.code === configCodes?.integer) ? 'number' : 'text'}
                          placeholder="Enter default value"
                          onKeyPress={(e: any) => {
                            if ((values.datatype.code === configCodes?.real || values.datatype.code === configCodes?.integer) && (e.key === "+" || e.key === "e")) {
                              e.preventDefault();
                            }
                            if (values.datatype.code === configCodes?.integer && e.key === "." && e.key === "-") {
                              e.preventDefault();
                            }
                          }}
                          onChange={(e: any) => {
                            setBtnDisable(false);
                            if (((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) ||
                              (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0))) {
                              setFieldValue('defaultValue', e.target.value);
                            }
                            setVariableData(values);
                          }}
                        />
                        {<span className='text-danger'> <ErrorMessage name={`defaultValue`} /> </span>}
                      </div>
                      {/* <div className="col-12 col-md-4">
                        <label htmlFor="missingCheck">Missing check :</label>
                        <div className="d-flex">
                          <Field
                            type={'checkbox'}
                            className='ms-2'
                            name='missingCheck'
                            id='missingCheckId'
                            onChange={(e: any) => {
                              setFieldValue('missingCheck', e.target.checked)
                              setBtnDisable(false);
                            }}
                          /> <span className="ms-2 mt-2">Missing check</span>
                        </div>
                      </div> */}
                      {/* Changing layout of past date and future date --Nitish */}
                      <div className={!values.groupId && ((values.responseType.code === configCodes?.text && (values.datatype.code === configCodes?.date))) ? "col-12 col-md-4 " :
                        " d-none"}>
                        <label htmlFor="futureDate">Dates:</label>
                        <div className="d-flex">
                          <div className="d-flex align-items-center">
                            <Field
                              type="checkbox"
                              name="isFutureDate"
                              id='futureDateId'
                              className="me-1"
                              onChange={(e: any) => {
                                setBtnDisable(false);
                                setFieldValue('isFutureDate', e.target.checked)
                                setBtnDisable(false);
                              }} />
                            Future Date
                          </div>
                          {/* </div> */}
                          {/* <div className={!values.groupId && ((values.responseType.code === configCodes?.text && (values.datatype.code === configCodes?.date))) ? "col-12 col-md-4" :
                        " d-none"}> */}
                          {/* <label htmlFor="isPastDateEnable">Past Date:</label> */}
                          <div className="d-flex align-items-center ms-2">
                            <Field
                              type="checkbox"
                              name="isPastDateEnable"
                              id='pastDateId'
                              className="me-1"
                              onChange={(e: any) => {
                                setBtnDisable(false);
                                setFieldValue('isPastDateEnable', e.target.checked)
                                setBtnDisable(false);
                              }} />
                            Past Date
                            {/* </div> */}
                          </div>
                        </div>
                      </div>

                      <div className={(values.responseType.name === "file" && (values.datatype.code === configCodes?.file)) ? "col-12 col-md-4" :
                        " d-none"}>
                        {/* {Added file type field - Akshay} */}
                        <label htmlFor="uploadFileType">File type:<span className="text-danger">*</span> </label>
                        <div className="d-flex align-items-center">
                          <Field
                            as='select'
                            name="uploadFileType.code"
                            id='uploadFileTypeId'
                            className="form-control form-select form-control-lg"
                            value={values?.uploadFileType?.code}
                            onChange={(e: any) => {
                              setBtnDisable(false);
                              const _val = uploadFileType?.find((item: any) => item.code === e.target.value);
                              setFieldValue("uploadFileType", _val ? _val : Variable.uploadFileType);
                              setBtnDisable(false);
                            }} >
                            <option value="">Select file type</option>
                            {
                              uploadFileType && uploadFileType.length > 0 && uploadFileType.map((item: any) => {
                                return <option value={item.code} key={item.code}>{item.name}</option>
                              })
                            }
                          </Field>
                        </div>
                        <span className='text-danger'><ErrorMessage name='uploadFileType.code' /></span>
                      </div>
                      <div className={(values.responseType.code === configCodes?.radio || values.responseType.code === configCodes?.checkbox) ? 'col-12 col-md-4' : "d-none"}>
                        <label htmlFor="sel-responseLayout">Response Layout: <span className="text-danger">*</span> </label>
                        <div className="d-flex align-items-center "></div>

                        <Field
                          as="select"
                          className="form-select form-control form-control-lg mt-1"
                          name="layoutId.name"
                          value={values.layoutId ? values.layoutId.name : ''}
                          id='sel-responseLayout'
                          onChange={(e: any) => {
                            setBtnDisable(false);
                            const _val = layoutTypes.find((item: any) => item.name === e.target.value)
                            setFieldTouched('layoutId.name', true);
                            setFieldValue('layoutId', _val ? _val : Variable.layoutId)
                          }}
                        >
                          <option value="" id="sel-optreslayout-0">Select Layout</option>
                          {layoutTypes && layoutTypes.map((item: any, index: any) => {
                            return <option key={index} value={item.name} id="sel-optrestype-1">{item.name}</option>
                          })}
                        </Field>
                        {errors.layoutId && touched.layoutId ? <span className='text-danger'>
                          {errors.layoutId.name}
                        </span> : <span>&nbsp;</span>}
                      </div>
                    </div>
                    <div className=" mb-2 row">
                      <div className={(values.responseType.code === configCodes?.text && values.datatype.code === configCodes?.string) ? 'col-12 col-md-4' : "d-none"}>
                        <label htmlFor="text-variableId">Field Format: <span className="text-danger">*</span> </label>
                        <div className="align-items-center">
                          <Field
                            as="select"
                            className="form-select form-control form-control-lg mt-1"
                            name="variableFieldFormat.label"
                            value={values?.variableFieldFormat?.value}
                            id='sel-datatype'
                            onChange={(e: any) => {
                              const findFormat = fieldFormat?.find((ele: any) => ele.value === e.target.value);
                              setBtnDisable(false);
                              setFieldTouched('variableFieldFormat.label', true);
                              setFieldValue('variableFieldFormat', findFormat ? findFormat : Variable.variableFieldFormat)

                            }}
                          >   <option value="">Select Field Format</option>
                            {fieldFormat?.map((item: any, index: any) => {
                              return <option key={index} value={item.value} id="sel-optrestype-1">{item.label}</option>
                            })}
                          </Field>
                          <span className='text-danger'><ErrorMessage name='variableFieldFormat.label' /></span>
                          {/* {errors.datatype && touched.datatype && !values.datatype.name ? <span className='text-danger'> <ErrorMessage name={`datatype.name`} /> </span> : <span>&nbsp;</span>} */}
                        </div>
                      </div>
                      <div className={!values.groupId && ((values.responseType.code === configCodes?.text && (values.datatype.code === configCodes?.string || values.datatype.code === configCodes?.integer || values.datatype.name === "real")) || values.responseType.code === configCodes?.textarea /*||
                        values.responseType.name === "file"*/) ? "d-flex col-12 col-md-4" :
                        " d-none"}>
                        {/* <label htmlFor="readOnly">Read Only:</label> */}
                        <div className="d-flex align-items-center ms-2">
                          <Field
                            type="checkbox"
                            name="readOnly"
                            id='readOnly'
                            className="me-1"
                            onChange={(e: any) => {
                              setBtnDisable(false);
                              setFieldValue('readOnly', e.target.checked)
                            }} />
                          Read Only
                        </div>
                      </div>
                      <div className={((values.responseType.code === configCodes?.text && values.datatype.code === configCodes?.string) || (values.responseType.code === configCodes?.textarea && values.datatype.code === configCodes?.string)) ? 'd-flex col-12 col-md-4' : "d-none"}>
                        {/* <label htmlFor="readOnly">Spell check:</label> */}
                        <div className="d-flex align-items-center ms-2">
                          <Field
                            type="checkbox"
                            name="spellCheck"
                            id='spellCheckId'
                            className="me-1"
                            onChange={(e: any) => {

                              setBtnDisable(false);
                              setFieldValue('spellCheck', e.target.checked)
                            }} />
                          Spell check
                        </div>
                      </div>
                      <div className="d-flex col-12 col-md-4">
                        {/* <label htmlFor="missingCheck">Missing check :</label> */}
                        <div className="d-flex align-items-center">
                          <Field
                            type={'checkbox'}
                            className='ms-2'
                            name='missingCheck'
                            id='missingCheckId'
                            onChange={(e: any) => {
                              setFieldValue('missingCheck', e.target.checked)
                              setBtnDisable(false);
                            }}
                          /> <span className="ms-2">Missing check</span>
                        </div>
                      </div>
                      <div className={(values.responseType.code === configCodes?.text && values.datatype.code === configCodes?.string) ? 'col-12 col-md-6 caseType' : "d-none"}>
                        <label htmlFor="text-variableId">Case Type: </label>
                        <div className="d-flex">
                          <div className="d-flex align-items-center me-2">
                          <Field
                              type="checkbox"
                              name="isValueUpperCase"
                              id='isValueUpperCase'
                              className="me-1"
                              disabled={values?.isValueLowerCase || values?.isValueCapitalisation }
                              onChange={(e: any) => {
                                setBtnDisable(false);
                                setFieldValue('isValueUpperCase', e.target.checked)
                              }} />
                              <label>To UpperCase </label>
                          </div>
                          <div className="d-flex align-items-center me-2">
                          <Field
                              type="checkbox"
                              name="isValueLowerCase"
                              id='isValueLowerCase'
                              className="me-1"
                              disabled={values?.isValueUpperCase || values?.isValueCapitalisation }
                              onChange={(e: any) => {
                                setBtnDisable(false);
                                setFieldValue('isValueLowerCase', e.target.checked)
                              }} />
                              <label>To LowerCase</label>
                          </div>
                          <div className="d-flex align-items-center me-2">
                          <Field
                              type="checkbox"
                              name="isValueCapitalisation"
                              id='isValueCapitalisation'
                              className="me-1"
                              disabled={values?.isValueUpperCase || values?.isValueLowerCase }
                              onChange={(e: any) => {
                                setBtnDisable(false);
                                setFieldValue('isValueCapitalisation', e.target.checked)
                              }} />
                              <label>To Capitalisation</label>
                          </div>
                          {/* <div className="d-flex align-items-center me-2">
                            <Field type="radio" name='isValueUpperCase' value='false' className="me-1"
                              onChange={(event: any) => {
                                setBtnDisable(false);
                                setFieldValue('isValueUpperCase', event.target.value)
                              }}
                            />
                            <label>To Lowercase </label>
                          </div>
                          <div className="d-flex align-items-center">
                            <Field type="radio" name='isValueUpperCase' value='true' className="me-1"
                              onChange={(event: any) => {
                                setBtnDisable(false);
                                setFieldValue('isValueUpperCase', event.target.value)
                              }}
                            />
                            <label>To Uppercase </label>
                          </div> */}
                        </div>
                        {/* <span className='text-danger'><ErrorMessage name='isValueUpperCase' /></span> */}
                      </div>
                    </div>

                  </div>
                </div>
                <div className="responseWidth ps-2 ms-2">
                  {(values.responseType.code === configCodes?.radio || values.responseType.code === configCodes?.checkbox ||
                    values.responseType.code === configCodes?.['single-select'] || values.responseType.code === configCodes?.['multi-select'])
                    && (values.datatype.name) ?
                    <div className='col-12 col-md-12 '>
                      <FieldArray
                        name="responseOptions"
                        render={(arrayHelpers) => {
                          const responseOptions = values.responseOptions;
                          return (
                            <div>
                              <label htmlFor="ResponseOptionText">Response Options Text:
                                <span className="text-danger">*</span>
                                {props.form !== "editVariable" &&
                                  <CustomToolTip title='Add response options'><AddCircleIcon color="primary"
                                    onClick={() => {
                                      const _validate = validateResponseOptions(values);
                                      if (_validate) {
                                        setaddRemoveMsg("");
                                        // arrayHelpers.push({
                                        //   id: ((values.responseOptions.length + 1) - 1),
                                        //   response: "",
                                        //   status: true
                                        // })
                                        arrayHelpers.push({
                                          id: 0,
                                          response: "",
                                          status: true
                                        })
                                      }
                                    }}
                                  /></CustomToolTip>}
                              </label>
                              <div className="responseOptions-Container">
                                {responseOptions && responseOptions.map((user: any, index: number) => (
                                  <div key={index} className="align-items-center mt-2">
                                    <div className="d-flex">
                                      <Field
                                        type={values.datatype.code === configCodes?.integer ? 'number' : 'text'}
                                        // type="text"
                                        className="form-control form-control-lg mt-1"
                                        placeholder="Enter response text"
                                        name={`responseOptions.${index}.response`}
                                        id={`text-restext-${index}`}
                                        value={values.responseOptions[index].response}
                                        // min="0"
                                        onKeyPress={(e: any) => {
                                          if (e.key === "." || e.key === "+" || e.key === "e" /*|| e.key === "-"*/) {
                                            values.datatype.code === configCodes?.integer && e.preventDefault();
                                          }
                                        }}
                                        onChange={(e: any) => {
                                          if ((e.target.value.length <= 1 && !e.target.value.includes(' ')) || (e.target.value.length > 1 && !e.target.value.includes('  '))) {
                                            const _valuesArr = [...[], ...values.responseOptions]
                                            _valuesArr[index].response = e.target.value.replace(/  +/g, ' ');
                                            setFieldValue(`responseOptions.${index}.response`, e.target.value);
                                            setaddRemoveMsg('');
                                            setBtnDisable(false);
                                            if (values.id > 0) {
                                              setError(`If you update the response options respected variable 
                                        Filed Level Dynamics and Rules will be updated`);
                                            }
                                          }
                                        }
                                        }
                                      />
                                      {/* {props.form != "editVariable" && responseOptions.length > 1 && <RemoveCircleIcon color="primary" */}
                                      {props.form !== "editVariable" && responseOptions.length > 1 && /* user.id is for disabling the remove Btn in edit */ /*user.id == 0 &&*/ <RemoveCircleIcon color="primary"
                                        onClick={() => {
                                          setBtnDisable(false);
                                          setaddRemoveMsg(''); values.responseOptions.length > 1 ?
                                            arrayHelpers.remove(index) :
                                            setaddRemoveMsg("You can't remove. Atleast one option required.")
                                        }}
                                      />}
                                    </div>
                                    {!addRemoveMsg && <div className="text-danger">
                                      <ErrorMessage name={`responseOptions.${index}.response`} /> </div>}
                                  </div>
                                ))}
                              </div>
                              {addRemoveMsg ? <p className="text-danger d-flex">{addRemoveMsg}</p> : <span>&nbsp;</span>}
                            </div>
                          );
                        }}
                      />

                    </div> : <div className="h-100 d-flex text-center text-secondary align-items-center">
                      {/* <div> Response options text, if you select response type and data type.</div> */}
                      <div>Response options text fields will display, if you select required response type & data type.</div>
                    </div>}
                </div>
              </div>
              <CustomDialog
                title={'Reason'}
                onClose={() => onReasonCloseHandler(values)}
                onSubmitHandler={() => handleReasonSubmit(values)}
                open={openReason}
                actionType={'Submit'}
                maxWidth={'xs'}
                form={'responseChangeReasonId'}
                disabled={reasonBtnDisable}
              >
                <div className="response-type-container">
                  <div className="mt-2 ">
                    <label htmlFor="reason" className="mb-3 response-reason-msg">Are you sure want to change the resoponse type & Data type ? </label>
                    <Field
                      className="form-control form-control-lg mt-1"
                      as="textarea"
                      rows="4"
                      name="reason"
                      value={values.reason}
                      id='responseChangeReasonId'
                      placeholder="Enter reason"
                      onChange={(e: any) => {
                        setFieldValue('reason', e.target.value)
                        values.reason === '' ? setReasonBtnDisable(true) : setReasonBtnDisable(false)
                      }}
                    />
                    {/* {!reasonBtnDisable ? '' : <span className="text-danger">Please enter reason*</span>} */}
                  </div>
                </div>
              </CustomDialog>
            </Form>
          )}
        </Formik>
      </CustomDialog>
      <UnitDialog openUnit={openUnit} setOpenUnit={setOpenUnit} />
    </React.Fragment>
  )
}
export default AddVariable