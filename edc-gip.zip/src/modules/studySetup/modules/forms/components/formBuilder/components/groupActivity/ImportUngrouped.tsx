import React, { useState } from "react";
import CustomDialog from "../../../../../../../../common/modals/CustomeDialog";
import { useDispatch, useSelector } from "react-redux";
import { importUngroupedParam } from "../../../../helpers/form-modal";
import { getFormsDetailsId, importUngroupedToGroup } from "../../../../actions/actions";
import { toastAlert } from "../../../../../../../../actions/actions";
import AddVariable from "../AddVariable";

function ImportUngrouped(props: any) {
  const dispatch = useDispatch();
  const [errorMsg, setErrorMsg] = React.useState('');
  const [importUngrouped, setImportUngrouped] = React.useState<any>([]);
  const { formDetails } = useSelector((state: any) => state.forms);
  const [open, setOPen] = React.useState(false);
  const [fields, setFields] = useState([]);
  const [disableSubmit, setDisableSubmit] = useState(true)
  const [selectAll, setSelectAll] = React.useState(false)


  React.useEffect(() => {
    const elements = formDetails && formDetails.formFields.filter((item: any) => (item.field && (item.field.status === true)));
    setFields(elements);
    if (props.page === 2) {
      setOPen(true);
      const _allFields: any = []
      const _fields = formDetails.formFields
      _fields && _fields.length > 0 && _fields.map((item: any) => {
        if (item.field) {
          const _item = item
          _item.field.checked = false
          _allFields.push({ ..._item })
        }
        return null;
      })
      setImportUngrouped(_allFields)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dispatch, props.page])

  const onCloseHandler = () => {
    setOPen(false);
    props.onCloseHandler();
    setImportUngrouped([]);
    setErrorMsg('');
    setDisableSubmit(true)
    setSelectAll(false)
  }


  const onChangeHandler = (e: any, fieldItem: any, index: number) => {
    const _importUngrouped = [...[], ...importUngrouped]
    _importUngrouped[index].field.checked = e.target.checked

    let count = 0
    _importUngrouped.map((item: any) => {
      if (!item.field.checked) {
        count = count + 1
      }
      return null
    })
    setSelectAll(count > 0 ? false : true)
    setImportUngrouped(_importUngrouped)
    setErrorMsg('')
    setDisableSubmit(false)
  }
  const onSelectAllHandler = () => {
    setSelectAll(selectAll ? false : true)
    const _data = [...[], ...importUngrouped]
    importUngrouped.map((item: any, index: number) => _data[index].field.checked = selectAll ? false : true)
    setDisableSubmit(selectAll ? true : false)
    setImportUngrouped(_data)
  }
  const ValidateFields = () => {
    const payload: any = []
    importUngrouped && importUngrouped.length > 0 && importUngrouped.map((item: any) => {
      if (item.field.checked) {
        const _exportUngroupedParam = { ...{}, ...importUngroupedParam }
        _exportUngroupedParam.groupId = item.field.groupId;
        _exportUngroupedParam.formId = item.field.formId;
        _exportUngroupedParam.id = item.field.id;
        _exportUngroupedParam.ordinal = item.field.ordinal;
        _exportUngroupedParam.variableId = item.field.variableId;
        _exportUngroupedParam.variableText = item.field.variableText;
        payload.push(_exportUngroupedParam)
      }
      return null
    })
    return payload
  }

  const onSubmit = () => {
    const validate = ValidateFields()
    if (validate.length > 0) {
      dispatch(importUngroupedToGroup(props.groupId, validate, (callback: any) => {
        if (callback.data.status === "error") {     
          dispatch(getFormsDetailsId(props.params.id))
          onCloseHandler();
          dispatch(toastAlert({ status: 0, message: callback.data.errorMessage, open: true }))
          props.setToastOpen(true)
        }else{
          dispatch(getFormsDetailsId(props.params.id))
          onCloseHandler();
          dispatch(toastAlert({ status: 1, message: callback.data, open: true }))
          // props.setToastOpen(true)
        }
      }))
    }
    else {
      setErrorMsg("Please select atleast one");
    }
  }

  return (
    <React.Fragment>
      <div className="ig-container">
        <CustomDialog
          title={'Import variables'}
          onClose={onCloseHandler}
          onSubmitHandler={onSubmit}
          open={open}
          maxWidth="xs"
          padding={true}
          fullWidth={false}
          actionType={'Submit'}
          form="addGroup"
          disabled={disableSubmit}
        >
          <div className="Import-group import-export-container">
            <div className="ig-header">
              <span> Import ungrouped variables to grouped variables</span>
              {fields.length > 0 &&
                <div className="select-all" onClick={() => onSelectAllHandler()}>{!selectAll ? "Select All" : "Deselect All"}
                </div>}
            </div>
            <div className="ig-variable">
              {errorMsg &&
                <div className='text-danger d-flex justify-content-center mt-2'>{errorMsg}</div>}
              <ul className="list-items">

                {importUngrouped && importUngrouped.length > 0 && importUngrouped.map(
                  (item: any, index: number) => {
                    if (item && item.field && item.field.status) {
                      return (
                        <li key={index}>
                          <input className="chekbox" type="checkbox"
                            checked={item.field.checked}
                            id={`chkbx-import-${item.field.id}`}
                            onChange={(e) => onChangeHandler(e, item.field, index)}
                          />
                          <label htmlFor={`chkbx-import-${item.field.id}`}>{item.field.variableText}</label>
                        </li>
                      )
                    }
                    return null
                  })
                }
              </ul>
              {fields.length === 0  &&
                <div className="e-alert-info w-100 py-5" role="alert">
                  <h6>No variables available to display</h6>
                  Please add {/*<a href="#/">Add New</a>*/} <AddVariable params={{ id: 0 }} /> variable
                </div>
              }
            </div>
          </div>
        </CustomDialog>
      </div>
    </React.Fragment>
  )
}
export default ImportUngrouped;