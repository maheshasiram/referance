import * as React from 'react';
import IconButton from '@mui/material/IconButton';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { Popover } from '@mui/material';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import ExportGroup from './ExportGroup';
import ImportUngrouped from './ImportUngrouped';
import IndexColumn from './IndexColumn';
import DefaultValues from './addDefaultValues/DefaultValues';
import BackupOutlinedIcon from '@mui/icons-material/BackupOutlined';
import CloudDownloadOutlinedIcon from '@mui/icons-material/CloudDownloadOutlined';
import CodeOffIcon from '@mui/icons-material/CodeOff';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import ViewColumnOutlinedIcon from '@mui/icons-material/ViewColumnOutlined';
import GroupVariable from '../GroupVariable';
import { MenuItems } from '../../../../helpers/menuItems';
import RowsHide from './RowsHide';
import CustomToolTip from '../../../../../../../../components/CustomToolTip';

function GroupLevelMenu(props: any) {
  const { groupId, params, groupIndex, setToastOpen } = props;
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const [page, setPage] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = (state: any) => {
    setPage(state);
    setAnchorEl(null);
  };

  const onCloseHandler = () => {
    setPage(null);
  }

  return (
    <div className='kabab-menu'>
      <GroupVariable type={3} groupId={groupId} isUpdate={false} page={page} params={params} onCloseHandler={onCloseHandler} />
      <ExportGroup groupId={groupId} params={params} setToastOpen={setToastOpen}
        groupIndex={groupIndex} isUpdate={false} page={page} onClose={onCloseHandler} />
      <ImportUngrouped groupId={groupId} params={params} isUpdate={false} page={page} onCloseHandler={onCloseHandler} setToastOpen={setToastOpen} />
      <IndexColumn isUpdate={false} page={page} onCloseHandler={onCloseHandler} />
      <DefaultValues groupId={groupId} isUpdate={false} page={page} group={props.group} onCloseHandler={onCloseHandler} />
      <RowsHide groupId={groupId} group={props.group} isUpdate={false} page={page} onCloseHandler={onCloseHandler} setToastOpen={setToastOpen}/>
      <IconButton
        aria-label="more"
        id="long-button"
        aria-controls={open ? 'long-menu' : undefined}
        aria-expanded={open ? 'true' : undefined}
        aria-haspopup="true"
        onClick={handleClick}
      >
        <CustomToolTip title='More'>
        <MoreVertIcon sx={{fontSize:18}} className='moreIcon-GRP' />
        </CustomToolTip>
      </IconButton>
      <Popover
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
      >
        <nav aria-label="secondary mailbox folders">
          <List className='kabab-menu-list'>
            {MenuItems.map((item:any , index:number) =>
              <ListItem disablePadding key={index} className='kabab-menu-listItem'>
                <ListItemButton className='kabab-menu-ItemBtn'
                  onClick={() => { handleClose(item.page); }}>
                  {item.icon === 'BackupOutlinedIcon' && <BackupOutlinedIcon />}
                  {item.icon === 'CloudDownloadOutlinedIcon' && <CloudDownloadOutlinedIcon />}
                  {item.icon === 'ViewColumnOutlinedIcon' && <ViewColumnOutlinedIcon />}
                  {item.icon === 'CodeOffIcon' && <CodeOffIcon />}
                  {item.icon === 'VisibilityOffIcon' && <VisibilityOffIcon />}
                  <ListItemText primary={item.label} />
                </ListItemButton>
              </ListItem>
            )}
          </List>
        </nav>
      </Popover>

    </div>
  );
}
export default GroupLevelMenu;
