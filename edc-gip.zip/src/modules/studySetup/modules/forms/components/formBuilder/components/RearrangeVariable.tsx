import React, { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import CustomDialog from "../../../../../../../common/modals/CustomeDialog";
import { Types } from "../../../reducer/Types";
// import { List, arrayMove } from "react-movable";
import { Box } from "@mui/system";
import _ from 'lodash'
import { getFormsDetailsId, updateFieldsOrder } from "../../../actions/actions";
import { useParams } from "react-router-dom";
import RearrangeImg from "../../../../../../../common/Assests/Images/RearrangeImg.png";
import { toastAlert } from "../../../../../../../actions/actions";
import { SortableContainer, SortableElement, arrayMove } from 'react-sortable-hoc';
import DragHandleIcon from '@mui/icons-material/DragHandle';
function RearrangeVariable(props: any) {

    const dispatch = useDispatch()
    const params = useParams()
    const [open, setOpen] = useState(false)
    // const [erroeMsg, setErroeMsg] = useState('')
    const { formDetails } = useSelector((state: any) => state.forms)
    const [list, setList] = useState(formDetails.formFields);
    const [groupDragging, setGroupDragging] = useState(false);
    const [groupWithChildrenDragging, setGroupWithChildrenDragging] = useState(false);
    // const [submitDisabled, setSubmitDisabled] = useState(true);
    // const dispatch = useDispatch();
    const dragGroup = useRef<any>();
    const dragNode = useRef<any>();
    const groupDragEntered = useRef<any>(false);
    // current drag element
    const currentDragIndex = useRef<any>(-1);
    const targetCount = useRef<any>(0)
    const currentTarget = useRef<any>()
    // const { setToastOpen } = props

    useEffect(() => {
        // debugger
        setList(formDetails && formDetails.formFields);
    }, [formDetails])

    useEffect(() => {
        if (dragNode.current != null) {
            if (groupWithChildrenDragging) {
                dragNode.current.addEventListener('dragend', handleGroupWithChildrenDragEnd);
            }
            if (groupDragging) {
                dragNode.current.addEventListener('dragend', handleGroupDragEnd);
            }
        }
    })
    const handleGroupDragEnd = () => {
        setGroupDragging(false);
        dragNode.current.removeEventListener('dragend', handleGroupDragEnd);
        dragGroup.current = null;
        setTimeout(() => {
            dragNode.current = null;
            groupDragEntered.current = false;
        }, props.timeout);
    }
    const handleGroupWithChildrenDragEnd = () => {
        setGroupWithChildrenDragging(false)
        if (dragNode.current != null) {
            dragNode.current.removeEventListener('dragend', handleGroupWithChildrenDragEnd);
        }
        dragGroup.current = null;
        setTimeout(() => {
            dragNode.current = null;
            groupDragEntered.current = false;
        }, props.timeout);
    }

    const groupElementRearange = (groupIndex: any, oldIndex: number, newIndex: number) => {

        const _list = _.cloneDeep(list)
        const _shuffle = arrayMove(_list[groupIndex].group.fields, oldIndex, newIndex)
        _list[groupIndex].group.fields = _shuffle
        setList(_list)
        // setSubmitDisabled(false);
    }
    const onOpenHandler = () => {
        dispatch({ type: Types.FORM_DETAILS_BY_ID, payload: _.cloneDeep(formDetails) })
        setOpen(true)
    }
    const onCloseHandler = () => {
        setOpen(false)
        // setErroeMsg('')
    }

    const onDragGroupStart = (e: any, groupIndex: number) => {
        // console.clear()
        // console.log('drag startted.......',);
        targetCount.current = 0
        currentDragIndex.current = groupIndex

    }

    const ondragEnterNonGrp = (e: any, groupIndex: number) => {
        console.log(e, groupIndex)
        // console.warn('drag enter div', groupIndex, currentDragIndex.current, targetCount.current);
        const _shuffle = arrayMove(list, currentDragIndex.current, currentTarget.current)
        setList(_shuffle)

    }

    const ondragenter = (groupIndex: any) => {
        // console.warn('dragEnter..........', groupIndex)
        currentTarget.current = groupIndex
    }
    const onsubmitImport = () => {
        const _list = _.cloneDeep(list)
        // console.log('_list.....107', _list)
        const payload: any = []
        let _ordinal = 1
        _list.map((item: any) => {
            // console.warn('item.............', item)
            if (item && item.group) {
                // console.log('group item....', item.group);
                if (item.group.fields && item.group.fields.length > 0) {
                    item.group.fields.map((grpItem: any) => {
                        // console.log('grpItem.......', grpItem);
                        payload.push(
                            {
                                "id": grpItem.id,
                                "formId": grpItem.formId,
                                "groupId": grpItem.groupId,
                                "variableId": grpItem.variableId,
                                "variableText": grpItem.variableText,
                                "ordinal": _ordinal
                            }
                        )
                        _ordinal = _ordinal + 1
                        return null
                    })
                }

            } else {
                // console.log('fields.......', item.field);
                payload.push(
                    {
                        "id": item.field.id,
                        "formId": item.field.formId,
                        "groupId": item.field.groupId,
                        "variableId": item.field.variableId,
                        "variableText": item.field.variableText,
                        "ordinal": _ordinal,
                    }
                )
                _ordinal = _ordinal + 1
            }
            return null
        })

        // console.warn('payload..........', payload);
        dispatch(updateFieldsOrder(payload, (response: any) => {
            // console.log('response...............', response)
            if (response.data) {
                onCloseHandler()
                dispatch(getFormsDetailsId(params.id))
                // dispatch(toastAlert({ status: 1, message: callback.data }))
                dispatch(toastAlert({
                    status: 1,
                    message: response.data,
                    open: true
                }))
                // props.setToastOpen(true)
                // setToastOpen(true)
            }
        }))
    }
    console.log('202...............', list)

    const onSortEndChild = ({ oldIndex, newIndex }: any, index: any) => {
        let _items = [...[], ...list]
        let _array = arrayMove(_items[index].group.fields, oldIndex, newIndex)
        _items[index].group.fields = _array
        setList(_items)
        // console.log('oldIndex, newIndex......222', oldIndex, newIndex, '==>>', index, _items);
    };
    const onSortEnd = ({ oldIndex, newIndex }: any) => {
        console.log('oldIndex, newIndex......', oldIndex, newIndex);
        // setItems(arrayMove(items, oldIndex, newIndex))
        setList(arrayMove(list, oldIndex, newIndex))
    };
    const getGroupStatus = (groupFields: any) => {
        let _flag = false
        groupFields.map((ele: any) => {
            if (ele.status) {
                _flag = true
            }
        })
        return _flag
    }
    const SortableItem = SortableElement((props: any) => {
        const { value } = props
        // return < div style={{ background: '#9FA8DA', margin: '10px 0px', padding: '10px', opacity:'1', visibility:'visible', zIndex:'999999' }}><DragHandleIcon /> {value}</div >
        return <div className="draggableVariable"><DragHandleIcon /> <p className="variableText w-100">{value}</p></div >
    });

    const SortableList: any = SortableContainer(({ items, ...restProps }: any) => {
        return (
            <div className="w-100" >
                {items.map((item: any, index: any) => {
                    if ((item?.field && item.field.status)/*active fields non group var */ ||
                        (item.status) /*active fields inside group */ ||
                        (item.group?.status && getGroupStatus(item?.group?.fields))/*active group */) {
                        return <SortableItem key={`item-${index}`} index={index} value={
                            <React.Fragment>
                                {item?.field ? item.field?.variableText : (item?.group ? item?.group?.name : item?.variableText)}
                                {item?.group && item?.group?.fields?.length > 0 &&
                                    <div className="grpFieldsContainer" >
                                        <SortableList items={item?.group?.fields} onSortEnd={(e: any) => onSortEndChild(e, index)} />
                                    </div>
                                }
                            </React.Fragment>
                        } {...restProps} />
                    }
                }
                )}
            </div>
        );
    });
    const getAllFieldsActive = (_list: any) => {
        let _flag = false
        _list.map((ele: any) => {
            if (ele.field && ele.field.status) {
                _flag = true
            } else if (ele.group && ele.group.status && ele.group.fields && ele.group.fields.length > 0) {
                ele.group.fields.map((el: any) => {
                    if (el?.status) {
                        _flag = true
                    }
                })
            }
        })
        return _flag
    }

    return (
        <React.Fragment>
            <li className="list-group-item" onClick={onOpenHandler}>
                <span className="icons"><img src={RearrangeImg} alt="" /></span>
                Rearrange Variable</li>

            <CustomDialog
                title={"Rearrange Variables"}
                open={open}
                onClose={onCloseHandler}
                maxWidth="sm"
                fullWidth={true}
                actionType={"submit"}
                cssName="rearrange-variable"
                onSubmitHandler={() => {
                    onsubmitImport()
                }}
            >
                <div className="Rearrange">
                    <div id="Rearrange-div" className='Rearrange-container'>
                        {list && list.length > 0 && getAllFieldsActive(list) ?
                            <div>
                                <SortableList items={list} onSortEnd={onSortEnd} axis='y' />
                            </div> : <div className="py-5 d-flex justify-content-center" >
                                <p>No variables available to display</p>
                            </div>
                        }
                    </div>
                </div>
            </CustomDialog>

        </React.Fragment>
    )
}
export default RearrangeVariable