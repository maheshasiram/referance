import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import CustomDialog from "../../../../../../../common/modals/CustomeDialog";
import { fetchAllActiveForm, fetchFieldsByFormId, getFormsDetailsId, importFieldsToForm, } from "../../../actions/actions";
import { Types } from "../../../reducer/Types";
import _ from 'lodash'
import CloudDownloadOutlinedIcon from '@mui/icons-material/CloudDownloadOutlined';
import { toastAlert } from "../../../../../../../actions/actions";

function ImportVariables(props: any) {
  const dispatch = useDispatch()
  const params: any = useParams()
  const [open, setOpen] = useState(false)
  const [errorMsg, setErrorMsg] = useState('')
  const [validate, setValidate] = useState('')
  const [formId, setFormId] = useState('')
  const { activeFormsList, formVariables } = useSelector((state: any) => state.forms)
  const [selectAll, setSelectAll] = React.useState(false)

  useEffect(() => {
    dispatch(fetchAllActiveForm())
  }, [dispatch])

  const onOpenHandler = () => {
    setOpen(true)
  }
  const onCloseHandler = () => {
    setOpen(false)
    setErrorMsg('')
    setFormId('')
    setValidate('')
    setSelectAll(false)
    dispatch({ type: Types.GET_FIELDS_BY_FORMID, payload: [] })
  }

  const onSelectFormHandler = (event: any) => {
    // console.log('event........', event.target.value);
    if (event.target.value !== "") {
      dispatch(fetchFieldsByFormId(event.target.value))
      setErrorMsg('')
      setValidate('')
    } else {
      dispatch({ type: Types.GET_FIELDS_BY_FORMID, payload: [] })
      setValidate('')
      setErrorMsg('Please select Form from the Dropdown')

    }
    setFormId(event.target.value)
  }


  const onSlectVariable = (event: any, index: number) => {
    const _data = [...[], ...formVariables]
    _data[index].checked = event.target.checked
    setSelectAll(_data.every((item:any)=> item.checked));
    dispatch({ type: Types.GET_FIELDS_BY_FORMID, payload: _data })
    setErrorMsg('')
  }

  const Validate = () => {
    if (formId !== "") {
      if (formVariables.length > 0) {
        let StatusFlag = false
        formVariables.map((item: any) => {
          if (item.checked) {
            StatusFlag = true
          }
          return null;
        })
        if (StatusFlag) {
          setErrorMsg('')
          return true
        } else {
          setErrorMsg('Please select atleast one variable')
          return false
        }
      } else {
        // setErrorMsg('form doesnot have any variables')
        return false
      }
    } else {
      setErrorMsg('Please select form from the dropdown')
      return false
    }
  }
  const onsubmitImport = () => {
    const validate = Validate();
    const _Variables = _.cloneDeep(formVariables)
    if (validate) {
      const payload: any = { formId: params.id, Fields: [] }
      _Variables.map((item: any) => {
        if (item.checked) {
          delete item.checked
          payload.Fields.push(item)
        }
        return null;
      })

      dispatch(importFieldsToForm(payload, (response: any) => {
        if (response.data.status === "error") {
          setValidate(response.data.errorMessage)
        } else {
          onCloseHandler()
          dispatch(getFormsDetailsId(params.id))
          dispatch(toastAlert({ status: 1, message: response.data, open: true }))
          props.setToastOpen(true)
        }
      }))
    }
  }
  const onSelectAllHandler = () => {
    setSelectAll(!selectAll)
    const _data = [...[], ...formVariables]
    _data?.map((item: any, index: any) => {
        item.checked = !selectAll;
        return null;
      })
    dispatch({ type: Types.GET_FIELDS_BY_FORMID, payload: _data })
    setErrorMsg('')
  }

  return (
    <React.Fragment>
      {(props.type === 0) ?
        <li className="list-group-item" onClick={onOpenHandler}>
          <span className="icons"><CloudDownloadOutlinedIcon /></span>
          Import Variable</li> : <a href="#/" onClick={onOpenHandler}>Import Variables</a>}

      <CustomDialog
        title={"import Variable"}
        open={open}
        onClose={onCloseHandler}
        maxWidth={500}
        fullWidth={false}
        actionType={"submit"}
        padding={true}
        onSubmitHandler={() => {
          onsubmitImport()
        }}
      >
        <div className="ImportVar-container import-export-container">

          <div className="select-element ig-header" >
            <label>Select Form :</label>
            <select className="form-select" value={formId} onChange={onSelectFormHandler}>
              <option value={''}>Select your Form</option>
              {
                activeFormsList && activeFormsList.length > 0 && activeFormsList.map((item: any, index: number) => {
                  if (item.noOfFields > 0) {
                    return <option className="form-option" value={item.id} disabled={parseInt(params.id) === item.id ? true : false} key={index}>{item.formName}</option>
                  }
                })
              }
            </select>
            <p className="text-danger d-flex justify-content-center">{errorMsg}</p>
            {validate && <p className="text-danger validate-importVar d-flex justify-content-center mt-2">{validate}</p>}
            {formVariables?.length > 1 && <div className="select-all" onClick={onSelectAllHandler}>{!selectAll ? "Select All" : "Deselect All"}</div>}
          </div>

          <div className="ig-variable">
            <ul className="list-items">
              {
                formVariables && formVariables.length > 0 && formVariables.map((item: any, index: number) => {
                  if (item.status) {
                    return (
                      <li key={item.id}>
                        <input id={`chkbx-variable-${item.id}`} type="checkbox"
                          checked={item.checked} onChange={(e) => onSlectVariable(e, index)} />
                        <label htmlFor={`chkbx-variable-${item.id}`} >{item.variableText}</label>
                        {item.groupName && <span className="ps-1">{` (${item.groupName})`}</span>}
                      </li>
                    )
                  }
                  return null
                }
                )
              }
            </ul>
            {
              formVariables && formVariables.length <= 0 && formId !== "" && errorMsg === "" &&
              <div className="e-alert-info w-100 py-5" role="alert">
                <h6>This form doesn&apos;t have any active variables!</h6>
                <span> Please select another form  from dropdown or add new variable</span>
              </div>
            }
          </div>
        </div>
      </CustomDialog>
    </React.Fragment>
  )
}
export default ImportVariables