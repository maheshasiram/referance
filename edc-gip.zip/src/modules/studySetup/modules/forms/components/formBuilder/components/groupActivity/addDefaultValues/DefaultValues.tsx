import React, { useState } from "react";
import CustomDialog from "../../../../../../../../../common/modals/CustomeDialog";
import { Formik, Form } from 'formik';
import { useDispatch, useSelector } from "react-redux";
import ScriptRow from "./ScriptRow";
import {
  deleteDefaultValues, getAllDefaultValues, updateDefaultValues
} from "../../../../../actions/actions";
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import AddDefaultValue from "./AddDefaultValue";
import CancelIcon from '@mui/icons-material/Cancel';
import { Confirm } from "../../../../../../../../../actions/actions";
import KeyboardDoubleArrowRightIcon from '@mui/icons-material/KeyboardDoubleArrowRight';
import { DefaultValuesSchema } from "../../../../../helpers/Validate";
import _ from "lodash";
import { Alert, Snackbar } from "@mui/material";


function DefaultValues(props: any) {
  const dispatch = useDispatch();
  const { variables, formDetails } = useSelector((state: any) => state.forms);
  const [defaultVal, setDefaultVal] = React.useState(true);
  // const [successMsg, setSuccessMsg] = React.useState('');
  const [erroeMsg, setErroeMsg] = useState('')
  const [open, setOPen] = React.useState(false);
  const [disableSubmit, setDisableSubmit] = useState(true)
  const [defaultVariables, setDefaultVariables] = React.useState({
    groupDefaultValues: [],
    variableId: "",
    fieldId: 0,
    fieldDataTypeCode: ''
  });
  const [isToast, setIsToast] = React.useState({ status: 0, message: '', open: false });
  React.useEffect(() => {
    if (props.page === 4) {
      dispatch(getAllDefaultValues(props.group, (response: any) => {
        setDefaultVariables(response[0]);
      }))
      setOPen(true);
      setDisableSubmit(true);
      // setSuccessMsg('');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dispatch, props.groupId, props.page])

  const onCloseHandler = () => {
    setOPen(false);
    props.onCloseHandler();
    setDefaultVal(true)
  }

  const onChangeHanlder = (index: any, values: any) => {
    if (disableSubmit) {
      const _variables = [...[], ...variables]
      setDefaultVariables(_variables[index]);
    } else {
      dispatch(Confirm({
        status: 0, message: 'Are you sure you want to move to next variable with saving the script data ?', onOk: () => {
          // let _variables = [...[], ...variables]
          // setDefaultVariables(_variables[index]);
          // setDisableSubmit(true)
          onSubmitHandler(values, index)
        }
      }));
    }
    setErroeMsg('');
  }

  const onDeleteVariable = (item: any) => {
    dispatch(Confirm({
      status: 0, message: 'Are you sure want to delete this default values',
      onOk: () => {
        dispatch(deleteDefaultValues(item, (_response: any) => {
          dispatch(getAllDefaultValues(props.groupId, (response: any) => {
            setDefaultVariables(response[0]);
            // dispatch(toastAlert({ status: 1, message: _response.data }))
            setIsToast({ status: 1, message: _response.data, open: true })
            // setToastOpen(true)
          }))
        }))
      }
    }));
  }

  const onvalidateHandler = (values: any) => {
    let itemValid = 0
    if (values.variableId !== '') {
      values.groupDefaultValues.map((item: any) => {
        if ((item.defaultValue && item.defaultValue.trim() !== '') || (item.readOnly)) {
          itemValid = itemValid + 1
        }
        return null
      })
      if (itemValid > 0) {
        setErroeMsg('')
        return true
      } else {
        setErroeMsg('Please enter value in input field or select read only')
        return false
      }
    }
  }
  const onSubmitHandler = (values: any, index: any) => {
    const _payload = { ...{}, ...values }
    const validate = onvalidateHandler(_payload)
    if (validate) {
      // adding row count for the default variable
      values?.groupDefaultValues?.map((item: any, index: number) => _payload.groupDefaultValues[index].rowId = index + 1)

      if (values.fieldDataTypeCode === "DATA_TYP_PARTIAL_DATE") {
        values.groupDefaultValues.map((item: any, index: number) => {
          if ((item.defaultValue && item.defaultValue.trim() !== '' && item.dateValue && item.dateValue.trim() !== '')) {
            _payload.groupDefaultValues[index].defaultValue = item.defaultValue + '@' + item.dateValue
          }
          return null
        })
      }
      dispatch(updateDefaultValues(_payload, (_response: any) => {
        if (_response.data) {
          // setSuccessMsg(_response.data);
          setDisableSubmit(true);
          dispatch(getAllDefaultValues(props.group, (response: any) => {
            const _index = index ? index : response.findIndex((item: any) => _payload.fieldId === item.fieldId);
            setDefaultVariables(response[(_index !== -1) ? _index : 0]);
            // setSuccessMsg('');
          }))
          // dispatch(toastAlert({ status: 1, message: response.data, open: true }))
          // setToastOpen(true)
          setIsToast({ status: 1, message: _response.data, open: true })
        }
      }))
    }
  }

  const onResetDefaulatValues = () => {
    setErroeMsg('')
    setDisableSubmit(true)
  };
  const handleClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
    if (reason === 'clickaway') {
      return;
    }
    setIsToast({ status: 1, message: '', open: false })
    // dispatch({
    //   type: Types.IS_TOAST_ENABLED, payload: {
    //     status: null, message: "", open: false
    //   }
    // });
  };

  return (
    <React.Fragment>
      <div className="defaultValues-container" >

        <CustomDialog
          title={`Default Values (${props?.group?.name })`}
          cssName='DV-container'
          onClose={onCloseHandler}
          onSubmitHandler={() => { return null }}
          open={open}
          maxWidth="md"
          disabled={disableSubmit}
          padding={true}
          actionType={defaultVal ? 'Update' : 'Add'}
          form="defaultValuesFrom"
          onResetHandler={() => { return null }}
        >
          <React.Fragment>
            <Formik
              enableReinitialize={true}
              initialValues={defaultVariables}
              validationSchema={DefaultValuesSchema(defaultVariables && defaultVariables.fieldDataTypeCode)}
              onSubmit={(values: any) => {
                onSubmitHandler(values, '');
                // resetForm()
              }}
              onReset={() => onResetDefaulatValues()}
            >
              {({ errors, values, setFieldValue }) => (
                <Form id="defaultValuesFrom">
                  {
                    // successMsg ?
                    //  <div className="successMsg">{successMsg}</div> :
                    <div className="d-flex default-values-container">
                      <div className="left-panel">
                        <ul className="list-items">
                          <li>
                            <AddDefaultValue
                              group={props.group}
                              setErroeMsg={setErroeMsg}
                              setDefaultVariables={setDefaultVariables}
                              // toastOpen={toastOpen}
                              setIsToast={setIsToast}
                            />
                          </li>
                          {(variables && variables.length > 0) &&
                            variables.map((item: any, index: any) => (
                              <li key={index}>
                                <input type="radio"
                                  className=''
                                  id={`default_${index}`}
                                  name="itemName"
                                  checked={((defaultVariables && defaultVariables.fieldId) === item.fieldId)}
                                  value={item.fieldId}
                                  onChange={_.isEmpty(errors) ? () => onChangeHanlder(index, values) : () => { return null}}
                                />
                                <label htmlFor={`default_${index}`} className="" id="radio-Hide">
                                  <ArrowForwardIosIcon />
                                  {item.variableId}</label>
                                <span className="gridItem ms-2">
                                  <CancelIcon onClick={() => onDeleteVariable(item)} />
                                </span>
                              </li>
                            ))
                          }
                        </ul>
                      </div>
                      <div className="content-panel w-75 position-relative">
                        {/* toast inside the popup */}
                        <Snackbar open={isToast.open}
                          autoHideDuration={3000}
                          className='DV-Toast'
                          anchorOrigin={{
                            vertical: 'top',
                            horizontal: 'right',
                          }}
                          onClose={handleClose}>
                          <Alert onClose={handleClose}
                            severity={isToast.status === 1 ? "success" : "error"}
                            sx={{ width: '100%' }}>
                            {isToast.message}
                          </Alert>
                        </Snackbar>
                        {(props.group && values) &&
                          <div className="default-values-header">
                            <h6>{formDetails.formName}</h6>
                            <span>{props.group && props.group.name}</span><span><KeyboardDoubleArrowRightIcon />
                              {`${defaultVariables && defaultVariables.variableId}`}
                            </span>
                          </div>
                        }
                        <div>{erroeMsg && <p className="text-danger text-center">{erroeMsg}</p>}</div>
                        <>{console.log('values............', values,errors, _.isEmpty(errors))}</>
                        {(values && values.groupDefaultValues) &&
                          <ScriptRow
                            id={'default_update'}
                            values={values}
                            errors={errors}
                            setFieldValue={setFieldValue}
                            setDisableSubmit={setDisableSubmit}
                            disableSubmit={disableSubmit}
                            setErroeMsg={setErroeMsg}
                          />

                        }
                        {(!values) &&
                          (<div className="e-alert-info w-100 py-5 my-5" role="alert">
                            <h6>No Default values are available to display !</h6>
                            <span> Please select add variable from left menu and add the default values</span>
                          </div>)
                        }
                      </div>
                      {/* <button type="reset" >
                      Reset All
                    </button> */}
                    </div>}
                </Form>
              )}
            </Formik>
          </React.Fragment>
        </CustomDialog>
      </div>
    </React.Fragment>
  )
}
export default DefaultValues;