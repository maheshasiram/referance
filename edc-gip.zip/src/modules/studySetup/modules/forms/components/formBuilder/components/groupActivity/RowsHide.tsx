
import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import CustomDialog from "../../../../../../../../common/modals/CustomeDialog";
import { getGroupRows, updateGroupRows } from "../../../../actions/actions";
import { Types } from "../../../../reducer/Types";
import _ from 'lodash';
import { toastAlert } from "../../../../../../../../actions/actions";
import CommonCard from "../../../../../../../../common/styleComponents/CommonCard";
import { Box } from "@mui/system";
import TabList from "@mui/lab/TabList";
import { Tab } from "@mui/material";
import TabContext from "@mui/lab/TabContext";
import TabPanel from "@mui/lab/TabPanel";
function RowsHide(props: any) {
    const [open, setOPen] = React.useState(false);
    const [error, setError] = React.useState('');
    const { hideGroupRowsData } = useSelector((state: any) => state.forms);
    const { groupId } = props;
    const [tabConextValue, setTabConextValue] = React.useState('0');
    const dispatch = useDispatch();
    useEffect(() => {
        if (props.page === 5) {
            setOPen(true);
            dispatch(getGroupRows(groupId, (response: any) => {
                // if (response.status == 'error') {
                //     console.log('29', response.errorMessage);
                //     setError(response.errorMessage)
                // } else {
                console.log('response?.data?.visits', response.data);

                if (response?.data?.visits.length > 0) {
                    setTabConextValue(`${response.data.visits[0].visitId}`)
                }
                // }
            }));
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.page]);

    const onSelectFormHandler = (e: any, fields: any) => {
        const _hideGroupRowsData = _.cloneDeep(hideGroupRowsData)
        console.log("343...", _hideGroupRowsData, tabConextValue, fields);

        if (_hideGroupRowsData !== null) {
            // _hideGroupRowsData[index - 1].hide = e.target.checked
            console.log("...670", fields);

            // _hideGroupRowsData.visits.map((item: any) => {
            //     item.groupRows[index - 1].hide = e.target.checked
            // })
            const _visitIndex = hideGroupRowsData.visits.findIndex((i: any) => i.visitId === parseInt(tabConextValue))


            console.log('_find Index......', _visitIndex)
            if (_visitIndex !== -1) {
                _hideGroupRowsData.visits[_visitIndex].groupRows[fields.rowIndex].hide = e.target.checked
            }

        }
        dispatch({ type: Types.HIDE_GROUP_ROWS, payload: _hideGroupRowsData });
    }
    const onCloseHandler = () => {
        setOPen(false);
        dispatch({ type: Types.HIDE_GROUP_ROWS, payload: [] });
        props.onCloseHandler();
    }
    // const groupName = (rowData: any) => {
    //     return (
    //         <>
    //             {rowData.rowId}
    //         </>
    //     )
    // }
    const renderCheckbox = (rowData: any, field: any) => {
        return (
            <>
                <input type="checkbox" onChange={(e) => onSelectFormHandler(e, field)} value={rowData.hide}
                    // defaultChecked={rowData.hide}
                    checked={rowData.hide}
                />
            </>
        )
    }
    console.log("...367", hideGroupRowsData);

    const validate = () => {
        let _notChecked = false

        hideGroupRowsData && hideGroupRowsData.visits.map((item: any) => {
            item.groupRows.map((i: any) => {
                if (!i.hide) {
                    _notChecked = true
                }
                return null
            })
            return null
        })
        return _notChecked

    }
    const onSubmitHandler = () => {
        const _validate = validate()
        console.log('hideGroupRowsData.......', _validate, hideGroupRowsData);
        if (_validate) {
            dispatch(updateGroupRows(hideGroupRowsData, (response: any) => {
                if (response.status === 200) {
                    onCloseHandler();
                    dispatch(toastAlert({ status: 1, message: 'Group rows updated successfully', open: true }))
                    props.setToastOpen(true)
                }
            }))
            setError('')
        } else {
            setError('Atleast one row should be show')
        }
    }

    const handleChange = (event: React.SyntheticEvent, newValue: number) => {
        setTabConextValue(newValue.toString());
    };

    console.log('99.......', error, hideGroupRowsData);
    return (
        <React.Fragment>
            <CustomDialog
                title={`Hide Group Rows (${props.group.name})`}
                onClose={onCloseHandler}
                onSubmitHandler={onSubmitHandler}
                open={open}
                maxWidth="md"
                actionType={'Submit'}
            >
                <CommonCard >
                    <div className="rows-hide">
                        <div className='d-flex justify-content-between mx-3'>
                            <h6>All Visits</h6>
                        </div>
                        <hr className="m-0"></hr>
                        <React.Fragment>
                            {hideGroupRowsData && <Box className="tab-container" >
                                <TabContext value={tabConextValue}>
                                    <Box sx={{ width: 300, height: 350, overflowY: 'auto' }} className="left-panel">
                                        <TabList
                                            variant="scrollable"
                                            onChange={handleChange}
                                            orientation='vertical'
                                            aria-label="lab API tabs example">
                                            {hideGroupRowsData && hideGroupRowsData?.visits?.map((element: any, item: any) => {
                                                return (
                                                    <Tab
                                                        className="title"
                                                        key={item}
                                                        value={`${element.visitId}`}
                                                        label={
                                                            <span className="d-flex">
                                                                <span className="pi pi-angle-double-right pe-2">
                                                                </span><p className="m-0" >{element.visitName}</p>
                                                            </span>}
                                                    />
                                                )
                                            })}
                                        </TabList>
                                    </Box>

                                    <div className="right-panel">
                                        {
                                            (hideGroupRowsData && hideGroupRowsData?.visits?.length > 0) && hideGroupRowsData?.visits?.map((element: any, index: any) => {
                                                // return <p>ytawfdtewhvdhawvdva</p>
                                                return (
                                                    <TabPanel value={`${element.visitId}`} key={index}>
                                                        <p>{element.visitName}</p>

                                                        <DataTable
                                                            value={element.groupRows}
                                                            scrollable
                                                            size="small"
                                                            scrollHeight="300px"
                                                            emptyMessage="No Rows To Display."
                                                            responsiveLayout="scroll"
                                                            selectionMode="single"
                                                        >
                                                            <Column field='rowId' header="Rows Count" style={{ width: 'auto' }} />
                                                            <Column body={renderCheckbox} header="Hide" style={{ width: '40%' }} />
                                                        </DataTable>
                                                    </TabPanel>
                                                )
                                            })
                                        }
                                    </div>
                                </TabContext>
                            </Box>}
                        </React.Fragment>
                        {(!hideGroupRowsData) && <p className="group-alert my-5 py-5">The given group is not assigned to any visit</p>}

                    </div>

                </CommonCard>

            </CustomDialog>
        </React.Fragment>
    )
}
export default RowsHide;