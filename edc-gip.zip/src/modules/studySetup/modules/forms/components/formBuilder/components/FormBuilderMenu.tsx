import React from "react";
import GroupVariable from "./GroupVariable";
import ImportVariables from "./ImportVariables";
import AddVariable from "./AddVariable";
import RearrangeVariable from "./RearrangeVariable";
import PreviewForm from "./PreviewForm";

function FormBuilderMenu(props: any) {
  const { currentFormName, setToastOpen } = props;

  return (

    <React.Fragment>
      <PreviewForm currentFormName={currentFormName} />
      <ul className="list-group list-group-flush">
        <GroupVariable type={0} groupId={{ id: 0 }} setToastOpen={setToastOpen} />
        <ImportVariables type={0} setToastOpen={setToastOpen} />
        <RearrangeVariable setToastOpen={setToastOpen} />
        <AddVariable params={{ id: 0 }} type={0} setToastOpen={setToastOpen} />
      </ul>
    </React.Fragment>

  )
}

export default FormBuilderMenu;