import React, { useState } from 'react';
import CustomDialog from '../../../../../../../common/modals/CustomeDialog'
import { Formik, Form, Field, FieldArray, } from "formik";
import AddCircleIcon from '@mui/icons-material/AddCircle';
import RemoveCircleIcon from '@mui/icons-material/RemoveCircle';
import { addUnits } from '../../../helpers/form-modal';
import { useDispatch } from 'react-redux';
import { createUnits, fetchAllUnits } from '../../../actions/actions';
import { toastAlert } from '../../../../../../../actions/actions';

function UnitDialog(props: any) {
    const dispatch = useDispatch();
    // const [btnDisable, setBtnDisable] = React.useState(true);
    const [msg, setMsg] = useState("");
    const onCloseHandler = () => {
        props.setOpenUnit(false)
        setMsg("")
    }
    const onSubmitHandler = (values: any) => {
        const validate = validateUnits(values)
        if (validate) {
            dispatch(createUnits(values.units, (response: any) => {
                if (!(response?.data?.errorMessage)) {
                    dispatch(fetchAllUnits())
                    onCloseHandler();
                }
                dispatch(toastAlert({
                    // status: 1,s
                    // message: 'unit added successfully',
                    open: true,
                    status: response.data.errorMessage ? 2 : 1,
                    message: response.data.errorMessage ? response.data.errorMessage : response.data,
                    // open: true
                }));
                // dispatch(fetchAllUnits())
            }))
        }
        // onCloseHandler();
    }

    const validateUnits = (values: any) => {
        let isDuplicate;
        let isEmpty = [];
        if (values.units) {
            const valueArr = values.units.map(function (item: any) { return item.units });
            isEmpty = values.units.filter((item: any) => item.units === "");
            isDuplicate = valueArr.some(function (item: any, idx: number) {
                return valueArr.indexOf(item) !== idx
            });
        }
        if (isDuplicate) {
            setMsg("Unit can't be same")
            return false;
        } else if (isEmpty.length > 0) {
            setMsg("Unit can't be empty")
            return false;
        } else {
            return true;
        }
    }
    return (
        <div>
            <CustomDialog
                title={'Add Units'}
                onClose={onCloseHandler}
                onSubmitHandler={() => { return null }}
                form={"unit"}
                open={props.openUnit}
                maxWidth={'xs'}
                actionType={'Submit'}
            >
                <div className='units'>
                    <div className="ps-2 ms-2">
                        <div>
                            <Formik
                                // enableReinitialize={true}
                                initialValues={addUnits}
                                // validationSchema={createUnitValidation}
                                onSubmit={(values: any) => {
                                    onSubmitHandler(values);
                                }}
                            >
                                {({ values, setFieldValue }) => (
                                    <Form id={"unit"}>
                                        <div className=''>
                                            <FieldArray
                                                name="units"
                                                render={(arrayHelpers) => {
                                                    const units = values.units;
                                                    return (
                                                        <div className="mx-2 mt-2">
                                                            <div className="d-flex mx-1">
                                                                <label id='label'>Unit:</label>
                                                                <AddCircleIcon
                                                                    className='text-primary mx-2 mb-1'
                                                                    fontSize='small'
                                                                    onClick={() => {
                                                                        const _validate = validateUnits(values);
                                                                        if (_validate) {
                                                                            setMsg("")
                                                                            arrayHelpers.push({
                                                                                id: 0,
                                                                                units: ""
                                                                            })
                                                                        }
                                                                    }} />
                                                            </div>
                                                            {units &&
                                                                units.map((data: any, index: number) => (
                                                                    <div key={index} className="d-flex w-100 mb-2">
                                                                        <div className="d-block col-12">
                                                                            <Field
                                                                                name={`units.${index}.units`}
                                                                                value={values.units[index].units}
                                                                                className="form-control"
                                                                                placeholder={"Enter unit"}
                                                                                onChange={(e: any) => {
                                                                                    if ((e.target.value.length <= 1 && !e.target.value.includes(' ')) || (e.target.value.length > 1 && !e.target.value.includes('  '))) {
                                                                                        setFieldValue(`units.${index}.units`, e.target.value)
                                                                                        // setBtnDisable(false)
                                                                                        setMsg("")
                                                                                    }
                                                                                }}
                                                                            >
                                                                            </Field>
                                                                        </div>
                                                                        <div>
                                                                            {units.length > 1 && <RemoveCircleIcon
                                                                                sx={{ cursor: 'pointer' }}
                                                                                color='error'
                                                                                className=""
                                                                                onClick={() => {
                                                                                    arrayHelpers.remove(index)
                                                                                    // setBtnDisable(false)
                                                                                }} />}
                                                                        </div>
                                                                    </div>
                                                                ))
                                                            }
                                                            {msg ? <p className="text-danger d-flex">{msg}</p> : <span>&nbsp;</span>}
                                                        </div>
                                                    )
                                                }}
                                            ></FieldArray>
                                        </div>
                                    </Form>
                                )}

                            </Formik>
                        </div>
                    </div>
                </div>
            </CustomDialog>
        </div>
    )
}

export default UnitDialog;



