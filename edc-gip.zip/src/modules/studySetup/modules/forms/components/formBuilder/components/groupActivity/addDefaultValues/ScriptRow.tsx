import React, { useState } from "react";
// import { useDispatch, useSelector } from "react-redux";
import { FieldArray } from 'formik';
// import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
// import { messages } from '../../../../../../../constants/messages'
// import CancelIcon from '@mui/icons-material/Cancel';
// import { MuiPickersUtilsProvider, KeyboardDatePicker } from "@material-ui/pickers";
import moment from "moment";
import MomentUtils from "@date-io/moment";
import { MuiPickersUtilsProvider, KeyboardDatePicker } from "@material-ui/pickers";
import { LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { useSelector } from "react-redux";
import PartialTime from "./PartialTime";



// -<KeyboardDatePicker />
// +<DatePicker />



function ScriptRow(props: any) {
  const { values, setFieldValue, errors, setErroeMsg, setDisableSubmit } = props;
  const { configCodes, currentStudy } = useSelector((state: any) => state.application);
  console.log("23...", configCodes)
  // const [selectedDate, handleDateChange] = useState<any>(new Date());
  // console.log("selected datev....", selectedDate)
  const [timeFields, setTimeFields] = useState([
    { label: 'hh', value: '' },
    { label: 'mm', value: '' },
    { label: 'ss', value: '' },
  ])
  return (
    <React.Fragment>
      <ul className="field-list">
        <React.Fragment>
          <FieldArray
            name="groupDefaultValues"
            render={() => {
              const fields: any = values.groupDefaultValues;
              console.log("33..", values.fieldDataTypeCode)
              switch (values.fieldDataTypeCode) {
                case configCodes?.partialdate:
                  return (
                    <React.Fragment>
                      {fields &&
                        fields.map((item: any, index: number) => {
                          return (
                            <li className="d-flex align-items-center datePicker-component" key={index}>
                              <div className="field-container">
                                <span className="index">{index + 1} </span>
                                <span className="field">
                                  <select value={item.defaultValue}
                                    className="mt-1 me-1"
                                    onChange={(e) => {
                                      setFieldValue(`groupDefaultValues[${index}].defaultValue`, e.target.value);
                                      setFieldValue(`groupDefaultValues[${index}].dateValue`, '');
                                      setErroeMsg('');
                                      // handleDateChange(new Date())
                                      setDisableSubmit(false)
                                    }}
                                  >
                                    <option value=''>Select Format</option>
                                    <option value={'monthAndYear'}>Month/Year</option>
                                    <option value={'year'}>Year</option>
                                    <option value={'date'}>Date</option>
                                  </select>
                                  {/* <input className={`form-control me-1 mb-2  
                                          ${item.validate && `border border-danger`}`}
                                    // type={item.defaultValue == "monthAndYear" ? 'month' : 'date'}
                                    type='date'
                                    date-format='YYYY'
                                    name={`groupDefaultValues[${index}].id`}
                                    onChange={(e) => {
                                      // setFieldValue(`groupDefaultValues[${index}].defaultValue`, e.target.value);
                                      // setErroeMsg('')

                                    }}
                                    value={''}
                                  /> */}
                                  <MuiPickersUtilsProvider libInstance={moment} utils={MomentUtils}>
                                    <KeyboardDatePicker
                                      autoOk
                                      inputVariant="outlined"
                                      disabled={item.defaultValue === "" ? true : false}
                                      className='mt-2 mb-2 me-1 datePicker-comp'
                                      // views={item.defaultValue == "monthAndYear" ? ["year", "month"] : item.defaultValue == "year" ? ["year"] : ["date", "month", "year"]}
                                      format={item.defaultValue === "monthAndYear" ? "MM/YYYY" : item.defaultValue === "year" ? "YYYY" : "DD/MM/YYYY"}
                                      InputProps={{
                                        style: {
                                          fontSize: 14,
                                          height: 29,
                                          width: 195
                                        }
                                      }}
                                      // emptyLabel={item.defaultValue == "monthAndYear" ? "MM/YYYY" : item.defaultValue == "year" ? "YYYY" : "DD/MM/YYYY"}
                                      placeholder={item.defaultValue === "monthAndYear" ? "MM/YYYY" : item.defaultValue === "year" ? "YYYY" : "DD/MM/YYYY"}
                                      InputAdornmentProps={{ position: "end" }}
                                      onChange={(e: any) => {
                                        const _momentDate = moment(e).format("MM/DD/YYYY");
                                        console.log('_momentDate.......', _momentDate)
                                        setFieldValue(`groupDefaultValues[${index}].dateValue`, _momentDate);
                                        setErroeMsg('');
                                        setDisableSubmit(false)
                                      }}
                                      value={props.values.groupDefaultValues[index].dateValue ? props.values.groupDefaultValues[index].dateValue : null}
                                      // value={'10/30/2022'}
                                      // onChange={handleDateChange}
                                      invalidDateMessage={false} />

                                  </MuiPickersUtilsProvider>
                                </span>
                              </div>
                              <span className="d-flex justify-content-start align-items-center" >
                                <input type={'checkbox'}
                                  id={`${props.id}_${index}`}
                                  name={`groupDefaultValues[${index}].readOnly`}
                                  onChange={(e) => {
                                    setFieldValue(`groupDefaultValues[${index}].readOnly`, e.target.checked);
                                    setErroeMsg('');
                                    setDisableSubmit(false);
                                  }}
                                  checked={item.readOnly} />
                                <label htmlFor={`${props.id}_${index}`}>Read Only</label>
                              </span>
                              {(errors && errors.groupDefaultValues && errors.groupDefaultValues[index]) ?
                                <p className='text-danger'>
                                  {errors.groupDefaultValues[index].defaultValue} </p> : ""}
                            </li>
                          )
                        })}
                    </React.Fragment>
                  )
                case configCodes?.date:
                  return (
                    <React.Fragment>
                      {fields &&
                        fields.map((item: any, index: number) => {
                          return (
                            <li className="d-flex" key={index}>
                              <div className="field-container">
                                <span className="index">{index + 1} </span>
                                <span className="field">
                                  <input className={`form-control me-1 mb-2  
                                          ${item.validate && `border border-danger`}`}
                                    type='date'
                                    name={`groupDefaultValues[${index}].id`}
                                    onChange={(e) => {
                                      setFieldValue(`groupDefaultValues[${index}].defaultValue`, e.target.value);
                                      setErroeMsg('')
                                      setDisableSubmit(false)
                                    }}
                                    value={item.defaultValue}
                                  />
                                </span>
                              </div>
                              <span className="d-flex justify-content-start align-items-center" >
                                <input type={'checkbox'}
                                  id={`${props.id}_${index}`}
                                  name={`groupDefaultValues[${index}].readOnly`}
                                  onChange={(e) => {
                                    setFieldValue(`groupDefaultValues[${index}].readOnly`, e.target.checked);
                                    setErroeMsg('')
                                    setDisableSubmit(false)
                                  }}
                                  checked={item.readOnly} />
                                <label htmlFor={`${props.id}_${index}`}>Read Only</label>
                              </span>
                            </li>
                          )
                        })}
                    </React.Fragment>
                  )
                case configCodes?.integer:
                  return (
                    <React.Fragment>
                      {fields &&
                        fields.map((item: any, index: number) => {
                          return (
                            <li className="d-flex" key={index}>
                              <div className="field-container">
                                <span className="index">{index + 1} </span>
                                <span className="field">
                                  <input className={`form-control me-1 mb-2  
                                          ${item.validate && `border border-danger`}`}
                                    type='number'
                                    onKeyPress={(e: any) => {
                                      if (e.key === "-" || e.key === "+" || e.key === "e" || e.key === ".") {
                                        e.preventDefault();
                                      }
                                    }}
                                    name={`groupDefaultValues[${index}].id`}
                                    onChange={(e) => {
                                      const { value } = e.target;
                                      const regex = /^(0*[0-9][0-9]*(\.[0-9]*)?|0*\.[0-9]*[1-9][0-9]*)$/;
                                      if (!value || regex.test(value.toString())) {
                                        setFieldValue(`groupDefaultValues[${index}].defaultValue`, value);
                                        setErroeMsg('')
                                        setDisableSubmit(false)
                                      }
                                    }}
                                    value={item.defaultValue}
                                  />
                                </span>
                              </div>
                              <span className="d-flex justify-content-start align-items-center" >
                                <input type={'checkbox'}
                                  id={`${props.id}_${index}`}
                                  name={`groupDefaultValues[${index}].readOnly`}
                                  onChange={(e) => {
                                    setFieldValue(`groupDefaultValues[${index}].readOnly`, e.target.checked);
                                    setErroeMsg('')
                                    setDisableSubmit(false)
                                  }}
                                  checked={item.readOnly} />
                                <label htmlFor={`${props.id}_${index}`}>Read Only</label>
                              </span>
                            </li>
                          )
                        })}
                    </React.Fragment>
                  )
                case configCodes?.string:
                  return (
                    <React.Fragment>

                      {fields &&
                        fields.map((item: any, index: number) => {
                          return (
                            <li key={index}>
                              <div className="d-flex justify-content-start align-items-center">
                                <div className="field-container">
                                  <span className="index">{index + 1} </span>
                                  <span className="field">
                                    <input className={`form-control me-1 mb-2  
                                          ${item.validate && `border border-danger`}`}
                                      type='text'
                                      name={`groupDefaultValues[${index}].id`}
                                      onChange={(e) => {
                                        setFieldValue(`groupDefaultValues[${index}].defaultValue`, e.target.value);
                                        setErroeMsg('')
                                        setDisableSubmit(false)
                                      }}
                                      value={props.values.groupDefaultValues[index].defaultValue}
                                    />
                                  </span>

                                </div>
                                <span className="d-flex justify-content-start align-items-center" >
                                  <input type={'checkbox'}
                                    id={`${props.id}_${index}`}
                                    name={`groupDefaultValues[${index}].readOnly`}
                                    onChange={(e) => {
                                      setFieldValue(`groupDefaultValues[${index}].readOnly`, e.target.checked);
                                      setErroeMsg('')
                                      setDisableSubmit(false)
                                    }}
                                    checked={item.readOnly} />
                                  <label htmlFor={`${props.id}_${index}`}>Read Only</label>
                                </span>
                              </div>
                              {(errors && errors.groupDefaultValues && errors.groupDefaultValues[index]) ?
                                <p className='text-danger'>
                                  {errors.groupDefaultValues[index].defaultValue} </p> : ""}
                            </li>
                          )
                        })}
                    </React.Fragment>
                  )
                case configCodes?.real:
                  return (
                    <React.Fragment>

                      {fields &&
                        fields.map((item: any, index: number) => {
                          return (
                            <li key={index}>
                              <div className="d-flex justify-content-start align-items-center">
                                <div className="field-container">
                                  <span className="index">{index + 1} </span>
                                  <span className="field">
                                    <input className={`form-control me-1 mb-2  
                                          ${item.validate && `border border-danger`}`}
                                      type='number'
                                      name={`groupDefaultValues[${index}].id`}
                                      onKeyPress={(e: any) => {
                                        if (e.key === "-" || e.key === "+" || e.key === "e") {
                                          e.preventDefault();
                                        }
                                      }}
                                      onChange={(e) => {
                                        setFieldValue(`groupDefaultValues[${index}].defaultValue`, e.target.value);
                                        setErroeMsg('')
                                        setDisableSubmit(false)
                                      }}
                                      value={props.values.groupDefaultValues[index].defaultValue}
                                    />

                                  </span>

                                </div>
                                <span className="d-flex justify-content-start align-items-center" >
                                  <input type={'checkbox'}
                                    id={`${props.id}_${index}`}
                                    name={`groupDefaultValues[${index}].readOnly`}
                                    onChange={(e) => {
                                      setFieldValue(`groupDefaultValues[${index}].readOnly`, e.target.checked);
                                      setErroeMsg('')
                                      setDisableSubmit(false)
                                    }}
                                    checked={item.readOnly} />
                                  <label htmlFor={`${props.id}_${index}`}>Read Only</label>
                                </span>
                              </div>
                              {(errors && errors.groupDefaultValues && errors.groupDefaultValues[index]) ?
                                <p className='text-danger'>
                                  {errors.groupDefaultValues[index].defaultValue} </p> : ""}
                            </li>
                          )
                        })}
                    </React.Fragment>
                  )
                case configCodes?.time:
                  return (
                    <React.Fragment>
                      {fields &&
                        fields.map((item: any, index: number) => {
                          return (
                            <li className="d-flex" key={index}>
                              <div className="field-container">
                                <span className="index">{index + 1} </span>
                                <span className="field">
                                  <input className={`form-control me-1 mb-2  
                                          ${item.validate && `border border-danger`}`}
                                    type='Time'
                                    name={`groupDefaultValues[${index}].id`}
                                    onChange={(e) => {
                                      setFieldValue(`groupDefaultValues[${index}].defaultValue`, e.target.value);
                                      setErroeMsg('')
                                      setDisableSubmit(false)
                                    }}
                                    value={item.defaultValue}
                                  />
                                </span>
                              </div>
                              <span className="d-flex justify-content-start align-items-center" >
                                <input type={'checkbox'}
                                  id={`${props.id}_${index}`}
                                  name={`groupDefaultValues[${index}].readOnly`}
                                  onChange={(e) => {
                                    setFieldValue(`groupDefaultValues[${index}].readOnly`, e.target.checked);
                                    setErroeMsg('')
                                    setDisableSubmit(false)
                                  }}
                                  checked={item.readOnly} />
                                <label htmlFor={`${props.id}_${index}`}>Read Only</label>
                              </span>
                            </li>
                          )
                        })}
                    </React.Fragment>
                  )
                case configCodes?.PartialTime:
                  return (
                    <>
                      {fields &&
                        fields.map((item: any, index: number) => {
                          return (
                            <li className="d-flex" key={index}>
                              <div className="d-flex">
                                <span className="index">{index + 1} </span>
                                <span className="d-flex">
                                  <>{console.log("374...",values)}</>
                                  <PartialTime item={item} index={index} setFieldValue={setFieldValue} setDisableSubmit={setDisableSubmit} setErroeMsg={setErroeMsg} />
                                </span>
                              </div>
                              <div>
                                <span className="d-flex justify-content-start align-items-center" >
                                  <input type={'checkbox'}
                                    id={`${props.id}_${index}`}
                                    name={`groupDefaultValues[${index}].readOnly`}
                                    onChange={(e) => {
                                      setFieldValue(`groupDefaultValues[${index}].readOnly`, e.target.checked);
                                      setErroeMsg('')
                                      setDisableSubmit(false)
                                    }}
                                    checked={item.readOnly} />
                                  <label htmlFor={`${props.id}_${index}`}>Read Only</label>
                                </span>
                              </div>
                            </li>

                          )
                        })}
                    </>
                  )
                default:
                  return (<div className="e-alert-info w-100 py-5 my-3" role="alert">
                    <>{console.log("34...", configCodes)}</>
                    <h6>No variables are available to display !</h6>
                    <span> Please select variable from dropdown!</span>
                  </div>)
              }
            }}
          />
        </React.Fragment>

      </ul>
      {/* {(values && values.groupDefaultValues && values.groupDefaultValues.length <= 0) &&
        (<div className="e-alert-info w-100 py-5 my-3" role="alert">
          <h6>No Deafault values foud to display!</h6>
          <span> Please select variable from dropdown!</span>
        </div>)
      } */}
    </React.Fragment>
  )
}

export default ScriptRow;