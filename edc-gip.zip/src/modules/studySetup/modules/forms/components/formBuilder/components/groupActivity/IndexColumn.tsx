import React from "react";
import CustomDialog from "../../../../../../../../common/modals/CustomeDialog";

function IndexColumn(props: any) {


    // const { indexOpen, setIndexOpen } = props;

    const [open, setOPen] = React.useState(false);


    React.useEffect(() => {
        if (props.page === 3) {
            setOPen(true);
        }
    }, [props.page])

  

    const onCloseHandler = () => {
        setOPen(false);
        props.onCloseHandler();
    }

    return (
        <React.Fragment>
            <CustomDialog
                title={'Index Columns'}
                onClose={onCloseHandler}
                onSubmitHandler={() => {return null }}
                open={open}
                maxWidth="md"
                actionType={'Add'}
                form="indexColumn-submit"
            >
            </CustomDialog>
            <React.Fragment>
                {/* <Tooltip title="Index Column" >
                    <span className="ms-1">
                        <ViewColumnOutlinedIcon onClick={() => onIndexColumn(null)} /></span>
                </Tooltip> */}
            </React.Fragment>
        </React.Fragment>
    )
}
export default IndexColumn;