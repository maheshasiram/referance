import React, {useState } from "react";
import CustomDialog from "../../../../../../../../common/modals/CustomeDialog";
import { useDispatch, useSelector } from "react-redux";
import { importUngroupedParam } from "../../../../helpers/form-modal";
import { getFormsDetailsId, exportGroupedToUngrouped } from "../../../../actions/actions";
import { toastAlert } from "../../../../../../../../actions/actions";
import AddVariable from "../AddVariable";

function ExportGroup(props: any) {
  const dispatch = useDispatch();
  // const exportToast = useRef<any | null>(null);
  const [errorMsg, setErrorMsg] = React.useState('');
  const [exportGrouped, setexportGrouped] = React.useState<any | null>([]);
  const [open, setOPen] = React.useState(false);
  const [disableSubmit, setDisableSubmit] = useState(true)
  const [selectAll, setSelectAll] = useState(false)
  const { formDetails } = useSelector((state: any) => state.forms);
  React.useEffect(() => {
    if (props.page === 1) {
      setOPen(true);
      const _allFields: any = []
      const _fields = formDetails.formFields[props.groupIndex].group.fields
      _fields && _fields.length > 0 && _fields.map((item: any) => {
        if(item.status){
          _allFields.push({ ...item, checked: false })
        }
        return null;
      })
      setexportGrouped(_allFields)

    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dispatch, props.page])

  const onCloseHandler = () => {
    props.onClose();
    setOPen(false);
    setexportGrouped([]);
    setDisableSubmit(true)
    setErrorMsg('');
    setSelectAll(false)
  }

  const onChangeHandler = (e: any, groupItem: any, index: number) => {
    const _exportVariables = [...[], ...exportGrouped];
    _exportVariables[index].checked = e.target.checked;
    let count = 0
    _exportVariables.map((item: any) => {
      if (!item.checked) { count = count + 1 }
      return null;
    })

    setSelectAll(count > 0 ? false : true)
    setexportGrouped(_exportVariables)
    setErrorMsg('')
    setDisableSubmit(false)
  }

  const onSelectAllHandler = () => {
    console.log("on click select all")
    setSelectAll(selectAll ? false : true)
    const _data = [...[], ...exportGrouped]
    exportGrouped.map((item: any, index: number) => {
      _data[index].checked = selectAll ? false : true
      return null
    })
    setexportGrouped(_data)
    setDisableSubmit(selectAll ? true : false)
  }

  const ValidateFields = () => {
    const payload: any = []
    exportGrouped && exportGrouped.length > 0 && exportGrouped.map((item: any) => {
      if (item.checked) {
        const _exportUngroupedParam = { ...{}, ...importUngroupedParam }
        _exportUngroupedParam.groupId = item.groupId;
        _exportUngroupedParam.formId = item.formId;
        _exportUngroupedParam.id = item.id;
        _exportUngroupedParam.ordinal = item.ordinal;
        _exportUngroupedParam.variableId = item.variableId;
        _exportUngroupedParam.variableText = item.variableText;
        payload.push(_exportUngroupedParam)
      }
      return null;
    })
    return payload
  }
  const onSubmit = () => {
    const validate = ValidateFields();
    if (validate.length > 0) {
      dispatch(exportGroupedToUngrouped(props.groupId, validate, (response: any) => {
        if(response.data.status === "error"){
          onCloseHandler();
          dispatch(getFormsDetailsId(props.params.id, (response: any) => { console.log(response) }))
          dispatch(toastAlert({ status: 2, message: response.data.errorMessage, open: true }))
          props.setToastOpen(true)
        }
        else {
          onCloseHandler();
          dispatch(getFormsDetailsId(props.params.id, (response: any) => { console.log(response) }))
          dispatch(toastAlert({ status: 1, message: response.data, open: true }))
          props.setToastOpen(true)
        }
      }))
    }
    else {
      setErrorMsg("Please select atleast one");
    }
  }
  // console.log('exportGrouped......', exportGrouped, exportGrouped.length>0 && (exportGrouped.filter((i:any)=>i.status==true)).length );

  return (
    <React.Fragment>
      {/* <span className="ms-1"><BackupOutlinedIcon /></span> */}
      <CustomDialog
        title={'Export variables'}
        onClose={onCloseHandler}
        onSubmitHandler={onSubmit}
        open={open}
        maxWidth="sm"
        fullWidth={false}
        padding={true}
        actionType={'Submit'}
        form="addGroup"
        disabled={disableSubmit}
      >
        <div className="Import-group import-export-container">
          <div className="ig-header">
            <span> Export Group variables to non-group variables</span>
            {
            // (exportGrouped && exportGrouped.length>0 && ((exportGrouped.filter((i:any)=>i.status==true)).length>0) ) &&
            (exportGrouped.length > 0) &&
              <div className="select-all" onClick={() => onSelectAllHandler()}>{!selectAll ? "Select All" : "Deselect All"}</div>
            }
          </div>
          <div className="ig-variable">
            {errorMsg && <div className='text-danger d-flex justify-content-center mt-2'>{errorMsg}</div>}
            <ul className="list-items">
              {exportGrouped && exportGrouped.length > 0 && exportGrouped.map(
                (item: any, index: number) => {
                  // if (item.status) {
                    return (<li key={index}>
                      <input className="chekbox" type="checkbox" id={`chkbx-import-${item.id}`}
                        checked={item.checked}
                        onChange={(e) => onChangeHandler(e, item, index)} />
                      <label htmlFor={`chkbx-import-${item.id}`} className="variable-text"> {item.variableText}</label>
                    </li>)
                  // }
                })
              }
            </ul>
            {exportGrouped.length === 0  &&
                <div className="e-alert-info w-100 py-5" role="alert">
                  <h6>No variables available to display</h6>
                   Please add {/*<a href="#/">add new</a>*/} <AddVariable params={{ id: 0 }} />variable
                </div>
              }
          </div>
        </div>
      </CustomDialog>
    </React.Fragment>
  )
}
export default ExportGroup;