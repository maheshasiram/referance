import { Loader } from "../../../../../actions/actions";
import { studySetup } from "../../../../../configs/enivornment/studySetup";
import { fetch } from "../../../../../constants/fetch";
// import { rulePayload } from "../../rules/constants/rules-modals";
import { Types } from "../reducers/Types";

export const fetchAllDerivationsForms: any = (studyId: any, callback: any) => {
  const url = studySetup.derivations.fetchAllDerivationsFroms + `?studyId=${studyId}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
    })
      .then((response: any) => {
        dispatch({ type: Types.GET_ALL_DERIVATIONS_FORMS, payload: response.data });
        dispatch(Loader(false));
        callback(response.data);
      })
      .catch(() => {
        // dispatch(Loader(false));
      })
  }
}
export const deleteDerivativeById: any = (id: any, callback: any) => {
  const url = studySetup.derivations.deleteDerivative + `?id=${id}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'post',
      url: url,
    })
      .then((response: any) => {
        if (callback) {callback(response)}
        dispatch(Loader(false));
      })
  }
}

export const restoreDerivativeById: any = (id: any, callback: any) => {
  const url = studySetup.derivations.restoreDerivative + `?id=${id}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'post',
      url: url,
    })
      .then((response: any) => {
        if (callback) {callback(response)}
        dispatch(Loader(false));
      })
  }
}
// api for fetch tree view
export const fetchTreeViewData: any = (studyId: any) => {
  const url = `${studySetup.treeViewData}?studyId=${studyId}`;

  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        const _response = [...[], ...response.data.data];
        _response.map((item, index) => {
          _response[index].key = index
          if (item.children && item.children.length > 0) {
            item.children.map((child: any, ci: any) => {
              if (_response[index].children[ci].children) {
                return _response[index].children[ci].key = `${index}-${ci}`;
              }
              return null
            });
          }
          return null
        })
        const _data: any = []
        _response.map((item: any) => {
          if (item.children.length > 0) {
            _data.push(item);
          }
          return null
        })
        _data.sort((a: any, b: any) => {
          if (a.label?.toLowerCase() < b.label?.toLowerCase()) { return -1; }
          if (a.label?.toLowerCase() > b.label?.toLowerCase()) { return 1; }
          return 0
        })
        dispatch({ type: Types.FETCH_TREEVIEW_DATA, payload: _data })
        dispatch(Loader(false));
      })
  }
}

export const setCaliculatedVariable = (derivation: any, node: any) => {
  const payload = { ...{}, ...derivation }
  payload.targetVariables.push({
    ...node,
    targetVarDisplayStatus: true
  })
  return payload;
}

export const setDependentCaliculatedVariable = (derivation: any, node: any, dispatch: any) => {
  console.log(dispatch)
  const payload = { ...{}, ...derivation }
  const dependentTargetVariable = setTargetAndDependentTagetPayload(node);
  payload.dependentTargetVar.push({
    ...dependentTargetVariable,
  })
  return payload;
}


export const resetCaliculateVariable = (derivation: any, index: number) => {
  const payload = { ...{}, ...derivation }
  payload.target.targetVariables.splice(index, 1);
  if (payload.target.targetVariables.length === 0) {
    payload.logic.visitId = "";
    payload.logic.logicVariables = (payload.logic.formula) && payload.logic.formula.formulaCode === 'BMI' ?
      [{
        operation: "/",
        numeratorFields: [],
        denominatorFields: []
      }] : (payload.logic.formula) && payload.logic.formula.formulaCode === 'AGE' ? [
        {
          operation: "/",
          numeratorFields: [],
          denominatorFields: [{ value: 365 }]
        }
      ] : [];
    payload.target.targetFormIds = [];
    payload.target.targetFieldIds = [];
    payload.target.targetVisitIds = [];
  }
  return payload;
}

export const resetTargetCaliculateVariable = (derivation: any, index: number) => {
  const payload = { ...{}, ...derivation }
  payload.dependentTargetVar.splice(index, 1);
  if (payload.dependentTargetVar.length === 0) {
    console.log("")
  }
  return payload;
}

export const resetLogicVariable = (derivation: any, index: number, type: string) => {
  const payload = { ...{}, ...derivation }
  console.log("...delete", payload);
  payload.logic.logicVariables[index].dataType = ''
  payload.logic.logicVariables[index].fieldId = ''
  payload.logic.logicVariables[index].formId = ''
  payload.logic.logicVariables[index].itemName = ''
  payload.logic.logicVariables[index].type = type
  payload.logic.logicVariables[index].units = ''
  return payload;
}

export const resetDependentTargetVariable = (derivation: any, index: number, type: string) => {
  const payload = { ...{}, ...derivation }
  payload.dependentTargetVar[index].dataType = ''
  payload.dependentTargetVar[index].formId = ''
  payload.dependentTargetVar[index].fieldName = ''
  payload.dependentTargetVar[index].fieldId = ''
  payload.dependentTargetVar[index].type = type
  payload.dependentTargetVar[index].visitId = null
  return payload;
}

export const setLogicVariable = (derivation: any, node: any, type: any, index: number) => {
  const _derivation = { ...{}, ...derivation }
  _derivation.logic.logicVariables[index].dataType = node.datatype.name
  _derivation.logic.logicVariables[index].fieldId = node.id
  _derivation.logic.logicVariables[index].formId = node.formId
  _derivation.logic.logicVariables[index].formName = node.formName
  _derivation.logic.logicVariables[index].itemName = node.label
  _derivation.logic.logicVariables[index].groupId = node.groupId
  _derivation.logic.logicVariables[index].type = type
  _derivation.logic.logicVariables[index].units = node.units
  _derivation.logic.logicVariables[index].updatedUnit = ''
  return _derivation;
}

export const setDependentTargetVariable = (derivation: any, node: any, type: any, index: number) => {
  const _derivation = { ...{}, ...derivation }
  const targetVisits: any = [];
  _derivation.target.targetVariables.map((ele: any) => {
    if (ele.visitsIds.length > 0) {
      ele.visitsIds.map((item: any) => {
        targetVisits.push(item.value);
        return null
      })
    }
    return null
  })
  _derivation.dependentTargetVar[index].dataType = node.datatype.name
  _derivation.dependentTargetVar[index].fieldId = node.id
  _derivation.dependentTargetVar[index].fieldName = node.label
  _derivation.dependentTargetVar[index].formId = node.formId
  _derivation.dependentTargetVar[index].type = type
  _derivation.dependentTargetVar[index].visitId = targetVisits
  return _derivation;
}

// action for pushing div into logic
export const setLogicElements = (logicValues: any, derivation: any) => {
  const _logicValues = [...[], ...logicValues]
  const _derivation = { ...{}, ...derivation }
  _logicValues.map((item: any) => {
    _derivation.logic.logicVariables.push({
      dataType: '',
      // eventOid: '',
      itemName: '',
      fieldId: '',
      formId: '',
      type: item
    })
    return null
  })
  return _derivation
}

export const setDependetTragetElements = (logicValues: any, derivation: any) => {
  const _logicValues = [...[], ...logicValues]
  const _derivation = { ...{}, ...derivation }
  _logicValues.map((item: any) => {
    _derivation.dependentTargetVar.push({
      dataType: '',
      fieldName: '',
      fieldId: '',
      formId: '',
      visitId: '',
      type: item
    })
    return null
  })
  return _derivation
}

export const onDragElement = (e: any) => {
  e.preventDefault();
}


export const searchByTargetVariableCriteria: any = (payload: any, callback: any) => {
  const url = `${studySetup.derivations.searchByTargetVariableCriteria}?fieldName=${payload}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: '',
    })
      .then((response: any) => {
        dispatch({ type: Types.FIND_DERIVATIVE_BY_ID, payload: response.data });
        if (callback) { callback(response.data) }
        dispatch(Loader(false));
      })
  }
}

export const saveDerivation: any = (payload: any, callback: any) => {
  const url = studySetup.derivations.saveDerivation
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: url,
      data: payload,
    })
      .then((response: any) => {
        if (callback) { callback(response) }
        dispatch(Loader(false));
      })
  }
}

// api for update derivaton
export const updateDerivation: any = (payload: any, callback: any) => {
  const url = studySetup.derivations.updateDerivation
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: url,
      data: payload,
    })
      .then((response: any) => {
        if (callback) { callback(response) }
        dispatch(Loader(false));
      })
  }
}

//api for units
export const fetchDerivationUnits: any = (payload: any, callback: any) => {
  const url = studySetup.derivations.units
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: '',
    })
      .then((response: any) => {
        dispatch({ type: Types.GET_ALL_UNITS, payload: response.data });
        if (callback) { callback(response) }
        dispatch(Loader(false));
      })
  }
}

//api for formula
export const fetchDerivationFormula: any = (payload: any, callback: any) => {
  const url = studySetup.formula
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: '',
    })
      .then((response: any) => {
        dispatch({ type: Types.GET_ALL_FORMULA, payload: response.data });
        if (callback) { callback(response) }
        dispatch(Loader(false));
      })
  }
}
// api for edit derivation
export const editDerivation: any = (payload: any) => {
  const url = `${studySetup.derivations.editDerivation}?id=${payload}`
  return function (dispatch: any) {
    fetch({
      method: 'GET',
      url: url,
      data: '',
    })
      .then((response: any) => {
        const _payload = { ...{}, ...response.data };
        if (_payload.customDerivationType != null && _payload.dependentTargetVar !== "") {
          _payload.dependentTargetVar = JSON.parse(response.data.dependentTargetVar)
        }
        _payload.logic = JSON.parse(response.data.logic);
        dispatch({ type: Types.CREATE_DERIVATION, payload: _payload })
      })
  }
}

export const fetchVisitsAssignedToFieldId: any = (payload: any, callback: any) => {
  const url = `${studySetup.derivations.fetchVisitsAssignedToFieldId}?fieldId=${payload}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: '',
    })
      .then((response: any) => {
        dispatch({ type: Types.SELECT_VISIT_IN_DERIVATION, payload: response.data });
        if (callback) { callback(response) }
        dispatch(Loader(false));
      })
  }
}


export const searchByDerivationType: any = (payload: any, callback: any) => {
  const url = `${studySetup.derivations.searchByDerivationType}?studyId=${payload}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: '',
    })
      .then((response: any) => {
        dispatch({ type: Types.FIND_DERIVATIVE_TYPE, payload: response.data });
        callback(response.data);
        dispatch(Loader(false));
      })
  }
}

export const fetchFindByAllByCriteria: any = (payload: any, callback: any) => {
  const url = studySetup.derivations.findByAllByCriteria
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      url: url,
      data: payload,
    })
      .then((response: any) => {
        if (callback) { callback(response.data) }
        dispatch({ type: Types.FETCH_ALL_DERIVATONS, payload: response.data })
        dispatch(Loader(false));
      })
  }
}


export const fetchAllVistis: any = (payload: any, callback: any) => {
  const url = `${studySetup.visits.rearrangeVisits}?studyId=${payload}`
  return function (dispatch: any) {
    dispatch(Loader(true))
    fetch({
      method: 'GET',
      url: url,
      data: null,
    })
      .then((response: any) => {
        if (callback) { callback(response.data) }
        const _data: any = [];
        if (response.data) {
          response.data.length > 0 && response.data.map((i: any) => {
            _data.push({ label: i.visitName, value: i.id });
            return null
          })
        }
        dispatch({ type: Types.GET_ALL_VISTIS, payload: _data })
        dispatch(Loader(false))
      })
  }
}

//to set target and dependent target payload

export const setTargetAndDependentTagetPayload = (node: any) => {
  const _payload = {
    id: node.id,
    formId: node.formId,
    formName: node.formName,
    groupId: node.groupId,
    variableId: node.variableId,
    variableText: node.variableText,
    label: node.label,
    ordinal: node.ordinal,
    repeatNumber: node.repeatNumber,
    dataType: node.dataType,
    status: node.status,
    units: node.units,
    responseType: {
      id: node.responseType.id,
      name: node.responseType.name,
      code: node.responseType.code
    },
    datatype: {
      id: node.datatype.id,
      name: node.datatype.name,
      code: node.datatype.code
    },
    readOnly: node.readOnly,
    responseOptionExist: node.responseOptionExist,
    responseOptions: node.responseOptions,
    onAirInstruction: node.onAirInstruction,
    missingCheck: node.missingCheck,
    spellCheck: node.spellCheck,
    minValueLength: node.minValueLength,
    maxValueLength: node.maxValueLength,
    isFutureDate: node.isFutureDate,
    selected: node.selected,
    deSelected: node.deSelected,
    targetVarDisplayStatus: node.targetVarDisplayStatus,
  }
  return _payload;
}

// to set target variables in derivation payload
export const setTargetVariablesElements = (dispatch: any, node: any, derivation: any) => {
  const _visitsList: any = []
  const _derivation = { ...{}, ...derivation }
  console.log("...476", node);
  node.visits.map((visit: any) => {
    _visitsList.push({ label: visit.visitName, value: visit.id });
    return null
  })
  // dispatch(fetchVisitsAssignedToFieldId(node.id, (response: any) => {
  //   if (response.data) {
  //     response.data.length > 0 && response.data.map((visit: any) => {
  //       _visitsList.push({ label: visit.visitName, value: visit.id });
  //       return null
  //     })
  //   }
    const targetVar = setTargetAndDependentTagetPayload(node);
    _derivation.target.targetVariables.push({
      // ...node,
      ...targetVar,
      visitsIds: [],
      visitList: _visitsList,
    })
    // _derivation.target.targetFormIds_be.push(node.formId)
    // _derivation.target.targetfieldIds_be.push(node.id)
    const _targetFormIds_be = _derivation.target.targetVariables.map((ele: any) => (ele.formId));
    const _targetfieldIds_be = _derivation.target.targetVariables.map((ele: any) => (ele.id));
    _derivation.target.targetFormIds = _targetFormIds_be.toString();
    _derivation.target.targetFieldIds = _targetfieldIds_be.toString();
  // }))
  return _derivation
}


