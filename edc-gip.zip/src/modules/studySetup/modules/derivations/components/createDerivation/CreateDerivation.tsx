import { useNavigate, useParams } from "react-router-dom";
import '../../styles/derivations.scss';
import React from 'react';
import { useDispatch, useSelector } from "react-redux";
import DerivationType from './DerivationType'
import DateCaliculation from "./dateDerivation/DateCaliculation";
import TimeCaliculation from "./timeDerivation/TimeCaliculation";
import AutoPopulation from './autoPopulation/AutoPopulation'
import NumaricCaliculation from "./numericDerivation/NumaricCaliculation";
import FileNameAutoPopulation from "./fileNameAutoPopulate/FileNameAutoPopulation";
import KeyboardDoubleArrowLeftIcon from '@mui/icons-material/KeyboardDoubleArrowLeft';
import AddCustomVariable from "../../../../../../common/Assests/Images/AddCustomVariable.png"
import TreeviewComponent from "../../../../../../components/TreeviewComponent";
import { fetchTreeViewData, saveDerivation, fetchFindByAllByCriteria, updateDerivation, editDerivation, fetchDerivationUnits } from "../../actions/actions";
import Footer from "./Footer";
import { validateOnSubmit } from '../../helpers/Validations';
import { toastAlert } from "../../../../../../actions/actions";
import { Types } from "../../reducers/Types";
import CustomeDerivationDashboard from "./customDerivation/CustomeDerivationDashboard";
import { derivationModal } from "../../constants/modal";
import _ from "lodash";

function CreateDerivation() {
  const dispatch = useDispatch();
  const params: any = useParams();
  const { derivation, treePayload, derivationParams, allUnits } = useSelector((state: any) => state.derivations);
  const { configCodes } = useSelector((state: any) => state.application);
  const navigate = useNavigate();
  const [node, setNode] = React.useState({});
  const { currentStudy } = useSelector((state: any) => state.application)
  const [validations, setValidations] = React.useState({ target: "", dependentTarget: "", logic: "" });
  const loaded = React.useRef(false);
  const [btnDisabled, setBtnDisabled] = React.useState(true);
  let actionType: any;
  // const [actionType, setActionType] = React.useState('')
  const code = derivation?.actionType?.code;
  const [units, setUnits] = React.useState(null)

  React.useEffect(() => {
    const _units = allUnits && allUnits.map((i: any) => {
      const obj = {
        id: i.units,
        formName: i.units
      }
      return obj
    });
    setUnits(_units)
  }, [allUnits]);

  React.useEffect(() => {
    if (!loaded.current) {
      dispatch({ type: Types.FETCH_TREEVIEW_DATA, payload: null })
      if (parseInt(params.id) > 0) {
        dispatch(editDerivation((params.id)));
      }
      dispatch(fetchTreeViewData(currentStudy.id));
      dispatch(fetchDerivationUnits());
      loaded.current = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onGetNodeDetails = (node: any) => {
    setNode(node);
  }

  const backToDerivations = () => {
    const _payload = { ...derivationParams, studyId: currentStudy.id, offset: 0, formId: null, fieldName: null, configId: null }
    dispatch({ type: Types.FIND_ALL_BY_CRITERIA, payload: _payload });
    dispatch({ type: Types.CREATE_DERIVATION, payload: derivationModal });
    dispatch(fetchFindByAllByCriteria(_payload));
    navigate('/study/derivation');
  }

  const onSubmitHandler = () => {
    const validations = validateOnSubmit(derivation);
    if (validations !== true) {
      setValidations(validations);
    } else {
      setValidations({ target: "", dependentTarget: "", logic: "" });
      const payload = _.cloneDeep(derivation);
      const allSelectedVisits: any = [];
      let _dependentFieldIDs = payload.dependentFieldIds.toString();
      payload.target.targetVariables.map((ele: any, index: number) => {
        const targetVisits: any = [];
        delete ele.visitList
        if (ele.visitsIds.length > 0) {
          ele.visitsIds.map((item: any) => {
            targetVisits.push(item.value);
            return null
          });
        }
        allSelectedVisits.push(targetVisits.toString())
        payload.target.targetVariables[index].visitsIds = targetVisits;
        return null
      });
      payload.target.targetVisitIds = allSelectedVisits.toString();
      payload.logic = JSON.stringify(payload.logic);
      payload.dependentFieldIds = _dependentFieldIDs
      if (payload.dependentTargetVar.length > 0) {
        payload.dependentTargetVar = JSON.stringify(payload.dependentTargetVar);
      } else {
        payload.dependentTargetVar = ""
      }
      console.log("...104", payload, _dependentFieldIDs);
      dispatch((payload.id ? updateDerivation : saveDerivation)(payload, (response: any) => {
        if (response.data.status === "error") {
          dispatch(toastAlert({
            status: 2, message: `${response.data.errorMessage}`, open: true
          }))
        }
        else {
          dispatch(toastAlert({
            status: 1, message: ` ${payload.actionType.name} Derivation ${payload.id ? 'Updated' : 'Created'} Successfully`, open: true
          }));
          dispatch({ type: Types.CREATE_DERIVATION, payload: derivationModal });
          navigate('/study/derivation')
        }
      })
      )
    }
  }

  const onSetValidations = (validation: any) => {
    setValidations({ ...validations, ...validation });
  }

  const onCustomDrag = (e: any) => {
    setNode(e.target.id);
  }

  const ondragEnd = () => {
    setNode({})
  }

  const onGroupVariable = () => {
    let success = false;
    if (derivation.actionType.code === configCodes.NumericCalculation || derivation.actionType.code === configCodes.VariableAutoPopulation ||
      derivation.actionType.code === configCodes.FileAutoPopulation || derivation.actionType.code === configCodes.CustomDerivation) {
      success = true
    }
    return !success ? '' : 'derivatives'
  }

  return (
    <React.Fragment>
      <div className="layout-container">
        <div className="form-header ">
          <h6>{parseInt(params.id) > 0 ? "Update Derivation" : "Create Derivation"} {derivation.id ? <span>({derivation && derivation.target.targetVariables[0].formName})</span> : ""} </h6>
          <span onClick={backToDerivations} className="btn-back"><KeyboardDoubleArrowLeftIcon /> Back To Derivations</span>
        </div>
        <div className="main-panel">
          <div className="left-panel">
            <div className="content-container">
              <DerivationType setValidations={setValidations} setBtnDisabled={setBtnDisabled} code={code} />
              {(code) ?
                (
                  <React.Fragment>
                    {code === configCodes?.DateCalculation && <DateCaliculation node={node} setBtnDisabled={setBtnDisabled} onSetValidations={onSetValidations} validations={validations} units={units} />}
                    {code === configCodes?.TimeCalculation && <TimeCaliculation node={node} setBtnDisabled={setBtnDisabled} onSetValidations={onSetValidations} validations={validations} units={units} />}
                    {code === configCodes?.VariableAutoPopulation && <AutoPopulation node={node} setBtnDisabled={setBtnDisabled} onSetValidations={onSetValidations} validations={validations} units={units} />}
                    {code === configCodes?.NumericCalculation && <NumaricCaliculation node={node} setBtnDisabled={setBtnDisabled} onSetValidations={onSetValidations} validations={validations} units={units} />}
                    {code === configCodes?.FileAutoPopulation && <FileNameAutoPopulation setBtnDisabled={setBtnDisabled} node={node} onSetValidations={onSetValidations} validations={validations} units={units} />}
                    {code === configCodes?.CustomDerivation && <CustomeDerivationDashboard setBtnDisabled={setBtnDisabled} node={node} onSetValidations={onSetValidations} validations={validations} code={code} />}

                    <Footer backToDerivations={backToDerivations} onSubmitHandler={onSubmitHandler} disabled={btnDisabled}
                      actionType={actionType} />
                  </React.Fragment>
                ) : (<React.Fragment>
                  <div className="e-alert-info w-100 py-5 mt-5" role="alert">
                    <h4>Start Create New Derivation</h4>
                    <span>Please Select Form And Start Creating New Derivation!</span>
                  </div>
                </React.Fragment>)
              }
            </div>
          </div>
          <div className="right-panel">
            <h1>Drag a variable from here</h1>
            <div className="menu-container field-menu">
              <TreeviewComponent
                data={treePayload}
                onDragTreeviewNode={onGetNodeDetails}
                ondragEnd={ondragEnd}
                // type="derivatives"
                // type={() => { return 'sucess' ? "derivatives" : '' }}
                type={onGroupVariable()}
              />
              {(code === "ACT_TYP_NUMERIC" && derivation.logic.itemList && derivation.logic.logicVariables[0]) && <div className="custom-variable"
                id="custumItem"
                draggable={true}
                onDragStart={(e) => onCustomDrag(e)}
                key="customeVarId">
                <img src={AddCustomVariable} alt="" /><span>Add Custom Variable</span>
              </div>}
            </div>
          </div>
        </div>
      </div>
    </React.Fragment>
  )
}
export default CreateDerivation;