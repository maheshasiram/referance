import React from "react";
import { useParams } from "react-router-dom";
import { Types } from "../../../reducers/Types";
import '../../../styles/derivations.scss';
import CustomDerivation from "./CustomDerivation";
import TotalCapsule from "./TotalCapsule";
import TotalScore from "./TotalScore";
import { useDispatch, useSelector } from "react-redux";
import { configDataType } from "../../../../../../../actions/actions";

export default function CustomeDerivationDashboard(props: any) {
    const dispatch = useDispatch();
    const params: any = useParams();
    const { node, onSetValidations, setBtnDisabled, validations } = props;
    const { derivation, actionTypes, customDerivationValues } = useSelector((state: any) => state.derivations);

    React.useEffect(() => {
        dispatch(configDataType('CUSTOM_DERIVATION', (data: any) => {
            dispatch({ type: Types.FETCH_CUSTOM_DERIVATION, payload: data.CUSTOM_DERIVATION })
        }));
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onCustomOptionChange = (e: any) => {
        const _payload = { ...{}, ...derivation }
        onSetValidations({ target: "", dependentTarget: "", logic: "" });
        if (e.target.value !== '') {
            const _actionType = actionTypes && actionTypes.find((ele: any) => ele.id === parseInt(_payload.actionType.id));
            const _customType = customDerivationValues && customDerivationValues.find((ele: any) => e.target.value === ele.code)
            _payload.actionType = {
                id: _actionType.id,
                name: _actionType.name,
                code: _actionType.code
            }
            _payload.target.targetVariables = [];
            _payload.dependentTargetVar = [];
            _payload.logic.visitId = ""
            _payload.logic.logicVariables = [];
            _payload.target.targetFormIds = [];
            _payload.target.targetFieldIds = [];
            _payload.target.targetVisitIds = [];
            _payload.target.targetVariables = [];
            _payload.dependentFieldIds = [];
            _payload.customDerivationType = {
                id: _customType.id,
                name: _customType.name,
                code: _customType.code
            };
            setBtnDisabled(true);
            dispatch({ type: Types.CREATE_DERIVATION, payload: _payload });
        }
    }

    const visitIsDisable = () => {
        let _isDisable = true
        if (derivation.actionType.code !== "ACT_TYP_NUMERIC") {
            const _every = derivation?.logic?.logicVariables[0]?.fields?.some((ele: any) => ele.fieldName);
            if (_every) {
                _isDisable = true
            } else {
                _isDisable = false
            }
        }
        return _isDisable
    }
    return (
        <React.Fragment>
            <div className="d-flex">
                {
                    customDerivationValues && customDerivationValues.map((response: any, index: any) => (
                        <div key={index} className="d-flex  flex-container ">
                            <input type="radio"
                                id={response.code}
                                name={'customDerivatives'}
                                value={response.code}
                                className='flex-item'
                                checked={derivation?.customDerivationType?.code === response.code}
                                // checked={parseInt(params.id) > 0 ? derivation?.customDerivationType?.code == response.code
                                //     : response.code == 'CUSTOM_DERIVATION_CUSTOM_CALCULATION'}
                                // defaultChecked={parseInt(params.id) > 0 ? false : response.id == 'CustomDerivation' && true}
                                disabled={parseInt(params.id) > 0 ? true : false}
                                onChange={(e: any) => onCustomOptionChange(e)}
                            />
                            <label htmlFor={response.code} className="radioLables">{response.name}</label>
                        </div>
                    ))
                }
            </div>

            <div>
                {derivation?.customDerivationType?.code === 'CUSTOM_DERIVATION_CUSTOM_CALCULATION' ?
                    <CustomDerivation setBtnDisabled={setBtnDisabled} node={node} onSetValidations={onSetValidations} validations={validations} visitIsDisable={visitIsDisable} /> : derivation?.customDerivationType?.code === "CUSTOM_DERIVATION_TOTAL_SCORE" ?
                        <TotalScore setBtnDisabled={setBtnDisabled} node={node} onSetValidations={onSetValidations} validations={validations} visitIsDisable={visitIsDisable} /> :
                        <TotalCapsule setBtnDisabled={setBtnDisabled} node={node} onSetValidations={onSetValidations} validations={validations} visitIsDisable={visitIsDisable} />
                }
            </div>
        </React.Fragment>
    )
}