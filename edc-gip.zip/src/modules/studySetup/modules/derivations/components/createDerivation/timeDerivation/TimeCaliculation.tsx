import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { Types } from "../../../reducers/Types";
import { fetchVisitsAssignedToFieldId, setLogicElements, setLogicVariable, setTargetVariablesElements, resetLogicVariable  } from "../../../actions/actions";
import TargetContainer from "../../../helpers/TargetContainer";
import { timeCalculationDataType } from "../../../helpers/LogicVariablesDataTypes";
import { validateDerivation } from "../../../helpers/Validations";
import LogicContainer from "../../../helpers/LogicContainer";

function TimeDerivation(props: any) {
  const dispatch = useDispatch();
  const { derivation } = useSelector((state: any) => state.derivations);
  const { node, onSetValidations, setBtnDisabled, units } = props

  const onDropTargetElement = () => {
    if (!derivation.id) {
      const _derivation = { ...{}, ...derivation };
      let _logicElements: any;
      const errors: any = validateDerivation(derivation, node, 'time', 'target')
      if (errors === false) {
        const _payload = setTargetVariablesElements(dispatch, node, _derivation);
        if (_payload && _payload.actionType.code === "ACT_TYP_TIME" && _payload.logic.logicVariables.length === 0) {
          _logicElements = setLogicElements(timeCalculationDataType, _payload);
        }
        dispatch({ type: Types.CREATE_DERIVATION, payload: _payload && _payload.actionType.code === "ACT_TYP_TIME" && _payload.logic.logicVariables.length === 0 ? _logicElements : _payload });
        setBtnDisabled(false);
        onSetValidations({ target: "", logic: "" });
      }
      else {
        props.onSetValidations(errors);
      }
    }
  }

  const onDropDependentElement = (type: string, index: number) => {
    const _derivations = { ...{}, ...derivation }
    let _flag = false;
    // dispatch(fetchVisitsAssignedToFieldId(node.id, (response: any) => {
    //   if (response.data) {
    //     response.data.map((ele: any) => {
    node.visits.map((ele: any) => {
          if (ele.id === parseInt(_derivations.logic.visitId)) {
            _flag = true;
          }
          return null
        });
      // }
      let errors: any = validateDerivation(derivation, node, type, 'logic')
      if (errors === false && _flag) {
        props.onSetValidations({ logic: "" });
        const _derivation = setLogicVariable(derivation, node, type, index);
        _derivation.calcFactor = null;
        _derivation.dependentFieldIds.push(node.id);
        dispatch({ type: Types.CREATE_DERIVATION, payload: _derivation })
        setBtnDisabled(false);
        console.log("...55666", _derivations);
      }
      else {
        if (!_flag) {
          errors = {
            target: '',
            dependentTarget: "",
            logic: "The dragged variable is not assigned to selected visit, please drag different variable",
          }
        }
        props.onSetValidations(errors);
      }
    // }));
  }

  const onDeleteDependent = (index: number, type: string) => {
    const payload = resetLogicVariable(derivation, index, type);
    payload.dependentFieldIds.splice(index, 1);
    console.log("...payload", payload.dependentFieldIds.splice(index));
    dispatch({ type: Types.CREATE_DERIVATION, payload: payload })
    props.onSetValidations({ logic: "" });
    setBtnDisabled(false);
  }

  return (
    <React.Fragment>
      <TargetContainer
        onDropTargetElement={onDropTargetElement}
        placeholder={<span className="txt-default">Drag <i>time</i> variable.</span>}
        validations={props.validations}
        onSetValidations={onSetValidations}
        setBtnDisabled={setBtnDisabled}
      />

      {derivation && derivation.logic.visitId !== "" &&
        <LogicContainer
          validations={props.validations}
          onDropDependentElement={onDropDependentElement}
          onDeleteDependent={onDeleteDependent}
        setBtnDisabled={setBtnDisabled}
        onSetValidations={onSetValidations}
        units={units}
        />
      }
    </React.Fragment>
  )
}
export default TimeDerivation;