import React from "react";
import { useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { fetchAllVistis, setTargetVariablesElements } from "../../../actions/actions";
import TargetContainer from "../../../helpers/TargetContainer";
import { Types } from "../../../reducers/Types";
import { customDerivationValidaton } from "../../../helpers/Validations";
import CustomDerivationSourceContainer from "./CustomDerivationSourceContainer";
import SelectField from "../../../../../../../common/selectField/SelectField";

function CustomDerivation(props: any) {
    const dispatch = useDispatch();
    const params: any = useParams();
    const { derivation, allVisits, customDerivationValues } = useSelector((state: any) => state.derivations);
    const { node, onSetValidations, setBtnDisabled, validations, visitIsDisable } = props;
    const { currentStudy } = useSelector((state: any) => state.application);
    const [customDerivatives, setCustomeDerivatives]: any = React.useState(derivation.id ? derivation : { logic: { logicVariables: [{ expression: '', fields: [] }] } });
    const [dependentVarVisits, setDependentVarVisits] = React.useState([]);
    const loaded = React.useRef(false);


    React.useEffect(() => {
        if (!loaded.current) {
            dispatch(fetchAllVistis(currentStudy.id, (response: any) => {
                if ((parseInt(params.id)) > 0) {
                    const _derivation = { ...{}, ...derivation };
                    const _logicVisit = response.filter((obj: any) => obj.id === parseInt(_derivation.logic.visitId))
                    const options: any = []
                    _logicVisit.map((item: any) => {
                        const option = {
                            label: item.visitName,
                            value: item.id
                        }
                        options.push(option);
            return null;
                    })
                    setDependentVarVisits(options);
                    dispatch({ type: Types.CREATE_DERIVATION, payload: _derivation })
                }
            }))
            loaded.current = true
        }
         // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onDependentVarVisitChangeHandler = (value: any) => {
        const _derivations = { ...{}, ...derivation }
        const selectedVisitsData: any = [];
        selectedVisitsData.push(value);
        const _value = value?.value?.toString();
        _derivations.logic.visitId = _value;
        setDependentVarVisits(selectedVisitsData);
        dispatch({ type: Types.CREATE_DERIVATION, payload: _derivations });
        dispatch({ type: Types.SELECT_VISIT_IN_DERIVATION, payload: [] });
        onSetValidations({ target: "", logic: "" });
        setBtnDisabled(false);
    }

    const onDropTargetElement = () => {
        if (!derivation.id) {
            const _derivation = { ...{}, ...derivation }
            const errors: any = customDerivationValidaton(derivation, node, 'integer', 'target');
            if (errors === false) {
                const payload = setTargetVariablesElements(dispatch, node, _derivation);
                const _customDerivation = customDerivationValues && customDerivationValues.find((ele: any) => ele.code === 'CUSTOM_DERIVATION_CUSTOM_CALCULATION')
                const _Custom = payload.customDerivationType = {
                    id: _customDerivation.id,
                    name: _customDerivation.name,
                    code: _customDerivation.code
                }
                payload.customDerivationType = derivation.id ? derivation.customDerivationType : _Custom
                payload.calcFactor = null;
                dispatch({ type: Types.CREATE_DERIVATION, payload });
                setBtnDisabled(false);
                onSetValidations({ target: "", logic: "" });
            }
            else {
                props.onSetValidations(errors);
            }
        }
    }

    return (
        <React.Fragment>
            <TargetContainer
                onDropTargetElement={onDropTargetElement}
                placeholder={<span className="txt-default">DRAG <i>INTEGER</i> VALUE</span>}
                validations={props.validations}
                onSetValidations={onSetValidations}
                setBtnDisabled={setBtnDisabled}
                setCustomeDerivatives={setCustomeDerivatives}
                setDependentVarVisits={setDependentVarVisits}
            />
            {derivation && derivation.target.targetVariables.length > 0 && <div className="d-flex logic-wrapper mb-3">
                <label className="derivation-labels">Visits:</label>
                <div className="d-flex justify-content-start align-items-center px-3">
                    <SelectField
                        className={'visitsDropDown'}
                        id={"visitName"}
                        defaultValue={"Select Visit"}
                        value={dependentVarVisits}
                        isClearable={true}
                        isDisabled={visitIsDisable()}
                        onChange={(e: any) => { onDependentVarVisitChangeHandler(e) }}
                        options={allVisits && allVisits}
                        isSearchable={true}
                        name={"VistsList"}
                        placeholder={"Select Visit"}
                    />
                </div>
            </div>}
            {derivation && derivation.logic.visitId !== "" && <CustomDerivationSourceContainer
                customDerivatives={customDerivatives}
                setCustomeDerivatives={setCustomeDerivatives}
                node={node}
                onSetValidations={onSetValidations}
                setBtnDisabled={setBtnDisabled}
                validations={validations}
            />}
        </React.Fragment>
    )
}

export default CustomDerivation;