import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { Types } from "../../../reducers/Types";
import { setLogicVariable, resetLogicVariable, setLogicElements, fetchVisitsAssignedToFieldId, setTargetVariablesElements } from "../../../actions/actions";
import TargetContainer from "../../../helpers/TargetContainer";
import { dateDaysCalculationDataType, dateHourCalculationDataType } from "../../../helpers/LogicVariablesDataTypes";
import { validateDerivation } from "../../../helpers/Validations";
import LogicContainer from "../../../helpers/LogicContainer";
import { configDataType } from "../../../../../../../actions/actions";

function DateCaliculation(props: any) {
  const dispatch = useDispatch();
  const { node, onSetValidations, setBtnDisabled, units } = props
  const { derivation, calculationFactorValues } = useSelector((state: any) => state.derivations);
  const { configCodes } = useSelector((state: any) => state.application);

  React.useEffect(() => {
    dispatch(configDataType('DATE_CAL', (data: any) => {
      dispatch({ type: Types.FETCH_CALCULATION_FACTOR, payload: data.DATE_CAL })
    }))
  }, [dispatch]);

  const onDropDateTargetElement = (e: any) => {
    console.log(e)
    if (!derivation.id) {
      const _derivation = { ...{}, ...derivation };
      let _logicElements: any;
      const errors: any = validateDerivation(derivation, node, 'date', 'target');
      if (errors === false) {
        const _payload = setTargetVariablesElements(dispatch, node, _derivation);
        const _daysCalcualtionFactor = calculationFactorValues && calculationFactorValues.find((ele: any) => ele.code === configCodes?.Days)
        const _calFactor = _payload.calcFactor = {
          id: _daysCalcualtionFactor.id,
          name: _daysCalcualtionFactor.name,
          code: _daysCalcualtionFactor.code
        };
        _payload.calcFactor = derivation.id ? derivation.calcFactor : _calFactor
        if (_payload && _payload.actionType.code === configCodes?.DateCalculation && _payload.logic.logicVariables.length === 0) {
          _logicElements = setLogicElements(dateDaysCalculationDataType, _payload);
        }
        dispatch({ type: Types.CREATE_DERIVATION, payload: _payload && _payload.actionType.code === configCodes?.DateCalculation && _payload.logic.logicVariables.length === 0 ? _logicElements : _payload });
        setBtnDisabled(false);
        onSetValidations({ target: "", logic: "" });
      } else {
        onSetValidations(errors);
      }
    }
  }

  const onDropDateDependentVariable = (type: string, index: number) => {
    const _derivations = { ...{}, ...derivation }
    let _flag = false;
    // dispatch(fetchVisitsAssignedToFieldId(node.id, (response: any) => {
    //   if (response.data) {

    node.visits.map((ele: any) => {
      if (ele.id === parseInt(_derivations.logic.visitId)) {
        _flag = true;
      }
      return null
    });
    // }
    let errors: any = validateDerivation(derivation, node, type, 'logic')
    if (errors === false && _flag) {
      props.onSetValidations({ logic: "" });
      const _derivation = setLogicVariable(derivation, node, type, index);
      _derivation.dependentFieldIds.push(node.id);
      dispatch({ type: Types.CREATE_DERIVATION, payload: _derivation })
      setBtnDisabled(false);
      console.log("...101", _derivation);
    }
    else {
      if (!_flag) {
        errors = {
          target: '',
          dependentTarget: "",
          logic: "The dragged variable is not assigned to selected visit, please drag different variable",
        }
      }
      props.onSetValidations(errors);
    }
    // }))
  }

  const onChangeHandler = (e: any) => {
    derivation.logic.logicVariables = []
    const _derivation = { ...{}, ...derivation }
    const _calcualtionFactor = calculationFactorValues && calculationFactorValues.find((ele: any) => ele.code === e.target.value)
    _derivation.calcFactor = _calcualtionFactor
    const _logicElements = setLogicElements(e.target.value === configCodes?.Hours ? dateHourCalculationDataType : dateDaysCalculationDataType, _derivation)
    dispatch({ type: Types.CREATE_DERIVATION, payload: _logicElements });
    onSetValidations({ logic: "" });
    setBtnDisabled(false)
  }

  const onDeleteVar = (index: any, type: string) => {
    const payload = resetLogicVariable(derivation, index, type);
    payload.dependentFieldIds.splice(index, 1);
    dispatch({ type: Types.CREATE_DERIVATION, payload });
    setBtnDisabled(false);
    const _array = (derivation.logic.logicVariables.filter((item: any) => item.dataType !== ''))
    if (_array.length === 0) {
      console.log("")
    }
  }

  const { validations } = props
  return (
    <React.Fragment>
      <TargetContainer
        onDropTargetElement={onDropDateTargetElement}
        placeholder={<span className="txt-default">Drag a <i>Date</i> variable here</span>}
        validations={validations}
        onSetValidations={onSetValidations}
        setBtnDisabled={setBtnDisabled}
      />

      {derivation && derivation.logic.visitId !== "" &&
        <div className="logic-wrapper">
          <div className="ligic-sub-wrapper">
            <label className="derivation-labels">Calculation factor :</label>
            <select name='fromInstance'
              className="form-select dropdown-form"
              onChange={(e: any) => { onChangeHandler(e) }}
              value={derivation.calcFactor && derivation.calcFactor.code}
            >
              {
                calculationFactorValues && calculationFactorValues.map((item: any, index: any) => (
                  <option value={item.code} key={index}>{item.name}</option>
                ))
              }
            </select>
          </div>

          <LogicContainer
            validations={props.validations}
            onDropDependentElement={onDropDateDependentVariable}
            onDeleteDependent={onDeleteVar}
            units={units}
            onSetValidations={onSetValidations}
            setBtnDisabled={setBtnDisabled}
          />
        </div>}
    </React.Fragment>
  )
}
export default DateCaliculation;