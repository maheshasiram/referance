import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { Types } from "../../../reducers/Types";
import { fetchDerivationFormula, fetchVisitsAssignedToFieldId, onDragElement, setTargetVariablesElements } from "../../../actions/actions";
import TargetContainer from "../../../helpers/TargetContainer";
import CancelIcon from '@mui/icons-material/Cancel';
import DropdownComponent from "../../../../../../../components/DropdownComponent";
import { validateDerivation } from "../../../helpers/Validations";
import BMIFormula from "../../../helpers/BMIFormula";
import AgeFormula from "../../../helpers/AgeFormula";
import { useParams } from "react-router-dom";
import convert from "convert-units";

function NumaricCaliculation(props: any) {
  const dispatch = useDispatch();
  const loaded = React.useRef(false);
  const params: any = useParams();
  const { derivation, numericOperator, allFormulas } = useSelector((state: any) => state.derivations);
  // const [numericValidate, setNumericValidate] = React.useState('')
  let numericValidate: any;
  const [totalElements, setTotalElements] = React.useState(0);
  const { node, validations, onSetValidations, setBtnDisabled, units } = props;
  // const [variableType, setVariableType] = React.useState(['integer', 'real']);
  const variableType: any = ['integer', 'real'];
  // const [dropdownData, setDropDownData] = React.useState(numericOperator && numericOperator);
  const dropdownData: any = numericOperator && numericOperator;

  React.useEffect(() => {
    if (!loaded.current) {
      dispatch(fetchDerivationFormula())
      loaded.current = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onDropTargetElement = (e: any) => {
    console.log(e)
    if (!derivation.id) {
      const _derivation = { ...{}, ...derivation };
      const errors: any = validateDerivation(derivation, node, variableType, 'target');
      if (errors === false) {
        const payload = setTargetVariablesElements(dispatch, node, _derivation)
        payload.calcFactor = null;
        dispatch({ type: Types.CREATE_DERIVATION, payload });
        setBtnDisabled(false);
        onSetValidations({ target: "", logic: "" });
      } else {
        onSetValidations(errors);
      }
    }
  }

  const addItem = (dataType: any, text: any, id: any, units: any, formId: any, formName: any, groupId: any) => {
    return ({
      fieldName: text,
      fieldId: id,
      formId: formId,
      formName: formName,
      dataType: dataType && dataType.name,
      operation: "",
      units: units,
      updatedUnit: '',
      groupId: groupId
    })
  }

  const onDropLogicDerivationElements = (e: any, isParent: any, index: any) => {
    const { datatype, label, id, units, formId, formName, groupId } = node;
    const _derivations = { ...{}, ...derivation };
    let _flag = false;
    // dispatch(fetchVisitsAssignedToFieldId(node.id, (response: any) => {
    //   if (response.data) {
    // response.data.map((ele: any) => {
    node.visits.map((ele: any) => {
      if (ele.id === parseInt(_derivations.logic.visitId)) {
        _flag = true;
      }
      return null
    })
    // }
    let errors: any = validateDerivation(derivation, node, variableType, 'logic')
    console.log("...8111", errors);
    if (errors === false && _flag) {
      props.onSetValidations({ target: "", logic: "" });
      if (isParent === 0) {
        _derivations.logic.logicVariables.push({
          operation: "",
          fields: [addItem(datatype, label, id, units, formId, formName, groupId)]
        });
        _derivations.dependentFieldIds.push(id);
      } else {
        _derivations.logic.logicVariables[index].fields.push(
          addItem(datatype, label, id, units, formId, formName, groupId))
        _derivations.dependentFieldIds.push(id)
      }
      console.log("...85555", _derivations);
      let count = 0;
      _derivations && _derivations.logic.logicVariables.map((num: any) => {
        count += num.fields.length;
        return null
      })
      setTotalElements(count);
      const _payload = { ...derivation }
      _payload.logic = _derivations.logic;
      dispatch({ type: Types.CREATE_DERIVATION, payload: _payload })
      setBtnDisabled(false);
    } else {
      if (!_flag) {
        errors = {
          target: '',
          dependentTarget: "",
          logic: "The dragged variable is not assigned to selected visit, please drag different variable",
        }
      }
      props.onSetValidations(errors);
    }
    // }));
  }


  const onDeleteLogic = (e: any, index: any, subIndex: any) => {
    const _derivations = { ...{}, ...derivation }
    _derivations.logic.logicVariables[index].fields.splice(subIndex, 1);
    _derivations.dependentFieldIds.splice(index, 1);
    if (_derivations.logic.logicVariables[index].fields.length === 0) {
      _derivations.logic.logicVariables.splice(index, 1);
    }
    setTotalElements((totalElements - 1));
    onSetValidations({ logic: "" });
    setBtnDisabled(false);
  }

  const onOuterOperatorChangeHandler = (value: any, index: any) => {
    const _derivations = { ...{}, ...derivation }
    _derivations.logic.logicVariables[index].operation = value;
    onSetValidations({ logic: "" });
    setBtnDisabled(false);
  }

  const onInnerOperatorChange = (value: any, index: any, subIndex: number) => {
    const _derivations = { ...{}, ...derivation }
    _derivations.logic.logicVariables[index].fields[subIndex].operation = value;
    onSetValidations({ logic: "" });
    setBtnDisabled(false);
  }

  const onUpdateCustomField = (e: any, index: any, subIndex: any) => {
    const _derivations = { ...{}, ...derivation }
    _derivations.logic.logicVariables[index].fields[subIndex].itemOid = e.target.value;
    onSetValidations({ logic: "" });
    setBtnDisabled(false);
  }

  const onUnitsChangeHandler = (value: any, index: any, subIndex: any) => {
    const _payload = { ...{}, ...derivation }
    _payload.logic.logicVariables[index].fields[subIndex].updatedUnit = value;
    setBtnDisabled(false);
    dispatch({ type: Types.CREATE_DERIVATION, payload: _payload });
    onSetValidations({ target: "", logic: "" });
  }

  const onFormulaChange = (e: any) => {
    const payload = { ...{}, ...derivation }
    if (e.target.value) {
      const _selectedFormula = allFormulas && allFormulas.find((item: any) => item.formulaCode === e.target.value);
      payload.logic.formula = _selectedFormula
      if (_selectedFormula?.formulaCode === "AGE") {
        payload.logic.logicVariables = [
          {
            operation: "/",
            numeratorFields: [],
            denominatorFields: [{ value: 365 }]
          }
        ]
      } else if (_selectedFormula?.formulaCode === "BMI") {
        payload.logic.logicVariables = [
          {
            operation: "/",
            numeratorFields: [],
            denominatorFields: []
          }
        ]
      }
    } else {
      payload.logic.formula = {}
      payload.logic.logicVariables = []
    }
    onSetValidations({ logic: "" });
    dispatch({ type: Types.CREATE_DERIVATION, payload: payload });
  }

  const getUnits = (units: any) => {
    let _units: any = [];
    let _possiblites = convert().from(units).possibilities();
    console.log("..._possiblites", _possiblites);
    _possiblites && _possiblites.map((i: any) => {
      const obj = {
        id: i,
        formName: i
      }
      _units.push(obj);
      return obj
    });
    return _units
  }

  return (
    <React.Fragment>
      <div className="logic-wrapper">
        <label className="derivation-labels">Formula:</label>
        <select className="form-select"
          value={derivation?.logic?.formula?.formulaCode}
          onChange={(e) => onFormulaChange(e)}
          disabled={parseInt(params.id) > 0 ? true : false}
        >
          <option value="" >Select Formula</option>
          {
            allFormulas && allFormulas.map((formula: any, index: any) => (
              <option key={index} value={formula.formulaCode}>{formula.formulaCode}</option>
            ))
          }
        </select>
      </div>

      <TargetContainer
        onDropTargetElement={onDropTargetElement}
        placeholder={<span className="txt-default">DRAG <i>INTEGER/REAL</i> VALUE</span>}
        validationForNumeric={numericValidate}
        validations={props.validations}
        onSetValidations={props.onSetValidations}
        setBtnDisabled={setBtnDisabled}
        node={node}
      />

      {(derivation && derivation && derivation.logic.visitId !== "" && (Object.keys(derivation.logic.formula).length <= 0)) ?
        <div className="logic-wrapper" >
          <label className="derivation-labels">Dependent Variables
            : {(validations && validations.logic) && <span className=" ms-2 text-danger">{validations.logic}</span>}
          </label>
          {
            derivation && derivation.logic && derivation.logic.logicVariables.length > 0 &&
            <div className="calc-wrapper" >
              {derivation.logic.logicVariables.map((element: any, index: number) => (
                <div className="w-100" key={index}>
                  {(index > 0) &&
                    <div className="d-flex justify-content-center align-items-center mb-2 w-100">
                      <DropdownComponent
                        data={dropdownData}
                        className='w-25'
                        defaultValue="Select operation"
                        onChangeHandler={(value: any) => onOuterOperatorChangeHandler(value, index)}
                        selectedOption={derivation.logic.logicVariables[index].operation}
                      />
                    </div>
                  }
                  {element.fields && element.fields.length > 0 &&
                    <ul className="vars-container">
                      {
                        element.fields.map((subEle: any, subIndex: number) => (
                          <React.Fragment key={subIndex}>
                            <>{console.log("...220", subEle)}</>
                            {(subIndex > 0) && <li className="var-operator ">
                              <DropdownComponent
                                data={dropdownData && dropdownData}
                                className='w-100'
                                defaultValue='Select operation'
                                onChangeHandler={(value: any) => onInnerOperatorChange(value, index, subIndex)}
                                selectedOption={derivation.logic.logicVariables[index].fields[subIndex].operation}
                              />
                            </li>}
                            {<li>
                              {subEle.fieldName && <span>{subEle.fieldName} <b>({subEle.dataType})({subEle.formName})</b></span>}
                              {subEle.units && <span>{subEle.units}</span>}
                              {subEle.units && <DropdownComponent
                                // data={units}
                                data={getUnits(subEle.units)}
                                className='w-10'
                                defaultValue='Select Unit'
                                onChangeHandler={(value: any) => onUnitsChangeHandler(value, index, subIndex)}
                                selectedOption={derivation.logic.logicVariables[index].fields[subIndex].updatedUnit}
                              />}
                              {!subEle.fieldName &&
                                <div className="custom-element">
                                  <div className="element">
                                    <input type="number"
                                      onKeyDown={(e: any) => {
                                        if (e.key === "e") {
                                          e.preventDefault();
                                        }
                                      }}
                                      onChange={(e: any) => onUpdateCustomField(e, index, subIndex)}
                                      value={subEle.fieldId}
                                      className="mr-auto"
                                      id="custumInput_0_1"
                                      placeholder=" Please enter value"
                                    />
                                  </div>
                                </div>
                              }
                              <CancelIcon onClick={(e: any) => onDeleteLogic(e, index, subIndex)} />
                            </li>}
                            {element.fields && element.fields.length < 2 &&
                              <li className="element">
                                <div className="element"
                                  onDragOver={onDragElement}
                                  onDrop={(e) => onDropLogicDerivationElements(e, 1, index)}>
                                  {/* <span>Drag <i>Numeric</i> Variable</span> */}
                                  <span>Drag a Variable here</span>
                                </div>
                              </li>
                            }
                          </React.Fragment>
                        ))
                      }
                    </ul>}
                </div>
              ))}
            </div>
          }
          {(totalElements < 5) && <div className="logic-container">
            <div className="element numaric-container"
              onDragOver={onDragElement}
              onDrop={(e) => onDropLogicDerivationElements(e, 0, null)}>
              {/* <span className="date">Drag a <i>Numeric</i> variable here</span> */}
              <span className="date">Drag a variable here</span>
            </div>
          </div>}
        </div>
        : (derivation && derivation && derivation.logic.visitId !== "" && derivation.logic.formula.formulaCode === "BMI") ?
          <div className="logic-wrapper" >
            <BMIFormula node={node} validations={validations}
              onSetValidations={onSetValidations} setBtnDisabled={setBtnDisabled} />
          </div> :
          (derivation && derivation && derivation.logic.visitId !== "" && derivation.logic.formula.formulaCode === "AGE") ?
            <div className="logic-wrapper" >
              <AgeFormula node={node} validations={validations}
                onSetValidations={onSetValidations} setBtnDisabled={setBtnDisabled} />
            </div> : ''}
    </React.Fragment>
  )
}
export default NumaricCaliculation;