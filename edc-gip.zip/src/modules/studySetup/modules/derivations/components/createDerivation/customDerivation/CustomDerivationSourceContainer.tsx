import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { /*fetchVisitsAssignedToFieldId, */ onDragElement } from "../../../actions/actions";
import CancelIcon from '@mui/icons-material/Cancel';
import { Types } from "../../../reducers/Types";
import { useParams } from "react-router-dom";
import { validateDerivation } from "../../../helpers/Validations";
import SelectDropdown from "../../../../rules/helpers/SelectDropdown";
import { customOperatorData } from "../../../constants/modal";
import CustomToolTip from "../../../../../../../components/CustomToolTip";

export default function CustomDerivationSourceContainer(props: any) {
    const dispatch = useDispatch();
    const params: any = useParams();
    const { derivation } = useSelector((state: any) => state.derivations);
    const { node, onSetValidations, setBtnDisabled, validations, setCustomeDerivatives } = props;
    // const [variableDataType, setVariableDataType] = React.useState('integer');
    const variableDataType = 'integer';
    // const [dropdownData, setDropDownData] = React.useState(customOperatorData && customOperatorData);
    const dropdownData = customOperatorData && customOperatorData;
    const [value, setValue] = React.useState('');
    const loaded = React.useRef(false);

    React.useEffect(() => {
        if (!loaded.current) {
            const _Payload = { ...{}, ...derivation }
            if ((parseInt(params.id)) <= 0) {
                _Payload.logic.logicVariables.push({
                    fields: []
                });
                dispatch({ type: Types.CREATE_DERIVATION, payload: _Payload })
                loaded.current = true
            }
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    React.useEffect(() => {
        const _Payload = { ...{}, ...derivation }
        if ((parseInt(params.id)) > 0) {
            _Payload.logic.logicVariables.map((i: any) => {
                if (i.expression !== "") {
                    const _data = i && i.expression;
                    setValue(_data);
                    dispatch({ type: Types.CREATE_DERIVATION, payload: _Payload })
                }
                return null
            })
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const onExpressionChangeHandler = (e: any, index: any) => {
        const _derivations = { ...{}, ...derivation };
        _derivations.logic.logicVariables[index].expression = e.target.value;
        setValue(e.target.value)
        dispatch({ type: Types.CREATE_DERIVATION, payload: _derivations })
        onSetValidations({ logic: "" });
        setBtnDisabled(false);
    }

    const onInputChangeValue = (e: any, index: any, i: any, itemIndex: any) => {
        console.log("iiiiii", e, index, i, itemIndex)
        const _data = { ...{}, ...derivation };
        _data.logic.logicVariables[i].fields[index].responseOptions[itemIndex].value = e.target.value;
        setCustomeDerivatives(_data)
        onSetValidations({ logic: "" });
        dispatch({ type: Types.CREATE_DERIVATION, payload: _data })
        setBtnDisabled(false);
    }

    console.log("ii derivations", derivation)
    const addItemList = (dataType: any, text: any, id: any, responseType: any, responseOptions: any, units: any, formId: any, formName: any) => {
        return ({
            fieldName: text,
            fieldId: id,
            formId: formId,
            formName: formName,
            units: units,
            dataType: dataType && dataType.name,
            operation: "",
            responseType: responseType && responseType.name,
            responseOptions: responseOptions,
        })
    }

    const onDeleteLogicVariable = (e: any, index: any, subIndex: any) => {
        const _derivations = { ...{}, ...derivation }
        _derivations.logic.logicVariables[index].fields.splice(subIndex, 1);
        _derivations.logic.logicVariables[index].expression = ''
        _derivations.dependentFieldIds.splice(index, 1);
        if (_derivations.logic.logicVariables[index].fields.length === 0) {
            _derivations.logic.logicVariables.splice(index, 1);
            _derivations.logic.logicVariables.push({
                fields: []
            })
        }
        setValue('');
        setCustomeDerivatives(_derivations);
        onSetValidations({ logic: "" });
        setBtnDisabled(false)
        dispatch({ type: Types.CREATE_DERIVATION, payload: _derivations })
    }


    const onDropLogicElements = (e: any, isParent: any, index: any) => {
        onSetValidations({ target: '', dependentTarget: '' })
        const { datatype, label, id, responseType, units, formId, formName } = node;
        const _derivations = { ...{}, ...derivation }
        let _flag = false;
        // dispatch(fetchVisitsAssignedToFieldId(node.id, (response: any) => {
        //     if (response.data) {
        //         response.data.map((ele: any) => {
        node.visits.map((ele: any) => {
            if (ele.id === parseInt(_derivations.logic.visitId)) {
                console.log("..52", ele.id, parseInt(_derivations.logic.visitId));
                _flag = true;
            }
            return null
        })
        // }
        let errors: any = validateDerivation(derivation, node, variableDataType, 'logic');
        if (errors === false && _flag) {
            onSetValidations({ logic: "" });
            const _responseOptions = [...[], ...node.responseOptions];
            node.responseOptions.map((item: any, i: any) => {
                return _responseOptions[i].value = ''
            });
            _derivations.logic.logicVariables[index].fields.push(addItemList(datatype, label, id, responseType, _responseOptions, units, formId, formName));
            setCustomeDerivatives(_derivations);
            const _payload = { ...derivation }
            _payload.logic.logicVariables = [..._derivations.logic.logicVariables];
            _payload.dependentFieldIds.push(node.id);
            dispatch({ type: Types.CREATE_DERIVATION, payload: _payload })
            setBtnDisabled(false);
            console.log("...135", _payload);
        } else {
            if (!_flag) {
                errors = {
                    target: '',
                    dependentTarget: "",
                    logic: "The dragged variable is not assigned to selected visit, please drag different variable",
                }
            }
            props.onSetValidations(errors);
        }
        // }));
    }
    return (
        <React.Fragment>
            {derivation && derivation.target.targetVariables.length > 0 &&
                <div className="logic-wrapper" >
                    {derivation && derivation.logic.logicVariables.map((i: any, index: any) => (
                        <div className="w-100" key={index}>
                            {(index === 0) &&
                                <div className="d-flex justify-content-center align-items-center mt-3 w-100">
                                    <SelectDropdown
                                        className='w-25'
                                        onChange={(e: any) => onExpressionChangeHandler(e, index)}
                                        disabled={false}
                                        value={value}
                                        defaultOption={'Select operation'}
                                        options={dropdownData}
                                        placeholder={"Select Visit"} />
                                </div>}
                        </div>
                    ))}
                    <label className="derivation-labels">Dependent Variables
                        : {(validations && validations.logic) && <span className=" ms-2 text-danger">{validations.logic}</span>}
                    </label>
                    <div className="custom-logic-div">
                        {derivation.logic.logicVariables &&
                            derivation.logic.logicVariables.map((element: any, loginIndex: number) => (
                                <div className="w-100" key={loginIndex}>
                                    {element.fields && element.fields.length > 0 &&
                                        <div className="">
                                            <ul className="vars-container">
                                                {element.fields.map((subEle: any, subIndex: number) => (
                                                    <React.Fragment key={subIndex}>
                                                        <>{console.log("subIndex...", subIndex)}</>
                                                        {<li className="custom-list m">
                                                            {subEle.fieldName && <span>{subEle.fieldName}
                                                                {/* <b>({subEle.dataType})({subEle.formName})</b> */}
                                                                <CustomToolTip title="Data Type"><b>({subEle.dataType})</b></CustomToolTip>
                                                                <CustomToolTip title="Form Name"><b>({subEle.formName})</b></CustomToolTip>
                                                            </span>}
                                                            {console.log("..172", subEle, element)}
                                                            {subEle.responseOptions.map((response: any, itemIndex: any, index: any) => (
                                                                <div key={index} className=" d-flex" >
                                                                    {response.variableText && <span className="me-1 mt-2">{response.response}</span>}
                                                                    <input
                                                                        type="number"
                                                                        className="form-control customInput"
                                                                        value={response && response.value}
                                                                        onChange={(e: any) =>
                                                                            onInputChangeValue(e, subIndex, loginIndex, itemIndex)}
                                                                        onKeyDown={(evt) => ["e", "E"].includes(evt.key) && evt.preventDefault()}
                                                                        onDragOver={(e) => e.preventDefault()}
                                                                    />
                                                                </div>
                                                            ))
                                                            }
                                                            <CancelIcon onClick={(e: any) => onDeleteLogicVariable(e, loginIndex, subIndex)} />
                                                        </li>}
                                                    </React.Fragment>
                                                ))}
                                            </ul>
                                        </div>
                                    }
                                </div>
                            ))
                        }
                        {<div className="logic-container ">
                            <div className="element numaric-container"
                                onDragOver={onDragElement}
                                onDrop={(e) => onDropLogicElements(e, 0, 0)}>
                                <span className="date">Drag a <i>Response</i> variable here</span>
                            </div>
                        </div>}
                    </div>
                </div>
            }
        </React.Fragment>
    )
}