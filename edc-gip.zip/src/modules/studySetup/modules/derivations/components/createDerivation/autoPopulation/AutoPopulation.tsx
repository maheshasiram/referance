import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { Types } from "../../../reducers/Types";
import {
  setLogicVariable, resetLogicVariable,
  fetchVisitsAssignedToFieldId, setLogicElements, setTargetVariablesElements,
} from "../../../actions/actions";
import TargetContainer from "../../../helpers/TargetContainer";
import { autoPopulateCalculation } from "../../../helpers/LogicVariablesDataTypes";
import { validateDerivation } from "../../../helpers/Validations";
import LogicContainer from "../../../helpers/LogicContainer";

function AutoPopulation(props: any) {
  const dispatch = useDispatch();
  const { node, onSetValidations, setBtnDisabled, units } = props;
  const { derivation } = useSelector((state: any) => state.derivations);

  const onDropAutoPopulateTarget = () => {
    if (!derivation.id) {
      const _derivation = { ...{}, ...derivation };
      let _logicElements: any;
      const errors: any = validateDerivation(derivation, node, 'file', 'target')
      if (errors === false) {
        const _payload = setTargetVariablesElements(dispatch, node, _derivation)
        onSetValidations({ target: "" });
        if (_payload && _payload.actionType.code === "ACT_TYP_VARIABLE_NAME_AUTO_POP" && _payload.logic.logicVariables.length === 0) {
          _logicElements = setLogicElements(autoPopulateCalculation, _payload)
        }
        dispatch({ type: Types.CREATE_DERIVATION, payload: _payload && _payload.actionType.code === "ACT_TYP_VARIABLE_NAME_AUTO_POP" && _payload.logic.logicVariables.length === 0 ? _logicElements : _payload });
        setBtnDisabled(false);
      } else {
        onSetValidations(errors);
      }
    }
  }

  const onDropAutoPopulateDependent = (type: string, index: number) => {
    const _derivations = { ...{}, ...derivation }
    let _flag = false;
    // dispatch(fetchVisitsAssignedToFieldId(node.id, (response: any) => {
    //   if (response.data) {
    node.visits.map((ele: any) => {
          if (ele.id === parseInt(_derivations.logic.visitId)) {
            _flag = true;
          }
          return null
        })
      // }
      let errors: any = validateDerivation(derivation, node, type, 'logic')
      if (errors === false && _flag) {
        props.onSetValidations({ logic: "" });
        const _derivation = setLogicVariable(derivation, node, type, index);
        _derivation.calcFactor = null;
        _derivation.dependentFieldIds.push(node.id);
        dispatch({ type: Types.CREATE_DERIVATION, payload: _derivation })
        setBtnDisabled(false);
        console.log("....57777", _derivation);
      }
      else {
        if (!_flag) {
          errors = {
            target: '',
            dependentTarget: "",
            logic: "The dragged variable is not assigned to selected visit, please drag different variable",
          }
        }
        props.onSetValidations(errors);
      }
    // }))
  }

  const onDeleteDependent = (index: number, type: string) => {
    const payload = resetLogicVariable(derivation, index, type);
    payload.dependentFieldIds.splice(index, 1);
    dispatch({ type: Types.CREATE_DERIVATION, payload: payload })
    props.onSetValidations({ logic: "" });
    setBtnDisabled(false)
  }

  return (
    <React.Fragment>
      <TargetContainer
        onDropTargetElement={onDropAutoPopulateTarget}
        placeholder={<span className="txt-default">Drag <i>variable</i> here.</span>}
        validations={props.validations}
        onSetValidations={onSetValidations}
        setBtnDisabled={setBtnDisabled}
      />
      {derivation && derivation.logic.visitId !== "" &&
        <LogicContainer
          validations={props.validations}
        onDropDependentElement={onDropAutoPopulateDependent}
          onDeleteDependent={onDeleteDependent}
          visitsList={true}
          onSetValidations={onSetValidations}
          setBtnDisabled={setBtnDisabled}
        units={units}
        />
      }
    </React.Fragment>
  )
}
export default AutoPopulation;