import React from "react";
import { useParams } from "react-router-dom";
import TargetContainer from "../../../helpers/TargetContainer";
import { useDispatch, useSelector } from "react-redux";
import { customDerivationValidaton } from "../../../helpers/Validations";
import { fetchAllVistis, setDependentCaliculatedVariable, setTargetVariablesElements } from "../../../actions/actions";
import { Types } from "../../../reducers/Types";
import DependentTargetContainer from "../../../helpers/DependentTargetContainer";
import CustomDerivationSourceContainer from "./CustomDerivationSourceContainer";
import SelectField from "../../../../../../../common/selectField/SelectField";

export default function TotalScore(props: any) {
    const dispatch = useDispatch();
    const params: any = useParams();
    const { currentStudy } = useSelector((state: any) => state.application);
    const { derivation, allVisits } = useSelector((state: any) => state.derivations);
    const { node, onSetValidations, setBtnDisabled, validations, visitIsDisable } = props;
    const [customDerivatives, setCustomeDerivatives]: any = React.useState(derivation.id ? derivation : { logic: { logicVariables: [{ expression: '', fields: [] }] } });
    const [dependentVarVisits, setDependentVarVisits] = React.useState([]);
    const loaded = React.useRef(false);

    React.useEffect(() => {
        if (!loaded.current) {
            dispatch(fetchAllVistis(currentStudy.id, (response: any) => {
                if ((parseInt(params.id)) > 0) {
                    const _derivation = { ...{}, ...derivation };
                    const _logicVisit = response.filter((obj: any) => obj.id === parseInt(_derivation.logic.visitId))
                    const options: any = []
                    _logicVisit.map((item: any) => {
                        const option = {
                            label: item.visitName,
                            value: item.id
                        }
                        options.push(option);
                        return null;
                    })
                    setDependentVarVisits(options);
                    dispatch({ type: Types.CREATE_DERIVATION, payload: _derivation })
                }
            }))
            loaded.current = true
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onDropTargetScoreElement = () => {
        if (!derivation.id) {
            const _derivation = { ...{}, ...derivation }
            const errors: any = customDerivationValidaton(derivation, node, 'integer', 'target');
            if (errors === false) {
                const payload = setTargetVariablesElements(dispatch, node, _derivation);
                payload.calcFactor = null;
                dispatch({ type: Types.CREATE_DERIVATION, payload });
                setBtnDisabled(false);
                onSetValidations({ target: '', dependentTarget: '', logic: '' })
            }
            else {
                props.onSetValidations(errors);
            }
        }
    }

    const onDropDependentTargetElement = () => {
        if (!derivation.id) {
            // const _derivation = { ...{}, ...derivation }
            const errors: any = customDerivationValidaton(derivation, node, 'integer', 'dependentTarget');
            if (errors === false) {
                const payload = setDependentCaliculatedVariable(derivation, node, dispatch);
                payload.target.targetVariables.map((ele: any, index: number) => {
                    const targetVisits: any = [];
                    if (ele.visitsIds.length > 0) {
                        ele.visitsIds.map((item: any) => {
                            targetVisits.push(item.value);
                            return null
                        })
                    }
                    payload.dependentTargetVar[index].visitsIds = targetVisits
                    return null
                });
                dispatch({ type: Types.CREATE_DERIVATION, payload });
                setBtnDisabled(false);
                onSetValidations({ target: '', dependentTarget: '', logic: '' });
            }
            else {
                props.onSetValidations(errors);
            }
        }

    }
    const onDerivationVisitChangeHandler = (value: any) => {
        const _derivations = { ...{}, ...derivation }
        const selectedVisitsData: any = [];
        selectedVisitsData.push(value);
        const _value = value?.value?.toString();
        _derivations.logic.visitId = _value;
        setDependentVarVisits(selectedVisitsData)
        dispatch({ type: Types.CREATE_DERIVATION, payload: _derivations });
        dispatch({ type: Types.SELECT_VISIT_IN_DERIVATION, payload: [] });
        onSetValidations({ target: "", dependentTarget: "", logic: "" });
        setBtnDisabled(false);
    }

    return (
        <React.Fragment>
            <TargetContainer
                onDropTargetElement={onDropTargetScoreElement}
                placeholder={<span className="txt-default">DRAG <i>INTEGER</i> VALUE</span>}
                validations={props.validations}
                onSetValidations={onSetValidations}
                setBtnDisabled={setBtnDisabled}
                setCustomeDerivatives={setCustomeDerivatives}
                setDependentVarVisits={setDependentVarVisits}
            />

            {derivation && derivation.target.targetVariables.length > 0 && <DependentTargetContainer
                placeholder={<span className="txt-default">DRAG <i>INTEGER</i> VALUE</span>}
                onDropTargetElement={onDropDependentTargetElement}
                validations={props.validations}
                onSetValidations={onSetValidations}
                setBtnDisabled={setBtnDisabled}
                setCustomeDerivatives={setCustomeDerivatives}
                setDependentVarVisits={setDependentVarVisits}
            />}

            {derivation && derivation.dependentTargetVar.length > 0 && <div className="d-flex logic-wrapper mt-2">
                <label className="derivation-labels">Visits:</label>
                <div className="d-flex justify-content-start align-items-center px-3">
                    <SelectField
                        className={'visitsDropDown'}
                        id={"visitName"}
                        defaultValue={"Select Visit"}
                        isDisabled={visitIsDisable()}
                        value={dependentVarVisits}
                        isSearchable={true}
                        isClearable={true}
                        name={"VistsList"}
                        onChange={(e: any) => { onDerivationVisitChangeHandler(e) }}
                        options={allVisits && allVisits}
                        placeholder={"Select Visit"}
                    />
                </div>
            </div>}

            {derivation && derivation.logic.visitId !== "" && <CustomDerivationSourceContainer
                customDerivatives={customDerivatives}
                setCustomeDerivatives={setCustomeDerivatives}
                node={node}
                onSetValidations={onSetValidations}
                setBtnDisabled={setBtnDisabled}
                validations={validations}
            />}
        </React.Fragment>
    )
}