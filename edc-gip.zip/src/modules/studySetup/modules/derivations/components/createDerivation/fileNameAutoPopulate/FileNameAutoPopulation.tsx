import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { Types } from "../../../reducers/Types";
import {
  setLogicVariable, resetLogicVariable,
  fetchVisitsAssignedToFieldId, setLogicElements,
  setTargetVariablesElements
} from "../../../actions/actions";
import TargetContainer from "../../../helpers/TargetContainer";
import { validateDerivation } from "../../../helpers/Validations";
import { fileDataType } from "../../../helpers/LogicVariablesDataTypes";
import LogicContainer from "../../../helpers/LogicContainer";

function FileNameAutoPopulation(props: any) {
  const dispatch = useDispatch();
  const { derivation } = useSelector((state: any) => state.derivations);
  const { configCodes } = useSelector((state: any) => state.application);
  const { node, onSetValidations, setBtnDisabled, units } = props

  const onDropFileAutoPopulateTargetElement = (e: any) => {
    console.log(e)
    if (!derivation.id) {
      const _derivation = { ...{}, ...derivation };
      let _logicElements: any;
      const errors: any = validateDerivation(derivation, node, 'file', 'target')
      if (errors === false) {
        const _payload = setTargetVariablesElements(dispatch, node, _derivation)
        props.onSetValidations({ target: "" });
        if (_payload && _payload.actionType.code === configCodes?.FileAutoPopulation && _payload.logic.logicVariables.length === 0) {
          _logicElements = setLogicElements(fileDataType, _payload);
        }
        dispatch({ type: Types.CREATE_DERIVATION, payload: _payload && _payload.actionType.code === configCodes?.FileAutoPopulation && _payload.logic.logicVariables.length === 0 ? _logicElements : _payload });
        setBtnDisabled(false);
      } else {
        props.onSetValidations(errors);
      }
    }
  }

  const onDeleteDependent = (index: number, type: string) => {
    const payload = resetLogicVariable(derivation, index, type);
    payload.dependentFieldIds.splice(index, 1);
    dispatch({ type: Types.CREATE_DERIVATION, payload: payload })
    props.onSetValidations({ logic: "" });
    setBtnDisabled(false)
  }

  const onDropFileAutoPopulateDependentElement = (type: string, index: number) => {
    const _derivations = { ...{}, ...derivation }
    let _flag = false;
    // dispatch(fetchVisitsAssignedToFieldId(node.id, (response: any) => {
    //   if (response.data) {
    // response.data.map((ele: any) => {
    node.visits.map((ele: any) => {
      if (ele.id === parseInt(_derivations.logic.visitId)) {
        _flag = true;
      }
      return null
    });
    // }
    let errors: any = validateDerivation(derivation, node, type, 'logic')
    if (errors === false && _flag) {
      props.onSetValidations({ logic: "" });
      const _derivation = setLogicVariable(derivation, node, type, index);
      _derivation.calcFactor = null;
      _derivation.dependentFieldIds.push(node.id);
      dispatch({ type: Types.CREATE_DERIVATION, payload: _derivation })
      setBtnDisabled(false);
      console.log("....79999", _derivation);
    }
    else {
      if (!_flag) {
        errors = {
          target: '',
          dependentTarget: "",
          logic: "The selected visit is not in dragged field, please drag the different field",
        }
      }
      props.onSetValidations(errors);
    }
    // }))
  }

  return (
    <React.Fragment>
      <TargetContainer
        onDropTargetElement={onDropFileAutoPopulateTargetElement}
        placeholder={<span className="txt-default">Drag <i>file</i> variable.</span>}
        validations={props.validations}
        onSetValidations={onSetValidations}
        setBtnDisabled={setBtnDisabled}
        node={node}
      />

      {derivation && derivation.logic.visitId !== "" &&
        <LogicContainer
          validations={props.validations}
        onDropDependentElement={onDropFileAutoPopulateDependentElement}
          onDeleteDependent={onDeleteDependent}
          visitsList={true}
          onSetValidations={onSetValidations}
        units={units}
        setBtnDisabled={setBtnDisabled}
        />
      }
    </React.Fragment>
  )
}
export default FileNameAutoPopulation;