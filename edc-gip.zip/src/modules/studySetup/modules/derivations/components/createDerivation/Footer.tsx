import React from 'react';
// import { useSelector } from 'react-redux';
import { useNavigate, useParams } from 'react-router-dom';

function Footer(props: any) {
    const { disabled, backToDerivations, actionType } = props;
    // const {fieldDynamics} = useSelector((state: any) => state.dynamics);
    const params: any = useParams();
    // console.log("actionType..", actionType, fieldDynamics, disabled)
  
    const onCancelHandler = () => {
        backToDerivations();
        navigate('/study/derivation')
    }
    const navigate = useNavigate();

    return (
        <div className="footer-wrapper">
            <button className="btn-esecondary" onClick={!actionType ? onCancelHandler : props.onCancelHandler}>Cancel</button>
            
            <button className={disabled === true ? "btn-esecondary" : "btn-eprimary"} disabled={disabled} onClick={props.onSubmitHandler}>{parseInt(params.id) > 0 ? "Update" : 'Submit'}</button>
        </div>
    )
}

export default Footer;