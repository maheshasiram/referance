import React from "react";
import { Types } from "../../reducers/Types";
import { useDispatch, useSelector } from "react-redux";
import '../../styles/derivations.scss';
import Helper from '../../helpers/Helper';
import HeplersText from "../../helpers/HelpersText";
import { configDataType } from "../../../../../../actions/actions";
import DropdownComponent from "../../../../../../components/DropdownComponent";

function DerivationType(props: any) {
  const dispatch = useDispatch();
  const [textvar, setTextvar] = React.useState('');
  const { derivation, actionTypes, customDerivationValues } = useSelector((state: any) => state.derivations);
  const {configCodes} = useSelector((state: any) => state.application);
  const { setValidations, setBtnDisabled } = props;
  const loaded = React.useRef(false);
  const actionTypeData = actionTypes && actionTypes.map((item: any) => ({ id: item.id, formName: item.name }));

  React.useEffect(() => {
    if (!loaded.current) {
      dispatch(configDataType('ACT_TYP', (data: any) => {
        dispatch({ type: Types.FETCH_ACTION_TYPE, payload: data.ACT_TYP })
      }))
      dispatch(configDataType('CUSTOM_DERIVATION', (data: any) => {
        dispatch({ type: Types.FETCH_CUSTOM_DERIVATION, payload: data.CUSTOM_DERIVATION })
      }))
      loaded.current = true
    }
     // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);


  const onChangeHandler = (value: any) => {
    const payload = { ...{}, ...derivation };
    if (value !== "") {
      setTextvar(value)
      const _actionType = actionTypes && actionTypes.find((ele: any) => ele.id === parseInt(value));
      payload.actionType = {
        id: _actionType.id,
        name: _actionType.name,
        code: _actionType.code
      }
      payload.target.targetVariables = [];
      payload.target.targetFormIds = [];
      payload.target.targetVisitIds = [];
      payload.target.targetFieldIds = [];
      payload.logic.logicVariables = [];
      payload.dependentTargetVar = [];
      payload.dependentFieldIds = [];
      payload.logic.visitId = "";
      payload.logic.formula = {};
      
      if (payload.actionType.code === configCodes?.CustomDerivation) {
        const _customType = customDerivationValues && customDerivationValues.find((i: any) => i.code === 'CUSTOM_DERIVATION_CUSTOM_CALCULATION')
        payload.customDerivationType = _customType ? _customType : null
      } else {
        payload.customDerivationType = null
      }
    } else {
      payload.actionType = {}
      payload.calcFactor = null
      payload.customDerivationType = null
      setTextvar('')
    }
    dispatch({ type: Types.CREATE_DERIVATION, payload });
    dispatch({ type: Types.CUSTOM_TYPE_VALUE, payload: "CustomDerivation" })
    setValidations({ target: "", dependentTarget: "", logic: "" });
    setBtnDisabled(true)
  }

  return (
    <React.Fragment>
      <div className="derivation-types" onDragStart={(e: any) => { e.preventDefault() }}>
        <label className="derivation-labels text-nowrap">Action Type :</label>
        <DropdownComponent
          data={actionTypeData}
          onChangeHandler={onChangeHandler}
          defaultValue='-- Select Action --'
          selectedOption={derivation?.actionType?.id}
          disabled={derivation.id && derivation.id > 0 ? true : false}
        />
        {
          textvar || derivation.id > 0 ? <Helper className={"popover-content"}
            content={<HeplersText textvar={textvar} />}
          /> : ''
        }
      </div>
    </React.Fragment>
  )
}
export default DerivationType