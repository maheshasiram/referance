import React, { useEffect, useState } from "react";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { derivationModal, filterSelection } from "../constants/modal";
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import { useDispatch, useSelector } from "react-redux";
import { NavLink, useNavigate } from "react-router-dom";
import {
  fetchAllDerivationsForms, deleteDerivativeById,
  searchByDerivationType, fetchFindByAllByCriteria, restoreDerivativeById
} from "../actions/actions";

import { Confirm, toastAlert } from "../../../../../actions/actions";
import { Types } from "../reducers/Types";
import DropdownComponent from "../../../../../components/DropdownComponent";
import SearchField from "../../../../../common/searchField/SearchField";

import CustomToolTip from "../../../../../components/CustomToolTip";
import { FilterSeachContainer } from "../../../../../common/styleComponents/FilterBy";
import Loader from "../../../../../common/loader/Loader";
import PageCount from "../../../../../common/pagecount/PageCount";
import ReplayIcon from '@mui/icons-material/Replay';

function DerivationsDashboard() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { derivations, forms, derivationTypes, derivationParams } = useSelector((state: any) => state.derivations);
  const { currentStudy } = useSelector((state: any) => state.application);
  const loaded = React.useRef(false);
  const [calculatedVariable, setCalculatedVariable] = React.useState('');
  const [selectedActionBy, setSelectedActionBy] = useState('');
  const [Selection, setSelection] = React.useState('');
  const [pageClick, setpageChange] = useState(false);
  const typeSelection = filterSelection
  console.log('derivations........', derivations);

  useEffect(() => {
    if (!loaded.current) {
      dispatch(fetchAllDerivationsForms(currentStudy.id, () => {
        dispatch(searchByDerivationType(currentStudy.id, () => {
          dispatch(fetchFindByAllByCriteria({ ...derivationParams, studyId: currentStudy.id, formId: null, fieldName: null, configId: null }))
        }));
      }));
      loaded.current = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onDeleteRestoreDerivation = (type: any, rowData: any) => {
    dispatch(Confirm({
      status: 0, message: type === 'delete' ? `Are you sure you want to delete this derivation ?` : `Are you sure you want to restore this derivation ?`,
      onOk: () => {
        const _id = rowData.id
        // const _payload = { ...derivationParams, studyId: currentStudy.id, formId: null, fieldName: null, configId: null }
        const _payload = { ...derivationParams, studyId: currentStudy.id }
        dispatch((type === 'delete' ? deleteDerivativeById : restoreDerivativeById)(_id, () => {
          dispatch(fetchFindByAllByCriteria(_payload, (data: any) => {
            if (data && data.allDerivatives.length === 0) {
              dispatch({ type: Types.FIND_ALL_BY_CRITERIA, payload: _payload })
              setSelectedActionBy("")
              setCalculatedVariable("")
              setSelection("")
              dispatch(fetchAllDerivationsForms(currentStudy.id, () => {
                dispatch(searchByDerivationType(currentStudy.id, () => {
                  dispatch(fetchFindByAllByCriteria(_payload))
                }));
              }));
            }
          }))
          dispatch(toastAlert({
            status: 1, message: type === 'delete' ? `${rowData.actionType.name} deleted successfully` : `${rowData.actionType.name} restored successfully`, open: true
          }));
        }));
      }
    }));
  }

  const onEditDeivation = (e: any, rowData: any) => {
    navigate(`../derivation/${rowData.id}`);
  }

  const onFormChangeHandler = (value: any) => {
    const _payload = { ...derivationParams, studyId: currentStudy.id, formId: value, fieldName: null, configId: null }
    dispatch({ type: Types.FIND_ALL_BY_CRITERIA, payload: _payload })
    dispatch(fetchFindByAllByCriteria(_payload))
  }

  const onSelectDerivation = (e: any) => {
    setSelectedActionBy('');
    setCalculatedVariable('');
    setSelection(e.target.value);
    const _payload = { ...derivationParams, studyId: currentStudy.id, offset: 0, formId: null, fieldName: null, configId: null }
    dispatch({ type: Types.FIND_ALL_BY_CRITERIA, payload: _payload })
    dispatch(fetchFindByAllByCriteria(_payload))
  }

  const onChangeCalculatedVariable = (e: any) => {
    setCalculatedVariable(e.target.value)
    const _payload = { ...derivationParams, studyId: currentStudy.id, formId: null, fieldName: e.target.value, configId: null }
    dispatch({ type: Types.FIND_ALL_BY_CRITERIA, payload: _payload })
    dispatch(fetchFindByAllByCriteria(_payload))
  }

  const onChangeDerivationType = (e: any) => {
    let _payload;
    if (e.target.value) {
      setSelectedActionBy(e.target.value);
      _payload = { ...derivationParams, studyId: currentStudy.id, formId: null, fieldName: null, configId: e.target.value }
    } else {
      setSelectedActionBy('');
      _payload = { ...derivationParams, studyId: currentStudy.id, formId: null, fieldName: null, configId: null }
    }
    dispatch({ type: Types.FIND_ALL_BY_CRITERIA, payload: _payload })
    dispatch(fetchFindByAllByCriteria(_payload))
  }

  const onClearSearch = () => {
    setCalculatedVariable('')
    const _payload = { ...derivationParams, studyId: currentStudy.id, formId: null, fieldName: null, configId: null }
    dispatch({ type: Types.FIND_ALL_BY_CRITERIA, payload: _payload })
    dispatch(fetchFindByAllByCriteria(_payload))
  }

  const renderActions = (rowData: any) => {
    return (
      <React.Fragment>
        <div className="d-flex align-items-center">
          {rowData.activeStatus === true ? <React.Fragment>
            <CustomToolTip title='Edit Derivation'><EditIcon onClick={(e: any) => onEditDeivation(e, rowData)} sx={{ fontSize: 14, opacity: .8, }} /></CustomToolTip>
            <span className="px-1" > |</span>
            <CustomToolTip title='Delete Derivation'><DeleteIcon sx={{ fontSize: 14, opacity: .8 }} className='text-danger'
              onClick={() => onDeleteRestoreDerivation('delete', rowData)} /></CustomToolTip>
          </React.Fragment> : <CustomToolTip title='Restore Derivation'><ReplayIcon sx={{ fontSize: 15, opacity: .8 }} onClick={() => onDeleteRestoreDerivation('restore', rowData)} /></CustomToolTip>}
        </div>
      </React.Fragment>)
  }

  const onPage = (event: any) => {
    if ((event.page > 0 || (pageClick && event.page === 0))) {
      const _payload = { ...derivationParams, studyId: currentStudy.id, offset: event.first }
      dispatch({ type: Types.FIND_ALL_BY_CRITERIA, payload: _payload });
      dispatch(fetchFindByAllByCriteria(_payload));
      setpageChange(true)
    }
  }

  const onChangePageCount = (e: any) => {
    // const _payload = { ...derivationParams, studyId: currentStudy.id, formId: null, fieldName: null, configId: null, limit: e.target.value }
    const _payload = { ...derivationParams, studyId: currentStudy.id, limit: parseInt(e.target.value) }
    dispatch({ type: Types.FIND_ALL_BY_CRITERIA, payload: _payload });
    dispatch(fetchFindByAllByCriteria(_payload))
  }

  const derivationTypeTemplate = (rowData: any) => {
    return (<span className={`${rowData.activeStatus === false ? 'visit-restore' : "visit-title"}`} >{rowData.actionType.name}</span>)
  }

  const targetVariableTemplate = (rowData: any) => {
    return (<span className={`${rowData.activeStatus === false ? 'visit-restore' : "visit-title"}`} >{`${rowData.targetVariable.variableId} ( ${rowData.formName} )`}</span>)
  }
  console.log('derivationParams..........', derivationParams);

  return (
    <React.Fragment>
      {!derivations.allDerivatives && <Loader />}
      <div className="d-flex justify-content-between selct-field right-panel mb-2">
        <PageCount onChange={(e: any) => onChangePageCount(e)} />
        <div className="d-flex  pb-2 controls-container">
          <div className="right-panel d-flex">
            <NavLink className="btn-eprimary"
              to={`../derivation/0`}
              onClick={() => { dispatch({ type: Types.CREATE_DERIVATION, payload: derivationModal }) }}
            >Create Derivation</NavLink>
            <FilterSeachContainer>
              <select className='dropdown'
                onChange={onSelectDerivation}
                value={Selection}>
                {/* <option value=''>Filter By</option> */}
                {
                  typeSelection && typeSelection.map((i: any, index: any) => (
                    <option key={index} value={i.id}>{i.formName}</option>
                  ))
                }
              </select>
              {(Selection === 'DerivationType' || Selection === "") &&
                <select className='form-select sub-dropdown'
                  onChange={onChangeDerivationType}
                  //  disabled={Selection == "" ? true : false}
                  value={selectedActionBy} >
                  <option value='' >Search By</option>
                  {derivationTypes.map((item: any, index: number) => (
                    <option key={index} value={item.id} >{item.name}</option>
                  ))}
                </select>
              }
              {Selection === 'CalculatedVariable' && <SearchField
                value={calculatedVariable}
                onChange={onChangeCalculatedVariable}
                placeholder="Search by calculated variable"
                onClearSearch={onClearSearch}
              />}

              {Selection === 'DerivationForms' && <DropdownComponent
                className='sub-dropdown'
                data={forms}
                onChangeHandler={onFormChangeHandler}
              />
              }
            </FilterSeachContainer>
          </div>
        </div>
      </div>

      {derivations.allDerivatives && <DataTable
        scrollable
        rows={derivationParams.limit}
        paginator={(derivations && derivations.totalRecords && derivations.totalRecords > derivationParams?.limit) ? true : false}
        first={derivationParams && derivationParams.offset}
        totalRecords={derivations.totalRecords}
        value={derivations.allDerivatives}
        lazy
        onPage={(e: any) => onPage(e)}
        responsiveLayout="scroll">
        <Column field="actionType.name" body={derivationTypeTemplate} header="Derivation Type"></Column>
        <Column field="targetVariable.variableId" body={targetVariableTemplate} header="Target variable"></Column>
        <Column body={renderActions} header="Actions"></Column>
      </DataTable>}
    </React.Fragment>
  )
}
export default DerivationsDashboard;