import { Derivation, Params } from "./dataTypes"

export const derivationModal: Derivation = {
  id: 0,
  actionType: {
    id: '',
    name: '',
    code: '',
  },
  target: {
    targetFieldIds: "",
    targetFormIds: "",
    targetVisitIds: "",
    targetVariables: []
  },
  dependentTargetVar: [],
  logic: {
    logicVariables: [],
    visitId: "",
    formula: null,
  },
  calcFactor: {
    id: '',
    name: '',
    code: '',
  },
  customDerivationType: {
    id: '',
    name: '',
    code: '',
  },
  dependentFieldIds: []
}

export const derivationParam: Params = {
  pageSize: 10,
  pageNumber: 0,
  formId: '',
  first: 0
}

export const filterSelection = [
  { id: 'DerivationType', formName: 'Derivation Type' },
  { id: 'CalculatedVariable', formName: 'Target variable' },
  { id: 'DerivationForms', formName: 'Derivation Forms' }
]

export const customOperatorData = [
  { label: '+', value: '+' },
  { label: '-', value: '-' },
  { label: '*', value: '*' },
  { label: '/', value: '/' }
]

export const numericOperatorData = [
  { id: '+', formName: '+' },
  { id: '-', formName: '-' },
  { id: '*', formName: '*' },
  { id: '/', formName: '/' }
]
export const customOptionData = [
  { id: 'CustomDerivation', optionName: 'CustomDerivation', name: 'customOption' },
  { id: 'TotalScore', optionName: 'TotalScore', name: 'customOption' },
  { id: 'TotalCapsules', optionName: 'TotalCapsules', name: 'customOption' },
]

export const measurementUnits = [
  { id: 'kilometer', formName: 'Kilometer' },
  { id: 'meter', formName: 'Meter' },
  { id: 'centimeter', formName: 'Mentimeter' },
  { id: 'millimeter', formName: 'Millimeter' },
  { id: 'foot', formName: 'Foot' },
  { id: 'inch', formName: 'Inch' },
  { id: 'kilogram', formName: 'Kilogram' },
  { id: 'gram', formName: 'Gram' },
  { id: 'tonne', formName: 'Tonne' },
]