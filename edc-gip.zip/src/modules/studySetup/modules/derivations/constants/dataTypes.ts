export type derivationsDataType = {
    actionType: _actionType
    target: _target,
    logic: _logic,
    calcFactor?: any
    customDerivationType?: any
}

export type _target = {
    targetFieldIds?: string,
    targetFormIds?: string,
    targetVisitIds?: string,
    targetVariables?: any,
}

export type _logic = {
    logicVariables?: any,
    visitId?: string,
    formula?: any,
}

export type derivationItem = {
    dataType?: string,
    eventName?: string,
    eventOid?: string,
    eventsList?: any,
    group?: boolean,
    itemName?: string,
    itemOid?: string,
    operation?: string

}
export type ListItem = {
    items: [derivationItem],
    operation?: any

}
type _actionType = {
    id?: any
    name?: string
    code?: string
}

type _calFactor = {
    id?: any
    name?: string
    code?: string
}

type _customType = {
    id?: any
    name?: string
    code?: string
}

export type Derivation = {
    id?: any,
    actionType: _actionType
    target: _target,
    logic: _logic,
    calcFactor?: _calFactor
    customDerivationType?: _customType
    dependentTargetVar?: any,
    dependentFieldIds?: any
}

export type Params = {
    pageNumber: number,
    pageSize: number,
    formId: string,
    first: number
}