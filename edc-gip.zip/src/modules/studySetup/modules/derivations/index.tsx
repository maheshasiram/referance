import React from 'react';
import DerivationsDashboard from './components/DerivationsDashboard';
import './styles/derivations.scss'

const Derivations = () => {
  return (
    <React.Fragment>
      <DerivationsDashboard />
    </React.Fragment>
  )
};
export default Derivations;