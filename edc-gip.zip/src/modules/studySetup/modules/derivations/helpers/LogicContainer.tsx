import React from "react";
import { useDispatch, useSelector } from "react-redux";
import CancelIcon from '@mui/icons-material/Cancel';
import { onDragElement } from "../actions/actions";
import DropdownComponent from "../../../../../components/DropdownComponent";
import { Types } from "../reducers/Types";
import CustomToolTip from "../../../../../components/CustomToolTip";
import SelectField from "../../../../../common/selectField/SelectField";
import convert from "convert-units";

function LogicContainer(props: any) {
    const dispatch = useDispatch();
    const { derivation } = useSelector((state: any) => state.derivations);
    const { configCodes } = useSelector((state: any) => state.application);
    const { validations, onDropDependentElement, onDeleteDependent, onSetValidations, setBtnDisabled, units } = props;
    const dependentVisits = derivation.target.targetVariables.map((i: any) => i?.visitsIds[0]?.label && i.visitsIds);

    const onUnitsChangeHandler = (value: any, index: any) => {
        const _payload = { ...{}, ...derivation };
        _payload.logic.logicVariables[index].updatedUnit = value;
        onSetValidations({ logic: "" });
        setBtnDisabled(false);
        dispatch({ type: Types.CREATE_DERIVATION, payload: _payload });
    }

    const getUnits = (units: any) => {
        let _units: any = [];
        let _possiblites = convert().from(units).possibilities();
        console.log("..._possiblites", _possiblites);
        _possiblites && _possiblites.map((i: any) => {
            const obj = {
                id: i,
                formName: i
            }
            _units.push(obj);
            return obj
        });
        return _units
    }

    return (
        <div>
            {derivation.dependentTargetVar.length === 0 ?
                <div className={derivation.actionType.code === configCodes?.DateCalculation ? "logic-wrapper mt-3 px-0" : "logic-wrapper"}>
                    <label className="derivation-labels">Dependent Variables:  {(validations && validations.logic) && <span className=" ms-2 text-danger">{validations.logic}</span>}
                    </label>
                    <div className="logic-container">
                        {
                            derivation?.logic?.logicVariables?.map((item: any, index: number) => (

                                <div className={(derivation.actionType.code === configCodes?.FileAutoPopulation || derivation.actionType.code === configCodes?.VariableAutoPopulation) ? "element w-100" : "element"}
                                    key={index}
                                    onDragOver={onDragElement}
                                    onDrop={() => onDropDependentElement(item.type === 'hour' ? 'real' : item.type, index)}>
                                    {
                                        derivation?.logic?.logicVariables[index].itemName ?
                                            <ul className="vars-container">
                                                <li>
                                                    {console.log("...41", item)}
                                                    <span>{item.itemName}
                                                        <CustomToolTip title="Data Type"><b>({item.dataType})</b></CustomToolTip>
                                                        <CustomToolTip title="Form Name"><b>({item.formName})</b></CustomToolTip>
                                                        {/* <b>({item.dataType})({item.formName})</b> */}
                                                    </span>
                                                    {item.units && <span>{item.units}</span>}
                                                    {item.units && <DropdownComponent
                                                        // data={units}
                                                        data={getUnits(item.units)}
                                                        className='w-10'
                                                        defaultValue='Select Unit'
                                                        onChangeHandler={(value: any) => onUnitsChangeHandler(value, index)}
                                                        selectedOption={derivation.logic.logicVariables[index].updatedUnit}
                                                    />}
                                                    <CancelIcon
                                                        onClick={() => onDeleteDependent(index, item.type)}
                                                    />
                                                </li>
                                            </ul>
                                            : <span className="date">Drag a <i>{item.type}</i> variable here</span>
                                    }

                                </div>
                            ))
                        }
                    </div>
                </div> :
                <div>
                    <div className={derivation.actionType.code === configCodes?.CustomDerivation ? "logic-wrapper " : "logic-wrapper"}>
                        <label className="derivation-labels">Dependent Target Variable: {(validations && validations.dependentTarget) && <span className=" ms-2 text-danger">{validations.dependentTarget}</span>}
                        </label>
                        <div className="calc-wrapper">
                            <div className="logic-container">
                            {
                                derivation?.dependentTargetVar.map((item: any, index: any) => (
                                    <div className={(derivation.actionType.code === configCodes?.VariableAutoPopulation ? "element w-100" : "element")}
                                        key={index}
                                        onDragOver={onDragElement}
                                        onDrop={() => onDropDependentElement(item.type === 'date' ? 'date' : item.type, index)}>
                                        {derivation?.dependentTargetVar[index].fieldName ?
                                            <ul className="vars-container">
                                                    <li className="var-dependent">
                                                    <span className='d-flex'>{item.fieldName}
                                                        <CustomToolTip title="Data Type"><b>({item.dataType})</b></CustomToolTip>   
                                                    </span>
                                                    <div className="target-wrapper" >
                                                        <SelectField
                                                            id={"visitName"}
                                                            defaultValue={"Select Visit"}
                                                            isDisabled={true}
                                                            isClearable={true}
                                                            isSearchable={true}
                                                            name={"VistsList"}
                                                            value={dependentVisits && dependentVisits[0]}
                                                            isMulti={true}
                                                        />
                                                    </div>
                                                    <CancelIcon
                                                        onClick={() => onDeleteDependent(index, item.type)} />
                                                    </li>
                                            </ul> : <span className="date">Drag a <i>{item.type}</i> variable here</span>
                                        }
                                    </div>
                                ))
                            }
                        </div>
                    </div>
                </div>
                </div>
            }
        </div>
    )
}
export default LogicContainer