import React from "react";
import { useSelector } from "react-redux";

function HeplersText(props: any) {
    const [typeMessages, setTypeMessages]: any = React.useState(null)
    const { derivation } = useSelector((state: any) => state.derivations);
    const { textvar } = props

    
    React.useEffect(() => {
        if (textvar === 62 || derivation.actionType.id === 62) {
            setTypeMessages(<div className="" role='alert'>
                <p> <strong>Note : </strong>Calculated Variable Type Is Date, So Logic Allows Only Date
                    variables.</p>
                <p>
                    Action type is Date Calculation.<br />
                    Date Calculation can be done by selecting either Days or Hours as Calculation Factor.<br />
                    If Days is selected, then logic should be one <em>date variable</em> and one <em>number variable</em>.<br />
                    If Hours is selected, then logic should be one <em>date variable</em>, one <em>hours variable</em> and one <br />
                    <em>time variable</em>.
                </p>
            </div>
            )
        } else if (textvar === 63 || derivation.actionType.id === 63) {
            setTypeMessages(
                <div className="" role="alert">
                    <p> <strong>Note : </strong> Action type Is Time Calculation.<br />
                    </p>
                    <p>
                        Auto population can be created by dragging and dropping same type of variables into the<br />
                        Time Calculation can be created by dragging and dropping one <em>time variable</em> and  one <em>hours <br />
                            variable</em> into the Logic section.</p>
                </div>
            )
        } else if (textvar === 64 || derivation.actionType.id === 64) {
            setTypeMessages(
                <div className="" role="alert">
                    <p> <strong>Note : </strong>
                        Action type is Auto Populate Calculation.<br /> </p>
                    <p>Auto population can be created by dragging and dropping same type of variables into the<br />
                        Logic section.</p>
                </div>
            )
        } else if (textvar === 61 || derivation.actionType.id === 61) {
            setTypeMessages(<div className="" role="alert">
                <p><strong>Note : </strong>
                    Action type is Numeric Calculation.<br />
                </p>
                <p>Drag a Target Variable type is Integer and Real,<br />
                    so drag a Dependent Variable allows only Response type as text, Single select,radio &  Data type as Integer , <br />
                    Real , Date , Time variables.</p>
            </div>)
        } else if (textvar === 65 || derivation.actionType.id === 65) {
            setTypeMessages(<div className="" role="alert">
                <p><strong>Note : </strong>
                    Action type is FileName Autopopulate Calculation.<br />
                </p>
                <p>Drag a Target Variable & Dependent Variable type is file variable.Target Variable and<br />
                    Dependent variable must drag from different Forms </p>
            </div>)
        }
        else if (textvar === 66 || derivation.actionType.id === 66) {
            setTypeMessages(<div className="" role="alert">
                <p><strong>Note : </strong>
                    Action type is Custom Derivation.<br />
                </p>
                <p>Drag a Target Variable type is Response Type as - text & Data Type- Integer.<br />
                    Drag a Dependent Target Variable is Response Type as text & Data Type-Integer(Total Score)<br />
                    Drag a Dependent Target Variable is Response Type as text & Data Type-Date(Total Capsules)<br />
                    Drag a Dependent Variable type is Response Type as - single-select , multi-select , checkbox <br />
                    radio & Data Type- String,integer. <br /> 
                    While dragging a variable to Dependent variable , the Response Type must be same.</p>
            </div>)
        }

    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])


    return (
        <React.Fragment>
            <div className="helpersText-Derivations" >
                {
                    typeMessages
                }
            </div>
        </React.Fragment>
    )

}
export default HeplersText;