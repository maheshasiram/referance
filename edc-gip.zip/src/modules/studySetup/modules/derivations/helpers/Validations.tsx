import store from "../../../../../store/store";
const _configCodes: any = store.getState().application.configCodes;

export const validateDerivation = (payload: any, nodeElement: any, type: any, section: any) => {
    console.warn('nodeElement in der.......', nodeElement);

    const numericLogicType = ['integer', 'real', 'date', 'time']
    const matchTargetVariable = payload.target.targetVariables.filter((ele: any) => ele.id === nodeElement.id);
    // const matchTargetLogicForm = payload.target.targetVariables.filter((ele: any) => ele.formId !== nodeElement.formId);
    const matchTargetLogicGroup = payload.target.targetVariables.filter((ele: any) => ele.groupId == null && nodeElement.groupId != null);
    const matchTargetVariableGroup = payload.target.targetVariables.filter((ele: any) => (ele.groupId == null && nodeElement.groupId != null) || (ele.groupId != null && nodeElement.groupId == null));
    let matchLogicVariable: any;
    let customTargetVariable;
    let customLogicVariable;
    const targetGroupValue = payload.target.targetVariables.filter((ele: any) => (ele.formId !== nodeElement.formId) && nodeElement.groupId !== null)
    const sameTargetVisits = payload.target.targetVariables.filter((ele: any) => (ele.formId === nodeElement.formId) && (ele.id !== nodeElement.id));
    let sameVariables: any
    //  = payload.target.targetVariables.filter((ele: any) => (ele.formId !== nodeElement.formId) && (ele.id !== nodeElement.id));

    // let isGroup;
    // let customSource: any;
    let autoPopulateResponseOptions: any = null;

    payload?.logic?.logicVariables?.map((item: any) => {
        console.warn("....25", item);
        if (item.fieldId === nodeElement.id) {
            sameVariables = true
        }
        return null
    })

    if (payload.actionType.code === _configCodes?.NumericCalculation) {
        if (nodeElement !== 'custumItem') {
            customTargetVariable = type.filter((ele: any) => (ele === nodeElement.datatype?.name && nodeElement.responseType.code === _configCodes?.text));
            customLogicVariable = numericLogicType.filter((ele: any) => ele === nodeElement.datatype?.name);
        }
        payload?.logic?.logicVariables?.map((item: any) => {
            matchLogicVariable = item?.fields?.filter((ele: any) => ele.itemOid === nodeElement.id);
            return null
        });
        payload?.logic?.logicVariables?.map((item: any) => {
            item?.fields?.filter((ele: any) => {
                if (ele.fieldId === nodeElement.id) {
                    sameVariables = true
                }
                return null
            });
            return null
        })
    } else if (payload.actionType.code === _configCodes?.VariableAutoPopulation) {
        customTargetVariable = nodeElement?.datatype?.name !== type ? [type] : [];
        customLogicVariable = payload?.target?.targetVariables?.filter((ele: any) => (ele.datatype.name === nodeElement.datatype.name && ele.responseType.name === nodeElement.responseType.name));
        const responseOptions: any = [];
        payload?.target?.targetVariables?.map((ele: any) => {
            if ((ele.responseOptions && nodeElement.responseOptions) && (ele.responseOptions.length === nodeElement.responseOptions.length)) {
                ele.responseOptions.map((res: any) => {
                    nodeElement.responseOptions.map((nres: any) => {
                        if ((responseOptions.indexOf(nres.response) === -1) && (nres.response === res.response)) {
                            responseOptions.push(res.response);
                        }
                        return null
                    })
                    return null
                })
            }
            return null
        })
        console.log("...6777", customLogicVariable);
        if (nodeElement.responseOptions) {
            if (responseOptions.length > 0 && nodeElement.responseOptions.length === responseOptions.length) {
                autoPopulateResponseOptions = true
            } else {
                autoPopulateResponseOptions = false
            }
        }
    }
    else {
        if (payload.actionType.code === _configCodes?.CustomDerivation && section === 'logic') {
            payload.logic.logicVariables && payload.logic.logicVariables.map((i: any) => {
                if (!matchLogicVariable) {
                    matchLogicVariable = i.fields.filter((ele: any) => ele.fieldId === nodeElement.id);
                }
                customLogicVariable = i.fields.filter((ele: any) => (ele.responseType === nodeElement.responseType.name));
                // customSource = i.fields.filter((ele: any) => ele.responseOptions);
                return null
            })
        }
    }
    if (payload.actionType.code === _configCodes?.FileAutoPopulation || payload.actionType.code === _configCodes?.VariableAutoPopulation) {
        // isGroup = nodeElement?.groupId ? true : false
    }

    let errors: any = false;

    if (section === 'target') {
        console.log("...payload.actionType.code", nodeElement?.datatype?.name, type)
        if (payload.actionType.code === _configCodes?.NumericCalculation || payload.actionType.code === _configCodes?.VariableAutoPopulation || payload.actionType.code === _configCodes?.FileAutoPopulation) {
            if (nodeElement.groupId !== null) {
                errors = {
                    target: 'Please drag a non-group variable. ',
                    dependentTarget: "",
                    logic: ""
                }
            }
            if ((nodeElement.groupId !== null && nodeElement.defaultValue !== '') || (nodeElement.groupId === null && nodeElement.defaultValue !== '')) {
                errors = {
                    target: `Please drag a variable ${nodeElement.groupId !== null && nodeElement.defaultValue !== '' ? "from non-group" : ''}  without default value`,
                    dependentTarget: "",
                    logic: ""
                }
            }
            if (payload.actionType.code === _configCodes?.NumericCalculation) {
                if (sameVariables) {
                    errors = {
                        target: "Target variable and Dependent variable should be different variable.",
                        dependentTarget: "",
                        logic: ''
                    }
                }
            }
        }
            console.log("...93", nodeElement, _configCodes?.NumericCalculation)
        if ((payload.actionType.code === _configCodes?.NumericCalculation || payload.actionType.code === _configCodes?.VariableAutoPopulation) ? customTargetVariable.length === 0 : nodeElement?.datatype?.name !== type) {
            errors = {
                target: `Please drag a ${payload.actionType.code === _configCodes?.NumericCalculation ? "data type (integer / real) & Response Type (text)" : payload.actionType.code === _configCodes?.VariableAutoPopulation ? "Vaild" : type} variable`,
                dependentTarget: ``,
                logic: ``
            }
        }
        if (sameVariables) {
            errors = {
                target: "Target variable and Dependent variable should be different variable.",
                dependentTarget: "",
                logic: ''
            }
        }
        else if (sameTargetVisits.length > 0) {
            errors = {
                target: 'Please drag a target variable from another form',
                dependentTarget: "",
                logic: ""
            }
        }
        else if (matchTargetVariable.length > 0) {
            errors = {
                target: 'Please drag different calculated variable',
                dependentTarget: "",
                logic: ""
            }
        }
        else if (matchTargetVariableGroup.length > 0) {
            errors = {
                target: `Please drag a ${matchTargetVariableGroup && matchTargetVariableGroup[0].groupId != null ? 'Group' : 'Non-Group'} variable`,
                dependentTarget: "",
                logic: ""
            }
        }
        else if (matchLogicVariable && matchLogicVariable.length > 0) {
            errors = {
                target: 'This variable already exists in logic, please drag different variable',
                dependentTarget: "",
                logic: ""
            }
        }
        else if (payload.actionType.code === _configCodes?.VariableAutoPopulation && customLogicVariable?.length === 0 && payload?.target?.targetVariables.length > 0) {
            errors = {
                target: 'Logic variable data type & response type should be same',
                dependentTarget: "",
                logic: ""
            }
        }
        else if ((nodeElement.groupId !== null && nodeElement.defaultValue !== '') || (nodeElement.groupId === null && nodeElement.defaultValue !== '')) {
            errors = {
                target: `Please drag a variable ${nodeElement.groupId !== null && nodeElement.defaultValue !== '' ? "from non-group" : ''}  without default value`,
                dependentTarget: "",
                logic: ""
            }
        }
    }

    else if (section === 'logic') {
        console.log("...174", autoPopulateResponseOptions, payload.actionType.code === _configCodes?.VariableAutoPopulation)
        if (nodeElement !== 'custumItem') {
            if (matchTargetLogicGroup.length > 0) {
                if (payload.actionType.code !== _configCodes?.CustomDerivation) {
                errors = {
                    target: '',
                    dependentTarget: "",
                    logic: "Please drag a non-group variable. "
                }
            }
                else {
                    errors = {
                        target: '',
                        dependentTarget: "",
                        logic: "Drag a response optional variable from non- group "
                    }
                }
            }
            if (matchTargetVariable.length > 0) {
                errors = {
                    target: '',
                    dependentTarget: "",
                    logic: "Calculated variable and logic variable should be different variable.",
                }
            }
            if ((payload.actionType.code === _configCodes?.DateCalculation || (payload.actionType.code === _configCodes?.TimeCalculation))) {
                if (targetGroupValue.length > 0) {
                    errors = {
                        target: '',
                        dependentTarget: "",
                        logic: "Drag a variable from same form and same group"
                    }
                }
                if (matchTargetLogicGroup.length > 0) {
                    errors = {
                        target: '',
                        dependentTarget: "",
                        logic: "Please drag a variable from non-group"
                    }
                }
            }
            else if ((payload.actionType.code === _configCodes?.VariableAutoPopulation) || (payload.actionType.code === _configCodes?.FileAutoPopulation)) {
                if (sameTargetVisits.length > 0) {
                    errors = {
                        target: '',
                        dependentTarget: "",
                        logic: "Please drag a variable from different form"
                    }
                }
            }
            if (((payload.actionType.code === _configCodes?.NumericCalculation ||
                payload.actionType.code === _configCodes?.VariableAutoPopulation) ? customLogicVariable?.length === 0 : nodeElement.datatype.name !== type)
                || (payload.actionType.code === _configCodes?.NumericCalculation && (nodeElement.responseType.code === _configCodes?.['multi-select']
                    || nodeElement.responseType.code === _configCodes?.checkbox))) {
                if (payload.actionType.code !== _configCodes?.CustomDerivation) {
                    errors = {
                        target: "",
                        dependentTarget: "",
                        logic: payload.actionType.code === _configCodes?.VariableAutoPopulation ? 'Calculated and logic variable data type & response type should be same' : `Please drag ${payload.actionType.code === _configCodes?.NumericCalculation ? "integer / real / date / time and we can't drag responseType multi-select and checkbox" : type} variable`
                    }
                }
            }
        }
        if (payload.actionType.code === _configCodes?.CustomDerivation) {
            if (!nodeElement.responseOptions) {
                errors = {
                    target: '',
                    dependentTarget: "",
                    logic: "Please drag a variable which have response options"
                }
            }
            else if (matchLogicVariable && matchLogicVariable.length > 0) {
                errors = {
                    target: '',
                    dependentTarget: "",
                    logic: "This variable has already been dragged to the dependent variable, Please drag another variable."
                }
            }
        }
    }
    return errors;
}

export const customDerivationValidaton = (payload: any, nodeElement: any, type: any, section: any) => {
    // const { customDerivationOptionType } = store.getState().derivations;
    let matchDependentTargetVariable;
    let errors: any = false;
    const matchTargetDependentVariable = payload.target.targetVariables.filter((ele: any) => ele.id === nodeElement.id);
    const matchTargetDependentGroup = payload.target.targetVariables.filter((ele: any) => ele.groupId == null && nodeElement.groupId != null);
    const matchGroupNonGroup = payload.target.targetVariables.filter((ele: any) => (ele.groupId == null && nodeElement.groupId != null) || (ele.groupId != null && nodeElement.groupId == null));
    const sameFormVariable = payload.target.targetVariables.filter((ele: any) => ele.formId !== nodeElement.formId);

    // validation for target variable in custom derivation 
    if (section === 'target') {
        if (payload.actionType.code === _configCodes?.CustomDerivation) {
            if (nodeElement.datatype.name !== type || nodeElement.responseType.code !== _configCodes?.text) {
                errors = {
                    target: 'Please drag a Data Type (integer) & Response Type (text) variable.',
                    dependentTarget: "",
                    logic: ""
                }
            }
            if (payload.target.targetVariables.length >= 1) {
                errors = {
                    target: 'You can not drag more that one traget variable',
                    dependentTarget: "",
                    logic: ""
                }
            }
            if (matchTargetDependentVariable.length > 0) {
                errors = {
                    target: 'dragged variable is already exist',
                    dependentTarget: "",
                    logic: ""
                }
            }
            if (nodeElement.groupId !== null) {
                errors = {
                    target: 'Please drag a non-group variable. ',
                    dependentTarget: "",
                    logic: ""
                }
            }
            if ((nodeElement.groupId !== null && nodeElement.defaultValue !== '') || (nodeElement.groupId === null && nodeElement.defaultValue !== '')) {
                errors = {
                    target: `Please drag a variable ${nodeElement.groupId !== null && nodeElement.defaultValue !== '' ? "from non-group" : ''}  without default value`,
                    dependentTarget: "",
                    logic: ""
                }
            }
        }

    }
    //validation for dependent target variable in total score custom derivation
    else if (payload.actionType.code === _configCodes?.CustomDerivation && section === 'dependentTarget') {
        if (matchTargetDependentGroup.length > 0) {
            errors = {
                target: '',
                dependentTarget: "Drag a non-group variable",
                logic: "",
            }
        }
        else if (matchGroupNonGroup.length > 0) {
            errors = {
                target: '',
                dependentTarget: "Please drag a group variable",
                logic: ""
            }
        } else if (sameFormVariable.length > 0) {
            errors = {
                target: '',
                dependentTarget: "Drag a variable from same form",
                logic: ""
            }
        }
        else if (payload.target.targetVariables.length > 0 && payload.target.targetVisitIds.length === 0) {
            errors = {
                target: '',
                dependentTarget: "Select the visits form target",
                logic: ""
            }
        }
        // if (customDerivationOptionType.optionName == 'TotalScore') {
        if (payload.customDerivationType.code === _configCodes?.TotalScore) {
            if (payload.dependentTargetVar.length >= 1) {
                errors = {
                    target: '',
                    dependentTarget: "You can not drag more that one Dependent Target variable",
                    logic: ""
                }
            }
            else if (nodeElement.datatype.name !== type || nodeElement.responseType.code !== _configCodes?.text) {
                errors = {
                    target: '',
                    dependentTarget: "Please drag integer variable and responsetype text",
                    logic: ""
                }
            } else if (matchTargetDependentVariable.length > 0) {
                errors = {
                    target: '',
                    dependentTarget: "Target variable and dependent target variable should be different variable.",
                    logic: "",
                }
            }
        }
        //validation for dependent target variable in total capsule custom derivation
        else if (payload.customDerivationType.code === 'CUSTOM_DERIVATION_TOTAL_CAPSULES') {
            matchDependentTargetVariable = payload.dependentTargetVar.find((ele: any) => ele.fieldId !== '');
            if (nodeElement.datatype.name !== type) {
                errors = {
                    target: '',
                    dependentTarget: "Please drag Date variable.",
                    logic: ""
                }
            }
            else if (matchDependentTargetVariable && matchDependentTargetVariable.fieldId === nodeElement.id) {
                errors = {
                    target: '',
                    dependentTarget: "You can not drag same variable",
                    logic: ""
                }
            }
        }
    }
    return errors;
}

export const validateOnSubmit = (payload: any) => {
    let numaricLogicValue: any = false;
    let numaricLogicOperation: any;
    // let customLogicOperation: any;
    let numaricLogic: any = true;
    // let customLogicVariable: any = false;
    let numariclogicUnits: any = false;
    let customeLogicItemList: any = false;
    let responseOptionValues: any = true;
    let dependentTargetLogicValue;
    // let logicUnitValue;
    const targetVisitSelection = payload.target.targetVariables.filter((ele: any) => ele.visitsIds.length === 0);
    const logicValue = payload.logic.logicVariables.filter((ele: any) => ele.fieldId === "");
    const logicUnitValue = payload.logic.logicVariables.filter((ele: any) => ele.units !== "" && ele.updatedUnit === "");
    let formulaValidation: any = false;
    if (payload.actionType.code === _configCodes?.NumericCalculation && payload.logic.formula && payload.logic.logicVariables.length > 0) {
        if (payload.logic.formula.formulaCode === 'BMI') {
            payload.logic.logicVariables.map((item: any) => {
                if (item.numeratorFields.length <= 0 || item.denominatorFields.length <= 0) {
                    formulaValidation = true
                }
                return null
            })
        }
        if (payload.logic.formula.formulaCode === 'AGE') {
            payload.logic.logicVariables.map((item: any) => {
                item.numeratorFields.map((subItem: any) => {
                    if (subItem.fieldName === "") {
                        formulaValidation = true
                    }
                    return null
                });
                return null
            });
        }
    }

    if ((payload.actionType.code === _configCodes?.NumericCalculation) && payload.logic.logicVariables) {
        numaricLogic = false;
        payload.logic.logicVariables.map((item: any) => {
            if (item?.fields?.filter((ele: any) => ele.operation === "").length > 1) {
                numaricLogicValue = true;
            }
            if (item?.fields?.filter((ele: any) => !ele.fieldId).length > 0) {
                // customLogicVariable = true;
            }
            if (payload?.logic?.logicVariables?.length > 1 || item?.fields?.length > 1) {

                if (item.fields && item.fields.filter((ele: any) => ele.fieldName).length > 0) {
                    numaricLogic = true
                }

                if (item?.fields?.filter((ele: any) => ele.units !== "" && ele.updatedUnit === "").length > 0) {
                    numariclogicUnits = true;
                }
            }
            return null
        });
        numaricLogicOperation = payload.logic.logicVariables.filter((ele: any) => ele.operation === "");
        if (formulaValidation) {
            return {
                target: "",
                dependentTarget: "",
                logic: "Please complete the formula",
            }
        }
        if (numariclogicUnits) {
            return {
                target: "",
                dependentTarget: "",
                logic: "Please select the unit  ",
            }
        }
    }

    const customLogicOperation = payload.logic.logicVariables.filter((ele: any) => !ele.expression);
    customeLogicItemList = payload.logic.logicVariables.map((item: any) => item.fields)

    if (payload.actionType.code === _configCodes?.CustomDerivation) {
        payload?.logic?.logicVariables?.map((item: any) => {
            item.fields.map((ele: any) => {
                if (ele.responseOptions.filter((val: any) => val.value === "").length > 0) {
                    responseOptionValues = false
                }
                return null
            });
            return null
        });
    }

    if (payload.target.targetVariables.length <= 0) {
        return {
            target: "Please drag a variable in target field ",
            dependentTarget: "",
            logic: "",
        }
    }
    else if (payload.target.targetVariables.length > 0 && targetVisitSelection.length > 0) {
        return {
            target: "Please select the visits in target field",
            dependentTarget: "",
            logic: "",
        }
    }

    else if (payload.actionType.code !== _configCodes?.CustomDerivation && Object.keys(payload.logic.formula).length === 0) {
        if (payload.target.targetVariables.length > 0 && payload.logic.visitId === "") {
            return {
                target: "Please select the visit from visits drop-down",
                dependentTarget: "",
                logic: "",
            }
        }
        else if ((logicValue && logicValue.length > 0) || (payload.logic.logicVariables && payload.logic.logicVariables.length === 0) || !numaricLogic) {
            return {
                target: "",
                dependentTarget: "",
                logic: "Logic is incomplete please drag valid variable",
            }
        }
        else if (numaricLogicValue || (numaricLogicOperation && numaricLogicOperation.length > 1)) {
            return {
                target: "",
                dependentTarget: "",
                logic: "Please select operation in below variables",
            }
        }
        else if (logicUnitValue && logicUnitValue.length > 0) {
            return {
                target: "",
                dependentTarget: "",
                logic: "Please select the unit",
            }
        }
    }

    else if (payload.actionType.code === _configCodes?.CustomDerivation) {
        if (((payload.target.targetVariables.length > 0 && payload.dependentTargetVar.length > 0 && payload.logic.visitId !== "") || (payload.target.targetVariables.length > 0 && payload.logic.visitId !== ""))) {
            if (customLogicOperation && customLogicOperation.length > 0) {
                return {
                    target: "",
                    dependentTarget: "",
                    logic: "Please select operator",
                }
            }

            if (customeLogicItemList[0].length < 2) {
                return {
                    target: '',
                    dependentTarget: "",
                    logic: 'To complete the logic we need at-least two variables'
                }
            }
            if (!responseOptionValues) {
                return {
                    target: '',
                    dependentTarget: "",
                    logic: 'Please enter valid value in below custom variable!'
                }
            }
        }

        if (payload.customDerivationType.code === _configCodes?.CustomCalculation) {
            if (payload.target.targetVariables.length > 0 && payload.logic.visitId === "") {
                return {
                    target: "Please select the visit from visits drop-down",
                    dependentTarget: "",
                    logic: "",
                }
            }
        }
        else if (payload.customDerivationType.code === _configCodes?.TotalScore) {
            if (payload.target.targetVariables.length > 0 && payload.dependentTargetVar.length === 0) {
                return {
                    target: "",
                    dependentTarget: "Please drag a dependet target variable",
                    logic: "",
                }
            }
            else if (payload.target.targetVariables.length > 0 && payload.dependentTargetVar.length > 0 && payload.logic.visitId === "") {
                return {
                    target: "",
                    dependentTarget: "Please select the visit from visits drop-down",
                    logic: "",
                }
            }
        }
        else if (payload.customDerivationType.code === _configCodes?.TotalCapsules) {
            dependentTargetLogicValue = payload.dependentTargetVar.filter((ele: any) => ele.fieldId === "");
            if (payload.target.targetVariables.length > 0 && dependentTargetLogicValue.length > 0) {
                return {
                    target: "",
                    dependentTarget: "Please drag a dependet target variable",
                    logic: "",
                }
            }
            else if (payload.target.targetVariables.length > 0 && payload.logic.visitId === "") {
                return {
                    target: "",
                    dependentTarget: "Please select the visit from visits drop-down",
                    logic: "",
                }
            }
        }
    }
    return true;
}

export const formulaValidation = (payload: any, nodeElement: any, formula: string) => {
    let errors: any = false;
    const BMIsameAsTarget: any = [];
    const sameVariable: any = [];
    const nonGroupLogic = payload.target.targetVariables.filter((ele: any) => ele.groupId == null && nodeElement.groupId != null);

    payload?.target?.targetVariables.map((item: any) => {
        if (item.id === nodeElement.id) {
            BMIsameAsTarget.push(item)
        }
        return null
    })
    payload?.logic?.logicVariables?.map((item: any) => {
        if (item.numeratorFields.length > 0) {
            item.numeratorFields.map((subItem: any) => {
                if (subItem.fieldId === nodeElement.id) {
                    sameVariable.push(item)
                }
                return null
            })
        } else if (item.denominatorFields.length > 0) {
            item.denominatorFields.map((subItem: any) => {
                if (subItem.fieldId === nodeElement.id) {
                    sameVariable.push(item)
                }
                return null
            })
        }
        return null
    })

    if (formula === 'BMI') {
        if (BMIsameAsTarget.length > 0) {
            errors = {
                target: '',
                dependentTarget: "",
                logic: "Target and logic variable should not be same"
            }
        }
        else if (nodeElement.dataType !== 'integer') {
            errors = {
                target: '',
                dependentTarget: "",
                logic: "Please drag integer variable"
            }
        } else if (sameVariable.length > 0) {
            errors = {
                target: '',
                dependentTarget: "",
                logic: "Numerator and denominator value should not be same"
            }
        }
        else if (nonGroupLogic.length > 0) {
            errors = {
                target: '',
                dependentTarget: "",
                logic: "Please deag a variable from non-group"
            }
        }
    } else if (formula === 'AGE') {
        if (nodeElement.dataType !== 'date') {
            errors = {
                target: '',
                dependentTarget: "",
                logic: "Please drag date variable"
            }
        }
        else if (sameVariable.length > 0) {
            errors = {
                target: '',
                dependentTarget: "",
                logic: "Numerator variables should not be same"
            }
        }
        else if (nonGroupLogic.length > 0) {
            errors = {
                target: '',
                dependentTarget: "",
                logic: "Please deag a variable from non-group"
            }
        }
    }
    return errors;
}