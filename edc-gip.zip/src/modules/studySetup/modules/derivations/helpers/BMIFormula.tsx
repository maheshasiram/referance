import React from 'react'
import { useDispatch, useSelector } from "react-redux";
import { Types } from '../reducers/Types';
import CancelIcon from '@mui/icons-material/Cancel';
import { formulaValidation } from './Validations';
// import { fetchVisitsAssignedToFieldId } from '../actions/actions';

function BMIFormula(props: any) {
    const dispatch = useDispatch();
    const { derivation } = useSelector((state: any) => state.derivations);
    const { node, validations, onSetValidations, setBtnDisabled } = props;
    const onDragElement = (e: any) => {
        e.preventDefault()
    }

    const onNumeratorDrop = (index: number) => {
        const payload = { ...{}, ...derivation }
        let _flag = false;
        const _numeratorLength = payload.logic.logicVariables[index].numeratorFields.length <= 0
        let errors: any = _numeratorLength && formulaValidation(derivation, node, 'BMI')
        const _numeratorFields = {
            "fieldName": node.label,
            "fieldId": node.id,
            "formId": node.formId,
            "dataType": node.datatype.name,
            "operation": "",
            "units": "",
            "updatedUnit": ""
        }
        // _numeratorLength && dispatch(fetchVisitsAssignedToFieldId(node.id, (response: any) => {
        //     if (response.data) {
        //         response.data.map((ele: any) => {
        //             if (ele.id === parseInt(payload.logic.visitId)) {
        //                 _flag = true;
        //             }
        //             return null
        //         })
        //     }
        _numeratorLength && node.visits.map((ele: any) => {
            if (ele.id === parseInt(payload.logic.visitId)) {
                _flag = true;
            }
            return null
        })
            if (errors === false && _flag) {
                if (payload.logic.logicVariables[index].numeratorFields.length <= 0) {
                    payload.logic.logicVariables[index].numeratorFields.push(_numeratorFields)
                    onSetValidations({ logic: "" });
                }
            }
            else {
                if (!_flag) {
                    errors = {
                        target: '',
                        dependentTarget: "",
                        logic: "The dragged variable is not assigned to selected visit, please drag different variable",
                    }
                }
                props.onSetValidations(errors);
            }
        // }));
        setBtnDisabled(false);
        dispatch({ type: Types.CREATE_DERIVATION, payload: payload });
    }
    const onDenominatorDrop = (index: number) => {
        const payload = { ...{}, ...derivation }
        const _denominatorFields: any = []
        let _flag = false;
        const _denominatorLength = payload.logic.logicVariables[index].denominatorFields.length <= 0
        let errors: any = _denominatorLength && formulaValidation(derivation, node, 'BMI')
        for (let i = 0; i < 2; i++) {
            _denominatorFields.push({
                "fieldName": node.label,
                "fieldId": node.id,
                "formId": node.formId,
                "dataType": node.datatype.name,
                "operation": i === 0 ? "*" : "",
                "units": "",
                "updatedUnit": ""
            })
        }
        // _denominatorLength && dispatch(fetchVisitsAssignedToFieldId(node.id, (response: any) => {
        //     if (response.data) {
        //         response.data.map((ele: any) => {
        //             if (ele.id === parseInt(payload.logic.visitId)) {
        //                 _flag = true;
        //             }
        //             return null
        //         })
        //     }
        _denominatorLength && node.visits.map((ele: any) => {
            if (ele.id === parseInt(payload.logic.visitId)) {
                _flag = true;
            }
            return null
        })
            if (errors === false && _flag) {
                if (payload.logic.logicVariables[index].denominatorFields.length <= 0) {
                    payload.logic.logicVariables[index].denominatorFields = _denominatorFields
                    onSetValidations({ logic: "" });
                }
            } else {
                if (!_flag) {
                    errors = {
                        target: '',
                        dependentTarget: "",
                        logic: "The dragged variable is not assigned to selected visit, please drag different variable",
                    }
                }
                props.onSetValidations(errors);
            }
        // }))
        dispatch({ type: Types.CREATE_DERIVATION, payload: payload });
    }

    const onDelete = (e: any, type: string, index: number) => {
        const payload = { ...{}, ...derivation }
        if (type === 'numerator') {
            payload.logic.logicVariables[index].numeratorFields = []
        } else {
            payload.logic.logicVariables[index].denominatorFields = []
        }
        onSetValidations({ logic: "" });
        setBtnDisabled(false);
        dispatch({ type: Types.CREATE_DERIVATION, payload: payload });
    }
    return (
        <React.Fragment>
            <label className="derivation-labels">BMI Formula:{(validations && validations.logic) && <span className=" ms-2 text-danger">{validations.logic}</span>}</label>
            <div className='bmi-formula-main'>
                <div className='bmi-formula'>
                    <div className='bmi-numerator'>
                        {
                            derivation?.logic?.logicVariables?.map((item: any, index: number) => (
                                <div key={index} className='bmi-numerator-value'
                                    onDragOver={onDragElement}
                                    onDrop={() => onNumeratorDrop(index)}>
                                    {
                                        item.numeratorFields.length > 0 ?
                                            item.numeratorFields.map((subItem: any,index:any) => (
                                                <div key={index}>
                                                    <span>{subItem.fieldName}</span>
                                                    <CancelIcon onClick={(e: any) => onDelete(e, 'numerator', index)} />
                                                </div>
                                            ))
                                            : <span>Drag a integer variable here</span>
                                    }
                                </div>
                            ))
                        }
                    </div>
                    <span className='bmi-divider'></span>
                    <div className='bmi-denominator'>
                        <div className='bmi-brackets'>
                            {
                                derivation?.logic?.logicVariables?.map((item: any, index: number) => (
                                    <div key={index} className='bmi-denominator-value'
                                        onDragOver={onDragElement}
                                        onDrop={() => onDenominatorDrop(index)}>
                                        {
                                            item.denominatorFields.length > 0 ?
                                                <div className='d-flex'>
                                                    <p className='m-0'>{item.denominatorFields[0].fieldName}</p>
                                                    <CancelIcon onClick={(e: any) => onDelete(e, 'denominator', index)} />

                                                </div>
                                                : <p className='m-0'>Drag a integer variable here</p>
                                        }
                                    </div>
                                ))
                            }
                        </div>
                        <span>2</span>
                    </div>
                </div>
            </div>
        </React.Fragment>
    )
}
export default BMIFormula