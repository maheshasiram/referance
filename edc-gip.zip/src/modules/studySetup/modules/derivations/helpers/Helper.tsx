import React from "react";
import { Popover } from "@mui/material";
import DerivationNoteLogo from '../../../../../common/Assests/Images/DerivationNoteLogo.png'

function Helper(props: any) {
  const { calculationType } = props;
  const [anchorEl, setAnchorEl] = React.useState<HTMLElement | null>(null);
  const handlePopoverOpen = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handlePopoverClose = () => {
    setAnchorEl(null);
  };

  const open = Boolean(anchorEl);
  return (
    <React.Fragment>
      <div>
        <img className="img-size" src={DerivationNoteLogo} alt=""
          aria-owns={open ? 'mouse-over-popover' : undefined}
          aria-haspopup="true"
          onMouseEnter={handlePopoverOpen}
          onMouseLeave={handlePopoverClose}
        />

      </div>
      {calculationType && <div className="form-group">
      </div>}

      {calculationType !== '' && <Popover
        className="Popover"
        id="mouse-over-popover"
        sx={{
          pointerEvents: 'none'
        }}

        open={open}
        anchorEl={anchorEl}

        PaperProps={{
          elevation: 0,
          sx: {
              overflow: 'visible',
              filter: 'drop-shadow(0px 2px 4px rgba(0,0,0,0.22))',
              mt: 1.5,
              '& .MuiAvatar-root': {
                  width: 32,
                  height: 32,
                  ml: -0.5,
                  mr: 1,
              },
              '&:before': {
                  content: '""',
                  display: 'block',
                  position: 'absolute',
                  bottom: -10,
                  left: 250,
                  width: 10,
                  height: 10,
                  bgcolor: '#333333',
                  transform: 'translateY(-50%) rotate(45deg)',
                  zIndex: 0,
              },
          },
      }}
        anchorOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
        transformOrigin={{
          vertical: 'bottom',
          horizontal: 'center',
        }}
        onClose={handlePopoverClose}
        disableRestoreFocus
      >
        <div className={props.className}>
          {props.content}
        </div>
      </Popover>}
    </React.Fragment>
  )
}
export default Helper;