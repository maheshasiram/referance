import React from 'react';
import { useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import CancelIcon from '@mui/icons-material/Cancel';
import { Types } from '../reducers/Types';
import { fetchAllVistis, onDragElement, resetCaliculateVariable } from '../actions/actions';
import SelectField from '../../../../../common/selectField/SelectField';
import CustomToolTip from '../../../../../components/CustomToolTip';
import _ from 'lodash';

function TargetContainer(props: any) {
  const dispatch = useDispatch();
  const params: any = useParams();
  const { derivation, treePayload, allVisits, customTypeValue } = useSelector((state: any) => state.derivations);
  const { currentStudy,configCodes } = useSelector((state: any) => state.application);
  const { setBtnDisabled, validations, onSetValidations, setCustomeDerivatives, setDependentVarVisits, setDisableVisitList } = props
  const [selectedLogicVisits, setSelectedLogicVisits] = React.useState('');
  const loaded = React.useRef(false);

  React.useEffect(() => {
    if (!loaded.current) {
      // const _derivation = { ...{}, ...derivation }
      const _derivation = _.cloneDeep(derivation);
      if ((parseInt(params.id)) > 0) {
        if (_derivation.customDerivationType == null) {
          dispatch(fetchAllVistis(currentStudy.id, (response: any) => {
            const _logicVisit = response.filter((obj: any) => obj.id === parseInt(_derivation.logic.visitId))
            const options: any = []
            _logicVisit.map((item: any) => {
              const option = {
                label: item.visitName,
                value: item.id
              }
              options.push(option);
            return null;
            })
            setSelectedLogicVisits(options);
            dispatch({ type: Types.CREATE_DERIVATION, payload: _derivation })
          }))
        }
      }
      else {
        dispatch(fetchAllVistis(currentStudy.id, () => {return null }))
      }
      loaded.current = true
    }
     // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  React.useEffect(() => {
    if (parseInt(params.id) > 0) {
      const _derivation = _.cloneDeep(derivation);
      _derivation.target.targetVariables.map((element: any, gIndex: number) => {
        _derivation.target.targetVariables[gIndex].visitsIds = [];
        treePayload && treePayload.map((node: any) => (
          node?.children?.map((nodee: any) => {
            if (!nodee.groupId) {
              if (nodee.id === element.id) {
                nodee?.visits?.map((item: any) => {
                  // if (element.visitsIds.includes(item.id)) {
                  console.log("...611-1", nodee, derivation.target.targetVariables[gIndex].visitsIds);
                  if (derivation.target.targetVariables[gIndex].visitsIds.indexOf(item.id) !== -1) {
                    _derivation.target.targetVariables[gIndex].visitsIds.push({ "id": item.id, "label": item.visitName });
                    console.log("...61", _derivation.target.targetVariables);
                  }
                  return null;
                })
              }
            }
            else if (nodee.groupId) {
              if (nodee.groupId === element.groupId) {
                nodee?.children?.map((grpItem: any) => {
                  if (grpItem.id === element.id) {
                    grpItem?.visits?.map((item: any) => {
                      console.log("...611-2", derivation.target.targetVariables[gIndex].visitsIds);
                      if (derivation.target.targetVariables[gIndex].visitsIds.indexOf(item.id) !== -1) {
                        _derivation.target.targetVariables[gIndex].visitsIds.push({ "id": item.id, "label": item.visitName });
                      }
                      return null;
                    })
                  }
                  return null;
                })
              }
            }
            return null;
          })
        ))
        dispatch({ type: Types.CREATE_DERIVATION, payload: _derivation });
        return null;
      });
    }

  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [treePayload]);



  const onDeleteTargetElement = (e: any, index: any) => {
    let payload: any;
    if (customTypeValue !== 'CustomDerivation' && derivation.actionType.code === configCodes?.CustomDerivation) {
      payload = { ...{}, ...derivation };
      payload.dependentTargetVar = []
      payload.logic.visitId = ""
      payload.target.targetFormIds = [];
      payload.target.targetFieldIds = [];
      payload.target.targetVisitIds = [];
      payload.target.targetVariables = [];
      payload.logic.logicVariables = [];
      setCustomeDerivatives({ logic: { logicVariables: [{ expression: '', fields: [] }] } });
      setDependentVarVisits('');
    } else {
      payload = resetCaliculateVariable(derivation, index);
      if (payload.target.targetVariables.length === 0) { setSelectedLogicVisits('') }
    }
    dispatch({ type: Types.CREATE_DERIVATION, payload });
    onSetValidations({ target: "", dependentTarget: "", logic: "" });
    setBtnDisabled(false);
    // setDisableVisitList(false);
  }

  const onChangeVisitHandler = (e: any, index: number) => {
    const _derivations = { ...{}, ...derivation }
    // const selectedVisitsData: any = []
    const visitIdData: any = [];
    _derivations.target.targetVariables[index].visitsIds = e;
    _derivations.target.targetVariables.map((ele: any) => {
      ele.visitsIds.map((visits: any) => (visitIdData.push(visits)));
      return null
    });
    console.log("..125", _derivations.target.targetVariables[index].visitsIds);
    _derivations.target.targetVisitIds = visitIdData.toString();
    onSetValidations({ target: "", dependentTarget: "", logic: "" });
    console.log("...127", _derivations);
    dispatch({ type: Types.CREATE_DERIVATION, payload: _derivations })
  }

  const onDerivationVisitChangeHandler = (value: any) => {
    const _derivations = { ...{}, ...derivation }
    const selectedVisitsData: any = [];
    selectedVisitsData.push(value);
    const _value = value?.value?.toString();
    _derivations.logic.visitId = _value;
    setSelectedLogicVisits(selectedVisitsData)
    dispatch({ type: Types.CREATE_DERIVATION, payload: _derivations });
    dispatch({ type: Types.SELECT_VISIT_IN_DERIVATION, payload: [] });
    onSetValidations({ target: "", logic: "" });
    setBtnDisabled(false);
  }

  const visitIsDisable = () => {
    let _isDisable = true
    if (derivation.actionType.code !== "ACT_TYP_NUMERIC") {
      const _every = derivation?.logic?.logicVariables?.some((ele: any) => ele.itemName)
      if (_every) {
        _isDisable = true
      } else {
        _isDisable = false
      }
    } else if (derivation.actionType.code === "ACT_TYP_NUMERIC" && Object.keys(derivation.logic.formula).length <= 0) {
      if (derivation.logic.logicVariables.length > 0) {
        _isDisable = true
      }
      else {
        _isDisable = false
      }
    } else if (derivation.actionType.code === "ACT_TYP_NUMERIC" && Object.keys(derivation.logic.formula).length > 0 && derivation.logic.formula.formulaCode === 'BMI') {
      derivation.logic.logicVariables.map((item: any) => {
        if (item.numeratorFields.length > 0 && item.denominatorFields.length > 0) {
          _isDisable = true
        } else {
          _isDisable = false

        }
        return null
      })
    } else if (derivation.actionType.code === "ACT_TYP_NUMERIC" && Object.keys(derivation.logic.formula).length > 0 && derivation.logic.formula.formulaCode === 'AGE') {
      const _every = derivation?.logic?.logicVariables[0]?.numeratorFields.some((ele: any) => ele.fieldName)
      if (_every && derivation.logic.visitId !== "") {
        _isDisable = true
      } else {
        _isDisable = false
      }
    }

    return _isDisable

  }

  return (
    <React.Fragment>
      <div className="logic-wrapper" >
        <label className='derivation-labels'>Target Variable:
          {(validations && validations.target) && <span className=" ms-2 text-danger">{validations.target}</span>}
        </label>
        {
          <div>
            <div className="calc-wrapper">
              <div className="w-100 main-target-container">
                {derivation.target.targetVariables.length > 0 &&
                  derivation.target.targetVariables.map((element: any, index: number) => {
                    console.log("270", element); return (
                      <div className="w-100 px-1 py-1 mb-1" key={index}>
                        <ul className="vars-container der-var-container">
                          <li className="w-100">
                            <div className="d-flex justify-content-center align-items-center col-sm-12 ">
                              {treePayload && treePayload.map((formName: any) => {
                                if (formName.id === element.formId) {
                                  return (
                                    <React.Fragment key={index}>
                                      <div className='col-sm-4 px-2'>
                                        <span className='d-flex'>{element.label}
                                          <CustomToolTip title="Data Type"><b>({element?.datatype?.name})</b></CustomToolTip>
                                          <CustomToolTip title="Form Name"><b>({formName.label})</b></CustomToolTip>
                                        </span>
                                      </div>
                                      <div className="target-wrapper col-sm-8" >
                                        <SelectField
                                          id={"visitName"}
                                          defaultValue={"Select Visit"}
                                          isDisabled={parseInt(params.id) > 0 ? true : false}
                                          isClearable={true}
                                          isSearchable={true}
                                          // value={selectedVisits}
                                          value={element?.visitsIds[0]?.label && element.visitsIds}
                                          name={"VistsList"}
                                          onChange={(e: any) => { onChangeVisitHandler(e, index) }}
                                          options={derivation.target.targetVariables[index].visitList}
                                          isMulti={true}
                                          selectAll={true}
                                          placeholder={"Select Visit"}
                                        />
                                      </div>
                                      {parseInt(params.id) <= 0 && <CancelIcon onClick={(e: any) => onDeleteTargetElement(e, index)} />}
                                    </React.Fragment>
                                  )
                                }
                                return null
                              })}
                            </div>
                          </li>
                        </ul>
                      </div>
                    )
                  }
                  )}
              </div>
              {derivation.actionType.code !== configCodes?.CustomDerivation && (parseInt(params.id)) === 0 ? <div className="w-100" >
                <div className="logic-container ">
                  <div className="element numaric-container"
                    onDragOver={onDragElement}
                    onDrop={props.onDropTargetElement}>
                    {props.placeholder}
                  </div>
                </div>
              </div> :
                derivation.target.targetVariables.length < 1 && <div className="w-100" >
                  <div className="logic-container ">
                    <div className="element numaric-container"
                      onDragOver={onDragElement}
                      onDrop={props.onDropTargetElement}>
                      {props.placeholder}
                    </div>
                  </div>
                </div>
              }
            </div>
            {(derivation && derivation.target.targetVariables.length > 0 && derivation.actionType.code !== configCodes?.CustomDerivation) && <div className="d-flex mb-3">
              <label className="derivation-labels">Visits:</label>
              <div className="d-flex justify-content-start align-items-center px-3">
                <SelectField
                  className={'visitsDropDown'}
                  id={"visitName"}
                  defaultValue={"Select Visit"}
                  value={selectedLogicVisits}
                  isClearable={true}
                  isDisabled={visitIsDisable()}
                  onChange={(e: any) => { onDerivationVisitChangeHandler(e) }}
                  options={allVisits && allVisits}
                  isSearchable={true}
                  name={"VistsList"}
                  placeholder={"Select Visit"}
                />
              </div>
            </div>}
          </div>

        }
        <span>
          {props.AutopopValidate && <span className='text-danger'>{props.AutopopValidate}</span>}
          {props.TimeValidation && <span className='text-danger'> {props.TimeValidation}</span>}
          {props.fileNameAutopopValidate && <span className='text-danger'>{props.fileNameAutopopValidate}</span>}
          {props.validateDate && <span className='text-danger'>{props.validateDate}</span>}
          {props.validationForNumeric && <span className='text-danger'>{props.validationForNumeric}</span>}
          {props.customValidation && <span className='text-danger'>{props.customValidation}</span>}
        </span>
      </div>
    </React.Fragment>
  )
}
export default TargetContainer;
