import React from 'react'
import { useDispatch, useSelector } from "react-redux";
import { Types } from '../reducers/Types';
import CancelIcon from '@mui/icons-material/Cancel';
import { formulaValidation } from './Validations';
// import { fetchVisitsAssignedToFieldId } from '../actions/actions';


function AgeFormula(props: any) {
    const dispatch = useDispatch();
    const { derivation } = useSelector((state: any) => state.derivations);
    const { node, validations, onSetValidations, setBtnDisabled } = props;

    React.useEffect(() => {
        if (derivation?.id === 0) {
            const payload = { ...{}, ...derivation }
            const _array: any = []
            for (let i = 0; i < 2; i++) {
                _array.push({
                    "fieldName": "",
                    "fieldId": "",
                    "formId": "",
                    "dataType": "",
                    "operation": "",
                    "units": "",
                    "updatedUnit": ""
                })
            }
            payload.logic.logicVariables[0].numeratorFields = _array
            dispatch({ type: Types.CREATE_DERIVATION, payload: payload });
        }
         // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const onDragElement = (e: any) => {
        e.preventDefault()
    }

    const onAgeDateDrop = (index: number) => {
        const payload = { ...{}, ...derivation }
        let _flag = false;
        const _numeratorLength = payload.logic.logicVariables[0].numeratorFields[index].fieldId === ""
        let errors: any = _numeratorLength && formulaValidation(derivation, node, 'AGE')
        // _numeratorLength && dispatch(fetchVisitsAssignedToFieldId(node.id, (response: any) => {
        // if (response.data) {
        //     response.data.map((ele: any) => {
        //         if (ele.id === parseInt(payload.logic.visitId)) {
        //             _flag = true;
        //         }
        //         return null
        //     })
        // }
        _numeratorLength && node.visits.map((ele: any) => {
            if (ele.id === parseInt(payload.logic.visitId)) {
                _flag = true;
            }
            return null
        })
            if (errors === false && _flag) {
                payload.logic.logicVariables[0].numeratorFields[index] = {
                    "fieldName": node.label,
                    "fieldId": node.id,
                    "formId": node.formId,
                    "dataType": node.datatype.name,
                    "operation": index === 0 ? "-" : "",
                    "units": "",
                    "updatedUnit": ""
                }
                onSetValidations({ logic: "" });
            } else {
                if (!_flag) {
                    errors = {
                        target: '',
                        dependentTarget: "",
                        logic: "The dragged variable is not assigned to selected visit, please drag different variable",
                    }
                }
                props.onSetValidations(errors);
            }
        // }))
        setBtnDisabled(false);
        dispatch({ type: Types.CREATE_DERIVATION, payload: payload });
    }

    const onDelete = (e: any, index: number) => {
        const payload = { ...{}, ...derivation }
        payload.logic.logicVariables[0].numeratorFields[index] = {
            "fieldName": "",
            "fieldId": "",
            "formId": "",
            "dataType": "",
            "operation": "",
            "units": "",
            "updatedUnit": ""
        }
        onSetValidations({ logic: "" });
        setBtnDisabled(false);
        dispatch({ type: Types.CREATE_DERIVATION, payload: payload });
    }
    return (
        <React.Fragment>
            <label className="derivation-labels">Age Formula:{(validations && validations.logic) && <span className=" ms-2 text-danger">{validations.logic}</span>}</label>
            <div className='age-formula-main'>
                <div className='age-formula'>
                    <div className='age-numerator'>
                        <div className='age-numerator-div'
                            onDragOver={onDragElement}
                            onDrop={() => onAgeDateDrop(0)}
                        >
                            <div className='age-visit-date'>
                                {
                                    derivation && derivation?.logic?.logicVariables[0]?.numeratorFields[0]?.fieldName !== "" ?
                                        <div className='d-flex'>
                                            <p className='m-0'>{derivation && derivation.logic.logicVariables[0].numeratorFields[0]?.fieldName}</p>
                                            <CancelIcon onClick={(e: any) => onDelete(e, 0)} />
                                        </div> : <p className='m-0'>Drag a date variable (visit date)</p>
                                }
                            </div>
                        </div>
                        <span> - </span>
                        <div className='age-numerator-div'
                            onDragOver={onDragElement}
                            onDrop={() => onAgeDateDrop(1)}>
                            <div className='age-DOB'>
                                {
                                    derivation && derivation?.logic?.logicVariables[0]?.numeratorFields[1]?.fieldName !== "" ?
                                        <div className='d-flex'>
                                            <p className='m-0'>{derivation && derivation?.logic?.logicVariables[0]?.numeratorFields[1]?.fieldName}</p>
                                            <CancelIcon onClick={(e: any) => onDelete(e, 1)} />
                                        </div> : <p className='m-0'> Drag a date variable (DOB) </p>
                                }
                            </div>
                        </div>
                    </div>
                    <span className='age-divider'></span>
                    <div className='age-denominator'>365
                    </div>
                </div>
            </div>
        </React.Fragment>
    )
}
export default AgeFormula