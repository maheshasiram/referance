import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { onDragElement, resetTargetCaliculateVariable } from "../actions/actions";
import { Types } from "../reducers/Types";
import CancelIcon from '@mui/icons-material/Cancel';
import CustomToolTip from "../../../../../components/CustomToolTip";
import SelectField from "../../../../../common/selectField/SelectField";

export default function DependentTargetContainer(props: any) {
    const dispatch = useDispatch()
    const { validations, onSetValidations, setBtnDisabled, setCustomeDerivatives, setDependentVarVisits } = props
    const { derivation, treePayload } = useSelector((state: any) => state.derivations);
    const dependentVisits = derivation.target.targetVariables.map((i: any) => i?.visitsIds[0]?.label && i.visitsIds);

    const onDeleteTarget = (e: any, index: number) => {
        const payload = resetTargetCaliculateVariable(derivation, index);
        payload.logic.visitId = ""
        payload.logic.logicVariables = [];
        setDependentVarVisits('')
        setCustomeDerivatives({ logic: { logicVariables: [{ expression: '', fields: [] }] } })
        dispatch({ type: Types.CREATE_DERIVATION, payload });
        onSetValidations({ target: "", dependentTarget: "", logic: "" });
        setBtnDisabled(false)
    }

    return (
        <div className="dependentTarget-wrapper">
            <label className="derivation-labels">Dependent Target Variable:
                {(validations && validations.dependentTarget) && <span className=" ms-2 text-danger">{validations.dependentTarget}</span>}
            </label>
            <div className="target-container"
                id="calculatedVar"
                onDragOver={onDragElement}
                onDrop={props.onDropTargetElement}
            >
                {derivation.dependentTargetVar.length <= 0 && props.placeholder}
                <ul className='vars-container'>
                    {
                        derivation.dependentTargetVar.length > 0 &&
                        derivation.dependentTargetVar.map((variable: any, index: number) => (
                            <li key={index} className="w-100">
                                <div className="d-flex justify-content-center align-items-center col-sm-12 ">
                                    {treePayload && treePayload.map((formName: any) => {
                                        if (formName.id === variable.formId) {
                                            return (
                                                <React.Fragment key={index}>
                                                    <div className='col-sm-4 px-2'>
                                                        <span className='d-flex'>{variable.label}
                                                            <CustomToolTip title="Data Type"><b>({variable.datatype.name})</b></CustomToolTip>
                                                            <CustomToolTip title="Form Name"><b>({formName.label})</b></CustomToolTip>
                                                        </span>
                                                    </div>
                                                    <div className="target-wrapper col-sm-8" >
                                                        <SelectField
                                                            id={"visitName"}
                                                            defaultValue={"Select Visit"}
                                                            isDisabled={true}
                                                            isClearable={true}
                                                            isSearchable={true}
                                                            name={"VistsList"}
                                                            value={dependentVisits[0]}
                                                            isMulti={true}
                                                        />
                                                    </div>
                                                    <CancelIcon onClick={(e: any) => onDeleteTarget(e, index)} />
                                                </React.Fragment>
                                            )
                                        }
                                        return null
                                    })}
                                </div>
                            </li>)
                        )
                    }
                </ul>
            </div>
        </div>
    )
}