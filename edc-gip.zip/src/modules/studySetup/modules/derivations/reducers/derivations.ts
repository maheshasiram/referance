import { Types } from "./Types";
import { derivationModal, measurementUnits, numericOperatorData } from "../constants/modal";

const initialState = {
    derivation: derivationModal,
    forms: [],
    derivations: [],
    derivationTypes: [],
    treeNode: [],
    treePayload: null,
    actionTypes: [],
    visitinDerivation: [],
    calculationFactorValues: [],
    customDerivationValues: null,
    derivationParams: {
        "limit": 10,
        "offset": 0,
        "formId": null,
        "fieldName": null,
        "configId": null,
        'studyId': 1
    },
    customDerivationOptionType: {
        'id': '',
        "optionName": '',
        "name": ''
    },
    numericOperator: numericOperatorData,
    unitMeasurement: measurementUnits,
    allVisits: null,
    allUnits: null,
    allFormulas: null
}

export const derivations = (state = initialState, action: any) => {
    switch (action.type) {
        case Types.FETCH_ACTION_TYPE:
            return { ...state, actionTypes: action.payload }
        case Types.GET_ALL_DERIVATIONS_FORMS:
            return { ...state, forms: action.payload }
        case Types.CREATE_DERIVATION:
            console.log("...41-1", action.payload)
            return { ...state, derivation: action.payload }
        case Types.FIND_DERIVATIVE_BY_ID:
            return { ...state, derivations: action.payload }
        case Types.SAVE_SELECTED_NODE_DATA:
            return { ...state, treeNode: action.payload }
        case Types.FETCH_TREEVIEW_DATA:
            return { ...state, treePayload: action.payload }
        case Types.SELECT_VISIT_IN_DERIVATION:
            return { ...state, visitinDerivation: action.payload }
        case Types.FIND_DERIVATIVE_TYPE:
            return { ...state, derivationTypes: action.payload }
        case Types.FETCH_CALCULATION_FACTOR:
            return { ...state, calculationFactorValues: action.payload }
        case Types.FETCH_CUSTOM_DERIVATION:
            return { ...state, customDerivationValues: action.payload }
        case Types.FIND_ALL_BY_CRITERIA:
            return { ...state, derivationParams: action.payload }
        case Types.FETCH_ALL_DERIVATONS:
            return { ...state, derivations: action.payload }
        case Types.CUSTOM_DERIVATION_OPTION_TYPE:
            return { ...state, customDerivationOptionType: action.payload }
        case Types.GET_ALL_VISTIS:
            return { ...state, allVisits: action.payload }
        case Types.GET_ALL_UNITS:
            return { ...state, allUnits: action.payload }
        case Types.GET_ALL_FORMULA:
            return { ...state, allFormulas: action.payload }
        default: return { ...state }
    }
}