import { cleanDigitSectionValue } from "@mui/x-date-pickers/internals/hooks/useField/useField.utils";
import { Loader} from "../../../../../actions/actions";
import { studySetup } from "../../../../../configs/enivornment/studySetup";
import { fetch } from "../../../../../constants/fetch";
import { Types } from "../reducer/Types";



export const findSiteBySiteName: any = (payload: any) => {
    const { studyId, siteName } = payload
    const url = `${studySetup.sites.findSiteBySiteName}?studyId=${studyId}&siteName=${siteName}`
    return (dispatch: any) => {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
        })
            .then((response: any) => {
                // if (callback) callback(response)
                console.log(".....19", response);

                // dispatch({ type: Types.FIND_SITE_BY_SITE_NAME, payload: response.action });
                // dispatch({ type: Types.GET_ALL_SITES, payload: { sites: response.data } })
                dispatch({ type: Types.GET_ALL_SITES, payload: response.data })
                dispatch(Loader(false))
            })
    }
}

//fetch all sites
export const findAllSitesByStudyIdCriteria: any = (payload: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: studySetup.sites.findAllSitesByStudyIdCriteria,
            data: payload
        })
            .then((response: any) => {
                console.log("40.....",response.data)
                // console.log("...39", response.data);

                dispatch({ type: Types.GET_ALL_SITE_LIST, payload: response.data })
                dispatch(Loader(false))
            })
            .catch((error) => {
                console.log("error....", error)
            })
    }
}

export const fetchAllSites: any = (payload: any) => {
    return function (dispatch: any) {
         dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: studySetup.sites.fetchAllSites,
            data: payload
        })
            .then((response: any) => {
                // console.log("...39", response.data);

                dispatch({ type: Types.GET_ALL_SITES, payload: response.data })
               dispatch(Loader(false))
            })
            .catch((error) => {
                console.log("error....", error)
            })
    }
}

//add new site API
export const onCreateSite: any = (payload: any, callback: any) => {
    return function (dispatch: any) {
         dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: studySetup.sites.addSite,
            data: payload
        })
            .then((response: any) => {
                callback(response.data);
                 dispatch(Loader(false))
            })
            .catch((error) => {
                console.log("error....", error)
            })
    }
}

//Fetach All Countries
export const fetchAllCountries: any = () => {
    return function (dispatch:any){
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: studySetup.countries.findAllCountries,
        })
            .then((response: any) => {
                dispatch({ type: Types.GET_ALL_COUNTRIES, payload: response.data });
                dispatch(Loader(false))
            })
    }
}

//delete site
export const onDeleteSite: any = (siteId: any, params: any, callback:any) => {
    const url = `${studySetup.sites.deleteSite}?siteId=${siteId}`
    return (dispatch: any) => {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
        })
            .then((response: any) => {
                callback(response.data);
                // dispatch({ type: Types.DELETE_SITE, payload: response.action });
                dispatch(Loader(false));
            })
    }
}

//restore sites
export const onRestoreSite: any = (siteId: any, params: any, callback:any) => {
    console.log("siteId",siteId)
    const url = `${studySetup.sites.restoreSite}?siteId=${siteId}`
    return (dispatch: any) => {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
        })
            .then((response: any) => {
                callback(response.data);
                // dispatch({ type: Types.RESTORE_SITE, payload: response.action })
                dispatch(Loader(false))
            })
    }
}

//edit sites
export const onUpdateSite: any  = (payload: any, callback: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: studySetup.sites.saveOrUpdateSite,
            data: payload
        })
            .then((response: any) => {
                callback(response.data);
                dispatch(Loader(false));
            })
            .catch((error) => {
                 console.log("error....", error)
            })
    }
}