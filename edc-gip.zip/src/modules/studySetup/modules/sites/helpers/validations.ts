import * as Yup from 'yup';

export const SitesSchema = Yup.object().shape({
    siteName: Yup.string()
        .matches(/^[a-zA-Z]/, 'Site name should start with text')
        .required('Please enter site name'),
    // .matches(/[a-zA-Z]/, 'Site name should start with text')
    // .required('Please enter site name'),
    country: Yup.object().shape({
        name: Yup.string()
            .required('Please select country')
    }),
    maxEnrollments: Yup.number()
        .required('Please enter expected total enrollment')
        .min(1, 'Enrollment should be greater than zero'),
    siteCode: Yup.string()
        .required('Please enter site id')
        // .matches(/^[^\s].+[^\s]$/,'Site ID should not start with spaces')
        // .matches(/^([a-zA-Z0-9]+\s)*[a-zA-Z0-9]+$/, 'only one space allowed between words')
    // .required('Please enter site code'),
});