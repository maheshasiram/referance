import { CreateSiteObj } from "../constants/models";
import { Types } from "./Types";

const initialState = {
    allSites: [],
    sitesParams: { studyId: 0, offset: 0, limit: 10, nameCriteria: '',siteIdName:'',countryName:'' },
    siteDetails: CreateSiteObj,
    allCountriesData: [],
    subCount: null,
    siteList: {}
}


export const sites = (state = initialState, action: { type: any, payload: any }) => {
    switch (action.type) {
        case Types.GET_ALL_SITES:
            return { ...state, allSites: action.payload }
        case Types.SITES_PARAMS:
            return { ...state, sitesParams: action.payload }
        case Types.GET_ALL_COUNTRIES:
            return { ...state, allCountriesData: action.payload }
        case Types.UPDATE_SITE_DETAILS:
            return { ...state, siteDetails: action.payload }
        case Types.GET_ALL_SITE_LIST:
            return { ...state, siteList: action.payload }
        default:
            return { ...state }
    }
}