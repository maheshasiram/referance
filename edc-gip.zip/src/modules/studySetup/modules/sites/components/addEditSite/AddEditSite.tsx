import React, { useEffect, useState } from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import CustomDialog from '../../../../../../common/modals/CustomeDialog';
import { useDispatch, useSelector } from 'react-redux';
import { onCreateSite,  findAllSitesByStudyIdCriteria, fetchAllCountries, onUpdateSite } from '../../actions/actions';
import { SitesSchema } from '../../helpers/validations';
import {  toastAlert } from '../../../../../../actions/actions';
import { messages } from '../../../../constants/messages';

function AddEditSite(props: any) {

    const { sitesParams, siteDetails, allCountriesData } = useSelector((state: any) => state.sites);
    const { currentStudy } = useSelector((state: any) => state.application)

    const [disableBtn, setDisableBtn] = React.useState(true);
    const [erroeMsg, setErroeMsg] = useState('');

    const dispatch = useDispatch();
    const loaded = React.useRef(false);
    const { setOpen } = props;

    useEffect(() => {
        if (!loaded.current) {
            dispatch(fetchAllCountries())
            loaded.current = true
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onCloseHandler = () => {
        setOpen(false);
    }

    const onSubmitSiteDetails = (values: any) => {
        const _values = { ...values, studyId: currentStudy.id }
        console.log('values..34',_values)
        dispatch((!_values.id ? onCreateSite : onUpdateSite)(_values, (data: any) => {
            if (data.status === "error") {
                setErroeMsg(data.errorMessage);
            } else {
                setErroeMsg('');
                onCloseHandler();
                dispatch(toastAlert({ status: 1, message: !_values.id ? `${values.siteName} ${messages.sites.addSiteSuccess}` : `${values.siteName} ${messages.sites.updateSiteSuccess}`, open: true }))
                const payload = { ...sitesParams, studyId: currentStudy.id, nameCriteria: '' }
                dispatch(findAllSitesByStudyIdCriteria(payload, () => {  return null}));
                // (dispatch as any)(Alert({
                //     status: 2, message: !_values.id ? messages.sites.addSiteSuccess : messages.sites.updateSiteSuccess,
                //     onOk: () => {
                //         let payload = { ...sitesParams, studyId: currentStudy.id }
               
                //     }
                // }));
            }
        }));
    }

    return (
        <CustomDialog
            title={siteDetails.id ? 'Update Site' : 'Add Site'}
            onClose={onCloseHandler}
            onSubmitHandler={() => { return null }}
            open={true}
            maxWidth='xs'
            fullWidth={false}
            actionType={siteDetails.id ? 'Update' : 'Submit'}
            form="site-submit"
            disabled={disableBtn}
        >
            <Formik
                enableReinitialize={true}
                initialValues={siteDetails}
                validationSchema={SitesSchema}
                onSubmit={values => {
                    onSubmitSiteDetails(values);
                }}
            >
                {({ errors, touched, values, setFieldValue }) => (
                    <Form id="site-submit" className='sites-form'>
                        {erroeMsg ? <span className="d-flex justify-content-center text-danger">{erroeMsg}</span> : <span>&nbsp;</span>}
                        <div className='form-group' id=''>
                            <label htmlFor='txt-siteName'>Site Name :<span className=' text-danger'>*</span></label>
                            <Field
                                name="siteName"
                                className="form-control mt-1"
                                value={values.siteName}
                                placeholder="Enter site name"
                                onChange={(e: any) => {
                                    if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
                                        setFieldValue("siteName", e.target.value);
                                        setDisableBtn(false);
                                    }
                                }}
                                id='txt-siteName'
                            />
                            {errors.siteName && touched.siteName ? <span className='text-danger'> <ErrorMessage name={`siteName`} /> </span> : <span>&nbsp;</span>}
                        </div>
                        <div className='form-group'>
                            <label htmlFor='site-expectEnv' >Expected Total Enrollment :<span className=' text-danger'>*</span></label>
                            <Field
                                name="maxEnrollments"
                                type="number"
                                className="form-control mt-1"
                                placeholder="Enter expected total enrollment"
                                value={values.maxEnrollments}
                                onKeyPress={(e: any) => {
                                    if (e.key === "-" || e.key === "+" || e.key === "e" || e.key === ".") {
                                        e.preventDefault();
                                    }
                                }}
                                onChange={(e: any) => {
                                    if ((e.target.value.length <= 15) && (e.target.value > 0 || !e.target.value)) {
                                        setFieldValue("maxEnrollments", e.target.value);
                                        setDisableBtn(false);
                                    }
                                }}
                                id='site-expectEnv'
                            />
                            {errors.maxEnrollments && touched.maxEnrollments ? <div className='text-danger'><ErrorMessage name={`maxEnrollments`} /></div> : <span>&nbsp;</span>}
                        </div>

                        <div className='form-group'>
                            <label htmlFor='site-country'>Country :<span className=' text-danger'>*</span></label>
                            <Field
                                as="select"
                                name="country.name"
                                className="form-select form-control mt-1 w-100"
                                value={values.country.name}
                                onChange={(e: any) => {
                                    const country = allCountriesData.find((item: any) => item.name === e.target.value);
                                    const _country = {
                                        countryCode: "",
                                        id: "",
                                        name: "",
                                        phoneCode: ""
                                    }
                                    setFieldValue('country', country ? country : _country);
                                    setDisableBtn(false);
                                }}
                                id='site-country'
                            >
                                <option value="">Select Country</option>
                                {allCountriesData &&
                                    allCountriesData.map(
                                        (item: any, index: any) => (
                                            <option key={index} value={item.name} id="sel-groupname">
                                                {item.name}
                                            </option>
                                        )
                                    )}
                            </Field>
                            {errors.country && touched.country ? <div className='text-danger'> <ErrorMessage name={`country.name`} /></div> : <span>&nbsp;</span>}
                        </div>

                        <div className='form-group'>
                            <label id='site-code'>Site ID:<span className=' text-danger'>*</span></label>
                            <Field
                                name="siteCode"
                                className="form-control mt-1"
                                value={values.siteCode}
                                placeholder="Enter site id"
                                onChange={(e: any) => {
                                    if (((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) ===false && e.target.value.length === 0)) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
                                        setFieldValue("siteCode", e.target.value);
                                        setDisableBtn(false);
                                    }
                                }}
                                id='site-ID'
                            />
                            {errors.siteCode && touched.siteCode ? <div className='text-danger'><ErrorMessage name={`siteCode`} /></div> : <span>&nbsp;</span>}
                        </div>
                    </Form>
                )}
            </Formik>
        </CustomDialog>

    )
}

export default AddEditSite;