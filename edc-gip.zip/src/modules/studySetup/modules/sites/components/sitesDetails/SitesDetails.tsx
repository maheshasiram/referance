import React, { useState } from "react";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { useSelector, useDispatch } from "react-redux";
import AddEditSite from "../addEditSite/AddEditSite";
import { findAllSitesByStudyIdCriteria, onDeleteSite, onRestoreSite } from "../../actions/actions";
import { Types } from "../../reducer/Types";
import EditIcon from '@mui/icons-material/Edit';
import ReplayIcon from '@mui/icons-material/Replay';
import DeleteIcon from '@mui/icons-material/Delete';
import { Confirm, toastAlert } from "../../../../../../actions/actions";
import { messages } from "../../../../constants/messages";
import '../../styles/Styles.scss'
import { CreateSiteObj, SiteSearchSelection } from "../../constants/models";
// import TextField from '@mui/material/TextField';
import SearchField from "../../../../../../common/searchField/SearchField";
import CustomToolTip from "../../../../../../components/CustomToolTip";
import PageCount from "../../../../../../common/pagecount/PageCount";
// import { rulePayload } from "../../../rules/constants/rules-modals";
import { FilterSeachContainer } from "../../../../../../common/styleComponents/FilterBy";

function SiteDetails() {

  const dispatch = useDispatch();
  const { sitesParams, siteList } = useSelector((state: any) => state.sites)
  const { currentStudy } = useSelector((state: any) => state.application)
  const [open, setOpen] = React.useState(false);
  const [searchSite, setSearchSite] = React.useState('')
  const [pageClick, setpageChange] = useState(false);
  const [searchSiteByName, setSearchSiteByName] = React.useState('');
  const [searchSiteByID, setSearchSiteByID] = React.useState('');
  const [searchSiteByCountry, setSearchSiteByCountry] = React.useState('');
  const loaded = React.useRef(false);


  React.useEffect(() => {
    if (!loaded.current) {
      const payload = { ...sitesParams, studyId: currentStudy.id, limit: 10, nameCriteria: '', offset: 0 }
      dispatch(findAllSitesByStudyIdCriteria(payload))
      dispatch({ type: Types.SITES_PARAMS, payload: payload })
      loaded.current = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const statusTemplate = (rowData: any) => {
    return (<div>{rowData.status === true ? "Available" : "Removed"}</div>)
  }

  const onOpenSiteForm = (rowData: any) => {
    setOpen(true);
    dispatch({ type: Types.UPDATE_SITE_DETAILS, payload: rowData ? rowData : CreateSiteObj });
  }

  const onDeleteRestoreSite = (type: string, rowData: any) => {
    dispatch(Confirm({
      status: 0,
      message: type === 'delete' ? messages.sites.delete : messages.sites.restore,
      onOk: () => {
        //setSearchSiteByName('')
        // setSearchSiteByID('')
        // setSearchSiteByCountry('')
        console.log("63..",sitesParams)
        const payload = { ...sitesParams, studyId: currentStudy.id }
        dispatch((type === 'delete' ? onDeleteSite : onRestoreSite)(rowData.id, payload, (response: any) => {
          if (response.status === "error") {
            dispatch(toastAlert({
              status: 1,
              message: type === 'delete' ? response.errorMessage : response.errorMessage, open: true
            }))
          } else {
            if (type === 'delete') {
              dispatch(toastAlert({
                status: 1,
                message: `${rowData.siteName} ${messages.sites.deleteSuccess}`, open: true
              }))
            } else {
              dispatch(toastAlert({
                status: 1,
                message: `${rowData.siteName} ${messages.sites.restoreSuccess}`, open: true
              }))
            }
            // let _payload = { ...sitesParams, studyId: currentStudy.id,}
            dispatch(findAllSitesByStudyIdCriteria(payload));
          }
        }));
      }
    }));
  }

  const actionTemplate = (rowData: any) => {

    return (<React.Fragment>
      <div className='actions d-flex'>
        {rowData.status === true ? <React.Fragment>
          <CustomToolTip title='Edit Site'><EditIcon sx={{ fontSize: 14, opacity: .8 }} onClick={() => onOpenSiteForm(rowData)} /></CustomToolTip>
          <span> |</span>
          <CustomToolTip title='Delete Site'><DeleteIcon sx={{ fontSize: 14, opacity: .8 }} className="text-danger" onClick={() => onDeleteRestoreSite('delete', rowData)} /></CustomToolTip>
        </React.Fragment> :
          <CustomToolTip title='Restore Site'><ReplayIcon sx={{ fontSize: 22, opacity: .8 }} onClick={() => onDeleteRestoreSite('restore', rowData)} /></CustomToolTip>}
      </div>
    </React.Fragment>)
  }

  const siteNameTempalte = (rowData: any) => {
    return (<span className={`${rowData.status === false ? 'visit-restore' : "visit-title"}`} >{rowData.siteName}</span>)
  }
  const siteCountryTemplate = (rowData: any) => {
    return (<span>{rowData.country && rowData.country.name}</span>)
  }

  const onPage = (event: any) => {
    console.log("109...",sitesParams,)
    if (((event.page > 0) || (pageClick && event.page === 0)) && (sitesParams.offset !== event.first)) {
      // let _payload = { ...sitesParams, pageSize: event.page, studyId: currentStudy.id, nameCriteria: '' }
      const _payload = { ...sitesParams, nameCriteria: '', offset: event.first, studyId: currentStudy.id }
      console.log("_payload...111", _payload)
      dispatch(findAllSitesByStudyIdCriteria(_payload))
      dispatch({ type: Types.SITES_PARAMS, payload: _payload })
      setpageChange(true)
    }
  }


  const OnFindSiteByName = (event: any) => {
    setSearchSiteByName(event.target.value)
    const _payload = { ...sitesParams, nameCriteria: event.target.value, studyId: currentStudy.id }
    delete _payload.pageSize
    delete _payload.numberOfPages
    dispatch({ type: Types.SITES_PARAMS, payload: _payload })
    dispatch(findAllSitesByStudyIdCriteria(_payload))
  }
  const OnFindSiteByID = (event: any) => {
    setSearchSiteByID(event.target.value)
    const _payload = { ...sitesParams, siteIdName: event.target.value,nameCriteria: '',studyId: currentStudy.id }
    delete _payload.pageSize
    delete _payload.numberOfPages
    dispatch({ type: Types.SITES_PARAMS, payload: _payload })
    dispatch(findAllSitesByStudyIdCriteria(_payload))
  }

  const OnFindSiteByCountry = (event: any) => {
    setSearchSiteByCountry(event.target.value)
    const _payload = { ...sitesParams, countryName: event.target.value,nameCriteria: '', studyId: currentStudy.id }
    delete _payload.pageSize
    delete _payload.numberOfPages
    dispatch({ type: Types.SITES_PARAMS, payload: _payload })
    dispatch(findAllSitesByStudyIdCriteria(_payload))
  }

  const siteEnvTempalte = (rowData: any) => {
    return (<span className={`${rowData.status === false ? 'txt-deleted' : ""}`} >{rowData.maxEnrollments}</span>)
  }

  const siteIdTemplate = (rowData: any) => {
    return (<span className={`${rowData.status === false ? 'txt-deleted' : ""}`} >{rowData.siteCode}</span>)
  }

  const onClearSearch = () => { 
      // setSearchSite('')
      setSearchSiteByName('')
      setSearchSiteByID('')
      setSearchSiteByCountry('')
      const _payload = { ...sitesParams, studyId: currentStudy.id, nameCriteria: '', siteIdName: '', countryName: '' }
      dispatch({ type: Types.SITES_PARAMS, payload: _payload })
      dispatch(findAllSitesByStudyIdCriteria(_payload))
  }

  const onChangePageCount = (e: any) => {
    const _payload = { ...sitesParams, limit: parseInt(e.target.value), studyId: currentStudy.id, nameCriteria: '', offset: 0, siteIdName: '', countryName: '' }
    console.log("_payload..160", _payload)
    dispatch({ type: Types.SITES_PARAMS, payload: _payload })
    dispatch(findAllSitesByStudyIdCriteria(_payload))
  }
  const onSelectSearchType = (e: any) => {
    setSearchSite(e.target.value);
    setSearchSiteByName('');
    setSearchSiteByID('')
    setSearchSiteByCountry('')
    const _payload = { ...sitesParams, studyId: currentStudy.id, nameCriteria: '', siteIdName: '', countryName: '' }
    dispatch(findAllSitesByStudyIdCriteria(_payload))
  }

  return (
    <React.Fragment>
      {open && <AddEditSite setOpen={setOpen} actionType="create" />}
      <div className="d-flex justify-content-between pb-2 controls-container">
        <div className="d-flex">
          <PageCount onChange={(e: any) => onChangePageCount(e)} />
          <div className="left-container">
            <span>Remaining Subjects :</span>
            <div className="count">
              {searchSite !== '' ? siteList.remainingCount : siteList.remainingCount}
            </div>

          </div>
        </div>
        <div className="right-panel d-flex ">
          <button type="button" onClick={() => onOpenSiteForm(null)} className="btn-eoutlined-secondary">Add Site</button>
          {/*
          <SearchField
            placeholder="Search by Site Name"
            value={searchSite}
            onChange={OnFindSite}
            onClearSearch={onClearSearch}
          /> */}
          <FilterSeachContainer>
            <select className='dropdown'
              onChange={onSelectSearchType}
              value={searchSite}>
              {/* <option value=''>Filter By</option> */}
              {
                SiteSearchSelection && SiteSearchSelection.map((i: any, index: any) => (
                  <option key={index} value={i.id}>{i.formName}</option>
                ))
              }
            </select>
            {(searchSite === 'SiteName' || searchSite === "") && <SearchField
              value={searchSiteByName}
              onChange={OnFindSiteByName}
              // disabled={searchSite == "" ? true : false}
              placeholder={'Search By Site Name'}
              onClearSearch={onClearSearch}
            />}

            {searchSite === 'SiteID' && <SearchField
              value={searchSiteByID}
              onChange={OnFindSiteByID}
              placeholder="Search by site id"
              onClearSearch={onClearSearch}
            />}

            {searchSite === 'CountryName' && <SearchField
              value={searchSiteByCountry}
              onChange={OnFindSiteByCountry}
              placeholder="Search by country"
              onClearSearch={onClearSearch}
            />}
          </FilterSeachContainer>
        </div>
      </div>
      {siteList &&
        <DataTable
          value={siteList.sites}
          selectionMode="single"
          emptyMessage="No sites to display."
          lazy
          scrollable
          rows={sitesParams.limit}
          paginator={siteList.totalRecords > sitesParams.limit ? true : false}
          totalRecords={siteList && siteList.totalRecords}
          responsiveLayout="scroll"
          stripedRows={true}
          first={sitesParams.offset}
          onPage={onPage}
        >
          <Column field="siteName" body={siteNameTempalte} header="Site Name" style={{ width: 'auto' }}></Column>
          <Column field="country.name" body={siteCountryTemplate} header="Country" style={{ width: 'auto' }} ></Column>
          <Column field="siteCode" header="Site ID" body={siteIdTemplate} style={{ width: 'auto' }} ></Column>
          <Column field="maxEnrollments" body={siteEnvTempalte} header="Expected Enrollment" style={{ width: 'auto' }}></Column>
          <Column field="status" body={statusTemplate} header="Status" style={{ width: 'auto' }}></Column>
          <Column body={actionTemplate} header="Action" ></Column>
        </DataTable>
      }

    </React.Fragment>
  )
}

export default SiteDetails