import React from "react";
import SitesDetails from './components/sitesDetails/SitesDetails'
import { useSelector, useDispatch } from "react-redux";
import { Types } from "./reducer/Types";

function Sites() {
    const dispatch = useDispatch();
    const { sitesParams} = useSelector((state: any) => state.sites)
    const { currentStudy } = useSelector((state: any) => state.application)
    const loaded = React.useRef(false);


    React.useEffect(() => {
        // console.log("...pagination", sitesParams)
        if(!loaded.current){
        const payload = { ...sitesParams, studyId: currentStudy.id, limit: 10, nameCriteria: '', offset: 0  }
        dispatch({ type: Types.SITES_PARAMS, payload: payload })
        loaded.current=true
              
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <React.Fragment>
            <SitesDetails />
        </React.Fragment >
    )
}
export default Sites;