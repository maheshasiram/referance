import { siteDetails } from "./dataTypes";

export const CreateSiteObj: siteDetails = {
  "studyId": 0,
  "siteCode": "",
  "siteName": "",
  "maxEnrollments": "",
  "country": {
    "id": 0,
    "name": "",
    "countryCode": "",
    "phoneCode": 0
  },
  "status": true
}

export const SiteSearchSelection = [
  { id: 'SiteName', formName: 'Site Name' },
  { id: 'CountryName', formName: 'Country Name' },
  { id: 'SiteID', formName: 'Site ID ' }
]