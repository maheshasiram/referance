type country = {
    id?: number,
    name?: string,
    countryCode?: string,
    phoneCode?: number
}

export type siteDetails = {
    studyId?:number,
    siteCode?:string,
    siteName?: string,
    maxEnrollments?: any,
    country?:country,
    status?: boolean
}