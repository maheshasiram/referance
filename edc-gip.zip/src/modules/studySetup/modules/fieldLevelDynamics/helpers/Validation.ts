
import * as Yup from 'yup';
import store from '../../../../../store/store';

export const messageValidation = Yup.object().shape({
    msg: Yup.string()
        .required("Please enter message")
        // .matches(/^([a-zA-Z0-9]+\s)*[a-zA-Z0-9]+$/, 'Special Characters are not allowed')
        // .matches(/^[a-zA-Z]/, 'Message must start with Text only')
        .matches(/^[A-Za-z].*/, 'Message must start with Text only')
})

export const validateOnSubmit = (fieldDynamics: any) => {
    const { configCodes } = store.getState().application
    const _noResponse = fieldDynamics.dependentFields.length > 0 && fieldDynamics.dependentFields.every((item: any) => item.responseOptions.some((res: any) => res.selected === true))
    const _targetVariable = fieldDynamics.dependentFields.length > 0 && fieldDynamics.dependentFields.every((item: any) => item.responseOptions.some((res: any) => (res.selected === true && res.targetFields?.length <= 0)))
    const _message = fieldDynamics.dependentFields.length > 0 && fieldDynamics.dependentFields.every((item: any) => item.responseOptions.some((res: any) => (res.selected === true && res.message === '')))
    const _noMessage: any = []
    let targetFieldLength = false
    console.log("16...", _noResponse)
    fieldDynamics.dependentFields.map((item: any) => {
        item.responseOptions.map((subItem: any) => {
            if (subItem?.targetFields?.length > 0) {
                targetFieldLength = true
            }
            return null
        })
        return null
    })
    fieldDynamics.dependentFields.map((item: any) => {
        item.responseOptions.map((subItem: any) => {
            if (subItem.selected === true && subItem.message === "") {
                _noMessage.push(subItem.responseOption)
            }
            return null
        })
        return null
    })
    if (fieldDynamics.dependentType.code === configCodes?.SingleTarget) {
        if (fieldDynamics.visits.length <= 0) {
            return {
                target: "",
                message: "",
                dependent: "",
                visits: "Please Select Visit"
            };

        } else if (fieldDynamics.dependentFields.length <= 0) {
            return {
                target: "",
                message: "",
                dependent: "Please drag dependent variable",
                visits: ''
            };
        } else if (!_noResponse) {
            return {
                target: "",
                message: "",
                dependent: "Please select response options",
                visits: ''
            };
        }
        else if (_targetVariable) {
            return {
                target: "Please Drag target variable",
                message: "",
                dependent: "",
                visits: ''
            };
        }
        else if (_message) {
            return {
                target: "",
                message: "Please enter valid message",
                dependent: "",
                visits: ''
            };
        } else { return true; }
    } else {
        if (fieldDynamics.visits.length <= 0) {
            return {
                target: "",
                message: "",
                dependent: "",
                visits: "Please Select Visit"
            };

        }
        else if (fieldDynamics.dependentFields.length <= 0) {
            return {
                target: "",
                message: "",
                dependent: "Please drag dependent variable",
                visits: ''
            };
        } else if (!targetFieldLength) {
            return {
                target: "Please drag atleast one target variable",
                message: "",
                dependent: "",
                visits: ''
            };
        } else if (_noMessage.length > 0) {
            return {
                target: "",
                message: `Please enter message for response option ${_noMessage.join()}`,
                dependent: "",
                visits: ''
            };
        }
        else { return true; }
    }
}


export const validateSingleTargetFLD = (payload: any, nodeElement: any, section: string) => {
    console.log("...nodeElement", nodeElement)
    let errors: any = false;

    const sameGroup = payload.dependentFields.filter((item: any) => (item.groupId !== null) && item.groupId !== nodeElement.groupId)
    const sameDependent = payload.dependentFields.filter((item: any) => item.fieldId === nodeElement.id);
    const nonGroupVariable = payload.dependentFields.filter((item: any) => (item.groupId === null && nodeElement.groupId !== null))
    const targetNonGroupVariable = payload.dependentFields.filter((item: any) => (item.groupId === null) && (!('children' in nodeElement) && nodeElement.groupId !== null))
    const _sameTargetGroup = payload.dependentFields.filter((item: any) => (nodeElement.children && nodeElement.groupId === item.groupId))
    const _targetLength: any = [];
    payload.dependentFields.map((item: any) =>
        item.responseOptions.map((subItem: any) => {
            if (subItem.targetFields.length > 0) {
                _targetLength.push(subItem)
            }
            return null
        })
    )

    if (section === 'dependent') {
        if (!nodeElement.responseOptions || nodeElement.responseOptions.length <= 0) {
            errors = {
                dependent: "This variable doesn't have any response options!",
                target: "",
                message: '',
                visits: ''
            }
        } else if (sameGroup.length > 0) {
            errors = {
                dependent: "Please drag variable from same group",
                target: "",
                message: '',
                visits: ''
            }
        } else if (sameDependent.length > 0) {
            errors = {
                dependent: "This Variable is already exists Please drag different Variable",
                target: "",
                message: '',
                visits: ''
            }
        } else if (nonGroupVariable.length > 0) {
            errors = {
                dependent: "Please drag from non-group variable",
                target: "",
                message: '',
                visits: ''
            }
        }


    } else {
        if (payload.dependentFields.length > 0 && sameDependent.length > 0 && _targetLength.length <= 0) {
            errors = {
                dependent: "",
                target: "Target and Dependent variables should not be same",
                message: '',
                visits: ''
            }
        } else if (sameGroup.length > 0) {
            errors = {
                dependent: "",
                target: "Please drag variable from same group",
                message: '',
                visits: ''
            }
        }
        else if (targetNonGroupVariable.length > 0 && _targetLength.length <= 0) {
            errors = {
                dependent: "",
                target: "Please drag a variable from non-group or drag a group",
                message: '',
                visits: ''
            }
        }
        else if (_sameTargetGroup.length > 0) {
            errors = {
                dependent: "",
                target: "Please drag another variable",
                message: '',
                visits: ''
            }

        }
    }
    return errors;
}
export const validateMultipleTargetFLD = (payload: any, nodeElement: any, section: string, Tindex: number, TsubIndex: number) => {
    let errors: any = false;
    const sameDependent = payload.dependentFields.filter((item: any) => nodeElement.id === item.fieldId);
    // const sameGroup = payload.dependentFields.filter((item: any) => (item.groupId !== null && nodeElement.groupId === null) && item.groupId !== nodeElement.groupId)
    const sameGroup = payload.dependentFields.filter((item: any) => (item.groupId !== null) && item.groupId !== nodeElement.groupId)
    // const msgValidation = paylaod.
    const targetNonGroupVariable = payload.dependentFields.filter((item: any) => (item.groupId === null) && (!('children' in nodeElement) && nodeElement.groupId !== null))
    // let targetNonGroupVariable = payload && payload.dependentFields.filter((item: any) => ((item.groupId === null && (nodeElement.groupId == null || (nodeElement?.children)))))
    let sameTarget;
    console.log("208....", sameTarget)
    payload.dependentFields.map((item: any) => {
        item.responseOptions.map((subItem: any, subIndex: number) => {
            // console.log("213...", subItem)
            let flag = false
            subItem.targetFields.map((i: any) => {
                console.log("216....", i, nodeElement)
                if (i.fieldId === nodeElement.id) {
                    flag = true
                }
                else if (i.groupId && i.groupId === nodeElement.groupId) {
                    flag = true
                }
                return null
            })
            if (subIndex === TsubIndex && flag) {
                sameTarget = subItem.responseOption
            }
            return null
        })
        return null
    })
    if (section === 'dependent') {
        if (sameGroup.length > 0) {
            errors = {
                dependent: "Please drag variable from same group",
                target: "",
                message: '',
                visits: ''
            }
        }
        else if ((payload.dependentFields.length <= 0) && (!nodeElement.responseOptions || nodeElement.responseOptions.length <= 0)) {
            errors = {
                dependent: "This variable doesn't have any response options!",
                target: "",
                message: '',
                visits: ''
            }
        }
    } else {
        if (sameGroup.length > 0) {
            errors = {
                dependent: "",
                target: "Please drag variable from same group",
                message: '',
                visits: ''
            }
        }
        if (targetNonGroupVariable.length > 0) {
            errors = {
                dependent: "",
                target: "Please drag from non-group variable or drag a group",
                message: '',
                visits: ''
            }
        }
        if (payload.dependentFields.length > 0 && sameDependent.length > 0) {
            errors = {
                dependent: "",
                target: "Target and Dependent variables should not be same",
                message: '',
                visits: ''
            }
        }
        else if (sameTarget) {
            errors = {
                dependent: "",
                target: `Target variable already exists for response option ${sameTarget}`,
                message: '',
                visits: ''
            }
        }
    }
    return errors;
}


