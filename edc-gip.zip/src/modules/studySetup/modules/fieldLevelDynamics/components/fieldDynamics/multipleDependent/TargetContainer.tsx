import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { Types } from "../../../reducers/types";
import CancelIcon from '@mui/icons-material/Cancel';
import { validateSingleTargetFLD } from "../../../helpers/Validation";
import CustomToolTip from "../../../../../../../components/CustomToolTip";

function TargetContainer(props: any) {
    const dispatch = useDispatch()
    const { node, validations, onSetValidations } = props
    const { fieldDynamics, treeViewData } = useSelector((state: any) => state.dynamics);
    const displayDropTarget = () => {
        console.log("12......displayDropTarget")
        if (fieldDynamics?.dependentFields.length > 0) {
            let _flag = false
            fieldDynamics?.dependentFields.map((item: any) => {
                item.responseOptions.map((subItem: any) => {
                    if (subItem.targetFields && subItem.targetFields.length > 0) {
                        _flag = true
                    }
                    return null
                })
                return null
            })
            return _flag
        }
    }
    const onDragHoverEelement = (e: any) => {
        e.preventDefault();
    }

    const onDropTargetVariable = () => {
        console.log("target Node...", node)
        const payload = { ...{}, ...fieldDynamics }
        const errors: any = Object.keys(node).length > 0 && validateSingleTargetFLD(payload, node, 'target')
        let _targetVariableFlag = false
        if (Object.keys(node).length > 0 && errors === false) {
            fieldDynamics.dependentFields.map((item: any, index: number) => {
                item.responseOptions.map((subItem: any, subIndex: number) => {
                    if (subItem?.targetFields?.length <= 0) {
                        if (subItem.selected) {
                            payload.dependentFields[index].responseOptions[subIndex].targetFields.push({
                                "id": null,
                                "fieldId": node.id,
                                "groupId": node.groupId,
                                "variableId": node.label,
                                "variableText": node.variableText,
                                "groupName": null
                            })
                        } else {
                            payload.dependentFields[index].responseOptions[subIndex].targetFields = []
                        }
                    }
                    return null

                })
                return null
            })
            payload.dependentFields.map((item: any) => {
                item.responseOptions.map((subItem: any) => {
                    if (subItem?.targetFields?.length > 0) {
                        _targetVariableFlag = true
                    }
                    return null
                })
                return null
            })
            if (_targetVariableFlag) {
                onSetValidations({ target: "" })
            }

        } else {
            onSetValidations(errors)
        }

        dispatch({ type: Types.CREATE_FIELD_LEVEL, payload: payload })

    }

    const renderTargetVariable = () => {
        let _targetVariable: any = null
        fieldDynamics.dependentFields.map((item: any) =>
            item.responseOptions.map((subItem: any) => {
                if (subItem.selected) {
                    _targetVariable = subItem
                }
                return null
            })
        )
        console.log("81...", _targetVariable)
        return _targetVariable
    }

    const onDeleteTarget = (e: any) => {
        console.log(e)
        const payload = { ...{}, ...fieldDynamics }
        payload.dependentFields.map((item: any) => {
            item.responseOptions.map((subItem: any) => {
                subItem.targetFields = []
                return null
            })
            return null
        })
        onSetValidations({ target: "" })
        dispatch({ type: Types.CREATE_FIELD_LEVEL, payload: payload })
    }

    const onMessageChangeHandler = (e: any) => {
        const payload = { ...{}, ...fieldDynamics }
        fieldDynamics.dependentFields.map((item: any, index: number) => {
            item.responseOptions.map((subItem: any, subIndex: number) => {
                if (subItem.selected) {
                    payload.dependentFields[index].responseOptions[subIndex].message = e.target.value
                } else {
                    payload.dependentFields[index].responseOptions[subIndex].message = ''
                }
                return null
            })
            return null
        })
        onSetValidations({ message: "" })
        dispatch({ type: Types.CREATE_FIELD_LEVEL, payload: payload })
    }
    const onBlurHandler = (e: any) => {
        e.preventDefault();
    }
    return (
        <React.Fragment>
            <div className="target-wrapper" id="targetContainer">
                <label className="fld-label">Target Variable <span style={{color:'red',fontSize:'12px'}}>*</span></label>
                <div className="target-container"
                    id="targetVariable"
                    onDragOver={onDragHoverEelement}
                    onDrop={onDropTargetVariable}>
                    {!displayDropTarget() ? <span className="txt-default">Drag <i>Target</i> Variable here</span> :

                        <ul className='vars-container'>
                            {renderTargetVariable().targetFields?.map((item: any) => (
                                <CustomToolTip title={item.variableText ? item.variableText : item.groupName} key={item.variableId}>
                                    <li>
                                        <React.Fragment key={item.variableId}>
                                            <span >{item.variableId}
                                                {
                                                    treeViewData?.map((i: any, index: any) => {
                                                        if (i.variableId === item.variableId) {
                                                            return <span key={index}>
                                                                ({i.datatype.name}/{i.responseType.name})
                                                            </span>
                                                        }
                                                        return null
                                                    })
                                                }
                                            </span>
                                            <CancelIcon onClick={(e) => onDeleteTarget(e)} />
                                        </React.Fragment>
                                    </li>
                                </CustomToolTip>
                            ))}
                        </ul>}
                </div>
                <div>{(validations && validations.target) && <span className="text-danger">
                    {validations.target}</span>}</div>
            </div>
            <div className="logic-wrapper" id="dependentContainer">
                <div className="mt-2" id="messageContainer" onDrop={(e: any) => { e.preventDefault() }}>
                    <label className='fieldLabel m-0 fld-label'>Message:</label>
                    <input type="text" placeholder="Enter message" className={`form-control`} id="conditionMeg"
                        value={renderTargetVariable().message}
                        onChange={onMessageChangeHandler}
                        onBlur={onBlurHandler}
                        onDrop={(e: any) => e.preventDefault()} />
                </div>
                <div>{(validations && validations.message) && <span className="text-danger">
                    {validations.message}</span>}</div>
            </div>

        </React.Fragment>
    )
}
export default TargetContainer