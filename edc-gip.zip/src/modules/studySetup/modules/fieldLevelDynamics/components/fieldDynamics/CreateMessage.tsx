import React from "react";
import { Formik, Form, Field, ErrorMessage } from 'formik';
import CustomDialog from "../../../../../../common/modals/CustomeDialog";
import { messageValidation } from "../../helpers/Validation";
import { useSelector, useDispatch } from "react-redux";
import { getCurrentStudyDetails, saveOrUpdateStudy } from "../../../study/actions/actions";
import { toastAlert } from "../../../../../../actions/actions";

function CreateMessage() {
    const dispatch = useDispatch()
    const [open, setOpen] = React.useState(false);
    const { currentStudy } = useSelector((state: any) => state.application);
    const [btnDisable, setBtnDisable] = React.useState(true)
    const onCreateMessage = () => {
        setOpen(true)
    }
    const onsubmitMessage = (values: any) => {
        const _payload = { ...{}, ...currentStudy }
        _payload.fldMessage = values.msg
        dispatch(saveOrUpdateStudy(_payload, (data: any) => {
            if (data.status === "error") {
                setOpen(true)
                dispatch(toastAlert({
                    status: 2, message: `${data.errorMessage}`, open: true,
                }))
            } else {
                dispatch(getCurrentStudyDetails(_payload.id))
                setOpen(false)
                dispatch(toastAlert({
                    status: 1, message: 'Message updated successfully', open: true
                }))

            }
        }))

    }
    const onCloseHandler = () => {
        setOpen(false)
    }
    return (
        <React.Fragment>
            <div>
                <button className="btn-eprimary" onClick={onCreateMessage}>Create Message</button>
            </div>
            <CustomDialog
                title={"Create Message"}
                open={open}
                onClose={onCloseHandler}
                maxWidth="xs"
                fullWidth={true}
                actionType={"submit"}
                form='createMsg'
                disabled={btnDisable}
            >
                <Formik
                    enableReinitialize={true}
                    initialValues={{ msg: currentStudy.fldMessage ? currentStudy.fldMessage : "" }}
                    validationSchema={messageValidation}
                    onSubmit={(values: any) => { onsubmitMessage(values); }}
                >
                    {({ setFieldValue,setFieldTouched }) => (
                        <Form id="createMsg">
                            <div className="pb-2">
                                <label htmlFor="txt-groupName">Message: </label>
                                <Field
                                    as='textarea'
                                    name='msg'
                                    className="form-control form-control-lg"
                                    onChange={(e: any) => {
                                        if (((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
                                            setFieldTouched('msg',true);
                                            setFieldValue("msg", e.target.value);
                                            setBtnDisable(false)
                                            // setDisableBtn(false);
                                        }
                                    }}

                                />
                                <span className="text-danger"><ErrorMessage name='msg' /></span>
                            </div>
                        </Form>)}
                </Formik>
            </CustomDialog>
        </React.Fragment>
    )
}
export default CreateMessage;