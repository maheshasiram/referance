import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { Types } from "../../../reducers/types";
import CancelIcon from '@mui/icons-material/Cancel';
import { validateMultipleTargetFLD } from "../../../helpers/Validation";
import CustomToolTip from "../../../../../../../components/CustomToolTip";

function TargetVariables(props: any) {
  const { fieldDynamics, treeViewData } = useSelector((state: any) => state.dynamics);
  const { node, validations, onSetValidations } = props
  const dispatch = useDispatch();
  const onDragHoverEelement = (e: any) => {
    e.preventDefault();
  }

  const onDropTargetElement = (e: any, index: number, subIndex: number) => {
    console.log("target node...", node)
    const payload = { ...{}, ...fieldDynamics }
    const errors: any = Object.keys(node).length > 0 && validateMultipleTargetFLD(payload, node, 'target', index, subIndex)
    if (Object.keys(node).length > 0 && errors === false) {
      const _targetFields = {
        "id": null,
        "fieldId": node?.children ? null : node.id,
        "groupId": node.groupId,
        "variableId": node?.children ? null : node.label,
        "variableText": node.variableText,
        "groupName": node?.children ? node.label : null
      }
      payload.dependentFields[index].responseOptions[subIndex].targetFields.push(_targetFields)
      payload.dependentFields[index].responseOptions[subIndex].selected = true
      onSetValidations({ target: "" })
    } else {
      onSetValidations(errors)
    }
    dispatch({ type: Types.CREATE_FIELD_LEVEL, payload: payload })
  }
  const onMsgChangeHandler = (e: any, index: number, subIndex: number) => {
    const payload = { ...{}, ...fieldDynamics }
    const errors: any = Object.keys(node).length > 0 && validateMultipleTargetFLD(payload, node, 'target', NaN, NaN)
    let result = /^[A-Za-z].*/.test(e.target.value)
    console.log("40...", result)
    if (!result) {
      onSetValidations({ message: "Message must start with Text only" })
    } else {
      onSetValidations({ message: "" })
    }
    payload.dependentFields[index].responseOptions[subIndex].message = e.target.value
    dispatch({ type: Types.CREATE_FIELD_LEVEL, payload: payload })
  }

  const onDeleteEelement = (e: any, index: number, subIndex: number, targetIndex: number) => {
    const payload = { ...{}, ...fieldDynamics }
    payload.dependentFields[index].responseOptions[subIndex].targetFields.splice(targetIndex, 1);
    dispatch({ type: Types.CREATE_FIELD_LEVEL, payload: payload })
  }
  return (
    <React.Fragment>
      <div className="d-flex pt-3">
        <div className="w-100">
          <div className="d-flex">
            <label className="fld-label">Dependent Responses <span style={{ color: 'red', fontSize: '12px' }}>*</span></label>
            {validations && validations.target && <div>{(validations && validations.target) && <span className="text-danger">
              {validations.target}</span>}</div>}
            {validations && validations.message && !validations.target  && <div>{(validations && validations.message) && <span className="text-danger">
              {validations.message}</span>}</div>}
          </div>
          <div className="dependentResponse-cls">
            {
              fieldDynamics?.dependentFields?.map((item: any, index: any) =>
                item?.responseOptions?.map((subItem: any, subIndex: number) => (
                  <div className="responeOption-container" key={index}>
                    <div className="label-container">
                      <label>{subItem.responseOption}</label>
                    </div>
                    <div className="targetMessage-container">
                      <div>
                        <label>Target Variable</label>
                        {subItem?.targetFields.length > 0 && <div className="target-container">
                          <ul className='vars-container'>
                            {
                              (subItem?.targetFields.length > 0) &&
                              <React.Fragment>
                                {
                                  subItem?.targetFields?.map((targetField: any, targetIndex: number) => (
                                    <CustomToolTip key={index} title={targetField.variableText ? targetField.variableText : targetField.groupName}>
                                      <li>
                                        <React.Fragment>
                                          <span className="d-flex">{targetField.variableId ? targetField.variableId : targetField.groupName}
                                            {
                                              treeViewData?.map((i: any) => (
                                                i?.children?.length > 0 ? i?.children.map((data: any) => (
                                                  <div>
                                                    {data.variableId === targetField?.variableId && <span>
                                                      ({data.datatype.name}/{data.responseType.name})
                                                    </span>}
                                                  </div>
                                                )) :
                                                  <div>
                                                    {
                                                      i.variableId === targetField?.variableId && <span key={index}>
                                                        {console.log("95....", i)}
                                                        ({i.datatype.name}/{i.responseType.name})
                                                      </span>
                                                    }
                                                  </div>
                                              ))
                                            }
                                          </span>
                                          <CancelIcon onClick={(e) => onDeleteEelement(e, index, subIndex, targetIndex)} />
                                        </React.Fragment>
                                      </li>
                                    </CustomToolTip>
                                  ))
                                }
                              </React.Fragment>
                            }
                          </ul>
                        </div>}
                        <div className="target-drop-container mt-2" id="targetVariable"
                          onDragOver={onDragHoverEelement}
                          onDrop={(e: any) => onDropTargetElement(e, index, subIndex)}>
                          <span className="txt-default">Drag <i>Target</i> Variable here</span>
                        </div>
                      </div>
                      <div>
                        <label className='fieldLabel m-0'>Message</label>
                        <input type="text" placeholder="Enter Message" className={`form-control`} id="conditionMeg"
                          value={subItem.message}
                          onDrop={(e: any) => e.preventDefault()}
                          onChange={(e) => onMsgChangeHandler(e, index, subIndex)} />
                          <span>{}</span>
                      </div>
                    </div>
                  </div>
                )
                )
              )
            }
          </div>
        </div>
      </div>
    </React.Fragment>
  )
}
export default TargetVariables