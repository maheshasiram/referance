import React from "react";
import { useDispatch, useSelector } from "react-redux";
import KeyboardDoubleArrowLeftIcon from '@mui/icons-material/KeyboardDoubleArrowLeft';
import DropdownComponent from "../../../../../../components/DropdownComponent";
import { useParams, useNavigate } from "react-router-dom";
import { fetchTreeViewData, getFeildDynamics, getFormsByStudyId, onUpdateFieldDynamics, saveFieldLevelDynamic } from "../../actions/actions";
import Footer from "../../../derivations/components/createDerivation/Footer";
import TreeviewComponent from "../../../../../../components/TreeviewComponent";
import { Types } from "../../reducers/types";
import SelectField from "../../../../../../common/selectField/SelectField";
import { fetchVisitsAssignedToFormId } from "../../../forms/actions/actions";
import { validateOnSubmit } from "../../helpers/Validation";
import SingleDependent from "./singleDependent/SingleDependent";
import MultipleDependent from "./multipleDependent/MultipleDependent";
import { configDataType, toastAlert } from "../../../../../../actions/actions";
import _ from "lodash";
import { color } from "echarts";

function CreateFiledDynamics() {
  const dispatch = useDispatch()
  const params: any = useParams();
  const navigate = useNavigate();
  const { fieldDynamics, forms, treeViewData, dependentType } = useSelector((state: any) => state.dynamics);
  const { currentStudy, configCodes } = useSelector((state: any) => state.application);
  const { visitAssignedToForms } = useSelector((state: any) => state.forms);
  const [validations, setValidations] = React.useState({ target: "", dependent: "", message: "", visits: "" });
  const [value, setValue] = React.useState("");
  const actionType = 'dynamic'
  const [node, setNode] = React.useState({});
  const loaded = React.useRef(false);
  const [dependentTypeSelected, setdependentTypeSelected] = React.useState(configCodes?.MultipleTarget)
  const [visitSelected, setVisitSelected] = React.useState([])
  const options: any = []
  React.useEffect(() => {
    if (!loaded.current) {
      dispatch(configDataType('FLD_DEPENDENT_TYPE', (congifResponse: any) => {
        dispatch({ type: Types.FLD_DEPENDENT_TYPE, payload: congifResponse.FLD_DEPENDENT_TYPE })
        console.log("38....", congifResponse.FLD_DEPENDENT_TYPE)
      }))
      if (parseInt(params.id) > 0) {
        dispatch(getFormsByStudyId(currentStudy.id, () => {
          dispatch(getFeildDynamics(parseInt(params.id), (response: any) => {
            dispatch(fetchTreeViewData(response.form.id))
            dispatch(fetchVisitsAssignedToFormId(response.form.id, (data: any) => {
              const output = data.filter((obj: any) => response.visits.indexOf(obj.id) !== -1);
              const options: any = []
              output.map((item: any) => {
                const option = {
                  label: item.visitName,
                  value: item.id
                }
                options.push(option)
                return null;
              })
              setVisitSelected(options)
            }))
            dispatch({ type: Types.CREATE_FIELD_LEVEL, payload: response })
            setValue(response.form.id);
          }))
        }))
      } else {
        dispatch(getFormsByStudyId(currentStudy.id))
        dispatch({
          type: Types.CREATE_FIELD_LEVEL, payload: {
            ...fieldDynamics,
            form: {},
            dependentFields: [],
            visits: [],
            targetType: ''
          }
        })
      }
      loaded.current = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const onFormChangeHandler = (value: any) => {
    const payload = { ...{}, ...fieldDynamics }
    const _forms = [...[], ...forms]
    const form = _forms.find((item: any) => item.id === parseInt(value));
    const _dependentType = dependentType && dependentType.find((dType: any) => dType.code === configCodes?.MultipleTarget)
    console.log('82', _dependentType)
    setValue(value);
    setVisitSelected([])
    payload.dependentFields = []
    payload.visits = []
    if (value !== '') {
      delete Object.assign(form, { 'noOfFields': form['formFields'] })['formFields'];
      form.noOfFields = 0
      payload.form = form
      payload.dependentType = _dependentType
      dispatch(fetchTreeViewData(value))
      dispatch(fetchVisitsAssignedToFormId(value))
    } else {
      payload.form = {
        id: 0,
        formName: "",
        ordinal: 0,
        status: true,
        studyId: currentStudy.id,
        noOfFields: null,
      }
    }
    onSetValidations({ target: "", dependent: "", message: "", visits: "" });
    dispatch({ type: Types.CREATE_FIELD_LEVEL, payload })
  }
  const onSubmitHandler = () => {
    const validations = validateOnSubmit(fieldDynamics);
    console.log("...68...", validations)
    const payload: any = _.cloneDeep(fieldDynamics)
    fieldDynamics.dependentFields.map((item: any, index: number) => {

      const _array: any = []
      item.responseOptions.map((subItem: any) => {
        if (subItem?.targetFields?.length > 0) {
          _array.push(subItem)
        }
        return null
      })
      payload.dependentFields[index].responseOptions = _array
      return null
    })
    if (validations !== true) {
      console.log("...77...", validations)
      setValidations(validations);
    } else {
      setValidations({ target: "", dependent: "", message: "", visits: "" });
      delete payload.targetType
      delete payload.selected
      dispatch(((parseInt(params.id) <= 0) ? saveFieldLevelDynamic : onUpdateFieldDynamics)(payload, (response: any) => {
        let message = `Field level dynamics ${parseInt(params.id) <= 0 ? 'created' : 'updated'} successfully`
        if (response.errorCode) {
          message = response.errorMessage
        } else {
          navigate('/study/dynamics')
        }
        dispatch(toastAlert({ status: (response.errorCode ? 2 : 1), message, open: true }))
      }))
    }
  }
  const onGetNodeDetails = (node: any) => {
    setNode(node);
  }
  const ondragEnd = () => {
    setNode({})
  }
  const onDependentTypeChange = (e: any) => {
    console.log(dependentTypeSelected, "1477")
    const _dependentType = dependentType && dependentType.find((dType: any) => dType.code === e.target.value)
    const payload = { ...{}, ...fieldDynamics }
    payload.dependentType = _dependentType
    payload.dependentFields = []
    payload.visits = []
    setdependentTypeSelected(e.target.value)
    setVisitSelected([])
    onSetValidations({ target: "", dependent: "", message: "", visits: "" });
    dispatch({ type: Types.CREATE_FIELD_LEVEL, payload })
  }

  const onSetValidations = (validation: any) => {
    setValidations({ ...validations, ...validation });
  }
  const onBackToDynamics = () => {
    navigate('/study/dynamics');
  }
  const onVisitChangeHandler = (e: any) => {
    const payload = { ...{}, ...fieldDynamics }
    const _id: any = []
    const selectedVisit: any = []
    e.map((visit: any) => {

      console.log(visit.value, "168.......")
      _id.push(visit.value)
      selectedVisit.push(visit)
      return null;
    })
    payload.visits = _id
    onSetValidations({ visits: '', dependent: '' })
    setVisitSelected(selectedVisit)
    if (selectedVisit.length <= 0) {
      payload.dependentFields = []
    }
    dispatch({ type: Types.CREATE_FIELD_LEVEL, payload })
  }
  const visitOptions = (visitsList: any) => {
    visitsList.map((item: any) => {
      const option = {
        label: item.visitName,
        value: item.id
      }
      options.push(option)
      return null;
    })
    return options
  }
  console.log('fieldDynamicsssssssss......', fieldDynamics)

  return (
    <React.Fragment>
      <div className="layout-container">
        <div className="form-header ">
          <h6> {fieldDynamics && fieldDynamics.id && fieldDynamics.id > 0 ? "Update Field Level Dynamics" : "Create Field Level Dynamics"} </h6>
          <span className="btn-back" onClick={onBackToDynamics}>
            <KeyboardDoubleArrowLeftIcon /> Back To Field Level Dynamics</span>
        </div>
        <div className="main-panel">
          <div className="left-panel">
            <div className="content-container field-container">
              <div className="derivation-types justify-content-between">
                <div className="d-flex align-items-center">
                  <label className="fld-label me-2">Study Forms <span style={{color:'red',fontSize:'12px'}}>*</span> </label>
                  <DropdownComponent
                    data={forms}
                    selectedOption={value}
                    disabled={parseInt(params.id) > 0 ? true : false}
                    onChangeHandler={onFormChangeHandler}
                    className='form-select dropdown-form-onDialog'
                  />
                </div>
                {
                  (fieldDynamics?.form?.formName) && <div className="d-flex">
                    <div className="d-flex align-items-center me-2">
                      {
                        dependentType && dependentType.map((type: any, index: any) => (
                          <React.Fragment key={index}>
                            <input type='radio' name='dependentType' value={type.code}
                              onChange={onDependentTypeChange}
                              checked={fieldDynamics?.dependentType?.code === type.code}
                              disabled={parseInt(params.id) > 0} />
                            <label className="fld-label ms-1 me-2">{type.name}</label>
                          </React.Fragment>
                        ))
                      }
                    </div>
                  </div>
                }
              </div>
              {fieldDynamics?.form?.formName && <div className="target-wrapper" id="targetContainer">
                <label className="fld-label">Visits <span style={{color:'red',fontSize:'12px'}}>*</span></label>
                <SelectField
                  id={"visitName"}
                  defaultValue={"Select Visit"}
                  isDisabled={fieldDynamics?.dependentFields.length > 0 ? true : false}
                  isClearable={true}
                  isSearchable={true}
                  name={"VistsList"}
                  value={visitSelected}
                  onChange={(e: any) => { onVisitChangeHandler(e) }}
                  options={visitOptions(visitAssignedToForms)}
                  isMulti={true}
                  selectAll={true}
                  placeholder="Select Visit"
                />
                <div>{(validations && validations.visits) && <span className="text-danger">
                  {validations.visits}</span>}</div>
              </div>}
              {fieldDynamics?.dependentType?.code === configCodes?.SingleTarget ? <MultipleDependent
                node={node}
                params={params}
                onSetValidations={onSetValidations}
                validations={validations}
                visitSelected={visitSelected}
                setVisitSelected={setVisitSelected}
              /> :
                fieldDynamics?.dependentType?.code === configCodes?.MultipleTarget ? <SingleDependent
                  node={node}
                  params={params}
                  visitAssignedToForms={visitAssignedToForms}
                  onSetValidations={onSetValidations}
                  validations={validations}
                  visitSelected={visitSelected}
                  setVisitSelected={setVisitSelected}
                /> :
                  (<React.Fragment>
                    <div className="e-alert-info w-100 py-5 mt-5" role="alert">
                      <h4>Create Field Level Dynamics!</h4>
                      <span>Please Select Form And Start Creating New Field Dynamics!</span>
                    </div>
                  </React.Fragment>)}
              {value && <Footer onSubmitHandler={onSubmitHandler} onCancelHandler={onBackToDynamics} actionType={actionType} />}
            </div>
          </div>
          <div className="right-panel">
            <h1>Drag a variable from here</h1>
            <div className="menu-container field-menu">
              {
                fieldDynamics?.form?.formName ? (
                  <React.Fragment>
                    <TreeviewComponent
                      data={treeViewData}
                      onDragTreeviewNode={onGetNodeDetails}
                      ondragEnd={ondragEnd}
                      placeholder='Search group or field'
                      payload={fieldDynamics}
                      type='fld'
                    />
                  </React.Fragment>) :
                  (
                    <div className="e-alert-info w-100 py-5 mt-5" role="alert">
                      <h6>No Variables match to display!</h6>
                      <span>Please Select Form From Left Panel Dropdown!</span>
                    </div>)
              }
            </div>
          </div>
        </div>
      </div>
    </React.Fragment>
  )
}
export default CreateFiledDynamics