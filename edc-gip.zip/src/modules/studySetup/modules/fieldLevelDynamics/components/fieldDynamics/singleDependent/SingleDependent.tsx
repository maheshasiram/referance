import React from "react";
import DependentContainer from "./DependentContainer";
import { useSelector } from "react-redux";

function SingleDependent(props: any) {
    const { node, params, validations, onSetValidations } = props
    const { fieldDynamics } = useSelector((state: any) => state.dynamics);

    return (
        <React.Fragment>
            {fieldDynamics?.visits.length > 0 && <DependentContainer
                node={node}
                params={params}
                validations={validations}
                onSetValidations={onSetValidations}
            />
            }
        </React.Fragment>
    )
}
export default SingleDependent