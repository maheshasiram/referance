import React from "react";
import DependentContainer from "./DependentContainer";
import TargetContainer from "./TargetContainer";
import { useSelector } from "react-redux";

function MultipleDependent(props: any) {
    const { node, params, validations, onSetValidations } = props
    const { fieldDynamics, } = useSelector((state: any) => state.dynamics);

    const displayTarget = () => {
        if (fieldDynamics?.dependentFields.length > 0) {
            let _flag = false
            fieldDynamics?.dependentFields.map((item: any) => {
                item.responseOptions.map((subItem: any) => {
                    if (subItem.selected) {
                        _flag = true
                    }
                    return null
                })
                return null
            })
            return _flag
        }
    }
    return (
        <React.Fragment>
            {fieldDynamics?.visits.length > 0 && <DependentContainer node={node} params={params}
                validations={validations}
                onSetValidations={onSetValidations} />}
            {displayTarget() && <TargetContainer node={node}
                params={params}
                validations={validations}
                onSetValidations={onSetValidations} />}
        </React.Fragment>
    )
}
export default MultipleDependent