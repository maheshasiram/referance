import React from "react";
import { useDispatch, useSelector } from "react-redux";
import CancelIcon from '@mui/icons-material/Cancel';
import { Types } from "../../../reducers/types";
import TargetVariables from "./TargetVariables";
import { validateMultipleTargetFLD } from "../../../helpers/Validation";
import CustomToolTip from "../../../../../../../components/CustomToolTip";
// import CustomToolTip from "../../../../../../../components/CustomToolTip";

function DependentContainer(props: any) {
  const { fieldDynamics, treeViewData } = useSelector((state: any) => state.dynamics);
  const { currentStudy } = useSelector((state: any) => state.application);
  const { validations, params, node, onSetValidations } = props;
  const dispatch = useDispatch();
  const onDragHoverEelement = (e: any) => {
    e.preventDefault();
  }
  const onDropDependentElement = () => {
    const payload = { ...{}, ...fieldDynamics }
    const errors: any = Object.keys(node).length > 0 && validateMultipleTargetFLD(payload, node, 'dependent', NaN, NaN)
    console.log("node....", errors)
    if (errors === false && payload.dependentFields.length <= 0) {
      const _dependentFields = {
        id: node.id,
        fieldId: node.id,
        fieldIdName: node.label,
        groupId: node.groupId,
        groupName: null,
        responseOptions: node.responseOptions.map((option: any) => (
          {
            id: null,
            responseOptionId: option.id,
            responseOption: option.response,
            message: currentStudy.fldMessage,
            selected: false,
            targetFields: []
          }
        )),
        availableResponseOptions: node.responseOptions
      }
      payload.dependentFields.push(_dependentFields)
      onSetValidations({ dependent: "" })
      dispatch({ type: Types.CREATE_FIELD_LEVEL, payload: payload })
    } else {
      onSetValidations(errors)
    }
  }
  const onDeleteEelement = (e: any, index: number) => {
    const payload = { ...{}, ...fieldDynamics };
    payload.dependentFields.splice(index, 1);
    fieldDynamics.dependentFields = [];
    onSetValidations({ dependent: "", target: "", message: "" })
    dispatch({ type: Types.CREATE_FIELD_LEVEL, payload })
  }
  return (
    <React.Fragment>
      <div className="target-wrapper" id="targetContainer">
        <label className="fld-label">Dependent Variable <span style={{ color: 'red', fontSize: '12px' }}>*</span></label>
        <div className="target-container"
          id="targetVariable"
          onDragOver={onDragHoverEelement}
          onDrop={onDropDependentElement}>
          {(fieldDynamics?.dependentFields.length <= 0) &&
            <span className="txt-default">Drag  <i>Dependent</i> (Select | Radio | Checkboxes options) Variable here</span>}
          <ul className='vars-container'>
            {(fieldDynamics?.dependentFields?.length > 0) &&
              <React.Fragment>
                {
                  fieldDynamics?.dependentFields?.map((field: any, index: number) => (
                    <div>
                      <li key={index}>
                        <React.Fragment>
                          {/* <CustomToolTip title='hello'>
                    </CustomToolTip> */}
                          <span className="d-flex">
                            {field.fieldIdName ? field.fieldIdName : field.groupName}
                            {treeViewData?.map((i: any, index: any) => (
                              i?.children?.length > 0 ? i?.children.map((data: any) => (
                                <div>
                                  {data.variableId === field.fieldIdName && <span>
                                    ({data.datatype.name}/{data.responseType.name})
                                  </span>}
                                </div>
                              )) :
                                <div>
                                  {
                                    i.variableId === field.fieldIdName && <span key={index}>
                                      ({i.datatype.name}/{i.responseType.name})
                                    </span>
                                  }
                                </div>
                            ))
                            }
                          </span>
                          {parseInt(params.id) <= 0 && <CancelIcon onClick={(e) => onDeleteEelement(e, index)} />}
                        </React.Fragment>
                      </li>
                    </div>
                  ))
                }
              </React.Fragment>
            }
          </ul>
        </div>
        <div>{(validations && validations.dependent) && <span className="text-danger">
          {validations.dependent}</span>}</div>
        {fieldDynamics?.dependentFields.length > 0 && <TargetVariables
          node={node} params={params}
          validations={validations}
          onSetValidations={onSetValidations} />}
      </div>
    </React.Fragment>
  )
}
export default DependentContainer