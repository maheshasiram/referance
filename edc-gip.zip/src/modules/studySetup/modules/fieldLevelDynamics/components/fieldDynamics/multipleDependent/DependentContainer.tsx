import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { Types } from "../../../reducers/types";
import CancelIcon from '@mui/icons-material/Cancel';
import { validateSingleTargetFLD } from "../../../helpers/Validation";
import CustomToolTip from "../../../../../../../components/CustomToolTip";
function DependentContainer(props: any) {
    const { fieldDynamics, treeViewData } = useSelector((state: any) => state.dynamics);
    const { currentStudy } = useSelector((state: any) => state.application);
    const { node, params, validations, onSetValidations } = props
    const dispatch = useDispatch();

    const onDragHoverEelement = (e: any) => {
        e.preventDefault();
    }

    const onDeleteDependent = (e: any, index: any) => {
        const payload = { ...{}, ...fieldDynamics }
        payload.dependentFields.splice(index, 1);
        onSetValidations({ dependent: "", target: "", message: "" })
        dispatch({ type: Types.CREATE_FIELD_LEVEL, payload: payload })
    }
    const onDropDependentVariable = () => {
        console.log("node.........", node)
        const payload = { ...{}, ...fieldDynamics }
        const errors: any = Object.keys(node).length > 0 && validateSingleTargetFLD(payload, node, 'dependent')
        if ((parseInt(params.id) <= 0) || (parseInt(params.id) > 0 && payload.dependentFields.length <= 0)) {
            if (Object.keys(node).length > 0 && errors === false) {
                const _dependentFields = {
                    id: node.id,
                    fieldId: node.id,
                    fieldIdName: node.label,
                    groupId: node.groupId,
                    groupName: null,
                    responseOptions: node.responseOptions.map((option: any) => (
                        {
                            id: null,
                            responseOptionId: option.id,
                            responseOption: option.response,
                            message: currentStudy.fldMessage,
                            selected: false,
                            targetFields: []
                        }
                    )),
                    availableResponseOptions: node.responseOptions
                }
                payload.dependentFields.push(_dependentFields)
                dispatch({ type: Types.CREATE_FIELD_LEVEL, payload: payload })
                onSetValidations({ dependent: "" })
            } else {
                onSetValidations(errors)
            }

        }
    }
    const onResponseChangeHandler = (e: any, index: number) => {
        const payload = { ...{}, ...fieldDynamics }
        const options = e.target.options;
        let _targetFields: any = [];
        const unselectedValue: any = [];
        const selectedValue: any = [];
        for (let i = 0, l = options.length; i < l; i++) {
            if (options[i].selected) {
                selectedValue.push(options[i].value);
            } else if (!options[i].selected) {
                unselectedValue.push(options[i].value);
            }
        }
        fieldDynamics.dependentFields.map((item: any) => {
            item.responseOptions.map((i: any) => {
                if (i && i.targetFields.length > 0 && (_targetFields.length <= 0)) {
                    _targetFields = i.targetFields
                }
                return null
            })
            return null
        })
        selectedValue.map((id: any) => {
            console.log(typeof (id))
            const _index = payload.dependentFields[index].responseOptions.findIndex((ele: any) => ele.responseOptionId === parseInt(id))
            payload.dependentFields[index].responseOptions[_index].selected = true
            payload.dependentFields[index].responseOptions[_index].targetFields = _targetFields
            return null
        })
        unselectedValue.map((id: any) => {
            const _index = payload.dependentFields[index].responseOptions.findIndex((ele: any) => ele.responseOptionId === parseInt(id))
            payload.dependentFields[index].responseOptions[_index].selected = false
            payload.dependentFields[index].responseOptions[_index].targetFields = []
            return null
        })
        dispatch({ type: Types.CREATE_FIELD_LEVEL, payload: payload })
    }

    // console.log("----60", node)
    return (
        <React.Fragment>
            <div className="logic-wrapper" id="dependentContainer">
                <div className="d-flex">
                <label className="fld-label">Dependent Variable <span style={{color:'red',fontSize:'12px'}}>*</span>
                    <div>{(validations && validations.dependent) && <span className="text-danger">
                        {validations.dependent}</span>}</div></label>
                </div>
              
                {(fieldDynamics?.dependentFields.length > 0) && <div className="logic-container select d-flex flex-wrap"
                // onDragOver={onDragHoverEelement}
                // onDrop={onDropDependentVariable}
                >
                    {/* {(fieldDynamics?.dependentFields.length <= 0) &&
                        <span className="txt-default">Drag  <i>Dependent</i> (Select | Radio | Checkboxes options) Variable here</span>} */}
                    {<React.Fragment>
                        {
                            fieldDynamics?.dependentFields.map((field: any, index: number) => {
                                return (
                                    <React.Fragment key={index}>
                                        <div className="select-element w-30" key={index}>
                                            <span className="d-flex">
                                                {field.fieldIdName}
                                                {
                                                    treeViewData?.map((data: any, index: any) => {
                                                        if (data.variableId === field.fieldIdName) {
                                                            return <span key={index}>
                                                                 {/* <CustomToolTip title={data.variableText ? data.variableText : data.groupName} key={data.variableId}></CustomToolTip> */}
                                                                ({data.datatype.name}/{data.responseType.name})
                                                            </span>
                                                        }
                                                        return null
                                                    })
                                                }
                                            </span>
                                            <div className="elements-container">
                                                <select multiple onChange={(e: any) => { onResponseChangeHandler(e, index) }} >
                                                    {
                                                        field.responseOptions.map((res: any) => (
                                                            <option selected={res.selected} value={res.responseOptionId} key={res.responseOptionId}>{res.responseOption}</option>
                                                        ))
                                                    }
                                                </select>
                                                {parseInt(params.id) <= 0 && <CancelIcon onClick={(e) => onDeleteDependent(e, index)} />}
                                            </div>
                                        </div>
                                    </React.Fragment>
                                )
                            })
                        }
                    </React.Fragment>}

                </div>}
                {parseInt(params.id) <= 0 && <div className="logic-container select mt-3"
                    onDragOver={onDragHoverEelement}
                    onDrop={onDropDependentVariable}>
                    <span className="txt-default">Drag  <i>Dependent</i> (Select | Radio | Checkboxes options) Variable here and select atleast one option</span>
                </div>}
                {/* <div>{(validations && validations.dependent) && <span className="text-danger">
                    {validations.dependent}</span>}</div> */}
            </div>
        </React.Fragment>
    )

}
export default DependentContainer