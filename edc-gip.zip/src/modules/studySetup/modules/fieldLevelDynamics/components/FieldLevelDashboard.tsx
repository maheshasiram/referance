import React, { useRef } from "react";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { useSelector, useDispatch } from "react-redux";
import '../styles/styles.scss'
import DropdownComponent from "../../../../../components/DropdownComponent";
import { NavLink } from "react-router-dom";
import EditIcon from '@mui/icons-material/Edit';
import ReplayIcon from '@mui/icons-material/Replay';
import DeleteIcon from '@mui/icons-material/Delete';
import { Confirm, toastAlert } from "../../../../../actions/actions";
import {
  fetchAllFieldForms, delteFieldDynamics,
  restoreFieldDynamics, getAllFieldDyanamics
} from "../actions/actions";
import { fetchPayload } from "../constants/models";
import { FilterContainer } from "../../../../../common/styleComponents/FilterBy";
import { Types } from "../reducers/types";
import CustomToolTip from "../../../../../components/CustomToolTip";
import PageCount from "../../../../../common/pagecount/PageCount";
import CreateMessage from "./fieldDynamics/CreateMessage"
import SelectField from "../../../../../common/selectField/SelectField";
const FieldLevelDashboard = () => {
  const { fieldDynamicsData, dyanmicFroms } = useSelector((state: any) => state.dynamics)
  const { currentStudy } = useSelector((state: any) => state.application);
  const [dynamicPayload, setDynamicPayload] = React.useState<any>(fetchPayload);
  const [lazyParams, setLazyParams] = React.useState<any>({
    first: 0,
    rows: 10,
    page: 1
  });
  const dispatch = useDispatch();
  const loaded = useRef(false);
  const [value, setValue]: any = React.useState('');

  React.useEffect(() => {
    if (!loaded.current) {
      dispatch(fetchAllFieldForms(currentStudy.id))
      setDynamicPayload({ ...dynamicPayload, formId: null, studyId: currentStudy.id });
      dispatch(getAllFieldDyanamics({ ...dynamicPayload, formId: null, studyId: currentStudy.id }))
      loaded.current = true;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])
  const onEditField = (rowData: any) => {
    console.log(rowData, "edit")
    dispatch({ type: Types.ACTION_TYPE, payload: 'edit' })
    // props.setBtnDisabled(true);
  }

  const onDreleteAndResote = (param: any, rowData: any) => {
    console.log('54...', rowData)
    dispatch(Confirm({
      status: 0,
      message: param === 0 ? "Are you sure want to delete?" : "Are you sure want to restore?",
      onOk: () => {
        if (param === 0) {
          dispatch(delteFieldDynamics(rowData.id, (response: any) => {
            dispatch(toastAlert({
              status: 1,
              message: `${rowData.targetFields} ${response.data}`,
              open: true
            }))
            dispatch(getAllFieldDyanamics({ ...dynamicPayload }));
          }))
        } else {
          dispatch(restoreFieldDynamics(rowData.id, (response: any) => {
            if (response.errorCode) {
              dispatch(toastAlert({
                status: 2,
                message: response.errorMessage,
                open: true
              }))
            } else {
              dispatch(toastAlert({
                status: 1,
                message: `${rowData.targetFields} ${response}`,
                open: true
              }))

            }
            dispatch(getAllFieldDyanamics({ ...dynamicPayload, }))
          }))
        }
      }
    }))
  }

  const actionBodyTemplate = (rowData: any) => {
    return (
      <React.Fragment>
        {rowData.status ? (
          <div className="actions d-flex">
            <NavLink to={`../dynamics/${rowData.id}`}>
              <CustomToolTip title='Edit Field Level Dynamic'><EditIcon onClick={() => onEditField(rowData)} sx={{ fontSize: 14, opacity: .8, cursor: "pointer", color: "grey" }} /></CustomToolTip>
            </NavLink>
            <span>|</span>
            <CustomToolTip title='Delete Field Level Dynamic'><DeleteIcon sx={{ fontSize: 14, opacity: .8 }} className='text-danger'
              onClick={() => onDreleteAndResote(0, rowData)} /></CustomToolTip>
          </div>
        )
          : <CustomToolTip title='Restore Field Level Dynamic'><ReplayIcon className="restoreDynamics"
            onClick={() => onDreleteAndResote(1, rowData)} /></CustomToolTip>
        }
      </React.Fragment>
    )
  }

  const onChangeHandler = (value: any) => {
    setValue(value);
    dispatch(getAllFieldDyanamics({ ...fetchPayload, studyId: currentStudy.id, formId: (value?.value ? value?.value : null) }))
    setDynamicPayload({ ...fetchPayload, studyId: currentStudy.id, formId: (value?.value ? value?.value : null) });
  }

  console.log("115...", value)

  const onChangePageCount = (e: any) => {
    setDynamicPayload({ ...fetchPayload, limit: parseInt(e.target.value), studyId: currentStudy.id, formId: (value?.value ? value?.value : null) });
    dispatch(getAllFieldDyanamics({ ...dynamicPayload, limit: parseInt(e.target.value), studyId: currentStudy.id, formId: (value?.value ? value?.value : null) }))
  }

  const onPage = (event: any) => {
    setLazyParams(event);
    setDynamicPayload({ ...fetchPayload, offset: event.first, limit: dynamicPayload.limit, studyId: currentStudy.id, formId: (value?.value ? value?.value : null) });
    dispatch({ type: Types.FETCH_ALL_TABLE_DATA, payload: { ...fieldDynamicsData, offset: event.first } })
    dispatch(getAllFieldDyanamics({ ...dynamicPayload, formId: null, offset: event.first, studyId: currentStudy.id }))
  }

  const onCreateFLD = () => {
    console.log("121..", lazyParams)
    dispatch({ type: Types.ACTION_TYPE, payload: 'add' })
    // dispatch({ type: Types.CREATE_FIELD_LEVEL, payload: { ...fieldDynamics, message: currentStudy.fldMessage } })
  }
  const targetVariableBody = (rowData: any) => {
    // return <p>{rowData.targetFields ? rowData.targetFields : rowData.targetGroups}</p>
    return <div className="d-flex">
      {rowData.targetFields && <p>{rowData.targetFields}</p>}
      {rowData.targetGroups && <p>{(rowData.targetGroups && rowData.targetFields) && `,`}{rowData.targetGroups}</p>}
    </div>
  }
  const options = (dyanmicFroms: any) => {
    let _options: any = []
    dyanmicFroms.map((item: any) => {
      _options.push({ label: item.formName, value: item.id })

    })
    return _options
  }


  return (
    <React.Fragment>
      <div className=" controls-container">
        <div className="d-flex justify-content-between  mb-2 ">
          <div className=" d-inline-flex ">
            <PageCount onChange={(e: any) => onChangePageCount(e)} />
          </div>
          <div className=" d-inline-flex ">
            <CreateMessage />
            <NavLink className="btn-eprimary ms-2" onClick={onCreateFLD}
              to={`../dynamics/0`}>
              Create Field Level Dynamics</NavLink>
            <div className=" d-flex align-items-center ms-2" style={{ gap: 5 }}>
              {/* <FilterContainer>
                <DropdownComponent
                  label={`Filter By :`}
                  data={dyanmicFroms}
                  defaultValue={'Select your Form'}
                  onChangeHandler={onChangeHandler}
                  isClear={true}
                  values={0}
                  className='w-150'
                />
              </FilterContainer> */}
              <label htmlFor="filterBy" className="py-2">Filter By :</label>
              <SelectField
                value={value}
                options={options(dyanmicFroms)}
                isClearable={true}
                // options={dyanmicFroms}
                defaultValue={"Select Your Form"}
                placeholder={"Select Your Form"}
                // className="fld-selectField"
                onChange={(e: any) => onChangeHandler(e)}
              />
            </div>
          </div>
        </div>
        <div>
          <DataTable value={fieldDynamicsData.fldDetails}
            // paginator 
            lazy
            scrollable
            paginator={(fieldDynamicsData && fieldDynamicsData.totalRecords && fieldDynamicsData.totalRecords > dynamicPayload.limit) ? true : false}
            first={dynamicPayload && dynamicPayload.offset} rows={fieldDynamicsData.limit}
            totalRecords={fieldDynamicsData.totalRecords} onPage={onPage}
            responsiveLayout="scroll">
            <Column body={targetVariableBody} header="Target variable" ></Column>
            <Column field="dependentField" header="Dependent variable"></Column>
            <Column body={actionBodyTemplate} header="Actions"></Column>
          </DataTable>
        </div>
      </div>
    </React.Fragment>
  )
};
export default FieldLevelDashboard;