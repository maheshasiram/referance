import React from 'react';
import FieldLevelDashboard from './components/FieldLevelDashboard';

const FieldLevelDynamics =()=>{
    return(
        <React.Fragment>
            <div>
                <FieldLevelDashboard />
            </div>
        </React.Fragment>
    )
};
export default FieldLevelDynamics;