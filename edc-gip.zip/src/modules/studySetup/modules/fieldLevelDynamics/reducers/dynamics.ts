import { Types } from "./types";
import { fieldDynamicModal } from "../constants/models";

const initialStates = {
    dyanmicFroms: [],
    inditialData: fieldDynamicModal,
    fieldDynamicsData: {
        fldDetails: []
    },
    responseOptions: [],
    treeViewData: [],
    nodeElement: null,
    targetElement: null,
    dependentElement: null,
    forms: [],
    fieldDynamics: fieldDynamicModal,
    fieldData: [],
    deleteItem: null,
    restoreItem: null,
    actionType: 'add',
    dependentType: null
};

export const dynamics = (state = initialStates, action: { type: any, payload: any }) => {

    switch (action.type) {
        case Types.SAVE_DEPENDENT_RES_OPTIONS:
            return { ...state, responseOptions: action.payload }
        case Types.FETCH_ALL_FIELD_FORM:
            return { ...state, dyanmicFroms: action.payload }
        case Types.TREE_VIEW_DATA:
            return { ...state, treeViewData: action.payload }
        case Types.SAVE_NODE_VALUE:
            return { ...state, nodeElement: action.payload };
        case Types.TARGET_DROPPED_VAR:
            return { ...state, targetElement: action.payload }
        case Types.DEPENDENT_DROPPED_VAR:
            return { ...state, dependentElement: action.payload }
        case Types.FORM_DETAILS_BY_STUDY_ID:
            return { ...state, forms: action.payload }
        case Types.CREATE_FIELD_LEVEL:
            console.log("...42 reducer", action.payload)
            return { ...state, fieldDynamics: action.payload }
        case Types.FORM_FIELD_BY_FORM_ID:
            return { ...state, fieldData: action.payload }
        case Types.DELETE_DATA_FROM_TABLE:
            return { ...state, deleteItem: action.payload }
        case Types.RESTORE_DATA_FROM_TABLE:
            return { ...state, restoreItem: action.payload }
        case Types.FETCH_ALL_TABLE_DATA:
            return { ...state, fieldDynamicsData: action.payload }
        case Types.ACTION_TYPE:
            console.log("...52", action.payload)
            return { ...state, actionType: action.payload }
        case Types.FLD_DEPENDENT_TYPE:
            return { ...state, dependentType: action.payload }
        default:
            return { ...state }
    }
}