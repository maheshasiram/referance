import { Loader } from "../../../../../actions/actions";
import { studySetup } from "../../../../../configs/enivornment/studySetup";
import { fetch } from "../../../../../constants/fetch";
import { Types } from "../reducers/types";
import _ from 'lodash'
import store from "../../../../../store/store";

export const saveFieldLevelDynamic: any  = (payload: any, callback: any) => {
  const url = `${studySetup.dynamics.save}`
  return (dispatch: any) => {
    dispatch(Loader(true))
    fetch({
      method: 'POST',
      url: url,
      data: payload
    })
      .then((response: any) => {
        callback(response.data);
        dispatch(Loader(false))
      })

  }
}

export const onUpdateFieldDynamics: any = (payload: any, callback: any) => {
  const _payload = { ...{}, ...payload }
  payload.dependentFields.map((item: any, index: number) => {
    item.responseOptions.map((subItem: any, subIndex: number) => {
      delete _payload.dependentFields[index].responseOptions[subIndex].selected
      return null
    })
    return null
  })
  console.log("26 action..", payload)

  return (dispatch: any) => {
    dispatch(Loader(true))
    fetch({
      method: 'POST',
      url: `${studySetup.dynamics.update}`,
      data: _payload
    })
      .then((response: any) => {
        callback(response.data);
        dispatch(Loader(false))
      })
  }
}

export const getFeildDynamics: any = (id: number, callback: any) => {
  return (dispatch: any) => {
    dispatch(Loader(true))
    fetch({
      method: 'GET',
      url: `${studySetup.dynamics.get}/${id}`,
    })
      .then((response: any) => {
        const _response = { ...{}, ...response.data }
        const currentStudy = store.getState().application.currentStudy
        response.data.dependentFields.map((item: any, index: number) => {
          item.availableResponseOptions.map((subItem: any) => {
            const _index = item.responseOptions.findIndex((resEle: any) => resEle.responseOptionId === subItem.id)
            console.log("..._index", _index)
            if (_index === -1) {
              _response.dependentFields[index].responseOptions.push({
                id: null,
                responseOptionId: subItem.id,
                responseOption: subItem.response,
                message: currentStudy.fldMessage,
                selected: false,
                targetFields: []
              })
            }
            return null
          })
          return null
        })
        _response.dependentFields.map((item: any, index: number) => {
          item.responseOptions.map((subItem: any, subIndex: number) => {
            if (subItem.targetFields?.length > 0) {
              _response.dependentFields[index].responseOptions[subIndex].selected = true
            } else {
              _response.dependentFields[index].responseOptions[subIndex].selected = false
              _response.dependentFields[index].responseOptions[subIndex].targetFields = []
            }
            return null
          })
          return null
        })
        console.log("edit fld", _response)
        callback(_response);
        dispatch(Loader(false))
      })
  }
}

// fetch all form which has fld 
export const fetchAllFieldForms: any = (payload: any) => {
  const url = `${studySetup.dynamics.fetchAllFieldForms}${payload}`
  return (dispatch: any) => {
    dispatch(Loader(true))
    fetch({
      method: 'GET',
      url: url,
    })
      .then((response: any) => {
        const data: any = response.data
        dispatch({ type: Types.FETCH_ALL_FIELD_FORM, payload: data })
        dispatch(Loader(false));
      })

  }
}

export const fetchTreeViewData: any = (payload: any) => {
  const url = `${studySetup.dynamics.treeView}/${payload}`
  return (dispatch: any) => {
    dispatch(Loader(true))
    fetch({
      method: 'GET',
      url: url,
    })
      .then((response: any) => {
        const data: any = response.data.data
        data && data.map((item: any, index: any) => {
          data[index].key = index
          if (item.children && item.children.length > 0) {
            item.children.map((child: any, ci: any) => {
              if (data[index].children[ci].children) {
                return data[index].children[ci].key = `${index}-${ci}`;
              }
              return null
            });
          }
          return null
        })
        dispatch({ type: Types.TREE_VIEW_DATA, payload: data[0].children })
        dispatch(Loader(false));
      })

  }
}

// get forms details inside create fld
export const getFormsByStudyId: any = (payload: any, callback: any) => {
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: `${studySetup.dynamics.fetchAllFormsOptionalVariables}?studyId=${payload}`,
      data: ''
    })
      .then((response: any) => {
        const _response = _.cloneDeep({ ...response, data: [] })
        response.data.map((item: any) => {
          if (item && item.formFields && item.formFields.length > 0) {
            _response.data.push(item)
          }
          return null
        })
        console.log("forms response,,....", _response)

        dispatch({ type: Types.FORM_DETAILS_BY_STUDY_ID, payload: response.data });
        if (callback) { callback(response.data) }
        dispatch(Loader(false));
      })
  }
}

export const getFormFieldByFormId: any = (payload: string, callback: any) => {
  const url = `${studySetup.forms.getFormsDetailsId}/${payload}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        console.log('responsee.......108', response)
        dispatch({ type: Types.FORM_FIELD_BY_FORM_ID, payload: response.data });
        if (callback) { callback(response) }
        dispatch(Loader(false));
      })
  }
}


// fetch table table data
export const getAllFieldDyanamics: any = (payload: any) => {
  return function (dispatch: any) {
    dispatch(Loader(true))
    fetch({
      method: 'POST',
      url: studySetup.dynamics.fetchAllByCriteria,
      data: payload
    })
      .then((response: any) => {
        dispatch({ type: Types.FETCH_ALL_TABLE_DATA, payload: response.data })
        dispatch(Loader(false))
      })
      .catch((error) => {
        console.log("error....", error)
      })
  }
}

export const delteFieldDynamics: any = (payload: any, callback: any) => {
  const url = `${studySetup.dynamics.deleteFormData}/${payload}`;
  return (dispatch: any) => {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
    })
      .then((response: any) => {
        if (callback) {
          callback(response);
        }
        dispatch(Loader(false));
      })
  }
}

export const restoreFieldDynamics: any = (payload: any, callback: any) => {
  const url = `${studySetup.dynamics.restoreFormData}/${payload}`;
  return (dispatch: any) => {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url,
    })
      .then((response: any) => {
        if (callback) {
          callback(response.data)
        }
        dispatch(Loader(false));
      })
  }
}
