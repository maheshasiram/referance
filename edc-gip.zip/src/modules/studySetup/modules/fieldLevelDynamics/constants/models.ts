import { FieldDynamic, Dyanamics } from "./dataType";

export const fieldDynamicModal: FieldDynamic = {
    // id: 0,
    form: {
        id: 0,
        formName: '',
        exportName: '',
        ordinal: 0,
        status: false,
        noOfFields: [],
        studyId: 0
    },
    dependentFields: [],
    visits: [],
    dependentType: {}
}

export const fetchPayload: Dyanamics = {
    "limit": 10,
    "offset": 0,
    "studyId": 0,
    "formId": null,
    "formNameCriteria": ""
}