

export type Target = {
    "id": number,
    "fieldId": number,
    "groupId": number,
    "variableId": string,
    "variableText": string
}
export type Opton = {
    "id": number,
    "responseOptionId": number,
    "responseOption": string
}
export type Dependent = {
    "id": number,
    "fieldId": number,
    "fieldIdName": string,
    "responseOptions": Opton[],
    "priority": number,
    "condition": string
}
export type Form = {
    "id": number,
    "formName": string,
    "exportName": string,
    "ordinal": number,
    "status": boolean,
    "noOfFields": [],
    "studyId": number
}

// type dependentFieldsType = [{
//     'id': any
//     "fieldId"?: number
//     "fieldIdName"?: string
//     "responseOptions"?: []
// }]


export type FieldDynamic = {
    // id?: any
    form?: Form
    dependentFields?: []
    msg?: string
    visits?: [],
    dependentType?: any
    // targetFields?: Target[],
    // dependentFields?: Dependent[]
    // message?: string,
    // formId?: Form
}

export type Dyanamics = {
    limit?: number,
    offset?: number,
    studyId?: number,
    formId?: any,
    formNameCriteria?: any
}