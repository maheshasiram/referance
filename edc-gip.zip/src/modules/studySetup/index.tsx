import * as React from 'react';
import KababMenu from './helpers/KababMenu';
import StudySetupRoutes from './routes';
import './styles.scss'
import { NavLink,useParams } from 'react-router-dom';
import { ROUTE_PATHS } from './constants/paths';
import { privateRoutes } from '../../constants/lazyRoutes';

function StudySetupModule() {
  const params = useParams()
  const param: any = params["*"];
  const newParam1 = param.replace('/', '');
  const newParam = newParam1.replace(/[0-9]/g, '')

  return (
    <React.Fragment>
      <div className='container' >
        <div className='d-flex sm-container'>
          <div className='page-header'>
            <h2>Study Setup</h2>
            <h6>{newParam === 'EditForm' ? "Create / Update Data entry Form" : newParam === 'createFLD' ? 'Create Field Level Dynamics' : newParam === 'dynamics' ? 'Field Level Dynamics' : newParam}</h6>
          </div>
          <div className=" w-50 d-block text-end s-navItems">
            <div className='d-flex justify-content-end my-3'>
              <div className='d-flex'>
                <ul className='ss-nav'>
                  {ROUTE_PATHS.map((item, index) => (
                    <React.Fragment key={index}>
                      {(index <= 4) && <li><NavLink to={item.path} className={({ isActive }) => {
                        return isActive ? 'active' : undefined;
                      }}>{item.label}</NavLink></li>}
                    </React.Fragment>
                  ))
                  }
                </ul>
              </div>
              <div className="justify-content-end "><KababMenu /></div>
            </div>
          </div>
        </div>
        {/* <StudySetupRoutes /> */}
        <div>
          {
            privateRoutes && privateRoutes.map((Item: any,index: any) => {
              if (Item.name === "Study SetUp") {
                // return <Routes>
                //   {Item.children && Item.children.length > 0 && Item.children.map((child: any) => {
                //     return <Route path={child.pathName} element={<child.Component />}></Route>
                //   })}
                // </Routes>
                return <StudySetupRoutes key={index} />
              }
              return null;
            })
          }
        </div>
      </div>
    </React.Fragment>
  )
}

export default StudySetupModule;