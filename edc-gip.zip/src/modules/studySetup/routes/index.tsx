import React from 'react';
import { Route, Routes, } from 'react-router-dom';
import Layout from '../modules/forms/components/formBuilder/Layout';
import FormsModule from '../modules/forms';
import SitesModule from '../modules/sites';
import StudyModule from '../modules/study';
import VisitsModule from '../modules/visits';
import FieldLevelDynamics from '../modules/fieldLevelDynamics';
import Derivations from '../modules/derivations';
import CreateFiledDynamics from '../modules/fieldLevelDynamics/components/fieldDynamics/CreateFiledDynamics';
import RolesandPermissions from '../modules/rolesandPermissions';
import StudyMigration from '../modules/studyMigration';
import CreateDerivation from '../modules/derivations/components/createDerivation/CreateDerivation';
import CreateRules from '../modules/rules/components/createRules/CreateRules';
import CreateRolesandPermissions from '../modules/rolesandPermissions/components/CreateRolesandPermissions';
import Labs from '../modules/labs';
import RulesModule from '../modules/rules';
import AuditLogs from '../modules/auditLogs';
import LabRange from '../modules/labs/components/labRangeBuilder/LabRange';
import Category from '../modules/labs/components/labBuilder/labCategory/Category';
import Test from '../modules/labs/components/labBuilder/labTest/Test';
import Unit from '../modules/labs/components/labBuilder/labUnit/Unit';
import SelectFormVariables from '../modules/visits/components/SelectFormVariables';

function StudySetupRoutes() {

  return (
    <Routes>
      <Route path="study" element={<StudyModule />} />
      <Route path="visits" element={<VisitsModule />} />
      <Route path='/visits/assignFormsToVisit/:id' element={<SelectFormVariables />} />
      <Route path="sites" element={<SitesModule />} />
      <Route path="forms" element={<FormsModule />} />
      <Route path="/EditForm/:id" element={<Layout />} />
      <Route path="dynamics" element={<FieldLevelDynamics />} />
      <Route path='/dynamics/:id' element={<CreateFiledDynamics />} />
      <Route path="/roles" element={<RolesandPermissions />} />
      <Route path="/roles/:id" element={<CreateRolesandPermissions />} />
      <Route path="studyMigration" element={<StudyMigration />} />
      <Route path="rules" element={<RulesModule />} />
      <Route path="createRules/:id" element={<CreateRules />}></Route>
      <Route path="/derivation/*" element={<Derivations />} />
      <Route path="/derivation/:id" element={<CreateDerivation />} />
      <Route path='/labs/' element={<Labs />} />
      <Route path='/auditLogs' element={<AuditLogs />} />
      <Route path='/labCategory/:id' element={<Category />} />
      <Route path='/labTest/:id' element={<Test />} />
      <Route path='/labUnit/:id' element={<Unit />} />
      <Route path='/labRange/:id' element={<LabRange />} />
    </Routes>
  )
}
export default StudySetupRoutes
