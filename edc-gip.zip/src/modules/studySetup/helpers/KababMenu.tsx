import * as React from 'react';
import IconButton from '@mui/material/IconButton';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import { useNavigate } from 'react-router-dom';
import { ROUTE_PATHS } from '../constants/paths';
import { Popover } from '@mui/material';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';

function KababMenu() {
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const navigate = useNavigate();
  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = (e: any, option: any) => {
    setAnchorEl(null);
    if (ROUTE_PATHS.indexOf(option) !== -1) {
      navigate(`/study/${option.path}`)
    }
  };

  return (
    <div className='kabab-menu'>
      <IconButton
        aria-label="more"
        id="long-button"
        aria-controls={open ? 'long-menu' : undefined}
        aria-expanded={open ? 'true' : undefined}
        aria-haspopup="true"
        onClick={handleClick}
      >
        <MoreVertIcon />
      </IconButton>
      <Popover
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
      >
        {ROUTE_PATHS.map((option: any, index: any) => (
          <nav aria-label="secondary mailbox folders" key={index} >
            <List className='kabab-menu-list'>
              {
                index >= 5 && <ListItem disablePadding className='kabab-menu-listItem'>
                  <ListItemButton className='kabab-menu-ItemBtn'
                    onClick={(e: any) => handleClose(e, option)}>
                    <ListItemText primary={option.label} />
                  </ListItemButton>
                </ListItem>
              }

            </List>
          </nav>
        ))}
      </Popover>
    </div>
  );
}
export default KababMenu;
