
export const ROUTE_PATHS = [
  { label: 'Study', path: "study" },
  { label: "Sites", path: "sites" },
  { label: "Visits", path: 'visits' },
  { label: "Forms", path: "forms" },
  { label: "Field Level Dynamics", path: "dynamics" },
  { label: "Derivations", path: "derivation" },
  { label: "Rules", path: "rules" },
  { label: 'Labs', path: 'labs' },
  // { label: "Labranges", path: "labranges" },
  { label: "Roles & Permissions", path: "roles" },
  { label: "Study Migration", path: "studyMigration" },
  { label: "Audit Logs", path: 'auditLogs' }
];