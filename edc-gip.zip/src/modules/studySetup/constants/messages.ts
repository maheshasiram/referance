export const messages = {
    study: {
    },
    sites: {
        delete: 'Are you sure do you want to delete this site?',
        restore: 'Are you sure do you want to restore this site?',
        deleteSuccess: 'Site deleted successfully',
        restoreSuccess: 'Site restored successfully',
        addSiteSuccess: 'Site added successfully',
        updateSiteSuccess: 'Site updated successfully'
    },
    visits: {
        delete: 'Are you sure do you want to delete this visit?',
        restore: 'Are you sure do you want to restore this visit?',

    },
    forms: {
        addVariable: 'Variable added successfully. Do you want to add one more variable?',
        updateVariable: 'The respected variable, field level dynamics, Derivations and rules are updated',
        noScripts: 'No scripts are available to display. click on add default values to group button to add scripts.',
        group: {
            success: 'Group added successfully',
            update: 'Group added successfully'
        }
    },
    derivation: {
        deleteDerivation: "Do you want to delete this derivation ?",
        restoreDerivation: "Do you want to restore this derivation ?"
    },
    rolesandpermissions: {
        deleteRole: "Do you want to delete this role ?",
        deletePrivilege: "Do you want to delete this privilege ?",
        restoreRole: "Do you want to restore this role ?"
    },
    labs: {
        deleteGroup: 'Do You want to delete this group ?',
        restoreGroup: "Do you want to restore this group ?",
        deleteUnit: 'Do you want to delete this unit ?',
        restoreUnit: 'Do you want to restore this unit ?',
        deleteTestData: 'Do you want to delete this test ?',
        restoreTestData: "Do you want to restore this test ?",
        deleteLab: 'Do you want to delete this lab ?',
        restoreLab: 'Do you want to restore this lab ?',
        deleteLabRange:'Do you want to delete this Lab Range ?',
        restoreLabRange:'Do you want to restore this Lab Range ?'
    }
}