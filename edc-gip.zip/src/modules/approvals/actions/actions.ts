
import { fetch } from "../../../constants/fetch"
import { Loader } from "../../../actions/actions"
import { Types } from "../reducer/Types"
import { studySetup } from "../../../configs/enivornment/studySetup"

export const fetchMonitorData: any = (payload: any, type: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: `${studySetup.approvals.bulkMonitor}?action=${payload}`,
        }).then((response: any) => {
            const data: any = response?.data?.data
            data?.map((item: any, index: any) => {
                data[index].key = index
                if (item.children && item.children.length > 0) {
                    item.children?.map((child0: any, ci0: any) => {
                        if (data[index].children[ci0].children) {
                            data[index].children[ci0].key = `${index}-${ci0}`;
                            child0.children.map((child1: any, ci1: any) => {
                                if (data[index].children[ci0].children[ci1]) {
                                    data[index].children[ci0].children[ci1].key = `${index}-${ci0}-${ci1}`;
                                    child1.children.map((child2: any, ci2: any) => {
                                        if (data[index].children[ci0].children[ci1].children[ci2]) {
                                            data[index].children[ci0].children[ci1].children[ci2].key = `${index}-${ci0}-${ci1}-${ci2}`;
                                            child2.children.map((child3: any, ci3: any) => {
                                                if (data[index].children[ci0].children[ci1].children[ci2].children[ci3]) {
                                                    data[index].children[ci0].children[ci1].children[ci2].children[ci3].key = `${index}-${ci0}-${ci1}-${ci2}-${ci3}`;
                                                }
                                            })
                                        }
                                    })
                                }
                            })
                        }
                        return null
                    });
                }
            })
            dispatch({ type: Types.FETCH_MONITOR_TREE_DATA, payload: data })
            dispatch(Loader(false));
        })
    }
}

export const submitBulkData: any = (payload: any, callback: any) => {
    return function (dispatch: any) {
        fetch({
            method: 'GET',
            url: `${studySetup.approvals.bulkMonitor}?action=${payload.action}&userName=${payload.userName}&password=${payload.password}&subjectFormIds=${payload.subjectFormIds}`,
        }).then((response: any) => {
            if (callback) {
                callback(response.data)
            }

        })
            .catch((error: any) => console.log("...error", error))
    }
}


export const fetchReviewData: any = (payload: any, type: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: `${studySetup.approvals.bulkReview}?action=${payload}`,
        })
            .then((response: any) => {
                const data: any = response?.data?.data
                data?.map((item: any, index: any) => {
                    data[index].key = index
                    if (item.children && item.children.length > 0) {
                        item.children?.map((child0: any, ci0: any) => {
                            if (data[index].children[ci0].children) {
                                data[index].children[ci0].key = `${index}-${ci0}`;
                                child0.children.map((child1: any, ci1: any) => {
                                    if (data[index].children[ci0].children[ci1]) {
                                        data[index].children[ci0].children[ci1].key = `${index}-${ci0}-${ci1}`;
                                        child1.children.map((child2: any, ci2: any) => {
                                            if (data[index].children[ci0].children[ci1].children[ci2]) {
                                                data[index].children[ci0].children[ci1].children[ci2].key = `${index}-${ci0}-${ci1}-${ci2}`;
                                                child2.children.map((child3: any, ci3: any) => {
                                                    if (data[index].children[ci0].children[ci1].children[ci2].children[ci3]) {
                                                        data[index].children[ci0].children[ci1].children[ci2].children[ci3].key = `${index}-${ci0}-${ci1}-${ci2}-${ci3}`;
                                                    }
                                                })
                                            }
                                        })
                                    }
                                })
                            }
                            return null
                        });
                    }
                    return null
                })
                dispatch({ type: Types.FETCH_REVIEW_TREE_DATA, payload: data })
                dispatch(Loader(false));
            })
    }
}





export const fetchSignData: any = (payload: any, type: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: `${studySetup.approvals.bulkSign}?action=${payload}`,
        })
            .then((response: any) => {
                const data: any = response?.data?.data
                data?.map((item: any, index: any) => {
                    data[index].key = index
                    if (item.children && item.children.length > 0) {
                        item.children?.map((child0: any, ci0: any) => {
                            if (data[index].children[ci0].children) {
                                data[index].children[ci0].key = `${index}-${ci0}`;
                                child0.children.map((child1: any, ci1: any) => {
                                    if (data[index].children[ci0].children[ci1]) {
                                        data[index].children[ci0].children[ci1].key = `${index}-${ci0}-${ci1}`;
                                        child1.children.map((child2: any, ci2: any) => {
                                            if (data[index].children[ci0].children[ci1].children[ci2]) {
                                                data[index].children[ci0].children[ci1].children[ci2].key = `${index}-${ci0}-${ci1}-${ci2}`;
                                                child2.children.map((child3: any, ci3: any) => {
                                                    if (data[index].children[ci0].children[ci1].children[ci2].children[ci3]) {
                                                        data[index].children[ci0].children[ci1].children[ci2].children[ci3].key = `${index}-${ci0}-${ci1}-${ci2}-${ci3}`;
                                                    }
                                                })
                                            }
                                        })
                                    }
                                })
                            }
                            return null
                        });
                    }
                    return null
                })
                dispatch({ type: Types.FETCH_SIGN_TREE_DATA, payload: data })
                dispatch(Loader(false));
            })
    }
}