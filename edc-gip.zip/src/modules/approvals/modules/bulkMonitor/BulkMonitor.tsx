import React from 'react'
import * as Yup from 'yup';
import { useDispatch, useSelector } from 'react-redux';
import { fetchMonitorData } from '../../actions/actions';
import BulkTreeView from '../../helpers/BulkTreeView';
import UserLogin from '../../helpers/UserLogin';
import '../../styles/Styles.scss'
import { Types } from '../../reducer/Types';
import _ from 'lodash';

function BulkMonitor() {
  const loaded = React.useRef(false);
  const dispatch = useDispatch()
  const { bulkData, selectedFormData, submitData } = useSelector((state: any) => state.approvals)
  const [monitor, setMonitor] = React.useState("getMonitorData")

  const [title, setTitle] = React.useState<any>(null);
  const [actionType, setActionType] = React.useState<any>(null);
  const [open, setOpen] = React.useState(false)

  React.useEffect(() => {
    if (!loaded.current) {
      let type = 'getMonitorData'
      dispatch(fetchMonitorData(type));
      loaded.current = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])


  const onSubmitBulkMonitor = (e: any) => {
    setTitle('Bulk Monitor')
    setActionType('Bulk Monitor')
    let _paylod = _.cloneDeep(submitData);
    _paylod.action = 'bulkMonitor'
    _paylod.subjectFormIds = selectedFormData.toString()
    dispatch({ type: Types.SUBMIT_DATA, payload: _paylod })
    setOpen(true);
  }

  const onSelectMonitor = (e: any) => {
    setMonitor(e.target.value)
    if (e.target.value === 'unMonitor') {
      let type = 'getunMonitorData'
      dispatch(fetchMonitorData(type))
    } else {
      let type = 'getMonitorData'
      dispatch(fetchMonitorData(type))
    }
  }

  const onSelcetNode = (node: any) => {
    let payload = _.cloneDeep(selectedFormData);
    if (node?.node?.subject_form_id && payload.indexOf(node.node.subject_form_id) === -1) {
      console.log("...55",)
      payload.push(node.node.subject_form_id)
      dispatch({ type: Types.SELECTED_FORM_DATA, payload: payload })
    }
    else {
      node.node.children.map((child: any) => {
        child.children.map((chi: any) => {
          chi.children.map((c: any) => {
            payload.push(c.subject_form_id)
            dispatch({ type: Types.SELECTED_FORM_DATA, payload: payload })
          })
        })
      })

    }
  }

  return (
    <div className='container'>
      <h2 >Bulk Monitor</h2>
      <div className='col-sm-2 my-2'>
        <select
          value={monitor}
          className="form-control form-select"
          onChange={onSelectMonitor}>
          <option value="getMonitorData">Monitor</option>
          <option value="getunMonitorData">UnMonitor</option>
        </select>
      </div>
      <div className='tree-card'>
        <BulkTreeView
          value={bulkData}
          selectionMode="checkbox"
          filter
          filterMode="lenient"
          filterPlaceholder="Filter"
          onSelcetNode={onSelcetNode}
        // selectionKeys={selectedKeys}
        // onSelectionChange={(e: any) => setSelectedKeys(e.value)}
        />
      </div>
      <div className="d-flex justify-content-end pt-3">
        <button type="submit" className=" btn btn-primary " onClick={(e: any) => onSubmitBulkMonitor(e)}>Submit</button>
      </div>
      <UserLogin open={open} setOpen={setOpen} title={title} actionType={actionType} submitData={submitData} />
    </div>
  )
}

export default BulkMonitor;
