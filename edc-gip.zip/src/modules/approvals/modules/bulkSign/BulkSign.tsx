import React from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { fetchSignData } from '../../actions/actions';
import BulkTreeView from '../../helpers/BulkTreeView';
import UserLogin from '../../helpers/UserLogin';
import '../../styles/Styles.scss'
import * as Yup from 'yup';

function BulkSign() {
  const dispatch = useDispatch()
  const loaded = React.useRef(false);
  const [selectedKeys, setSelectedKeys] = React.useState(null);
  const { bulkData } = useSelector((state: any) => state.approvals)
  const [sign, setSign] = React.useState("getSignedData")

  const [open, setOpen] = React.useState(false)
  const [title, setTitle] = React.useState<any>(null);
  const [actionType, setActionType] = React.useState<any>(null);

  React.useEffect(() => {
    if (!loaded.current) {
      let type = 'getSignedData'
      dispatch((fetchSignData(type)))
      loaded.current = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const onSubmitBulkSign = (e: any) => {
    setTitle('Bulk Sign')
    setActionType('Bulk Sign')
    setOpen(true);
  }

  const onSelectSign = (e: any) => {
    setSign(e.target.value)
    if (e.target.value === 'unSign') {
      let type = 'getunSignedData'
      dispatch(fetchSignData(type))
    } else {
      let type = 'getSignedData'
      dispatch(fetchSignData(type))
    }
  }

  return (
    <div className='container'>
      <h2>Bulk Sign</h2>
      <div className='col-sm-2 my-2'>
        <select className="form-control form-select"
          value={sign}
          onChange={onSelectSign}>
          <option value="getSignedData">Sign</option>
          <option value="getunSignedData">Un Sign</option>
        </select>
      </div>
      <div className='tree-card'>
        <BulkTreeView
          value={bulkData}
          selectionMode="checkbox"
          filter
          filterMode="lenient"
          filterPlaceholder="Filter"
          selectionKeys={selectedKeys}
          onSelectionChange={(e: any) => setSelectedKeys(e.value)}
        />
      </div>
      <div className="d-flex justify-content-end pt-3">
        <button type="submit" className=" btn btn-primary " onClick={(e: any) => onSubmitBulkSign(e)}>Submit</button>
      </div>
      <UserLogin open={open} setOpen={setOpen} title={title} actionType={actionType} />
    </div>
  )
}

export default BulkSign;
