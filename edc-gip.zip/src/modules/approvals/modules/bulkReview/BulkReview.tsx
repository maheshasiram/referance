import React from 'react'
import * as Yup from 'yup';
import { useDispatch, useSelector } from 'react-redux';
import BulkTreeView from '../../helpers/BulkTreeView';
import { fetchReviewData } from '../../actions/actions';
import UserLogin from '../../helpers/UserLogin';
import '../../styles/Styles.scss'
function BulkReview() {

  const dispatch = useDispatch()
  const loaded = React.useRef(false);
  const [selectedKeys, setSelectedKeys] = React.useState(null);
  const { bulkData, userDetails } = useSelector((state: any) => state.approvals);
  const [review, setReview] = React.useState("getReviewData")

  const [open, setOpen] = React.useState(false)
  const [title, setTitle] = React.useState<any>(null);
  const [actionType, setActionType] = React.useState<any>(null);

  console.log("...20",userDetails)

  React.useEffect(() => {
    if (!loaded.current) {
      let type = 'getReviewData'
      dispatch(fetchReviewData(type))
      loaded.current = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const onSubmitBulkReview = (e: any) => {
    setTitle('Bulk Review')
    setActionType('Bulk Review')
    setOpen(true);
  }

  const onSelectReview = (e: any) => {
    setReview(e.target.value)
    if (e.target.value === 'getunReviewData') {
      let type = 'getunReviewData'
      dispatch(fetchReviewData(type))
    } else {
      let type = 'getReviewData'
      dispatch(fetchReviewData(type))
    }
  }


  return (
    <div className='container'>
      <h2>Bulk Review</h2>
      <div className='col-sm-2 my-2'>
        <select className="form-control form-select"
          value={review}
          onChange={onSelectReview}>
          <option value="getReviewData">Review</option>
          <option value="getunReviewData">Un Review</option>
        </select>
      </div>
      <div className='tree-card'>
        <BulkTreeView
          value={bulkData}
          selectionMode="checkbox"
          filter
          filterMode="lenient"
          filterPlaceholder="Filter"
          selectionKeys={selectedKeys}
          onSelectionChange={(e: any) => setSelectedKeys(e.value)}
        />
      </div>
      <div className="d-flex justify-content-end pt-3">
        <button type="submit" className=" btn btn-primary " onClick={(e: any) => onSubmitBulkReview(e)}>Submit</button>
      </div>
      <UserLogin open={open} setOpen={setOpen} actionType={actionType}
        title={title}
      />
    </div>
  )
}

export default BulkReview;
