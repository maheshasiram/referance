import { Types } from "./Types";

const initialState = {
    bulkData: null,
    userDetails: {
        userName: '',
        password: ''
    },
    selectedFormData: [],
    submitData: { action: "", userName: "", password: "", subjectFormIds: "" }
}

export const approvals = (state = initialState, action: { type: any, payload: any }) => {
    switch (action.type) {

        case Types.FETCH_REVIEW_TREE_DATA:
            return { ...state, bulkData: action.payload }
        case Types.FETCH_MONITOR_TREE_DATA:
            return { ...state, bulkData: action.payload }
        case Types.FETCH_SIGN_TREE_DATA:
            return { ...state, bulkData: action.payload }
        case Types.USER_DETAILS:
            return { ...state, userDetails: action.payload }
        case Types.SELECTED_FORM_DATA:
            return { ...state, selectedFormData: action.payload }
        case Types.SUBMIT_DATA:
            console.log("....27", action.payload)
            return { ...state, submitData: action.payload }
        default:
            return { ...state }
    }

}