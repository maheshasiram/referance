export const bulkReviewData = {
    "data": [
        {
            "children": [
                {
                    "key": '0-0',
                    "label": "Site005",
                    "id": "s_13",
                    "children": [
                        {
                            "key": '0-1',
                            "id": "sub_43",
                            "label": "905-001",
                            "children": [
                                {
                                    "key": '0-2',
                                    "id": "ev_405",
                                    "label": "Visit: 3 PK Sampling Day for Period-1 (Day 14)",
                                    "children": [
                                        {
                                            "key": '0-3',
                                            "id": "fa_1809",
                                            "label": "Pre-Dose Sampling",
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            "key": '0-4',
                            "id": "sub_53",
                            "label": "905-002",
                            "children": [
                                {
                                    "key": '0-5',
                                    "id": "ev_446",
                                    "label": "Visit: 1 Screening/Baseline (Day -5 to Day 0)",
                                    "children": [
                                        {
                                            "key": '0-6',
                                            "id": "fa_1931",
                                            "label": "Demographic Profile",
                                        },
                                        {
                                            "key": '0-7',
                                            "id": "fa_1929",
                                            "label": "Informed Consent",
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            "key": '0-8',
                            "id": "sub_55",
                            "label": "905-003",
                            "children": [
                                {
                                    "key": '0-9',
                                    "id": "ev_453",
                                    "label": "Visit: 1 Screening/Baseline (Day -5 to Day 0)",
                                    "children": [
                                        {
                                            "key": '0-10',
                                            "id": "fa_1999",
                                            "label": "Substance Usage History",
                                        }
                                    ]
                                },
                                {
                                    "key": '0-11',
                                    "id": "ev_475",
                                    "label": "Visit: 2 Enrolment and Randomization (Day 0)",
                                    "children": [
                                        {
                                            "key": '0-12',
                                            "id": "fa_2026",
                                            "label": "Visit Details",
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            "key": '0-13',
                            "id": "sub_75",
                            "label": "905-011",
                            "children": [
                                {
                                    "key": '0-14',
                                    "id": "ev_634",
                                    "label": "Visit: 1 Screening/Baseline (Day -5 to Day 0)",
                                    "children": [
                                        {
                                            "key": '0-15',
                                            "id": "fa_2549",
                                            "label": "Substance Usage History",
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ],
            "key": "1",
            "id": 8,
            "label": "CSC-CT-021"
        }
    ]
}

export const bulkUnReviewData = {
    "data": [
        {
            "children": [
                {
                    "key": '1-0',
                    "label": "NewSite01",
                    "id": "s_13",
                    "children": [
                        {
                            "key": '1-1-0',
                            "id": "sub_43",
                            "label": "905-001",
                            "children": [
                                {
                                    "key": '1-1-1-0',
                                    "id": "ev_405",
                                    "label": "Visit: 1 PK Sampling Day for Period-1 (Day 10)",
                                    "children": [
                                        {
                                            "key": '1-1-1-1-0',
                                            "id": "fa_1809",
                                            "label": "Pre-Dose Sampling",
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            "key": '1-2-0',
                            "id": "sub_53",
                            "label": "905-002",
                            "children": [
                                {
                                    "key": '1-2-2-0',
                                    "id": "ev_446",
                                    "label": "Visit: 1 Screening/Baseline (Day -5 to Day 0)",
                                    "children": [
                                        {
                                            "key": '1-2-2-1',
                                            "id": "fa_1931",
                                            "label": "Demographic Profile",
                                        },
                                        {
                                            "key": '1-2-2-2',
                                            "id": "fa_1929",
                                            "label": "Informed Consent",
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            "key": '1-3-0',
                            "id": "sub_55",
                            "label": "905-003",
                            "children": [
                                {
                                    "key": '1-3-1',
                                    "id": "ev_453",
                                    "label": "Visit: 1 Screening/Baseline (Day -5 to Day 0)",
                                    "children": [
                                        {
                                            "key": '1-3-1-0',
                                            "id": "fa_1999",
                                            "label": "Substance Usage History",
                                        }
                                    ]
                                },
                                {
                                    "key": '1-3-2',
                                    "id": "ev_475",
                                    "label": "Visit: 2 Enrolment and Randomization (Day 0)",
                                    "children": [
                                        {
                                            "key": '1-3-2-0',
                                            "id": "fa_2026",
                                            "label": "Visit Details",
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            "key": '1-4-0',
                            "id": "sub_75",
                            "label": "905-011",
                            "children": [
                                {
                                    "key": '1-4-0-0',
                                    "id": "ev_634",
                                    "label": "Visit: 1 Screening/Baseline (Day -6 to Day )",
                                    "children": [
                                        {
                                            "key": '1-4-0-0-0',
                                            "id": "Na_658",
                                            "label": "Substance Usage History data",
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                },
            ],
            "key": "1",
            "id": 8,
            "label": "IQA DEMO Study",
        }
    ]
}