export const bulkMonitorData = {
    "data":
        [
            {
                "children": [
                    {
                        "key": "0-1",
                        "label": "Sites",
                        "id": "s_13",
                        "children": [
                            {
                                "key": "0-0-1",
                                "id": "sub_43",
                                "label": "Subject1(905-001)",
                                "children": [
                                    {
                                        "key": "0-3",
                                        "id": "ev_405",
                                        "label": "Visit: 3 PK Sampling Day for Period-1 (Day 14)",
                                        "children": [
                                            {
                                                "key": "0-3",
                                                "id": "fa_1809",
                                                "label": "Pre-Dose Sampling(Form)",
                                                "crfVersionId": 121,
                                                "studyEventId": 405
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "key": "0-0-2",
                                "id": "sub_53",
                                "label": "Subject2905-002)",
                                "children": [
                                    {
                                        "key": "0-5",
                                        "id": "ev_446",
                                        "label": "Visit: 1 Screening/Baseline (Day -5 to Day 0)",
                                        "children": [
                                            {
                                                "key": "0-6",
                                                "id": "fa_1931",
                                                "label": "Demographic Profile(Form)",
                                                "crfVersionId": 62,
                                                "studyEventId": 446
                                            },
                                            {
                                                "key": "0-7",
                                                "id": "fa_1929",
                                                "label": "Informed Consent(Form)",
                                                "crfVersionId": 73,
                                                "studyEventId": 446
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "key": "0-0-3",
                                "id": "sub_55",
                                "label": "Subject3(905-003)",
                                "children": [
                                    {
                                        "key": "0-9",
                                        "id": "ev_453",
                                        "label": "Visit: 1 Screening/Baseline (Day -5 to Day 0)",
                                        "children": [
                                            {
                                                "key": "0-10",
                                                "id": "fa_1999",
                                                "label": "Substance Usage History(Form)",
                                                "crfVersionId": 112,
                                                "studyEventId": 453
                                            }
                                        ]
                                    },
                                    {
                                        "key": "0-11",
                                        "id": "ev_475",
                                        "label": "Visit: 2 Enrolment and Randomization (Day 0)",
                                        "children": [
                                            {
                                                "key": "0-11",
                                                "id": "fa_2026",
                                                "label": "Visit Details(Form)",
                                                "crfVersionId": 63,
                                                "studyEventId": 475
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "key": "0-0-4",
                                "id": "sub_75",
                                "label": "Subject4(905-011)",
                                "children": [
                                    {
                                        "key": "0-13",
                                        "id": "ev_634",
                                        "label": "Visit: 1 Screening/Baseline (Day -5 to Day 0)",
                                        "children": [
                                            {
                                                "key": "0-13",
                                                "id": "fa_2549",
                                                "label": "Substance Usage History(Form)",
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    }
                ],
                "key": "1",
                "id": 8,
                "label": "CSC-CT-020(Study)"
            },
        ]
}

export const bulkUnMonitorData = {
    "data":
        [
            {
                "children": [
                    {
                        "key": "0-1",
                        "label": "Sites_Data",
                        "id": "s_13",
                        "children": [
                            {
                                "key": "0-0-1",
                                "id": "sub_43",
                                "label": "Subject1(905-001)",
                                "children": [
                                    {
                                        "key": "0-3",
                                        "id": "ev_405",
                                        "label": "Visit: 3 PK Sampling Day for Period-1 (Day 14)",
                                        "children": [
                                            {
                                                "key": "0-3",
                                                "id": "fa_1809",
                                                "label": "Pre-Dose Sampling(Form)",
                                                "crfVersionId": 121,
                                                "studyEventId": 405
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "key": "0-0-2",
                                "id": "sub_53",
                                "label": "Subject2905-002)",
                                "children": [
                                    {
                                        "key": "0-5",
                                        "id": "ev_446",
                                        "label": "Visit: 1 Screening/Baseline (Day -5 to Day 0)",
                                        "children": [
                                            {
                                                "key": "0-6",
                                                "id": "fa_1931",
                                                "label": "Demographic Profile(Form)",
                                                "crfVersionId": 62,
                                                "studyEventId": 446
                                            },
                                            {
                                                "key": "0-7",
                                                "id": "fa_1929",
                                                "label": "Informed Consent(Form)",
                                                "crfVersionId": 73,
                                                "studyEventId": 446
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "key": "0-0-3",
                                "id": "sub_55",
                                "label": "Subject3(905-003)",
                                "children": [
                                    {
                                        "key": "0-9",
                                        "id": "ev_453",
                                        "label": "Visit: 1 Screening/Baseline (Day -5 to Day 0)",
                                        "children": [
                                            {
                                                "key": "0-10",
                                                "id": "fa_1999",
                                                "label": "Substance Usage History(Form)",
                                                "crfVersionId": 112,
                                                "studyEventId": 453
                                            }
                                        ]
                                    },
                                    {
                                        "key": "0-11",
                                        "id": "ev_475",
                                        "label": "Visit: 2 Enrolment and Randomization (Day 0)",
                                        "children": [
                                            {
                                                "key": "0-11",
                                                "id": "fa_2026",
                                                "label": "Visit Details(Form)",
                                                "crfVersionId": 63,
                                                "studyEventId": 475
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "key": "0-0-4",
                                "id": "sub_75",
                                "label": "Subject4(905-011)",
                                "children": [
                                    {
                                        "key": "0-13",
                                        "id": "ev_634",
                                        "label": "Visit: 1 Screening/Baseline (Day -5 to Day 0)",
                                        "children": [
                                            {
                                                "key": "0-13",
                                                "id": "fa_2549",
                                                "label": "Substance Usage History(Form)",
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    }
                ],
                "key": "1",
                "id": 8,
                "label": "STUDY-CT(001)"
            },
        ]
}