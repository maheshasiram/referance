import React from 'react'
import ApprovalsRoutes from './routes/ApprovalRoutes'
function Approvals() {
    return (
        <React.Fragment>
            <ApprovalsRoutes />
        </React.Fragment>
    )
}

export default Approvals
