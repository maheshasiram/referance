import React from 'react'
import { Route, Routes } from 'react-router-dom';
import BulkMonitor from '../modules/bulkMonitor/BulkMonitor';
import BulkReview from '../modules/bulkReview/BulkReview';
import BulkSign from '../modules/bulkSign/BulkSign';



function ApprovalsRoutes() {
    return (
        <Routes>
            <Route path='bulkreview' element={< BulkReview />}></Route>
            <Route path='bulkmonitor' element={< BulkMonitor />}></Route>
            <Route path='bulksign' element={< BulkSign />}></Route>
        </Routes>

    )
}
export default ApprovalsRoutes