import React, { useState } from 'react';
import { Tree } from 'primereact/tree';

function BulkTreeView(props: any) {
    const [selectedKeys, setSelectedKeys] = useState(null);
  

    const nodeTemplate = (node: any) => {
        return (
            <React.Fragment>
                <span>
                    {node.label}
                </span>
            </React.Fragment>
        )
    }

   

    return (
        <React.Fragment>
            <Tree
                value={props.value}
                selectionMode="checkbox"
                filter
                filterMode="lenient"
                filterPlaceholder="Search ..."
                selectionKeys={selectedKeys}
                nodeTemplate={nodeTemplate}
                onSelect={props.onSelcetNode}
                onUnselect={props.onUnselect}
                onSelectionChange={(e: any) => {
                    setSelectedKeys(e.value)
                }}
            />
        </React.Fragment>
    )
}

export default BulkTreeView;