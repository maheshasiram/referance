import React from "react";
import CustomDialog from '../../../common/modals/CustomeDialog';
import { useSelector, useDispatch } from 'react-redux';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';


function UserLogin(props: any) {
    console.log('....props', props);
    
    const { open, setOpen } = props
    const { userDetails } = useSelector((state: any) => state.approvals)

    const BulkLockSchema = Yup.object().shape({
        userName: Yup.string()
            .required('Please enter username'),
        password: Yup.string()
            .required('Please enter password'),
    });
    const respondClose = () => {
        setOpen(false)

    }



    return (
        <React.Fragment>
            <div>
                <CustomDialog
                    open={open}
                    title={props.title === "Bulk Monitor" ? "Bulk Monitor" : props.title === "Bulk Review" ? 'Bulk Review' : props.title === "Bulk Sign" ? 'Bulk Sign' : 'Bulk Lock'}
                    maxWidth='xs'
                    fullWidth={true}
                    actionType={props.actionType === "Bulk Review" ? "Bulk Review" : props.actionType === "Bulk Monitor" ? "Bulk Monitor" : props.actionType === "Bulk Sign" ? "Bulk Sign" : "Bulk Lock"}
                    onClose={respondClose}
                    form='submitUser'
                >
                    <div className=''>
                        <Formik
                            initialValues={userDetails}
                            validationSchema={BulkLockSchema}
                            onSubmit={(values) => props.onSubmitUser(values)}
                        >
                            {({ errors, touched, values, setFieldValue }) => (
                                <Form id='submitUser'>
                                    <div className="p-3">
                                        <div className="mb-2">
                                            <label>User Name :</label>
                                            <Field
                                                name="userName"
                                                className='form-control'
                                                onChange={(e: any) => {
                                                    setFieldValue('userName', e.target.value);
                                                }}

                                            />
                                            {errors.userName && touched.userName ? <div className="text-danger"><ErrorMessage name={`userName`} /></div> : null}
                                        </div>
                                        <div className="mb-2">
                                            <label>Password :</label>
                                            <Field
                                                name="password"
                                                className='form-control '
                                                type='password'
                                                onChange={(e: any) => {
                                                    setFieldValue('password', e.target.value);

                                                }}
                                            />
                                            {errors.userName && touched.userName ? <div className="text-danger"><ErrorMessage name={`password`} /></div> : null}
                                        </div>
                                    </div>
                                </Form>
                            )}
                        </Formik>
                    </div>
                </CustomDialog>
            </div>
        </React.Fragment >
    )
}
export default UserLogin;
