import React from 'react'
import { Route, Routes } from 'react-router-dom';
import CaseBooksModule from '../modules/caseBooks/CaseBooks';
import DataExportModule from '../modules/dataExport/DataExport';


function SubmissionRoutes() {
    return (
        <Routes>
            <Route path='dataexport' element={<DataExportModule />}></Route>
            <Route path='casebooks' element={<CaseBooksModule />}></Route>
        </Routes>
        // <Routes>
        //     <Route
        //         element={
        //             <PrivateRoute isAuthenticated={isAuthenticated} to="/">
        //                 <DataExport />
        //             </PrivateRoute>
        //         }
        //         path="/dataexport"
        //     />
        //     <Route
        //         element={
        //             <PrivateRoute isAuthenticated={isAuthenticated} to="/">
        //                 <CaseBooks />
        //             </PrivateRoute>
        //         }
        //         path="/casebooks"
        //     />
        // </Routes>
    )
}
export default SubmissionRoutes