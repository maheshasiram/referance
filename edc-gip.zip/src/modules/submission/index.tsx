import React from 'react'
import SubmissionRoutes from './routes'

function Submission() {
    return (
        <React.Fragment>
            {/* <h1>Submission</h1> */}
            <SubmissionRoutes />
        </React.Fragment>

    )
}
export default Submission