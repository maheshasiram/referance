import { Types } from "./Types";
import { SubjectListData } from "../constants/SubjectListData";
import { downloadCaseBookModal} from "../constants/modal";

const initialState = {
    subjects: [],
    downloadCaseBook: downloadCaseBookModal,
    annotationPayload: { annotation: '' }
}

export const casebook = (state = initialState, action: any) => {
    switch (action.type) {
        case Types.GET_SUBJECT_LIST:
            return { ...state, subjects: action.payload }
        case Types.DOWNLOAD_PDF_FOR_STUDY:
            return { ...state, downloadCaseBook: action.payload }
        case Types.DOWNLOAD_ANNOTATION_PDF:
            console.log('18....', action.payload)
            return { ...state, annotationPayload: action.payload }
        default: return { ...state }
    }
}