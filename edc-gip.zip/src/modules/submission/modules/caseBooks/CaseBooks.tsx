import React from "react";
import SubjectList from "./components/SubjectList";
import PdfForStudy from "./components/PdfForStudy";
import './style.scss';
 


function CaseBooks() {
    return (
        <React.Fragment>
            <div className='border border-bottom-1'>
                <h1 className='mt-2'>Case Books</h1>
            </div>
            <div className="row">
                <div className="col-9">
                    <SubjectList />
                </div>
                <div className="col-3">
                    <PdfForStudy />
                </div>
            </div>
        </React.Fragment>
    )
}
export default CaseBooks