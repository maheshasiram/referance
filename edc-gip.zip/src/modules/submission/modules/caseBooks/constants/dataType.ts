export type downloadCaseBookDataType = {
    subjectIds?: string
    audit?: boolean,
    query?: boolean,
    notes?: boolean

}
export type subjectListDataType = [
    {
        id?:number ,
        label?: string,
        status?: boolean
    }
]
