import { downloadCaseBookDataType, subjectListDataType } from "./dataType"

export const downloadCaseBookModal: downloadCaseBookDataType = {
    subjectIds: '',
    audit: false,
    query: false,
    notes: false,
}
export const subectListModal: subjectListDataType = [
    {
        id: 0,
        label: "",
        status: false
    }
]