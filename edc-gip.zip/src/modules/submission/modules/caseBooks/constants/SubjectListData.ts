export const SubjectListData: any = [
    {
        id: 1,
        label: "101-01",
        status: false
    },
    {
        id: 2,
        label: "101-02",
        status: false
    },
    {
        id: 3,
        label: "101-03",
        status: false
    },
    {
        id: 4,
        label: "101-04",
        status: false
    },
    {
        id: 5,
        label: "101-05",
        status: false
    },
    {
        id: 6,
        label: "101-06",
        status: false
    },
    {
        id: 7,
        label: "101-07",
        status: false
    },
    {
        id: 8,
        label: "101-08",
        status: false
    },
    {
        id: 9,
        label: "101-09",
        status: false
    },
    {
        id: 10,
        label: "101-10",
        status: false
    },
    {
        id: 11,
        label: "101-11",
        status: false
    },
    {
        id: 12,
        label: "101-12",
        status: false
    },
    {
        id: 13,
        label: "101-13",
        status: false
    },
    {
        id: 14,
        label: "101-14",
        status: false
    },{
        id: 15,
        label: "101-15",
        status: false
    },
    {
        id: 16,
        label: "101-16",
        status: false
    },
    {
        id: 17,
        label: "101-17",
        status: false
    },
    {
        id: 18,
        label: "101-18",
        status: false
    },
    {
        id: 19,
        label: "101-19",
        status: false
    },
    {
        id: 20,
        label: "101-20",
        status: false
    },
    {
        id: 21,
        label: "101-21",
        status: false
    },
    {
        id: 22,
        label: "101-22",
        status: false
    },
    {
        id: 23,
        label: "101-23",
        status: false
    },
    {
        id: 24,
        label: "101-24",
        status: false
    },
    {
        id: 25,
        label: "101-25",
        status: false
    },
    {
        id: 26,
        label: "101-26",
        status: false
    },
    {
        id: 27,
        label: "101-27",
        status: false
    },
    {
        id: 28,
        label: "101-28",
        status: false
    },
    {
        id: 29,
        label: "101-29",
        status: false
    },
    {
        id: 30,
        label: "101-30",
        status: false
    },
]