import { Loader } from "../../../../../actions/actions";
import { Submission } from "../../../../../configs/enivornment/submission";
import { fetch } from "../../../../../constants/fetch";
import { SubjectListData } from "../constants/SubjectListData";
import { Types } from "../reducer/Types";

export const downloadCasebook = (payload: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'POST',
            //   url: url,
            data: payload,
        })
            .then((response: any) => {
                console.log('payload for subject list casebook', payload,response)
                // if (callback) { callback(response) }
                dispatch(Loader(false));
            })
    }

};
export const downloadBlankPDf = (payload: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'POST',
            //   url: url,
            data: payload,
        })
            .then((response: any) => {
                console.log('payload for downloadBlank pdf', payload,response)
                // if (callback) { callback(response) }
                dispatch(Loader(false));
            })
    }

}
export const fetchAllSubjectList:any = () => {
    return  (dispatch: any)=> {
        const url = Submission.casebooks.fetchAllSubjects;
        console.log('payload for downloadBlank pdf',url)
        dispatch(Loader(true));
        fetch({
            method: 'GET',
            url: url,
            data: '',
        })
            .then((response: any) => {
                console.log('payload for downloadBlank pdf', SubjectListData)
                dispatch({ type: Types.GET_SUBJECT_LIST, payload: response.data })
                // if (callback) { callback(response) }
                dispatch(Loader(false));
            }).catch((error: any) => {
                console.log('error', error)
            })
    }

}
