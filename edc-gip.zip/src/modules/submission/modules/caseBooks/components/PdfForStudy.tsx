import React from 'react'
import { styled } from '@mui/material/styles';
import Radio, { RadioProps } from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import { useDispatch, useSelector } from 'react-redux';
import { Types } from '../reducer/Types';
import { toastAlert } from '../../../../../actions/actions';

const BpIcon = styled('span')(({ theme }) => ({
    borderRadius: '50%',
    width: 16,
    height: 16,
    boxShadow:
        theme.palette.mode === 'dark'
            ? '0 0 0 1px rgb(16 22 26 / 40%)'
            : 'inset 0 0 0 1px rgba(16,22,26,.2), inset 0 -1px 0 rgba(16,22,26,.1)',
    backgroundColor: theme.palette.mode === 'dark' ? '#394b59' : '#f5f8fa',
    backgroundImage:
        theme.palette.mode === 'dark'
            ? 'linear-gradient(180deg,hsla(0,0%,100%,.05),hsla(0,0%,100%,0))'
            : 'linear-gradient(180deg,hsla(0,0%,100%,.8),hsla(0,0%,100%,0))',
    '.Mui-focusVisible &': {
        outline: '2px auto rgba(19,124,189,.6)',
        outlineOffset: 2,
    },
    'input:hover ~ &': {
        backgroundColor: theme.palette.mode === 'dark' ? '#30404d' : '#ebf1f5',
    },
    'input:disabled ~ &': {
        boxShadow: 'none',
        background:
            theme.palette.mode === 'dark' ? 'rgba(57,75,89,.5)' : 'rgba(206,217,224,.5)',
    },
}));

const BpCheckedIcon = styled(BpIcon)({
    backgroundColor: '#137cbd',
    backgroundImage: 'linear-gradient(180deg,hsla(0,0%,100%,.1),hsla(0,0%,100%,0))',
    '&:before': {
        display: 'block',
        width: 16,
        height: 16,
        backgroundImage: 'radial-gradient(#fff,#fff 28%,transparent 32%)',
        content: '""',
    },
    'input:hover ~ &': {
        backgroundColor: '#106ba3',
    },
});

// Inspired by blueprintjs
function BpRadio(props: RadioProps) {
    return (
        <Radio
            disableRipple
            color="default"
            checkedIcon={<BpCheckedIcon />}
            icon={<BpIcon />}
            {...props}
        />
    );
}
function PdfForStudy() {
    const { annotationPayload } = useSelector((state: any) => state.casebook)
    const dispatch = useDispatch()

    const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const _annotation = { ...{}, ...annotationPayload };
        if (event.target.value === 'withAnnotation') {
            _annotation.annotation = true;
            dispatch({ type: Types.DOWNLOAD_ANNOTATION_PDF, payload: _annotation });
        } else {
            _annotation.annotation = false;
            dispatch({ type: Types.DOWNLOAD_ANNOTATION_PDF, payload: _annotation });
        }
    };
    const handleDownload = () => {
        if (annotationPayload.annotation === '') {
            dispatch(toastAlert({
                status: 0,
                open: true,
                message: 'Please select atleast one annotation.'
            }))
        } else {
            //here will call emptyPdf API  
            console.log('payload for annotation....',annotationPayload) 
            dispatch(toastAlert({
                status: 1,
                open: true,
                message: 'The selected annotions blank pdf,started downloading.You will get a mail notification after completion'
            }))
        }
    }
    return (
        <div>
            <div className='PDF-for-study-container'>
                <span className='header'>Blank pdf fo study</span>
                <FormControl>
                    <RadioGroup
                        aria-labelledby="demo-customized-radios"
                        name="customized-radios"
                        onChange={handleChange}
                    >
                        <FormControlLabel value="withAnnotation" control={<BpRadio />} sx={{ color: '#ffff' }} label="With Annotation" />
                        <FormControlLabel value="withoutAnnotation" control={<BpRadio />} sx={{ color: '#ffff' }} label="Without Annotation" />
                    </RadioGroup>
                </FormControl>
                <div className='d-flex justify-content-center mt-3'>
                    <button className="btn-eprimary" onClick={handleDownload} type="button">Download PDF</button>
                </div>
            </div>
        </div>
    )
}

export default PdfForStudy