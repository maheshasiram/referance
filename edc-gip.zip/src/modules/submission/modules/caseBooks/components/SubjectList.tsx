import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import { Types } from '../reducer/Types';
import { toastAlert } from '../../../../../actions/actions';
import { fetchAllSubjectList } from '../actions/action';

function SubjectList() {
    const { subjects, downloadCaseBook } = useSelector((state: any) => state.casebook)
    const dispatch = useDispatch();
    const loaded = React.useRef(false);


    const [checked, setChecked] = React.useState<any | null>([]);

    React.useEffect(() => {
        if (!loaded.current) {
            dispatch(fetchAllSubjectList())
            loaded.current = true
        }
    }, [])

    const handleCheckAllChange = (e: any) => {
        const _payload = { ...{}, ...downloadCaseBook };
        if (e.target.checked) {
            const allSubjects = subjects.map((sub: any) => sub.id);
            _payload.subjectIds = allSubjects.toString();
            dispatch({ type: Types.DOWNLOAD_PDF_FOR_STUDY, payload: _payload })
            setChecked(allSubjects);
        } else {
            setChecked([]);
            _payload.subjectIds = '';
            dispatch({ type: Types.DOWNLOAD_PDF_FOR_STUDY, payload: _payload })
        }
    };
    const handleSubjectChange = (e: any, sub: any) => {
        const _payload = { ...{}, ...downloadCaseBook };
        let _checked: any;
        if (e.target.checked) {
            _checked = [...checked, sub.id]
            setChecked([...checked, sub.id]);
            _payload.subjectIds = _checked.toString();
            dispatch({ type: Types.DOWNLOAD_PDF_FOR_STUDY, payload: _payload })
        } else {
            setChecked(checked.filter((item: any) => item !== sub.id));
            _checked = checked.filter((item: any) => item !== sub.id)
            _payload.subjectIds = _checked.toString();
            dispatch({ type: Types.DOWNLOAD_PDF_FOR_STUDY, payload: _payload })
        }
    };

    const handleChange = (e: any, param: string) => {
        const _payload = { ...{}, ...downloadCaseBook };
        if (param === 'audit') {
            _payload.audit = e.target.checked;
            dispatch({ type: Types.DOWNLOAD_PDF_FOR_STUDY, payload: _payload })
        } else if (param === 'notes') {
            _payload.notes = e.target.checked;
            dispatch({ type: Types.DOWNLOAD_PDF_FOR_STUDY, payload: _payload })
        } else if (param === 'query') {
            _payload.query = e.target.checked;
            dispatch({ type: Types.DOWNLOAD_PDF_FOR_STUDY, payload: _payload })
        }

    }
    const handleDownload = () => {
        if (downloadCaseBook.subjectIds !== '') {
            console.log('payload for download casebook....', downloadCaseBook)
            dispatch(toastAlert({
                status: 1,
                open: true,
                message: 'The selected casebook is started downloading,you will get a mail notification after completion'
            }))
        } else {
            dispatch(toastAlert({
                status: 0,
                open: true,
                message: 'Please select atleast one subject'
            }))
        }
    }

    return (
        <div className='subject-list-container'>
            <div className='subject-list-container-header'>
                <div className='ms-3'>
                    {subjects && subjects.length > 1 && <FormControlLabel control={<Checkbox
                        // onChange={handleSelectAllChange}
                        checked={checked.length === subjects.length}
                        onChange={handleCheckAllChange}
                        size="small" />} label="Select all" />}

                </div>
                <div className='subject-list-container-header-right ps-4'>
                    <FormControlLabel control={<Checkbox size="small" onChange={(e: any) => handleChange(e, 'audit')} />} label="Audit trail" />
                    <FormControlLabel control={<Checkbox size="small" onChange={(e: any) => handleChange(e, 'query')} />} label="Query logs" />
                    <FormControlLabel control={<Checkbox size="small" onChange={(e: any) => handleChange(e, 'notes')} />} label="Sticky notes" />
                </div>
            </div>
            <div className='subject-list-data-container '>
                {
                    subjects && subjects.length > 0 ? subjects?.map((sub: any, index: number) => {
                        return <div className='w-25 ps-3 d-flex' key={index}>

                            <input
                                value={sub.id}
                                type='checkBox'
                                checked={checked.includes(sub.id)}
                                onChange={(e) => handleSubjectChange(e, sub)}
                            />
                            <label className="form-check-label m-2 " >{sub.subjectId}</label>
                        </div>
                    }) : <span className='empty-container'>No subjects are available to display</span>
                }
            </div>
            <div className='d-flex justify-content-end m-2'>
                <button className="btn-eprimary" onClick={handleDownload} type="button">Download</button>
            </div>
        </div>
    )
}

export default SubjectList