export const VisitsAndFormsData: any = [
    {
        visitid: 1,
        visitName: "Screening",
        forms: [
            {
                formId: 20,
                formName: "Demographic",
            },
            {
                formId: 21,
                formName: "Bloodsample",
            },
            {
                formId: 22,
                formName: "MealForm",
            }
        ]
    },
    {
        visitid: 2,
        visitName: "PostStudy",
        forms: [
            {
                formId: 20,
                formName: "Bloodsample",
            }
        ]
    },
    {
        visitid: 3,
        visitName: "Screening",
        forms: [
            {
                formId: 20,
                formName: "Demographic",
            },
            {
                formId: 21,
                formName: "Bloodsample",
            },

        ]
    },
]

export const FormsAndVisiteData: any = [
    {
        formid: 1,
        formName: "Demographic",
        visits: [
            {
                visitId: 22,
                visitName: "Screening"
            },
            {
                visitId: 23,
                visitName: "Period-1"
            },
            {
                visitId: 24,
                visitName: "Period-2"
            },
            {
                visitId: 25,
                visitName: "PostStudy"
            }
        ]
    },
    {
        formId: 2,
        formName: "MealForm",
        visits: [
            {
                visitId: 20,
                visitName: "Period-1"
            },
            {
                visitId: 21,
                visitName: "Period-2"
            }
        ]
    }
]