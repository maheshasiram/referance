import React from 'react';
import Accordion from '@mui/material/Accordion';
import { styled } from '@mui/material/styles';
// import ExportByForm from './components/ExportByForm';
// import ExportByVisit from './components/ExportByVisit';
import ExportByForm from './components/ExportByForm';
import ExportByVisit from './components/ExportByVisit';
import '../../styles/Styles.scss'

export const AccordionNexted = styled((props: any) => (
    <Accordion disableGutters elevation={0} square {...props} />
))(({ theme }) => ({
    background: '#FFF',
    border: `0px solid ${theme.palette.divider}`,
    '&:not(:last-child)': {
        borderBottom: `1px solid ${theme.palette.divider}`,
    },
    '&:before': {
        display: 'none',
    },
}));

function DataExport() {
 
    return (
        <React.Fragment>
            <div className='data-export-container'>
                <h4  className='m-4'>Data Export     </h4>
                <nav >
                    <div className="nav nav-tabs px-3" id="nav-tab" role="tablist">
                        <button className="nav-link active" id="exportByVisit" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true">Export By Visit</button>
                        <button className="nav-link" id="exportByForm" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="false">Export By Form</button>
                    </div>
                </nav>
                <div className="tab-content data-table " id="nav-tabContent">
                    <div className="tab-pane fade show active" id="nav-home"
                        role="tabpanel" aria-labelledby="exportByForm">
                        <ExportByVisit />
                    </div>
                    <div className="tab-pane fade" id="nav-profile"
                        role="tabpanel" aria-labelledby="exportByVisit">
                        <ExportByForm  />
                    </div>
                </div>
            </div>
        </React.Fragment >
    )
}
export default DataExport;