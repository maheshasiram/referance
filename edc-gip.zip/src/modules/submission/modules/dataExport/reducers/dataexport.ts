// import { Types } from "./Types";
import { Types } from "./Types";
import { VisitsAndFormsData, FormsAndVisiteData } from "../constants/VisitsAndFormsData";

const initialState = {
    getAllVisitsWithForms: VisitsAndFormsData,
    getAllFormsWithVisits: FormsAndVisiteData
}

export const dataexport = (state = initialState, action: any) => {
    switch (action.type) {
        case Types.GET_ALL_VISITS_WITH_ASSIGN_FORMS:
            return { ...state, getAllVisitsWithForms: action.payload }
        case Types.GET_ALL_FORMS_WITH_ASSIGN_VISITS:
            return { ...state, getAllFormsWithVisits: action.payload }
        default: return { ...state }
    }

}