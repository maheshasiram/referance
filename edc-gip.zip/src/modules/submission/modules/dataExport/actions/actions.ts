import { Loader } from "../../../../../actions/actions";
import { fetch } from "../../../../../constants/fetch";
// import { VisitsAndFormsData, FormsAndVisiteData } from "../constants/VisitsAndFormsData";
import { Types } from "../reducers/Types";

export const fetchVisitsAndFormsData = () => {
    return function (dispatch: any) {
        alert('')
        dispatch(Loader(true));
        fetch({
            method: 'GET',
            url: '',
            data: '',
        })
            .then((response: any) => {
                dispatch({ type: Types.GET_ALL_VISITS_WITH_ASSIGN_FORMS, payload: response.data })
                // if (callback) { callback(response) }
                dispatch(Loader(false));
            }).catch((error: any) => {
                console.log('error', error)
            })
    }

}

export const fetchFormsAndVisitsData = () => {
    return function (dispatch: any) {
        alert('')
        dispatch(Loader(true));
        fetch({
            method: 'GET',
            url: '',
            data: '',
        })
            .then((response: any) => {
                dispatch({ type: Types.GET_ALL_VISITS_WITH_ASSIGN_FORMS, payload: response.data })
                // if (callback) { callback(response) }
                dispatch(Loader(false));
            }).catch((error: any) => {
                console.log('error', error)
            })
    }

}