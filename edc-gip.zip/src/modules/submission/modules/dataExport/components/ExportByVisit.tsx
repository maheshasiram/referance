import React from "react";
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Switch from '@mui/material/Switch';
import _ from 'lodash';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import FormControl from '@mui/material/FormControl';
import { useDispatch, useSelector } from "react-redux";
import { Types } from "../reducers/Types";
import { fetchVisitsAndFormsData } from "../actions/actions";
import { VisitFormTreeView } from "../../../../studySetup/modules/rules/actions/actions";



function ExportByVisit() {
    const dispatch = useDispatch()
    const { getAllVisitsWithForms } = useSelector((state: any) => state.dataexport)
    // const { destinationTreeeData } = useSelector((state: any) => state.rules);
    const [currentVisit, setCurrentVisit] = React.useState('0');
    const { currentStudy } = useSelector((state: any) => state.application);
    const [allFormsSelected, setAllFormsSelected] = React.useState(false);
    React.useEffect(() => {
        // fetchVisitsAndFormsData()
        // dispatch(VisitFormTreeView(currentStudy.id, {},(response:any)=>{
        //     // setCurrentVisit(`${response[1].id}`)
        //     dispatch({ type: Types.GET_ALL_VISITS_WITH_ASSIGN_FORMS, payload: response })
        // }))
    }, [])
    console.log('35....',currentVisit);
    
    


    const onSelectItemsHandler = (e: any, index: any) => {
        const _getVisits = _.cloneDeep(getAllVisitsWithForms);
        _getVisits[index].selected = e.target.checked;
        _getVisits[index].children.map((item: any) => item.selected = e.target.checked);
        dispatch({ type: Types.GET_ALL_VISITS_WITH_ASSIGN_FORMS, payload: _getVisits })
        // dispatch(fetchVisitsAndFormsData(_getVisits))
        setAllFormsSelected(e.target.checked)
    }
    const onVisitClick = (e: any, index: any, visits: any) => {
        setCurrentVisit(index);
        setAllFormsSelected(true);
        visits.children.map((item: any) => {
            if (!item.selected) {
                setAllFormsSelected(false);
            }
            return null;

        })

    }
    const onChangeSwitch = (e: any, pIndex: any, cIndex: any, item: any, type: any) => {
        
        if (type === 'childSwitch') {
            const _getVisits = _.cloneDeep(getAllVisitsWithForms);
            let allSelected = false;
            _getVisits.allFormsSelected = true;
            setAllFormsSelected(true);
            _getVisits[pIndex].children[cIndex].selected = e.target.checked;
            _getVisits[pIndex].selected = true;
            _getVisits[pIndex].children.map((itam: any) => {
                if (itam.selected) {
                    allSelected = true
                } else {
                    setAllFormsSelected(false)
                }
                return null;
            })
            if (!allSelected) {
                _getVisits[pIndex].selected = false
            }
            dispatch({ type: Types.GET_ALL_VISITS_WITH_ASSIGN_FORMS, payload: _getVisits });
        } else {
            const _getVisits = _.cloneDeep(getAllVisitsWithForms);
            setAllFormsSelected(e.target.checked);
            _getVisits[currentVisit].selected = e.target.checked;
            _getVisits[currentVisit]?.children.map((item: any, findex: any) => {
                _getVisits[currentVisit].children[findex].selected = e.target.checked;
                return null;
            });
            dispatch({ type: Types.GET_ALL_VISITS_WITH_ASSIGN_FORMS, payload: _getVisits });

        }
    }
    const onSelectAll = () => {
        alert('123')
    }


    return (
        <React.Fragment>
            <div className="m-3">
                <h6>Filters : </h6>
            </div>
            <div className="d-flex col-sm-12">
                <div className="data-export-row col-sm-9">
                    <div className="col-sm-4 field">
                        <label>Form Status</label>
                        <select className="form-control form-select">
                            <option>Select</option>
                            <option>Select</option>
                        </select>
                    </div>
                    <div className="col-sm-4 field">
                        <div><label>Start Date</label></div>
                        <FormControl className=" date-field">
                            <div className="d-flex align-items-center" >
                                <LocalizationProvider dateAdapter={AdapterDayjs}>
                                    <DatePicker
                                        className='df_datefield '
                                    />
                                </LocalizationProvider>
                            </div>
                        </FormControl>
                    </div>
                    <div className="col-sm-4 field">
                        <div><label>End Date</label></div>
                        <FormControl className=" date-field">
                            <div className="d-flex align-items-center" >
                                <LocalizationProvider dateAdapter={AdapterDayjs}>
                                    <DatePicker
                                        className='df_datefield '
                                    />
                                </LocalizationProvider>
                            </div>
                        </FormControl>
                    </div>
                </div>
                <div className="col-sm-3 form-status">
                    <label>Download File Type</label>
                    <select className="form-control form-select" >
                        <option>Select</option>
                        <option>Select</option>
                    </select>
                </div>
            </div>
            <div className="visits-forms-container d-flex">
                <ul id="left-container">
                    <li key=''>
                        <input type="checkbox" onClick={onSelectAll} />
                        <label htmlFor='#' >Select All</label>
                    </li>
                    {getAllVisitsWithForms?.map((element: any, index: any) => {

                        return (
                            <li key={element.id} value={currentVisit} onClick={(e) => onVisitClick(e, index, element)}>
                                <input type="checkbox"
                                    value={index}
                                    id={element.visitId}
                                    onChange={(e: any) => onSelectItemsHandler(e, index)}
                                    checked={element.selected} />
                                <label htmlFor='#' >{element.label}</label>
                            </li>
                        )
                    })}
                </ul>
                <div className="right-container">
                    <div className="">
                        <div className="select-all">
                            <FormGroup className="mui-icon">
                                <span className="me-3">All forms :</span>
                                <FormControlLabel control={<Switch />} label="" checked={allFormsSelected} onChange={(e: any, item: any) => onChangeSwitch(e, item, null, null, 'allForms')} />
                            </FormGroup>
                        </div>
                        {getAllVisitsWithForms.length >0 ?<div className="header ">
                            {getAllVisitsWithForms.map((element: any, pIndex: any) => {
                                if (pIndex === currentVisit) {
                                    return element.children.map((item: any, cIndex: any) => {
                                        <h2>{element.label}</h2>
                                        return <FormGroup className="mui-icon " key={cIndex}>
                                            <FormControlLabel control={<Switch size="small" checked={item.selected} />} onChange={(e: any) => onChangeSwitch(e, pIndex, cIndex, item, 'childSwitch')} label="" />
                                            <span className="me-3">{item.formName}</span>
                                        </FormGroup>
                                    })
                                }
                                return null;

                            })}
                        </div> :'empty'}
                    </div>
                </div>
            </div>
            <div>
                <div className=" mt-2 me-2 d-flex justify-content-end">
                    <button className="btn-esuccess" >Download Data Export File</button>
                </div>
            </div>
        </React.Fragment>
    )
}
export default ExportByVisit