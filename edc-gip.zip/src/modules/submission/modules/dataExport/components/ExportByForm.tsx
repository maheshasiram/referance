import React from "react";
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Switch from '@mui/material/Switch';
import _ from 'lodash';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import FormControl from '@mui/material/FormControl';
import { useDispatch, useSelector } from "react-redux";
import { Types } from "../reducers/Types";
import { fetchFormsAndVisitsData } from "../actions/actions";

function ExportByForm() {

    const dispatch = useDispatch()
    const { getAllFormsWithVisits } = useSelector((state: any) => state.dataexport)
    const [currentVisit, setCurrentVisit] = React.useState('0');
    const [allVisitsSelected, setAllVisitsSelected] = React.useState(false);
    React.useEffect(() => {
        fetchFormsAndVisitsData()
        // if(response?.length > 0){
            //     setCurrentVisit(`${response[0].id}`)
            // }
    },[getAllFormsWithVisits])

    const onSelectItemsHandler = (e: any, index: any) => {
        const _getForms = _.cloneDeep(getAllFormsWithVisits);
        _getForms[index].selected = e.target.checked;
        _getForms[index].visits.map((item: any) => item.selected = e.target.checked);
        dispatch({ type: Types.GET_ALL_FORMS_WITH_ASSIGN_VISITS, payload: _getForms })
        setAllVisitsSelected(e.target.checked)
    }
    const onVisitClick = (e: any, index: any, visits: any) => {
        setCurrentVisit(index);
        setAllVisitsSelected(true);
        visits.forms.map((item: any) => {
            console.log('30...',item);
            if (!item.selected) {
                setAllVisitsSelected(false);
            } 
            return null;
        })

    }
    const onChangeSwitch = (e: any, pIndex: any, cIndex: any, item: any, type: any) => {
        if (type === 'childSwitch') {
            const _getForms = _.cloneDeep(getAllFormsWithVisits);
            let allSelected = false;
            _getForms.allFormsSelected = true;
            setAllVisitsSelected(true);
            _getForms[pIndex].visits[cIndex].selected = e.target.checked;
            _getForms[pIndex].selected = true;
            _getForms[pIndex].visits.map((itam: any) => {
                if (itam.selected) {
                    allSelected = true
                } else {
                    setAllVisitsSelected(false)
                }
                return null;
            })
            if (!allSelected) {
                _getForms[pIndex].selected = false
            }
            dispatch({ type: Types.GET_ALL_FORMS_WITH_ASSIGN_VISITS, payload: _getForms });
        } else {
            const _getForms = _.cloneDeep(getAllFormsWithVisits);
            setAllVisitsSelected(e.target.checked);
            _getForms[currentVisit].selected = e.target.checked;
            _getForms[currentVisit]?.visits.map((item: any, findex: any) => {
                _getForms[currentVisit].visits[findex].selected = e.target.checked;
                return null;
            });
            dispatch({ type: Types.GET_ALL_FORMS_WITH_ASSIGN_VISITS, payload: _getForms });

        }
    }
   


    return (
        <React.Fragment>
            <div className="m-3">
                <h6>Filters : </h6>
            </div>
            <div className="d-flex col-sm-12">
                <div className="data-export-row col-sm-9">
                    <div className="col-sm-4 field">
                        <label>Form Status</label>
                        <select className="form-control form-select">
                            <option>Select</option>
                            <option>Select</option>
                        </select>
                    </div>
                    <div className="col-sm-4 field">
                        <div><label>Start Date</label></div>
                        <FormControl className=" date-field">
                            <div className="d-flex align-items-center" >
                                <LocalizationProvider dateAdapter={AdapterDayjs}>
                                    <DatePicker
                                        className='df_datefield '
                                    />
                                </LocalizationProvider>
                            </div>
                        </FormControl>
                    </div>
                    <div className="col-sm-4 field">
                        <div><label>End Date</label></div>
                        <FormControl className=" date-field">
                            <div className="d-flex align-items-center" >
                                <LocalizationProvider dateAdapter={AdapterDayjs}>
                                    <DatePicker
                                        className='df_datefield '
                                    />
                                </LocalizationProvider>
                            </div>
                        </FormControl>
                    </div>
                </div>
                <div className="col-sm-3 form-status">
                    <label>Download File Type</label>
                    <select className="form-control form-select" >
                        <option>Select</option>
                        <option>Select</option>
                    </select>
                </div>
            </div>
            <div className="visits-forms-container d-flex">
                <ul id="left-container">
                    <li key=''>
                        <input type="checkbox" />
                        <label htmlFor='#' >Select All</label>
                    </li>
                    {getAllFormsWithVisits?.map((element: any, index: any) => {

                        return (
                            <li key={element.id} value={currentVisit} onClick={(e) => onVisitClick(e, index, element)}>
                                <input type="checkbox"
                                    value={index}
                                    id={element.formid}
                                    onChange={(e: any) => onSelectItemsHandler(e, index)}
                                    checked={element.selected} />
                                <label htmlFor='#' >{element.formName}</label>
                            </li>
                        )
                    })}
                </ul>
                <div className="right-container">
                    <div className="">
                        <div className="select-all">
                            <FormGroup className="mui-icon">
                                <span className="me-3">All Visits :</span>
                                <FormControlLabel control={<Switch />} label="" checked={allVisitsSelected} onChange={(e: any, item: any) => onChangeSwitch(e, item, null, null, 'allVisits')} />
                            </FormGroup>
                        </div>
                        <div className="header ">
                            {getAllFormsWithVisits.map((element: any, pIndex: any) => {
                                if (pIndex === currentVisit) {
                                    return element.visits.map((item: any, cIndex: any) => {
                                        return <FormGroup className="mui-icon " key={cIndex}>
                                            <FormControlLabel control={<Switch size="small" checked={item.selected} />} onChange={(e: any) => onChangeSwitch(e, pIndex, cIndex, item, 'childSwitch')} label="" />
                                            <span className="me-3">{item.visitName}</span>
                                        </FormGroup>
                                        return null;
                                    })
                                }
                                return null;
                            })}
                        </div>
                    </div>
                </div>
            </div>
            <div>
                <div className=" mt-2 me-2 d-flex justify-content-end">
                    <button className="btn-esuccess" >Download Data Export File</button>
                </div>
            </div>
        </React.Fragment>
    )
}
export default ExportByForm