import { fetch } from "../../../constants/fetch"
import { Loader } from "../../../actions/actions"
import { subjects } from "../../../configs/enivornment/subjects"
import { Types } from "../reducers/Types"

export const fetchAndFilterQueries: any = (payload: any, callback: any) => {
    const url = subjects.queryListingModule.filterAndFetchQueries
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload
        })
            .then((response: any) => {
                if (callback) {
                    const _response = { ...{}, ...response }
                    response.data.queries.map((i: any, index: number) => {
                        if (i.closeQuery === true) {
                            _response.data.queries[index].disable = true
                        } else {
                            _response.data.queries[index].disable = false
                        }
                        return null
                    })
                    console.log('_response.......', _response);
                    callback(_response.data);
                    dispatch({ type: Types.FETCH_ALL_QUERIES, payload: _response.data });
                }
                dispatch(Loader(false))
            })
    }
}

export const saveReasonForClose: any = (payload: any, callback: any) => {
    const url = subjects.queryListingModule.saveReasonForClose
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload
        })
            .then((response: any) => {
                if (callback) {
                    console.log('_response.......', response);
                    callback(response.data);
                    // dispatch({ type: Types.FETCH_ALL_QUERIES, payload: response.data });
                }
                dispatch(Loader(false))
            })
    }
}

export const addReasonForClose: any = (payload: any, callback: any) => {
    const url = subjects.queryListingModule.saveResolutionType
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload
        })
            .then((response: any) => {
                if (callback) {
                    console.log('_response.......', response);
                    callback(response.data);
                }
                dispatch(Loader(false))
            })
    }
}

export const downloadQueries: any = (payload: any, callback: any) => {
    const url = subjects.queryListingModule.download
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload
        })
            .then((response: any) => {
                if (callback) {
                    console.log('_response.......', response);
                    callback(response.data);
                }
                dispatch(Loader(false))
            })
    }
}

export const fetchVisitsByStudyId: any = (studyId: any, callback: any) => {
    const url = `${subjects.queryListingModule.visitsByStudyId}?studyId=${studyId}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data);
                    // dispatch({ type: Types.GET_ALL_VISITS_BY_STUDY_ID, payload: response.data });
                    dispatch(Loader(false))
                }
            })
    }
}

export const fetchQueryByQueryId: any = (queryId: any, callback: any) => {
    const url = `${subjects.queryListingModule.fetch}/${queryId}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data);
                    dispatch(Loader(false))
                }
            })
    }
}

export const fetchSitesByStudyId: any = (studyId: any, callback: any) => {
    const url = `${subjects.queryListingModule.sitesByStudyId}?studyId=${studyId}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data);
                    dispatch(Loader(false))
                }
            })
    }
}

export const fetchFormsByStudyId: any = (studyId: any, callback: any) => {
    const url = `${subjects.queryListingModule.formsByStudyId}?studyId=${studyId}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data);
                    dispatch(Loader(false))
                }
            })
    }
}

export const fetchSubjectVisitIdById: any = (payload: any, callback: any) => {
    const url = `${subjects.visits.getById}?subjectVisitId=${payload}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
            data: payload,
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data);
                    dispatch(Loader(false));
                }
            })
    }
}

export const fetchSubjectIDById: any = (payload: any, callback: any) => {
    const url = `${subjects.queryListingModule.getBySubjectId}?subjectId=${payload}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
            data: payload,
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data);
                    dispatch(Loader(false));
                }
            })
    }
}

export const fetchSubjectFormIDById: any = (payload: any, callback: any) => {
    const url = `${subjects.queryListingModule.getBySubjectFormId}?subjectFormId=${payload}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
            data: payload,
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data);
                    dispatch(Loader(false));
                }
            })
    }
}