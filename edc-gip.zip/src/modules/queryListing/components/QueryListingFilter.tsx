import React from "react";
import SelectField from "../../../common/selectField/SelectField";
import { configDataType } from "../../../actions/actions";
import { Types } from "../reducers/Types";
import { useDispatch, useSelector } from 'react-redux';
import { fetchAndFilterQueries, fetchFormsByStudyId, fetchSitesByStudyId, fetchVisitsByStudyId } from "../actions/action"; 
import { queriesModel } from "../constants/modal";


function QueryListingFilter() {
    const dispatch = useDispatch();
    const { queryTypes, queryStatus, queryPayload, visitsByStudyId, sitesByStudyId, formsByStudyId } = useSelector((state: any) => state.queriesList);
    const loaded = React.useRef(false);
    const { currentStudy } = useSelector((state: any) => state.application);
    const [queriesStatus, setQueriesStatus] = React.useState('');
    const [selectedVisits, setSelectedVisits] = React.useState([]);
    const [selectedSites, setSelectedSites] = React.useState([]);
    const [selectedForms, setSelectedForms] = React.useState([]);
    const [queryType, setQueryType] = React.useState('');
    const [QuerySubId, setQuerySubId] = React.useState('');
    const [queryId, setQueryId] = React.useState('');
    const [variableId, setVariableId] = React.useState('');
    const [filterQueryBtn, setFilterQueryBtn] = React.useState(true);

    React.useEffect(() => {

        if (!loaded.current) {
            dispatch(configDataType('QUERY_STATUS', (response: any) => {
                dispatch({ type: Types.GET_QUERY_STATUS, payload: response });
            }));
            dispatch(configDataType('QUERY_TYPE', (response: any) => {
                dispatch({ type: Types.GET_ALL_QUERIES_TYPE, payload: response });
            }));
            // dispatch(configDataType('RESOLUTION_TYPE', (response: any) => {
            //     dispatch({ type: Types.GET_REASON_FOR_CLOSE, payload: response });
            // }));
            dispatch(fetchVisitsByStudyId(currentStudy.id, (response: any) => {
                const options: any = []
                response?.map((item: any) => {
                    const option = {
                        label: item.visitName,
                        value: item.id
                    }
                    options.push(option)
                    return null;
                })
                console.log("...29", response, options);
                dispatch({ type: Types.GET_ALL_VISITS_BY_STUDY_ID, payload: options })
            }));
            dispatch(fetchSitesByStudyId(currentStudy.id, (response: any) => {
                const options: any = []
                response?.sites?.map((item: any) => {
                    const option = {
                        label: item.siteName,
                        value: item.id
                    }
                    options.push(option)
                    return null;
                })
                console.log("..53", response);
                dispatch({ type: Types.GET_ALL_SITES_BY_STUDY_ID, payload: options })
            }));

            dispatch(fetchFormsByStudyId(currentStudy.id, (response: any) => {
                const options: any = []
                response?.map((item: any) => {
                    const option = {
                        label: item.formName,
                        value: item.id
                    }
                    options.push(option)
                    return null;
                })
                console.log("..65", response);
                dispatch({ type: Types.GET_ALL_FORMS_BY_STUDY_ID, payload: options })
            }));
            loaded.current = true
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onChangeSitesHandler = (e: any) => {
        const payload = { ...{}, ...queryPayload }
        // const _id: any = []
        // const selectedSite: any = []
        // e?.forEach((site: any) => {
        //     console.log(site.value, "168.......")
        //     _id.push(site.value)
        //     selectedSite.push(site)
        // })
        // payload.visitName = _id
        // setSelectedSites(selectedSite);
        const _value = e?.label?.toString();
        setSelectedSites(e);
        setFilterQueryBtn(false);
        console.log("...85", e);
        payload.siteName = _value
        dispatch({ type: Types.QUERY_LIST, payload });
    }

   

    const onQueryTypeChange = (e: any) => {
        const _paylaod = { ...{}, ...queryPayload }
        // _paylaod.queryType = parseInt(e.target.value);
        _paylaod.queryType = e.target.value;
        setQueryType(e.target.value);
        setFilterQueryBtn(false);
        dispatch({ type: Types.QUERY_LIST, payload: _paylaod });
    }

    const onQueryStatusChange = (e: any) => {
        const _paylaod = { ...{}, ...queryPayload }
        // _paylaod.statusId = parseInt(e.target.value);
        setQueriesStatus(e.target.value);
        _paylaod.queryStatus = e.target.value;
        setFilterQueryBtn(false);
        dispatch({ type: Types.QUERY_LIST, payload: _paylaod });
    }

    const onChangeFormHandler = (e: any) => {
        const payload = { ...{}, ...queryPayload }
        // const _id: any = []
        // const selectedForm: any = []
        // e?.forEach((form: any) => {
        //     console.log(form.value, "168.......")
        //     _id.push(form.value)
        //     selectedForm.push(form)
        // })
        // payload.visitName = _id
        // setSelectedForms(selectedForm);
        const _value = e?.label?.toString();
        setSelectedForms(e);
        payload.formName = _value;
        setFilterQueryBtn(false);
        dispatch({ type: Types.QUERY_LIST, payload });
    }

    const onFilterQueries = (e: any) => {
        e.preventDefault();
        const _paylaod = { ...{}, ...queryPayload }
        console.log(".._paylaod", _paylaod);
        dispatch(fetchAndFilterQueries(_paylaod, (response: any) => {
            console.log("...141", response)
            dispatch({ type: Types.FETCH_ALL_QUERIES, payload: response });
        }));
    }

    const onClearFilterQueries = (e: any) => {
        // let _paylaod = { ...queryPayload, limit: 10, offset: 0 }
        e.preventDefault();
        setQueryType('');
        setQuerySubId('');
        setSelectedForms([]);
        setSelectedSites([]);
        setSelectedVisits([]);
        setQueryType('');
        setVariableId('');
        setQueryId('');
        setFilterQueryBtn(true);
        setQueriesStatus('');
        dispatch(fetchAndFilterQueries(queriesModel, (response: any) => {
            dispatch({ type: Types.FETCH_ALL_QUERIES, payload: response });
        }));
        dispatch({ type: Types.QUERY_LIST, payload: queriesModel });
    }

    const onChangeVisitHandler = (e: any) => {
        const payload = { ...{}, ...queryPayload }
        // const _id: any = []
        // const selectedVisit: any = []
        // e?.forEach((visit: any) => {
        //     console.log(visit.value, "168.......")
        //     _id.push(visit.value)
        //     selectedVisit.push(visit)
        // })
        // setSelectedVisits(selectedVisit);
        const _value = e?.label?.toString();
        payload.visitName = _value;
        setSelectedVisits(e);
        setFilterQueryBtn(false);
        console.log("...164", payload)
        dispatch({ type: Types.QUERY_LIST, payload });
    }

    const onSubjectIdChange = (e: any) => {
        setQuerySubId(e.target.value);
        setFilterQueryBtn(false);
    }
    const onQueryIdChange = (e: any) => {
        setQueryId(e.target.value);
        setFilterQueryBtn(false);
    }
    const onVariableIdChange = (e: any) => {
        setVariableId(e.target.value);
        setFilterQueryBtn(false);
    }

    return (
        <div className="queryFilter">
            <div className="card queryCard">
                <h5 className="card-header queryTitle h5">Query Listing</h5>
                <div className="card-body">
                    <div className="container">
                        <form id="queryListingForm">
                            <div className="d-flex col-sm-12">
                                <div className="col-sm-3 px-3">
                                    <div className="">
                                        <label htmlFor="queryType" className="py-2">Query Type:</label>
                                        <select className="form-select" value={queryType} onChange={(e: any) => onQueryTypeChange(e)}>
                                            <option value=''>All Queries</option>
                                            {
                                                queryTypes?.QUERY_TYPE?.map((opt: any, i: any) => (
                                                    <option key={i} value={opt.name}>{opt.name}</option>
                                                ))
                                            }
                                        </select>
                                    </div>
                                    <div className="">
                                        <label htmlFor="variableId" className="py-2">Variable ID:</label>
                                        <input className="form-control " id="variableId" name="variableId" value={variableId} onChange={(e) => onVariableIdChange(e)} placeholder="Enter Variable Id" />
                                    </div>
                                </div>
                                <div className="col-sm-3 px-3">
                                    <div className="">
                                        <label htmlFor="status" className="py-2">Status:</label>
                                        <select className="form-select" value={queriesStatus} onChange={(e: any) => onQueryStatusChange(e)} >
                                            <option value="">All Queries Status</option>
                                            {
                                                queryStatus?.QUERY_STATUS?.map((opt: any, i: any) => (
                                                    <option key={i} value={opt.name}>{opt.name}</option>
                                                ))
                                            }
                                        </select>
                                    </div>
                                    <div className="">
                                        <label htmlFor="visitName" className="py-2">Visits :</label>
                                        <SelectField
                                            id={"visitName"}
                                            defaultValue={"Select Visit"}
                                            isDisabled={false}
                                            isClearable={true}
                                            isSearchable={true}
                                            placeholder={"Visits"}
                                            value={selectedVisits}
                                            name={"VistsList"}
                                            onChange={(e: any) => { onChangeVisitHandler(e) }}
                                            options={visitsByStudyId}
                                            // isMulti={true}
                                            selectAll={true}
                                            menuPortalTarget={document.body}
                                            menuPosition={'fixed'}
                                        />
                                    </div>
                                </div>
                                <div className="col-sm-3 px-3">
                                    <div className="">
                                        <label htmlFor="subjectId" className="py-2" >Subject ID:</label>
                                        <input className="form-control " value={QuerySubId} id="subjectId" name="subjectId" placeholder="Enter Subject Id" onChange={(e) => onSubjectIdChange(e)} />
                                    </div>
                                    <div className="">
                                        <label htmlFor="siteName" className="py-2">Sites :</label>
                                        <SelectField
                                            id={"siteName"}
                                            defaultValue={"Select Sites"}
                                            isDisabled={false}
                                            isClearable={true}
                                            isSearchable={true}
                                            placeholder={"Sites"}
                                            value={selectedSites}
                                            name={"siteList"}
                                            onChange={(e: any) => { onChangeSitesHandler(e) }}
                                            options={sitesByStudyId}
                                            // isMulti={true}
                                            selectAll={true}
                                            menuPortalTarget={document.body}
                                            menuPosition={'fixed'}
                                        />
                                    </div>
                                </div>
                                <div className="col-sm-3 px-3">
                                    <div className="">
                                        <label htmlFor="queryId" className="py-2">Query ID:</label>
                                        <input className="form-control" value={queryId} onChange={(e) => onQueryIdChange(e)} id="queryId" name="queryId" placeholder="Enter Query Id" />
                                    </div>
                                    <div className="">
                                        <label htmlFor="formName" className="py-2">Forms :</label>
                                        <SelectField
                                            id={"formName"}
                                            defaultValue={"Select Form"}
                                            isDisabled={false}
                                            isClearable={true}
                                            isSearchable={true}
                                            value={selectedForms}
                                            placeholder={"Forms"}
                                            name={"formList"}
                                            onChange={(e: any) => { onChangeFormHandler(e) }}
                                            options={formsByStudyId}
                                            // isMulti={true}
                                            selectAll={true}
                                            menuPortalTarget={document.body}
                                            menuPosition={'fixed'}
                                        />
                                    </div>
                                </div>
                            </div>
                            <div className="d-flex justify-content-end pt-3">
                                <button type="submit" className=" btn btn-primary" disabled={filterQueryBtn} onClick={(e: any) => onFilterQueries(e)}>Apply</button>
                                <button type="submit" className=" btn btn-secondary clearQueryFilter" onClick={(e: any) => onClearFilterQueries(e)}>Clear</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default QueryListingFilter