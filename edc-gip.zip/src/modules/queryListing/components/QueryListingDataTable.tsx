import React from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import PageCount from "../../../common/pagecount/PageCount";
import CustomToolTip from "../../../components/CustomToolTip";
import VisibilityIcon from '@mui/icons-material/Visibility';
import FeedIcon from '@mui/icons-material/Feed';
import { useDispatch, useSelector } from 'react-redux';
import { Types as Type } from "../../../constants/Types";
import ViewQuery from "../../../common/viewQueries/ViewQuery";
import { fetchReasonsToClose } from "../../subjects/modules/subjectsList/components/dynamicForms/actions/actions";
import { Types } from "../reducers/Types";
import ApiIcon from '@mui/icons-material/Api';
import { IconButton } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { downloadQueries, fetchAndFilterQueries, fetchQueryByQueryId, fetchSubjectFormIDById, fetchSubjectIDById, fetchSubjectVisitIdById, saveReasonForClose } from "../actions/action";
import CustomDialog from "../../../common/modals/CustomeDialog";
import CommonReasons from "./CommonReasons";
import { dataEntryNavigation, toastAlert } from "../../../actions/actions";
import { downloadExcel } from "../constants/modal";

function QueryListingDataTable() {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const { page, reasonsToClose, currentStudy, currentUser } = useSelector((state: any) => state.application);
    const { queryPayload, allQueries, reasonToClosePayload } = useSelector((state: any) => state.queriesList);
    const loaded = React.useRef(false);
    const [openReasonToCloseDialog, setOpenReasonToCloseDialog] = React.useState(false);
    const [pageClick, setpageChange] = React.useState(false);
    const [disableBtn, setDisableBtn] = React.useState(true);
    const [errorMsg, setErrorMsg] = React.useState(false);

    React.useEffect(() => {
        if (!loaded.current) {
            const _payload = {
                ...queryPayload, limit: 10,
                offset: 0,
            }
            dispatch(fetchAndFilterQueries(_payload, (response: any) => {
                console.log('199', response);
                dispatch({ type: Types.FETCH_ALL_QUERIES, payload: response });
                // setUser(response.queries);
            }));
            dispatch({ type: Types.QUERY_LIST, payload: _payload })
            dispatch(fetchReasonsToClose());
            loaded.current = true
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

//this is page-count function
    const onPageCountChange = (e: any) => {
        const _payload = { ...queryPayload, limit: e.target.value }
        dispatch({ type: Types.QUERY_LIST, payload: _payload });
        dispatch(fetchAndFilterQueries(_payload, (response: any) => {
            console.log('5444', response);
            dispatch({ type: Types.FETCH_ALL_QUERIES, payload: response })
            // setUser(response.queries);
        }));
    }

    //this is download excel function
    const onClickExcel = () => {
        let _arrya: any = []
        Object.keys(queryPayload).forEach(function (key, index) {
            if (queryPayload[key] !== null) {
                if (key !== 'limit' && key !== 'offset') {
                    _arrya.push(key)
                }
            }
        });
        let _paylaod = { ...downloadExcel, studyId: currentStudy.id, userId: currentUser.id, reportName: 'QueryListing', searchColumnNames: _arrya.length > 0 ? _arrya : null }
        console.log("...6666", _arrya);
        dispatch(downloadQueries(_paylaod, (response: any) => {
            console.log("...66excel", response);
            if (response.status !== 'error') {
                dispatch(toastAlert({
                    status: 1, message: `${response.msg}`, open: true
                }));
            }
        }));
    }

    //this is open View Query function
    const handleOpenDialog = (rowData: any) => {
        dispatch({ type: Type.OPEN_CUSTOM_DIALOG, payload: true });
        dispatch({ type: Type.SUBJECT_FIELDID, payload: rowData.subjectFieldDataId });
        dispatch(fetchQueryByQueryId(rowData.queryId, (response: any) => {
            dispatch({ type: Type.GET_VIEW_QUERY_DATA, payload: response });
        }))
    }

    //this is navigation function which navigate to data-entry form
    const handleViewForm = (rowData: any) => {
        const _paylaod = { ...{}, ...page };
        _paylaod.currentTab = '3'
        _paylaod.currentSubjectId = rowData.subjectId
        _paylaod.currentVisitId = rowData.subjectVisitId
        _paylaod.currentFormId = rowData.subjectFormsId
        _paylaod.tabs[1].isActive = true
        _paylaod.tabs[2].isActive = true
        _paylaod.tabs[3].isActive = true
        dispatch(fetchSubjectVisitIdById(rowData.subjectVisitId, (visitResponse: any) => {
            _paylaod.selectedVisit = visitResponse
            dispatch(fetchSubjectFormIDById(rowData.subjectFormsId, (formResponse: any) => {
                _paylaod.selectedForm = formResponse
                dispatch(fetchSubjectIDById(rowData.subjectId, (subjectRes: any) => {
                    _paylaod.selectedSubject = subjectRes
                    dispatch(dataEntryNavigation(_paylaod));
                    console.log("...266page", _paylaod, rowData);
                    navigate("../subjects");
                }));
            }));
        }));
    }

    //Action template for view query and navigate to data-entry form
    const actionsTemplate = (rowData: any) => {
        return (
            <div className='d-flex justify-content-start' onClick={(e) => e.stopPropagation()}>
                <CustomToolTip title="View query">
                    <VisibilityIcon sx={{ fontSize: '13px' }} onClick={() => handleOpenDialog(rowData)} />
                </CustomToolTip>
                <span> {' '}|{' '} </span>
                <CustomToolTip title="View form">
                    <FeedIcon sx={{ fontSize: '13px' }} onClick={() => handleViewForm(rowData)} />
                </CustomToolTip>
            </div>
        )
    }

    //this is onChnage function for reason to close (dropdown) 
    const onChangeReasonToClose = (e: any, rowData: any) => {
        e.stopPropagation();
        let _queries = { ...{}, ...allQueries }
        allQueries.queries.map((element: any, eleIndex: number) => {
            if (rowData.queryId === element.queryId) {
                _queries.queries[eleIndex].reasonForClose = e.target.value
            }
            console.log("...116", element)
            return null
        });
        dispatch({ type: Types.FETCH_ALL_QUERIES, payload: _queries });
    }

    //this is reason for close dropdown in table
    const reasonForCloseTemplate = (rowData: any) => {
        console.log('rowdata...1.', rowData);
        let temp = { ...{}, ...allQueries }
        let _reasonId: any = false
        temp.queries.map((i: any) => {
            if (i.queryId === rowData.queryId) {
                if (errorMsg && rowData.isChecked && !rowData.reasonForClose) {
                    _reasonId = true
                }
            }
            return null
        })
        return (
            <div onClick={(e) => e.stopPropagation()}>
                <select
                    // className="form-select reasonsList"
                    className={_reasonId ? "form-select reasonNotSelected " : "form-select reasonsList"}
                    onChange={(e: any) => onChangeReasonToClose(e, rowData)}
                    disabled={!rowData.isChecked}
                    value={rowData.reasonForClose ? rowData.reasonForClose : ''}
                >
                    <option value="">Select One</option>
                    {
                        reasonsToClose && reasonsToClose?.map((opt: any, i: any) => (
                            <option key={i} value={opt.name}>{opt.name}</option>
                        ))
                    }
                </select>
                {_reasonId && <span className=" ms-2 text-danger">{"select a reason"}</span>}
            </div>
        )
    }

    //this is on change function for check-boxs in columns
    const handleChange = (e: any, rowData: any) => {
        const { checked } = e.target;
        let tempUser = { ...{}, ...allQueries }
        // onChange for header check-box
        if (e.target.name === "allSelect") {
            tempUser?.queries?.map((element: any, eleIndex: number) => {
                if (!element.disable) {
                    element.closeQuery = checked
                    element.isChecked = checked
                }
                return null
            })
        } else {
            // onChange for columns check-box
            tempUser?.queries?.map((element: any, eleIndex: number) => {
                if (element.queryId === rowData.queryId) {
                    element.closeQuery = checked
                    element.isChecked = checked
                }
                return null
            });
        }
        dispatch({ type: Types.FETCH_ALL_QUERIES, payload: tempUser });
    }

    //close template
    const closedQueryTemplate = (rowData: any) => {
        return (
            <div>{rowData.closeQuery}
                <input
                    type='checkBox'
                    name={rowData.closeQuery}
                    // defaultChecked={rowData.disable || false}
                    // checked={rowData.isChecked || false}
                    checked={rowData.closeQuery && !rowData.disable}
                    disabled={rowData.disable}
                    onChange={(e) => handleChange(e, rowData)}
                />
            </div>
        )
    }

// this function is to display query id's in column
    const queryIdTemplate = (rowData: any) => {
        return (
            <div>
                <div>{rowData?.queryId}</div>
            </div>
        )
    }

    //this function is to update the common reason to close 
    const onClickAllReasons = () => {
        setOpenReasonToCloseDialog(true);
    }

    //this function is reason for close in column header
    const actionHeaderTemplate = (rowData: any) => {
        return (
            <React.Fragment>
                <div className="d-flex">
                    Reason For Close<IconButton disabled={!getChecked()}><ApiIcon onClick={() => onClickAllReasons()} ></ApiIcon></IconButton>
                </div>
            </React.Fragment>
        )
    }

    // this function is to close reason popup
    const handleClose = () => {
        setOpenReasonToCloseDialog(false);
        setDisableBtn(true);
    }

    //this is pagination function
    const onPage = (event: any) => {
        if ((event.page > 0) || (pageClick && event.page === 0)) {
            const _payload = { ...queryPayload, offset: event.first }
            dispatch(fetchAndFilterQueries(_payload, (response: any) => {
                dispatch({ type: Types.FETCH_ALL_QUERIES, payload: response });
            }));
            dispatch({ type: Types.QUERY_LIST, payload: _payload })
            setpageChange(true)
        }
    }

    const isCellSelectable = (event: any) => {
        // event.data.field === 'closeQuery' && event.data.value === true ? false : true
        console.log('event.data......', event.data)
        return event.data.disable ? false : true
    }


    // this function is to set the checked property to check-box in column heade 
    const getChecked = () => {
        let _flag = true
        allQueries?.queries?.map((i: any) => {
            console.log('test.....', i)
            if (!i.disable && !i.closeQuery) {
                console.log('test.....1')
                _flag = false
            }
            return null
        })
        if (_flag) {
            _flag = !(allQueries?.queries?.every((i: any) => i.disable && i.closeQuery))
        }
        return _flag
    }

    // this function is to diplay check-box in header of column
    const closedQueryHeader = (rowData: any) => {
        return (
            <div className="d-flex ">
                <span className="pt-2" > Closed</span >
                <div className="px-2"><input
                    name="allSelect"
                    type='checkBox'
                    checked={getChecked()}
                    // disabled={allQueries?.queries?.filter((i: any) => !i.closeQuery).length >= 1 ? false : true}
                    // checked={allQueries?.queries?.filter((i: any) => i.isChecked !==true && i.queryStatus === "Closed").length >= 1 }
                    onChange={(e) => handleChange(e, rowData)}
                />
                </div>
            </div>
        )
    }

// this is to close all quries in bulk
    const onSubmitReasonHandler = () => {
        let _paylaod = [...[], ...reasonToClosePayload];
        let _queryPayload = { ...{}, ...queryPayload }
        dispatch(saveReasonForClose(_paylaod, (queryResponse: any) => {
            dispatch(fetchAndFilterQueries(_queryPayload, (response: any) => {
                dispatch({ type: Types.FETCH_ALL_QUERIES, payload: response });
                setOpenReasonToCloseDialog(false)
            }));
        }));
    }

    // close query function on submit
    const onSingleCloseQuery = () => {
        let reasonToClose: any = []
        let singleCloseQuery = { ...{}, ...allQueries }
        singleCloseQuery?.queries?.map((element: any, eleIndex: number) => {
            if (element.queryStatus !== "Closed" && element.isChecked) {
                if (element.closeQuery && element.reasonForClose) {
                    reasonToClose.push({
                        queryId: element.queryId,
                        reasonForClose: element.reasonForClose,
                        closeQuery: true
                    });
                    dispatch(saveReasonForClose(reasonToClose, (queryResponse: any) => {
                        if (queryResponse.status === 'error') {
                            dispatch(toastAlert({
                                status: 2, message: `${queryResponse.errorMessage}`, open: true
                            }));
                        } else {
                            dispatch(fetchAndFilterQueries({ ...queryPayload }, (response: any) => {
                                dispatch({ type: Types.FETCH_ALL_QUERIES, payload: response });
                            }));
                            setErrorMsg(false);
                        }
                    }));
                }
            } else {
                setErrorMsg(true);
            }
            return null
        });
    }

    return (
        <React.Fragment>
            <div className='queriesList'>
                {/* page count  */}
                <div className=" d-flex justify-content-between mt-3 controls-container">
                    <div className=" d-flex">
                        <PageCount onChange={(e: any) => onPageCountChange(e)} />
                        {/* download excel */}
                        <div className="ms-2 mt-1">
                            <button className="btn-eoutlined-secondary" onClick={() => onClickExcel()}>Download Excel</button>
                        </div>
                    </div>
                </div>
                {<ViewQuery />}
                <CustomDialog
                    maxWidth={'sm'}
                    open={openReasonToCloseDialog}
                    onClose={handleClose}
                    title={"Reason To Close"}
                    disabled={disableBtn}
                    onSubmitHandler={onSubmitReasonHandler}
                    actionType='submit'
                >
                    <CommonReasons setDisableBtn={setDisableBtn} />
                </CustomDialog>
                {/* Data-table to display all quries */}
                <div className='mt-3 queryTable'>
                    {allQueries && <DataTable scrollable
                        value={allQueries && allQueries.queries}
                        scrollHeight="300px"
                        responsiveLayout="scroll"
                        selectionMode="single"
                        lazy
                        emptyMessage="No Queries Are Available To Display"
                        rows={queryPayload?.limit}
                        paginator={allQueries.queries && allQueries?.searchCount > queryPayload?.limit ? true : false}
                        totalRecords={allQueries && allQueries?.searchCount}
                        first={queryPayload?.offset}
                        stripedRows={true}
                        onPage={onPage}
                        // // selectionMode="multiple" selection={selectedQuery}
                        // isDataSelectable={() => { return false }}
                        isDataSelectable={isCellSelectable}
                    // // onSelectionChange={(e: any) => { onClickClosedQueryCheckbox(e) }}
                    >
                        <Column body={queryIdTemplate} header="Query ID" ></Column>
                        <Column field="subjectId" header="Subject ID" ></Column>
                        <Column field="siteName" header="Site Name" ></Column>
                        <Column field="visitName" header="Visit Name" ></Column>
                        <Column field="formName" header="Form Name" ></Column>
                        <Column field="userName" header="User Name" ></Column>
                        <Column field="role_name" header="Role Name" ></Column>
                        <Column field="days" header="Day" ></Column>
                        <Column field="queryStatus" header="Status" ></Column>
                        {/* <Column selectionMode="multiple" body={closedQueryTemplate} header="Closed"  ></Column> */}
                        <Column body={closedQueryTemplate} header={closedQueryHeader}  ></Column>
                        <Column body={reasonForCloseTemplate} header={actionHeaderTemplate}></Column>
                        <Column field="queryType" header="Query Type" ></Column>
                        <Column header='Actions' body={actionsTemplate}></Column>
                    </DataTable>}
                </div>
            </div>
            <div className="d-flex justify-content-end p-1 w-100">
                <button type="submit" className="btn btn-primary" disabled={(allQueries?.queries?.every((i: any) => !i.isChecked))} onClick={() => onSingleCloseQuery()}>Submit</button>
            </div>

        </React.Fragment>
    )
}

export default QueryListingDataTable;