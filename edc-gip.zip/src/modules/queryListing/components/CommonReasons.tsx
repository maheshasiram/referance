import React from "react";
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import { useDispatch, useSelector } from 'react-redux';
import { fetchReasonsToClose } from "../../subjects/modules/subjectsList/components/dynamicForms/actions/actions";
import { Types as mainTypes } from "../../../constants/Types";
import { Types } from "../reducers/Types";

function CommonReasons(props: any) {
    const { setDisableBtn } = props
    const { allQueries } = useSelector((state: any) => state.queriesList);
    const { reasonsToClose } = useSelector((state: any) => state.application);
    const dispatch = useDispatch();
    const loaded = React.useRef(false);
    const [reasons, setReasons] = React.useState<any>([])

    React.useEffect(() => {
        if (!loaded.current) {
            dispatch(fetchReasonsToClose());
            loaded.current = true
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onReasonToClose = (e: any) => {
        let _data: any = { ...{}, ...allQueries }
        setReasons([]);
        _data.queries.filter((i: any) => {
            if (i.queryStatus !== "Closed") {
                console.log("...29", i)
                reasons.push({
                    queryId: i.queryId,
                    reasonForClose: e.target.value,
                    closeQuery: true
                })
            }
            return null
        });
        dispatch({ type: Types.REASON_FOR_CLOSE, payload: reasons });
        console.log("...34", e.target.value, reasons);
        setDisableBtn(false);
    }

    const onClickAddReason = (e: any) => {
        // e.preventDefault();
        dispatch({ type: mainTypes.OPEN_ADD_REASON_DIALOG, payload: true })
    }

    return (
        <React.Fragment>
            <div className="pb-3 pt-2">
                <div className="d-flex">
                    <div className=""><label className="selectReasonLabel">Select The Reason To Close The Query</label></div>
                    <div className="pt-2 px-2"><AddCircleOutlineIcon className="addReasonIcon" onClick={(e) => onClickAddReason(e)}></AddCircleOutlineIcon></div>
                </div>
                <select className="form-select reasonsList"
                    onChange={(e: any) => onReasonToClose(e)}
                >
                    <option value="">Select One</option>
                    {
                        reasonsToClose && reasonsToClose?.map((opt: any, i: any) => (
                            <option key={i} value={opt.name}>{opt.name}</option>
                        ))
                    }
                </select>
            </div>
        </React.Fragment>
    )
}

export default CommonReasons