import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { Formik, Field, Form, ErrorMessage, FieldArray } from 'formik';
import AddCircleOutlineOutlined from "@mui/icons-material/AddCircleOutlineOutlined";
import RemoveCircleOutlineIcon from '@mui/icons-material/RemoveCircleOutline';
import CustomDialog from "../../../common/modals/CustomeDialog";
import { Types as mainTypes } from "../../../constants/Types";
import { Types } from "../reducers/Types";
import { addReasonForClose } from "../actions/action";
import { fetchReasonsToClose } from "../../subjects/modules/subjectsList/components/dynamicForms/actions/actions";

function AddReasonToClose(props: any) {
    const dispatch = useDispatch();
    const [reasonsToAdd, setReasondToAdd] = React.useState('');
    const [addRemoveMsg, setaddRemoveMsg] = React.useState('');
    const { addReasonToClose, openAddReasonDialog } = useSelector((state: any) => state.application);
    const { form } = props;
    const [btnDisable, setBtnDisable] = React.useState(true)

    console.log("...13", form);
    const onAddReasonChange = (e: any, setFieldValue: any, setFieldTouched: any, index: number) => {
        setReasondToAdd(e.target.value);
        setFieldTouched(`addReason.${index}.name`, true)
        setFieldValue(`addReason.${index}.name`, e.target.value)
        setaddRemoveMsg("");
        setBtnDisable(false);
    }

    const onVlidateAddReason = (values: any, arrayHelpers: any, type: any) => {
        let emptyField = false;
        const sameReason: any = [];
        console.log("...2333", values, arrayHelpers);
        values.addReason.map((item: any) => {
            emptyField = item.name !== '' ? false : true;
            console.log("item === reasonsToAdd", item, emptyField)
            if (item.name === reasonsToAdd) {
                sameReason.push(item)
            }
            return null;
        })
        if (!emptyField) {
            if (sameReason.length > 1) {
                setaddRemoveMsg("You can not add same reasons");

            } else {
                setaddRemoveMsg("");
                type === 'addField' ? arrayHelpers.push({ name: '' }) : onSubmitHandler(values);
            }
        } else {
            setaddRemoveMsg("Field can't be empty");

        }
    }

    const onRemoveField = (e: any, arrayHelpers: any, index: number) => {
        arrayHelpers.remove(index)
        setaddRemoveMsg("")
    }

    const onSubmitHandler = (values: any) => {
        let _paylaod = [...[], ...values.addReason]
        console.log("...values", _paylaod);
        dispatch(addReasonForClose(_paylaod, (response: any) => {
            console.log("...62", response);
            dispatch(fetchReasonsToClose());
            dispatch({ type: mainTypes.OPEN_ADD_REASON_DIALOG, payload: false })
        }))
    }

    const handleClose = () => {
        dispatch({ type: mainTypes.OPEN_ADD_REASON_DIALOG, payload: false })
        dispatch({ type: Types.REASON_FOR_CLOSE, payload: [] })
        // setBtnDisable(true);
    }

    return (
        <React.Fragment>
            <CustomDialog
                maxWidth={'xs'}
                open={openAddReasonDialog}
                onClose={handleClose}
                title={"Add Reason To Close"}
                form={'AddReasonToClose'}
                actionType='submit'
                disabled={btnDisable}
                onSubmitHandler={() => { }}
            >
                <div>
                    <Formik
                        enableReinitialize={true}
                        initialValues={addReasonToClose}
                        onSubmit={(values: any) => {
                            onVlidateAddReason(values, '', '');
                        }}
                    >
                        {({ values, setFieldTouched, setFieldValue, errors }) => (
                            <Form id='AddReasonToClose'>
                                <div>
                                    {<>{console.log("...7111", values, addReasonToClose)}</>}
                                    <FieldArray
                                        name="addReason"
                                        render={(arrayHelpers) => {
                                            const allReasons = values.addReason
                                            console.log('...arrayHelpers', arrayHelpers)
                                            return (
                                                <div className="mx-1">
                                                    <div className="d-flex">
                                                        <label id='label'>Add Reason To Close</label>
                                                        <AddCircleOutlineOutlined
                                                            className='text-primary addReasonIcon mx-2 mb-1'
                                                            fontSize='small'
                                                            onClick={() => {
                                                                onVlidateAddReason(values, arrayHelpers, 'addField')
                                                            }}
                                                        />
                                                        <div>
                                                            {addRemoveMsg && <span className="" style={{ color: 'red', marginLeft: 10 }}>{addRemoveMsg}</span>}
                                                        </div>
                                                    </div>

                                                    {allReasons &&
                                                        allReasons.map((data: any, index: number) => (
                                                            <div key={index} className="d-flex mb-2">
                                                                <div className="col-12">
                                                                    <Field
                                                                        name={`addReason.${index}.name`}
                                                                        value={values.addReason[index].name}
                                                                        className="form-control"
                                                                        placeholder={"Add Reason"}
                                                                        onChange={(e: any) => onAddReasonChange(e, setFieldValue, setFieldTouched, index)}
                                                                    >
                                                                    </Field>
                                                                    {!addRemoveMsg &&
                                                                        <div className="text-danger"><ErrorMessage name='addReason' /></div>
                                                                    }
                                                                </div>
                                                                <div>
                                                                    {allReasons.length > 1 && <RemoveCircleOutlineIcon
                                                                        sx={{ cursor: 'pointer' }}
                                                                        color='error'
                                                                        className="mt-1"
                                                                        onClick={(e: any) => onRemoveField(e, arrayHelpers, index)}
                                                                    />}
                                                                </div>
                                                            </div>
                                                        ))
                                                    }
                                                </div>
                                            )
                                        }}
                                    ></FieldArray>
                                </div>
                            </Form>
                        )}
                    </Formik>
                </div>
            </CustomDialog>
        </React.Fragment>
    )
}

export default AddReasonToClose;