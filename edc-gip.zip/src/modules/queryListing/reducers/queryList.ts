
import { queriesModel, reasonToCloseModal, addReasonToCloseModal } from "../constants/modal";
import { Types } from "./Types";

const initialState = {
    queryTypes: null,
    queryStatus: null,
    reasonForClose: null,
    queryPayload: queriesModel,
    allQueries: [],
    fetchAllForm: [],
    reasonToClosePayload: reasonToCloseModal,
    addReasonToClose: addReasonToCloseModal,
    visitsByStudyId: [],
    sitesByStudyId: [],
    formsByStudyId: [],
}
export const queriesList = (state = initialState, action: any) => {
    switch (action.type) {
        case Types.GET_QUERY_STATUS:
            return { ...state, queryStatus: action.payload }
        case Types.GET_ALL_QUERIES_TYPE:
            return { ...state, queryTypes: action.payload }
        case Types.GET_REASON_FOR_CLOSE:
            return { ...state, reasonForClose: action.payload }
        case Types.QUERY_LIST:
            console.log("...266", action.payload);
            return { ...state, queryPayload: action.payload }
        case Types.FETCH_ALL_QUERIES:
            return { ...state, allQueries: action.payload }
        case Types.FETCH_ALL_FORMS:
            return { ...state, fetchAllForm: action.payload }
        case Types.REASON_FOR_CLOSE:
            console.log("...34444", action.payload);
            return { ...state, reasonToClosePayload: action.payload }
        case Types.GET_ALL_VISITS_BY_STUDY_ID:
            return { ...state, visitsByStudyId: action.payload }
        case Types.GET_ALL_SITES_BY_STUDY_ID:
            return { ...state, sitesByStudyId: action.payload }
        case Types.GET_ALL_FORMS_BY_STUDY_ID:
            return { ...state, formsByStudyId: action.payload }
        default:
            return { ...state }
    }
}