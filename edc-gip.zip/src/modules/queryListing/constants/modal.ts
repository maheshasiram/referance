export const queriesModel = {
    limit: 10,
    offset: 0,
    queryId: null,
    queryType: null,
    visitName: null,
    formName: null,
    fieldName: null,
    siteName: null,
    ruleName: null,
    queryStatus: null,
    subjectId: null,
    variableId: null
}

export const reasonToCloseModal = {
    closeReason: [
        {
            queryId: 0,
            reasonForClose: "",
            closeQuery: true
        }
    ]
}

export const addReasonToCloseModal = {
    addReason: [{
        name: ''
    }]
}

export const downloadExcel = {
    studyId: 0,
    userId: 0,
    reportName: "",
    searchColumnNames: null
}
