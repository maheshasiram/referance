import React from 'react';
import './styles/queryListing.scss';
import '../studySetup/styles.scss';
import QueryListingFilter from "./components/QueryListingFilter";
import QueryListingDataTable from "./components/QueryListingDataTable";
import { useParams } from 'react-router-dom';

const QueryListing = () => {
    const params = useParams()
    console.log("...params", params);
    return (
        <React.Fragment>
            <div className='queryListing container'>
                <div className="d-flex sm-container">
                    <div className="page-header">
                        <h2>Query Listing</h2>
                    </div>
                </div>
                <QueryListingFilter />
                <QueryListingDataTable />
            </div>
        </React.Fragment >
    )
}
export default QueryListing;