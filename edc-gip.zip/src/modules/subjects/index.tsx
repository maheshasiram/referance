import React from 'react'
import SubjectsRoutes from './routes';

function SubjectsModule() {
    return (
        <React.Fragment>            
            <SubjectsRoutes/>
        </React.Fragment>
    )
}
export default SubjectsModule