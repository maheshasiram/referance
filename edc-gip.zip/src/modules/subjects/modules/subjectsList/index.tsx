import * as React from 'react';
import Box from '@mui/material/Box';
import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
import { useDispatch, useSelector } from 'react-redux';
import { Icons } from './components/DynamicComponent';
import { withStyles } from "@material-ui/core";
// import _ from "lodash";
import { dataEntryNavigation } from '../../../../actions/actions';
import { pageModal } from './constants/modal';
import Loader from '../../../../common/loader/Loader';
import _ from 'lodash';
import { Types } from './reducers/Types';

function SubjectsModule() {
  const dispatch = useDispatch()
  const { page } = useSelector((state: any) => state.application);
  const loaded = React.useRef(false);

  React.useEffect(() => {
    return () => {
      console.log('inside return......');
      if (loaded.current) {
        const payload: any = _.cloneDeep(pageModal);
        dispatch(dataEntryNavigation(payload));
      }
      loaded.current = true;
    }

  }, [dispatch])
  const handleChange = (event: React.SyntheticEvent, newValue: string) => {
    const payload: any = { ...{}, ...page };
    payload && payload.tabs.map((tab: any) => {
      tab.isActive = (parseInt(tab.index) > parseInt(newValue)) ? false : true;
      return null;
    })
    dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: null });
    payload.currentTab = newValue;
    dispatch(dataEntryNavigation(payload))
  };


  const CustomTab = withStyles({
    root: {
      textTransform: "none"
    }
  })(Tab);

  return (
    <Box sx={{ width: '100%', typography: 'body1' }} className='dataentry-module' >
      <React.Suspense fallback={<Loader />} >
        <TabContext value={page.currentTab}  >
          <Box sx={{ borderBottom: 1, borderColor: 'divider', height: '40px' }} className='tabs' >
            <TabList onChange={handleChange} aria-label="lab API tabs example" >
              {page.tabs.map((page: any, index: number) => {
                // const ICON = Icons[page.icon]
                if (page.isActive === true) {
                  return <CustomTab key={index} id={`customTab${page.label}`} iconPosition={'start'}
                    label={page.label} icon={Icons[page.icon]} value={page.index}
                  />
                }
                return null;
              })
              }
            </TabList>
          </Box>
          {
            page.tabs.map((Item: any, index: number) => {
              const Component = pageModal.tabs[index].ComponentPath
              return (<React.Fragment key={index}>
                {(Item.isActive === true) &&
                  <TabPanel key={index} value={Item.index} className={'formPage-' + Item.component}>
                    <Component {...Item} />
                  </TabPanel>
                }
              </React.Fragment>)
            })
          }
        </TabContext>
      </React.Suspense>
    </Box>
  );
}
export default SubjectsModule
