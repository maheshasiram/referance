export const stickyNotesData = {
    stickyNotes: [
        {
            "subid": 9,
            "count": 1,
            "studySubjectId": 9,
            "siteName": "A_5694",
            "label": "01-27",
            "subjectId": "01-27"
        },
        {
            "subid": 194,
            "count": 7,
            "studySubjectId": 194,
            "siteName": "A_5694",
            "label": "01115-ssxc",
            "subjectId": "01115-ssxc"
        }
    ],
    count: 2
}