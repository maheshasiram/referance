export const formstickyNotesData ={
    "stickyNotes": [
        {
            "repeatingForms": false,
            "count": 1,
            "formName": "NumaricCaliculation",
            "eventCRFId": 3713,
            "crfVersionId": 33,
            "url": "/InitialDataEntry?eventCRFId=3713"
        }
    ],
    "count": 1
}