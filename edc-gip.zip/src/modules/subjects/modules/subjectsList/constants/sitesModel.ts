export const sitesModel = [
    {
        "siteId": 9,
        "siteName": "Site 2"
    },
    {
        "siteId": 13,
        "siteName": "w234"
    },
    {
        "siteId": 14,
        "siteName": "dsf"
    },
    {
        "siteId": 15,
        "siteName": "A_1234"
    },
    {
        "siteId": 96,
        "siteName": "Site4"
    },
    {
        "siteId": 128,
        "siteName": "Apollo1"
    }
]