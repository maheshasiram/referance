import React from "react"
import { addVolunteerDataType, visitParamsDataType, volunteersDataType, addNoteTransactionDataType, notifyUsersDataType, notesDataTypes } from "./dataTypes"

export const pageModal = {
    currentTab: '0',
    currentSubjectId: 0,
    currentVisitId: 0,
    currentFormId: 0,
    tabs: [
        {
            label: 'Subjects',
            index: '0',
            isActive: true,
            icon: 'volunteers',
            component: 'volunteers',
            ComponentPath: React.lazy(() => import('../components/volunteers/Volunteers')),
            data: {
                selectedSubject: {},
                volunteers: {},
                openQuries: {},
                stickyNotes: {},
                sites: [],
                statusList: [],
                dataTableColumn: [
                    { header: 'Volunteer', field: 'volunteer' },
                    { header: 'Site Name', field: 'siteName' },
                    { header: 'Count', field: 'count' }
                ]
            },
            api: {
                url: '',
                openQuries: '',
                stickyNotes: ''
            }
        },
        {
            label: 'Visits',
            index: '1',
            isActive: false,
            icon: 'visits',
            component: 'visits',
            ComponentPath: React.lazy(() => import('../components/visits/Visits')),
            data: {
                visits: [],
                openQuries: {},
                stickyNotes: {},
                unscheduledFormsList: [],
                dataTableColumn: [
                    { header: 'Visit Name', field: 'visitName' },
                    { header: 'Count', field: 'count' }
                ]
            },
            params: {},
            api: {
                url: '',
                openQuries: '',
                stickyNotes: ''
            }
        },
        {
            label: 'Forms',
            index: '2',
            isActive: false,
            icon: 'forms',
            component: 'forms',
            ComponentPath: React.lazy(() => import('../components/forms/Forms')),
            data: {
                forms: null,
                openQuries: {},
                stickyNotes: {},
                dataTableColumn: [
                    { header: 'Form Name', field: 'formName' },
                    { header: 'Count', field: 'count' }
                ]
            },
            params: {},
            api: {
                url: '',
                openQuries: '',
                stickyNotes: ''
            }
        },
        {
            label: 'DynamicForms',
            index: '3',
            isActive: false,
            icon: 'dataentry',
            component: 'dynamicForms',
            ComponentPath: React.lazy(() => import('../components/dynamicForms')),
            data: {
                dynamicFormData: null
            },
            params: {},
            api: {}
        }
    ]
}

export const addVolunteerModel: addVolunteerDataType = {
    id: 0,
    subjectId: "",
    subjectEnrollmentDate: "",
    studyId: 0,
    siteId: 0,
    siteName: "",
    userId: 0,
    status: true,
    subjectStatusId: 0,
    subjectStatus: "",
    subjectStatusCode: ""
}

export const volunteersModel: volunteersDataType = {
    limit: 10,
    offset: 0,
    studyId: 0,
    userId: 0,
    siteNameSearch: "",
    subjectStatusCode: "",
    subjectId: ""
}

export const visitParamModal: visitParamsDataType = {
    subjectId: 0,
    visitName: "",
    visitStatusCode: "",
    limit: 10,
    offset: 0
}

export const addQueryModal = {
    // id: 0,
    subjectFieldId: 0,
    comments: '',
    respond: true,
    assignTo: 0,
    type: null,
    status: null,
    resolutionType: {
        id: 0,
        name: "",
    },
    request: null,
    ruleId: 0,
}

export const notifyUsersModal: notifyUsersDataType = [
    {
        id: 0,
        userId: 0,
        userName: "string"
    }
]
export const addNoteTransactionModal: addNoteTransactionDataType = {

    id: 0,
    userId: 0,
    fieldId: 0,
    userName: "",
    title: "",
    comments: "",
    acknowledge: true,
    notifyUsers: notifyUsersModal,

}
export const notesModel: notesDataTypes = {
    id: 0,
    userName: '',
    fieldId: 0,
    userId: 0,
    title: '',
    comments: '',
    notifyUsers: [{ UserId: 0, id: 0, userName: '' }],
    acknowledge: true
}

export const addDeviationModel = {
    id: 0,
    subjectFieldDataId: 0,
    userId: 0,
    deviationTypeCode: "",
    categoryCode: "",
    description: "",
    status: true
}
