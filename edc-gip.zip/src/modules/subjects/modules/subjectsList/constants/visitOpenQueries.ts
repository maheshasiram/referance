export const visitOpenQueries = {

    "openQueries": [
        {
            "visitName": "Visit cycle-1 day-1",
            "eventId": 2180,
            "eventName": " Visit cycle-1 day-1",
            "count": 2
        },
        {
            "visitName": " Visit cycle-1 day-2",
            "eventId": 2180,
            "eventName": "  Visit cycle-1 day-2",
            "count": 1
        },
        {
            "visitName": "  Visit cycle-1 day-3",
            "eventId": 2180,
            "eventName": "  Visit cycle-1 day-3",
            "count": 2
        },
        {
            "visitName": "  Visit cycle-1 day-4",
            "eventId": 2180,
            "eventName": "  Visit cycle-1 day-4",
            "count": 4
        },
        {
            "visitName": "  Visit cycle-1 day-5",
            "eventId": 2180,
            "eventName": "  Visit cycle-1 day-5",
            "count": 3
        }
    ],
    "count": 5,
}