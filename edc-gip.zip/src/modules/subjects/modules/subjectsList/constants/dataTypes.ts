export type addVolunteerDataType = {
    id: number,
    subjectId: string,
    subjectEnrollmentDate: string,
    studyId: number,
    siteId: number,
    siteName: string,
    userId: number,
    status: boolean,
    subjectStatusId: number,
    subjectStatus: string,
    subjectStatusCode: string
}

export type volunteersDataType = {
    limit: number,
    offset: number,
    studyId: number,
    userId: number,
    siteNameSearch: string,
    subjectStatusCode: string,
    subjectId: string
}

export type visitParamsDataType = {
    subjectId: number | string,
    visitName: null | string,
    visitStatusCode: null | string,
    limit: number,
    offset: number
}

export type addNoteTransactionDataType = {
    id: number,
    userId: number,
    fieldId: number,
    userName: string,
    title: string,
    comments: string,
    acknowledge: boolean,
    notifyUsers: notifyUsersDataType
}
export type notifyUsersDataType = [
    {
        id: number,
        userId: number,
        userName: string
    }
]

export type notesDataTypes ={
    id: number,
    userName: string,
    fieldId: number,
    userId: number,
    title: string,
    comments: string,
    notifyUsers: [{UserId: number, id: number, userName: string}],
    acknowledge : boolean
}
