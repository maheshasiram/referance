export const openQuries= {
        "count": 1,
        "openQueries": [
            {
                "subid": 13983,
                "studySubjectId": 13983,
                "siteName": "site1",
                "count": 1,
                "label": "01-25"
            }
        ]
    }
