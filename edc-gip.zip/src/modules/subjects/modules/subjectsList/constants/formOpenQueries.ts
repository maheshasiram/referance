export const formOpenQuries={
    "count": 2,
    "openQueries": [
        {
            "repeatingForms": false,
            "formName": "NumaricCaliculation",
            "eventCRFId": 3713,
            "count": 2,
            "crfVersionId": 33,
            "url": "/InitialDataEntry?eventCRFId=3713"
        },{
            "repeatingForms": false,
            "formName": "NumaricCaliculation",
            "eventCRFId": 3653,
            "count": 4,
            "crfVersionId": 43,
            "url": "/InitialDataEntry?eventCRFId=3713"
        }
    ]
}