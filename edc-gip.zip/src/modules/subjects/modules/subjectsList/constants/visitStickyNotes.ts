export const visitStickyNotes = {
    "stickyNotes": [
        {
            "visitName": "test test",
            "eventId": 1500,
            "count": 2,
            "eventName": "test test"
        },
        {
            "visitName": "new",
            "eventId": 1501,
            "count": 1,
            "eventName": "new"
        },
        {
            "visitName": "Screening1",
            "eventId": 1563,
            "count": 3,
            "eventName": "Screening1"
        },
        {
            "visitName": "test(1)",
            "eventId": 1603,
            "count": 1,
            "eventName": "test(1)"
        },
        {
            "visitName": "Screening1",
            "eventId": 1563,
            "count": 3,
            "eventName": "Screening1"
        },
        {
            "visitName": "test(1)",
            "eventId": 1603,
            "count": 1,
            "eventName": "test(1)"
        }
    ],
    "count": 6

}