import { stickyNotesData } from "../constants/stickyNotesData";
import { openQuries } from "../constants/openQuries";
import { visitOpenQueries } from "../constants/visitOpenQueries";
import { formOpenQuries } from "../constants/formOpenQueries";
import { formstickyNotesData } from "../constants/formStickyNotes";
import { visitStickyNotes } from "../constants/visitStickyNotes";
import { fetch } from "../../../../../constants/fetch";
import { subjects } from '../../../../../configs/enivornment/subjects';
import { Loader } from '../../../../../actions/actions';
import { Types } from "../reducers/Types";

export const fetchVolunteers: any = (payload: any, callback: any) => {
    return (dispatch: any) => {
        dispatch(Loader(true));
        const url = `${subjects.volunteers.fetchAllVolunteers}`
        fetch({
            method: 'POST',
            url: url,
            data: payload
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data)
                }
                dispatch(Loader(false));
            })

    }
}

export const addNewSubject: any = (payload: any, callback: any) => {
    return (dispatch: any) => {
        dispatch(Loader(true));
        const url = `${subjects.volunteers.addSubject}`
        fetch({
            method: 'POST',
            url: url,
            data: payload
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data)
                }
                dispatch(Loader(false));
            })

    }
}
export const fetchStatusList: any = (callback: any) => {
    return (dispatch: any) => {
        dispatch(Loader(true));
        const url = `${subjects.volunteers.statusList}`
        fetch({
            method: 'GET',
            url: url,
            data: ''
        })
            .then((response: any) => {
                if (callback) { callback(response.data) }
                dispatch(Loader(false));
            })
    }
}
export const fetchAllSites: any = (payload: any, callback: any) => {
    const url = `${subjects.volunteers.sitesList}?studyId=${payload}`
    return (dispatch: any) => {
        dispatch(Loader(true));
        fetch({
            method: 'GET',
            url: url,
            data: ''
        })
            .then((response: any) => {
                if (callback) { callback(response.data) }
                dispatch(Loader(false));
            })
    }
}




export const fetchOpenQuries: any = (id: any, callback: any) => {
    const data = id === 0 ? openQuries : id === 1 ? visitOpenQueries : id === 2 ? formOpenQuries : " "
    return () => {
        if (callback) {
            callback(data)
        }
    }
}

export const fetchStickyNotes: any = (id: any, callback: any) => {
    const data = id === 0 ? stickyNotesData : id === 1 ? visitStickyNotes : id === 2 ? formstickyNotesData : ""
    return () => {
        if (callback) {
            callback(data)
        }
    }
}

export const deleteSubject: any = (payload: any, callback: any) => {
    const url = `${subjects.volunteers.deleteSubject}?studyId=${payload.studyId}&subjectId=${payload.subjectId}`
    return (dispatch: any) => {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
        })
            .then((response: any) => {
                callback(response.data)
                dispatch(Loader(false));
            })
    }
}
export const subjectRestore: any = (payload: any, callback: any) => {
    const url = `${subjects.volunteers.restoreSubject}?studyId=${payload.studyId}&subjectId=${payload.subjectId}`
    return (dispatch: any) => {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
        })
            .then((response: any) => {
                callback(response.data)
                dispatch(Loader(false));
            })
    }
}

export const fetchSubjectSitesList: any = (studyId: number, callback: any) => {
    const url = `${subjects.volunteers.subjectSitesList}?studyId=${studyId}`
    return (dispatch: any) => {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data)
                }
                dispatch({ type: Types.FETCH_SUBJECT_SITES_LIST, payload:response.data  })
            })
    }
}
