import { Types } from "./Types";
import { addVolunteerModel, pageModal, visitParamModal, volunteersModel, addQueryModal, addNoteTransactionModal, notesModel, addDeviationModel } from "../constants/modal";
import { totalScoreData } from "../constants/totalScoreData";
// import { stat } from "fs";

const initialState = {
    page: pageModal,
    volunteer: addVolunteerModel,
    filter: [],
    lock: [],
    unlock: [],
    volunteersPayload: volunteersModel,
    // SubjectVisits
    subjectVisitParams: visitParamModal,
    allSubjectVisits: [],
    visitActionStatus: [],
    visitTypes: [],
    subjectSites: [],
    dynamicFormData: null,
    entryFormData: null,
    subjectStatusConfig: null,
    fieldleveldynamics: null,
    derivations: null,
    addQueryPayload: addQueryModal,
    getQueryType: null,
    dynamicFormSaveType: {},
    getQueryStatus: null,
    notes: notesModel,
    getNotes: null,
    noteTransactions: addNoteTransactionModal,
    auditLogDetails: null,
    deviationCategories: null,
    deviationTypes: null,
    deviationPayload: addDeviationModel,
    fetchAllDeviationRecords: null,
    totalScore: totalScoreData,
    rules: []
}

export const subjects = (state = initialState, action: any) => {
    switch (action.type) {
        case Types.ADD_VOLUNTEER:
            return { ...state, volunteer: action.payload }
        case Types.FILTER_VOLUNTEER:
            return { ...state, filter: action.payload }
        case Types.LOCK_VISIT:
            return { ...state, lock: action.payload }
        case Types.UNLOCK_VISIT:
            return { ...state, unlock: action.payload }
        case Types.VOLUNTEERS_PAYLOAD:
            return { ...state, volunteersPayload: action.payload }
        case Types.SUBJECT_VISIT_PARAMS:
            return { ...state, subjectVisitParams: action.payload }
        case Types.GET_ALL_SUBJECTVISITS:
            return { ...state, allSubjectVisits: action.payload }
        case Types.VISIT_ACTION_STATUS:
            return { ...state, visitActionStatus: action.payload }
        case Types.GET_VISIT_TYPES:
            return { ...state, visitTypes: action.payload }
        case Types.FETCH_SUBJECT_SITES_LIST:
            return { ...state, subjectSites: action.payload }
        case Types.GET_DYNAMIC_FORMDATA:
            console.log("...GET_DYNAMIC_FORMDATA.....", action.payload)
            return { ...state, dynamicFormData: action.payload }
        case Types.ENTRY_FORM_DATA:
            return { ...state, entryFormData: action.payload }
        case Types.SUBJECT_STATUS_CONFIG:
            return { ...state, subjectStatusConfig: action.payload }
        case Types.GET_FIELD_LEVEL_DYNAMICS:
            return { ...state, fieldleveldynamics: action.payload }
        case Types.FETCH_DERIVATIONS:
            console.log("get derivation....", action.payload)
            return { ...state, derivations: action.payload }
        case Types.CREATE_QUERY:
            return { ...state, addQueryPayload: action.payload }
        case Types.GET_QUERY_TYPE:
            return { ...state, getQueryType: action.payload }
        case Types.DYNAMIC_FORM_SAVE_TYPE:
            console.log("...67", action.payload);
            return { ...state, dynamicFormSaveType: action.payload }
        case Types.GET_QUERY_STATUS:
            console.log("...60", action.payload);
            return { ...state, getQueryStatus: action.payload }
        case Types.CREATE_NOTES:
            return { ...state, notes: action.payload }
        case Types.GET_NOTES:
            return { ...state, getNotes: action.payload }
        case Types.ADD_UPDATE_NOTE_TRANSACTION:
            return { ...state, noteTransactions: action.payload }
        case Types.GET_AUDIT_LOG_DETAILS_BY_ID:
            return { ...state, auditLogDetails: action.payload }
        case Types.GET_DEVIATION_TYPE:
            return { ...state, deviationTypes: action.payload }
        case Types.GET_PROTOCOL_CATEGORIES:
            return { ...state, deviationCategories: action.payload }
        case Types.CREATE_PROTOCOL_DEVIATION:
            return { ...state, deviationPayload: action.payload }
        case Types.GET_ALL_PROTOCOL_DEVIATION:
            return { ...state, fetchAllDeviationRecords: action.payload }
        case Types.TOTAL_SCORE_DERIVATION:
            return { ...state, totalScore: action.payload }
        case Types.GET_RULES:
            console.log("...103", action.payload);
            return { ...state, rules: action.payload }
        default:
            return { ...state }
    }
}