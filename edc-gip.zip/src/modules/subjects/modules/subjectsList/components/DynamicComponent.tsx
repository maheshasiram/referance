import React from 'react'
import Visits from './visits/Visits';
import Volunteers from './volunteers/Volunteers';
import { AnyObject } from 'immer/dist/internal';
import FolderOpenIcon from '@mui/icons-material/FolderOpen';
import DescriptionIcon from '@mui/icons-material/Description';
import Forms from './forms/Forms';
import DynamicForms from './dynamicForms';
import PeopleAltRoundedIcon from '@mui/icons-material/PeopleAltRounded';
import SmsRoundedIcon from '@mui/icons-material/SmsRounded';

export const Icons: AnyObject = {
    volunteers: <PeopleAltRoundedIcon />,
    visits:  <SmsRoundedIcon /> ,
    forms: <FolderOpenIcon />,
    dataentry: <DescriptionIcon />
}
export const Components: AnyObject = {
    volunteers: (props: any) => <Volunteers {...props} />,
    visits: (props: any) => <Visits {...props} />,
    forms: (props: any) => <Forms {...props} />,
    dynamicForms:(props:any) => <DynamicForms  {...props}/>
};