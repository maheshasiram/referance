// import _ from "lodash";
import React from "react";
import { useDispatch, useSelector } from "react-redux";
import SearchField from "../../../../../../common/searchField/SearchField";
import { dataEntryNavigation } from "../../../../../../actions/actions";
import { fetchVolunteers } from '../../actions/action';
import "../../styles/Styles.scss"
import { Types } from "../../reducers/Types";

function VolunteerFilters(props: any) {
    const dispatch = useDispatch()
    const { data } = props
    const { page } = useSelector((state: any) => state.application);
    const { volunteersPayload, subjectSites } = useSelector((state: any) => state.subjects);

    const onSearchOrClearSubject = (e: any, type: number) => {
        const payload = { ...{}, ...page }
        const params = { ...{}, ...volunteersPayload }
        type === 0 ? params.subjectId = e.target.value : params.subjectId = ''
        dispatch({ type: Types.VOLUNTEERS_PAYLOAD, payload: params })
        dispatch(fetchVolunteers(params, (response: any) => {
            payload.tabs[parseInt(page.currentTab)].data.volunteers = type === 0 ? { ...response, subjects: response.subjects ? response.subjects : [] } : response;
            dispatch(dataEntryNavigation(payload));
        }));
    }

    const onSelectStatusOrSites = (e: any, type: string) => {
        const _payload = { ...{}, ...page }
        const params = { ...{}, ...volunteersPayload }
        params[type] = e.target.value
        dispatch({ type: Types.VOLUNTEERS_PAYLOAD, payload: params })
        dispatch(fetchVolunteers(params, (data: any) => {
            const _data = { ...{}, ...data }
            _data.subjects = data.subjects ? data.subjects : []
            _payload.tabs[parseInt(page.currentTab)].data.volunteers = _data
            dispatch(dataEntryNavigation(_payload));
        }))
    }

    return (
        <React.Fragment>
            <div className="filter-container col-sm-6">
                <div className=" left-container w-50 pe-2">
                    <label>  Filter By :  </label>
                    <div className="filter-by d-flex">
                        <select className='dropdown-container' onChange={(e) => onSelectStatusOrSites(e, 'siteNameSearch')}
                            value={volunteersPayload.siteNameSearch}>
                            <option value=""> Site </option>
                            {
                                subjectSites.map((site: any, index: number) => (
                                    <option key={index} value={site.siteName}>{site.siteName}</option>
                                ))
                            }
                        </select>
                        <select className='dropdown-container' onChange={(e) => onSelectStatusOrSites(e, 'subjectStatusCode')}
                            value={volunteersPayload.subjectStatusCode}>
                            <option value=""> Status </option>
                            {
                                data && data.statusList && data.statusList.map((opt: any, index: any) => (
                                    <option key={index} value={opt.code}>{opt.name}</option>
                                ))
                            }
                        </select>
                    </div>
                </div>

                <div className="right-panel w-50 ps-2">
                    <label>  Search By Subject :  </label>
                    <SearchField
                        placeholder="Please enter subject id"
                        value={volunteersPayload.subjectId}
                        onChange={(e: any) => onSearchOrClearSubject(e, 0)}
                        onClearSearch={(e: any) => onSearchOrClearSubject(e, 1)}
                    />
                </div>
            </div>
        </React.Fragment>
    )
}
export default VolunteerFilters