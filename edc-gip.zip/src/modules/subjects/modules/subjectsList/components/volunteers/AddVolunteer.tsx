import React, { useState } from 'react';
import CustomDialog from '../../../../../../common/modals/CustomeDialog';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import _ from "lodash";
import { useDispatch, useSelector } from "react-redux";
import { addNewSubject, fetchVolunteers } from '../../actions/action';
import { dataEntryNavigation, toastAlert } from '../../../../../../actions/actions';
import AddIcon from '@mui/icons-material/Add';
import moment from "moment";

function AddVolunteer(props: any) {
    const dispatch = useDispatch()
    const { volunteer, volunteersPayload, subjectStatusConfig } = useSelector((state: any) => state.subjects);
    const { currentStudy, currentUser, page,configCodes } = useSelector((state: any) => state.application);
    const { data } = props;
    const [open, setOpen] = useState(false)
    const [errorMsg, setErrorMsg] = useState('');

    const onOpenAddVolunteer = () => {
        if (currentStudy && currentStudy.configData.code !== configCodes?.manual && data.sites.length <= 1) {
            onSubmitHandler(volunteer)
        } else {
            setOpen(true);
            setErrorMsg("")
        }
    }

    const onCloseAddVolunteer = () => {
        setOpen(false)
    }

    const volunteerSchema = (currentStudy: any) => {
        return Yup.object().shape({
            subjectId: currentStudy?.configData?.code === configCodes?.manual ? Yup.string()
                .required('Please enter subject Id ')
                .matches(/^[a-zA-Z0-9](.*[a-zA-Z0-9])?$/, "Special characters are not allowed in the Start & End position") : Yup.string(),
            siteName: Yup.string().required('Please select site name ')
        });
    }

    const onSubmitHandler = (values: any) => {
        console.log("...43 add volunterr", values)
        const _enrolledSubject = subjectStatusConfig?.SUBJECT_STATUS.find((item: any) => item.code === configCodes?.Enrolled)
        // let _enrolledSubject = page && page.tabs[parseInt(page.currentTab)].data.statusList.find((item: any) => item.code == 'SUBJECT_STATUS_ENROLLED')
        console.log("_enrolledSubject...", _enrolledSubject)
        dispatch(addNewSubject({
            ...values,
            subjectId: currentStudy && currentStudy.configData.code === configCodes?.manual ? values.subjectId.toUpperCase() : null,
            studyId: currentStudy.id,
            subjectEnrollmentDate: moment(),
            userId: currentUser.id,
            subjectStatusId: _enrolledSubject && _enrolledSubject.id,
            subjectStatus: _enrolledSubject && _enrolledSubject.name,
            subjectStatusCode: _enrolledSubject && _enrolledSubject.code,
            siteId: currentStudy && currentStudy.configData.code !== configCodes?.manual && data.sites.length <= 1 ? '43' : values.siteId
        }, (_response: any) => {
            if (!_response.errorMessage) {
                onCloseAddVolunteer()
                const payload: any = _.cloneDeep(sessionStorage.page ? JSON.parse(sessionStorage.page) : page);
                dispatch(fetchVolunteers(volunteersPayload, (response: any) => {
                    payload.tabs[parseInt(page.currentTab)].data.volunteers = response;
                    payload.tabs[(parseInt(page.currentTab) + 1)].isActive = true;
                    payload.tabs[(parseInt(page.currentTab) + 1)].label = _response.subjectId;
                    payload.currentSubjectId = _response.id;
                    payload.subjectStatusCode = _response.subjectStatusCode;
                    payload.currentTab = (parseInt(page.currentTab) + 1).toString();
                    dispatch(dataEntryNavigation(payload))
                }))
                dispatch(toastAlert({
                    status: 1,
                    open: true,
                    message: 'New Volunteer created successfully!'
                }))

            } else {
                if (currentStudy && currentStudy.configData.code !== configCodes?.manual && data.sites.length <= 1) {
                    dispatch(toastAlert({
                        status: 2,
                        open: true,
                        message: _response.errorMessage
                    }))
                } else {
                    setErrorMsg(_response.errorMessage)
                }
             
            }
        }))
    }

    const onSiteChange = (e: any, setFieldValue: any, setFieldTouched: any) => {
        const index = e.target.selectedIndex;
        const el = e.target.childNodes[index]
        const id = el.getAttribute('id');
        setFieldTouched('siteName', true)
        setFieldValue('siteId', id)
        setFieldValue('siteName', e.target.value)
    }

    return (
        <React.Fragment>
            <div className='d-flex px-3 col-sm-2'>
                <button type="button"
                    className="btn-eprimary-rounded"
                    onClick={onOpenAddVolunteer}>
                    <AddIcon />Add Subject</button>
                <CustomDialog
                    title='Add Subject'
                    open={open}
                    form='addVolunteer'
                    onClose={onCloseAddVolunteer}
                    maxWidth="xs"
                    fullWidth={true}
                    actionType='Submit'
                >
                    <Formik
                        enableReinitialize={true}
                        initialValues={volunteer}
                        validationSchema={volunteerSchema(currentStudy)}
                        onSubmit={(values) => { onSubmitHandler(values) }}>
                        {({  values, setFieldValue, setFieldTouched }) => (
                            <Form id='addVolunteer'>
                                {errorMsg && <span className="d-flex justify-content-center text-danger">{errorMsg}</span>}
                                <div className=''>
                                    <div className='form-group p-2 m-2'>
                                        <label>Subject Id:</label>
                                        <Field
                                            className="form-control form-control-lg"
                                            name='subjectId'
                                            placeholder="Subject ID"
                                            value={values.subjectId.toUpperCase()}
                                            disabled={currentStudy && currentStudy.configData.code === configCodes?.manual ? false : true}
                                        // onChange={(e: any) => {
                                        //     setFieldValue('subjectId', (e.target.value).toUpperCase())
                                        // }}
                                        />
                                        <span className='text-danger'><ErrorMessage name='subjectId' /></span>
                                    </div>
                                    <div className='form-group p-2 m-2'>
                                        <label>Site Name:</label>
                                        <Field
                                            name='siteName'
                                            as='select'
                                            value={values.siteName}
                                            className="form-select form-control-lg"
                                            onChange={(e: any) => { onSiteChange(e, setFieldValue, setFieldTouched) }}
                                        >
                                            <option value="">Select Site Name</option>
                                            {
                                                data && data.sites && data.sites.map((opt: any) => (
                                                    <option key={opt.id} id={opt.id} value={opt.siteName}>{opt.siteName}</option>
                                                ))
                                            }
                                        </Field>
                                        <span className='text-danger'><ErrorMessage name='siteName' /></span>
                                    </div>
                                </div>
                            </Form>
                        )}
                    </Formik>
                </CustomDialog>
            </div>
        </React.Fragment>
    )
}
export default AddVolunteer