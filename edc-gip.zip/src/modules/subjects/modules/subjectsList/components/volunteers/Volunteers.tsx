import React from "react";
import '../../styles/Styles.scss'
import _ from "lodash";
import OutStandingActions from "../helpers/outStandingActions/OutStandingActions";
// import '../../styles/Styles.scss'
import VolunteerFilters from "./VolunteerFilters";
import AddVolunteer from "./AddVolunteer";
import VolunteerDataTable from "./VolunteerDataTable";
import { useDispatch, useSelector } from 'react-redux';
import { fetchAllSites, fetchOpenQuries, fetchStickyNotes, fetchVolunteers, fetchStatusList, fetchSubjectSitesList } from '../../actions/action';
import { configDataType, dataEntryNavigation } from "../../../../../../actions/actions";
import PageCount from "../../../../../../common/pagecount/PageCount";
import BoxContainer from "../helpers/BoxContainer";
import { Types } from "../../reducers/Types";

function Volunteers(props: any) {

    const dispatch = useDispatch()
    const loaded = React.useRef(false);
    const { currentStudy, currentUser, page } = useSelector((state: any) => state.application);
    const { volunteersPayload } = useSelector((state: any) => state.subjects);
    const { data } = props

    React.useEffect(() => {
        if (!loaded.current) {
            dispatch(configDataType('SUBJECT_STATUS', (data: any) => {
                dispatch({ type: Types.SUBJECT_STATUS_CONFIG, payload: data })
            }))
            const payload: any = _.cloneDeep(sessionStorage.page ? JSON.parse(sessionStorage.page) : page);
            const params = { ...volunteersPayload, studyId: currentStudy.id, userId: currentUser.id, siteNameSearch: '', subjectStatusCode: "", limit: 10 }
            dispatch({ type: Types.VOLUNTEERS_PAYLOAD, payload: params })
            dispatch(fetchVolunteers(params, (response: any) => {
                payload.tabs[parseInt(page.currentTab)].data.volunteers = response;
                dispatch(fetchOpenQuries(0, (queryResponse: any) => {
                    payload.tabs[parseInt(page.currentTab)].data.openQuries = queryResponse;
                    dispatch(fetchStickyNotes(0, (stickyResponse: any) => {
                        payload.tabs[parseInt(page.currentTab)].data.stickyNotes = stickyResponse;
                        dispatch(fetchAllSites(currentStudy.id, (sitesResponse: any) => {
                            payload.tabs[parseInt(page.currentTab)].data.sites = sitesResponse;
                            dispatch(fetchStatusList((statusResponse: any) => {
                                payload.tabs[parseInt(page.currentTab)].data.statusList = statusResponse;
                                dispatch(fetchSubjectSitesList(currentStudy.id))
                                dispatch(dataEntryNavigation(payload));
                            }))
                        }))
                    }
                    ));
                }));
            }));
            loaded.current = true;
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps


        // return () => {
        //     alert('test.....')
        // }
         // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const onPageCountChange = (e: any) => {
        const payload = { ...{}, ...page }
        const params = { ...volunteersPayload, limit: parseInt(e.target.value) }
        dispatch({ type: Types.VOLUNTEERS_PAYLOAD, payload: params })
        dispatch(fetchVolunteers(params, (response: any) => {
            payload.tabs[parseInt(page.currentTab)].data.volunteers = response
            dispatch(dataEntryNavigation(payload));
        }))
    }

    return (
        <React.Fragment>
            <div className="subjects-container" >
                <div className=" d-flex col-sm-12 align-items-end mb-3">
                    <VolunteerFilters data={data} />
                    <AddVolunteer data={data} />
                </div>
                <div>
                    <BoxContainer
                        dashboardHeader='Subjects'
                        pageCount={<PageCount onChange={onPageCountChange} />}
                        dashBoard={<VolunteerDataTable {...props} />}
                        outStandingActions={<OutStandingActions data={data} />}
                    />
                </div>
            </div>
        </React.Fragment>
    )
}
export default Volunteers;