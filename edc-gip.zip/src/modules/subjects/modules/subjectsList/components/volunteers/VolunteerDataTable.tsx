import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import recycleBin from '../../../../../../common/Assests/subjectListImages/recycleBin.png'
import volunteerType from '../../../../../../common/Assests/subjectListImages/volunteerType.png'
import CustomToolTip from "../../../../../../components/CustomToolTip";
import { Confirm, dataEntryNavigation,toastAlert } from "../../../../../../actions/actions";
import ReplayIcon from '@mui/icons-material/Replay';
import _ from "lodash";
import { deleteSubject, fetchVolunteers, subjectRestore } from "../../actions/action";
import { Types } from "../../reducers/Types";

function VolunteerDataTable(props: any) {
    const dispatch = useDispatch()
    const { page } = useSelector((state: any) => state.application);
    const { volunteersPayload } = useSelector((state: any) => state.subjects);
    const { data } = props;

    const onNavigateToVisits = (e: any, rowData: any) => {
        e.preventDefault()
        const payload = { ...{}, ...page };
        payload.tabs[(parseInt(page.currentTab) + 1)].isActive = true;
        payload.tabs[(parseInt(page.currentTab) + 1)].label = rowData.subjectId;
        payload.currentSubjectId = rowData.id;
        payload.subjectStatusCode = rowData.subjectStatusCode;
        payload.tabs[(parseInt(page.currentTab) )].data.selectedSubject = rowData;
        payload.selectedSubject = rowData;
        payload.currentTab = (parseInt(page.currentTab) + 1).toString();
        dispatch(dataEntryNavigation(payload))
    }

    const onDeleteOrRestoreSubject = (rowData: any, type: string) => {
        const payload = { subjectId: rowData.subjectId, studyId: rowData.studyId, }
        dispatch(Confirm({
            status: 0,
            message: `Are you sure you want to ${type === 'delete' ? 'delete' : 'restore'} the volunteer ${rowData.subjectId} ?`,
            onOk: () => {
                dispatch((type === 'delete' ? deleteSubject : subjectRestore)(payload, () => {
                    dispatch(toastAlert({
                        status: 1,
                        message: `${rowData.subjectId}  ${type === 'delete' ? 'deleted' : 'restored'} Successfully`,
                        open: true
                    }))
                    const _payload: any = _.cloneDeep(page);
                    dispatch(fetchVolunteers(volunteersPayload, (respones: any) => {
                        _payload.tabs[parseInt(page.currentTab)].data.volunteers = respones;
                        dispatch(dataEntryNavigation(_payload));
                    }))
                }))
            }
        }))
    }

    const volunteerTemplate = (rowData: any) => {
        return (
            <React.Fragment>
                <a title="" href="#/" id={rowData.subjectId} onClick={(e) => onNavigateToVisits(e, rowData)}>
                    <img src={volunteerType} alt="" />
                    <span className="label-span px-2 fw-500" style={{ cursor: "pointer" }}>{rowData.subjectId}</span>
                </a>
            </React.Fragment>
        )
    }

    const actionsTemplate = (rowData: any) => {
        return (
            <React.Fragment>
                {rowData.status === false ?
                    <div>
                        <CustomToolTip title='Restore'>
                            <ReplayIcon sx={{ fontSize: 18, opacity: .8 }}
                                onClick={() => onDeleteOrRestoreSubject(rowData, 'restore')} /></CustomToolTip>
                    </div>
                    : <div className="actions d-flex">
                        <CustomToolTip title='Delete'>
                            <img src={recycleBin} alt=""
                                onClick={() => onDeleteOrRestoreSubject(rowData, 'delete')} /></CustomToolTip>
                    </div>
                }
            </React.Fragment >
        )
    }

    const onPageChange = (e: any) => {
        const _payload = _.cloneDeep(page)
        const params = { ...volunteersPayload, offset: e.first }
        dispatch({ type: Types.VOLUNTEERS_PAYLOAD, payload: params })
        dispatch(fetchVolunteers(params, (response: any) => {
            _payload.tabs[parseInt(page.currentTab)].data.volunteers = response;
            dispatch(dataEntryNavigation(_payload));
        }));
    }
    
    
    return (
        <React.Fragment>
            {data.volunteers && data.volunteers.subjects && <div>
                <DataTable
                    value={data.volunteers.subjects ? data.volunteers.subjects : []}
                    emptyMessage="No volunteers to display."
                    lazy
                    rows={volunteersPayload.limit}
                    frozenValue={[]}
                    scrollable
                    scrollHeight='300px'
                    paginator={(data && data.volunteers.totalRecords && data.volunteers.totalRecords > volunteersPayload.limit) ? true : false}
                    totalRecords={data.volunteers.totalRecords}
                    responsiveLayout="scroll"
                    first={volunteersPayload.offset}
                    onPage={onPageChange}
                >
                    <Column field="subjectId" body={volunteerTemplate} header="Subject" ></Column>
                    <Column field="subjectStatus" header="Status"></Column>
                    <Column field="siteName" header="Site Name" ></Column>
                    <Column body={actionsTemplate} header="Actions"></Column>
                </DataTable>
            </div>
            }
            {
                data.volunteers && (!(data.volunteers.subjects) ||(data.volunteers.subjects.length<=0)) &&
                <div className="d-flex justify-content-center pt-5" >
                    <span>No Subjects are available to display , please try to ADD ...!</span>
                </div>
            }
        </React.Fragment>
    )
}
export default VolunteerDataTable;