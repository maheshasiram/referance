import React, { useEffect } from 'react'
import _ from "lodash";
import { useDispatch, useSelector } from "react-redux";
import SearchField from '../../../../../../../common/searchField/SearchField'
import { dataEntryNavigation, configDataType } from '../../../../../../../actions/actions';
import '../../../styles/Styles.scss'
import { Types } from '../../../reducers/Types';
import { findAllVisitsByCriteria } from '../actions/action';

function VisitsFilters() {
    const dispatch = useDispatch();
    const { page } = useSelector((state: any) => state.application);
    const { subjectVisitParams,visitActionStatus } = useSelector((state: any) => state.subjects);
    const loaded = React.useRef(false);
    useEffect(() => {
        if(!loaded.current){
            dispatch(configDataType('VISIT_STATUS', (response: any) => {
            dispatch({ type: Types.VISIT_ACTION_STATUS, payload: response.VISIT_STATUS })
        }))
        loaded.current = true;
    }
    }, [dispatch])
    
    const onVisitSearch = (value: any) => {
        const _payload = _.cloneDeep(page)
        console.log("26....",subjectVisitParams)
        const _subjectVisitParams  = { ...subjectVisitParams, visitName: value }
        dispatch(findAllVisitsByCriteria(_subjectVisitParams, (response: any) => {
            _payload.tabs[parseInt(page.currentTab)].data.visits = response;
        }))
        dispatch(dataEntryNavigation(_payload))
        dispatch({ type: Types.SUBJECT_VISIT_PARAMS, payload: _subjectVisitParams })
    }

    const onSelectVisit = (event: any) => {
        const _payload = _.cloneDeep(page)
        // let _visits = allSubjectVisits.filter((item: any) => item.actionStatus.code.includes(event.target.value))
        // _payload.tabs[parseInt(page.currentTab)].data.visits = _visits
        console.log("38....",subjectVisitParams)
        const _subjectVisitParams  = { ...subjectVisitParams, /* visitName: '',*/ visitStatusCode: event.target.value }
        dispatch(findAllVisitsByCriteria(_subjectVisitParams, (response: any) => {
            _payload.tabs[parseInt(page.currentTab)].data.visits = response;
        }))
        dispatch(dataEntryNavigation(_payload))
        dispatch({ type: Types.SUBJECT_VISIT_PARAMS, payload: _subjectVisitParams })
    }
    return (
        <React.Fragment>
            <div className="col-md-4">
                <label>  Filter By :  </label>
                <select className='dropdown-container w-100 me-1'
                    onChange={onSelectVisit}
                    value={subjectVisitParams.visitStatusCode}
                >
                    <option value="">Status</option>
                    {visitActionStatus && visitActionStatus?.map((item: any) => {
                        return <option id={item.id} key={item.id} value={item.code} >{item.name}</option>
                    })}
                </select>
            </div>
            <div className="col-md-8 ps-3">
                <label>Search By Visit Name :</label>
                <SearchField
                    placeholder="Please enter visit"
                    value={subjectVisitParams.visitName}
                    onChange={(e: any) => onVisitSearch(e.target.value)}
                    onClearSearch={() => onVisitSearch('')}
                />
            </div>
        </React.Fragment>
    )
}

export default VisitsFilters