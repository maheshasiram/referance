export const visitTypeCodes = {
    scheduled: 'VISIT_TYP_SCHEDULED',
    unscheduled: 'VISIT_TYP_UNSCHEDULED',
    common: 'VISIT_TYP_COMMON'
}

export const visitStatusCodes = {
    dataEntryStarted: 'VISIT_STATUS_DATA_ENTRY_STARTED',
    scheduled: 'VISIT_STATUS_SCHEDULED',
    unscheduled: 'VISIT_STATUS_UNSCHEDULED',
    locked: 'VISIT_STATUS_LOCKED',
    completed: 'VISIT_STATUS_COMPLETED'
}