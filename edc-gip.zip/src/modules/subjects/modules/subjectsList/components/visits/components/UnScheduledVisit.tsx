import React, { useState } from "react";
import CustomToolTip from "../../../../../../../components/CustomToolTip";
import CustomDialog from "../../../../../../../common/modals/CustomeDialog";
import { useDispatch, useSelector } from "react-redux";
import _ from "lodash";
import { dataEntryNavigation } from "../../../../../../../actions/actions";
import { addUnscheduledVisit, fetchAssignedFormsByVisitId, findAllVisitsByCriteria } from "../actions/action";
import { visitTypeCodes } from "../constants/visitConfigCodes";

function UnScheduledVisit(props: any) {

    const dispatch = useDispatch()
    const { rowData, subjectStatusLocked } = props;
    const { page, currentUser } = useSelector((state: any) => state.application);
    const { subjectVisitParams } = useSelector((state: any) => state.subjects);
    const [open, setOPen] = React.useState(false);
    const [formsList, setFormsList] = useState([])
    const [error, setError] = useState(false)

    const onCloseHandler = () => {
        setOPen(false);
        setError(false)
    }
    const onAddUnscheduleVisits = () => {
        const payload: any = _.cloneDeep(page);
        dispatch(fetchAssignedFormsByVisitId(rowData.visit.id, (response: any) => {
            const _response = response
            _response?.length > 0 && _response.map((item: any) => {
                item.checked = false
                return null;
            })
            setFormsList(response)
            if (rowData.visit.visitType.code === visitTypeCodes.unscheduled) {
                setOPen(true)
            } else {
                const _payload = {
                    id: 0,
                    subjectId: page.currentSubjectId,
                    visitId: rowData.visit.id,
                    userId: currentUser.id,
                    formsIds: response.map((i: any) => { return i.id })
                }
                dispatch(addUnscheduledVisit(_payload, () => {
                    // dispatch(fetchVisits(_payload.subjectId, (response: any) => {
                    //     payload.tabs[parseInt(page.currentTab)].data.visits = response;
                    // }))
                    const params = { ...subjectVisitParams }
                    dispatch(findAllVisitsByCriteria(params, (response: any) => {
                        payload.tabs[parseInt(page.currentTab)].data.visits = response;
                    }))
                    dispatch(dataEntryNavigation(payload))
                }))
            }
        }))
    }

    const onSelectFormHandler = (e: any, item: any, index: number) => {
        const _formsList: any = [...[], ...formsList]
        _formsList[index].checked = e.target.checked
        setFormsList(_formsList)
    }
    const validateForms = (list: any) => {
        const formSelected: any = []
        const _list = list
        _list?.length > 0 && _list.map((i: any) => {
            if (i && i.checked) {
                formSelected.push(i.id)
            }
            return null;
        })
        return formSelected
    }
    const onSubmitUnscheduledForms = () => {
        const _formsList: any = [...[], ...formsList]
        const payload: any = _.cloneDeep(page);
        const selectedForms = validateForms(_formsList)
        const _payload = {
            id: 0,
            subjectId: page.currentSubjectId,
            visitId: rowData.visit.id,
            userId: currentUser.id,
            formsIds: selectedForms
        }
        if (selectedForms?.length > 0) {
            dispatch(addUnscheduledVisit(_payload, () => {
                // dispatch(fetchVisits(_payload.subjectId, (response: any) => {
                //     payload.tabs[parseInt(page.currentTab)].data.visits = response;
                // }))
                const params = { ...subjectVisitParams }
                dispatch(findAllVisitsByCriteria(params, (response: any) => {
                    payload.tabs[parseInt(page.currentTab)].data.visits = response;
                }))
                dispatch(dataEntryNavigation(payload))
                onCloseHandler()
            }))
        } else {
            setError(true)
        }
    }

    return (
        <div>
            <CustomToolTip title={rowData.visit.visitType.code === visitTypeCodes.unscheduled ? 'Add Unscheduled Vists' : 'Add Common Visits'}>
                <button onClick={subjectStatusLocked ? () => {
                    console.log('...99');
                } : onAddUnscheduleVisits} className="repeat-Btn" >Repeat</button>
            </CustomToolTip>

            <div>
                <CustomDialog
                    title={'UnScheduled Visits'}
                    onClose={onCloseHandler}
                    onSubmitHandler={() => { onSubmitUnscheduledForms() }}
                    open={open}
                    maxWidth="sm"
                    fullWidth={true}
                    padding={true}
                    actionType={'Submit'}
                // form="addGroup"
                // disabled={(selectedForms.length > 0) ? false : true}
                >
                    <div>
                        <div className="p-3">
                            {error && <p className="text-danger" >Please select atleast one form</p>}
                            {formsList.length > 0 ? <div>
                                <div className="d-flex justify-content-between align-items-center border-bottom unScheduled-visits-label" ><label className="">Forms</label> {/* <input type={'checkbox'} /> */}</div>
                                {
                                    formsList?.length > 0 && formsList.map((form: any, index: number) => (
                                        <div key={form.formID} className="d-flex justify-content-between align-items-center ">
                                            <label className="m-0" >{form.formName}</label>
                                            <input type={'checkbox'} checked={form.checked} onChange={(e: any) => onSelectFormHandler(e, form, index)} />
                                        </div>
                                    ))
                                }
                            </div> : <div>
                                <p className="text-center">No forms available to display</p>
                            </div>}
                        </div>
                    </div>
                </CustomDialog>
            </div>
        </div>
    )
}
export default UnScheduledVisit