import React, { useEffect, useState } from "react";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { useDispatch, useSelector } from "react-redux";
import { dataEntryNavigation } from "../../../../../../../actions/actions";
import UnScheduledVisit from "./UnScheduledVisit";
import { VisitStatusIcons } from "./VisitStatusIcons";
import VisitsActions from "./VisitsActions";
import "../../../styles/Styles.scss"
import { addScheduledVisit, fetchVisits, findAllVisitsByCriteria } from "../actions/action";
import { visitTypeCodes } from "../constants/visitConfigCodes";
import _ from "lodash";
import { Types } from "../../../reducers/Types";

function VisitsDashBoard(props: any) {
    const dispatch = useDispatch()
    const { page, currentUser } = useSelector((state: any) => state.application);
    const { subjectVisitParams } = useSelector((state: any) => state.subjects);
    const [expandedRows, setExpandedRows] = useState<any>({});
    const [pageClick, setpageChange] = useState(false);

    const { data } = props;

    useEffect(() => {
        const _expanded: any = {}
        const _data = data?.visits?.subjectVisits
        if (_data) {
            _data.map((i: any) => {
                // if (i.childVisits) {
                return ((i.childVisits) && (_expanded[i.id] = true))
                // }
            })
        }
        setExpandedRows(_expanded)
    }, [data.visits])

    const onNavigateToForms = (rowData: any) => {
        const payload = { ...{}, ...page };
        payload.tabs[(parseInt(page.currentTab) + 1)].isActive = true;
        payload.tabs[(parseInt(page.currentTab) + 1)].label = rowData.visit.visitName;
        payload.currentTab = (parseInt(page.currentTab) + 1).toString();
        payload.tabs[(parseInt(page.currentTab))].data.selectedVisit = rowData;
        payload.currentVisitId = rowData.id;
        payload.selectedVisit = rowData;
        dispatch(dataEntryNavigation(payload))
    }
    const statusTemplate = (rowData: any) => {
        if (rowData?.actionStatus?.code) {
            const Component = VisitStatusIcons[rowData.actionStatus.code]
            return Component && <Component />
        }
    };
    const onScheduleVisitHandler = (rowData: any) => {
        // console.clear()
        let visitRowData = rowData
        if (!rowData.id || rowData.id === 0) {
            const payload = {
                id: 0,
                subjectId: page.currentSubjectId,
                visitId: rowData.visit.id,
                userId: currentUser.id,
                formsIds: [0]
            }

            dispatch(addScheduledVisit(payload, (response: any) => {
                if (response.data) {
                    visitRowData = response.data
                    dispatch(fetchVisits(payload.subjectId))
                    onNavigateToForms(response.data)
                }
            }))
        } else {
            onNavigateToForms(visitRowData)
        }
    }

    const visitNameTemplate = (rowData: any) => {
        const subjectStatusLocked = page && page.subjectStatusCode === 'SUBJECT_STATUS_LOCKED' ? true : false
        if (!rowData.visit.visitRepeat) {
            return (
                <div className="d-flex">
                    <div className="pe-1">{statusTemplate(rowData)}</div>
                    <span id={rowData.visit.id} style={{ cursor: "pointer" }} onClick={() => onScheduleVisitHandler(rowData)}>{rowData.visit.visitName}</span>
                </div>
            )
        } else {
            return (
                <div>
                    <div className="d-flex">
                        {/* {rowData && !rowData.childVisits ? <div className="pe-1">{statusTemplate(rowData)}</div> : <div className="px-3" ></div>} */}
                        {<div className="pe-1">{statusTemplate(rowData)}</div>}
                        <span id={rowData.visit.id}>{rowData.visit.visitName}</span>
                        <UnScheduledVisit
                            rowData={rowData}
                            onNavigateToForms={onNavigateToForms}
                            data={data}
                            subjectStatusLocked={subjectStatusLocked}
                        />
                    </div>
                </div>
            )
        }
    }
    const subVisitNameTemplate = (rowData: any) => {
        return <div className="d-flex">
            <div className="pe-1">{statusTemplate(rowData)}</div>
            <span id={rowData.visit.id} style={{ cursor: "pointer" }} onClick={() => onScheduleVisitHandler(rowData)}>{rowData.visit.visitName}</span>
        </div>
    }

    const rowExpansionTemplate = (data: any) => {
        if (data.childVisits) {
            return (<div className="sub-visits-DashBoard ms-5 w-100" >
                <DataTable
                    value={data.childVisits}
                    scrollable
                    scrollHeight="200px"
                    responsiveLayout="scroll">
                    <Column body={subVisitNameTemplate}></Column>
                    <Column field="" header="Date"></Column>
                    <Column body={subVisitActionTemplate}></Column>
                </DataTable>
            </div>
            );
        }
    }
    const subVisitActionTemplate = (rowData: any) => {
        return <VisitsActions rowData={rowData} />
    }
    const actionBodyTemplate = (rowData: any) => {
        if (rowData?.visitType?.code === visitTypeCodes.scheduled) {
            return <VisitsActions rowData={rowData} />
        }
    }
    const onPageChange = (e: any) => {
        if (((e.page > 0) || (pageClick && e.page === 0)) && subjectVisitParams.offset !== e.first) {
            const payload = _.cloneDeep(page)
            const params = { ...subjectVisitParams, offset: e.first }
            dispatch(findAllVisitsByCriteria(params, (response: any) => {
                payload.tabs[parseInt(page.currentTab)].data.visits = response;
            }))
            dispatch(dataEntryNavigation(payload))
            dispatch({ type: Types.SUBJECT_VISIT_PARAMS, payload: params })
            setpageChange(true)
        }
    }
    console.log('data.visits......', data.visits, subjectVisitParams)
    return (
        <div className="visitsDashboard-Container" >
            {data && data.visits ? <div>
                <DataTable value={data.visits && data.visits?.subjectVisits}
                    lazy
                    scrollable
                    first={subjectVisitParams.offset}
                    totalRecords={data?.visits?.totalRecords}
                    scrollHeight="330px"
                    paginator={data.visits.totalRecords > subjectVisitParams.limit ? true : false}
                    rows={subjectVisitParams.limit}
                    expandedRows={expandedRows}
                    onRowToggle={(e: any) => { setExpandedRows(e.data) }}
                    rowExpansionTemplate={rowExpansionTemplate} dataKey="id"
                    onPage={onPageChange}
                >
                    {/* <Column expander={true} style={{ width: '40px' }} /> */}
                    <Column body={visitNameTemplate} header="Visit Name"></Column>
                    <Column field="" header="Date"></Column>
                    <Column body={actionBodyTemplate} header="Action"></Column>
                </DataTable>
            </div> : <div className="d-flex pt-5" >
                <p className="text-center w-100 pt-5">No Visits are available.......!</p>
            </div>}
        </div>
    )
} export default VisitsDashBoard