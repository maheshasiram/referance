import React from 'react';
import { AnyObject } from 'immer/dist/internal';
import CustomToolTip from '../../../../../../../components/CustomToolTip';
import AssignmentTurnedInIcon from '@mui/icons-material/AssignmentTurnedIn';
import AcUnitIcon from '@mui/icons-material/AcUnit';
import DoDisturbOnIcon from '@mui/icons-material/DoDisturbOn';
import GradingIcon from '@mui/icons-material/Grading';
import SkipNextIcon from '@mui/icons-material/SkipNext';
import ListAltOutlinedIcon from '@mui/icons-material/ListAltOutlined';
import AssignmentOutlinedIcon from '@mui/icons-material/AssignmentOutlined';
import dataEntyIcon from '../../../../../../../common/Assests/visitStatusImages/dataEntyIcon.png'
import lockIcon from '../../../../../../../common/Assests/visitStatusImages/lockIcon.png'
import scheduledIcon from '../../../../../../../common/Assests/visitStatusImages/scheduledIcon.png'
import unscheduledIcon from '../../../../../../../common/Assests/visitStatusImages/unscheduledIcon.png'


export const VisitStatusIcons: AnyObject = {
    "VISIT_STATUS_DATA_ENTRY_STARTED": (props: any) => <CustomToolTip title='Data Entry Started'><img src={dataEntyIcon} alt="" {...props} /></CustomToolTip>,
    "VISIT_STATUS_SCHEDULED": (props: any) => <CustomToolTip title='Scheduled'><img src={scheduledIcon} alt="" {...props} /></CustomToolTip>,
    "VISIT_STATUS_NOT_SCHEDULED": (props: any) => <CustomToolTip title='Not Scheduled'><img src={unscheduledIcon} alt="" {...props} /></CustomToolTip>,
    "VISIT_STATUS_LOCKED": (props: any) => <CustomToolTip title='Locked'><img src={lockIcon} alt="" {...props} /></CustomToolTip>,
    "VISIT_STATUS_COMPLETED": (props: any) => <CustomToolTip title='Completed'><AssignmentTurnedInIcon {...props} /></CustomToolTip>,
    "skipped": (props: any) => <SkipNextIcon {...props} />,
    "frozen": (props: any) => <AcUnitIcon {...props} />,
    "monitered": (props: any) => <ListAltOutlinedIcon {...props} />,
    "stopped": (props: any) => <DoDisturbOnIcon {...props} />,
    "signed": (props: any) => <AssignmentOutlinedIcon {...props} />,
    "Reviewd": (props: any) => <GradingIcon {...props} />,
};