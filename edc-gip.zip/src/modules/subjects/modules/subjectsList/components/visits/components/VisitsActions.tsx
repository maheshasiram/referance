import _ from 'lodash'
import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { dataEntryNavigation ,Confirm,toastAlert} from '../../../../../../../actions/actions'
import CustomDialog from '../../../../../../../common/modals/CustomeDialog'
import { Formik, Form, Field } from "formik";
import CustomToolTip from '../../../../../../../components/CustomToolTip'
import * as Yup from 'yup';
import { unlockVisit, lockVisit, findAllVisitsByCriteria } from '../actions/action'
// import actionUnLockIcon from '../../../../../../../common/Assests/visitStatusImages/actionUnLockIcon.png';

function VisitsActions(props: any) {
    const dispatch = useDispatch()
    const { rowData } = props
    const [open, setOPen] = React.useState(false);
    const { page } = useSelector((state: any) => state.application)
    const { subjectVisitParams } = useSelector((state: any) => state.subjects)


    const validationSchema = Yup.object().shape({
        comments: Yup.string().required('Please enter the reason for unlock'),
    });

    const onCloseHandler = () => {
        setOPen(false)
    }
    const OnLockAction = (rowData: any) => {
        const payload: any = _.cloneDeep(page);
        dispatch(Confirm({
            status: 0,
            message: "Do you want to Lock the Subject Event and CRF Forms",
            onOk: () => {
                dispatch(lockVisit(rowData.id, (response: any) => {
                    if (response.data?.errorMessage) {
                        dispatch(toastAlert({
                            status: 0,
                            message: response.data.errorMessage,
                            open: true
                        }))
                    } else {
                        // dispatch(fetchVisits(payload.currentSubjectId, (response: any) => {
                        //     payload.tabs[parseInt(page.currentTab)].data.visits = response;
                        // }))
                        const params = { ...subjectVisitParams }
                        dispatch(findAllVisitsByCriteria(params, (response: any) => {
                            payload.tabs[parseInt(page.currentTab)].data.visits = response;
                        }))
                        dispatch(dataEntryNavigation(payload))
                        dispatch(toastAlert({
                            status: 1,
                            message: response.data,
                            open: true
                        }))
                    }
                }))
            }
        }))
    }
    const onUnlockAction = () => {
        setOPen(true)
    }
    const onSubmitUnlockAction = (values: any) => {
        const _payload = {
            subjectVisitId: rowData.id,
            comments: values.comments
        }
        const payload: any = _.cloneDeep(page);
        dispatch(unlockVisit(_payload, (response: any) => {
            if (response.data) {
                // dispatch(fetchVisits(payload.currentSubjectId, (response: any) => {
                //     payload.tabs[parseInt(page.currentTab)].data.visits = response;
                // }))
                const params = { ...subjectVisitParams }
                dispatch(findAllVisitsByCriteria(params, (response: any) => {
                    payload.tabs[parseInt(page.currentTab)].data.visits = response;
                }))
                dispatch(dataEntryNavigation(payload))
                onCloseHandler()
                dispatch(toastAlert({
                    status: 1,
                    message: response.data,
                    open: true
                }))
            }
        }))
    }

    return (
        <React.Fragment>
            <div>
                {
                    (rowData.lockStatus && rowData.lockStatus === true && rowData.id && rowData.id > 0) ?
                        <CustomToolTip title='UnLock Event' data-placement="top">
                            <i className='pi pi-lock-open' onClick={() => onUnlockAction()} ></i>
                        </CustomToolTip> : rowData.lockStatus === false ?
                            <CustomToolTip title='Lock Visit' data-placement="top" >
                                <i className='pi pi-lock' onClick={() => OnLockAction(rowData)} ></i>
                            </CustomToolTip> : <></>
                }
                <CustomDialog
                    title="Enter reason for Unlock"
                    maxWidth="xs"
                    open={open}
                    onClose={onCloseHandler}
                    fullWidth={true}
                    actionType='Submit'
                    form='unlockReasonForm'
                >
                    <Formik
                        initialValues={{ subjectVisitId: '', comments: '' }}
                        validationSchema={validationSchema}
                        onSubmit={(values) => { onSubmitUnlockAction(values) }}
                    >
                        {({ errors, touched }) => (
                            <Form id='unlockReasonForm'>
                                {errors?.comments && touched?.comments ? <p className="text-danger text-center pb-1">Please enter the reason for Unlock</p> : <span>&nbsp;</span>}
                                <div className='form-group mb-2' id=''>
                                    <Field
                                        as="textarea"
                                        name="comments"
                                        placeHolder='Please enter reason'
                                        className="form-control mt-5"
                                        id='reason'
                                    />
                                    {/* <span className='text-danger'><ErrorMessage name='comments' /></span> */}
                                </div>
                            </Form>
                        )}
                    </Formik>
                </CustomDialog>
            </div>
        </React.Fragment>
    )
}
export default VisitsActions;