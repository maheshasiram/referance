import _ from "lodash";
import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { dataEntryNavigation, toastAlert } from "../../../../../../actions/actions";
import { fetchOpenQuries, fetchStickyNotes } from "../../actions/action";
import { visitOpenQueries } from "../../constants/visitOpenQueries";
import { visitStickyNotes } from "../../constants/visitStickyNotes";
import OutStandingActions from "../helpers/outStandingActions/OutStandingActions";
import { configDataType, findAllVisitsByCriteria } from "./actions/action";
import VisitsDashBoard from "./components/VisitsDashBoard";
import VisitsFilters from "./components/VisitsFilters";
import '../../styles/Styles.scss'
import PageCount from "../../../../../../common/pagecount/PageCount";
import BoxContainer from "../helpers/BoxContainer";
import './styles/styles.scss'
import { Types } from "../../reducers/Types";

function Visits(props: any) {
    const dispatch = useDispatch()
    const { page } = useSelector((state: any) => state.application);
    const { subjectVisitParams } = useSelector((state: any) => state.subjects);
    const loaded = React.useRef(false);
    const { data } = props
    React.useEffect(() => {
        if (!loaded.current) {

            const payload: any = _.cloneDeep(page);
            // dispatch(fetchVisits(payload.currentSubjectId, (response: any) => {
            //     payload.tabs[parseInt(page.currentTab)].data.visits = {totalRecords:response.length,subjectVisits: response};
            //     dispatch(fetchOpenQuries(1, (queryResponse: any) => {
            //         payload.tabs[parseInt(page.currentTab)].data.openQuries = visitOpenQueries;
            //         dispatch(fetchStickyNotes(1, (stickyResponse: any) => {
            //             payload.tabs[parseInt(page.currentTab)].data.stickyNotes = visitStickyNotes;
            //         }));
            //     }));
            // }));
            const params = {
                ...subjectVisitParams, subjectId: payload.currentSubjectId, limit: 10, offset: 0, visitName: '', visitStatusCode: ''
            }
            dispatch(findAllVisitsByCriteria(params, (response: any) => {
                console.log('fetchAll callback....', response)
                if (response?.status === "error") {
                    payload.tabs[parseInt(page.currentTab)].data.visits = null;
                    dispatch(toastAlert({
                        status: 0,
                        open: true,
                        message: response.errorMessage
                    }))
                }else{
                    payload.tabs[parseInt(page.currentTab)].data.visits = response;
                    dispatch(fetchOpenQuries(1, () => {
                        payload.tabs[parseInt(page.currentTab)].data.openQuries = visitOpenQueries;
                        dispatch(fetchStickyNotes(1, () => {
                            payload.tabs[parseInt(page.currentTab)].data.stickyNotes = visitStickyNotes;
                        }));
                    }));

                }
            }))
            // loading the volunteer info
            dispatch(dataEntryNavigation(payload))
            dispatch(configDataType('VISIT_TYP', (response: any) => {
                dispatch({ type: Types.GET_VISIT_TYPES, payload: response.VISIT_STATUS })
            }))
            dispatch({ type: Types.SUBJECT_VISIT_PARAMS, payload: params })

            loaded.current = true;
        }
    }, [dispatch, page, subjectVisitParams])
    const onChangePageCount = (event: any) => {
        dispatch({ type: Types.SUBJECT_VISIT_PARAMS, payload: { ...subjectVisitParams, limit: event.target.value } })
    }
    return (
        <React.Fragment>
            <div className="subjects-container" >
                <div className=" d-flex col-sm-4 align-items-end mb-3 ">
                    <VisitsFilters />
                </div>
                <BoxContainer
                    dashboardHeader='Visits'
                    pageCount={<PageCount value={subjectVisitParams.limit} onChange={onChangePageCount} />}
                    dashBoard={<VisitsDashBoard data={data} />}
                    outStandingActions={<OutStandingActions data={data} />}
                />
            </div>
        </React.Fragment>
    )
}
export default Visits