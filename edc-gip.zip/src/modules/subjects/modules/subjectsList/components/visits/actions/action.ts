
import { Loader } from '../../../../../../../actions/actions';
import { studySetup } from '../../../../../../../configs/enivornment/studySetup';
import { subjects } from '../../../../../../../configs/enivornment/subjects';
import { fetch } from '../../../../../../../constants/fetch';
import { Types } from '../../../reducers/Types';

export const fetchVisits: any = (payload: any, callback: any) => {
    const url = `${subjects.visits.findAllBySubjectId}?subjectId=${payload}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
            data: ''
        })
            .then((response: any) => {
                if (callback) {
                    callback(response.data)
                    dispatch({ type: Types.GET_ALL_SUBJECTVISITS, payload: response.data });
                }
                dispatch(Loader(false))
            })
    }
}

export const fetchAssignedFormsByVisitId: any = (payload: any, callback: any) => {
    const url = `${studySetup.visits.fetchFormsByVisitId}?visitId=${payload}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
            data: payload,
        })
            .then((response: any) => {
                if (callback) { callback(response.data) }
                // dispatch({ type: Types.UNSCHEDULED_VISITS, payload: response.data });
                dispatch(Loader(false))
            })
    }
}
export const addUnscheduledVisit: any = (payload: any, callback: any) => {
    const url = `${subjects.visits.addUnscheduledVisit}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload,
        })
            .then((response: any) => {
                dispatch(Loader(false))
                if (callback) { callback(response) }
            })
            .catch((error: any) => {
                dispatch(Loader(false))
                if (callback) { callback(error) }

            })
    }
}
export const unlockVisit: any = (payload: any, callback: any) => {
    const url = `${subjects.visits.unlock}/${payload.subjectVisitId}?comments=${payload.comments}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
            data: payload,
        })
            .then((response: any) => {
                if (callback) {
                    callback(response)
                }
                dispatch(Loader(false))
            })
            .catch(() => {
                dispatch(Loader(false))
            })
    }
}
export const lockVisit: any = (payload: any, callback: any) => {
    const url = `${subjects.visits.lock}/${payload}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
            data: payload,
        })
            .then((response: any) => {
                dispatch(Loader(false))
                if (callback) {
                    callback(response)
                }
            }).catch((error: any) => {
                if (callback) { callback(error.response) }
                dispatch(Loader(false))
            })
    }
}
export const saveVisit: any = (payload: any) => {
    const url = `${subjects.visits.lock}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
            data: payload,
        })
            .then(() => {
                dispatch(Loader(false))
            })
    }
}
export const getById: any = (payload: any) => {
    const url = `${subjects.visits.getById}?subjectVisitId=${payload}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
            data: payload,
        })
            .then(() => {
                dispatch(Loader(false))
            })
    }
}

export const addScheduledVisit: any = (payload: any, callback: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: `${subjects.visits.addScheduledVisit}`,
            data: payload
        })
            .then((response: any) => {
                console.log('response addScheduledVisit.......', response)
                if (callback) { callback(response) }
                dispatch(Loader(false))
            })
    }
}

export const configDataType: any = (param: any, callback: any) => {
    const url = `${studySetup.configDataType}/${param}`
    return function () {
        fetch({
            method: 'GET',
            url: url,
            data: null,
        })
            .then((response: any) => {
                if (callback) { callback(response.data) }

            })
    }
}
export const findAllVisitsByCriteria: any = (payload: any, callback: any) => {
    const url = `${subjects.visits.findAllByCriteria}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload,
        })
            .then((response: any) => {
                dispatch(Loader(false))
                if (callback) { callback(response.data) }

            }).catch((error: any) => {
                dispatch(Loader(false))
                if (callback) { callback(error.response.data) }
            })
    }
}