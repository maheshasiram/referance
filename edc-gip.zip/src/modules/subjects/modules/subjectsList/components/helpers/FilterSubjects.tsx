import React from "react";

export default function FilterSubjects() {
    return (
        <div>

        </div>
    )
}
