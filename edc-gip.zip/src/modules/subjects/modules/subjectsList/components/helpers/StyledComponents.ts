import styled from 'styled-components';

export const BoxContainerDiv = styled.div`
font-family:'Roboto';
font-size:13px;
margin-top: 10px;
display: flex;
box-shadow: rgba(0, 0, 0, 0.35) 0px 1px 4px;
border-raddius:8px;
background:#FFF;

`;

export const DashBoardContainer = styled.div`
width: 67%;
padding: 10px 15px;
border-raddius:8px;
`;

export const OutStandingContainer = styled.div`
width: 33%;
background-color: #fbfbfb;
padding: 10px 15px;

`;
export const DashboardHeader = styled.div`
display:flex;
justify-content: space-between;
align-items: cenrter;

`;
export const Dashboard = styled.div`
margin-top: 10px;

`;

