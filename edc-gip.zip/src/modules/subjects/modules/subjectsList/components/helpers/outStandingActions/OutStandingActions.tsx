import React from 'react';
import Accordion from '@mui/material/Accordion';
import { styled } from '@mui/material/styles';
// import AccordionDetails from '@mui/material/AccordionDetails';
// import AccordionSummary from '@mui/material/AccordionSummary';
// import Typography from '@mui/material/Typography';
// import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import OpenQueries from './OpenQueries';
import StickyNotes from './StickyNotes';
import { useSelector } from 'react-redux';
// import Tab from '@mui/material/Tab';
// import TabContext from '@mui/lab/TabContext';
// import TabList from '@mui/lab/TabList';
// import TabPanel from '@mui/lab/TabPanel';

export const AccordionNexted = styled((props: any) => (
    <Accordion disableGutters elevation={0} square {...props} />
))(({ theme }) => ({
    background: '#FFF',
    border: `0px solid ${theme.palette.divider}`,
    '&:not(:last-child)': {
        borderBottom: `1px solid ${theme.palette.divider}`,
    },
    '&:before': {
        display: 'none',
    },
}));

function OutStandingActions(props: any) {
    // const [expanded, setExpanded] = React.useState('panel1');
    // const [nested, setNested] = React.useState('panel2');
    // const { data } = props;
    const { page, data = page.tabs[page.currentTab].data } = useSelector((state: any) => state.application);
    // const [value, setValue] = React.useState('1');

    // const handleChange = (event: React.SyntheticEvent, newValue: string) => {
    //     setValue(newValue);
    // };

    // const changeHandler = (panel: any) => (event: any, newExpanded: any) => {
    //     setExpanded(newExpanded ? panel : false);
    // };
    // const nestedChangeHandler = (panel: any) => (event: any, newExpanded: any) => {
    //     setNested(newExpanded ? panel : false);
    // };
    return (
        <React.Fragment>
            <div className='actions-header '>
                <h6  className='pb-2'>Outstanding Actions <span>
                    (<span>#{data.openQuries.count + data.stickyNotes.count}</span>)</span>
                </h6>
                <nav >
                    <div className="nav nav-tabs pt-2 px-3" id="nav-tab" role="tablist">
                        <button className="nav-link active" id="openQueries" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true">Open Queries</button>
                        <button className="nav-link" id="stickyNotes" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="false">Sticky Notes</button>
                    </div>
                </nav>
                <div className="tab-content data-table " id="nav-tabContent">
                    <div className="tab-pane fade show active" id="nav-home"
                        role="tabpanel" aria-labelledby="openQueries">
                        <OpenQueries data={data} />
                    </div>
                    <div className="tab-pane fade" id="nav-profile"
                        role="tabpanel" aria-labelledby="stickyNotes">
                        <StickyNotes data={data} />
                    </div>
                </div>
            </div>
        </React.Fragment >
    )
}
export default OutStandingActions;