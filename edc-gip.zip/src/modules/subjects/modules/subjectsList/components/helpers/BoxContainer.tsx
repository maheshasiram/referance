import React from "react";
import { BoxContainerDiv, Dashboard, DashBoardContainer, DashboardHeader, OutStandingContainer } from "./StyledComponents";
function BoxContainer(props: any) {
    const { dashboardHeader, pageCount, outStandingActions, dashBoard } = props;
    return (
        <React.Fragment>
            <BoxContainerDiv>
                <DashBoardContainer>
                    <DashboardHeader>
                        <h6> {dashboardHeader} </h6>
                        <div> {pageCount} </div>
                    </DashboardHeader>
                    <Dashboard>
                        {dashBoard}
                    </Dashboard>
                </DashBoardContainer>
                <OutStandingContainer>
                    {outStandingActions}
                </OutStandingContainer>
            </BoxContainerDiv>
        </React.Fragment>
    )
}
export default BoxContainer