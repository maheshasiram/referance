import React from 'react';
import { DataTable } from 'primereact/datatable';
import { useDispatch, useSelector } from "react-redux";
import volunteerType from "../../../../../../../common/Assests/subjectListImages/volunteerType.png";
import { Column } from 'primereact/column';
import { dataEntryNavigation } from '../../../../../../../actions/actions';

function OpenQueries(props: any) {
    const dispatch = useDispatch();
    const { data } = props;
    const { page } = useSelector((state: any) => state.application);

    const onNavigateToVisits = (rowData: any) => {
        const payload = { ...{}, ...page };
        payload.tabs[(parseInt(page.currentTab) + 1)].isActive = true;
        payload.tabs[(parseInt(page.currentTab) + 1)].label = rowData.label;
        payload.currentTab = (parseInt(page.currentTab) + 1).toString();
        dispatch(dataEntryNavigation(payload))
    }


    const onNavigateToForms = (rowData: any) => {
        const payload = { ...{}, ...page };
        payload.tabs[(parseInt(page.currentTab) + 1)].isActive = true;
        payload.tabs[(parseInt(page.currentTab) + 1)].label = rowData.eventName;
        payload.currentTab = (parseInt(page.currentTab) + 1).toString();
        dispatch(dataEntryNavigation(payload))
    }

    const onNavigateDynamicForms = (rowData: any) => {
        const payload = { ...{}, ...page };
        payload.tabs[(parseInt(page.currentTab) + 1)].isActive = true;
        payload.tabs[(parseInt(page.currentTab) + 1)].label = rowData.eventName;
        payload.currentTab = (parseInt(page.currentTab) + 1).toString();
        dispatch(dataEntryNavigation(payload))
    }

    const openQueriesData = (rowData: any, item: any) => {
        let columnData;
        if (item.field === "visitName") {
            columnData = item.field !== "count" ? <p onClick={() => onNavigateToForms(rowData)} style={{ cursor: "pointer" }}>{rowData.visitName}</p> : <p>{rowData.count}</p>
        } else if (item.field === "formName") {
            columnData = item.field !== "count" ? <p onClick={() => onNavigateDynamicForms(rowData)} style={{ cursor: "pointer" }}>{rowData.formName}</p> : <p>{rowData.count}</p>
        }
        else {
            columnData = item.field === "volunteer" ? 
            <a  href='#/' title="">
                <img src={volunteerType} alt="" />
                <span onClick={() => onNavigateToVisits(rowData)} 
                 className="d-inline-block px-1">{rowData.label}</span>
            </a> : item.field === "siteName" ? <p>{rowData.siteName}</p> : <p>{rowData.count}</p>
        }
        return columnData;
    }

    return (
        <React.Fragment>
            <p className='d-flex justify-content-end py-3 m-0'>Total Queries : 
            <span>{data.openQuries.count}</span></p>

            {data && data.openQuries.openQueries &&
                <DataTable
                    value={data.openQuries.openQueries}
                    rows={8}
                    scrollable
                    responsiveLayout="scroll">
                    {data.dataTableColumn.map((item: any, index: any) => (
                        <Column key={index} body={(rowData: any) => openQueriesData(rowData, item)} header={item.header}></Column>
                    ))}
                </DataTable>
            }
        </React.Fragment>
    )
}
export default OpenQueries;