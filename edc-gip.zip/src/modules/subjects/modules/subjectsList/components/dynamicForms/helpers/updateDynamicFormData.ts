export const updateDynamicFormData = (payload: any) => {
    let updateDynamicFormData: any;

    if (payload) {
        updateDynamicFormData = payload;
        sessionStorage.setItem('dynamicData', JSON.stringify(payload));
    } else {
        if (sessionStorage.dynamicData) {
            updateDynamicFormData = JSON.parse(sessionStorage.dynamicData);
        }
    }
    return updateDynamicFormData;
};

export const changeableProperties = (field: any) => {
    const { errorMsg, readOnly, id, index, isGroup, grpFieldIndex, freez, spellCheck, disable,
        value, rowIndex, minValueLength, maxValueLength, defaultValue, variableFieldFormat, isValueUpperCase, fldError, ruleError } = field;

    return { errorMsg, fldError, freez }
}

