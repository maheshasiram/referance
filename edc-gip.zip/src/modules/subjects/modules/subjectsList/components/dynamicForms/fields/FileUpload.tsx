import React, { Fragment, useState } from "react";
import TextField from '@mui/material/TextField';
import FieldContainer from "../helpers/FieldContainer";
import FormControl from '@mui/material/FormControl';
import { useDispatch, useSelector } from "react-redux";
import _ from "lodash";
import { Types } from "../../../reducers/Types";
import CustomToolTip from "../../../../../../../components/CustomToolTip";
import PriorityHighIcon from '@mui/icons-material/PriorityHigh';
import AutorenewIcon from '@mui/icons-material/Autorenew';
import { onResetValues } from "../helpers/resetValues";
import ImageView from "../helpers/ImageView";
import { getRulesByFieldId } from "../actions/actions";
import { changeableProperties, updateDynamicFormData } from "../helpers/updateDynamicFormData";

function FileUpload(props: any) {
    const dispatch = useDispatch()
    const {
        readOnly, index, isGroup, grpFieldIndex, /*freez,*/ id,
        value, rowIndex, fldError, uploadFileType, defaultValue, disable, ruleError,
    } = props;
    const [val, setVal]=useState(value ? value : defaultValue);
    const { dynamicFormData } = useSelector((state: any) => state.subjects);
    const { configCodes } = useSelector((state: any) => state.application);
    let payload = updateDynamicFormData(null);
    let field = isGroup ? payload.data[index]?.group?.rows[rowIndex]?.fields[grpFieldIndex] : payload.data[index]?.field;
    let _properties: any = changeableProperties(field);
    const { errorMsg, freez } = _properties;

    const [freezField, setFreezField] = useState(freez);

    const onChangeHandler = (event: any) => {
        console.log('payload of event....', event.target.files[0], uploadFileType?.code)
        const _file = event.target.files[0]
        const currentFileType = event?.target?.files[0]?.name?.substring(event?.target?.files[0]?.name?.indexOf('.') + 1)
        const fileType = dynamicType()?.substring(dynamicType()?.indexOf('.') + 1)
        // const payload = _.cloneDeep(dynamicFormData)
        payload = updateDynamicFormData(null);
        if (isGroup) {
            payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].value = (fileType === currentFileType) ? { ..._file, path: event.target.value } : ''
            payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].errorMsg = (fileType !== currentFileType) ? `Please upload ${fileType} type ` : ""
            delete payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].ruleError
        } else {
            payload.data[index].field.value = (fileType === currentFileType) ? { ..._file, path: event.target.value } : ''
            delete payload.data[index].field.fldError
            payload.data[index].field.errorMsg = (fileType !== currentFileType) ? `Please upload ${fileType} type ` : ""
            delete payload.data[index].field.ruleError;
        }
        updateDynamicFormData(payload);
        setVal((fileType === currentFileType) ? { ..._file, path: event.target.value } : '')
        // dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload })
    };
    console.log("...35", value)
    // const onResetValues = () => {
    //     const payload = _.cloneDeep(dynamicFormData)
    //     if (isGroup) {
    //         payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].value = null
    //     } else {
    //         payload.data[index].field.value = null
    //         delete payload.data[index].field.fldError
    //     }
    //     dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload })
    // }
    function dynamicType() {
        let docTYpe: any = ''
        switch (uploadFileType?.code) {
            case configCodes?.Doc:
                docTYpe = ".doc"
                break;
            case configCodes?.Jpg:
                docTYpe = ".jpg"
                break;
            case configCodes?.png:
                docTYpe = ".png"
                break;
            case configCodes?.Jpeg:
                docTYpe = ".jpeg"
                break;
            default:
                break;
        }
        return docTYpe
    }

    const onBlurHandler = () => {
        const payload = _.cloneDeep(dynamicFormData)
        console.log("75...", payload);
    }
    // console.log("47....", dynamicType())
    return (
        <Fragment>
            <FieldContainer {...props} setFreezField={setFreezField}>
                <FormControl className="field">
                    <TextField type={'file'} id={`field_${id}`}
                        className='de_file field'
                        value={val ? val.path : ''}
                        onChange={onChangeHandler}
                        disabled={readOnly || freezField || disable}
                        inputProps={{ accept: `${dynamicType()}` }}
                        onBlur={onBlurHandler}
                    />
                </FormControl>
                {value && <ImageView value={value} />}
                {fldError && <CustomToolTip title={fldError}>
                    <PriorityHighIcon
                        sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
                </CustomToolTip>}
                {ruleError && <CustomToolTip title={ruleError}>
                    <PriorityHighIcon
                        sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
                </CustomToolTip>}
               {((val) && (!disable && !freezField && !readOnly)) &&
                    <span className="ps-1 resetFieldValue">
                        <CustomToolTip title='clear value'>
                            <AutorenewIcon onClick={() => onResetValues(updateDynamicFormData(null), "", isGroup, null, dispatch, rowIndex, index, grpFieldIndex,setVal)}
                                sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
                        </CustomToolTip>
                    </span>
                }
            </FieldContainer>
        </Fragment>
    )
}
export default FileUpload