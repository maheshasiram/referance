import { totalScoreData } from "../../../../constants/totalScoreData";
import { extractCustomDerivation, extractDateLogic, extractNumericLogic, extractRowTargetDate, extractRowTargetTime, extractTimeLogic, extractVariableAutoPopulateValue, getLogicCompletedRows } from "./numericDerivation";
import store from "../../../../../../../../store/store";
import convert from 'convert-units'

export const getDerivativeValues = async (derivations: any, dynamicFormData: any) => {
    const logicCompleted: any = [];
    const targetCompleted: any = [];
    let allTargetsExicuted = false;
    let logicCompletedRows: any = [];
    if (derivations && derivations.length > 0) {
        if (derivations.length > 1) {
            // while (allTargetsExicuted === false) {
                const updateDerivationValues = await updateDerivativeValues(derivations, dynamicFormData, targetCompleted, logicCompleted, logicCompletedRows);
                console.log('allTargetsExicuted......2', targetCompleted.length, logicCompleted.length, targetCompleted)
                if (targetCompleted.length === logicCompleted.length) {
                    allTargetsExicuted = true;
                }
            // }
        } else {
            const updateDerivationValues = await updateDerivativeValues(derivations, dynamicFormData, targetCompleted, logicCompleted, logicCompletedRows);
        }
        console.log('allTargetsExicuted......2', targetCompleted.length, logicCompleted.length, logicCompletedRows)

    }

    return dynamicFormData;
}

const updateLogicValues = async (derivationItem: any, dynamicFormData: any, logicCompletedRows: any) => {
    const _configCodes: any = store.getState().application.configCodes;
    const _derivationItem = { ...{}, ...derivationItem };
    _derivationItem.logicCompletd = true;
    if (derivationItem?.actionType?.code === _configCodes?.CustomDerivation) {
        dynamicFormData?.data?.map((data: any) => {
            derivationItem?.logic?.logicVariables?.map((item: any, itemIndex: number) => {
                item?.fields?.map((res: any, resIndex: number) => {
                    // if (res.formId === parseInt(dynamicFormData.formId)) {
                    if (res.fieldId === parseInt(data.field.fieldId)) {
                        const _findResponse = res?.responseOptions.find((resEle: any) => resEle.response == data.field.value)
                        _derivationItem.logic.logicVariables[itemIndex].fields[resIndex].value = _findResponse ? _findResponse.value : null
                        // logicFieldExist = true
                        if (!_derivationItem.logic.logicVariables[itemIndex].fields[resIndex].value) {
                            _derivationItem.logicCompletd = false;
                        }
                    } else if (res.formId != dynamicFormData.formId) {
                        if (!res.value) {
                            _derivationItem.logicCompletd = false;
                        }
                    }
                    // }
                    // return null;
                });
                // return null;
            });
            // return null;
        });
    } else if (derivationItem?.actionType?.code === _configCodes?.NumericCalculation) {
        dynamicFormData?.data?.map((data: any) => {
            // let _value = data.field.value
            derivationItem?.logic?.logicVariables?.map((item: any, itemIndex: number) => {
                if ((derivationItem?.logic?.formula?.formulaCode == "AGE") || (derivationItem?.logic?.formula?.formulaCode == "BMI")) {
                    if (derivationItem?.logic?.formula?.formulaCode == "BMI") {
                        item?.denominatorFields?.map((ele: any, eleIndex: number) => {
                            // if (ele.formId == dynamicFormData.formId) {
                            if (ele.fieldId == data.field.fieldId) {
                                let _value = data.field.value
                                if (ele.units && ele.updatedUnit) {
                                    _value = convert(data.field.value).from(ele.units).to(ele.updatedUnit)
                                }
                                _derivationItem.logic.logicVariables[itemIndex].denominatorFields[eleIndex].value = _value
                                if (!_derivationItem.logic.logicVariables[itemIndex].denominatorFields[eleIndex].value) {
                                    _derivationItem.logicCompletd = false;
                                }
                            } else if (ele.formId != dynamicFormData.formId) {
                                if (!ele.value) {
                                    _derivationItem.logicCompletd = false;
                                }
                            }
                            // }
                        })
                    }
                    item?.numeratorFields?.map((ele: any, eleIndex: number) => {
                        // if (ele.formId == dynamicFormData.formId) {
                        if (ele.fieldId == data.field.fieldId) {
                            let _value = data.field.value
                            if (ele.units && ele.updatedUnit) {
                                _value = convert(data.field.value).from(ele.units).to(ele.updatedUnit)
                            }
                            _derivationItem.logic.logicVariables[itemIndex].numeratorFields[eleIndex].value = _value
                            if (!_derivationItem.logic.logicVariables[itemIndex].numeratorFields[eleIndex].value) {
                                _derivationItem.logicCompletd = false;
                            }
                        } else if (ele.formId != dynamicFormData.formId) {
                            if (!ele.value) {
                                _derivationItem.logicCompletd = false;
                            }
                        }
                        // }
                    })
                } else {
                    item?.fields?.map((ele: any, eleIndex: number) => {
                        // if (ele.formId == dynamicFormData.formId) {
                        if (ele.fieldId == data?.field?.fieldId) {
                            let _value = data.field.value
                            if (ele.units && ele.updatedUnit) {
                                _value = convert(data.field.value).from(ele.units).to(ele.updatedUnit)
                            }
                            _derivationItem.logic.logicVariables[itemIndex].fields[eleIndex].value = _value
                            if (!_derivationItem.logic.logicVariables[itemIndex].fields[eleIndex].value) {
                                _derivationItem.logicCompletd = false;
                            }
                        } else if (ele.formId != dynamicFormData.formId) {
                            if (!ele.value) {
                                _derivationItem.logicCompletd = false;
                            }
                        }
                        // }
                    })
                }
            })
        })
    } else if ((derivationItem?.actionType?.code === _configCodes?.DateCalculation) ||
        (derivationItem?.actionType?.code === _configCodes?.TimeCalculation)) {
        let uniqueGrpRows: any = []
        let grpLogicFieldCount: any = 0
        dynamicFormData?.data.map(async (data: any, dataIndex: number) => {
            derivationItem?.logic?.logicVariables.map(async (item: any, itemIndex: any) => {
                if ((data?.group?.id == item?.groupId)) {
                    if (item.groupId) { grpLogicFieldCount += 1 }
                    data?.group?.rows?.map((row: any, rowIndex: number) => {
                        item?.value?.map((rowItem: any, rowItemIndex: number) => {
                            if (row.rowId == rowItem.rowId) {
                                row.fields.map((rowField: any, rowFieldIndex: number) => {
                                    if (rowField.fieldId == rowItem.fieldId) {
                                        _derivationItem.logic.logicVariables[itemIndex].value[rowItemIndex].value = rowField.value;
                                        // grpLogicFieldCount += 1
                                        if (rowField.value) {
                                            uniqueGrpRows.push(rowItem.rowId)
                                        }
                                    }
                                })
                            }
                        })
                    })
                }
                // else {

                if (item?.fieldId === data?.field?.fieldId) {
                    _derivationItem.logic.logicVariables[itemIndex].value = data.field.value;
                    if (!_derivationItem.logic.logicVariables[itemIndex].value) {
                        _derivationItem.logicCompletd = false;
                    }
                } else if (item.formId != dynamicFormData.formId) {
                    if (!item.value) {
                        _derivationItem.logicCompletd = false;
                    }
                }
                // }
            });
        });
        let _logicCompletedRows = await getLogicCompletedRows(uniqueGrpRows, grpLogicFieldCount)
        _derivationItem.logicCompletedRows = _logicCompletedRows
        if (_logicCompletedRows.length <= 0 && grpLogicFieldCount > 0 /* && (!_derivationItem.logicCompletd) */) {
            _derivationItem.logicCompletd = false;
        }
    } else if (derivationItem?.actionType?.code === _configCodes?.VariableAutoPopulation) {
        dynamicFormData?.data.map((data: any, dataIndex: number) => {
            derivationItem?.logic?.logicVariables.map((item: any, itemIndex: any) => {
                if (item?.fieldId === data?.field?.fieldId) {
                    _derivationItem.logic.logicVariables[itemIndex].value = data.field.value;
                    if (!_derivationItem.logic.logicVariables[itemIndex].value) {
                        _derivationItem.logicCompletd = false;
                    }
                } else if (item.formId != dynamicFormData.formId) {
                    if ((!item.value) || (item.value == '')) {
                        _derivationItem.logicCompletd = false;
                    }
                }
            });
        });
    }
    return _derivationItem;
}

const updateTargetValues = async (derivationItem: any, dynamicFormData: any) => {
    const application = store.getState().application
    const { configCodes }: any = store.getState().application;

    const _derivationItem = { ...{}, ...derivationItem };
    const _dynamicFormData = { ...{}, ...dynamicFormData };
    _derivationItem.targetCompletd = false;
    let _logicValue: any;
    // logic will be extracted only when the Derivation logic is completed
    if (derivationItem.logicCompletd) {

        if (derivationItem?.actionType?.code === configCodes?.TimeCalculation) {
            _logicValue = await extractTimeLogic(_derivationItem);
        }
        else if (derivationItem?.actionType?.code === configCodes?.DateCalculation) {
            _logicValue = await extractDateLogic(_derivationItem);
        }
        else if (derivationItem?.actionType?.code === configCodes?.CustomDerivation) {

            _logicValue = await extractCustomDerivation(_derivationItem, dynamicFormData);
        } else if (derivationItem?.actionType?.code === configCodes?.NumericCalculation) {
            _logicValue = await extractNumericLogic(_derivationItem);
        } else if (derivationItem?.actionType?.code === configCodes?.VariableAutoPopulation) {
            _logicValue = await extractVariableAutoPopulateValue(_derivationItem)
        }
        // if (derivationItem.logicCompletd) {
        dynamicFormData.data.map((data: any, dataIndex: number) => {
            derivationItem.target.targetVariables.map(async (item: any, itemIndex: any) => {
                _derivationItem.target.targetVariables[itemIndex].value = _logicValue;
                let groupTargetPresent: any
                if (((derivationItem?.actionType?.code === configCodes?.DateCalculation) ||
                    (derivationItem?.actionType?.code === configCodes?.TimeCalculation) &&
                    derivationItem?.logicCompletedRows?.length > 0)) {
                    if (item.groupId == data.group?.id) {
                        data.group?.rows?.map((row: any, rowIndex: number) => {
                            row?.fields?.map(async (field: any, fieldIndex: number) => {
                                let _rowLogicValue: any = ''
                                if (item.id == field.fieldId) {
                                    if (derivationItem?.actionType?.code === configCodes?.DateCalculation) {
                                        _rowLogicValue = await extractRowTargetDate(derivationItem, row, derivationItem.logicCompletedRows)
                                    } else if (derivationItem?.actionType?.code === configCodes?.TimeCalculation) {
                                        _rowLogicValue = await extractRowTargetTime(derivationItem, row, derivationItem.logicCompletedRows)
                                    }
                                    if (_rowLogicValue) { groupTargetPresent = true }
                                    _dynamicFormData.data[dataIndex].group.rows[rowIndex].fields[fieldIndex].value = _rowLogicValue;
                                    const input = document.getElementById('field_' + `${field.id}`) as HTMLInputElement;
                                    input.value = _rowLogicValue
                                }
                            })
                        })
                    }
                }

                if (_derivationItem.target.targetVariables[itemIndex].value || groupTargetPresent) {
                    _derivationItem.targetCompletd = true;
                }
                if (item?.id === data?.field?.fieldId) {
                    _dynamicFormData.data[dataIndex].field.value = _logicValue;
                    const input = document.getElementById('field_' + `${data.field.id}`) as HTMLInputElement;
                    input.value = _logicValue;
                }
            });
            if (_derivationItem?.actionType?.code === configCodes?.CustomDerivation && _derivationItem?.customDerivationType?.code === application?.configCodes?.TotalScore) {
                _derivationItem.dependentTargetVar.map((dtVar: any, dtIndex: any) => {
                    _derivationItem.dependentTargetVar[dtIndex].value = totalScoreData[_logicValue as keyof typeof totalScoreData]
                    if (dtVar?.id === data?.field?.fieldId) {
                        _dynamicFormData.data[dataIndex].field.value = totalScoreData[_logicValue as keyof typeof totalScoreData];
                    }
                    return null;
                })
            }
            return null;
        });
    }
    return { _derivationItem, _dynamicFormData };
}

export const updateDerivativeValues = async (derivations: any, dynamicFormData: any, targetCompleted: any, logicCompleted: any, logicCompletedRows: any) => {
    const _derivations: any = [...[], ...derivations];
    let _dynamicFormData = { ...{}, ...dynamicFormData }
    derivations.map(async (derivationItem: any, derivationIndex: number) => {
        _derivations[derivationIndex] = await updateLogicValues(derivationItem, _dynamicFormData, logicCompletedRows);
        if (_derivations[derivationIndex].logicCompletd && (logicCompleted.indexOf(_derivations[derivationIndex].id) === -1)) {
            logicCompleted.push(_derivations[derivationIndex].id);
        }
        const updatedData = await updateTargetValues(_derivations[derivationIndex], _dynamicFormData);
        _derivations[derivationIndex] = updatedData._derivationItem;
        _dynamicFormData = updatedData._dynamicFormData;
        if (_derivations[derivationIndex].targetCompletd && (targetCompleted.indexOf(_derivations[derivationIndex].id) === -1)) {
            targetCompleted.push(_derivations[derivationIndex].id);
        }
    });
    return _dynamicFormData;
}


export const resetDerivation = (dynamicFormData: any, fieldId: any, isGroup: any, fldFields: any, rowIndex: any, mainIndex: any, grpFieldIndex: any) => {

    const { derivations }: any = store.getState().subjects;
    const { configCodes }: any = store.getState().application
    let _derivativeIndex: any = []
    if (derivations.length > 0 && fieldId) {
        derivations?.map((derv: any, drevIndex: number) => {
            if (derv?.actionType?.code === configCodes?.TimeCalculation || derv?.actionType?.code === configCodes?.DateCalculation || derv?.actionType?.code === configCodes?.VariableAutoPopulation) {
                derv?.logic?.logicVariables?.map((item: any, itemIndex: number) => {
                    if (item.fieldId === fieldId) {
                        _derivativeIndex.push(derv.id)
                    }
                })
            } else if (derv?.actionType?.code === configCodes?.CustomDerivation) {
                derv?.logic?.logicVariables?.map((item: any, itemIndex: number) => {
                    item?.fields?.map((field: any, fieldIndex: number) => {
                        if (field.fieldId === fieldId) {
                            _derivativeIndex.push(derv.id)
                        }
                    })
                })

            } else if (derv?.actionType?.code === configCodes?.NumericCalculation) {
                if (Object.keys(derv?.logic?.formula).length > 0 && derv?.logic?.formula?.formulaCode === "BMI") {
                    derv?.logic?.logicVariables?.map((item: any, itemIndex: number) => {
                        item?.denominatorFields?.map((ele: any, eleIndex: number) => {
                            if (ele.fieldId === fieldId) {
                                _derivativeIndex.push(derv.id)
                            }
                        })
                        item?.numeratorFields?.map((ele: any, eleIndex: number) => {
                            if (ele.fieldId === fieldId) {
                                _derivativeIndex.push(derv.id)
                            }
                        })
                    })
                } else if (Object.keys(derv?.logic?.formula).length > 0 && derv?.logic?.formula?.formulaCode === "AGE") {
                    derv?.logic?.logicVariables?.map((item: any, itemIndex: number) => {
                        item?.numeratorFields?.map((ele: any, eleIndex: number) => {
                            if (ele.fieldId === fieldId) {
                                _derivativeIndex.push(derv.id)
                            }
                        })
                    })

                }
                else {
                    derv?.logic?.logicVariables?.map((item: any, itemIndex: number) => {
                        item?.fields?.map((field: any, fieldIndex: number) => {
                            if (field.fieldId === fieldId) {
                                _derivativeIndex.push(derv.id)
                            }
                        })
                    })
                }
            }
        })
    }
    if (_derivativeIndex.length > 0) {
        dynamicFormData?.data?.map((dynamicForm: any, index: number) => {
            derivations?.map((item: any, itemIndex: number) => {
                let _Index = _derivativeIndex.findIndex((id: any) => id == item.id)
                if (_Index !== -1) {
                    item.target.targetVariables.map((target: any) => {
                        if (target.id == dynamicForm.field?.fieldId) {
                            dynamicFormData.data[index].field.value = null
                        }
                        if (target.groupId) {
                            if (index == mainIndex && isGroup) {
                                dynamicForm.group.rows[rowIndex].fields.map((rowField: any, rowFielfIndex: number) => {
                                    if (target.id == rowField.fieldId) {
                                        dynamicFormData.data[index].group.rows[rowIndex].fields[rowFielfIndex].value = null
                                        const input: any = document.getElementById('field_' + `${rowField.id}`) as HTMLInputElement;
                                        input.value = null
                                    }
                                })
                            } else if (!isGroup) {
                                dynamicForm?.group?.rows?.map((row: any, _rowindex: any) => {
                                    row.fields.map((rowField: any, rowFielfIndex: number) => {
                                        if (target.id == rowField.fieldId) {
                                            dynamicFormData.data[index].group.rows[_rowindex].fields[rowFielfIndex].value = null
                                            const input: any = document.getElementById('field_' + `${rowField.id}`) as HTMLInputElement;
                                            input.value = null
                                        }
                                    })
                                })
                            }
                        }
                    })
                }
            })
        })
    }
    return dynamicFormData

}

export const derivationExist = (dynamicFormData: any, fieldId: any, isGroup: any, fldFields: any, rowIndex: any, mainIndex: any, grpFieldIndex: any) => {
    const { derivations }: any = store.getState().subjects;
    const { configCodes }: any = store.getState().application
    let _derivationExist: any = false

    if (derivations.length > 0 && fieldId) {
        derivations?.map((derv: any, drevIndex: number) => {
            if (derv?.actionType?.code === configCodes?.TimeCalculation || derv?.actionType?.code === configCodes?.DateCalculation || derv?.actionType?.code === configCodes?.VariableAutoPopulation) {
                derv?.logic?.logicVariables?.map((item: any, itemIndex: number) => {
                    if (item.fieldId === fieldId) {
                        // _derivativeIndex.push(derv.id)
                        _derivationExist = true
                    }
                })
            } else if (derv?.actionType?.code === configCodes?.CustomDerivation) {
                derv?.logic?.logicVariables?.map((item: any, itemIndex: number) => {
                    item?.fields?.map((field: any, fieldIndex: number) => {
                        if (field.fieldId === fieldId) {
                            _derivationExist = true
                            // _derivativeIndex.push(derv.id)
                        }
                    })
                })

            } else if (derv?.actionType?.code === configCodes?.NumericCalculation) {
                if (Object.keys(derv?.logic?.formula).length > 0 && derv?.logic?.formula?.formulaCode === "BMI") {
                    derv?.logic?.logicVariables?.map((item: any, itemIndex: number) => {
                        item?.denominatorFields?.map((ele: any, eleIndex: number) => {
                            if (ele.fieldId === fieldId) {
                                _derivationExist = true
                                // _derivativeIndex.push(derv.id)
                            }
                        })
                        item?.numeratorFields?.map((ele: any, eleIndex: number) => {
                            if (ele.fieldId === fieldId) {
                                _derivationExist = true
                                // _derivativeIndex.push(derv.id)
                            }
                        })
                    })
                } else if (Object.keys(derv?.logic?.formula).length > 0 && derv?.logic?.formula?.formulaCode === "AGE") {
                    derv?.logic?.logicVariables?.map((item: any, itemIndex: number) => {
                        item?.numeratorFields?.map((ele: any, eleIndex: number) => {
                            if (ele.fieldId === fieldId) {
                                _derivationExist = true
                                // _derivativeIndex.push(derv.id)
                            }
                        })
                    })

                }
                else {
                    derv?.logic?.logicVariables?.map((item: any, itemIndex: number) => {
                        item?.fields?.map((field: any, fieldIndex: number) => {
                            if (field.fieldId === fieldId) {
                                _derivationExist = true
                                // _derivativeIndex.push(derv.id)
                            }
                        })
                    })
                }
            }
        })
    }
    return _derivationExist
}