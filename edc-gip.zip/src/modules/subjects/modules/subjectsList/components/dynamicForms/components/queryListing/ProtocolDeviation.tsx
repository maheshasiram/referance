import React from 'react';
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { useDispatch, useSelector } from 'react-redux';
import CustomToolTip from '../../../../../../../../components/CustomToolTip';
import ReplayIcon from '@mui/icons-material/Replay';
import DeleteIcon from '@mui/icons-material/Delete';
import { deleteRestoreDeviation, fetchProtocolDeviations } from '../../actions/actions';
import { configDataType } from '../../../../../../../../actions/actions';
import { Types } from '../../../../reducers/Types';

function ProtocolDeviation(props: any) {
    const { fetchAllDeviationRecords, deviationTypes, deviationCategories } = useSelector((state: any) => state.subjects);
    const { subjectFieldId } = props;
    const dispatch = useDispatch();
    const loaded = React.useRef(false);

    React.useEffect(() => {
        if (!loaded.current) {
            dispatch(configDataType('DEVIATION_TYPE', (response: any) => {
                dispatch({ type: Types.GET_DEVIATION_TYPE, payload: response });
            }));
            dispatch(configDataType('CATEGORY_TYPE', (response: any) => {
                dispatch({ type: Types.GET_PROTOCOL_CATEGORIES, payload: response });
            }));
            loaded.current = true
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    console.log("..fetchAllDeviationRecords", fetchAllDeviationRecords)
    const onDeleteRestoreDeviation = (type: any, rowData: any) => {
        const _paylaod = {
            protocolDeviationId: rowData.id,
            status: rowData.status === false ? true : false,

        }
        dispatch(deleteRestoreDeviation(_paylaod, (response: any) => {
            console.log("rowData13", rowData, response);
            dispatch(fetchProtocolDeviations(subjectFieldId));
        }));
    }

    const actionsTemplate = (rowData: any) => {
        return (<React.Fragment>
            <div className="d-flex align-items-center" onClick={(e) => e.stopPropagation()}>
                <>{console.log("...19", rowData)}</>
                {rowData.status === true ? <React.Fragment>
                    <CustomToolTip title="Delete Deviation"><DeleteIcon sx={{ fontSize: 22, opacity: .8 }} className="text-danger" onClick={() => onDeleteRestoreDeviation('delete', rowData)} /></CustomToolTip>
                </React.Fragment> : <CustomToolTip title='Restore deviation'><ReplayIcon sx={{ fontSize: 22, opacity: .8 }} onClick={() => onDeleteRestoreDeviation('restore', rowData)} /></CustomToolTip>}
            </div>
        </React.Fragment>)
    }

    const deviationTypeTemplate = (rowData: any) => {
        const _deviationType = deviationTypes?.DEVIATION_TYPE?.find((item: any) => item.code === rowData.deviationTypeCode);
        console.log("..._deviationType", _deviationType?.name);
        return (
            <div>{_deviationType?.name}</div>
        )
    }

    const deviationCategoryTemplate = (rowData: any) => {
        const _deviationCategory = deviationCategories?.CATEGORY_TYPE?.find((item: any) => item.code === rowData.categoryCode);
        console.log("..._deviationCategory", _deviationCategory?.name);
        return (
            <div>{_deviationCategory?.name}</div>
        )
    }
    return (
        <React.Fragment>
            <div className='deviations'>
                {/* <div className='d-flex justify-content-end'><AddProtocalDeviation /></div> */}
                <div className='mt-3 mb-3 deviationTable'>
                    <DataTable scrollable value={fetchAllDeviationRecords && fetchAllDeviationRecords} stripedRows={true} scrollHeight="300px"
                        responsiveLayout="scroll"
                        selectionMode="single"
                        emptyMessage="No Protocol Deviations Are Available To Display">
                        <Column body={deviationTypeTemplate} header="Deviation Type" ></Column>
                        <Column body={deviationCategoryTemplate} header="Category" ></Column>
                        <Column field="description" header="Description" ></Column>
                        <Column header='Action' body={actionsTemplate}></Column>
                    </DataTable>
                </div>
            </div>
        </React.Fragment>
    );
}
export default ProtocolDeviation;
