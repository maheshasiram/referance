import React, { Fragment, useState, useEffect } from "react";
// import { MuiPickersUtilsProvider, KeyboardDatePicker } from "@material-ui/pickers";
// import Select from '@mui/material/Select';
// import moment, { now } from "moment";
// import MomentUtils from "@date-io/moment";
// import InstructionsHelper from '../helpers/InstructionsHelper';
import FieldContainer from "../helpers/FieldContainer";
import { useDispatch, useSelector } from "react-redux";
import _ from 'lodash'
import { Types } from "../../../reducers/Types";
import AutorenewIcon from '@mui/icons-material/Autorenew';
import CustomToolTip from "../../../../../../../components/CustomToolTip";
import PriorityHighIcon from '@mui/icons-material/PriorityHigh';
import { onResetValues } from "../helpers/resetValues";
import { onReasonToChange } from "../helpers/resonTochange";
import { getRulesByFieldId } from "../actions/actions";
import { changeableProperties, updateDynamicFormData } from "../helpers/updateDynamicFormData";

function PartialDate(props: any) {
    const dispatch = useDispatch()
    const {
        readOnly, index, isGroup, grpFieldIndex, rowIndex, /*freez,*/ fldError, value, defaultValue, disable, ruleError
    } = props;
    const { currentStudy, page } = useSelector((state: any) => state.application);
    const { dynamicFormData, entryFormData } = useSelector((state: any) => state.subjects);
    const [val, setVal] = useState(value ? value : defaultValue);

    const format = currentStudy.dateFormat?.split(/-/);
    const _val = value ? value?.split(/-/) : defaultValue?.split(/-/);
    const dateinitialValues: any = {}
    format?.map((item: any, i: number) => {
        dateinitialValues[item] = _val ? _val[i] : ""
        return null
    });
    const [dateFields, setDateFields] = useState(dateinitialValues)
    useEffect(() => {
        if (val && val.trim() !== '') {
            const _date = val.split('-')
            // const _timeFields = [...[], ...dateFields]
            const _timeFields = { ...{}, ...dateFields }
            // _date.map((item: any, index: number) => {
            //     _timeFields[index].value = item
            //     return null
            // })
            setDateFields(_timeFields)
        }

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    let _formatValues: any = {}
    format.map((item: any) => {
        return _formatValues[item] = ""
    });

    const data = format?.find((month: any) => {
        return month === ("MM" || "MMM")
    });

    const monthsMMM = ["MMM", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Oct", "Nov", "Dec"];
    const monthsMM = ["MM", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"]


    let payload = updateDynamicFormData(null);
    let field = isGroup ? payload.data[index]?.group?.rows[rowIndex]?.fields[grpFieldIndex] : payload.data[index]?.field;
    let _properties: any = changeableProperties(field);
    const { errorMsg, freez } = _properties;

    const [freezField, setFreezField] = useState(freez);

    const partialDateChangeHandler = (event: any, dateIndex: any, val: any) => {
        payload = updateDynamicFormData(null);
        const data = { ...dateFields };
        data[val] = event.target.value
        setDateFields(data);
        const date = []
        for (const dateKey in data) {
            date.push(data[dateKey])
        }
        const fullDate = date.map((item: any) => item ? item : 'un').join('-')
        let error :any = ''
        format?.map((item: any) => {
            let _value = parseInt(data[item])
            if (((item == "DD")) && _value > 31) {
                error = 'Please enter date below 31'
            }
        })
        // let payload = _.cloneDeep(dynamicFormData)
        payload = onReasonToChange(isGroup, payload, index, rowIndex, grpFieldIndex, fullDate, page, entryFormData)
        if (isGroup) {
            payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].value = fullDate;
            payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].errorMsg = error;
            delete payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].ruleError
        } else {
            payload.data[index].field.value = fullDate;
            payload.data[index].field.errorMsg = error;
            delete payload.data[index].field.fldError
            delete payload.data[index].field.ruleError;
        }
        updateDynamicFormData(payload);
        setVal(fullDate)
        // dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload })
    }
    
    // const onClearPartialDate = () => {
    //     const payload = _.cloneDeep(dynamicFormData)
    //     if (isGroup) {
    //         // payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].value = dateinitialValues;
    //         setDateFields(dateinitialValues)
    //     } else {
    //         // payload.data[index].field.value = dateinitialValues;
    //         setDateFields(dateinitialValues)
    //     }
    //     dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload })
    // }

    const onBlurHandle = () => {
        const payload = _.cloneDeep(dynamicFormData)
    }
    return (
        <Fragment>
            <FieldContainer {...props} setFreezField={setFreezField} >
                <div className="d-flex" key={''}>
                    {format?.map((item: any, dateIndex: any) => {
                        return (
                            <div key={dateIndex}>
                                {item === 'DD' ? <input type="text"
                                    id={item}
                                    key={`txt_${dateIndex}`}
                                    name={item}
                                    style={{ width: "45px" }}
                                    className={dateIndex !== 0 ? "border ms-2" : "border"}
                                    placeholder={item}
                                    disabled={readOnly || freezField || disable}
                                    value={dateFields[item]}
                                    onChange={(event: any) => partialDateChangeHandler(event, dateIndex, item)}
                                    maxLength={2}
                                    onBlur={onBlurHandle}
                                /> :
                                    item === ('MM' || 'MMM') ?
                                        <select name={item}
                                            id="Month"
                                            key={`slct_${dateIndex}`}
                                            style={{ padding: "4px" }}
                                            className={dateIndex !== 0 ? "border ms-2" : "border"}
                                            value={dateFields[item]}
                                            disabled={readOnly || freezField || disable}
                                            // onBlur={onBlurHandle}
                                            onChange={(event: any) => partialDateChangeHandler(event, dateIndex, item)}
                                        >
                                            {
                                                (data === "MM" ? monthsMM : monthsMMM)?.map((item: any) => {
                                                    return <option key={item} value={(item === 'MM' || item === 'MMM') ? '' : item}>{item}</option>
                                                })
                                            }
                                        </select> :
                                        item === 'YYYY' ? <input type="text" id="Year"
                                            placeholder={item}
                                            name={item}
                                            key={`txt_${dateIndex}`}
                                            style={{ width: "54px" }}
                                            className={dateIndex !== 0 ? "border ms-2" : "border"}
                                            value={dateFields[item]}
                                            disabled={readOnly || freezField || disable}
                                            onChange={(event: any) => partialDateChangeHandler(event, dateIndex, item)}
                                            maxLength={4}
                                        // onBlur={onBlurHandle}
                                        /> : ''}
                            </div>)
                    })}
                    {((val) && (!disable && !freezField && !readOnly)) &&
                        <span className="ps-1 resetFieldValue">
                            <CustomToolTip title='clear value'>
                                <AutorenewIcon onClick={() => onResetValues(updateDynamicFormData(null), _formatValues, isGroup, null, dispatch, rowIndex, index, grpFieldIndex, setDateFields)}
                                    sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
                            </CustomToolTip>
                        </span>
                    }
                    {fldError && <CustomToolTip title={fldError}>
                        <PriorityHighIcon
                            sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
                    </CustomToolTip>}
                    {ruleError && <CustomToolTip title={ruleError}>
                        <PriorityHighIcon
                            sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
                    </CustomToolTip>}
                </div>

            </FieldContainer>
        </Fragment >
    )
}
export default PartialDate