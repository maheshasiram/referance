import React, { Fragment, useState } from "react";
import FormControl from '@mui/material/FormControl';
import { Types } from "../../../reducers/Types";
import { useDispatch, useSelector } from "react-redux";
import _ from 'lodash'
import Select from 'react-select';
import FieldContainer from "../helpers/FieldContainer";
import CustomToolTip from "../../../../../../../components/CustomToolTip";
import PriorityHighIcon from '@mui/icons-material/PriorityHigh';
import { onReasonToChange } from "../helpers/resonTochange";
import AutorenewIcon from '@mui/icons-material/Autorenew';
import { onResetValues } from "../helpers/resetValues";
import { getRulesByFieldId } from "../actions/actions";
import { changeableProperties, updateDynamicFormData } from "../helpers/updateDynamicFormData";


function MultiSelect(props: any) {
    const dispatch = useDispatch()
    const {
        // header, note, onAirInstruction, variableText, defaultValue, questionNumber,layout,
        /*freez,*/ readOnly, id, index, isGroup, grpFieldIndex, value, rowIndex, responseOptions, ruleError,
        fldError, fldFields, defaultValue, disable
    } = props;
    const { dynamicFormData, entryFormData } = useSelector((state: any) => state.subjects);
    const { page } = useSelector((state: any) => state.application);
    const [val, setVal]=useState(value ? value : defaultValue);
    let payload = updateDynamicFormData(null);
    let field = isGroup ? payload.data[index]?.group?.rows[rowIndex]?.fields[grpFieldIndex] : payload.data[index]?.field;
    let _properties: any = changeableProperties(field);
    const { errorMsg, freez } = _properties;

    const [freezField, setFreezField] = useState(freez);
    const onChangeHandler = (event: any) => {
        // const _checked = value ? value.split(',') : []
        // const _selected = Array.prototype.map.call(event, function(item) { return item.value; }).join(",");
        const _selected = event.map((item: any) => { return item.value }).join(',');
        console.log("23.....", event, _selected)
        // let payload = _.cloneDeep(dynamicFormData)
        payload = updateDynamicFormData(null);
        payload = onReasonToChange(isGroup, payload, index, rowIndex, grpFieldIndex, event, page, entryFormData)
        if (isGroup) {
            payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].value = _selected
            console.log("28.............", payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].value)
        } else {
            payload.data[index].field.value = _selected
            delete payload.data[index].field.fldError
        }
        // console.log('payload.........singleselct', payload)
        // dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload })
        updateDynamicFormData(payload);
		setVal(_selected)
    };

    const selectOptions = (responseOptions: any) => {
        const options: any = []
        responseOptions?.map((item: any) => {
            const option = {
                label: item.response,
                value: item.id
            }
            options.push(option)
            return null;
        })
        return options
    }
    const getSelectedValue = (responseOptions: any) => {
        const options: any = [];
        responseOptions?.map((item: any) => {
            if (val?.includes(item?.id)) {
                const option = {
                    label: item.response,
                    value: item.id
                }
                options.push(option);
            }
            return null;
        })
        return options;
    }

    const onBlurHandle = () => {
        const payload = _.cloneDeep(dynamicFormData)
        console.log("72...", payload);
    }

    return (
        <Fragment>
            <FieldContainer {...props}  setFreezField={setFreezField}>
                <FormControl className="field">
                    <Select
                        id={`field_${id}`}
                        className="df_multiselect field"
                        classNamePrefix="multiSelect"
                        defaultValue="Select your Form"
                        isDisabled={readOnly || setFreezField || disable}
                        isClearable={true}
                        isSearchable={true}
                        name={`multi_select_${id}`}
                        isMulti={true}
                        value={getSelectedValue(responseOptions)}
                        onChange={onChangeHandler}
                        options={selectOptions(responseOptions)}
                        placeholder={props.placeholder}
                        onBlur={onBlurHandle}
                    />
                </FormControl>

                {fldError && <CustomToolTip title={fldError}>
                    <PriorityHighIcon
                        sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
                </CustomToolTip>}
                {ruleError && <CustomToolTip title={ruleError}>
                    <PriorityHighIcon
                        sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
                </CustomToolTip>}
                {((val) && (!disable && !freez && !readOnly)) &&
                    <span className="ps-1 resetFieldValue">
                        <CustomToolTip title='clear value'>
                            <AutorenewIcon onClick={() => onResetValues(updateDynamicFormData(null), "", isGroup, fldFields, dispatch, rowIndex, index, grpFieldIndex,setVal)}
                                sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
                        </CustomToolTip>
                    </span>
                }

            </FieldContainer>
        </Fragment>
    )
}
export default MultiSelect