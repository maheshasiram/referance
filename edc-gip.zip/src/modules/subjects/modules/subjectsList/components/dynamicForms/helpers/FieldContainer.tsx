import React, { useState } from "react";
import {
    FieldActions, FieldContainerDiv, FieldError, FieldLabel,
    FieldMainContainer, FieldNote, FieldQuery, FieldSubContainer,
    HeaderLabel, HelperText, QuestionNumberContainer, RowContainer
} from "../styles/stylesComponents";
import InstructionsHelper from "./InstructionsHelper";
import QueryMenu from "../components/queryListing/QueryMenu";
import { changeableProperties, updateDynamicFormData } from "./updateDynamicFormData";


function FieldContainer(props: any) {
    const {
        header, note, onAirInstruction, variableText, questionNumber, isGroup, children,  units,
        readOnly, id, index, defaultValue, grpFieldIndex, value, rowIndex, minValueLength, maxValueLength,
        setFreezField
    } = props;
    const dynamicData = updateDynamicFormData(null);
    let field = isGroup ? dynamicData.data[index]?.group?.rows[rowIndex]?.fields[grpFieldIndex] : dynamicData.data[index]?.field;
    let _properties: any = changeableProperties(field);
    const { errorMsg, freez } = _properties;
    
    return (
        <RowContainer className="fieldRowConatiner">
            {/* {isGroup && parseInt(rowIndex) == 0 && <GroupFieldLabel>{variableText}</GroupFieldLabel>} */}
            <FieldContainerDiv className="fieldContainer">
                {!isGroup && <QuestionNumberContainer className="questionNumContainer">{questionNumber}</QuestionNumberContainer>}
                <FieldSubContainer className="fieldSubContainer" >
                    {header && !isGroup &&
                        <HeaderLabel className="fieldHeader">{header}</HeaderLabel>
                    }
                    <FieldActions className="fieldActions">
                        {!isGroup &&
                            <FieldLabel className="fieldLabel">{`${variableText} ${units ? `( ${units} )` : ''}`}</FieldLabel>
                        }
                        <FieldQuery className="QueryContainer" ><QueryMenu {...props} setFreezField={setFreezField} /></FieldQuery>
                        <FieldMainContainer className="fieldMain">
                            <div className="">
                                <div className={isGroup ? 'groupFieldDiv' : ''} >
                                    {children}
                                </div>
                                {errorMsg && <FieldError>{errorMsg}</FieldError>}
                                {/* {isGroup ? dynamicData?.data[index]?.group?.rows[rowIndex]?.fields[grpFieldIndex]?.errorMsg && <FieldError>{dynamicData?.data[index]?.group?.rows[rowIndex]?.fields[grpFieldIndex]?.errorMsg}</FieldError> : dynamicData?.data[index]?.field?.errorMsg && <FieldError>{dynamicData?.data[index]?.field?.errorMsg}</FieldError>} */}
                            </div>
                        </FieldMainContainer>
                        {onAirInstruction &&
                            <HelperText className="FieldHelper" >
                                <InstructionsHelper title={onAirInstruction} />
                            </HelperText>
                        }
                    </FieldActions>
                    {note && note !== '' && !isGroup &&
                        <FieldNote className="fieldNote">
                            <span className="noteLabel">Note :</span>
                            <span className="noteContent">{note}</span>
                        </FieldNote>
                    }
                </FieldSubContainer>
            </FieldContainerDiv>
        </RowContainer>
    )
}
export default FieldContainer