import React from "react";
import { AnyObject } from 'immer/dist/internal';
import TextArea from "../fields/TextArea";
import SingleSelect from "../fields/SingleSelect";
import RadioField from "../fields/RadioField";
import MultiSelect from "../fields/MultiSelect";
import CheckBox from "../fields/CheckBox";
import FileUpload from "../fields/FileUpload";
import Textfield from "../fields/TextField";
import Integer from "../fields/Integer";
import Real from "../fields/Real";
import DateField from "../fields/DateField";
import TimeField from "../fields/TimeField";
import PartialDate from "../fields/PartialDate";
import PartialTime from "../fields/PartialTime";
import store from "../../../../../../../store/store";
const application = store.getState().application
console.log("18...",application?.configCodes)
export const dynamicFields: AnyObject = {
    "RES_TYP_TEXT": "RES_TYP_TEXT",
    [application?.configCodes?.textarea]: (props:any)=><TextArea {...props} />,
    [application?.configCodes?.['single-select']]: (props:any)=><SingleSelect {...props} />,
    [application?.configCodes?.radio]: (props:any)=><RadioField {...props} />,
    [application?.configCodes?.['multi-select']]: (props:any)=><MultiSelect {...props} />,
    [application?.configCodes?.checkbox]: (props:any)=><CheckBox {...props} />,
    "RES_TYP_FILE": (props:any)=><FileUpload {...props} />,
    [application?.configCodes?.string]: (props:any)=><Textfield {...props} />,
    [application?.configCodes?.integer]: (props:any)=><Integer {...props} />,
    [application?.configCodes?.real]: (props:any)=><Real {...props} />,
    [application?.configCodes?.date]: (props:any)=><DateField {...props} />,
    [application?.configCodes?.time]: (props:any)=><TimeField {...props} />,
    [application?.configCodes?.partialdate]: (props:any)=><PartialDate {...props} />,
    [application?.configCodes?.PartialTime]: (props:any)=><PartialTime {...props} />,
};