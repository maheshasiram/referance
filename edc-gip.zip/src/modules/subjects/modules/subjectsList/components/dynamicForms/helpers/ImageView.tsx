import React from "react";
import VisibilityIcon from '@mui/icons-material/Visibility';
import CustomDialog from "../../../../../../../common/modals/CustomeDialog";
import { ReactPanZoom } from "./ZoomImage";

function ImageView(props:any) {
    const {value} =props;
    console.log("8....",value)
    const[openImageView, setOpenImageView] = React.useState(false);
    const onCloseHandler = () => {
        setOpenImageView(false)
    }
    const imagePreview = () =>{
        setOpenImageView(true)
    }
    const submitHandler = () => {
        alert('test')
    }
    return (
        <React.Fragment>
            <VisibilityIcon onClick={imagePreview} />
            <CustomDialog
                title={"Image Preview"}
                onClose={onCloseHandler}
                onSubmitHandler={() => { submitHandler() }}
                open={openImageView}
                form={"reasonToChange"}
                disabled={false}
                onResetHandler={null}
                actionType="Submit"
            >
                <ReactPanZoom
                 alt="image"
                 image= {value?.path}
                />

            </CustomDialog>
        </React.Fragment>
    )
}

export default ImageView;