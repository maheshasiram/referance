import React, { Fragment, useState } from "react";
import FieldContainer from "../helpers/FieldContainer";
// import _ from "lodash";
import { useDispatch, useSelector } from "react-redux";
// import { Types } from "../../../reducers/Types";
import dayjs from 'dayjs';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DesktopTimePicker } from '@mui/x-date-pickers/DesktopTimePicker';
import AutorenewIcon from '@mui/icons-material/Autorenew';
import CustomToolTip from "../../../../../../../components/CustomToolTip";
import FormControl from '@mui/material/FormControl';
import PriorityHighIcon from '@mui/icons-material/PriorityHigh';
import { onResetValues } from "../helpers/resetValues";
import _ from "lodash";
import { Types } from "../../../reducers/Types";
import { getDerivativeValues } from "../helpers/derivations/derivations";
import { getRulesByFieldId } from "../actions/actions";
import { changeableProperties, updateDynamicFormData } from "../helpers/updateDynamicFormData";

function TimeField(props: any) {
    const dispatch = useDispatch()
    const {
        /*header, note, onAirInstruction, variableText,*/ defaultValue, id, /*questionNumber,layout,*/
        readOnly, index, isGroup, grpFieldIndex, value, rowIndex, /*freez,*/ fldError, disable, ruleError
    } = props;
    const [val, setVal] = useState(value ? value : defaultValue);
    const { dynamicFormData, derivations } = useSelector((state: any) => state.subjects);
    const { currentStudy } = useSelector((state: any) => state.application);
    let payload = updateDynamicFormData(null)
    let field = isGroup ? payload.data[index]?.group?.rows[rowIndex]?.fields[grpFieldIndex] : payload.data[index]?.field;
    let _properties: any = changeableProperties(field);
    const { errorMsg, freez } = _properties;

    const [freezField, setFreezField] = useState(freez);

    const onChangeHandler = async (event: any) => {
        // let payload = _.cloneDeep(dynamicFormData)
        payload = updateDynamicFormData(null)
        const _format = currentStudy?.timeFormat === '24 Hrs' ? 'HH:mm' : "hh:mm a"
        const time = dayjs(event).format(_format)
        if (isGroup) {
            payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].value = time
            delete payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].ruleError
        } else {
            payload.data[index].field.value = time
            delete payload.data[index].field.ruleError;
        }
        if (time != 'Invalid Date') {
            payload = await getDerivativeValues(derivations, payload)
        }
        setVal(time);
        updateDynamicFormData(payload);
        // dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload })
        // setTimeout(() => {
        //     dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload })
        // }, 250);
    };

    const getValue = () => {
        const now = dayjs();
        // const _value = value ? value : defaultValue
        return val ? dayjs(`${now.format("YYYY-MM-DD")} ${val}`) : null
    }

    // const onCloseHandle = () => {
    //     const payload = _.cloneDeep(dynamicFormData)
    //     console.log("50...", payload);
    // }

    return (
        <Fragment>
            <FieldContainer {...props} setFreezField={setFreezField} >
                <div className="d-flex align-items-center" >
                    <FormControl className="field">
                        <div className="time-field-container" >
                            <LocalizationProvider dateAdapter={AdapterDayjs}>
                                {/* <MobileTimePicker
                                    // defaultValue={dayjs('2022-04-17T15:30')}
                                    closeOnSelect
                                    ampm={currentStudy?.timeFormat == '24' ? false : true}
                                    onChange={onChangeHandler}
                                    className="df_timefield field"
                                    value={getValue()}
                                    disabled={readOnly}
                                /> */}
                                <DesktopTimePicker
                                    className="df_timefield field"
                                    // defaultValue={getDefalutValue()}
                                    ampm={currentStudy?.timeFormat === '24 Hrs' ? false : true}
                                    onChange={onChangeHandler}
                                    disabled={readOnly || freezField || disable}
                                    value={getValue()}
                                    // onClose={onCloseHandle}
                                    slotProps={{
                                        textField: {
                                            id:`field_${id}` 
                                        }
                                      }}
                                />
                            </LocalizationProvider>
                            {/* <div className="time-icon" >
                                <AccessTimeIcon />
                            </div> */}
                        </div>
                    </FormControl>

                    {fldError && <CustomToolTip title={fldError}>
                        <PriorityHighIcon
                            sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
                    </CustomToolTip>}
                    {ruleError && <CustomToolTip title={ruleError}>
                        <PriorityHighIcon
                            sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
                    </CustomToolTip>}
                   
                    {((val) && (!disable && !freezField && !readOnly)) &&
                        <span className="ps-1 resetFieldValue">
                            { <CustomToolTip title='clear value'>
                                <AutorenewIcon onClick={() => onResetValues(updateDynamicFormData(null), null, isGroup, null, dispatch, rowIndex, index, grpFieldIndex, setVal)}
                                    sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
                            </CustomToolTip>}
                        </span>
                    }
                </div>
            </FieldContainer>
        </Fragment>
    )
}
export default TimeField