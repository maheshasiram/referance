import React, { Fragment, useState } from 'react';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import Radio from '@mui/material/Radio';
import { useDispatch, useSelector } from 'react-redux';
import { Types } from '../../../reducers/Types';
import _ from 'lodash';
import FieldContainer from '../helpers/FieldContainer';
import AutorenewIcon from '@mui/icons-material/Autorenew';
import CustomToolTip from '../../../../../../../components/CustomToolTip';
import FormControl from '@mui/material/FormControl';
import PriorityHighIcon from '@mui/icons-material/PriorityHigh';
import { NonGroupfieldLevelDynamics, groupfieldLevelDynamics } from '../helpers/fieldLevelDyanmics';
import { onResetValues } from '../helpers/resetValues';
import { onReasonToChange } from '../helpers/resonTochange';
import { getDerivativeValues } from '../helpers/derivations/derivations';
import { getRulesByFieldId } from '../actions/actions';
import { changeableProperties, updateDynamicFormData } from '../helpers/updateDynamicFormData';

function RadioField(props: any) {
	const dispatch = useDispatch()
	const {
		// header, note, onAirInstruction, variableText, defaultValue, questionNumber,id,
		responseOptions, readOnly, index, isGroup, grpFieldIndex, value, rowIndex, layout,/* freez,*/ fldFields, fldError, defaultValue, disable, ruleError
	} = props;
	const { dynamicFormData, derivations } = useSelector((state: any) => state.subjects);
	const { page, entryFormData, configCodes } = useSelector((state: any) => state.application);
	const [val, setVal] = useState(value ? value : defaultValue);

	let payload = updateDynamicFormData(null);
	let field = isGroup ? payload.data[index]?.group?.rows[rowIndex]?.fields[grpFieldIndex] : payload.data[index]?.field;
    let _properties: any = changeableProperties(field);
    const { errorMsg, freez } = _properties;

    const [freezField, setFreezField] = useState(freez);

	const onChangeHandler = async (event: any) => {
	    payload = updateDynamicFormData(null);
		payload = onReasonToChange(isGroup, payload, index, rowIndex, grpFieldIndex, event.target.value, page, entryFormData)
		if (isGroup) {
			if (fldFields && fldFields?.fieldId === payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].fieldId) {
				const _fldValidate = groupfieldLevelDynamics(payload, fldFields, event.target.value, dispatch, rowIndex, 'radio');
				if (_fldValidate) {
					payload = _fldValidate
					payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].value = event.target.value;
				}
				// updateDynamicFormData(payload);
				setVal(payload.data[index]?.group?.rows[rowIndex]?.fields[grpFieldIndex]?.value);
				dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload });

			} else {
				payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].value = event.target.value;
				delete payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].fldError
				delete payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].ruleError
				// updateDynamicFormData(payload);
				setVal(event.target.value);
			}
		} else {
			if (fldFields && fldFields?.fieldId === payload.data[index].field?.fieldId) {
				const _fldValidate = NonGroupfieldLevelDynamics(payload, fldFields, event.target.value, dispatch, 'radio');
				if (_fldValidate) {
				payload = _fldValidate
					payload.data[index].field.value = event.target.value;
				}
				setVal(payload?.data[index]?.field?.value);
				// updateDynamicFormData(payload);
				dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload });

			} else {
				payload.data[index].field.value = event.target.value;
				delete payload.data[index].field.fldError
				delete payload.data[index].field.ruleError
				// updateDynamicFormData(payload);
				setVal(event.target.value);
			}
		}
		
		payload = await getDerivativeValues(derivations, payload);
		updateDynamicFormData(payload);
		// console.log("...78", payload)
		// dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload });
	};

	// const onBlurHandler = async (event: any) => {
		// alert("blur....")
		// let payload = _.cloneDeep(dynamicFormData)
		// payload = await getDerivativeValues(derivations, payload, props)
		// dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload })
	// }

	// const onfocusHandler = () => {
		// alert("..focus");
		// console.log("...focus");
	// }
	
	return (
		<Fragment>
			<FieldContainer {...props} setFreezField={setFreezField}>
				<div className="d-flex align-items-center" >
					<FormControl>
						<RadioGroup
							value={val}
							name="radio-buttons-group"
							className='df_radioGroup'
							onChange={onChangeHandler}
							// onBlur={onBlurHandler}
							// onFocus={onfocusHandler}
						>
							<div className={layout?.code === configCodes?.horizontal ? 'd-flex' : ''} >
								{responseOptions?.map((option: any) => (
									<FormControlLabel
										key={`radio_${option.id}`}
										name='radioName'
										id={`field_${option.id}`}
										value={option.response}
										control={<Radio />}
										label={option.response}
										// checked={option.selected ? option.selected : false}
										checked={option.response === val ? option.selected : false}
										disabled={readOnly || freezField || disable}
										// disabled={true}
									/>
								))
								}
							</div>
						</RadioGroup>
					</FormControl>

					{fldError && <CustomToolTip title={fldError}>
						<PriorityHighIcon
							sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
					</CustomToolTip>}
					{ruleError && <CustomToolTip title={ruleError}>
						<PriorityHighIcon
							sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
					</CustomToolTip>}
					{((val ) && (!disable && !freezField && !readOnly)) &&
						<span className="ps-1 resetFieldValue">
							<CustomToolTip title='clear value'>
								<AutorenewIcon onClick={() => onResetValues(updateDynamicFormData(null), "", isGroup, fldFields, dispatch, rowIndex, index, grpFieldIndex,setVal)}
									sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
							</CustomToolTip>
						</span>
					}
				</div>
			</FieldContainer>
		</Fragment>
	);
}
export default RadioField;
