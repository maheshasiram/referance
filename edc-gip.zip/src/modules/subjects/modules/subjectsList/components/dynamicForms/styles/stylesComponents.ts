// import { padding } from '@mui/system';
import styled from 'styled-components';

export const RowContainer = styled.div({
    // borderBottom: '1px solid rgb(238, 238, 238)'
    // borderRight:'1px solid lightgray'
})
export const HeaderLabel = styled.div({
    backgroundColor: 'rgb(229, 239, 255)',
    fontSize: '12px',
    fontWeight: '700',
    padding: '5px 5px',
    borderBottom: '1px solid #BFD3EB'
})
export const FieldContainerDiv = styled.div({
    // background:'skyblue',
    display: 'flex',
})
export const QuestionNumberContainer = styled.div({
    // background:'green'
    width: '30px',
    borderRight: '1px solid #BFD3EB',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
})
export const FieldSubContainer = styled.div({
    // background:'lime',
    width: '100%',
})
export const FieldLabel = styled.div({
    display: 'inline-flex',
    width: '25%',
    padding: '0px 10px',
    alignItems: 'center'

})
export const FieldActions = styled.div({
    // background:'lightgray',
    display: 'flex',
    alignItems: 'center',
    // padding: '3px 0px',
})
export const FieldQuery = styled.div({
    // background:'orange'
})
export const FieldMainContainer = styled.div({
    display: 'inline-flex',
    width: 'auto',
    padding: '5px 0px',
    marginRight: '0px',
    alignItems: 'center',
    minWidth: '150px',
    justifyContent: 'flex-start'
})
export const HelperText = styled.div({
    // background:'blue'
    padding: '0px 8px'
})
export const FieldNote = styled.div({
    backgroundColor: '#d99d1059',
    padding: '2px 5px',
})
export const GroupFieldLabel = styled.div({
    background: "#ecececfa",
    display: "flex",
    justifyContent: "center",
    fontWeight: "550",
    padding: "2px",
    border: "1px solid lightgrey"
})

export const FieldError = styled.p({
    margin: '0px',
    color: 'tomato',
    fontSize: '11px',
    textAlign: 'left'
})

export const NonGroupFieldContainer = styled.div({
    borderBottom: "1px solid #0f35523b"
})