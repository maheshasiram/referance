import React, { Fragment, useState } from "react";
import moment from "moment";
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import FieldContainer from "../helpers/FieldContainer";
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { useDispatch, useSelector } from "react-redux";
import dayjs from "dayjs";
import { Types } from "../../../reducers/Types";
import _ from 'lodash';
import AutorenewIcon from '@mui/icons-material/Autorenew';
import CustomToolTip from "../../../../../../../components/CustomToolTip";
import FormControl from '@mui/material/FormControl';
import PriorityHighIcon from '@mui/icons-material/PriorityHigh';
import { onResetValues } from "../helpers/resetValues";
import { onReasonToChange } from "../helpers/resonTochange";
import { getDerivativeValues } from "../helpers/derivations/derivations";
import { getRulesByFieldId } from "../actions/actions";
import { changeableProperties, updateDynamicFormData } from "../helpers/updateDynamicFormData";


function DateField(props: any) {
    // const [value, setValue] = React.useState<any>(null);
    const dispatch = useDispatch()
    const {
        // header, note, onAirInstruction, variableText, defaultValue, questionNumber, layout,
        readOnly, id, index, isGroup, grpFieldIndex, value, rowIndex, fldError, defaultValue, disable, ruleError,
    } = props;
    const { currentStudy, page } = useSelector((state: any) => state.application);
    const { dynamicFormData, derivations, entryFormData } = useSelector((state: any) => state.subjects);
    const [val, setVal] = useState(value ? value : defaultValue);
    // const handleChange = (newValue: Date | null) => {
    //     // setValue(newValue);
    // };
    // console.log("currentStudy....", currentStudy)
    let payload = updateDynamicFormData(null);
    let field = isGroup ? payload.data[index]?.group?.rows[rowIndex]?.fields[grpFieldIndex] : payload.data[index]?.field;

    let _properties: any = changeableProperties(field);
    const { errorMsg, freez } = _properties;

    const [freezField, setFreezField] = useState(freez);

    const onChangeHandler = async (event: any) => {
        // let payload = _.cloneDeep(dynamicFormData)
        payload = updateDynamicFormData(null);
        const _momentDate = dayjs(event.$d).format(currentStudy.dateFormat);
        payload = onReasonToChange(isGroup, payload, index, rowIndex, grpFieldIndex, _momentDate, page, entryFormData)
        // console.log("30...", _momentDate, event)
        if (isGroup) {
            payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].value = _momentDate
            delete payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].ruleError
        } else {
            payload.data[index].field.value = _momentDate
            delete payload.data[index].field.fldError
            delete payload.data[index].field.ruleError;
        }

        if (_momentDate != 'Invalid Date') {
            payload = await getDerivativeValues(derivations, payload)
        }
        updateDynamicFormData(payload);
        setVal(_momentDate);
        // dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload })
        // setTimeout(() => {
        //     dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload })
        // }, 250);
    };

    return (
        <Fragment>
            <FieldContainer {...props} setFreezField={setFreezField} >
                <div className="d-flex align-items-center" >
                    <FormControl className="field date-field">
                        <div className="d-flex align-items-center" >
                            <LocalizationProvider dateAdapter={AdapterDayjs}>
                                <DatePicker
                                    key={`datefield_${id}`}
                                    className='df_datefield field'
                                    disabled={readOnly || freezField || disable}
                                    format={currentStudy.dateFormat}
                                    value={val ? dayjs(val, currentStudy.dateFormat) : null}
                                    onChange={(e: any) => onChangeHandler(e)}
                                    slotProps={{
                                        textField: {
                                            id: `field_${id}`
                                        }
                                    }}
                                />
                            </LocalizationProvider>
                        </div>
                    </FormControl>
                    {((val) && (!disable && !freezField && !readOnly)) &&
                        <span className="ps-1 resetFieldValue">
                            <CustomToolTip title='clear value'>
                                <AutorenewIcon onClick={() => onResetValues(payload, null, isGroup, null, dispatch, rowIndex, index, grpFieldIndex, setVal)}
                                    sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
                            </CustomToolTip>
                        </span>
                    }

                    {fldError && <CustomToolTip title={fldError}>
                        <PriorityHighIcon
                            sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
                    </CustomToolTip>}
                    {ruleError && <CustomToolTip title={ruleError}>
                        <PriorityHighIcon
                            sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
                    </CustomToolTip>}
                </div>
            </FieldContainer>
        </Fragment>
    )
}
export default DateField
