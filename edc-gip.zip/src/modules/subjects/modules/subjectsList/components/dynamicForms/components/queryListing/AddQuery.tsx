import React from "react";
import { Field, Form, Formik } from "formik";
import * as Yup from 'yup';
import { useDispatch, useSelector } from 'react-redux';
import { CreateQueryies } from "../../actions/actions";
import { Types } from "../../../../reducers/Types";

function AddQuery(props: any) {
    const { formName, setBtnDisable, setOPenDialog } = props;
    const { addQueryPayload } = useSelector((state: any) => state.subjects);
    const dispatch = useDispatch();

    const onAddQueryValidation = Yup.object().shape({
        comments: Yup.string()
            .min(2, 'Too Short!')
            .max(100, 'Too Long!')
            .required('Enter the text')
    });

    const onQueryTextHandle = (e: any, setFieldValue: any) => {
        setFieldValue('comments', e.target.value);
        setBtnDisable(false);
    }

    const onRespondChangeHandle = (e: any, setFieldValue: any) => {
        setFieldValue('respond', e.target.checked);
        const _payload = { ...{}, ...addQueryPayload };
        _payload.respond = e.target.checked
        dispatch({ type: Types.CREATE_QUERY, payload: _payload });
    }

    // const onQueryTypeChangeHandle = (e: any, setFieldValue: any) => {
    //     let _payload = { ...{}, ...addQueryPayload };
    //     let _data = getQueryType?.RESOLUTION_TYPE.find((item: any) => {
    //         return item;
    //     });
    //     console.log("..36", _payload, e.target.value, _data);
    //     _payload.resolutionType = _data;
    //     dispatch({ type: Types.CREATE_QUERY, payload: _payload })
    // }

    const onSubmitAddQuery = (values: any) => {
        const _payload = { ...{}, ...values };
        delete _payload.request
        delete _payload.resolutionType
        delete _payload.ruleId
        delete _payload.status
        delete _payload.type
        delete _payload.assignTo
        dispatch((CreateQueryies)(_payload, (response: any) => {
            console.log("...24 response", response);
        }));
        setOPenDialog(false);
        console.log("...43add query", _payload);
    }

    return (
        <div>
            <Formik
                enableReinitialize={true}
                initialValues={addQueryPayload}
                validationSchema={onAddQueryValidation}
                onSubmit={(values: any) => {
                    onSubmitAddQuery(values)
                }}
            >
                {({ errors, touched, values, setFieldValue }) => (
                    <Form id={formName} >
                        {/* {erroeMsg ? <span className="d-flex justify-content-center text-danger">{erroeMsg}</span> : <span>&nbsp;</span>} */}
                        {/* <div className="pb-2">
                            <label htmlFor="txt-queryType">Query Type: </label>
                            <Field as='select'
                                name='queryType'
                                id="txt-queryType"
                                className="form-select mt-1"
                                value={values.queryType}
                                onChange={(e: any) => onQueryTypeChangeHandle(e, setFieldValue)}
                            >
                                <option value="">--Select Query--</option>
                                {
                                    getQueryType?.RESOLUTION_TYPE.map((opt: any, i: any) => (
                                        <option key={i} value={opt.id}>{opt.name}</option>
                                    ))
                                }
                            </Field>
                        </div> */}

                        <div className="pb-2">
                            <label htmlFor="text-queryText">Query Text: </label>
                            <Field
                                as='textarea'
                                id="text-queryText"
                                name='comments'
                                value={values.comments}
                                className="form-control"
                                onChange={(e: any) => onQueryTextHandle(e, setFieldValue)}
                            />
                            {(errors && errors.comments && touched && touched.comments) &&
                                <span className="text-danger">{errors.comments as string}</span>}
                        </div>

                        <div className="d-flex">
                            <label className="addQueryRespond" htmlFor="txt-respond">Respond: </label>
                            <Field
                                className="p-2"
                                type='checkbox'
                                name='respond'
                                id="txt-respond"
                                onChange={(e: any) => onRespondChangeHandle(e, setFieldValue)}
                            >
                            </Field>
                        </div>

                        <div className="pb-2">
                            <label htmlFor="txt-assignTo">Assign To:</label>
                            <Field as='select'
                                name='assignTo'
                                id="txt-assignTo"
                                className="form-select "
                                value={values.assignTo}
                            // onChange={(e: any) => onAssignToUserHandle(e, setFieldValue)}
                            >
                                <option value="">--Select User--</option>
                                {/* {
                                    categoriesList && categoriesList.data && categoriesList.data.map((opt: any, i: any) => (
                                        <option key={i} value={opt.id}>{opt.name}</option>
                                    ))
                                } */}
                            </Field>
                        </div>
                    </Form>
                )}
            </Formik>
        </div>
    )
}
export default AddQuery