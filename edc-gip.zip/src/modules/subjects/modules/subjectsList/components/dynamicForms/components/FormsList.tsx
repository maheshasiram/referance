import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import KeyboardDoubleArrowLeftIcon from '@mui/icons-material/KeyboardDoubleArrowLeft';
import FeedOutlinedIcon from '@mui/icons-material/FeedOutlined';
import { fetchByMappingForm, fetchForms, findSubjectFormsByUnscheduledVisitId } from "../../forms/actions/action";
import { dataEntryNavigation } from "../../../../../../../actions/actions";
import { getDerivations, getDynamicFormData, getFieldLevelDynamics } from "../actions/actions";
import { Types } from "../../../reducers/Types";
import { getDerivativeValues } from "../helpers/derivations/derivations";

function FormsList(props: any) {
    const dispatch = useDispatch()
    const { setExpandForms, expandForms } = props;
    const { page } = useSelector((state: any) => state.application);
    const [expandRepeatForm, setExpandRepeatForm] = useState<any>(null)
    // const [activeForm, setActiveForm] = useState()
    const onExpandForm = (index: number) => {
        setExpandRepeatForm(expandRepeatForm === index ? null : index)
    }
    const onCollapseFormsList = () => {
        setExpandForms(!expandForms)
    }
    const onChangeFormHandler = (form: any, index: any) => {
        const payload = { ...{}, ...page };
        if (!form.id) {
            dispatch(fetchByMappingForm({ subjectVisitId: page.currentVisitId, formId: form.formId }, (response: any) => {
                payload.selectedForm = response;
                form = response
                dispatch((page.selectedVisit.visit.visitRepeat ? findSubjectFormsByUnscheduledVisitId : fetchForms)(page.selectedVisit.id, (response: any) => {
                    payload.tabs[parseInt(page.currentTab) - 1].data.forms = response;
                    const _payload = {
                        siteId: page.selectedSubject?.siteId,
                        formId: response[index].formId,
                        visitId: page.selectedVisit?.visit?.id
                    }
                    dispatch(getDynamicFormData(form.id, (_response: any) => {
                        if (_response) {
                            // payload.tabs[parseInt(page.currentTab)].data.dynamicFormData = _response;
                            // payload.tabs[parseInt(page.currentTab)].label = _response.formName;
                            // dispatch(dataEntryNavigation(payload))
                            // dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: _response });
                            dispatch(getFieldLevelDynamics(_payload))
                            // dispatch(getDerivations(_payload));
                            dispatch(getDerivations(_payload, async (derivativeResponse: any) => {
                                console.log('derivativeResponse......', derivativeResponse);
                                if (derivativeResponse?.error) {
                                    dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: _response });
                                    payload.tabs[parseInt(page.currentTab)].data.dynamicFormData = _response;
                                    payload.tabs[parseInt(page.currentTab)].label = _response.formName;

                                    dispatch(dataEntryNavigation(payload))
                                } else {
                                    console.log('response....derivativeResponse...', derivativeResponse, response)
                                    setTimeout(async() => {
                                        response = await getDerivativeValues(derivativeResponse, _response)
                                        payload.tabs[parseInt(page.currentTab)].data.dynamicFormData = _response;
                                        dispatch(dataEntryNavigation(payload))
                                        dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: response });
                                    }, 250);
                                }
                            }));
                        }
                    }))
                    // dispatch(dataEntryNavigation(payload))
                }));
            }))
        } else {
            payload.selectedForm = form;

            const _payload = {
                siteId: page.selectedSubject?.siteId,
                formId: form.formId,
                visitId: page.selectedVisit?.visit?.id
            }

            dispatch(getDynamicFormData(form.id, (response: any) => {
                if (response) {
                    // payload.tabs[parseInt(page.currentTab)].data.dynamicFormData = response;
                    // payload.tabs[parseInt(page.currentTab)].label = response.formName;
                    dispatch(dataEntryNavigation(payload))
                    // dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: response });
                    dispatch(getFieldLevelDynamics(_payload, (response: any) => {
                        console.log(response, "61....")
                        // dispatch(getDerivations(_payload));
                    }));
                    dispatch(getDerivations(_payload, async (derivativeResponse: any) => {
                        if (derivativeResponse?.error) {
                            dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: response });
                            payload.tabs[parseInt(page.currentTab)].data.dynamicFormData = response;                    // payload.tabs[parseInt(page.currentTab)].label = response.formName;
                            payload.tabs[parseInt(page.currentTab)].label = response.formName;
                            dispatch(dataEntryNavigation(payload))
                        } else {
                            setTimeout(async() => {
                                response = await getDerivativeValues(derivativeResponse, response)
                                payload.tabs[parseInt(page.currentTab)].data.dynamicFormData = response;
                                payload.tabs[parseInt(page.currentTab)].label = response.formName;
                                dispatch(dataEntryNavigation(payload))
                                dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: response });
                            }, 250);
                        }
                    }));
                }
            }))
            dispatch(dataEntryNavigation(payload))
        }
    }
    return (
        <ul className="p-0" >
            <li className="forms-header" >
                <h6>Forms</h6>
                <div className="d-flex expandIcon" onClick={onCollapseFormsList}>
                    <KeyboardDoubleArrowLeftIcon />
                </div>
            </li>
            {page?.tabs[2]?.data?.forms?.map((ele: any, index: any) => (
                <li key={`form_${ele.formId}`}
                    onClick={ele.repeat ? () => onExpandForm(index) : () => onChangeFormHandler(ele, index)}
                    className={`formsList-container ${ele?.formId === page?.selectedForm?.formId ? 'activeForm' : ''} ${expandRepeatForm === index ? 'expandedForm' : ''}`}
                >
                    <div className={`d-flex w-100 px-1 `} >
                        <div className='formIcon' >
                            {!ele.repeat ? <FeedOutlinedIcon className="file-icon" /> :
                                <ArrowForwardIosIcon onClick={() => onExpandForm(index)} className={expandRepeatForm !== index ? "expandIcon" : "expandIcon expanded"} />}
                        </div>
                        <div className="form-container" >
                            <span className="formName" >{ele.formName}</span> <span className="ps-1 form-status" >{` (${ele.actionStatus.name})`}</span>
                            {/* {ele.repeat && <button onClick={() => { }} className="repeat-Btn" >Repeat</button>} */}
                            {
                                expandRepeatForm === index && (ele.repeat && ele.childForms) &&
                                <ul className="childForm-container" onClick={(e: any) => { e.stopPropagation() }} >
                                    {
                                        ele.childForms.map((childForm: any, childIndex: number) => (
                                            <li
                                                className={`${childForm.id === page.selectedForm.id ? 'activeSubForm' : ''} ${expandRepeatForm === index ? 'expandedForm' : ''}`}
                                                onClick={() => onChangeFormHandler(childForm, childIndex)}
                                                key={childIndex}
                                            >{childForm.formName}</li>
                                        ))
                                    }
                                </ul>
                            }
                        </div>
                    </div>
                </li>
            ))}
        </ul>
    )
}
export default FormsList