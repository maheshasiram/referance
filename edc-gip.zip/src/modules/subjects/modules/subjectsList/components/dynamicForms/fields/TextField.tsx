import React, { Fragment, useEffect, useState } from 'react';
import TextField from '@mui/material/TextField';
import _ from 'lodash';
import { useDispatch, useSelector } from 'react-redux';
import { Types } from '../../../reducers/Types';
import FieldContainer from '../helpers/FieldContainer';
import FormControl from '@mui/material/FormControl';
import PriorityHighIcon from '@mui/icons-material/PriorityHigh';
import CustomToolTip from '../../../../../../../components/CustomToolTip';
import AutorenewIcon from '@mui/icons-material/Autorenew';
import { onResetValues } from '../helpers/resetValues';
import { onReasonToChange } from '../helpers/resonTochange';
import { getRulesByFieldId } from '../actions/actions';
import { getDerivativeValues } from '../helpers/derivations/derivations';
import { changeableProperties, updateDynamicFormData } from '../helpers/updateDynamicFormData';

function Textfield(props: any) {
	const dispatch = useDispatch();

	const { isGroup, index, grpFieldIndex, rowIndex, readOnly, id, spellCheck, disable, value, fldError,
		minValueLength, maxValueLength, defaultValue, variableFieldFormat, ruleError, isValueUpperCase, placeholder } = props;

	const { page } = useSelector((state: any) => state.application);
	const { dynamicFormData, entryFormData, rules, derivations } = useSelector((state: any) => state.subjects);

	let payload = updateDynamicFormData(null);
	let field = isGroup ? payload.data[index]?.group?.rows[rowIndex]?.fields[grpFieldIndex] : payload.data[index]?.field;

	let _properties: any = changeableProperties(field);
	const { errorMsg, freez } = _properties;

	const [freezField, setFreezField] = useState(freez);

	const regex = new RegExp(variableFieldFormat?.value);

	let _value = value ? value : defaultValue;
	const [val, setVal] = useState(isValueUpperCase ? _value.toUpperCase() : _value);

	const onChangeHandler = (event: any) => {
		payload = updateDynamicFormData(null);
		setVal(isValueUpperCase ? event.target.value.toUpperCase() : event.target.value);
		payload = onReasonToChange(isGroup, payload, index, rowIndex, grpFieldIndex, event.target.value, page, entryFormData)
		if (isGroup) {
			payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].value = isValueUpperCase ? event.target.value.toUpperCase() : event.target.value
			delete payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].fldError
			delete payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].ruleError
			payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].errorMsg = event.target.value ? regex.test(event.target.value) ? event.target.value.length < minValueLength ? `Please add minimum ${minValueLength} characters` : "" : variableFieldFormat?.errorMessage : "";
		} else {
			payload.data[index].field.value = isValueUpperCase ? event.target.value.toUpperCase() : event.target.value;
			delete payload.data[index].field.fldError
			delete payload.data[index].field.ruleError;
			payload.data[index].field.errorMsg = event.target.value ? regex.test(event.target.value) ? event.target.value.length < minValueLength ? `Please add minimum ${minValueLength} characters` : "" : variableFieldFormat?.errorMessage : "";
		}
		console.log('text field.....', payload.data[index].group?.rows[rowIndex].fields[grpFieldIndex].value);
		

		updateDynamicFormData(payload);
		setVal(event.target.value);
		// dispatch({ type: Types.GET_DYNAMIC_FORMDATA,s payload: payload });
	};

	const onBlurHandler = async (event: any) => {
		payload = updateDynamicFormData(null);
		if (isGroup) {
			payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].errorMsg = event.target.value ? regex.test(event.target.value) ? event.target.value.length < minValueLength ? `Please add minimum ${minValueLength} characters` : "" : variableFieldFormat?.errorMessage : "";
		} else {
			payload.data[index].field.errorMsg = event.target.value ? regex.test(event.target.value) ? event.target.value.length < minValueLength ? `Please add minimum ${minValueLength} characters` : "" : variableFieldFormat?.errorMessage : "";
		}
		payload = await getDerivativeValues(derivations, payload);
		console.log("...67", payload)
		updateDynamicFormData(payload);
		// dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload });
	};

	return (
		<Fragment>
			<FieldContainer {...props} setFreezField={setFreezField}>
				<FormControl className="field">
					<TextField
						key={`txt_${id}`}
						id={`field_${id}`}
						name={`input_${id}`}
						placeholder={placeholder ? placeholder : ''}
						className='df_txtField field'
						variant="outlined"
						type={'text'}
						disabled={readOnly || freezField || disable}
						error={errorMsg ? true : false}
						value={val}
						onChange={onChangeHandler}
						onBlur={onBlurHandler}
						spellCheck={spellCheck} //Added spellcheck
						inputProps={{ minLength: minValueLength, maxLength: maxValueLength }}
					/>
				</FormControl>
				{fldError && <CustomToolTip title={fldError}>
					<PriorityHighIcon
						sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
				</CustomToolTip>}
				{ruleError && <CustomToolTip title={ruleError}>
					<PriorityHighIcon
						sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
				</CustomToolTip>}
				{((val) && (!disable && !freezField && !readOnly)) &&
					<span className="ps-1 resetFieldValue" id={'reset_' + id}>
						<CustomToolTip title='clear value'>
							<AutorenewIcon onClick={() => onResetValues(payload, "", isGroup, null, dispatch, rowIndex, index, grpFieldIndex, setVal)}
								sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
						</CustomToolTip>
					</span>}
			</FieldContainer>
		</Fragment>
	);
}
export default Textfield;
