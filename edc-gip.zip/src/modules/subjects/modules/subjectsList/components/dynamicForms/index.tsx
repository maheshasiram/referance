import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getDerivations, getDynamicFormData, getFieldLevelDynamics } from "./actions/actions";
import DynamicForm from "./components/DynamicForm";
import FormsList from "./components/FormsList";
import './styles/styles.scss'
import _ from "lodash";
import { configDataType, dataEntryNavigation } from "../../../../../../actions/actions";
import { Types } from '../../reducers/Types';
import { getDerivativeValues } from "./helpers/derivations/derivations";
import { updateDynamicFormData } from "./helpers/updateDynamicFormData";

function DynamicForms() {
    const dispatch = useDispatch()
    const { page } = useSelector((state: any) => state.application);
    const { dynamicFormData, entryFormData, derivations } = useSelector((state: any) => state.subjects);
    const loaded = React.useRef(false);
    const loadDerivatives = React.useRef(false);
    const [expandForms, setExpandForms] = useState(true);

    useEffect(() => {
        if (!loaded.current) {
            const payload: any = _.cloneDeep(page);
            const params = {
                siteId: page.selectedSubject?.siteId,
                formId: page.selectedForm?.formId,
                visitId: page.selectedVisit?.visit?.id
            }
            dispatch(getDynamicFormData(page.selectedForm?.id, (response: any) => {
                if (response) {
                    dispatch(getFieldLevelDynamics(params, (_response: any) => {
                    }));
                    dispatch(getDerivations(params, async (derivativeResponse: any) => {
                        if (derivativeResponse?.error) {
                            dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: response });
                            payload.tabs[parseInt(page.currentTab)].data.dynamicFormData = response;
                            dispatch(dataEntryNavigation(payload))
                        } else {
                            dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: response });
                            payload.tabs[parseInt(page.currentTab)].data.dynamicFormData = response;
                            dispatch(dataEntryNavigation(payload))
                        }
                    }));
                }
            }))
            dispatch(configDataType('FORM_STATUS', (response: any) => {
                dispatch({ type: Types.DYNAMIC_FORM_SAVE_TYPE, payload: response });
            }));
            loaded.current = true
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
    useEffect(() => {
        if ((dynamicFormData && dynamicFormData.data) && (derivations && derivations.length > 0)) {
            if (!loadDerivatives.current) {
                setTimeout(() => {
                    onLoadDerivations(derivations,dynamicFormData )
                }, 250);
                loadDerivatives.current = true;
            }
        }
    }, [dynamicFormData, derivations])
    const onLoadDerivations = async (_derivations:any, _dynamicFormData:any) => {
        let payload: any = _.cloneDeep(_dynamicFormData);
        payload = await getDerivativeValues(_derivations, payload);
        dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload });
    }
    return (
        <div className="dynamicForms-container">
            <div className="d-flex col-sm-12 dForm-subcontainer">
                <div className={`${expandForms ? 'FormList-expanded forms-sideNav' : 'formsList forms-sideNav'}`} >
                    <FormsList setExpandForms={setExpandForms} expandForms={expandForms} />
                </div>
                <div className={`${expandForms ? 'dynamicForm-sm' : 'dynamicForm-mx'}`} >
                    <DynamicForm
                        dynamicFormData={page.tabs[parseInt(page.currentTab)].data.dynamicFormData}
                        setExpandForms={setExpandForms}
                        expandForms={expandForms}
                    />
                </div>
            </div>
        </div>
    )
}
export default DynamicForms;