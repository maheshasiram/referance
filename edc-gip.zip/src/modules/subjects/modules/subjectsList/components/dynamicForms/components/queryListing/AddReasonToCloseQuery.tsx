import React from "react";
import CustomDialog from "../../../../../../../../common/modals/CustomeDialog";
import { useDispatch, useSelector } from "react-redux";
import { Formik, Field, Form, ErrorMessage, FieldArray } from 'formik';
import AddCircleOutlineOutlined from "@mui/icons-material/AddCircleOutlineOutlined";
import RemoveCircleOutlineIcon from '@mui/icons-material/RemoveCircleOutline';

function AddReasonToCloseQuery(props: any) {

    const [btnDisable, setBtnDisable] = React.useState(true);
    const { addReasonToClose } = useSelector((state: any) => state.application);
    const { openAddReasonDialog, setOpenAddReasonDialog } = props

    const handleClose = () => {
        setOpenAddReasonDialog(false);
    }

    return (
        <React.Fragment>
            <CustomDialog
                maxWidth={'xs'}
                open={openAddReasonDialog}
                onClose={handleClose}
                title={"Add Reason To Close"}
                form={'AddReasonToClose'}
                actionType='submit'
                disabled={btnDisable}
            >
                <Formik
                    enableReinitialize={true}
                    initialValues={addReasonToClose}
                    onSubmit={(values: any) => {
                        // onVlidateAddReason(values, '', '');
                    }}
                >
                    {({ values, setFieldTouched, setFieldValue, errors }) => (
                        <Form id='AddReasonToClose'>
                            <div>
                                <FieldArray
                                    name="addReason"
                                    render={(arrayHelpers) => {
                                        const allReasons = values.addReason
                                        console.log('...arrayHelpers', arrayHelpers)
                                        return (
                                            <div className="mx-1">
                                                <div className="d-flex">
                                                    <label id='label'>Add Reason To Close</label>
                                                    <AddCircleOutlineOutlined
                                                        className='text-primary mx-2 mb-1'
                                                        fontSize='small'
                                                        onClick={() => {
                                                            // onVlidateAddReason(values, arrayHelpers, 'addField')
                                                        }}
                                                    />
                                                    <div>
                                                        {/* {addRemoveMsg && <span className="" style={{ color: 'red', marginLeft: 10 }}>{addRemoveMsg}</span>} */}
                                                    </div>
                                                </div>

                                                {allReasons &&
                                                    allReasons.map((data: any, index: number) => (
                                                        <div key={index} className="d-flex mb-2">
                                                            <div className="col-12">
                                                                <Field
                                                                    name={`addReason.${index}`}
                                                                    value={values.addReason[index]}
                                                                    className="form-control"
                                                                    placeholder={"Add Reason"}
                                                                // onChange={(e: any) => onAddReasonChange(e, setFieldValue, setFieldTouched, index)}
                                                                >
                                                                </Field>
                                                                {/* {!addRemoveMsg &&
                                                                    <div className="text-danger"><ErrorMessage name='addReason' /></div>
                                                                } */}
                                                            </div>
                                                            <div>
                                                                {allReasons.length > 1 && <RemoveCircleOutlineIcon
                                                                    sx={{ cursor: 'pointer' }}
                                                                    color='error'
                                                                    className="mt-1"
                                                                // onClick={(e: any) => onRemoveField(e, arrayHelpers, index)}
                                                                />}
                                                            </div>
                                                        </div>
                                                    ))
                                                }
                                            </div>
                                        )
                                    }}
                                ></FieldArray>
                            </div>
                        </Form>
                    )}
                </Formik>
            </CustomDialog>
        </React.Fragment>
    )
}

export default AddReasonToCloseQuery