import React from "react";
import { Field, Form, Formik, ErrorMessage } from "formik";
import { addDeviationModel } from "../../../../constants/modal";
import * as Yup from 'yup';
import { useDispatch, useSelector } from 'react-redux';
import { Types } from "../../../../reducers/Types";
import { addProtocolDeviation } from "../../actions/actions";

function AddProtocalDeviation(props: any) {
    const { formName, setOPenDialog, setBtnDisable, subjectFieldId } = props;
    const dispatch = useDispatch();
    const { deviationTypes, deviationCategories, deviationPayload } = useSelector((state: any) => state.subjects);
    const { currentUser } = useSelector((state: any) => state.application);

    const deviationValidation = Yup.object().shape({
        deviationTypeCode: Yup.string()
            .required('Select the deviation type'),
        categoryCode: Yup.string()
            .required('Select the category'),
        description: Yup.string()
            .required('Enter deviation description')
    })

    const onDeviationTypeChangeHandle = (e: any, setFieldValue: any) => {
        const _paylaod = { ...{}, ...deviationPayload };
        _paylaod.deviationTypeCode = e.target.value
        dispatch({ type: Types.CREATE_PROTOCOL_DEVIATION, payload: _paylaod })
        setFieldValue('deviationTypeCode', e.target.value);
        setBtnDisable(false);
    }

    const onCategoryChangeHandle = (e: any, setFieldValue: any) => {
        setBtnDisable(false);
        const _paylaod = { ...{}, ...deviationPayload };
        _paylaod.categoryCode = e.target.value
        dispatch({ type: Types.CREATE_PROTOCOL_DEVIATION, payload: _paylaod })
        setFieldValue('categoryCode', e.target.value);
    }
    const onDescriptionHandle = (e: any, setFieldValue: any) => {
        const _paylaod = { ...{}, ...deviationPayload };
        _paylaod.description = e.target.value
        dispatch({ type: Types.CREATE_PROTOCOL_DEVIATION, payload: _paylaod })
        setBtnDisable(false);
        setFieldValue('description', e.target.value);
    }

    const onSubmitDeviation = (values: any) => {
        const _paylaod = { ...{}, ...values };
        _paylaod.userId = currentUser.id
        _paylaod.subjectFieldDataId = subjectFieldId
        dispatch(addProtocolDeviation(_paylaod, (response: any) => {
            console.log("...48", response);
        }));
        setOPenDialog(false);
    }

    console.log("...28", deviationTypes, deviationCategories);

    return (
        <React.Fragment>
            <div>
                <Formik
                    enableReinitialize={true}
                    initialValues={addDeviationModel}
                    validationSchema={deviationValidation}
                    onSubmit={(values: any) => {
                        onSubmitDeviation(values)
                    }}
                >
                    {({ errors, touched, values, setFieldValue }) => (
                        <Form id={formName} >
                            {/* {erroeMsg ? <span className="d-flex justify-content-center text-danger">{erroeMsg}</span> : <span>&nbsp;</span>} */}
                            <div className="mt-1">
                                <label htmlFor="txt-deviationType">Deviation Type:</label>
                                <Field as='select'
                                    name='deviationTypeCode'
                                    id="txt-deviationType"
                                    className="form-select mt-1"
                                    value={values.deviationTypeCode}
                                    onChange={(e: any) => onDeviationTypeChangeHandle(e, setFieldValue)}
                                >
                                    <option value="">--Select Deviation Type--</option>
                                    {
                                        deviationTypes?.DEVIATION_TYPE?.map((opt: any, i: any) => (
                                            <option key={i} value={opt.code}>{opt.name}</option>
                                        ))
                                    }
                                </Field>
                                <div className="text-danger"><ErrorMessage name='deviationTypeCode' /></div>
                            </div>
                            <div className="pb-1">
                                <label htmlFor="text-category">Category : </label>
                                <Field
                                    as='select'
                                    id="text-category"
                                    name='categoryCode'
                                    value={values.categoryCode}
                                    className="form-select mt-1"
                                    onChange={(e: any) => onCategoryChangeHandle(e, setFieldValue)}
                                >
                                    <option value="">--Select Category --</option>
                                    {
                                        deviationCategories?.CATEGORY_TYPE?.map((opt: any, i: any) => (
                                            <option key={i} value={opt.code}>{opt.name}</option>
                                        ))
                                    }
                                </Field>
                                {(errors && errors.categoryCode && touched && touched.categoryCode) &&
                                    <span className="text-danger">{errors.categoryCode as string}</span>}
                            </div>
                            <div className="pb-2">
                                <label htmlFor="text-derscription">Description: </label>
                                <Field
                                    as='textarea'
                                    id="text-derscription"
                                    name='description'
                                    value={values.description}
                                    className="form-control mt-1"
                                    onChange={(e: any) => onDescriptionHandle(e, setFieldValue)}
                                />
                                {(errors && errors.description && touched && touched.description) &&
                                    <span className="text-danger">{errors.description as string}</span>}
                            </div>
                        </Form>
                    )}
                </Formik>
            </div>
        </React.Fragment>
    )

}

export default AddProtocalDeviation;