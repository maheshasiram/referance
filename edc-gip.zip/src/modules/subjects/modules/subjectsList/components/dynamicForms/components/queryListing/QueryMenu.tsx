import React from 'react';
import IconButton from '@mui/material/IconButton';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import RemoveRedEyeIcon from '@mui/icons-material/RemoveRedEye';
import FolderOpenIcon from '@mui/icons-material/FolderOpen';
// import LockIcon from '@mui/icons-material/Lock';
import LockOpenIcon from '@mui/icons-material/LockOpen';
// import ViewQuery from './ViewQuery';
import AuditHistory from './AuditHistory';
import StickyNote2Icon from '@mui/icons-material/StickyNote2';
import CustomDialog from '../../../../../../../../common/modals/CustomeDialog';
import AcUnitIcon from '@mui/icons-material/AcUnit';
import AddCommentIcon from '@mui/icons-material/AddComment';
import AddQuery from './AddQuery';
import { useDispatch, useSelector } from 'react-redux';
import _ from 'lodash';
import { Types } from '../../../../reducers/Types';
import { addQueryModal } from '../../../../constants/modal';
import ViewQuery from '../../../../../../../../common/viewQueries/ViewQuery';
// import ViewQuery from './ViewQuery';
import { Types as Type } from '../../../../../../../../constants/Types';
import { fetchViewQueryData, getdteNoteRequest, findBySubjectFieldId, fetchProtocolDeviations, dteNoteRequest } from '../../actions/actions';
import { configDataType } from '../../../../../../../../actions/actions';
import ProtocolDeviation from './ProtocolDeviation';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import Notes from './Notes';
import AddProtocalDeviation from './AddProtocalDeviation';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import { changeableProperties, updateDynamicFormData } from '../../helpers/updateDynamicFormData';

function QueryMenu(props: any) {
	const { dynamicFormData } = useSelector((state: any) => state.subjects);
	const { index, rowIndex, grpFieldIndex, isGroup, setFreezField } = props;
	const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
	const open = Boolean(anchorEl);
	const [openDialog, setOPenDialog] = React.useState(false);
	const [actionType, setActionType] = React.useState<any>(null);
	const dispatch = useDispatch();
	const [btnDisable, setBtnDisable] = React.useState(true);
	const { notes } = useSelector((state: any) => state.subjects);
	const { currentUser, page } = useSelector((state: any) => state.application);
	const [subjectFieldId, setSubjectFieldId] = React.useState(0);

	const payload = updateDynamicFormData(null);
	let field = isGroup ? payload.data[index]?.group?.rows[rowIndex]?.fields[grpFieldIndex] : payload.data[index]?.field
	let _properties: any = changeableProperties(field);
	const { freez } = _properties;

	const onOpenHandler = (type: string) => {
		handleClose();
		if (type !== "viewQuery") {
			setOPenDialog(true);
		}
		setActionType(type);
		const _payload = { ...{}, ...addQueryModal };
		if (type === "AddQuery") {
			// dispatch(configDataType('RESOLUTION_TYPE', (response: any) => {
			// 	dispatch({ type: Types.GET_QUERY_TYPE, payload: response });
			// }));
			if (payload.data[index].field) {
				_payload.subjectFieldId = payload.data[index].field.id;
				dispatch({ type: Types.CREATE_QUERY, payload: _payload });
			} else if (payload.data[index].group) {
				_payload.subjectFieldId = payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].id;
				dispatch({ type: Types.CREATE_QUERY, payload: _payload });
			}
		} else if (type === "viewQuery") {
			let _subFieldId: any
			dispatch({ type: Type.OPEN_CUSTOM_DIALOG, payload: true });
			if (payload.data[index].field) {
				_subFieldId = payload.data[index].field.id
				setSubjectFieldId(payload.data[index].field.id);
			} else if (payload.data[index].group) {
				_subFieldId = payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].id
				setSubjectFieldId(payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].id);
			}
			dispatch(fetchViewQueryData(_subFieldId, (response: any) => {
				console.log("...65", response);
				dispatch({ type: Type.GET_VIEW_QUERY_DATA, payload: response.data });
			}));
			if (type === "viewQuery") {
				dispatch(configDataType('QUERY_STATUS', (response: any) => {
					dispatch({ type: Types.GET_QUERY_STATUS, payload: response });
				}));
				dispatch(configDataType('RESOLUTION_TYPE', (response: any) => {
					dispatch({ type: Types.GET_QUERY_TYPE, payload: response });
				}));
			}
		} else if (type === "Notes") {
			setBtnDisable(true);
			const params = {
				fieldId: props.fieldId,
				userId: currentUser.id,
				formId: page.selectedForm.id,
				visitId: page.selectedVisit.id,
				subjectId: page.selectedSubject.id
			}
			dispatch(getdteNoteRequest(params, (response: any) => {
				console.log('89....', response);
				dispatch({ type: Types.GET_NOTES, payload: response })
			}))
			const _paylaod = {
				...{}, ...notes,
				fieldId: props.fieldId,
				acknowledge: false,
				userId: currentUser.id,
				userName: currentUser.userName,
				notifyUsers: [{ UserId: currentUser.id, id: 0, userName: currentUser.userName }]
			};
			dispatch({ type: Types.CREATE_NOTES, payload: _paylaod })
		} else if (type === "AuditHistory") {
			let _subFieldId: any;
			if (payload.data[index].field) {
				_subFieldId = payload.data[index].field.id
			} else if (payload.data[index].group) {
				_subFieldId = payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].id
			}
			dispatch(findBySubjectFieldId(_subFieldId, (response: any) => {
				dispatch({ type: Types.GET_AUDIT_LOG_DETAILS_BY_ID, payload: response.data })
			}))
		} else if (type === 'protocolDeviation') {
			let _subFieldId: any
			if (payload.data[index].field) {
				_subFieldId = payload.data[index].field.id
				setSubjectFieldId(payload.data[index].field.id);
			} else if (payload.data[index].group) {
				_subFieldId = payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].id
				setSubjectFieldId(payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].id);
			}
			dispatch(fetchProtocolDeviations(_subFieldId))
		}
		else if (type === 'addProtocolDeviation') {
			dispatch(configDataType('DEVIATION_TYPE', (response: any) => {
				dispatch({ type: Types.GET_DEVIATION_TYPE, payload: response });
			}));
			dispatch(configDataType('CATEGORY_TYPE', (response: any) => {
				dispatch({ type: Types.GET_PROTOCOL_CATEGORIES, payload: response });
			}));
			if (payload.data[index].field) {
				setSubjectFieldId(payload.data[index].field.id);
			} else if (payload.data[index].group) {
				setSubjectFieldId(payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].id);
			}
		}
	}

	const onCloseHandler = () => {
		setOPenDialog(false);
		setBtnDisable(true);
	};

	const handleClick = (event: React.MouseEvent<HTMLElement>) => {
		setAnchorEl(event.currentTarget);

	};

	const handleClose = () => {
		setAnchorEl(null);
	};

	const onFreezeHandler = () => {
		handleClose();
		// let id;
		let freezStatus;
		// let field;
		if (payload.data[index].field) {
			payload.data[index].field.freez = payload.data[index].field.freez ? false : true;
			// field = payload.data[index].field
			// id = payload.data[index].field.id;
			freezStatus = payload.data[index].field.freez;
		} else if (payload.data[index].group) {
			payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].freez = payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].freez ? false : true;
			// id = payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].id;
			// field = payload.data[index].group.rows[rowIndex].fields[grpFieldIndex]
			freezStatus = payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].freez;
		}
		// const input = document.getElementById('field_' + `${id}`) as HTMLInputElement;
		// const reset = document.getElementById('reset_' + `${id}`) as HTMLInputElement;
		// input.disabled = freezStatus;
		setFreezField(freezStatus)
		// if(reset){
		// 	reset.style.display = freezStatus ? "none" : '';
		// }
		
		updateDynamicFormData(payload);
		// dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload });
	}

	const onSubmitHandler = () => {
		if (actionType === "StickyNotes") {
			dispatch(dteNoteRequest(notes));
			onCloseHandler();
		}
	}

	return (
		<div className='field-actions'>
			<IconButton
				aria-label="more"
				id="long-button"
				className='field-kababMenu'
				aria-controls={open ? 'long-menu' : undefined}
				aria-expanded={open ? 'true' : undefined}
				aria-haspopup="true"
				onClick={handleClick}
			>
				<MoreVertIcon />
			</IconButton>
			<Menu
				id="long-menu"
				MenuListProps={{
					'aria-labelledby': 'long-button'
				}}
				anchorEl={anchorEl}
				open={open}
				onClose={handleClose}
				PaperProps={{
					style: {
						display: 'block',
						fontSize: '13px'
					}
				}}
			>
				<MenuItem
					key={'viewQuery'}
					className='ActionMenuItem'
					id='ActionMenuItem'
					selected={true}
					onClick={() => onOpenHandler('viewQuery')}
				// onClick={() => onViewQueryHandler('viewQuery')}
				>
					<RemoveRedEyeIcon /><span>View Query </span>
				</MenuItem>
				<MenuItem
					className='ActionMenuItem'
					key={'AddQuery'}
					selected={false}
					onClick={() => onOpenHandler('AddQuery')}
				>
					<AddCommentIcon /><span> Add Query</span>
				</MenuItem>
				<MenuItem
					className='ActionMenuItem'
					key={'AuditHistory'}
					selected={false}
					onClick={() => onOpenHandler('AuditHistory')}
				>
					<FolderOpenIcon /><span>Audit History</span>
				</MenuItem>
				<MenuItem
					className='ActionMenuItem'
					key={'Notes'}
					selected={false}
					onClick={() => onOpenHandler('Notes')}
				>
					<StickyNote2Icon /><span>Notes</span>
				</MenuItem>
				<MenuItem
					className='ActionMenuItem'
					key={'freeze_unFreeze'}
					selected={false}
					onClick={onFreezeHandler}
				>
					{!freez ? <div><AcUnitIcon /><span>Freeze</span></div> : <div><LockOpenIcon /><span>Un Freeze</span></div>}
				</MenuItem>
				<MenuItem
					className='ActionMenuItem'
					key={'protocolDeviation'}
					selected={false}
					onClick={() => onOpenHandler('protocolDeviation')}
				>
					<AccessTimeIcon /><span>Protocol Deviation</span>
				</MenuItem>
				<MenuItem
					className='ActionMenuItem'
					key={'addProtocolDeviation'}
					selected={false}
					onClick={() => onOpenHandler('addProtocolDeviation')}
				>
					<AddCircleOutlineIcon /><span>Add Protocol Deviation</span>
				</MenuItem>
			</Menu>
			<div>
				{actionType === 'viewQuery' && <ViewQuery subjectFieldId={subjectFieldId} />}
				<CustomDialog
					title={actionType}
					open={openDialog}
					// form="resonToChange"
					form={actionType === 'AddQuery' ? 'addQueryForm' : actionType === 'addProtocolDeviation' ? 'deviation' : ''}
					onClose={onCloseHandler}
					maxWidth={actionType === 'AddQuery' || actionType === 'Notes' ? 'sm' : ''}
					fullWidth={actionType === 'AddQuery' || actionType === 'Notes' ? true : false}
					onSubmitHandler={actionType === 'Notes' && onSubmitHandler}
					padding={actionType === 'Notes' ? true : false}
					actionType={((actionType === 'AddQuery') || (actionType === 'addProtocolDeviation') || (actionType === 'Notes')) && 'Submit'}
					disabled={btnDisable}
				>
					<div>
						{
							actionType === 'AddQuery' ? <AddQuery formName={"addQueryForm"} setBtnDisable={setBtnDisable} setOPenDialog={setOPenDialog} /> :
								actionType === 'AuditHistory' ? <AuditHistory /> :
									actionType === 'Notes' ? <Notes setBtnDisable={setBtnDisable} /> :
										actionType === 'protocolDeviation' ? <ProtocolDeviation onCloseHandler={onCloseHandler} subjectFieldId={subjectFieldId} /> :
											actionType === 'addProtocolDeviation' && <AddProtocalDeviation formName={"deviation"} setBtnDisable={setBtnDisable} setOPenDialog={setOPenDialog} subjectFieldId={subjectFieldId} />
						}
					</div>
				</CustomDialog>
			</div>
		</div>
	);
}
export default QueryMenu;
