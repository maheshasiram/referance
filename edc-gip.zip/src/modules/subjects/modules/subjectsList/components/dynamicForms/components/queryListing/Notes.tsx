import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import SelectField from '../../../../../../../../common/selectField/SelectField';
import { Types } from '../../../../reducers/Types';
import EditIcon from '@mui/icons-material/Edit';
import DoneIcon from '@mui/icons-material/Done';
import CloseIcon from '@mui/icons-material/Close';
import './styles.scss';
import _ from 'lodash';
import { upadteNoteTransaction } from '../../actions/actions';
import TextareaAutosize from '@mui/base/TextareaAutosize';
import CustomToolTip from '../../../../../../../../components/CustomToolTip';

function Notes(props: any) {
    const { setBtnDisable } = props;
    const { notes, getNotes } = useSelector((state: any) => state.subjects);
    const { currentUser } = useSelector((state: any) => state.application);
    const [editIndex, setEditIndex] = React.useState(null);
    const [value, setValue] = React.useState(null);
    const dispatch = useDispatch();

    const onChangeNote = (e: any, type: any) => {
        if (type === 'add') {
            setBtnDisable(false);
            const _paylaod = { ...{}, ...notes, comments: e.target.value };
            dispatch({ type: Types.CREATE_NOTES, payload: _paylaod });
        } else {
            setValue(e.target.value)
        }
    }


    const onEditHandler = (e: any, index: any) => {
        setEditIndex(index)
    }
    const onUpdateNote = (e: any, item: any, index: any) => {
        const _getNotes = [...[], ...getNotes]
        _getNotes[index].comments = value
        dispatch({ type: Types.GET_NOTES, payload: _getNotes })
        setEditIndex(null)
        dispatch(upadteNoteTransaction(getNotes[index]))
    }

    const onClearNote = () => {
        setEditIndex(null)
    }
    const handleMouseOver = (e: any, index: number) => {
        const _paylaod = _.cloneDeep(getNotes);
        _paylaod[index].hover = true   
        dispatch({ type: Types.GET_NOTES, payload: _paylaod })
    };
    
    const handleMouseOut = (e: any, index: number) => {
        const _paylaod = _.cloneDeep(getNotes);
        delete _paylaod[index].hover
        dispatch({ type: Types.GET_NOTES, payload: _paylaod })
    };


    return (
        <React.Fragment>
            <div className='notes-main'>
                <div className='notes-header'>
                    <label>Users :</label>
                    <SelectField placeholder={"Select User"} />
                </div>
                <div className='notes-container'>
                    {getNotes?.map((item: any, index: number) => {
                        return (

                            <div className={`${item.userId === currentUser.id ? 'd-flex flex-row justify-content-end notes-content' : 'd-flex flex-row justify-content-start notes-content'}`}>
                                {index === editIndex ?
                                    <div className='d-flex align-items-center'>
                                        <input defaultValue={item.comments} className='form-control' onChange={(e: any) => onChangeNote(e, 'edit')} />
                                        <span onClick={(e: any) => onUpdateNote(e, item, index)} className='done-icon' ><CustomToolTip title=''><DoneIcon /></CustomToolTip></span>
                                        <span onClick={onClearNote} className='close-icon'><CustomToolTip title=''><CloseIcon /></CustomToolTip></span>
                                    </div> :
                                    <div onMouseOver={(e: any) => handleMouseOver(e, index)}
                                        onMouseOut={(e: any) => handleMouseOut(e, index)}
                                    >
                                        <div className='item-content'>
                                            {item.hover ?
                                            <div className='d-flex align-items-center'>
                                                <ul>{item.comments}</ul><span onClick={(e: any) => onEditHandler(e, index)} className='edit-icon'><CustomToolTip title='edit Notes'><EditIcon /></CustomToolTip></span></div> 
                                            :
                                            <ul>{item.comments}</ul>}
                                        </div>
                                    </div>
                                }
                            </div>
                        )
                    })}
                </div>
                <div className='notes-text'>
                        <TextareaAutosize   onChange={(e: any) => onChangeNote(e, 'add')} placeholder="Enter Notes" />
                </div>
            </div>
        </React.Fragment>
    );
}
export default Notes;
