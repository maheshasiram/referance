import React, { Fragment, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import FieldContainer from "../helpers/FieldContainer";
import { Types } from "../../../reducers/Types";
import _ from "lodash";
import FormControl from '@mui/material/FormControl';
import TextareaAutosize from '@mui/base/TextareaAutosize';
import PriorityHighIcon from '@mui/icons-material/PriorityHigh';
import CustomToolTip from "../../../../../../../components/CustomToolTip";
import { onReasonToChange } from "../helpers/resonTochange";
import AutorenewIcon from '@mui/icons-material/Autorenew';
import { onResetValues } from "../helpers/resetValues";
import { getRulesByFieldId } from "../actions/actions";
import { toastAlert } from "../../../../../../../actions/actions";
import { changeableProperties, updateDynamicFormData } from "../helpers/updateDynamicFormData";


function TextArea(props: any) {
    const dispatch = useDispatch();
    const {
        readOnly, id, index, isGroup, grpFieldIndex, /*freez,*/ spellCheck,
        value, rowIndex, minValueLength, fldError, fldFields, defaultValue, disable, ruleError,placeholder
    } = props;
    const { dynamicFormData, entryFormData } = useSelector((state: any) => state.subjects);
    const { page } = useSelector((state: any) => state.application);
    const [val, setVal]=useState(value ? value : defaultValue );

    let payload = updateDynamicFormData(null);
    console.log("39...",payload)
	let field = isGroup ? payload.data[index]?.group?.rows[rowIndex]?.fields[grpFieldIndex] : payload.data[index]?.field
	let _properties: any = changeableProperties(field);
    
    const { errorMsg, freez } = _properties;

    const [freezField, setFreezField] = useState(freez);


    const onChangeHandler = (event: any) => {
        // let payload = _.cloneDeep(dynamicFormData)
        payload = updateDynamicFormData(null)
        payload = onReasonToChange(isGroup, payload, index, rowIndex, grpFieldIndex, event.target.value, page, entryFormData)
        if (isGroup) {
            payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].value = event.target.value
            delete payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].ruleError
        } else {
            payload.data[index].field.value = event.target.value
            delete payload.data[index].field.fldError
            delete payload.data[index].field.ruleError;
        }
        console.log("31....", payload)
        // dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload })
        updateDynamicFormData(payload);
		setVal(event.target.value)
    };
    // const onBlurHandler = (event: any) => {
        // const payload = _.cloneDeep(dynamicFormData)
        // console.log("34...", payload)
        // if (isGroup) {
        //     payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].errorMsg = event.target.value.length < minValueLength ? `Please add minimum ${minValueLength} characters` : ''
        // } else {
        //     payload.data[index].field.errorMsg = event.target.value.length < minValueLength ? `Please add minimum ${minValueLength} characters` : ''
        // }
        // dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload })
        // updateDynamicFormData(payload);
    // };
    return (
        <Fragment>
            <FieldContainer {...props} setFreezField={setFreezField} >
                <FormControl className="field">
                    <TextareaAutosize
                        // multiline
                        // rows="2"
                        // variant="outlined"
                        key={`txtArea_${id}`}
                        id={`field_${id}`}
                        name={`input_${id}`}
                        placeholder={placeholder ? placeholder : ''}
                        className='df_txtField field'
                        value={val}
                        onChange={onChangeHandler}
                        // inputProps={{ minLength: minValueLength, maxLength: maxValueLength }}
                        // onBlur={onBlurHandler}
                        spellCheck={spellCheck}//Added spellcheck -Nitish
                        disabled={readOnly || freezField || disable}
                    />
                </FormControl>
                {fldError && <CustomToolTip title={fldError}>
                    <PriorityHighIcon
                        sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
                </CustomToolTip>}
                {ruleError && <CustomToolTip title={ruleError}>
                    <PriorityHighIcon
                        sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
                </CustomToolTip>}
                {((val) && (!disable && !freezField && !readOnly)) &&
                    <span className="ps-1 resetFieldValue">
                        <CustomToolTip title='clear value'>
                            <AutorenewIcon onClick={() => onResetValues(updateDynamicFormData(null), "", isGroup, null, dispatch, rowIndex, index, grpFieldIndex,setVal)}
                                sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
                        </CustomToolTip>
                    </span>
                }
            </FieldContainer>
        </Fragment>
    )
}
export default TextArea