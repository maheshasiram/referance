import React, { Fragment, useState } from "react";
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import { useDispatch, useSelector } from "react-redux";
import _ from 'lodash'
import { Types } from '../../../reducers/Types';
import FieldContainer from "../helpers/FieldContainer";
import CustomToolTip from "../../../../../../../components/CustomToolTip";
import PriorityHighIcon from '@mui/icons-material/PriorityHigh';
import AutorenewIcon from '@mui/icons-material/Autorenew';
import { NonGroupfieldLevelDynamics, groupfieldLevelDynamics } from "../helpers/fieldLevelDyanmics";
import { onResetValues } from "../helpers/resetValues";
import { onReasonToChange } from "../helpers/resonTochange";
import { getDerivativeValues } from "../helpers/derivations/derivations";
import { getRulesByFieldId } from "../actions/actions";
import { changeableProperties, updateDynamicFormData } from "../helpers/updateDynamicFormData";

function SingleSelect(props: any) {
    const dispatch = useDispatch()

    const {
        // header, note, onAirInstruction, defaultValue, questionNumber,
        /*freez,*/ variableText, readOnly, id, index, isGroup, grpFieldIndex, value, rowIndex, responseOptions, fldError, fldFields, defaultValue, disable, ruleError } = props;
        
    const [val, setVal]=useState(value ? value : defaultValue);
    const { dynamicFormData, entryFormData, derivations } = useSelector((state: any) => state.subjects);
    const { page } = useSelector((state: any) => state.application);

    let payload = updateDynamicFormData(null);
    let field = isGroup ? payload.data[index]?.group?.rows[rowIndex]?.fields[grpFieldIndex] : payload.data[index]?.field;
    let _properties: any = changeableProperties(field);
    const { errorMsg, freez } = _properties;

    const [freezField, setFreezField] = useState(freez);

    const onChangeHandler = async (event: any) => {
        payload = updateDynamicFormData(null);
        payload = onReasonToChange(isGroup, payload, index, rowIndex, grpFieldIndex, event.target.value, page, entryFormData)
        if (isGroup) {
            if (fldFields && fldFields?.fieldId === payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].fieldId) {
                const _fldValidate = groupfieldLevelDynamics(payload, fldFields, event.target.value, dispatch, rowIndex, 'single-select');
                if (_fldValidate) {
                    payload = _fldValidate
                    payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].value = event.target.value;
                }
                setVal(payload.data[index]?.group?.rows[rowIndex]?.fields[grpFieldIndex]?.value);
				dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload });
            } else {
                payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].value = event.target.value;
                delete payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].fldError;
                delete payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].ruleError;
                // updateDynamicFormData(payload);
				setVal(event.target.value);
            }
        } else {
            if (fldFields && fldFields?.fieldId === payload.data[index].field?.fieldId) {
                const _fldValidate = NonGroupfieldLevelDynamics(payload, fldFields, event.target.value, dispatch, 'single-select');
                if (_fldValidate) {
                    payload = _fldValidate
                    payload.data[index].field.value = event.target.value;
                }
                setVal(payload?.data[index]?.field?.value);
				dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload });
            } else {
                payload.data[index].field.value = event.target.value;
                delete payload.data[index].field.fldError;
                delete payload.data[index].field.ruleError;
                // updateDynamicFormData(payload);
				setVal(event.target.value);
            }
        }
        // payload = await getDerivativeValues(derivations, payload)
        // console.log("58....",payload)
        updateDynamicFormData(payload);
		// setVal(event.target.value)
        // dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload });
    };

    const onBlurHandler = async () => {
        payload = await updateDynamicFormData(null);
        payload = await getDerivativeValues(derivations, payload)
        updateDynamicFormData(payload);
        // dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload });
    }

    return (
        <Fragment>
            <FieldContainer {...props} setFreezField={setFreezField} >
                <FormControl className="field select_field">
                    <Select
                        native
                        id={`field_${id}`}
                        name={`select_${id}`}
                        className='df_select'
                        disabled={readOnly || freezField || disable}
                        value={val}
                        onChange={onChangeHandler}
                        onBlur={onBlurHandler}
                    >
                        <option key={''} value={''}>{`Select ${variableText}`}</option>
                        {responseOptions?.map((item: any) => (
                            <option key={item.id} value={item.response}>{item.response}</option>
                        ))}

                    </Select>
                </FormControl>

                {fldError && <CustomToolTip title={fldError}>
                    <PriorityHighIcon
                        sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
                </CustomToolTip>}
                {ruleError && <CustomToolTip title={ruleError}>
                    <PriorityHighIcon
                        sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
                </CustomToolTip>}
                {((val) && (!disable && !freezField && !readOnly)) &&
                    <span className="ps-1 resetFieldValue">
                        <CustomToolTip title='clear value'>
                            <AutorenewIcon onClick={() => onResetValues(updateDynamicFormData(null), "", isGroup, fldFields, dispatch, rowIndex, index, grpFieldIndex,setVal)}
                                sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
                        </CustomToolTip>
                    </span>
                }
            </FieldContainer>
        </Fragment>
    )
}
export default SingleSelect