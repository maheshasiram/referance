import _ from 'lodash';
export const onReasonToChange = (isGroup:any,dynamicFormData:any,index:any,rowIndex:any,grpFieldIndex:any,fieldValue:any,page:any,entryFormData:any) =>{
    const pageData = { ...{}, ...page };
    const payload = _.cloneDeep(dynamicFormData);
    const formStatus = pageData.selectedForm.actionStatus.code;
    if(isGroup){
        const savedValue = entryFormData?.data[index]?.group?.rows[rowIndex]?.fields[grpFieldIndex]?.value;
        const currentValue = fieldValue === '' ? null : fieldValue
        if(formStatus === "FORM_STATUS_COMLETED" && savedValue !== currentValue){
            payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].reasonToChange = true;
        }
        else{
            delete payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].reasonToChange;
        }
        console.log("4....",savedValue,currentValue)
    }else{
        const savedValue = entryFormData?.data[index]?.field?.value;
        const currentValue = fieldValue === '' ? null : fieldValue
        if(formStatus === "FORM_STATUS_COMLETED" && savedValue !== currentValue){
            payload.data[index].field.reasonToChange = true;
        }
        else{
            delete payload.data[index].field.reasonToChange;
        }
        console.log("23....",savedValue !== currentValue)
    }
    console.log("25...",payload)
    return payload;
}