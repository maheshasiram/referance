import React, { Fragment, useState } from "react";
import { TextField } from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import _ from 'lodash'
import { Types } from "../../../reducers/Types";
import FieldContainer from "../helpers/FieldContainer";
import FormControl from '@mui/material/FormControl';
import PriorityHighIcon from '@mui/icons-material/PriorityHigh';
import CustomToolTip from "../../../../../../../components/CustomToolTip";
import { onReasonToChange } from "../helpers/resonTochange";
import { getDerivativeValues } from "../helpers/derivations/derivations";
import AutorenewIcon from '@mui/icons-material/Autorenew';
import { onResetValues } from "../helpers/resetValues";
import { getRulesByFieldId } from "../actions/actions";
import { changeableProperties, updateDynamicFormData } from "../helpers/updateDynamicFormData";

function Real(props: any) {
    const {
        readOnly, id, index, isGroup, grpFieldIndex, /*freez,*/ defaultValue,
        value, rowIndex, minValueLength, fldError, variableFieldFormat, fldFields, disable, ruleError,placeholder
    } = props;
    const { dynamicFormData, derivations } = useSelector((state: any) => state.subjects);
    const { page, entryFormData } = useSelector((state: any) => state.application);
    const regex = new RegExp(variableFieldFormat?.value);
    const [val, setVal]=useState(value ? value : defaultValue);
    const dispatch = useDispatch()
    let payload = updateDynamicFormData(null);
    let field = isGroup ? payload.data[index]?.group?.rows[rowIndex]?.fields[grpFieldIndex] : payload.data[index]?.field;
    let _properties: any = changeableProperties(field);
    const { errorMsg, freez } = _properties;

    const [freezField, setFreezField] = useState(freez);

    const onChangeHandler = (event: any) => {
        // let payload = _.cloneDeep(dynamicFormData)
        payload = updateDynamicFormData(null);
        payload = onReasonToChange(isGroup, payload, index, rowIndex, grpFieldIndex, event.target.value, page, entryFormData)
        if (event.target.value >= 0) {
            if (isGroup) {
                payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].value = event.target.value
                delete payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].fldError
                delete payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].ruleError
                payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].errorMsg = event.target.value ? regex.test(event.target.value) ? event.target.value.length < minValueLength ? `Please add minimum ${minValueLength} characters` : "" : variableFieldFormat?.errorMessage : "";
            } else {
                payload.data[index].field.value = event.target.value
                delete payload.data[index].field.fldError
                delete payload.data[index].field.ruleError;
                payload.data[index].field.errorMsg = event.target.value ? regex.test(event.target.value) ? event.target.value.length < minValueLength ? `Please add minimum ${minValueLength} characters` : "" : variableFieldFormat?.errorMessage : "";
            }
        }
        updateDynamicFormData(payload);
		setVal(event.target.value)
        // dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload })
    };
    const getNoOfSteps = () => {
        if (value && value.length > 0) {
            if (value.includes('.')) {
                const splits = value.split(".")
                const decimalLength = splits[1].length;
                const decimalList = [];
                for (let i = 1; i < decimalLength; i++) {
                    decimalList.push('0');
                }
                decimalList.push('1');
                return `0.${decimalList.join('')}`;
            } else {
                return '0.1';
            }
        } else {
            return '0.1';
        }
    }
    const onBlurHandler = async (event: any) => {
        let payload = _.cloneDeep(dynamicFormData)
        payload = await getDerivativeValues(derivations, payload)
        // const _length = event.target.value.length
        if (isGroup) {
            payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].errorMsg = event.target.value ? regex.test(event.target.value) ? event.target.value.length < minValueLength ? `Please add minimum ${minValueLength} characters` : "" : variableFieldFormat?.errorMessage : "";
        } else {
            payload.data[index].field.errorMsg = event.target.value ? regex.test(event.target.value) ? event.target.value.length < minValueLength ? `Please add minimum ${minValueLength} characters` : "" : variableFieldFormat?.errorMessage : "";
        }
        updateDynamicFormData(payload)
        // dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload })
        // setTimeout(() => {
        //     dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload })
        // }, 250);
    };
    // console.log('props real........', props);

    return (
        <Fragment>
            <FieldContainer {...props} setFreezField={setFreezField} >
                <FormControl className="field">
                    <TextField
                        id={`field_${id}`}
                        name={`input_${id}`}
                        placeholder={placeholder ? placeholder : ''}
                        className='df_txtField field'
                        variant="outlined"
                        type={'number'}
                        disabled={readOnly || freezField || disable}
                        value={val ? val : defaultValue}
                        onChange={onChangeHandler}
                        inputProps={{ step: getNoOfSteps() }}
                        onKeyPress={(e) => {
                            if (e.key === "-" || e.key === "+" || e.key === "e") {
                                e.preventDefault();
                            }
                        }}
                        onBlur={onBlurHandler}
                    />
                </FormControl>

                {fldError && <CustomToolTip title={fldError}>
                    <PriorityHighIcon
                        sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
                </CustomToolTip>}
                {ruleError && <CustomToolTip title={ruleError}>
                    <PriorityHighIcon
                        sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
                </CustomToolTip>}
               {((val) && (!disable && !freezField && !readOnly)) &&
                    <span className="ps-1 resetFieldValue">
                        <CustomToolTip title='clear value'>
                            <AutorenewIcon onClick={() => onResetValues(updateDynamicFormData(null), "", isGroup, null, dispatch, rowIndex, index, grpFieldIndex,setVal)}
                                sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
                        </CustomToolTip>
                    </span>
                }

            </FieldContainer>
        </Fragment>
    )
}
export default Real