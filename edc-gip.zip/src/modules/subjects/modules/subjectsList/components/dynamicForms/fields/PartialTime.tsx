// import dayjs from "dayjs";
import _ from "lodash";
import React, { Fragment, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Types } from "../../../reducers/Types";
import FieldContainer from "../helpers/FieldContainer";
import { LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import AutorenewIcon from '@mui/icons-material/Autorenew';
import CustomToolTip from "../../../../../../../components/CustomToolTip";
import PriorityHighIcon from '@mui/icons-material/PriorityHigh';
import { onResetValues } from "../helpers/resetValues";
import { onReasonToChange } from "../helpers/resonTochange";
import { getRulesByFieldId } from "../actions/actions";
import { changeableProperties, updateDynamicFormData } from "../helpers/updateDynamicFormData";

function PartialTime(props: any) {
    const dispatch = useDispatch()
    const {
        // header, note, onAirInstruction, variableText, defaultValue, questionNumber,layout,
        id, readOnly, index, isGroup, grpFieldIndex, value, rowIndex, /*freez,*/ fldError, defaultValue, disable, ruleError
    } = props;
    const { currentStudy } = useSelector((state: any) => state.application);
    const { dynamicFormData, entryFormData } = useSelector((state: any) => state.subjects);
    const { page } = useSelector((state: any) => state.application);
    const [val, setVal] = useState(value ? value : defaultValue);
    const [timeFields, setTimeFields] = useState([
        { label: 'hh', value: '' },
        { label: 'mm', value: '' },
        { label: 'ss', value: '' },
    ])
    const [meridiem, setMeridiem] = useState('am')
    const initialTimeValue: any = [
        { label: 'hh', value: '' },
        { label: 'mm', value: '' },
        { label: 'ss', value: '' },];
    useEffect(() => {

        if (val && val.trim() !== '') {
            let _time: any = null
            if (currentStudy?.timeFormat === '12 Hrs') {
                let _timeFormat = val.split(' ')
                _time = _timeFormat[0].split(':')
                setMeridiem(_timeFormat[1])
            } else {
                _time = val.split(':')
            }
            const _timeFields = [...[], ...timeFields]
            _time.map((item: any, index: number) => {
                _timeFields[index].value = item
                return null
            })
            setTimeFields(_timeFields)
        }

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    let payload = updateDynamicFormData(null);
    let field = isGroup ? payload.data[index]?.group?.rows[rowIndex]?.fields[grpFieldIndex] : payload.data[index]?.field;
    let _properties: any = changeableProperties(field);
    const { errorMsg, freez } = _properties;

    const [freezField, setFreezField] = useState(freez);

    const onChangeHandler = async (event: any, fieldIndex: number) => {
        // let payload = _.cloneDeep(dynamicFormData)
        // const time = dayjs(event).format('hh:mm')
        payload = updateDynamicFormData(null);
        const _time = [...[], ...timeFields]
        _time[fieldIndex].value = event.target.value
        let _partialTime: any = null
        if (currentStudy?.timeFormat === '12 Hrs') {
            let _timeArray: string = _time.map((item: any) => item.value ? item.value : 'un').join(':')
            _partialTime = _timeArray + ' ' + meridiem
        } else {
            _partialTime = _time.map((item: any) => item.value ? item.value : 'un').join(':')
        }

        // check for error message for the time format
        let error = await getErrors(_time)

        payload = onReasonToChange(isGroup, payload, index, rowIndex, grpFieldIndex, _partialTime, page, entryFormData)
        if (isGroup) {
            payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].value = _partialTime
            payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].errorMsg = error;
            delete payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].ruleError
        } else {
            payload.data[index].field.value = _partialTime
            payload.data[index].field.errorMsg = error;
            delete payload.data[index].field.fldError
            delete payload.data[index].field.ruleError;
        }
        updateDynamicFormData(payload);
        setVal(_partialTime)
        // dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload })
    };
    const onClearPartialTime = () => {
        const payload = _.cloneDeep(dynamicFormData)
        if (isGroup) {
            // payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].value = null
            setTimeFields([
                { label: 'hh', value: '' },
                { label: 'mm', value: '' },
                { label: 'ss', value: '' },
            ])
        } else {
            // payload.data[index].field.value = null
            setTimeFields([
                { label: 'hh', value: '' },
                { label: 'mm', value: '' },
                { label: 'ss', value: '' },
            ])
        }
        dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload })
    }
    const onChangeMeridiem = (event: any) => {
        setMeridiem(event.target.value)
    }
    const getErrors = (_time: any) => {
        let error: any = ''
        _time.map((i: any) => {
            let _intValue = parseInt(i.value)
            if (i?.label == 'hh' && _intValue) {
                if ((currentStudy?.timeFormat === '12 Hrs' && _intValue > 12) ||
                    (currentStudy?.timeFormat === '24 Hrs' && _intValue > 24)) {
                    error = `The Time format should not exceed ${currentStudy?.timeFormat} format`
                }
            }
            if ((i?.label == 'mm' || i.label == 'ss') && _intValue) {
                if (_intValue > 59) {
                    error = `${i?.label == 'mm' ? 'Minutes' : 'Seconds'} should not exceed more than 60`
                }
            }
        })
        return error
    }

    return (
        <Fragment>
            <FieldContainer {...props} setFreezField={setFreezField} >
                <div className="d-flex align-items-center" >
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                        {
                            timeFields?.map((item: any, fieldIndex: any) => (
                                <React.Fragment key={`time_${fieldIndex}`} >
                                    {fieldIndex !== 0 && <span>:</span>}
                                    <input key={`TXT_${fieldIndex}`} type="text"
                                        id={`field_${id}`}
                                        name="Date"
                                        maxLength={2}
                                        placeholder={item.label}
                                        style={{ width: "54.5px" }}
                                        className="border form-control"
                                        value={item?.value}
                                        disabled={readOnly || freezField || disable}
                                        onChange={(event: any) => onChangeHandler(event, fieldIndex)}
                                    // onBlur={() => onBlurHandler(fieldIndex)}
                                    />
                                </React.Fragment>
                            ))
                        }
                        {
                            currentStudy?.timeFormat === '12 Hrs' &&
                            <React.Fragment>
                                <label>:</label>
                                <select value={meridiem} onChange={onChangeMeridiem} >
                                    <option value={'am'} >am</option>
                                    <option value={'pm'} >pm</option>
                                </select>
                            </React.Fragment>
                        }
                    </LocalizationProvider>
                    {((val) && (!disable && !freezField && !readOnly)) &&
                        <span className="ps-1 resetFieldValue">
                            <CustomToolTip title='clear value'>
                                <AutorenewIcon onClick={() => onResetValues(updateDynamicFormData(null), initialTimeValue, isGroup, null, dispatch, rowIndex, index, grpFieldIndex, setTimeFields)}
                                    sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
                            </CustomToolTip>
                        </span>
                    }
                </div>

                {fldError && <CustomToolTip title={fldError}>
                    <PriorityHighIcon
                        sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
                </CustomToolTip>}
                {ruleError && <CustomToolTip title={ruleError}>
                    <PriorityHighIcon
                        sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
                </CustomToolTip>}
            </FieldContainer>
        </Fragment>
    )
}
export default PartialTime