import moment from "moment";
// import _ from "lodash";
// import { updateDerivativeValues } from "./derivations";
import dayjs from "dayjs";
import store from "../../../../../../../../store/store";


export const extractNumericLogic = (_derivation: any) => {
    console.log('_derivation......num', _derivation)
    const application = store.getState().application

    let logicString = ''
    _derivation?.logic?.logicVariables?.map((item: any, itemIndex: any) => {
        console.log("..88", itemIndex);
        if (_derivation.logic.formula.formulaCode === "AGE") {
            // const _numerator = ''
            const dates: any = {};
            item.numeratorFields.map((i: any, index: number) => {
                console.log('i.value......', i.value)
                dates[`date${(index + 1)}`] = i.value
                return null;
            })
            let denominator = ''
            item.denominatorFields.map((i: any) => {
                denominator = denominator + i.value
                return null;
            })
            console.log('dates.......2', (moment(moment(dates.date1).format('YYYY-MM-DD'))).diff(moment(dates.date2).format('YYYY-MM-DD'), 'day'), moment('2019-11-11'))
            console.log('dates.......',dates, logicString,dayjs("17-07-2023").diff("16-07-2023", 'd', true),
            dayjs(dates.date1).diff((dates.date2), 'day') , (moment([17,7,2023]).diff(moment([16,7,2022],), 'months')), 'date..moment....', dayjs(dates.date1), dayjs(dates.date2));
            logicString = logicString + dayjs(dates.date1, application.currentStudy.dateFormat).diff(dayjs(dates.date2, application.currentStudy.dateFormat), 'day') + item.operation + denominator
        } else if (_derivation.logic.formula.formulaCode === "BMI") {
            let numerator = ''
            let denomionator = ''
            item.numeratorFields.map((i: any, index: number) => {
                // console.log("..7", index)
                numerator = numerator + i.value
                return null;
            })
            item.denominatorFields.map((i: any, index: number) => {
                // console.log("..887", index);

                denomionator = denomionator + i.value + i.operation
                return null;
            })
            logicString = numerator + item.operation + '(' + denomionator + ')'
        } else {
            let _fieldLogic = ''
            item?.fields?.map((i: any) => {
                _fieldLogic = _fieldLogic + i.operation + i.value
                return null;
            })
            logicString = logicString + item.operation + _fieldLogic
        }
        return null;
    })
    console.warn('logic string................', logicString);

    return eval(logicString)
}

export const extractDateLogic = (_derivation: any) => {
    const application = store.getState().application
    console.log("extractDateLogic", _derivation)
    let _addDate: any = ''

    if (_derivation?.calcFactor?.code === "DAYS_DATE_CAL") {
        console.log("_derivation 55", _derivation)
        // alert("daysss")
        let _date = ""
        let _int = ""
        _derivation?.logic?.logicVariables?.map((item: any) => {
            console.log("...59", item)
            if (item.dataType === "date") {
                _date = item.value
            } else if (item.dataType === "integer") {
                _int = item.value
            }
            return null;
        })
        if (_date && _int) {
            // _addDate = moment(_date).add(parseInt(_int), 'd').format(application.currentStudy.dateFormat)
            _addDate = dayjs(_date, application.currentStudy.dateFormat).add(parseInt(_int), 'day').format(application.currentStudy.dateFormat)
        }
        console.log("_addDate....", _addDate)
    } else {
        // alert("hourssss")
        let _date = ""
        let _hour = ""
        let _time = ""
        _derivation?.logic?.logicVariables?.map((item: any) => {
            console.log("...76", item)
            if (item.dataType === "date") {
                _date = item.value
            } else if (item.dataType === "real") {
                _hour = item.value
            } else if (item.dataType === "time") {
                _time = item.value
            }
            return null;
        })
        console.log("_date_date_date_date_date", _date)

        if (_date && _hour && _time) {
            _time = application.currentStudy.timeFormat == "12 Hrs" ? dayjs(`1/1/1 ${_time}`).format("HH:MM") : _time
            // _addDate = moment(_date).add((parseInt(_hour) + parseInt(_time)), "h").format(application.currentStudy.dateFormat)
            _addDate = dayjs(_date, application.currentStudy.dateFormat).add(((parseInt(_hour) + moment.duration(_time).asHours())), "hour").format(application.currentStudy.dateFormat)
           
        }
        console.log("else _addDate...", _addDate, (parseInt(_hour) + moment.duration(_time).asHours()))
        // console.log("else _addDate...22",application.currentStudy)
    }
    console.log("...89", _addDate)
    return _addDate
}

export const extractTimeLogic = (_derivation: any) => {
    console.log("extract time logic", _derivation)
    // let application = store.getState().application
    let targetTime: any = '';
    let _time = ""
    let _real = 0;
    _derivation?.logic?.logicVariables?.map((item: any) => {
        console.log("99...", item)
        if (item.dataType === "time") {
            _time = item.value
        } else if (item.dataType === "real") {
            _real = item.value
        }
        if (_time && _real) {
            targetTime = moment(_time, 'h:mm A').add(_real, 'hours').format('LT');
        }
        return null;
    })
    return targetTime;
}

export const extractCustomDerivation = (_derivation: any, _dynamicFormData: any) => {
    // alert("118...")
    // const subjects = store.getState().subjects
    let logicString: any = '';
    // const _subjects = store.getState().subjects;
    if (_derivation?.customDerivationType?.code === 'CUSTOM_DERIVATION_TOTAL_CAPSULES') {
        const _dateValue: any = [];
        _derivation?.dependentTargetVar?.map((item: any) => {
            if (item?.fieldId) {
                _dateValue.push(_dynamicFormData?.data?.find((_dynamicData: any) => _dynamicData?.field?.fieldId === item?.fieldId))
            }
            return null;
        })
        const startDate = moment(_dateValue[0]?.field?.value);
        const endDate = moment(_dateValue[1]?.field?.value);
        const days = Math.abs(startDate.diff(endDate, 'days'));
        //Value
        let _value: any = 0;
        _derivation?.logic?.logicVariables?.map((item: any) => {
            item?.fields?.reduce((total: any, current: any) => {
                _value = parseInt(total.value) + parseInt(current.value)
                return null;
            })
            return null;
        })
        if (days !== 0) {
            logicString = days * _value;
        }
        else {
            logicString = _value;
        }
    }
    else {
        _derivation?.logic?.logicVariables?.map((item: any) => {
            item?.fields?.reduce((total: any, current: any) => {
                logicString = total.value + item.expression + current.value
                return null;
            })
            return null;
        })
    }
    console.log('logicString.......', logicString)
    return eval(logicString)
}


export const extractVariableAutoPopulateValue = (_derivation: any) => {
    let logicValue: any;
    _derivation?.logic?.logicVariables?.map((item: any, itemIndex: any) => {
        console.log("99...", item)
        if (item.value) {
            logicValue = item.value
        }
    })
    return logicValue;
}

export const getLogicCompletedRows = (uniqueGrpRows: any, grpLogicFieldCount: number) => {
    const count: any = {};
    const _rows: any = []
    for (let ele of uniqueGrpRows) {
        if (count[ele]) {
            count[ele] += 1;
        } else {
            count[ele] = 1;
        }
    }

    Object.keys(count).forEach(function (key, index) {
        console.log('map  obj........', key, index)
        if (count[key] == grpLogicFieldCount) {
            _rows.push(parseInt(key))
        }
    });
    console.log('map  obj........22.', uniqueGrpRows, count, _rows)
    return _rows
}

export const extractRowTargetTime = (derivationItem: any, row: any, logicCompletedRows: any) => {

    let targetTime: any = '';
    let _time = ""
    let _real = 0;
    console.log("item....................2222", logicCompletedRows)
    derivationItem?.logic?.logicVariables?.map((item: any) => {
        let getRow = logicCompletedRows.find((_row: any) => _row == row.rowId)
        if (getRow && item.groupId) {
            if (item.dataType === "time") {
                _time = item.value[getRow - 1].value
            } else if (item.dataType === "real") {
                _real = item.value[getRow - 1].value
            }
        } else {
            if (item.dataType === "time") {
                _time = item.value
            } else if (item.dataType === "real") {
                _real = item.value
            }
        }
        if (_time && _real) {
            targetTime = moment(_time, 'h:mm A').add(_real, 'hours').format('LT');
        }
    })
    return targetTime != 'Invalid date' ? targetTime : null
}

export const extractRowTargetDate = (_derivation: any, row: any, logicCompletedRows: any) => {
    const application = store.getState().application
    console.log("extractDateLogic", _derivation)
    let _addDate: any = ''

    if (_derivation?.calcFactor?.code === "DAYS_DATE_CAL") {
        console.log("_derivation 55", _derivation)
        // alert("daysss")
        let _date = ""
        let _int = ""
        _derivation?.logic?.logicVariables?.map((item: any) => {
            console.log("...59", item)

            let getRow = logicCompletedRows.find((_row: any) => _row == row.rowId)
            if (getRow && item.groupId) {
                if (item.dataType === "date") {
                    _date = item.value[getRow - 1].value
                } else if (item.dataType === "integer") {
                    _int = item.value[getRow - 1].value
                }
            } else {
                if (item.dataType === "date") {
                    _date = item.value
                } else if (item.dataType === "integer") {
                    _int = item.value

                }
            }
        })
        if (_date && _int) {
            console.log("68....", _int)
            // _addDate = moment(_date).add(parseInt(_int), 'd').format(application.currentStudy.dateFormat)
            _addDate = dayjs(_date, application.currentStudy.dateFormat).add(parseInt(_int), 'day').format(application.currentStudy.dateFormat)
        }
        console.log("_addDate....", _addDate)
    } else {
        // alert("hourssss")
        let _date = ""
        let _hour = ""
        let _time = ""
        _derivation?.logic?.logicVariables?.map((item: any) => {
            console.log("...76", item)

            let getRow = logicCompletedRows.find((_row: any) => _row == row.rowId)
            if (getRow && item.groupId) {
                if (item.dataType === "date") {
                    _date = item.value[getRow - 1].value
                } else if (item.dataType === "real") {
                    _hour = item.value[getRow - 1].value
                } else if (item.dataType === "time") {
                    _time = item.value[getRow - 1].value
                }
            } else {
                if (item.dataType === "date") {
                    _date = item.value
                } else if (item.dataType === "real") {
                    _hour = item.value
                } else if (item.dataType === "time") {
                    _time = item.value
                }
            }
        })
        console.log("_date_date_date_date_date", _date)

        if (_date && _hour && _time) {
            // _addDate = moment(_date).add((parseInt(_hour) + parseInt(_time)), "h").format(application.currentStudy.dateFormat)
            _addDate = dayjs(_date, application.currentStudy.dateFormat).add(((parseInt(_hour) + moment.duration(_time).asHours())), "hour").format(application.currentStudy.dateFormat)
        }
        console.log("else _addDate...", _addDate)
    }
    console.log("...89", _addDate)
    return _addDate != 'Invalid Date' ? _addDate : null
}