import { toastAlert } from "../../../../../../../actions/actions";
import _ from 'lodash';

export const NonGroupfieldLevelDynamics = (payload: any, fldTarget: any, value: any, dispatch: any, type: string) => {
    const _payload = _.cloneDeep(payload);
    let fldError = false;
    _payload.data.map((data: any, tindex: number) => {
        fldTarget.responseOptions.map((fldField: any) => {
            if (data.field) {
                if (fldField?.targetFields?.find((targetField: any) => targetField?.fieldId === data.field?.fieldId)) {
                    const _value = type === 'radio' ? fldField.responseOption === value :
                        type === 'single-select' ? fldField.responseOption === value :
                            type === 'checkbox' ? value.indexOf(fldField.responseOption) !== -1 :
                                type === 'multiSelect' ? value.indexOf(fldField.responseOption) !== -1 : '';
                    // console.log("33 non-grp....", value, fldField.responseOption, value.indexOf(fldField.responseOption))
                    if (_value) {
                        _payload.data[tindex].field.hide = false;
                    } else {
                        if (_payload.data[tindex].field.value) {
                            fldError = true;
                            payload.data[tindex].field.fldError = fldField.message;
                        } else {
                            _payload.data[tindex].field.hide = true;
                        }
                    }
                }
            } else {
                if (fldField?.targetFields?.find((targetField: any) => targetField?.groupId === data.group?.id)) {
                    const _value = type === 'radio' ? fldField.responseOption === value :
                        type === 'single-select' ? fldField.responseOption === value :
                            type === 'checkbox' ? value.indexOf(fldField.responseOption) !== -1 :
                                type === 'multiSelect' ? value.indexOf((fldField.responseOption)) !== -1 : ''
                    console.log("33....", value, fldField.responseOption, value.indexOf(fldField.responseOption))
                    if (_value) {
                        _payload.data[tindex].group.hide = false;
                    } else {
                        data.group.rows.map((row: any, ri: number) => {
                            row.fields.map((rField: any, rfieldIndex: number) => {
                                if (_payload.data[tindex].group.rows[ri].fields[rfieldIndex].value) {
                                    fldError = true;
                                    payload.data[tindex].group.rows[ri].fields[rfieldIndex].fldError = fldField.message;
                                } else {
                                    payload.data[tindex].group.rows[ri].fields[rfieldIndex].hide = true;
                                }
                                return null;
                            })
                            return null;
                        })
                    }
                }
            }
            return ''
        });
        return ''
    });

    if (fldError) {
        dispatch(toastAlert({
            status: 0,
            message: 'Please delete data',
            open: true
        }));
    }
    return fldError ? null : _payload;
}

export const groupfieldLevelDynamics = (payload: any, fldTarget: any, value: any, dispatch: any, rowIndex: number, type: string) => {
    const _payload = _.cloneDeep(payload);
    let fldError = false;
    _payload.data.map((data: any, tindex: number) => {
        if (fldTarget?.groupId === data.group?.id) {
            data.group.rows.map((rowItem: any) => {
                rowItem.fields.map((fItem: any, fIndex: number) => {
                    fldTarget.responseOptions.map((fldField: any) => {
                        if (fldField?.targetFields?.find((targetField: any) => targetField.fieldId === fItem.fieldId)) {
                            const _value = type === 'radio' ? fldField.responseOption === value :
                                type === 'single-select' ? fldField.responseOption === value :
                                    type === 'checkbox' ? value.indexOf(fldField.responseOption) !== -1 :
                                        type === 'multiSelect' ? value.indexOf(fldField.responseOption) !== -1 : '';
                            if (_value) {
                                _payload.data[tindex].group.rows[rowIndex].fields[fIndex].disable = false;
                            } else {
                                if (_payload.data[tindex].group.rows[rowIndex].fields[fIndex].value) {
                                    fldError = true;
                                    payload.data[tindex].group.rows[rowIndex].fields[fIndex].fldError = fldField.message;
                                } else {
                                    _payload.data[tindex].group.rows[rowIndex].fields[fIndex].disable = true;
                                }
                            }
                        }
                        return ''
                    });
                    return ''
                });
                return ''
            });
        }
        return ''
    });

    if (fldError) {
        dispatch(toastAlert({
            status: 1,
            message: 'Please delete data',
            open: true
        }));
    }
    return fldError ? null : _payload;
}