import React from 'react';
// import CustomDialog from '../../../../../../../../common/modals/CustomeDialog';
// import RemoveRedEyeIcon from '@mui/icons-material/RemoveRedEye';

function ViewQuery(props: any) {
	console.log(props)
	// const [ open, setOPen ] = React.useState(false);
    // const onOpenHandler =()=>{
    //     setOPen(true)
    // }
	// const onCloseHandler = () => {
	// 	setOPen(false);
	// };
	return (
		<React.Fragment>
			<div>
                {/* <button type='button' > <RemoveRedEyeIcon />View Query / Add Query</button> */}
                {/* <div onClick={onOpenHandler} > <RemoveRedEyeIcon />View Query / Add Query</div>
				<CustomDialog
					title={'View Query'}
					open={open}
					// form="resonToChange"
					onClose={onCloseHandler}
					maxWidth="xs"
					fullWidth={true}
					// onSubmitHandler={submitHandler}
					actionType="Submit"
				>
				</CustomDialog> */}
				<p>View Query</p>
			</div>
		</React.Fragment>
	);
}
export default ViewQuery;
