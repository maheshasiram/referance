import React from "react";
import HelpIcon from '@mui/icons-material/Help';
import CustomToolTip from "../../../../../../../components/CustomToolTip";
function InstructionsHelper(props: any) {
    const {title}= props;
    return (
        <div className="d-flex align-items-center" >
            <CustomToolTip title={title} >
                <HelpIcon sx={{fill:'#135e838f', width:'18px'}} />
            </CustomToolTip>
        </div>
    )
}
export default InstructionsHelper