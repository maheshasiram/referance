import { Types } from "../../../reducers/Types";
import { getDerivativeValues, resetDerivation } from "./derivations/derivations";
import { NonGroupfieldLevelDynamics, groupfieldLevelDynamics } from "./fieldLevelDyanmics";
import _ from 'lodash';
// import store from "../../../../../../../store/store";
import { updateDynamicFormData } from "./updateDynamicFormData";


export const onResetValues = async (dynamicFormData: any, value: any, isGroup: any, fldFields: any, dispatch: any, rowIndex: any, index: any, grpFieldIndex: any, setVal: any) => {
    // let payload = _.cloneDeep(dynamicFormData);
    let payload = dynamicFormData;
    let _value: any;
    if (isGroup && payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].datatype.code == "DATA_TYP_PARTIAL_TIME") {
        _value = value
        value = null
    } else if (payload.data[index]?.field?.datatype?.code == "DATA_TYP_PARTIAL_TIME") {
        _value = value
        value = null
    }
    // const subjects = store.getState().subjects
    let _fieldId: any = null
    if (isGroup) {
        if (fldFields) {
            const _fldValidate = groupfieldLevelDynamics(payload, fldFields, value, dispatch, rowIndex, 'radio');
            if (_fldValidate) {
                payload = _fldValidate
                payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].value = value;
                payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].defaultValue = value;
                delete payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].fldError;
            }
            setVal(payload.data[index].group.rows[rowIndex]?.fields[grpFieldIndex]?.value);
            dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload });
        } else {
            payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].value = value;
            payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].defaultValue = value;
            delete payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].fldError;
            _fieldId = payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].fieldId
            setVal(_value ? _value : value);
            updateDynamicFormData(payload);
        }
    } else {
        if (fldFields) {
            const _fldValidate = NonGroupfieldLevelDynamics(payload, fldFields, value, dispatch, 'radio');
            if (_fldValidate) {
                payload = _fldValidate
                payload.data[index].field.value = value;
                payload.data[index].field.defaultValue = value;
                delete payload.data[index].field.fldError;
            }
            setVal(payload.data[index]?.field?.value);
            dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload });
        } else {
            _fieldId = payload.data[index].field.fieldId
            payload.data[index].field.value = value;
            payload.data[index].field.defaultValue = value;
            delete payload.data[index].field.fldError;
            setVal(_value ? _value : value);
            updateDynamicFormData(payload);
        }
    }
    // payload = await getDerivativeValues(derivations, payload, props)
    payload = await resetDerivation(payload, _fieldId, isGroup, fldFields, rowIndex, index, grpFieldIndex);

    // dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload });

}