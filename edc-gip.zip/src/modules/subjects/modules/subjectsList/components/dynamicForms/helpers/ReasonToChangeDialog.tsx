import React, { Fragment } from "react";
import CustomDialog from "../../../../../../../common/modals/CustomeDialog";
import { useDispatch, useSelector } from "react-redux";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { TextareaAutosize } from "@mui/material";
import _ from "lodash";
import { Types } from "../../../reducers/Types";
import { getDynamicFormData, saveFormData } from "../actions/actions";
import PriorityHighIcon from '@mui/icons-material/PriorityHigh';
import { fetchForms } from "../../forms/actions/action";
import { dataEntryNavigation } from "../../../../../../../actions/actions";
// import CustomToolTip from "../../../../../../../components/CustomToolTip";
// import '../styles/styles.scss'

function ReasonToChangeDialog(props: any) {
    const dispatch = useDispatch();
    // const [error, setError] = useState(false);
    const { openReasonDialog, setOpenReasonDialog } = props;
    const { dynamicFormData } = useSelector((state: any) => state.subjects);
     const { page } = useSelector((state: any) => state.application);
    const onCloseHandler = () => {
        setOpenReasonDialog(false)
    }
    const onTextChanged = (rowData: any, value: any) => {
        const payload = _.cloneDeep(dynamicFormData)
        if (!rowData?.groupId) {
            payload.data[rowData?.index].field.comments = value;
        }
        else {
            payload.data[rowData?.index].group.rows[rowData?.rowIndex].fields[rowData?.grpFieldIndex].comments = value;
        }
        dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload })
    }
    // {console.log("35...",error)}
    const textBody = (rowData: any) => {
        return (
            <div className="d-flex justify-content-center align-items-center">
                <TextareaAutosize
                    id={rowData.id}
                    className={/*error &&*/ rowData.comments === '' ? "areaOutline border-danger" : ''}
                    value={rowData.comments}
                    onChange={(e) => onTextChanged(rowData, e.target.value)}
                    placeholder="Please enter reason"
                />
              {/*error && */rowData.comments === '' &&/* <CustomToolTip title='Please enter reason'>*/ <PriorityHighIcon  className="text-danger"/>/*</CustomToolTip>*/}
            </div>
        )
    }

    const variableTextBody = (rowData: any) => {
        return (
            <>{!rowData?.groupId ? <span>{rowData?.variableText} </span> : <span>{rowData?.variableText}({rowData?.rowIndex})</span>}
            </>
        )
    }
    const submitHandler = () => {
        let Validate: any = false;
        _data?.map((reasonChangeItem: any, index: any) => {
            if (!reasonChangeItem?.comments) {
                console.log("50....", reasonChangeItem, _data[index])
                // _data[index].error = true;
                console.log("54...", reasonChangeItem, _data[index])
                Validate = true;
            }
            return null
        })
        if (!Validate) {
            onCloseHandler();
            dispatch(saveFormData(dynamicFormData, (saveResponse: any) => {
                if (saveResponse) {
                    dispatch(getDynamicFormData(page.selectedForm.id, (dynamicFormResponse: any) => { 
                        const payload: any = _.cloneDeep(page);
                        payload.tabs[parseInt(page.currentTab)].data.dynamicFormData = dynamicFormResponse;
                        dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: dynamicFormResponse });
                    }))
                    dispatch(fetchForms(page.currentVisitId, (formsResponse: any) => {
                        const payload: any = _.cloneDeep(page);
                        payload.selectedForm = formsResponse.find((item: any) => item.id === payload.selectedForm.id)
                        payload.tabs[2].data.forms = formsResponse;
                        dispatch(dataEntryNavigation(payload))
                    }))
                }
            }));
        }
        else {
            // setError(true)
        }
    }

    const _data: any = [];
    dynamicFormData?.data?.map((Fields: any, index: any) => {
        if (Fields?.field) {
            if (Fields?.field?.reasonToChange) {
                const _Field: any = _.cloneDeep(Fields?.field)
                _Field.index = index
                _data.push(_Field)
            }
        } else {
            Fields?.group?.rows?.map((rowField: any, rowIndex: any) => {
                rowField?.fields?.map((grpFieldData: any, grpFieldIndex: any) => {
                    if (grpFieldData?.reasonToChange) {
                        const _GrpField: any = _.cloneDeep(grpFieldData)
                        _GrpField.index = index;
                        _GrpField.rowIndex = rowIndex;
                        _GrpField.grpFieldIndex = grpFieldIndex;
                        _data.push(_GrpField)
                    }
                    return null
                })
                return null
            })
        }
        return null
    })

    return (
        <Fragment>
            <CustomDialog
                title={"Reason To Change"}
                onClose={onCloseHandler}
                onSubmitHandler={() => { submitHandler() }}
                open={openReasonDialog}
                form={"reasonToChange"}
                disabled={false}
                onResetHandler={null}
                actionType="Submit"
            >
                <DataTable
                    value={_data}
                    responsiveLayout="scroll"
                    scrollable
                    scrollHeight="250px"
                >
                    <Column body={variableTextBody} header="Variable Text" />
                    <Column body={textBody} header="Reason for Change" />
                </DataTable>
            </CustomDialog>
        </Fragment>
    )
}

export default ReasonToChangeDialog;