import React from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { useSelector } from 'react-redux';
// import { findBySubjectFieldId } from '../../actions/actions';
// import CustomDialog from '../../../../../../../../common/modals/CustomeDialog';
// import RemoveRedEyeIcon from '@mui/icons-material/RemoveRedEye';
// import FolderOpenIcon from '@mui/icons-material/FolderOpen';

function AuditHistory(props: any) {

	const {auditLogDetails} = useSelector((state:any)=>state.subjects)
	console.log('14......audit',auditLogDetails)

	console.log(props)
	// const auditDetails = [
	// 	{ field: 'Variable data value updated', header: 'Audit Event', rfc: 'qwert', dts: "30-May-2023 03:33:43 ", username: "mbhukya", variableID: 'BMI', oldValue: '4', newValue: '6' },
	// 	{ field: 'Variable data value updated', header: 'Audit Event', rfc: '', dts: "30-May-2023 03:26:16 ", username: "mbhukya", variableID: 'BMI', oldValue: '0', newValue: '4' },
	// 	{ field: 'Variable data value updated', header: 'Audit Event', rfc: 'Initial Values', dts: "09-Jan-2023 12:51:26 ", username: "mbhukya", variableID: 'BMI', oldValue: '', newValue: '0' },

	// ];
	// const [ open, setOPen ] = React.useState(false);
	// const onOpenHandler =()=>{
	//     setOPen(true)
	// }
	// const onCloseHandler = () => {
	// 	setOPen(false);
	// };
	return (
		<React.Fragment>
			<div className='mt-3 mb-3'>
				<DataTable scrollable value={auditLogDetails}>
					<Column field="comments" header="Reason for change" ></Column>
					<Column field="updatedOn" header="Date/Time of Server" ></Column>
					<Column field="userDetailsDto.userName" header="User Name"></Column>
					<Column field="variableID" header="Variable ID"></Column>
					<Column field="oldValue" header="Old values"></Column>
					<Column field="newValue" header="New values"></Column>
				</DataTable>
			</div>
			{/* <div onClick={onOpenHandler} > <FolderOpenIcon />Audit History</div>
				<CustomDialog
					title={'Audit History'}
					open={open}
					// form=""
					onClose={onCloseHandler}
					maxWidth="xs"
					fullWidth={true}
					// onSubmitHandler={submitHandler}
					actionType="Submit"
				>
				
				</CustomDialog> */}
		</React.Fragment>
	);
}
export default AuditHistory;
