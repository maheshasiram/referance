import { Loader } from '../../../../../../../actions/actions';
import { subjects } from '../../../../../../../configs/enivornment/subjects';
// import { Types as commonTypes } from '../../../../../../../constants/Types';
import { fetch } from '../../../../../../../constants/fetch';
import { Types } from '../../../reducers/Types';
import store from '../../../../../../../store/store';
import { Types as Type } from '../../../../../../../constants/Types'

const _configCodes: any = store.getState().application.configCodes;

export const getFormsDetailsId: any = (payload: any, callback: any) => {
	return () => {
		// dispatch(Loader(true));
		const url = `${subjects.dataEntry.getFormsDetailsId}/${payload.siteId}/${payload.formId}`;
		fetch({
			method: 'GET',
			url: url,
			data: ''
		}).then((response: any) => {
			if (callback) {
				callback(response.data);
			}
			// dispatch(Loader(false));
		});
	};
};

export const getRulesByFieldId: any = (payload: any, callback: any) => {
	return (dispatch: any) => {
		dispatch(Loader(true));
		const url = `${subjects.dataEntry.executeRule}/${payload.subjectFormId}/${payload.fieldId}?dryRun=${payload.dryRun}`;
		fetch({
			method: 'GET',
			url: url,
			data: ''
		}).then((response: any) => {
			if (callback) {
				callback(response.data);
			}
			dispatch(Loader(false));
		});
	};
};

export const fetchReasonsToClose: any = () => {
	return (dispatch: any) => {
		dispatch(Loader(true));
		const url = `${subjects.dataEntry.fetchResolutionType}`
		fetch({
			method: 'GET',
			url: url,
			data: ''
		})
			.then((response: any) => {
				dispatch({ type: Type.GET_REASON_TO_CLOSE, payload: response.data });
				dispatch(Loader(false));
			})
	}
}

//form data with fields in data entry
export const getDynamicFormData: any = (formId: any, callback: any) => {
	const url = `${subjects.dataEntry.getDynamicFormData}/${formId}`
	return (dispatch: any) => {
		dispatch(Loader(true));
		fetch({
			method: 'GET',
			url: url,
			data: ''
		}).then((response: any) => {
			console.log(response, "311.....")
			if (response.data) {
				response.data?.data?.map((item: any) => {
					if (item.field) {
						item.field.errorMsg = '';
						item.field.comments = null;
						const fieldValue = item.field.value
						item.field.value ? item.field.value = fieldValue : item.field.value = null;
					} else if (item.group) {
						item.group.rows.map((row: any) => {
							row.isActive = true
							row.fields.map((grpItem: any) => {
								grpItem.errorMsg = '';
								grpItem.comments = null;
								return null
							});
							return null
						});
					}
					return null
				});
				response.data.validate = true
				dispatch({ type: Types.ENTRY_FORM_DATA, payload: response.data });
				dispatch(Loader(false));
			}
			if (callback) {
				callback(response.data)
			}
		})
			.catch(err => {
				
				console.log("...err", err)
			})

	}
}


// save form

export const saveFormData: any = (payload: any, callback: any) => {
	return (dispatch: any) => {
		dispatch(Loader(true));
		const url = `${subjects.dataEntry.saveFormData}`
		fetch({
			method: 'POST',
			url: url,
			data: payload
		})
			.then((response: any) => {
				if (callback) {
					callback(response.data)
				}
				dispatch(Loader(false));
			})
			.catch(err => {
				console.log("...err", err)
			})

	}
}

// get field level dynamics
export const getFieldLevelDynamics: any = (payload: any, callback: any) => {
	return (dispatch: any) => {
		dispatch(Loader(true));
		const url = `${subjects.dataEntry.getFieldLevelDynamics}/visit/${payload.visitId}/form/${payload.formId}`;
		fetch({
			method: 'GET',
			url: url,
			data: ''
		}).then((response: any) => {
			if (response.data.length > 0) {
				dispatch({ type: Types.GET_FIELD_LEVEL_DYNAMICS, payload: response.data });
			}
			if (callback) {
				callback(response.data);
			}
			dispatch(Loader(false));
		})
			.catch(err => { console.log("err", err) })
	};
};


// derivations
export const getDerivations: any = (payload: any, callback: any) => {
	return (dispatch: any) => {
		dispatch(Loader(true));
		const url = `${subjects.dataEntry.getDerivations}?formIds=${payload.formId}&visitIds=${payload.visitId}`;
		fetch({
			method: 'GET',
			url: url,
			data: ''
		}).then(async (response: any) => {
			if (response.data.length > 0) {
				const subjectId = (JSON.parse(sessionStorage.page)).selectedSubject?.id
				await response.data.map(async (item: any, index: number) => {
					const _logic = item.logic && JSON.parse(item.logic)
					const _dependentTargetVar = item.dependentTargetVar && JSON.parse(item.dependentTargetVar)
					item.logic = _logic
					item.dependentTargetVar = _dependentTargetVar
					console.log('logic.........', _logic, item.actionType)
					if (item.actionType?.code === _configCodes?.NumericCalculation || item.actionType?.code === _configCodes?.CustomDerivation) {

						await _logic.logicVariables?.map(async (element: any, elementIndex: any) => {
							if ((_logic.formula.formulaCode === "AGE") || (_logic.formula.formulaCode === "BMI")) {
								if (_logic.formula.formulaCode === "BMI") {
									await element.denominatorFields.map(async (ele: any) => {
										await dispatch(fetchFieldValue(subjectId, _logic.visitId, ele.formId, ele.fieldId, (_response: any) => {
											ele.value = _response.data[0]?.value
										}))
									})
								}
								await element.numeratorFields.map(async (ele: any, eleIndex: number) => {
									await dispatch(fetchFieldValue(subjectId, _logic.visitId, ele.formId, ele.fieldId, (_response: any) => {
										ele.value = _response.data[0]?.value
										if ((response.data.length - 1 === index) && (_logic.logicVariables.length - 1 === elementIndex) && (element.numeratorFields.length - 1 === eleIndex)) {
											dispatch({ type: Types.GET_DERIVATIONS, payload: response.data });
										}
									}))
								})
							} else {
								await element && element.fields.map(async (ele: any, eleIndex: number) => {
									// console.log('_logic')
									await dispatch(fetchFieldValue(subjectId, _logic.visitId, ele.formId, ele.fieldId, (_response: any) => {
										if ((item.actionType?.code === _configCodes?.CustomDerivation) && (ele.formId != payload.formId)) {
											const _findResponse = ele?.responseOptions.find((resEle: any) => resEle.response === _response.data[0]?.value)
											ele.value = _findResponse ? _findResponse.value : null
										} else {
											ele.value = _response.data[0]?.value
										}
										if ((response.data.length - 1 === index) && (_logic.logicVariables.length - 1 === elementIndex) && (element.fields.length - 1 === eleIndex)) {
											dispatch({ type: Types.GET_DERIVATIONS, payload: response.data });
										}
									}))
								})
							}
						})
					} else {
						console.log('test......else....')
						await _logic.logicVariables?.map(async (element: any, elementIndex: any) => {

							await dispatch(fetchFieldValue(subjectId, _logic.visitId, element.formId, element.fieldId, (_response: any) => {
								if (element.groupId) {
									element.value = _response.data
								} else {
									element.value = _response.data[0]?.value
								}

								if ((response.data.length - 1 === index) && (_logic.logicVariables.length - 1 === elementIndex)) {
									dispatch({ type: Types.GET_DERIVATIONS, payload: response.data });
								}
							}))
						})
					}
				})

				console.warn('response of derivation......', response);

				// dispatch({ type: Types.GET_DERIVATIONS, payload: response.data });
			}
			dispatch({ type: Types.FETCH_DERIVATIONS, payload: response.data });
			if (callback) {
				callback(response.data);
			}
			dispatch(Loader(false));
		})
			.catch(err => {
				if (callback) {
					callback(err.response.data);
				}
				console.log("err.......", err)
			})
	};
};
//create protocol deviation
export const addProtocolDeviation: any = (payload: any, callback: any) => {
	const url = `${subjects.dataEntry.createProtocoDeviations}`
	return function (dispatch: any) {
		dispatch(Loader(true))
		fetch({
			method: 'POST',
			url: url,
			data: payload
		})
			.then((response: any) => {
				if (callback) {
					callback(response.data)
					dispatch(Loader(false))
				}
			})
	}
}

// fetch all protocol deviation records
export const fetchProtocolDeviations: any = (payload: any, callback: any) => {
	return (dispatch: any) => {
		dispatch(Loader(true));
		const url = `${subjects.dataEntry.getProtocolDeviations}?subjectFieldDataId=${payload}`
		fetch({
			method: 'GET',
			url: url,
			data: ''
		})
			.then((response: any) => {
				console.log("...268", response)
				// if (callback) {
				dispatch({ type: Types.GET_ALL_PROTOCOL_DEVIATION, payload: response.data });
				// 	callback(response.data)
				// }
				dispatch(Loader(false));
			})
	}
}

// delete restore protocol deviation 
export const deleteRestoreDeviation: any = (payload: any, callback: any) => {
	const url = `${subjects.dataEntry.updateStatus}?protocolDeviationId=${payload.protocolDeviationId}&status=${payload.status}`
	return function (dispatch: any) {
		dispatch(Loader(true))
		fetch({
			method: 'POST',
			url: url,
			data: ''
		})
			.then((response: any) => {
				if (callback) {
					callback(response.data)
					dispatch(Loader(false))
				}
			})
	}
}

// add query
export const CreateQueryies: any = (payload: any, callback: any) => {
	const url = `${subjects.dataEntry.createQuery}`
	return function (dispatch: any) {
		dispatch(Loader(true))
		fetch({
			method: 'POST',
			url: url,
			data: payload
		})
			.then((response: any) => {
				if (callback) {
					callback(response.data)
					dispatch(Loader(false))
				}
			})
	}
}

//update query
export const updateQuery: any = (payload: any, callback: any) => {
	const url = `${subjects.dataEntry.updateQuery}`
	return function (dispatch: any) {
		dispatch(Loader(true));
		fetch({
			method: 'POST',
			url: url,
			data: payload,
		})
			.then((response: any) => {
				if (callback) { callback(response) }
				dispatch(Loader(false));
			})
	}
}

// view query
export const fetchViewQueryData: any = (payload: any, callback: any) => {
	return (dispatch: any) => {
		dispatch(Loader(true));
		const url = `${subjects.dataEntry.viewQuery}/${payload}`;
		fetch({
			method: 'GET',
			url: url,
			data: ''
		}).then((response: any) => {
			if (callback) {
				callback(response);
			}
			dispatch(Loader(false));
		})
			.catch(err => { console.log("errors", err) })
	};
}

export const dteNoteRequest: any = (payload: any, callback: any) => {
	return (dispatch: any) => {
		dispatch(Loader(true));
		const url = `${subjects.dataEntry.dteNoteRequest}`
		fetch({
			method: 'POST',
			url: url,
			data: payload
		})
			.then((response: any) => {
				if (callback) {
					callback(response.data)
				}
				dispatch(Loader(false));
			})
			.catch(err => {
				console.log("...err", err)
			})

	}
}

export const upadteNoteTransaction: any = (payload: any, callback: any) => {
	return (dispatch: any) => {
		dispatch(Loader(true));
		const url = `${subjects.dataEntry.upadteNoteTransaction}`
		fetch({
			method: 'POST',
			url: url,
			data: payload
		})
			.then((response: any) => {
				if (callback) {
					callback(response.data)
				}
				dispatch(Loader(false));
			})
			.catch(err => {
				console.log("...err", err)
			})

	}
}

export const getdteNoteRequest: any = (payload: any, callback: any) => {
	return (dispatch: any) => {
		dispatch(Loader(true));
		const url = `${subjects.dataEntry.getdteNoteRequest}?userId=${payload.userId}&fieldId=${payload.fieldId}&formId=${payload.formId}&visitId=${payload.visitId}&subjectId=${payload.subjectId}`;
		fetch({
			method: 'GET',
			url: url,
			data: ''
		}).then((response: any) => {
			if (callback) {
				callback(response.data);
			}
			dispatch(Loader(false));
		});
	};
};


// Audit log subject field id

export const findBySubjectFieldId: any = (payload: any, callback: any) => {
	return (dispatch: any) => {
		dispatch(Loader(true));
		const url = `${subjects.dataEntry.findBySubjectFieldId}/${payload}`
		fetch({
			method: 'GET',
			url: url,
			data: '',
		}).then((response: any) => {
			console.log('resp...', response)
			if (callback) { callback(response) }
			dispatch(Loader(false));
		}).catch((error: any) => {
			console.log('error..', error)
			dispatch(Loader(false));
		})
	}
}

// fetch field value for Derivations
export const fetchFieldValue: any = (subjectId: number, visitId: number, formId: number, fieldId: number, callback: any) => {
	const url = `${subjects.dataEntry.fetchValue}/subject/${subjectId}/visit/${visitId}/form/${formId}/field/${fieldId}`
	return function (dispatch: any) {
		// dispatch(Loader(true));
		fetch({
			method: 'GET',
			url: url,
			data: '',
		})
			.then((response: any) => {
				if (response?.data?.length <= 0) {
					response.data = [
						{
							"fieldId": fieldId,
							"value": null,
							"rowId": null
						}
					]
				}
				if (callback) { callback(response) }
				dispatch(Loader(false));
			})
	}
}

// set subject field value action 
export const setSubjectFieldValue: any = (payload: any, index: number, data: any, rowIndex: any, grpFieldIndex: any) => {
	let _data: any
	if (payload.data[index].field) {
		_data = data.subjectFieldId = payload.data[index].field.id
	} else if (payload.data[index].group) {
		_data = data.subjectFieldId = payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].id;
	}
	return _data
}