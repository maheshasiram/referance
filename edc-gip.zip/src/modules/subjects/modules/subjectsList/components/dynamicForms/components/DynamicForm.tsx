import React, { useEffect, useMemo, useState } from "react";
import KeyboardDoubleArrowRightIcon from '@mui/icons-material/KeyboardDoubleArrowRight';
import { useDispatch, useSelector } from "react-redux";
import _ from "lodash";
import { dynamicFields } from "../helpers/dynamicFields";
import { FieldNote, HeaderLabel, NonGroupFieldContainer } from "../styles/stylesComponents";
import HighlightOffIcon from '@mui/icons-material/HighlightOff';
import CustomToolTip from "../../../../../../../components/CustomToolTip";
import { Types } from "../../../reducers/Types";
import ReplayIcon from '@mui/icons-material/Replay';
import { getDerivations, getDynamicFormData, saveFormData } from "../actions/actions";
import { fetchByMappingForm, fetchForms, findSubjectFormsByUnscheduledVisitId } from "../../forms/actions/action";
import { Loader, dataEntryNavigation } from "../../../../../../../actions/actions";
// import { saveFormData } from "../actions/actions";
import ReasonToChangeDialog from "../helpers/ReasonToChangeDialog";
import SkipPreviousRoundedIcon from '@mui/icons-material/SkipPreviousRounded';
import SkipNextRoundedIcon from '@mui/icons-material/SkipNextRounded';
import { getDerivativeValues } from "../helpers/derivations/derivations";
import { changeableProperties, updateDynamicFormData } from "../helpers/updateDynamicFormData";
import TextArea from "../fields/TextArea";
import SingleSelect from "../fields/SingleSelect";
import RadioField from "../fields/RadioField";
import MultiSelect from "../fields/MultiSelect";
import CheckBox from "../fields/CheckBox";
import FileUpload from "../fields/FileUpload";
import Textfield from "../fields/TextField";
import Real from "../fields/Real";
import Integer from "../fields/Integer";
import DateField from "../fields/DateField";
import TimeField from "../fields/TimeField";
import PartialDate from "../fields/PartialDate";
import PartialTime from "../fields/PartialTime";
// import ReasonToChangeDialog from "../helpers/ReasonToChangeDialog";
// import { saveFormData } from "../actions/actions";

function DynamicForm(props: any) {
    const [openReasonDialog, setOpenReasonDialog] = useState(false);
    const { setExpandForms, expandForms } = props;
    const { page } = useSelector((state: any) => state.application);
    const { dynamicFormData, fieldleveldynamics, dynamicFormSaveType } = useSelector((state: any) => state.subjects);
    const { configCodes } = useSelector((state: any) => state.application);
    const dispatch = useDispatch();

    const onCollapseFormsList = () => {
        setExpandForms(!expandForms)
    }

    const onAddRowHandler = (element: any, index: number) => {
        if (element.group && (element.group.rows?.length < element.group.repeatMax)) {
            const payload = updateDynamicFormData(null);
            const _row = payload.data[index].group.rows.find((item: any) => item)
            const groupRow = _.cloneDeep(_row)
            groupRow.rowId = payload.data[index].group.rows.length + 1
            _row?.fields?.map((item: any, _index: number) => {
                groupRow.fields[_index].value = ''
                groupRow.fields[_index].defaultValue = ''
                groupRow.fields[_index].errorMsgs = ''
                return null
            });
            payload.data[index].group.rows.push({ ...groupRow, static: true, isActive: true });
            dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: _.cloneDeep(payload) })
        }
    }
    const onDeleteRowHandler = (element: any, index: number, row: any, rowIndex: number) => {
        const payload = updateDynamicFormData(null)
        if (row.static) {
            payload.data[index].group.rows.splice(rowIndex, 1)
        } else {
            payload.data[index].group.rows[rowIndex].isActive = false
        }
        dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload })
    }

    const onRestoreRowHandler = (element: any, index: number, row: any, rowIndex: number) => {
        const payload = updateDynamicFormData(null)
        payload.data[index].group.rows[rowIndex].isActive = true;
        dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload });
    }

    const renderDynamicForm: any = useMemo(() => {
        if (dynamicFormData) {
            const { data } = dynamicFormData;
            updateDynamicFormData(dynamicFormData);
            return (
                _.map(data, (element: any, index: number) => {
                    if (element.field && element.field !== undefined && element.field.status && !element.field.hide) {
                        const fldFields = fieldleveldynamics?.find((fldFields: any) => fldFields?.fieldId === element?.field?.fieldId);
                        const dynamicField = element?.field?.responseType?.code === dynamicFields?.RES_TYP_TEXT ? element?.field?.datatype?.code : element?.field?.responseType?.code

                        switch (dynamicField) {
                            case configCodes?.textarea:
                                return <NonGroupFieldContainer><TextArea key={index} {...element?.field} index={index} fldFields={fldFields} isGroup={false} /></NonGroupFieldContainer>
                            case configCodes?.['single-select']:
                                return <NonGroupFieldContainer><SingleSelect key={index} {...element?.field} index={index} fldFields={fldFields} isGroup={false} /></NonGroupFieldContainer>
                            case configCodes?.radio:
                                return <NonGroupFieldContainer><RadioField key={index} {...element?.field} index={index} fldFields={fldFields} isGroup={false} /></NonGroupFieldContainer>
                            case configCodes?.['multi-select']:
                                return <NonGroupFieldContainer><MultiSelect key={index} {...element?.field} index={index} fldFields={fldFields} isGroup={false} /></NonGroupFieldContainer>
                            case configCodes?.checkbox:
                                return <NonGroupFieldContainer><CheckBox key={index} {...element?.field} index={index} fldFields={fldFields} isGroup={false} /></NonGroupFieldContainer>
                            case "RES_TYP_FILE":
                                return <NonGroupFieldContainer><FileUpload key={index} {...element?.field} index={index} fldFields={fldFields} isGroup={false} /></NonGroupFieldContainer>
                            case configCodes?.string:
                                return <NonGroupFieldContainer><Textfield key={index} {...element?.field} index={index} fldFields={fldFields} isGroup={false} /></NonGroupFieldContainer>
                            case configCodes?.integer:
                                return <NonGroupFieldContainer><Integer key={index} {...element?.field} index={index} fldFields={fldFields} isGroup={false} /></NonGroupFieldContainer>
                            case configCodes?.real:
                                return <NonGroupFieldContainer><Real key={index} {...element?.field} index={index} fldFields={fldFields} isGroup={false} /></NonGroupFieldContainer>
                            case configCodes?.date:
                                return <NonGroupFieldContainer><DateField key={index} {...element?.field} index={index} fldFields={fldFields} isGroup={false} /></NonGroupFieldContainer>
                            case configCodes?.time:
                                return <NonGroupFieldContainer><TimeField key={index} {...element?.field} index={index} fldFields={fldFields} isGroup={false} /></NonGroupFieldContainer>
                            case configCodes?.partialdate:
                                return <NonGroupFieldContainer> <PartialDate key={index} {...element?.field} index={index} fldFields={fldFields} isGroup={false} /> </NonGroupFieldContainer>
                            case configCodes?.PartialTime:
                                return <NonGroupFieldContainer> <PartialTime key={index} {...element?.field} index={index} fldFields={fldFields} isGroup={false} /> </NonGroupFieldContainer>
                        }
                        // return(
                        //     <NonGroupFieldContainer>
                        //       {
                        //         switch(dynamicField){
                        //             case "RES_TYP_TEXT":
                        //                 return 
                        //         }
                        //       }
                        //     </NonGroupFieldContainer>
                        // )
                        //  <NonGroupFieldContainer>

                        {/* {Component && <Component key={index} {...element?.field} index={index} fldFields={fldFields} isGroup={false} />} */ }
                        // </NonGroupFieldContainer>
                    } else {
                        if (element?.group && element?.group !== undefined && element?.group?.status && !element?.group?.hide) {
                            return <React.Fragment>
                                <div className="group-main-component">
                                    <div key={index} className="group-component">
                                        {((element?.group?.header) && (element?.group?.header !== '' || element?.group?.name)) &&
                                            <HeaderLabel><b>{element?.group?.name}</b> : {element?.group?.header}</HeaderLabel>
                                        }
                                        {element.group.rows.length > 0 ? <div className="group-container">
                                            <div className="group-header-container">
                                                <div className="header-items" >
                                                    <span>S No.</span>
                                                </div>
                                                {
                                                    element?.group?.rows[0]?.fields.map((i: any, _index: number) => (
                                                        <div className="header-items" key={_index} >
                                                            <span> {i?.questionNumber} </span>
                                                            <span> {i?.variableText} </span>
                                                        </div>
                                                    ))
                                                }
                                                <div className="header-items"></div>
                                            </div>
                                            {element?.group?.rows?.map((row: any, rowIndex: number) =>
                                                <div key={rowIndex} className="row-item">
                                                    <div className="group-field-container">
                                                        <span className="px-2" >{rowIndex + 1}</span>
                                                    </div>
                                                    {row?.fields?.map((grpField: any, grpFieldIndex: number) => {

                                                        if (grpField && grpField.status) {
                                                            const dynamicField = grpField?.responseType?.code === dynamicFields?.RES_TYP_TEXT ? grpField.datatype.code : grpField.responseType.code;
                                                            const fldFields = fieldleveldynamics?.find((fldFields: any) => fldFields?.fieldId === grpField?.fieldId);
                                                            // const Component = dynamicFields[dynamicField]
                                                            switch (dynamicField) {
                                                                case configCodes?.textarea:
                                                                    return <div key={grpFieldIndex} className="group-field-container">
                                                                        <TextArea {...grpField} index={index} fldFields={fldFields} rowIndex={rowIndex} grpFieldIndex={grpFieldIndex} isGroup={true} />
                                                                    </div>
                                                                case configCodes?.['single-select']:
                                                                    return <div key={grpFieldIndex} className="group-field-container">
                                                                        <SingleSelect {...grpField} index={index} fldFields={fldFields} rowIndex={rowIndex} grpFieldIndex={grpFieldIndex} isGroup={true} />
                                                                    </div>
                                                                case configCodes?.radio:
                                                                    return <div key={grpFieldIndex} className="group-field-container">
                                                                        <RadioField  {...grpField} index={index} fldFields={fldFields} rowIndex={rowIndex} grpFieldIndex={grpFieldIndex} isGroup={true} />
                                                                    </div>
                                                                case configCodes?.['multi-select']:
                                                                    return <div key={grpFieldIndex} className="group-field-container">
                                                                        <MultiSelect  {...grpField} index={index} fldFields={fldFields} rowIndex={rowIndex} grpFieldIndex={grpFieldIndex} isGroup={true} />
                                                                    </div>
                                                                case configCodes?.checkbox:
                                                                    return <div key={grpFieldIndex} className="group-field-container">
                                                                        <CheckBox   {...grpField} index={index} fldFields={fldFields} rowIndex={rowIndex} grpFieldIndex={grpFieldIndex} isGroup={true} />
                                                                    </div>
                                                                case "RES_TYP_FILE":
                                                                    return <div key={grpFieldIndex} className="group-field-container">
                                                                        <FileUpload  {...grpField} index={index} fldFields={fldFields} rowIndex={rowIndex} grpFieldIndex={grpFieldIndex} isGroup={true} />
                                                                    </div>
                                                                case configCodes?.string:
                                                                    return <div key={grpFieldIndex} className="group-field-container">
                                                                        <Textfield  {...grpField} index={index} fldFields={fldFields} rowIndex={rowIndex} grpFieldIndex={grpFieldIndex} isGroup={true} />
                                                                    </div>
                                                                case configCodes?.integer:
                                                                    return <div key={grpFieldIndex} className="group-field-container">
                                                                        <Integer  {...grpField} index={index} fldFields={fldFields} rowIndex={rowIndex} grpFieldIndex={grpFieldIndex} isGroup={true} />
                                                                    </div>
                                                                case configCodes?.real:
                                                                    return <div key={grpFieldIndex} className="group-field-container">
                                                                        <Real  {...grpField} index={index} fldFields={fldFields} rowIndex={rowIndex} grpFieldIndex={grpFieldIndex} isGroup={true} />
                                                                    </div>
                                                                case configCodes?.date:
                                                                    return <div key={grpFieldIndex} className="group-field-container">
                                                                        <DateField  {...grpField} index={index} fldFields={fldFields} rowIndex={rowIndex} grpFieldIndex={grpFieldIndex} isGroup={true} />
                                                                    </div>
                                                                case configCodes?.time:
                                                                    return <div key={grpFieldIndex} className="group-field-container">
                                                                        <TimeField  {...grpField} index={index} fldFields={fldFields} rowIndex={rowIndex} grpFieldIndex={grpFieldIndex} isGroup={true} />
                                                                    </div>
                                                                case configCodes?.partialdate:
                                                                    return <div key={grpFieldIndex} className="group-field-container">
                                                                        <PartialDate {...grpField} index={index} fldFields={fldFields} rowIndex={rowIndex} grpFieldIndex={grpFieldIndex} isGroup={true} />
                                                                    </div>
                                                                case configCodes?.PartialTime:
                                                                    return <div key={grpFieldIndex} className="group-field-container">
                                                                        <PartialTime  {...grpField} index={index} fldFields={fldFields} rowIndex={rowIndex} grpFieldIndex={grpFieldIndex} isGroup={true} />
                                                                    </div>
                                                            }
                                                            // return <div key={grpFieldIndex} className="group-field-container">
                                                            //     {Component && <Component
                                                            //         {...grpField}
                                                            //         index={index}
                                                            //         fldFields={fldFields}
                                                            //         rowIndex={rowIndex}
                                                            //         grpFieldIndex={grpFieldIndex}
                                                            //         isGroup={true}
                                                            //     />}
                                                            // </div>
                                                        }
                                                        return null
                                                    })}
                                                    <div className="group-field-container" >
                                                        {
                                                            (row.isActive) ?
                                                                <HighlightOffIcon sx={{ fill: '#ff674b' }}
                                                                    onClick={() => onDeleteRowHandler(element, index, row, rowIndex)} /> :
                                                                <ReplayIcon onClick={() => onRestoreRowHandler(element, index, row, rowIndex)} />
                                                        }
                                                    </div>
                                                </div>
                                            )}
                                        </div> : <div>No Rows are available</div>}
                                    </div>
                                    {(element?.group?.rows?.length < element?.group?.repeatMax) && <div className="w-100 d-flex justify-content-end text-right p-1 addRowButtonDiv">
                                        <span className="rowsInfo mx-2"> More <b>{element?.group?.repeatMax - element?.group?.rows?.length}</b> rows can be added</span>
                                        <button className="btn btn-success btn-sm"
                                            onClick={() => onAddRowHandler(element, index)}> Add Row</button>
                                    </div>}
                                    {element?.group?.note && element?.group?.note !== '' && <FieldNote>
                                        {element?.group?.note}
                                    </FieldNote>}
                                </div>
                            </React.Fragment>
                        }
                    }
                })
            )
        }

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [dynamicFormData, fieldleveldynamics]);

    const refreshDynamicFormData = (response: any) => {
        const payload: any = _.cloneDeep(page);
        payload.tabs[parseInt(page.currentTab)].data.dynamicFormData = response;
        dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: response });
    }

    const onPreviousFormHandler = async () => {
        const _forms = page.tabs[2].data.forms
        let prevForm: any;
        if (!(page.selectedForm?.unscheduledParentId)) {
            // finding index of the current form in the forms list
            const _formIndex = _forms.findIndex((item: any) => item.id === page.selectedForm.id)
            // assigning the previous form to a dup variable for checking
            const _prevForm = _forms[_formIndex - 1]
            // checking whether previous form is repeating 
            if (_prevForm.repeat) {
                // if previous form having children, making the last form in child as previous form 
                if (_prevForm?.childForms && _prevForm.childForms?.length > 0) {
                    prevForm = _prevForm.childForms[_prevForm.childForms.length - 1]
                } else {
                    const _reversedList = _.cloneDeep(_forms.slice(0, _formIndex)).reverse()
                    const _skippedPrevForm = await _reversedList.find((form: any) => {
                        if (form && form.repeat && form.childForms && form.childForms.length > 0) {
                            return form.childForms[form.childForms.length - 1]
                        } else if (!form.repeat) {
                            return form
                        }
                        return null;
                    })
                    prevForm = _skippedPrevForm.childForms ? _skippedPrevForm.childForms[0] : _skippedPrevForm
                }
            } else {
                prevForm = _forms[_formIndex - 1]
            }
        } else {
            const _formIndex = _forms.findIndex((item: any) => item.id === page.selectedForm.unscheduledParentId)  // finding index of the current form in the forms list
            const repeatingForm = _forms[_formIndex]
            const currentChildIndex = repeatingForm.childForms.findIndex((i: any) => i.id === parseInt(page.selectedForm.id))
            if (currentChildIndex !== 0) {
                prevForm = repeatingForm.childForms[currentChildIndex - 1]
            } else {
                const _reversedList = _.cloneDeep(_forms.slice(0, _formIndex)).reverse()
                const _skippedPrevForm = await _reversedList.find((form: any) => {
                    if (form && form.repeat && form.childForms && form.childForms.length > 0) {
                        return form.childForms[form.childForms.length - 1]
                    } else if (!form.repeat) {
                        return form
                    }
                    return null;
                })
                // prevForm = _skippedPrevForm
                prevForm = _skippedPrevForm.childForms ? _skippedPrevForm.childForms[0] : _skippedPrevForm
            }
        }
        if (prevForm) {
            getNextPrevFormData(prevForm)
        }
    }
    const onNextFormHandler = async () => {
        const _forms = page.tabs[2].data.forms
        let nextForm: any;
        if (!(page.selectedForm?.unscheduledParentId)) {
            const _formIndex = _forms.findIndex((item: any) => item.id === page.selectedForm.id)
            const _nextForm = _forms[_formIndex + 1]
            if (_nextForm.repeat) {
                if (_nextForm?.childForms && _nextForm.childForms?.length > 0) {
                    nextForm = _nextForm.childForms[0]
                } else {
                    const _sliceList = _.cloneDeep(_forms.slice(_formIndex + 1))
                    const _skippedNextForm = await _sliceList.find((form: any) => (form && form.repeat && form.childForms && form.childForms.length > 0) || (!form.repeat))
                    nextForm = _skippedNextForm.childForms ? _skippedNextForm.childForms[0] : _skippedNextForm
                }
            } else {
                nextForm = _forms[_formIndex + 1]
            }
        } else {
            const _formIndex = _forms.findIndex((item: any) => item.id === page.selectedForm.unscheduledParentId)  // finding index of the current form in the forms list
            const repeatingForm = _forms[_formIndex]
            const currentChildIndex = repeatingForm.childForms.findIndex((i: any) => i.id === page.selectedForm.id)
            if (currentChildIndex !== repeatingForm.childForms.length - 1) {
                nextForm = repeatingForm.childForms[currentChildIndex + 1]
            } else {
                const _sliceList = _.cloneDeep(_forms.slice(_formIndex + 1))
                const _skippedNextForm = await _sliceList.find((form: any) => (form && form.repeat && form.childForms && form.childForms.length > 0) || (!form.repeat))
                nextForm = _skippedNextForm.childForms ? _skippedNextForm.childForms[0] : _skippedNextForm
            }
        }
        if (nextForm) {
            getNextPrevFormData(nextForm)
        }
    }
    const getNextPrevFormData = (form: any) => {
        const payload = _.cloneDeep(page)
        if (!form.id) {
            dispatch(fetchByMappingForm({ subjectVisitId: page.currentVisitId, formId: form.formId }, (response: any) => {
                payload.selectedForm = response;
                form = response
                dispatch((page.selectedVisit.visit.visitRepeat ? findSubjectFormsByUnscheduledVisitId : fetchForms)(page.selectedVisit.id, (response: any) => {
                    payload.tabs[parseInt(page.currentTab) - 1].data.forms = response;
                    dispatch(getDynamicFormData(form.id, (_response: any) => {
                        if (_response) {
                            // payload.tabs[parseInt(page.currentTab)].data.dynamicFormData = _response;
                            // payload.tabs[parseInt(page.currentTab)].label = _response.formName;
                            // dispatch(dataEntryNavigation(payload))
                            // dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: _response })
                            const _payload = {
                                siteId: page.selectedSubject?.siteId,
                                formId: form.formId,
                                visitId: page.selectedVisit?.visit?.id
                            }
                            dispatch(getDerivations(_payload, async (derivativeResponse: any) => {
                                if (derivativeResponse?.error) {
                                    dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: _response });
                                    payload.tabs[parseInt(page.currentTab)].data.dynamicFormData = _response;                    // payload.tabs[parseInt(page.currentTab)].label = response.formName;
                                    payload.tabs[parseInt(page.currentTab)].label = _response.formName;
                                    dispatch(dataEntryNavigation(payload))
                                } else {
                                    response = await getDerivativeValues(derivativeResponse, _response)
                                    dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: response });
                                    payload.tabs[parseInt(page.currentTab)].data.dynamicFormData = response;
                                    payload.tabs[parseInt(page.currentTab)].label = response.formName;
                                    dispatch(dataEntryNavigation(payload))
                                }
                            }));
                        }
                    }))
                }));
            }))
        } else {
            payload.selectedForm = form;
            dispatch(getDynamicFormData(form.id, (response: any) => {
                if (response) {
                    // payload.tabs[parseInt(page.currentTab)].data.dynamicFormData = response;
                    // payload.tabs[parseInt(page.currentTab)].label = response.formName;
                    // dispatch(dataEntryNavigation(payload))
                    // dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: response })

                    const _payload = {
                        siteId: page.selectedSubject?.siteId,
                        formId: form.formId,
                        visitId: page.selectedVisit?.visit?.id
                    }
                    dispatch(getDerivations(_payload, async (derivativeResponse: any) => {
                        if (derivativeResponse?.error) {
                            dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: response });
                            payload.tabs[parseInt(page.currentTab)].data.dynamicFormData = response;                    // payload.tabs[parseInt(page.currentTab)].label = response.formName;
                            payload.tabs[parseInt(page.currentTab)].label = response.formName;
                            dispatch(dataEntryNavigation(payload))
                        } else {
                            response = await getDerivativeValues(derivativeResponse, response)
                            dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: response });
                            payload.tabs[parseInt(page.currentTab)].data.dynamicFormData = response;
                            payload.tabs[parseInt(page.currentTab)].label = response.formName;
                            dispatch(dataEntryNavigation(payload))
                        }
                    }));
                }
            }))
            // dispatch(dataEntryNavigation(payload))
        }
    }

    const validateReason = () => {
        let validate: any = null;
        dynamicFormData?.data?.map((fields: any) => {
            if (fields?.field) {
                if (fields?.field && fields?.field?.reasonToChange) {
                    validate = true;
                }
            }
            else {
                fields?.group?.rows.map((rowsFields: any) => {
                    rowsFields?.fields?.map((groupFields: any) => {
                        if (groupFields?.reasonToChange) {
                            validate = true
                        }
                        return null;
                    })
                    return null;
                })
            }
            return null;
        })
        return validate;
    }

    const onRuleExecution = (ruleExecutionResponse: any) => {
        const _payload = _.cloneDeep(dynamicFormData);
        let ruleError = false;
        _payload.finalSubmit = true
        _payload.data.map((data: any, tindex: number) => {
            ruleExecutionResponse.map((rulesField: any) => {
                if (data.field) {
                    if (data.field.fieldId === rulesField.targetFieldId) {
                        ruleError = true
                        _payload.data[tindex].field.ruleError = rulesField.message
                    }
                } else {
                    data.group.rows.map((row: any, rIndex: number) => {
                        row.fields.map((rField: any, rfieldIndex: number) => {
                            if (rField.fieldId === rulesField.targetFieldId) {
                                ruleError = true
                                _payload.data[tindex].group.rows[rIndex].fields[rfieldIndex].ruleError = rulesField.message;
                            }
                            return null
                        })
                        return null
                    })
                }
                return null
            });
            return null;
        });
        return { ruleError, _payload }
        // dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: _payload })
    }
    const validateDynamicForm = (dynamicData: any) => {
        let _validate: Boolean = true;
        dynamicData?.data?.map((item: any) => {
            item.group?.rows?.map((row: any) => {
                row?.fields?.map((rowField: any) => {
                    if (rowField?.errorMsg && rowField.errorMsg.trim() != '') {
                        _validate = false
                    }
                })
            })
            if (item.field && item.field.errorMsg && item.field.errorMsg.trim() != '') {
                _validate = false
            }
        })
        return _validate
    }
    const onSubmitForm = async (saveType: string) => {
        let dynamicData: any = updateDynamicFormData(null);
        let _validateForm = await validateDynamicForm(dynamicData)
        const validate = validateReason();
        if (_validateForm) {
            if (saveType === 'saveForm') {
                const _dynamicFormSaveType = dynamicFormSaveType?.FORM_STATUS?.find((statusItem: any) => statusItem.code === "FORM_STATUS_SAVED");
                // dynamicFormData.saveType = _dynamicFormSaveType;
                dynamicData.saveType = _dynamicFormSaveType
                dispatch(saveFormData(dynamicData, async (saveResponse: any) => {
                    if (saveResponse.ruleExecutionResponse.length > 0) {
                        let _rule = await onRuleExecution(saveResponse.ruleExecutionResponse)
                        if (_rule.ruleError) {
                            dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: _rule._payload });
                        } else {
                            dispatch(getDynamicFormData(page.selectedForm.id, (dynamicFormResponse: any) => {
                                refreshDynamicFormData(dynamicFormResponse)
                            }));
                            dispatch(fetchForms(page.currentVisitId, (formsResponse: any) => {
                                const payload: any = _.cloneDeep(page);
                                payload.tabs[2].data.forms = formsResponse;
                                payload.selectedForm = formsResponse.find((item: any) => item.id === payload.selectedForm.id)
                                dispatch(dataEntryNavigation(payload))
                            }))
                        }
                    } else {
                        dispatch(getDynamicFormData(page.selectedForm.id, (dynamicFormResponse: any) => {
                            refreshDynamicFormData(dynamicFormResponse)
                        }));
                        dispatch(fetchForms(page.currentVisitId, (formsResponse: any) => {
                            const payload: any = _.cloneDeep(page);
                            payload.tabs[2].data.forms = formsResponse;
                            payload.selectedForm = formsResponse.find((item: any) => item.id === page.selectedForm.id)
                            dispatch(dataEntryNavigation(payload))
                        }))
                    }
                    // if (saveResponse) {
                    //     dispatch(getDynamicFormData(page.selectedForm.id, (dynamicFormResponse: any) => {
                    //         refreshDynamicFormData(dynamicFormResponse)
                    //     }))
                    //     dispatch(fetchForms(page.currentVisitId, (formsResponse: any) => {
                    //         const payload: any = _.cloneDeep(page);
                    //         payload.selectedForm = formsResponse.find((item: any) => item.id === payload.selectedForm.id)
                    //         payload.tabs[2].data.forms = formsResponse;
                    //         dispatch(dataEntryNavigation(payload))
                    //     }))
                    // }
                }));
            }
            else if (saveType === 'submitForm') {
                const _dynamicFormSaveType = dynamicFormSaveType?.FORM_STATUS?.find((statusItem: any) => statusItem.code === "FORM_STATUS_COMLETED");
                // dynamicFormData.saveType = _dynamicFormSaveType;
                // dynamicFormData.finalSubmit = false;
                let dynamicData: any = updateDynamicFormData(null);
                dynamicData.saveType = _dynamicFormSaveType
                dynamicData.finalSubmit = false;
                if (validate) {
                    dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: dynamicFormData })
                    setOpenReasonDialog(true)
                }
                else {
                    dispatch(saveFormData(dynamicData, async (saveResponse: any) => {
                        if (saveResponse.ruleExecutionResponse.length > 0) {
                            let _rule = await onRuleExecution(saveResponse.ruleExecutionResponse)
                            if (_rule.ruleError) {
                                dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: _rule._payload })
                            } else {
                                dispatch(getDynamicFormData(page.selectedForm.id, (dynamicFormResponse: any) => {
                                    refreshDynamicFormData(dynamicFormResponse)
                                }));
                                dispatch(fetchForms(page.currentVisitId, (formsResponse: any) => {
                                    const payload: any = _.cloneDeep(page);
                                    payload.tabs[2].data.forms = formsResponse;
                                    payload.selectedForm = formsResponse.find((item: any) => item.id === payload.selectedForm.id)
                                    dispatch(dataEntryNavigation(payload))
                                }))
                            }
                        }
                        else {
                            dispatch(getDynamicFormData(page.selectedForm.id, (dynamicFormResponse: any) => {
                                refreshDynamicFormData(dynamicFormResponse)
                            }));
                            dispatch(fetchForms(page.currentVisitId, (formsResponse: any) => {
                                const payload: any = _.cloneDeep(page);
                                payload.tabs[2].data.forms = formsResponse;
                                payload.selectedForm = formsResponse.find((item: any) => item.id === page.selectedForm.id)
                                dispatch(dataEntryNavigation(payload))
                            }))
                        }

                        // if (saveResponse) {
                        //     dispatch(getDynamicFormData(page.selectedForm.id, (dynamicFormResponse: any) => {
                        //         refreshDynamicFormData(dynamicFormResponse)
                        //     }));
                        //     dispatch(fetchForms(page.currentVisitId, (formsResponse: any) => {
                        //         const payload: any = _.cloneDeep(page);
                        //         payload.tabs[2].data.forms = formsResponse;
                        //         payload.selectedForm = formsResponse.find((item: any) => item.id === payload.selectedForm.id)
                        //         dispatch(dataEntryNavigation(payload))
                        //     }))

                        // }
                    }));
                }
            }
        }
    }
    console.warn('dynamicFormData.......', dynamicFormData);

    return (
        <React.Fragment>
            <div className="formConatiner-header">
                {/* <div className="d-flex justify-content-between" > */}
                <div className="d-flex" >
                    <div className="expand-formList">
                        {!expandForms && <div className="d-flex expandCollapseIcon" onClick={onCollapseFormsList}>
                            <CustomToolTip title='Expand'><KeyboardDoubleArrowRightIcon /></CustomToolTip>
                        </div>}
                    </div>
                    <h6 className="formName">{page.selectedForm?.formName}</h6>
                </div>
                <div className="d-flex" >
                    <button onClick={onPreviousFormHandler} className="btn btn-primary btn-sm d-flex align-items-center me-1" >
                        <SkipPreviousRoundedIcon sx={{ width: '20px', height: '20px' }} /> Prev</button>
                    <button onClick={onNextFormHandler} className="btn btn-success btn-sm d-flex align-items-center me-1">
                        Next <SkipNextRoundedIcon sx={{ width: '20px', height: '20px' }} /></button>
                </div>
                {/* </div> */}
            </div>
            <div className="dynamicFormFields">
                {renderDynamicForm}
            </div>
            <div className="form-footer" >
                <button className="btn btn-danger btn-sm" >Cancel</button>
                {/*submit*/}
                {/* {((page?.selectedForm?.actionStatus?.code === configCodes?.NotStarted) || (page?.selectedForm?.actionStatus?.code === configCodes?.Incompleted) || 
                (page?.selectedForm?.actionStatus?.code === configCodes?.submitted) || (page?.selectedForm?.actionStatus?.code === configCodes?.Saved)) && */}
                <button className="btn btn-success btn-sm" onClick={() => onSubmitForm('submitForm')}>Submit</button>
                {/* } */}
                {/* save */}
                {((page?.selectedForm?.actionStatus?.code === configCodes?.NotStarted) || (page?.selectedForm?.actionStatus?.code === configCodes?.Incompleted)) && <button className="btn btn-primary px-3 btn-sm" onClick={() => onSubmitForm('saveForm')}>Save</button>}
                {/* Monitor */}
                {(page?.selectedForm?.actionStatus?.code === configCodes?.Comleted) && <button className="btn btn-primary px-3 btn-sm" onClick={() => onSubmitForm('monitorForm')}>Monitor</button>}
                {/* Review */}
                {(page?.selectedForm?.actionStatus?.code === configCodes?.Comleted) && <button className="btn btn-primary px-3 btn-sm" onClick={() => onSubmitForm('reviewForm')}>Review</button>}
                {/* Sign */}
                {(page?.selectedForm?.actionStatus?.code === configCodes?.MonitoredandReviewed) && <button className="btn btn-primary px-3 btn-sm" onClick={() => onSubmitForm('signForm')}>Sign</button>}
                {/* Locked */}
                {(page?.selectedForm?.actionStatus?.code === configCodes?.MonitoredandReviewedandsigned) && <button className="btn btn-primary px-3 btn-sm" onClick={() => onSubmitForm('lockForm')}>Lock</button>}
            </div>
            <ReasonToChangeDialog openReasonDialog={openReasonDialog} setOpenReasonDialog={setOpenReasonDialog} />
        </React.Fragment>
    )
}
export default DynamicForm