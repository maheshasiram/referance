import React, { Fragment, useState } from 'react';
import TextField from '@mui/material/TextField';
import { useDispatch, useSelector } from 'react-redux';
import _ from 'lodash';
import { Types } from '../../../reducers/Types';
import FieldContainer from '../helpers/FieldContainer';
import FormControl from '@mui/material/FormControl';
import CustomToolTip from '../../../../../../../components/CustomToolTip';
import PriorityHighIcon from '@mui/icons-material/PriorityHigh';
import AutorenewIcon from '@mui/icons-material/Autorenew';
import { onResetValues } from '../helpers/resetValues';
import { onReasonToChange } from '../helpers/resonTochange';
import { getDerivativeValues } from '../helpers/derivations/derivations';
import { getRulesByFieldId } from '../actions/actions';
import { changeableProperties, updateDynamicFormData } from '../helpers/updateDynamicFormData';

function Integer(props: any) {
	const dispatch = useDispatch()
	const {
		/*errorMsg,*/ readOnly, id, index, isGroup, grpFieldIndex, /*freez,*/ disable,
		value, rowIndex, minValueLength, maxValueLength, fldError, defaultValue, ruleError,placeholder
	} = props;

	const { dynamicFormData, entryFormData, derivations } = useSelector((state: any) => state.subjects);
	const { page } = useSelector((state: any) => state.application);
	const [val, setVal]=useState(value ? value : defaultValue);
	// const [errorMsg, setErrorMsg] = useState('')

	// console.log("..ruleError", ruleError, dynamicFormData);
	// console.log("integer value...", value)
	let payload = updateDynamicFormData(null);
	let field = isGroup ? payload.data[index]?.group?.rows[rowIndex]?.fields[grpFieldIndex] : payload.data[index]?.field;
    let _properties: any = changeableProperties(field);
    const { errorMsg, freez } = _properties;

    const [freezField, setFreezField] = useState(freez);
	const onChangeHandler = (event: any) => {
		// alert('sdkjhg')
		// let payload = _.cloneDeep(dynamicFormData)
		payload = updateDynamicFormData(null);
		payload = onReasonToChange(isGroup, payload, index, rowIndex, grpFieldIndex, event.target.value, page, entryFormData)
		if ((event.target.value.length <= maxValueLength) || (!maxValueLength)) {
			if (isGroup) {
				payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].value = event.target.value;
				payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].errorMsg =
					event.target.value ? event.target.value.length < minValueLength ? `Please enter minimum ${minValueLength} characters` : '' : '';
			} else {
				payload.data[index].field.value = event.target.value;
				payload.data[index].field.errorMsg =
					event.target.value ? event.target.value.length < minValueLength ? `Please enter minimum ${minValueLength} characters` : '' : '';
				delete payload.data[index].field.fldError
			}
			updateDynamicFormData(payload);
			setVal(event.target.value)
			// dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload })
		}
	};

	const onBlurHandler = async (event: any) => {
		// let payload: any = _.cloneDeep();
		payload = updateDynamicFormData(payload)
		payload = await getDerivativeValues(derivations, payload)
		if (isGroup) {
			payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].errorMsg = event.target.value ? event.target.value.length < minValueLength ? `Please enter minimum ${minValueLength} characters` : '' : '';
			delete payload.data[index].group.rows[rowIndex].fields[grpFieldIndex].ruleError
		} else {
			payload.data[index].field.errorMsg = event.target.value ? event.target.value.length < minValueLength ? `Please enter minimum ${minValueLength} characters` : '' : '';
			delete payload.data[index].field.ruleError;
		}
		updateDynamicFormData(payload);
	
		// setTimeout(() => {
		// 	dispatch({ type: Types.GET_DYNAMIC_FORMDATA, payload: payload });
		// }, 250);
	};
	// const onFocusHandler = () => {
	// 	console.clear()
	// 	// let derivationExist = derivations.findIndex((item:any)=>((item.target.targetFieldIds).split(',')).includes(fieldId))
	// 	let derivationExist: any;
	// 	if (derivations && derivations.length > 0) {
	// 		derivations.map((item: any) => {
	// 			console.log('itemm.......', item);
	// 			// let _fields = 
	// return null;
	// 		})
	// 	}
	// }

	// console.log("integer props.....", props)
	return (
		<Fragment>
			<FieldContainer {...props} setFreezField={setFreezField} >
				<FormControl className="field">
					<TextField
						id={`field_${id}`}
						name={`input_${id}`}
						placeholder={placeholder ? placeholder : ''}
						className='df_txtField field'
						variant="outlined"
						disabled={readOnly || freezField || disable}
						type='number'
						value={val}
						error={errorMsg ? true : false}
						onChange={onChangeHandler}
						// inputProps={{ minlength: minValueLength, maxlength: maxValueLength }}
						onBlur={onBlurHandler}
					// onFocus={onFocusHandler}
					// helperText={errorMsg ? <p className='m-0 text-danger'>{errorMsg}</p> : ''}
					/>
				</FormControl>

				{fldError && <CustomToolTip title={fldError}>
					<PriorityHighIcon
						sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
				</CustomToolTip>}
				{ruleError && <CustomToolTip title={ruleError}>
					<PriorityHighIcon
						sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
				</CustomToolTip>}
				{((val) && (!disable && !freezField && !readOnly)) &&
					<span className="ps-1 resetFieldValue">
						<CustomToolTip title='clear value'>
							<AutorenewIcon onClick={() => onResetValues(updateDynamicFormData(null), "", isGroup, null, dispatch, rowIndex, index, grpFieldIndex,setVal)}
								sx={{ fill: 'rgb(68, 157, 68)', width: '18px' }} />
						</CustomToolTip>
					</span>
				}
			</FieldContainer>
		</Fragment>
	);
}
export default Integer;
