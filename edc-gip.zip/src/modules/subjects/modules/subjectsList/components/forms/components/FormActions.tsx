import React, { useState } from "react";
import { useSelector } from "react-redux";
import { Button } from "primereact/button";
import ReplayIcon from '@mui/icons-material/Replay';
import LockOpenOutlinedIcon from '@mui/icons-material/LockOpenOutlined';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import _ from 'lodash'
import { Confirm, dataEntryNavigation, toastAlert } from "../../../../../../../actions/actions";
import { subjectFormLock, fetchByMappingForm, subjectFormUnlock, fetchForms, markNotComplete, restoreNotComplete } from "../actions/action";
import ReasonDialog from "./ReasonDialog";

function FormActions(props: any) {
    const { rowData, dispatch } = props;
    const [reason, setReason] = useState("");
    const [validate, setValidate] = React.useState(false);
    const [open, setOpen] = useState(false);
    const { page } = useSelector((state: any) => state.application);
    const [actionType, setActionType] = useState('')
    const onchangeHandler = (e: any) => {
        setReason(e.target.value)
        if (e.target.value === "") {
            setValidate(true)
        }
        else {
            setValidate(false)
        }
    }
    const updatePageData = () => {
        dispatch(fetchForms(page.currentVisitId, (response: any) => {
            const payload: any = _.cloneDeep(page);
            payload.tabs[parseInt(page.currentTab)].data.forms = response;
            dispatch(dataEntryNavigation(payload))
        }))
    }
    const submitHandler = () => {
        if (reason !== "") {
            switch (actionType) {
                case 'unlock': {
                    return (
                        dispatch(subjectFormUnlock({ rowDataID: rowData?.id, reason: reason }, (response: any) => {
                            dispatch(toastAlert({
                                status: 1,
                                message: response,
                                open: true
                            }))
                            setOpen(false);
                            updatePageData();
                        }))
                    )
                }
                case 'Mark Not Expected': {
                    return (
                        // <>{console.log("53...",rowData)}</>
                        dispatch(fetchByMappingForm({ subjectVisitId: page.currentVisitId, formId: rowData.formId }, (response: any) => {
                            console.log("86...", response)
                            if (response) {
                                dispatch(markNotComplete({ rowDataID: response?.id, reason: reason }, (response: any) => {
                                    dispatch(toastAlert({
                                        status: 1,
                                        message: response,
                                        open: true
                                    }))
                                    setOpen(false);
                                    updatePageData();
                                }))
                            }
                        }))
                        // rowData?.id && dispatch(markNotComplete({ rowDataID: rowData?.id, reason: reason  }, (response: any) => {
                        //     dispatch(toastAlert({
                        //         status: 1,
                        //         message: response,
                        //         open: true
                        //     }))
                        //     setOpen(false);
                        //     updatePageData();
                        // }))
                    )
                }
                default: {
                    return null

                }

            }
        }
        else {
            setValidate(true);
        }
    }
    const onClose = () => {
        setValidate(false);
        setReason('')
        setOpen(false)
        setActionType('')
    }
    const onMarkNotComplete = (rowData: any, type: any) => {
        // console.log("84...",rowData)
        onOpen()
        setActionType(type)
    }
    const onOpen = () => {
        setOpen(true);
    }
    const onRestore = (rowData: any, type: any) => {
        setActionType(type)
        dispatch(Confirm({
            status: 0,
            message: "Are you sure you want to restore form ?",
            onOk: () => {
                dispatch(restoreNotComplete(rowData?.id, (response: any) => {
                    dispatch(toastAlert({
                        status: 1,
                        message: response,
                        open: true
                    }))
                    setOpen(false);
                    updatePageData();
                }))
            }
        }))
    }
    // const onDelete = (rowData: any, type: any) => {
    //     setActionType(type)
    // }
    const unLockEvents = (rowData: any, type: any) => {
        setOpen(true);
        setReason('')
        setActionType(type)
    }
    const lockEvents = (rowData: any, type: any) => {
        setActionType(type)
        dispatch(subjectFormLock(rowData.id, (response: any) => {
            dispatch(toastAlert({
                status: 1,
                message: response,
                open: true
            }))
            updatePageData();
        }))

    }
    return (
        <React.Fragment>
            {!rowData.repeat && <div className="action-icons">
                {(rowData && !rowData.notComplete && !rowData.lockStatus) &&
                    <Button id="MarkNotExpectedBtn" icon="pi pi-id-card"
                        onClick={() => onMarkNotComplete(rowData, 'Mark Not Expected')}
                        className="p-button-rounded p-button-outlined" title="Mark Not  Expected" ></Button>
                }
                {
                    (rowData?.notComplete) &&
                    <ReplayIcon sx={{ fontSize: 22, opacity: .8 }}
                        onClick={() => onRestore(rowData, 'restore')} />}
                {/* {
                (rowData && rowData.actionStatus.code != 'FORM_STATUS_NOT_EXPECTED') && (
                    <DeleteIcon sx={{ fontSize: 14, opacity: .8 }} className='text-danger'
                        onClick={() => onDelete(rowData, 'delete')} />
                )
            }  */}

                {
                    (rowData?.lockStatus === true) &&
                    <LockOpenOutlinedIcon onClick={() => unLockEvents(rowData, 'unlock')} />}
                {(rowData?.actionStatus?.name === 'Incompleted' && rowData?.lockStatus === false) &&
                    <LockOutlinedIcon onClick={() => lockEvents(rowData, 'lock')} />
                }
            </div>}
            <ReasonDialog open={open} actionType={actionType} reason={reason} validate={validate} onClose={onClose} submitHandler={submitHandler} onchangeHandler={onchangeHandler} />
        </React.Fragment>
    )
}
export default FormActions;