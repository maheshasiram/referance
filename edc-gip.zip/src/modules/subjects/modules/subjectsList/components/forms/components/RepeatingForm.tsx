import React from "react"
import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useDispatch } from "react-redux";
import FormActions from "./FormActions";

export const RepeatingForm: any = (props: any) => {
    console.log("8.....",props)
    const dispatch = useDispatch()
    return (
        <div id='subForms-SubTable' className="subForms-SubTable w-100">
            <DataTable value={props.data.childForms}
                scrollable scrollHeight="200px"
                responsiveLayout="scroll">
                {/* <Column style={{ width: '40px' }} /> */}
                <Column body={(rowData) => {
                    return (
                        <React.Fragment>
                            {/* {
                                rowData.formStatus === 'Not Expected' ? (
                                    <a id={rowData.formName} style={{ fontWeight: 'normal', color: 'rgba(0,0,0,.5)', paddingLeft: 22 }}>
                                        {rowData.formName} <span>{`(${fields.rowIndex + 1})`}</span> <span> &nbsp; ({rowData.formStatus}) </span>
                                    </a>
                                ) : (<span className="cursor-pointer"><a id={rowData.formName} onClick={() => props.onNavigateDynamicForms(rowData)} >
                                    {rowData.formName}<span>{`(${fields.rowIndex + 1})`}</span> <span> &nbsp; ({rowData.formStatus}) </span>
                                </a></span>)
                            } */}
                            {
                                <span className="cursor-pointer"><a href="# " id={rowData.formName}  onClick={() => props.onNavigateDynamicForms(rowData)} >
                                    {rowData.formName}<span> &nbsp; ({rowData.actionStatus && rowData.actionStatus.name }) </span>
                                </a></span>
                            }
                        </React.Fragment>
                    )
                }} header="Form Name" ></Column>
                <Column body={(rowData: any, field: any) => <FormActions rowData={rowData} field={field} dispatch={dispatch} />} header="Actions"></Column>
            </DataTable>
        </div>)
}