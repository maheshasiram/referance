export const Types = {
    GET_ALL_FORMS:"GET_ALL_FORMS"
}