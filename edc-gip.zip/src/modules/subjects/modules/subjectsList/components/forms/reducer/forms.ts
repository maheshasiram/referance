import { Types } from "./Types"

const initialState = {
}
export const forms = (state = initialState, action: { type: any, payload: any }) => {
    switch (action.type) {
        case Types.GET_ALL_FORMS:
            return { ...state, groupDetails: '' }
        default:
            return { ...state }
    }
}
