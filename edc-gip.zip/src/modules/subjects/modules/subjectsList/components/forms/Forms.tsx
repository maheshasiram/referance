import React from "react";
import { useDispatch, useSelector } from "react-redux";
import {  fetchOpenQuries, fetchStickyNotes } from "../../actions/action";
import OutStandingActions from "../helpers/outStandingActions/OutStandingActions";
import FormsDashBoard from "./components/FormsDashboard";
import _ from "lodash";
import './styles.scss'
import { dataEntryNavigation } from "../../../../../../actions/actions";
import { fetchForms, findSubjectFormsByUnscheduledVisitId } from "./actions/action";

function Forms(props: any) {
    const dispatch = useDispatch()
    const { page } = useSelector((state: any) => state.application);
    const loaded = React.useRef(false);
    const { data } = props;

    React.useEffect(() => {
        if (!loaded.current) {
            const payload: any = _.cloneDeep(page);
                dispatch((page.selectedVisit.visit.visitRepeat? findSubjectFormsByUnscheduledVisitId:fetchForms)(page.selectedVisit.id,(response: any) => {
                    payload.tabs[parseInt(page.currentTab)].data.forms = response;
                    dispatch(fetchOpenQuries(2, (queryResponse: any) => {
                        payload.tabs[parseInt(page.currentTab)].data.openQuries = queryResponse;
                        dispatch(fetchStickyNotes(2, (stickyResponse: any) => {
                            payload.tabs[parseInt(page.currentTab)].data.stickyNotes = stickyResponse;
                            dispatch(dataEntryNavigation(payload))
    
                        }));
                    }));
                }));
            loaded.current = true;
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []) 
    return (
        <React.Fragment>
            <div className="form-container d-flex">
                <div className="forms">
                    <FormsDashBoard />
                </div>
                <div className="statistics ps-3">
                    <OutStandingActions data={data} />
                </div>
            </div>
        </React.Fragment>
    )

}
export default Forms
