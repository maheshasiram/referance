import React from "react";
import CustomDialog from "../../../../../../../common/modals/CustomeDialog";

export default function ReasonDialog(props: any) {
    const {validate,actionType,open,onClose,submitHandler,reason,onchangeHandler} = props;
    return (
        <React.Fragment>
            <CustomDialog
                title={actionType === "Mark Not Expected" ? `Enter Reason For Mark Not Expected`
                    : "Enter Reason For Unlock"}
                open={open}
                form='resonToChange'
                onClose={onClose}
                maxWidth="xs"
                fullWidth={true}
                onSubmitHandler={submitHandler}
                actionType='Submit'
            >
                <div className="mt-3">
                    {validate && <div className=" d-flex justify-content-center text-danger">Enter Reason To Change</div>}
                    <div>
                        <textarea className="form-control"
                            rows={7} cols={58}
                            value={reason}
                            onChange={(e) => onchangeHandler(e)}
                            placeholder="Please enter the reason">
                        </textarea>
                    </div>
                </div>
            </CustomDialog>
        </React.Fragment>
    )
}