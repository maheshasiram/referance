import { Loader } from "../../../../../../../actions/actions";
import { subjects } from "../../../../../../../configs/enivornment/subjects";
import { fetch } from "../../../../../../../constants/fetch";

export const fetchForms: any = (payload: any, callback: any) => {
    return (dispatch: any) => {
        dispatch(Loader(true));
        const url = `${subjects.forms.findAllBySubjectVisitId}?subjectVisitId=${payload}`
        fetch({
            method: 'GET',
            url: url,
            data: payload
        })
            .then((response: any) => {
                if (callback) { callback(response.data) }
                dispatch(Loader(false));
            })

    }
}



export const createRepeatForm: any = (payload: any, callback: any) => {
    return (dispatch: any) => {
        dispatch(Loader(true));
        const url = `${subjects.forms.createRepeatForm}/${payload.subjectVisitId}/${payload.formId}`
        fetch({
            method: 'GET',
            url: url,
            data: payload
        })
            .then((response: any) => {
                if (callback) { callback(response.data) }
                dispatch(Loader(false));
            })

    }
}

export const findSubjectFormsByUnscheduledVisitId: any = (payload: any, callback: any) => {
    return (dispatch: any) => {
        dispatch(Loader(true));
        const url = `${subjects.forms.findSubjectFormsByUnscheduledVisitId}/${payload}`
        fetch({
            method: 'GET',
            url: url,
            data: payload
        })
            .then((response: any) => {
                if (callback) { callback(response.data) }
                dispatch(Loader(false));
            })

    }
}

export const fetchByMappingForm: any = (payload: any, callback: any) => {
    return (dispatch: any) => {
        dispatch(Loader(true));
        const url = `${subjects.forms.fetchByMappingForm}/${payload.subjectVisitId}/${payload.formId}`
        fetch({
            method: 'GET',
            url: url,
            data: payload
        })
            .then((response: any) => {
                if (callback) { callback(response.data) }
                dispatch(Loader(false));
            })
            .catch((error: any) => {
                console.log('error.....', error)
                dispatch(Loader(false));
                if (callback) { callback(error.response.data) }
            })

    }
}

export const subjectFormLock: any = (payload: any, callback: any) => {
    return (dispatch: any) => {
        dispatch(Loader(true));
        const url = `${subjects.forms.lock}/${payload}`
        fetch({
            method: 'GET',
            url: url,
            data: payload
        })
            .then((response: any) => {
                if (callback) { callback(response.data) }
                dispatch(Loader(false));
            })

    }
}

export const markNotComplete: any = (payload: any, callback: any) => {
    return (dispatch: any) => {
        dispatch(Loader(true));
        const url = `${subjects.forms.markNotComplete}/${payload.rowDataID}?comments=${payload.reason}`
        fetch({
            method: 'GET',
            url: url,
            data: payload
        })
            .then((response: any) => {
                if (callback) { callback(response.data) }
                dispatch(Loader(false));
            })

    }
}

export const restoreNotComplete: any = (payload: any, callback: any) => {
    return (dispatch: any) => {
        dispatch(Loader(true));
        const url = `${subjects.forms.restoreNotComplete}/${payload}`
        fetch({
            method: 'GET',
            url: url,
            data: payload
        })
            .then((response: any) => {
                if (callback) { callback(response.data) }
                dispatch(Loader(false));
            })

    }
}

export const subjectFormUnlock: any = (payload: any, callback: any) => {
    // const { subjectFormId, comments } = payload
    return (dispatch: any) => {
        dispatch(Loader(true));
        const url = `${subjects.forms.unlock}/${payload.rowDataID}?comments=${payload.reason}`
        console.log("payload...", payload)
        fetch({
            method: 'GET',
            url: url,
            data: payload
        })
            .then((response: any) => {
                if (callback) { callback(response.data) }
                dispatch(Loader(false));
            })

    }
}