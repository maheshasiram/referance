import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { RepeatingForm } from "./RepeatingForm";
import { Confirm, dataEntryNavigation, toastAlert } from "../../../../../../../actions/actions";
import FormActions from "./FormActions";
import { createRepeatForm, fetchByMappingForm } from "../actions/action";
import ControlPointIcon from '@mui/icons-material/ControlPoint';
import CustomToolTip from "../../../../../../../components/CustomToolTip";

function FormsDashBoard() {
    const dispatch = useDispatch()
    const { page } = useSelector((state: any) => state.application);
    const [expandedRows, setExpandedRows] = useState<any>(null);
    const [formData, setFormData] = useState(page.tabs[parseInt(page.currentTab)].data.forms)

    useEffect(() => {
        setFormData(page.tabs[parseInt(page.currentTab)].data.forms)
    }, [page])

    const onAddForm = (rowData: any) => {
        const payload = {
            subjectVisitId: page.currentVisitId,
            formId: rowData.formId
        }
        if (rowData.childForms && rowData.childForms.length >= 1) {
            dispatch(Confirm({
                status: 0, message: "Are you sure you want to add more form?",
                onOk: () => {
                    dispatch(createRepeatForm(payload, (response: any) => {
                        if (response.status === "error") {
                            dispatch(toastAlert({
                                status: 2, message: response.errorMessage, open: true
                            }));
                        }
                        else {
                            onNavigateDynamicForms(response)
                        }
                    }))
                }
            }))
        }
        else {
            dispatch(createRepeatForm(payload, (response: any) => {
                onNavigateDynamicForms(response)
            }))
        }
    }


    const onNavigateDynamicForms = (rowData: any) => {
        const payload = { ...{}, ...page };
        payload.tabs[(parseInt(page.currentTab) + 1)].isActive = true;
        payload.tabs[(parseInt(page.currentTab) + 1)].label = rowData.formName;
        payload.currentTab = (parseInt(page.currentTab) + 1).toString();
        if (!rowData.id && !rowData.repeat) {
            dispatch(fetchByMappingForm({ subjectVisitId: page.currentVisitId, formId: rowData.formId }, (response: any) => {
                console.log('response......', response);
                if (response.errorMessage || response?.error) {
                    dispatch(toastAlert({
                        status: 0, message: response.errorMessage ? response.errorMessage : response?.error, open: true
                    }));
                } else {
                    payload.selectedForm = response;
                    dispatch(dataEntryNavigation(payload))
                }
            }))
        } else {
            payload.selectedForm = rowData;
            dispatch(dataEntryNavigation(payload))
        }
    }

    const rowExpansionTemplate = (data: any) => {
        return (
            data.childForms && data.childForms.length > 0 &&
            <RepeatingForm data={data} onNavigateDynamicForms={onNavigateDynamicForms} />
        );
    }

    const formNameTemplate = (rowData: any) => {
        return (
            <div className="event-template-forms">
                <span>
                    {!rowData.repeat ? rowData.actionStatus.name === "Not Expected" ? (
                        <span id={rowData.formName} >
                            {rowData.formName} <span className='formstatustd'>( {rowData.actionStatus.name} )
                            </span> </span>
                    ) : (<span id={rowData.formName} onClick={() => onNavigateDynamicForms(rowData)} >
                        {rowData.formName} <span className='formstatustd'>( {rowData.actionStatus.name} )
                        </span> </span>) : <span className="d-flex justify-content-start align-items-center" >
                        {rowData.formName}
                        <CustomToolTip id={rowData.formName} className="repeatIcon cursor-pointer" title={'Add Form'}>
                            <ControlPointIcon onClick={() => onAddForm(rowData)} />
                        </CustomToolTip>
                    </span>
                    }
                </span>
            </div>
        )
    }

    return (
        <React.Fragment>
            Forms Details
            <div id="Forms-table" className="Forms-table">
                <DataTable
                    value={formData}
                    responsiveLayout="scroll"
                    emptyMessage="No Forms are found to display."
                    stripedRows
                    dataKey="formID"
                    scrollable
                    scrollHeight="400px"
                    expandedRows={expandedRows}
                    onRowToggle={(e: any) => setExpandedRows(e.data)}
                    rowExpansionTemplate={rowExpansionTemplate}
                >
                    <Column expander style={{ maxWidth: "50px" }} />
                    <Column body={formNameTemplate} header="Form Names"></Column>
                    <Column body={(rowData: any, field: any) => <FormActions rowData={rowData} field={field} dispatch={dispatch} />} header="Actions"></Column>
                </DataTable>

            </div>
        </React.Fragment>
    )
}
export default FormsDashBoard;
