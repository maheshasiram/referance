import { Types } from "./Types"
import { formListParam } from "../constants/importData-modal" 

const initialState = {
    allformList: {},
    formListParam:formListParam,
    downloadFOrm:null,
}

export const importData = (state = initialState, action: { type: any, payload: any }) => {
    switch (action.type) {
        case Types.GET_ALL_FORM_LISTS:
            return { ...state,  allformList:action.payload }
            case Types.GET_FORM_BY_ID:
            return { ...state,  downloadFOrm:action.payload }
            default:
                return { ...state }
        }
    }