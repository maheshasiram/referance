export const importDataModel = [
    {
        "formId": 67,
        "formName": "12 Lead ECG"
    },
    {
        "formId": 68,
        "formName": "2D Echo"
    },
    {
        "formId": 98,
        "formName": "Adverse Events"
    },
    {
        "formId": 79,
        "formName": "Biochemistry"
    },
    {
        "formId": 70,
        "formName": "Chest X-Ray"
    },
    {
        "formId": 93,
        "formName": "Compliance Restrictions"
    },
    {
        "formId": 90,
        "formName": "Concomitant Medications"
    },
    {
        "formId": 76,
        "formName": "Covid Test"
    },
    {
        "formId": 91,
        "formName": "CT or MRI or PET Scan"
    },
    {
        "formId": 62,
        "formName": "Demographic Profile"
    },
    {
        "formId": 120,
        "formName": "Dispensing of Investigational Product"
    },
    {
        "formId": 65,
        "formName": "ECOG Assessment"
    },
    {
        "formId": 83,
        "formName": "Eligibility Criteria"
    },
    {
        "formId": 84,
        "formName": "Enrolment and Randomization"
    },
    {
        "formId": 122,
        "formName": "file name autopopulation"
    },
    {
        "formId": 78,
        "formName": "Hematology"
    },
    {
        "formId": 97,
        "formName": "History of Allergies"
    },
    {
        "formId": 110,
        "formName": "Hospitalization"
    },
    {
        "formId": 108,
        "formName": "Hospitalization (Check-In)"
    },
    {
        "formId": 111,
        "formName": "Hospitalization (Check-Out)"
    },
    {
        "formId": 73,
        "formName": "Informed Consent"
    },
    {
        "formId": 96,
        "formName": "Issuance of Diary Card"
    },
    {
        "formId": 92,
        "formName": "Meal Consumption Record (Day 11)"
    },
    {
        "formId": 95,
        "formName": "Meal Consumption Record (Day 12)"
    },
    {
        "formId": 100,
        "formName": "Meal Consumption Record (Day 13)"
    },
    {
        "formId": 101,
        "formName": "Meal Consumption Record (Day 14)"
    },
    {
        "formId": 103,
        "formName": "Meal Consumption Record (Day 15)"
    },
    {
        "formId": 105,
        "formName": "Meal Consumption Record (Day 25)"
    },
    {
        "formId": 106,
        "formName": "Meal Consumption Record (Day 26)"
    },
    {
        "formId": 107,
        "formName": "Meal Consumption Record (Day 27)"
    },
    {
        "formId": 109,
        "formName": "Meal Consumption Record (Day 28)"
    },
    {
        "formId": 75,
        "formName": "Medical History"
    },
    {
        "formId": 94,
        "formName": "Physical Examination"
    },
    {
        "formId": 119,
        "formName": "Post-Dose Sampling"
    },
    {
        "formId": 89,
        "formName": "Post-Dose Vital Signs And Wellbeing"
    },
    {
        "formId": 121,
        "formName": "Pre-Dose Sampling"
    },
    {
        "formId": 86,
        "formName": "Pre-Dose Vital Signs And Wellbeing"
    },
    {
        "formId": 88,
        "formName": "Review of Concomitant Medications"
    },
    {
        "formId": 114,
        "formName": "Review of Subject Diary and IP Compliance Check"
    },
    {
        "formId": 102,
        "formName": "Safety Monitoring"
    },
    {
        "formId": 85,
        "formName": "Screening For Urine Drugs of Abuse"
    },
    {
        "formId": 82,
        "formName": "Serious Adverse Event (SAE) - Follow-up Report"
    },
    {
        "formId": 81,
        "formName": "Serious Adverse Event (SAE) - Initial Report"
    },
    {
        "formId": 99,
        "formName": "Serology"
    },
    {
        "formId": 71,
        "formName": "Serum Electrolytes"
    },
    {
        "formId": 66,
        "formName": "Serum Pregnancy Test"
    },
    {
        "formId": 113,
        "formName": "Study Completion"
    },
    {
        "formId": 116,
        "formName": "Study Drug Administration"
    },
    {
        "formId": 64,
        "formName": "Subject Details"
    },
    {
        "formId": 104,
        "formName": "Subject Eligibility"
    },
    {
        "formId": 112,
        "formName": "Substance Usage History"
    },
    {
        "formId": 123,
        "formName": "target file"
    },
    {
        "formId": 124,
        "formName": "TESTLABFORM"
    },
    {
        "formId": 72,
        "formName": "Thyroid Function Test"
    },
    {
        "formId": 115,
        "formName": "Treatment Discontinuation Form"
    },
    {
        "formId": 118,
        "formName": "Unscheduled Visit"
    },
    {
        "formId": 74,
        "formName": "Urine Alcohol Test"
    },
    {
        "formId": 87,
        "formName": "Urine Analysis"
    },
    {
        "formId": 69,
        "formName": "Urine Pregnancy Test"
    },
    {
        "formId": 63,
        "formName": "Visit Details"
    },
    {
        "formId": 80,
        "formName": "Vital Signs and Wellbeing"
    },
    {
        "formId": 77,
        "formName": "Women Childbearing Potential"
    }
]