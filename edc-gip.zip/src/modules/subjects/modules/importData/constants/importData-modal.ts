import { Params } from "./importData-types" 

export const formListParam: Params = {
    limit: 10,
    offset: 0,
    nameCriteria: '',
    studyId: 0
  }