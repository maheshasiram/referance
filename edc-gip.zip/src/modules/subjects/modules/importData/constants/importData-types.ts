export type Params = {
    offset: number,
    limit: number,
    nameCriteria: string,
    studyId: number
  }