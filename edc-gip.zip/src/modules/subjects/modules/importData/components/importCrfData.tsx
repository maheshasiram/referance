import React from 'react'
import "../style/styles.scss"
import CustomToolTip from '../../../../../components/CustomToolTip';
import FileDownloadOutlinedIcon from '@mui/icons-material/FileDownloadOutlined';
import { NavLink ,useParams} from "react-router-dom";
import { useDispatch } from 'react-redux';
import { downloadformTemplateById, uploadForm } from '../actions/action';


function ImportCrfData() {
    const dispatch = useDispatch()
    const params = useParams();

    const [fileError, setFileError] = React.useState('')
    const [uploadfile, setUploadfile] = React.useState('')

    const onUploadFile = (e: any) => {
        console.log('..itemId', e.target.files[0]);
        setUploadfile(e.target.value)
        if (e.target.value) {
            setFileError('')
        }
    };
    const onDownloadFile = () => {
        dispatch(downloadformTemplateById(params.selectVal))
    };

    const onSubmit = () => {
        console.log('..itemId', uploadfile);
        if (!uploadfile) {
            setFileError('Please Select File')
        } else {
            const payload = { id: params.selectVal, FormData: uploadfile }
            dispatch(uploadForm(payload))
            setFileError('')
        }

    };
    return (

        <React.Fragment>
            <div className='container'>
                <h2 className='p-1 m-1'>
                    <span className='title_manage'>
                        Import CRF Data
                    </span>
                </h2>
                <div className="notePoint">Upload an excel file that contains crf data.
                    If your crf has error value fields, You will have to go in errors page.
                </div>
                <NavLink className="crfImportBack text-primary float-right"
                    to={`../importdata`}>← Back to File Import
                </NavLink>

                <div className='row card templateDownload'>
                    <div className='d-flex '>
                        <input className='file' type='file' accept=".xls" onChange={onUploadFile} />
                        <span className='dowloadIcon'>
                            <CustomToolTip title='Download Template to Import Data'>
                                <FileDownloadOutlinedIcon sx={{ fontSize: 22, opacity: .9 }} onClick={onDownloadFile} />
                            </CustomToolTip>
                        </span>
                    </div>
                    <div className='text-danger'>{fileError}</div>
                    <button type='submit' style={{ float: 'right', marginLeft: '20px' }} className="btn btn-success submit" onClick={onSubmit}> Continue</button>
                </div>
            </div>
        </React.Fragment>

    )
}

export default ImportCrfData