import React, { useRef } from 'react';
// import { Toast } from 'primereact/toast';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import RefreshIcon from '@mui/icons-material/Refresh';
import { FileUpload } from 'primereact/fileupload';
// import UploadFileIcon from '@mui/icons-material/UploadFile';
import { downloadformTemplateById } from '../actions/action';
import { useDispatch } from 'react-redux';

function UploadAndDownloadCrf(props:any) {
    const [file, setFile] = React.useState(null);
    const dispatch = useDispatch()


    const onTemplateSelect = (e: any) => {
        console.log('e.files', e.files[0].name);
        // let _totalSize = totalSize;
        // let files = e.files;

        // Object.keys(files).forEach((key) => {
        //     _totalSize += files[key].size || 0;
        // });
        setFile(e.files[0].name);

        // setTotalSize(_totalSize);
        // onTemplateClear(files)
    };
    // const onTemplateRemove = (file:any) => {
    //     console.log("file....",file,totalSize);
    //     // setTotalSize(totalSize - file.size);
    //     // callback();
    // };

    const onTemplateClear = (e: any) => {
        setFile(null);
        // setTotalSize(0);
        // onTemplateRemove(e.target)
    };

    // console.log('1111....', totalSize);

    const onTemplateDownload = (e: any) => {
        console.log('...41',props.selectVal);
         dispatch(downloadformTemplateById(props.selectVal))


    };


    return (
        <React.Fragment>
            {!file && <div className="file-download-icon" onClick={onTemplateDownload}> <FileDownloadIcon /></div>}

            <div className="card flex justify-content-center file-upload">
                {!file ? <FileUpload mode="basic" name="" url="/api/upload" accept=".xlsx" onSelect={onTemplateSelect} /> :
                    <div className="file-name">{file}<i className="pi pi-upload"></i></div>
                }
            </div>
            {file && <div className="file-refresh-icon ms-2"> <RefreshIcon onClick={onTemplateClear} /></div>}


        </React.Fragment>
    )
}

export default UploadAndDownloadCrf;