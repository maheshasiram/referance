import React, { useEffect, } from "react";
import { useDispatch, useSelector } from "react-redux";
// import { importDataModel } from "./constants/imortDetails";
import "./style/styles.scss"
// import { useNavigate } from 'react-router-dom';
import { fetchAllFormsDataByCriteria } from "./actions/action";
import UploadAndDownloadCrf from "./components/UploadAndDownloadCrf";


function ImportData() {
    const dispatch = useDispatch()
    // const navigate = useNavigate()
    const [selectVal, setSelectVal] = React.useState('')
    const [error, setError] = React.useState('')
    const { currentStudy } = useSelector((state: any) => state.application)
    const { allformList } = useSelector((state: any) => state.importData)



    useEffect(() => {
        dispatch(fetchAllFormsDataByCriteria(currentStudy.id))

    }, [dispatch, currentStudy.id])

    // const submitForm = (e: any) => {
    //     e.preventDefault()
    //     console.log('...20', selectVal);
    //     if (selectVal !== '') {
    //         setError('')
    //         // navigate(`/subjects/LabFileImportUpload/${selectVal}`)
    //     } else {
    //         setError('Please Select atleast one form from below list.')
    //     }
    // };

    const handleChange = (e: any) => {
        setSelectVal(e.target.value);
        setError('')
    };

    return (
        <React.Fragment>
            <div className="">
                <h3 className="p-1 m-1">File Import</h3>
            </div>
            <form >
                <div className="card" style={{ backgroundColor: "#f7f7f7" }}>
                    <div className="text-danger text-center">{error}</div>
                    <ul className="listofForms">
                        {allformList?.data?.map((item: any, index: number) => {
                            return (
                                <li style={{ listStyle: 'none' }} key={index} className="justify-content-between">
                                    <div className="radioContainer ">
                                        <input className="btn-checked" name="qform" type="radio" value={item.formId} onChange={handleChange} />
                                        <span className="formName">{item.formName}</span>
                                    </div>
                                   <div className="d-flex align-items-center upload-download"> {(parseInt(selectVal)===item.formId) && <UploadAndDownloadCrf selectVal={selectVal} />}</div>
                                </li>
                            )
                        })}
                    </ul>
                </div>
                {/* <div className="dataSubmit text-right">
                    <button type='submit' style={{ float: 'right' }} className="btn btn-success" onClick={(e: any) => submitForm(e)} > Submit</button>
                </div> */}
            </form>
        </React.Fragment>
    )
}
export default ImportData