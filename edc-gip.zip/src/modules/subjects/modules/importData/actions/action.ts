import { fetch } from '../../../../../constants/fetch';
import { studySetup } from '../../../../../configs/enivornment/studySetup';
import { Types } from '../reducer/Types';
import { Loader } from '../../../../../actions/actions';
// import _ from 'lodash'

// api for loading all forms 
export const fetchAllFormsDataByCriteria: any = (studyId: any) => {
  const url = `${studySetup.importData.allForms}?studyId=${studyId}`
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'GET',
      url: url
      // data: payload
    })
      .then((response: any) => {
        dispatch({ type: Types.GET_ALL_FORM_LISTS, payload: response.data });
        dispatch(Loader(false));
        //   if (callback) { callback(response) }
      })
      .catch(() => {
        dispatch(Loader(false));
      })
  }
}

      // api for downloadFormTemplateExcel by id
    export const downloadformTemplateById: any = (payload: any) => {
    return function (dispatch: any) {
      dispatch(Loader(true));
      console.log('..payload',payload);
      fetch({
        method: 'GET',
        url: `${studySetup.importData.downloadExcelTemplate}?formId=${payload}`,
        responseType: 'blob',
      })
        .then((blob: any) => {
          const url = window.URL.createObjectURL(new Blob([blob.data]));
          const fileType: any ='xlsx' 
          const link: any = document.createElement('a');
          link.href = url;
          link.setAttribute('download', `${'formExcelTemplate' + `${"."}` + fileType}`);
          // 3. Append to html page
          document.body.appendChild(link);
          // 4. Force download
          link.click();
          dispatch(Loader(false));
        })
        .catch(() => {
          dispatch(Loader(false));
        })
    }
  }

  // API for uploadForm
// payload-( "formId": 1,/ FormData - fileuplaod(need to upload file))
export const uploadForm: any = (payload: any) => {
  console.log('...payload', payload);
  return function (dispatch: any) {
    dispatch(Loader(true));
    fetch({
      method: 'POST',
      // url: studySetup.forms.uploadForm,
      data: payload
    })
      .then((response: any) => {
    dispatch({ type: Types.UPLOAD_FORM, payload: response.data });
        dispatch(Loader(false));
      //   if (callback) { callback(response) }
      })
      .catch(() => {
        dispatch(Loader(false));
      })
  }
}