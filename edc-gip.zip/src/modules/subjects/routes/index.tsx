import React from 'react'
import { Route, Routes } from 'react-router-dom';
// import DownloadsModule from '../modules/downloads/Downloads';
import ImportDataModule from '../modules/importData';
import ImportCrfData from '../modules/importData/components/importCrfData';
import SubjectsListModule from '../modules/subjectsList';

function SubjectsRoutes() {
    return (
        <Routes>
            <Route path='/' element={<SubjectsListModule/>}></Route>
            <Route path='importdata' element={<ImportDataModule />}></Route>
            <Route path='LabFileImportUpload/:selectcVal' element={<ImportCrfData />}></Route>
            {/* <Route path='downloads' element={<DownloadsModule />}></Route> */}
        </Routes>
    )
}
export default SubjectsRoutes;