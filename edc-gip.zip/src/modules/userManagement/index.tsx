import React from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from 'react-redux';
import SearchField from "../../common/searchField/SearchField";
import UserManagementDashboard from "./components/UserManagementDashboard";
import './styles/Styles.scss'
import { fetchAllUsersManagementData } from "./actions/actions";
import { Types } from "./reducer/Types";
import { createUserModel } from "./constants/models";

function UserManagement() {

    const { userManagementParams } = useSelector((state: any) => state.userManagement);
    const dispatch = useDispatch()
    const navigate = useNavigate()

    const onSearchUserName = (e: any) => {
        const _payload = { ...{}, ...userManagementParams, offset: 0, userName: e.target.value }
        dispatch({ type: Types.USER_PARAMS, payload: _payload })
        dispatch(fetchAllUsersManagementData(_payload))
    }
    const onClearSearch = () => {
        const _payload = { ...{}, ...userManagementParams, offset: 0, limit: userManagementParams.limit, userName: '' }
        dispatch({ type: Types.USER_PARAMS, payload: _payload })
        dispatch(fetchAllUsersManagementData(_payload))
    }

    const handleCreateUser = () => {
        // let _payload = { ...{}, ...userManagementParams, offset: 0, limit: userManagementParams.limit, userName: '' }
        // dispatch({ type: Types.USER_PARAMS, payload: _payload })
        // dispatch(fetchAllUsersManagementData(_payload))
        dispatch({ type: Types.CREATE_USER, payload: createUserModel })
        navigate('./createUser/0')
    }
    return (
        <div className='container' >
            <div className='um-container' >
                <h2>User Management</h2>
                <div className='um-header'>
                    <button className='btn-eprimary me-3' onClick={handleCreateUser}>Create User</button>
                    <SearchField
                        value={userManagementParams.userName}
                        placeholder='Search with User Name'
                        onChange={onSearchUserName}
                        onClearSearch={onClearSearch}
                    />
                </div>
            </div>
            <UserManagementDashboard />
        </div>
    )
}
export default UserManagement;