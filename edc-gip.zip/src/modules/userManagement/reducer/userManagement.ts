import { createUserModel } from "../constants/models"
import { Types } from "./Types"

const initialState = {
    userDetails: null,
    createUser: createUserModel,
    editUser: null,
    allUsersData: null,
    allRoles: null,
    allSites: null,
    userManagementParams: {
        limit: 10,
        offset: 0,
        userName: ""
    },
    approveOrRejectStudy: ''
}

export const userManagement = (state = initialState, action: { type: any, payload: any }) => {
    switch (action.type) {
        case Types.GET_ALL_USERS_DATA:
            return { ...state, allUsersData: action.payload }
        case Types.FETCH_USER:
            return { ...state, userDetails: action.payload }
        case Types.CREATE_USER:
            return { ...state, createUser: action.payload }
        case Types.USER_PARAMS:
            return { ...state, userManagementParams: action.payload }
        case Types.FETCH_ALL_ROLES:
            return { ...state, allRoles: action.payload }
        case Types.FETCH_ALL_SITES:
            return { ...state, allSites: action.payload }
        // case Types.APPROVE_OR_REJECT_STUDY_BY_ADMIN:
        //     return { ...state, approveOrRejectStudy: action.payload }
        default:
            return { ...state }
    }
}
