import * as Yup from 'yup';

function validateUserSchema() {
    return Yup.object().shape({
        // userName: userName ? Yup.string().matches(/^[^\s]/, "user name should not start with space").nullable() : Yup.string().required('Please Enter User Name').nullable(),
        userName: Yup.string().nullable()
            .required("Please Enter User Name")
            .min(2, "Too Short!")
            .max(50, "Too Long!"),
        firstName: Yup.string().nullable()
            .required("Please Enter First Name"),
        lastName: Yup.string().nullable()
            .required("Please Enter Last Name"),
        // designation: Yup.string().nullable()
        //     .required("Please Enter Designation"),
        email: Yup.string().nullable()
            .required('Please Enter Email')
            .min(2, "Too Short!")
            .email("Please Enter Valid Email Address")
            .max(50, "Too Long!"),
    })
}
export default validateUserSchema