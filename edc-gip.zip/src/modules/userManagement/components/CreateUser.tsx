import React, { useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Formik, Form, Field} from 'formik';
import { useDispatch, useSelector } from 'react-redux';
import SearchField from "../../../common/searchField/SearchField";
import KeyboardDoubleArrowLeftIcon from '@mui/icons-material/KeyboardDoubleArrowLeft';
import { Types } from "../reducer/Types";
import { editUserManagementData, fetchAllUsersManagementData, fetchUserName, saveUserManagementData, updateUserManagementData , fetchAllRoles, fetchAllSites} from "../actions/actions";
import validateUserSchema from "./validate";
import _ from 'lodash';
import { toastAlert } from "../../../actions/actions";
import { createUserModel } from "../constants/models";
import "../styles/Styles.scss";

function CreateUser() {
    const dispatch = useDispatch()
    const navigate = useNavigate()
    const loaded = React.useRef(false);
    const bindRoles = React.useRef(false);
    const bindSites = React.useRef(false);
    const { createUser, allRoles, allSites, userManagementParams } = useSelector((state: any) => state.userManagement)
    const { currentStudy } = useSelector((state: any) => state.application)
    
    const [userName, setUserName] = React.useState('');
    const [userError, setUserError] = React.useState('');
    const params: any = useParams()

    // console.log("userDetails", userDetails)

    useEffect(() => {
        if (!loaded.current) {
            dispatch({ type: Types.FETCH_ALL_ROLES, payload: null });
            dispatch({ type: Types.FETCH_ALL_SITES, payload: null });
            if (params.id > 0) {
                dispatch(editUserManagementData(params.id, (response: any) => {
                    dispatch({ type: Types.CREATE_USER, payload: response })
                }))
            }
            const payload = currentStudy.id
            dispatch(fetchAllSites(payload))
            const newPayload = { limit: null, studyId: currentStudy.id, roleName: "" }
            dispatch(fetchAllRoles(newPayload))
            loaded.current = true
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    useEffect(() => {
        if (createUser?.userId > 0 && allRoles && allRoles.length > 0 && !bindRoles.current) {
            const _allRoles = [...[], ...allRoles]
            allRoles && allRoles?.map((role: any, roleIndex: any) => {
                createUser.rolesList.map((item: any) => {
                    if (item.id === role.id) {
                        _allRoles[roleIndex] = { ...role, checked: true }
                    }
                    return null
                })
                return null
            })
            dispatch({ type: Types.FETCH_ALL_ROLES, payload: _allRoles })
            bindRoles.current = true
        }
    }, [allRoles, createUser,dispatch]);

    useEffect(() => {
        if (createUser?.userId > 0 && allSites && allSites.length > 0 && !bindSites.current) {
            const _allSites = [...[], ...allSites]
            allSites && allSites.map((site: any, siteIndex: number) => {
                createUser.sitesList.map((item: any) => {
                    if (item.id === site.id) {
                        _allSites[siteIndex] = { ...site, checked: true }
                    }
                    return null
                })
                return null
            })
            dispatch({ type: Types.FETCH_ALL_SITES, payload: _allSites })
            bindSites.current = true
        }
    }, [allSites, createUser,dispatch])

    const backToUserManagement = () => {
        const _payload = { ...{}, ...userManagementParams, offset: 0, limit: userManagementParams.limit, userName: '' }
        dispatch({ type: Types.USER_PARAMS, payload: _payload })
        dispatch({ type: Types.CREATE_USER, payload: createUserModel })
        navigate('/usermanagement')
    }


    function onChangeHandler(value: any) {
        setUserName(value);
    }

    const onUserNameSearch = () => {
        // const user = allUsersData && allUsersData.userDetails.find((user: any) => (user && user.userName === userName));
        // console.log("user", user)
        setUserError('');
        dispatch(fetchUserName(userName, (response: any) => {
            if (!response.userName) {
                setUserError("This user doesn't  exits in our GPU. Please try with valid user!");
            }
            else if (response.userName) {
                dispatch({
                    type: Types.CREATE_USER, payload: {
                        ...createUser, userName: response.userName, firstName: response.firstName, lastName: response.lastName,
                        email: response.email,
                    }
                })
            }
            // else {
            //     setUserError('User Already Exits');
            // }
        }));
    }

    const onSelectSite = (e: any, item: any, index: any, values: any) => {
        const _values = _.cloneDeep(values);
        const _allSites = [...[], ...allSites]
        _allSites[index].checked = e.target.checked;
        if (e.target.checked === true) {
            _values.sitesList.push({ id: item.id, site: item.siteName })
        } else {
            const _index: any = _values.sitesList.findIndex((i: any) => i.id === item.id);
            _values.sitesList.splice(_index, 1);
        }
        dispatch({ type: Types.CREATE_USER, payload: _values });
        dispatch({ type: Types.FETCH_ALL_SITES, payload: _allSites })
    };

    const onSelectRole = (e: any, item: any, index: any, values: any) => {
        const _values: any = _.cloneDeep(values);
        const _allRoles = [...[], ...allRoles]
        _allRoles[index].checked = e.target.checked;
        if (e.target.checked === true) {
            _values.rolesList.push({ id: item.id, role: item.name })
        } else {
            const _index: any = _values.rolesList.findIndex((i: any) => i.id === item.id)
            _values.rolesList.splice(_index, 1)
        }
        dispatch({ type: Types.CREATE_USER, payload: _values });
        dispatch({ type: Types.FETCH_ALL_ROLES, payload: _allRoles });
    }

    const onSubmitUser = (values: any) => {
        const _payload = { ...values }
        dispatch({ type: Types.CREATE_USER, payload: _payload })
        dispatch((!_payload.userId ? saveUserManagementData : updateUserManagementData)(_payload, (response: any) => {
            dispatch(toastAlert({ status: 0, message: response, open: true }))
            const payload = { ...userManagementParams, offset: userManagementParams.offset, limit: userManagementParams.limit }
            dispatch(fetchAllUsersManagementData(payload))
            navigate('/usermanagement')
        }))
    }

    return (
        <div className='container'>
            <div className="user-details">
                <div className="user-header">
                    <h2>User Details</h2>
                    <span onClick={backToUserManagement} className="btn-back"><KeyboardDoubleArrowLeftIcon /> Back To User Management</span>
                </div>
                <hr className=""></hr>
                {/* <div className="col-sm-3">
                    <label>User Name</label>
                    <SearchField
                        placeholder='Search with User Name'
                        onChange={onSearchUserName} />
                </div> */}
            </div>
            <Formik
                enableReinitialize={true}
                initialValues={createUser}
                validationSchema={validateUserSchema}
                onSubmit={(values) => {
                    onSubmitUser(values)

                }}>
                {({ errors, touched, values, setFieldValue }) => (
                    <Form id="createUser">
                        <div className="user-details">
                            {/* <>{console.log("values", values)}</> */}
                            {/* {message && (
                                <p className="error  text-center">
                                    <i className='pi pi-exclamation-triangle  text-danger' ></i>
                                    <span className="" style={{ color: 'red', marginLeft: 10 }}>{message}</span>
                                </p>
                            )} */}
                            <div className=''>
                                {/* <>{console.log("errors", errors)}</> */}
                                <div className='text-danger'>{userError}</div>
                                <div className='col-3 pe-4'>
                                    <label id='label' >User Name :<span className='text-danger mx-1'>*</span></label>
                                    <SearchField
                                        name="userName"
                                        value={values.userName}
                                        placeholder="User Name"
                                        onChange={(e: any) => {
                                            if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) === false && e.target.value.length === 0)) {
                                                setFieldValue("userName", e.target.value);
                                            }
                                            onChangeHandler(e.target.value);
                                            setFieldValue('firstName', '')
                                            setFieldValue('lastName', '')
                                            setFieldValue('email', '')
                                            // setFieldValue('designation', '')
                                        }}
                                        onClearSearch={() => {
                                            setFieldValue('userName', '')
                                            setFieldValue('firstName', '')
                                            setFieldValue('lastName', '')
                                            setFieldValue('email', '')
                                            setUserError('')
                                            // setFieldValue('designation', '')
                                            dispatch({ type: Types.CREATE_USER, payload: createUserModel })
                                        }}
                                        onSearchHandler={()=>onUserNameSearch()}
                                    />
                                    {/* <div className='d-flex'>
                                        <Field
                                            className="form-control"
                                            name="userName"
                                            id='userName'
                                            value={values.userName}
                                            placeholder={"User Name"}
                                            // disabled={values.userName ? true : false}
                                            onChange={(e: any) => {
                                                if ((/^[^\s]/.test(e.target.value) && !e.target.value.includes('  ')) || (/^[^\s]/.test(e.target.value) == false && e.target.value.length == 0)) {
                                                    setFieldValue("userName", e.target.value);
                                                }
                                                onChangeHandler(e.target.value);
                                                setFieldValue('firstName', '')
                                                setFieldValue('lastName', '')
                                                setFieldValue('email', '')
                                                // setFieldValue('designation', '')
                                            }}
                                        >
                                        </Field>
                                        {
                                            values.userName.length > 0 && <span className='position-relative'><CloseIcon
                                                className='closeIcon'
                                                // onClick={() => { onClearUserName() }}
                                                onClick={() => {
                                                    setFieldValue('userName', '')
                                                    setFieldValue('firstName', '')
                                                    setFieldValue('lastName', '')
                                                    setFieldValue('email', '')
                                                    setUserError('')
                                                    // setFieldValue('designation', '')
                                                    dispatch({ type: Types.CREATE_USER, payload: createUserModel })
                                                }}
                                            />
                                            </span>
                                        }
                                        <div className='col-2 me-4' > <SearchIcon onClick={(e) => { onUserNameSearch() }} /></div>
                                    </div> */}
                                    <div className='text-danger'>
                                        {errors.firstName && touched.firstName ? <div>{errors.firstName as string}</div> : null}
                                    </div>
                                </div>
                            </div>
                            <div className='row'>
                                <div className='col-3'>
                                    <div className='form-group '>
                                        <label id='label'> First Name :<span className='text-danger mx-1'>*</span></label>
                                        <Field
                                            className="form-control"
                                            name="firstName"
                                            value={values.firstName}
                                            id='txt-firstName'
                                            disabled={true}
                                        />
                                        <div className='text-danger'>
                                            {errors.firstName && touched.firstName ? <div>{errors.firstName as string}</div> : null}
                                        </div>
                                    </div>
                                </div>
                                <div className='col-3'>
                                    <div className='form-group  '>
                                        <label id='label' > Last Name :<span className='text-danger mx-1'>*</span> </label>
                                        <Field
                                            className="form-control "
                                            name="lastName"
                                            value={values.lastName}
                                            id='txt-lastName'
                                            disabled={true}
                                        />
                                        {errors.lastName && touched.lastName ? (
                                            <div className='text-danger'>{errors.lastName as string}</div>
                                        ) : null}

                                    </div>
                                </div>
                                <div className='col-3'>
                                    <div className='form-group'>
                                        <label id='label'>Email:<span className='text-danger mx-1'>*</span> </label>
                                        <Field
                                            className="form-control "
                                            name="email"
                                            value={values.email}
                                            id='txt-email'
                                            disabled={true}
                                        />
                                        {errors.email && touched.email ? (
                                            <div className='text-danger'>{errors.email as string}</div>
                                        ) : null}
                                    </div>
                                </div>
                                {/* <div className='col-3'>
                                    <div className='form-group'>
                                        <label id='label'>Designation:<span className='text-danger mx-1'>*</span> </label>
                                        <Field
                                            className="form-control "
                                            name="designation"
                                            value={values.designation}
                                            id='txt-designation'
                                        // disabled={true}
                                        />
                                        {errors.designation && touched.designation ? (
                                            <div className='text-danger'>{errors.designation as string}</div>
                                        ) : null}
                                    </div>
                                </div> */}
                            </div>
                            <hr></hr>
                            <div className="row sites-roles">
                                <div className="sites">
                                    <h4>Sites</h4>
                                    <ul>
                                        {allSites && allSites?.map((item: any, index: any) => {
                                            return (
                                                <div className="sites-roles-list" key={index}>
                                                    <input
                                                        type="checkbox"
                                                        checked={item && item.checked}
                                                        onChange={(e: any) => onSelectSite(e, item, index, values)} />
                                                    <label className="ms-2">{item.siteName}</label>
                                                </div>
                                            )
                                        })}
                                    </ul>
                                </div>
                                <div className="roles">
                                    <h4>Roles</h4>
                                    <ul>
                                        {allRoles && allRoles.map((item: any, index: any) => {
                                            return (
                                                <div className="sites-roles-list" key={index}>
                                                    <input
                                                        type="checkbox"
                                                        checked={item && item.checked}
                                                        onChange={(e: any) => onSelectRole(e, item, index, values)} />
                                                    <label className="ms-2">{item.name}</label>
                                                </div>
                                            )
                                        })}
                                    </ul>
                                </div>
                            </div>
                            <div className="d-flex mt-2 justify-content-end">
                                <button type='submit' className="btn-eprimary">Submit</button>
                            </div>
                            <div>
                            </div>
                        </div>
                    </Form>
                )}
            </Formik>
        </div >
    )
}
export default CreateUser;