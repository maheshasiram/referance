import React, { useState } from "react";
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { Column } from 'primereact/column'
import { DataTable } from 'primereact/datatable'
// import SearchField from '../../../common/searchField/SearchField';
// import PersonRemoveIcon from '@mui/icons-material/PersonRemove';
import ReplayIcon from '@mui/icons-material/Replay';
// import LockResetIcon from '@mui/icons-material/LockReset';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import { fetchAllUsersManagementData, deleteUser, restoreUser } from "../actions/actions";
import { Types } from "../reducer/Types";
import { Confirm, toastAlert } from "../../../actions/actions";
import "../styles/Styles.scss"
function UserManagementDashboard() {

    const dispatch = useDispatch()
    const navigate = useNavigate()
    const loaded = React.useRef(false);
    const [pageClick, setpageChange] = useState(false);
    const { userManagementParams, allUsersData } = useSelector((state: any) => state.userManagement);

    React.useEffect(() => {
        if (!loaded.current) {
            const _payload = { ...userManagementParams, offset: userManagementParams.offset, limit: userManagementParams.limit }
            dispatch(fetchAllUsersManagementData(_payload))
            loaded.current = true
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    const onEditUserDetails = (rowData: any) => {
        navigate(`./createUser/${rowData.userId}`)
        dispatch({ type: Types.FETCH_ALL_ROLES, payload: null });
        dispatch({ type: Types.FETCH_ALL_SITES, payload: null });
    }

    const onDeleteRestoreUser = (type: any, rowData: any) => {
        dispatch(Confirm({
            status: 0,
            message: type === 'delete' ? 'do you want to delete User' : 'do you want to restore User',
            onOk: () => {
                dispatch((type === 'delete' ? deleteUser : restoreUser)(rowData.userId, (response: any) => {
                    dispatch(toastAlert({
                        status: 1,
                        message: response,
                        open: true
                    }))
                    const payload = { ...userManagementParams, offset: userManagementParams.offset, limit: userManagementParams.limit }
                    dispatch(fetchAllUsersManagementData(payload))
                }))
            }
        }))
    }
    
    const actionsBodyTemplate = (rowData: any) => {
        return (
            <React.Fragment>
                <div className='actions d-flex' onClick={(e) => e.stopPropagation()}>
                    {rowData.isActive === true ?
                        <React.Fragment>
                            <EditIcon className='me-1' style={{ fontSize: '13px' }} onClick={() => onEditUserDetails(rowData)} />  <span>|</span>
                            <DeleteIcon className=' text-danger ms-1' style={{ fontSize: '17px' }} onClick={() => onDeleteRestoreUser('delete', rowData)} />
                        </React.Fragment> :
                        <ReplayIcon className='ms-1' style={{ fontSize: '13px' }} onClick={() => onDeleteRestoreUser('restore', rowData)} />
                    }
                </div>
                {/* <LockResetIcon className='mx-1' style={{ fontSize: '15px' }} onClick={() => onRestoreUser(rowData)} /> */}
            </React.Fragment>
        )
    }

    const onPageChange = (event: any) => {
        if (((event.page > 0 )|| (pageClick && event.page === 0))) {
            const _payload = { ...userManagementParams, offset: event.first }
            dispatch({ type: Types.USER_PARAMS, payload: _payload })
            dispatch(fetchAllUsersManagementData(_payload))
            setpageChange(true)
        }
    }

    return (
        <React.Fragment>
                <DataTable
                    // scrollable
                    value={allUsersData && allUsersData.userDetails}
                    emptyMessage="No Users are available to display"
                    rows={userManagementParams.limit}
                    paginator={allUsersData && allUsersData.totalRecords > userManagementParams.limit ? true : false}
                    first={userManagementParams.offset}
                    totalRecords={allUsersData?.totalRecords}
                    // scrollHeight="300px
                    lazy onPage={onPageChange}  responsiveLayout='scroll'
                     >
                    <Column field="userName" header="User Name"></Column>
                    <Column field="email" header="Email"></Column>
                    <Column field="firstName" header="First Name"></Column>
                    <Column field="lastName" header="Last Name"></Column>
                    <Column field="designation" header="Designation"></Column>
                    <Column body={actionsBodyTemplate} header="Actions"></Column>
                </DataTable>
        </React.Fragment>
    )
}
export default UserManagementDashboard;