import { createUser} from "./dataTypes";

export const createUserModel: createUser = {
    userName: "",
    firstName: "",
    lastName: "",
    rolesList: [],
    sitesList: [],
    designation: "",
    userId: 0,
    email: ""
}   