export const usersData = [
    {
        "userName": "schimakurthy",
        "firstName": "santhoshi",
        "lastName": "chimakurthy",
        "rolesList": [
            {
                "id": 1,
                "role": "Study Developer"
            },
            {
                "id": 2,
                "role": "CRC"
            }
        ],
        "sitesList": [
            {
                "id": 1,
                "site": "Clicnical Hospital"
            },
            {
                "id": 2,
                "site": "KMISA"
            }
        ],
        "designation": "Requestor",
        "userId": 9,
        "email": "santhoshi.chimakurthy@inductivequotient.com"
    },
    {
        "userName": "Rchitturi",
        "firstName": "Ram",
        "lastName": "chitturi",
        "rolesList": [],
        "sitesList": [],
        "designation": "requestor",
        "userId": 1,
        "email": "R@gmail.com"
    },
    {
        "userName": "SrinivasK",
        "firstName": "Srinivas",
        "lastName": "Kolluju",
        "rolesList": [],
        "sitesList": [],
        "designation": "requestor",
        "userId": 2,
        "email": "K@gmail"
    },
    {
        "userName": "PPrajapathi",
        "firstName": "Pankaj",
        "lastName": "Prajapathi",
        "rolesList": [],
        "sitesList": [],
        "designation": "requestor",
        "userId": 3,
        "email": "P@gmail"
    },
    {
        "userName": "RavikumarN",
        "firstName": "Ravikumar",
        "lastName": "N",
        "rolesList": [],
        "sitesList": [],
        "designation": "requestor",
        "userId": 4,
        "email": "N@gmail"
    },
    {
        "userName": "IQA",
        "firstName": "Inductive",
        "lastName": "Quatient",
        "rolesList": [],
        "sitesList": [],
        "designation": "requestor",
        "userId": 5,
        "email": "chandrasekhar.p@inductivequotient.com"
    },
    {
        "userName": "sbhattar",
        "firstName": "sravani",
        "lastName": "korukondabhattar",
        "rolesList": [
            {
                "id": 3,
                "role": "Study_Des"
            }
        ],
        "sitesList": [
            {
                "id": 3,
                "site": "Clicnical Hospital"
            }
        ],
        "designation": "developer",
        "userId": 10,
        "email": "sravani.korukondabhattar@inductivequotient.com"
    },
    {
        "userName": "GaneshK",
        "firstName": "Ganesh",
        "lastName": "Kanthi",
        "rolesList": [],
        "sitesList": [],
        "designation": "requestor",
        "userId": 7,
        "email": "K@gmail.com"
    }
]