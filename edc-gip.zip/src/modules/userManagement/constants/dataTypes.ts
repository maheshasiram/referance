


export type createUser =
    {
        userName?: string,
        firstName?: string,
        lastName?: string,
        rolesList?: [],
        sitesList?: [],
        designation?: string,
        userId?: number,
        email?: string
    }