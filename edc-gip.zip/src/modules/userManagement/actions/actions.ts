import { studySetup } from "../../../configs/enivornment/studySetup";
import { fetch } from "../../../constants/fetch";
import { Types } from "../reducer/Types";
import { Loader } from "../../../actions/actions";


//fethc All UserDeatils
export const fetchAllUsersManagementData: any = (payload: any) => {
    const url = `${studySetup.userManagement.fetchAllUsersManagementData}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
            data: payload
        }).then((response: any) => {
            dispatch({ type: Types.GET_ALL_USERS_DATA, payload: response.data })
            dispatch(Loader(false))
        })
    }
}

//Get UserBy UserName
export const fetchUserName: any = (userName: any, callback: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: `${studySetup.userManagement.getUserByUserName}?userName=${userName}`
        }).then((response: any) => {
            if (callback) {
                callback(response.data)
            }
            dispatch(Loader(false))
        })
    }
}

//Edit User
export const editUserManagementData: any = (id: any, callback: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: `${studySetup.userManagement.editUserManagementData}/${id}`,
        }).then((response: any) => {
            // dispatch({ type: Types.EDIT_USER, payload: response.data })
            if (callback) {
                callback(response.data)
                dispatch(Loader(false))
            }
        })
    }
}

export const fetchAllRoles: any = (payload: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: studySetup.roles.fetchAllRolesByStudyId,
            data: payload
        })
            .then((response: any) => {
                dispatch({ type: Types.FETCH_ALL_ROLES, payload: response.data.roles })
                dispatch(Loader(false))
            }).catch((err) => {
                console.log("...err", err)
            })
    }
}

// Fetch All Sites
export const fetchAllSites: any = (studyId: any) => {
    const url = `${studySetup.sites.findAllSitesByStudyId}?studyId=${studyId}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'GET',
            url: url,
        })
            .then((response: any) => {
                // console.log("response all sites....82",response.data.sites)
                dispatch({ type: Types.FETCH_ALL_SITES, payload: response.data.sites })
                dispatch(Loader(false))
            })
    }
}

export const saveUserManagementData: any = (payload: any, callback: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: studySetup.userManagement.saveUserManagementData,
            data: payload
        }).then((response: any) => {
            if (callback) {
                callback(response.data)
            }
            dispatch(Loader(false))
        })
    }
}

export const updateUserManagementData: any = (payload: any, callback: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: studySetup.userManagement.updateUserManagementData,
            data: payload
        }).then((response: any) => {
            if (callback) {
                callback(response.data)
            }
            dispatch(Loader(false))
        })
    }
}



export const deleteUser: any = (id: any, callback: any) => {
    const url = `${studySetup.userManagement.deleteUserManagementData}?id=${id}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url,
        }).then((response: any) => {
            if (callback) {
                callback(response.data)
                dispatch(Loader(false))
            }
        })
    }
}

export const restoreUser: any = (id: any, callback: any) => {
    const url = `${studySetup.userManagement.restoreUserManagementData}?id=${id}`
    return function (dispatch: any) {
        dispatch(Loader(false))
        fetch({
            method: 'POST',
            url: url
        }).then((response: any) => {
            if (callback) {
                callback(response.data)
            }
        })
    }
}
export const approveOrRejectStudyByAdmin: any = (payload: any, callback: any) => {
    const url = `${studySetup.userManagement.approveOrRejectStudyByAdmin}?userName=${payload.userName}&status=${payload.status}`
    return function (dispatch: any) {
        dispatch(Loader(true))
        fetch({
            method: 'POST',
            url: url
        }).then((response: any) => {

            if (callback) {
                callback(response.data)
                dispatch(Loader(false))

            }
        })
    }
}
