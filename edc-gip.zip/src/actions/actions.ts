
import { studySetup } from "../configs/enivornment/studySetup"
import { Types } from "../constants/Types"
import { fetch } from "../constants/fetch"
import { getCurrentStudyDetails } from "../modules/studySetup/modules/study/actions/actions"
export const Alert: any = (data: any) => {
  return (dispatch: any) => {
    dispatch({
      type: Types.ON_OPEN_ALERT_DIALOG,
      payload: {
        ...data,
        header: 'Alert',
        open: true
      }
    })
  }
}

export const Confirm: any = (data: any) => {
  return (dispatch: any) => {
    dispatch({
      type: Types.ON_OPEN_ALERT_DIALOG,
      payload: {
        ...data,
        header: 'Confirm',
        open: true
      }
    })
  }
}

export const Loader = (payload: any) => {
  return (dispatch: any) => {
    dispatch({ type: Types.ON_SET_LOADER, payload })
  }
}

// api for study setup config data
export const configDataType: any = (param: any, callback: any) => {
  const url = `${studySetup.configDataType}/${param}`
  return function (dispatch: any) {
    fetch({
      method: 'GET',
      url: url,
      data: null,
    })
      .then((response: any) => {
        if (callback) { callback(response.data) }

      }).catch((error:any)=>{
        console.log('error',error)
        dispatch(Loader(false))
      })
  }
}


export const toastAlert: any = (payload: any) => {
  return (dispatch: any) => {
    dispatch({
      type: Types.IS_TOAST_ENABLED,
      payload
    })
  }
}

export const getAllStudies: any = () => {
  const url = `${studySetup.study.fetchAllStudies}`
  return function (dispatch: any) {
    fetch({
      method: 'GET',
      url: url,
      data: ''
    })
      .then((response: any) => {
        dispatch({ type: Types.FETCH_STUDIES, payload: response.data });
        const Study = response.data.find((item: any) => item.status === true);
        if (Study) {
          dispatch(getCurrentStudyDetails(Study.id, (data: any) => {
            dispatch({ type: Types.FETCH_STUDY_DETAILS, payload: data })
          }))
        }
      })
  }
}

export const dataEntryNavigation: any = (payload: any) => {
  return (dispatch: any) => {
    dispatch({
      type: Types.UPDATE_DATAENTRY_PAGES,
      payload
    })
  }
}

export const findAllCountries: any = () => {
  const url = studySetup.countries.findAllCountries
  return function (dispatch: any) {
    fetch({
      method: 'GET',
      url: url
    })
      .then((response: any) => {
        dispatch({ type: Types.FETCH_ALL_COUNTRIES, payload: response.data })
      })
  }
}

export const findStateByCountryId: any = (countryId: any) => {
  const url = `${studySetup.countries.findStateByCountryId}?countryId=${countryId}`
  return function (dispatch: any) {
    fetch({
      method: 'GET',
      url: url
    })
      .then((response: any) => {
        dispatch({ type: Types.FETCH_STATES_BY_COUNTRY_ID, payload: response.data })
      })
  }
}

export const findCitiesByStateId: any = (stateId: any) => {
  const url = `${studySetup.countries.findCitiesByStateId}?stateId=${stateId}`
  return function (dispatch: any) {
    fetch({
      method: 'GET',
      url: url
    })
      .then((response: any) => {
        dispatch({ type: Types.FETCH_CITIES_BY_STATE_ID, payload: response.data })
      })
  }
}


export const fetchCurrentStudy: any = (payload: any) => {
  console.log("133.........", payload)
  return (dispatch: any) => {
    dispatch({
      type: Types.FETCH_STUDY_DETAILS,
      payload: payload
    })
  }

}

export const fetchAllConfigData: any = (callback:any) => {
  return (dispatch: any) => {
    // dispatch(Loader(true));
    const url = `${studySetup.allConfigCodes}`;
    fetch({
    method:'GET',
    url: url
    }).then((response:any) =>{
      dispatch({ type: Types.CONFIG_CODES, payload: response.data })
      if(callback){callback(response.data)}
    })
  }
}