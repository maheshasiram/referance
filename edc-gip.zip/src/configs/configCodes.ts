export const congifCodes = {
   study: {
  
   },
   sites: {
     
   },
   visits: {
      
   },
   forms: {
      
      field: {
      
      },
      group: {
         
   },

   fieldLevelDynamics: {
   
   },
   derivations: {

   },
   labranges: {
      
   },
   rules: {
    
   },
   auditLogs: {
      
   },
   labs: {

   },
   userManagement: {
     
   }
}
}