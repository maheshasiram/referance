export const name = 'Clinical Platform App';
