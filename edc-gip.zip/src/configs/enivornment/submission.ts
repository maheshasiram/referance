import { baseUrl } from './env';

export const Submission = {
    casebooks: {
        fetchAllSubjects: (baseUrl + '/dataEntry/casebooks/v1/fetchAllSubjects'),
    },
}