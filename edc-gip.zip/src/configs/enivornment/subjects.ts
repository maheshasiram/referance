import { baseUrl } from './env'

export const subjects = {
    volunteers: {
        fetchAllVolunteers: (baseUrl + '/dataEntry/subject/v1/findAllSubjectsByCriteria'),
        statusList: (baseUrl + '/dataEntry/subject/v1/statusSubjectList'),
        sitesList: (baseUrl + '/dataEntry/subject/v1/sitesList'),
        addSubject: (baseUrl + '/dataEntry/subject/v1/addSubject'),
        // deleteSubject: (baseUrl + "/dataEntry/subject/v1/deleteSubject"),
        // restoreSubject: (baseUrl + '/dataEntry/subject/v1/restoreSubject'),
        // subjectSitesList: (baseUrl + '/dataEntry/subject/v1/subjectSitesList')
    },
    visits: {
        findAllBySubjectId: (baseUrl + '/dataEntry/subjectVisit/v1/findAllBySubjectId'),
        unlock: (baseUrl + '/dataEntry/subjectVisit/v1/unlock'),
        lock: (baseUrl + '/dataEntry/subjectVisit/v1/lock'),
        save: (baseUrl + '/dataEntry/subjectVisit/v1/save'),
        getById: (baseUrl + '/dataEntry/subjectVisit/v1/getById'),
        addUnscheduledVisit: (baseUrl + '/dataEntry/subjectVisit/v1/addUnscheduledVisit'),
        addScheduledVisit: (baseUrl + '/dataEntry/subjectVisit/v1/addScheduledVisit'),
        findAllByCriteria: (baseUrl + '/dataEntry/subjectVisit/v1/findAllByCriteria'),


    },
    forms: {
        findAllBySubjectVisitId: (baseUrl + '/dataEntry/subjectForm/v1/findAllBySubjectVisitId'),
        createRepeatForm: (baseUrl + '/dataEntry/subjectForm/v1/createRepeatForm'),
        fetchByMappingForm: (baseUrl + '/dataEntry/subjectForm/v1/fetchByMappingForm'),
        lock: (baseUrl + '/dataEntry/subjectForm/v1/lock'),
        unlock: (baseUrl + '/dataEntry/subjectForm/v1/unlock'),
        markNotComplete: (baseUrl + '/dataEntry/subjectForm/v1/markNotComplete'),
        restoreNotComplete: (baseUrl + '/dataEntry/subjectForm/v1/restoreNotComplete'),
        findSubjectFormsByUnscheduledVisitId: (baseUrl + '/dataEntry/subjectForm/v1/findSubjectFormsByUnscheduledVisitId'),

    },
    dataEntry: {
        getFormsDetailsId: (baseUrl + '/dataEntry/form/v1/getFormsDetailsId'),
        saveFormData: (baseUrl + '/dataEntry/subjectForm/v1/save'),
        getDynamicFormData: (baseUrl + '/dataEntry/subjectForm/v1'),
        getFieldLevelDynamics: (baseUrl + '/dataEntry/common/v1/fetchFLDs'),
        getDerivations: (baseUrl + '/dataEntry/common/v1/derivativesFormAndVisit'),
        createQuery: (baseUrl + '/dataEntry/query/v1/create'),
        viewQuery: (baseUrl + '/dataEntry/query/v1/fetchAllQueries'),
        dteNoteRequest: (baseUrl + '/dataEntry/dteNoteRequest/v1/addNoteTransaction'),
        getdteNoteRequest: (baseUrl + '/dataEntry/dteNoteRequest/v1/searchById'),
        upadteNoteTransaction: (baseUrl + '/dataEntry/dteNoteRequest/v1/upadteNoteTransaction'),
        updateQuery: (baseUrl + '/dataEntry/query/v1/update'),
        // viewQuery: (baseUrl + '/dataEntry/query/v1/fetchAllQueries'),
        findBySubjectFieldId :(baseUrl + '/dataEntry/dteAuditLog/v1/findBysubjectFieldId'),
        fetchValue :(baseUrl + '/dataEntry/subjectForm/v1/fetchValue'),
        createProtocoDeviations: (baseUrl + '/dataEntry/protocolDeviation/v1/save'),
        getProtocolDeviations: (baseUrl + '/dataEntry/protocolDeviation/v1/findBySubjectFieldDataId'),
        updateStatus: (baseUrl + '/dataEntry/protocolDeviation/v1/updateStatus'),
        fetchResolutionType: (baseUrl + '/dataEntry/query/v1/fetchResolutionType'),
        executeRule: (baseUrl + '/dataEntry/rule/v1/execute'),
    },
    queryListingModule: {
        filterAndFetchQueries: (baseUrl + '/dataEntry/query/v1/search'),
        visitsByStudyId: (baseUrl + '/studySetup/visit/v1/findAllVisitsByStudyId'),
        sitesByStudyId: (baseUrl + '/studySetup/site/v1/findAllSitesByStudyId'),
        formsByStudyId: (baseUrl + '/studySetup/form/v1/getFormsByStudyId'),
        getBySubjectId: (baseUrl + '/dataEntry/query/v1/getBySubjectId'),
        getBySubjectFormId: (baseUrl + '/dataEntry/query/v1/getBySubjectFormId'),
        saveReasonForClose: (baseUrl + '/dataEntry/query/v1/saveReasonForClose'),
        saveResolutionType: (baseUrl + '/dataEntry/query/v1/saveResolutionType'),
        fetch: (baseUrl + '/dataEntry/query/v1/fetch'),
        download: (baseUrl + '/studySetup/query/v1/downloadExcel'),
    }
}