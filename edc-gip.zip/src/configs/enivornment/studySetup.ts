import { baseUrl } from './env'

export const studySetup = {
   configDataType: (baseUrl + '/studySetup/configData/v1/getConfigDataByTypeCode'),
   allConfigCodes: (baseUrl + '/studySetup/configData/v1/fetchAllConfigData'),
   treeViewData: (baseUrl + '/studySetup/form/v1/getVisitFormsTreeViewByStudyId'),
   formula: (baseUrl + '/studySetup/formula/v1/getAllFormulas'),

   countries: {
      findAllCountries: (baseUrl + '/studySetup/country/v1/findAllCountries'),
      findStateByCountryId: (baseUrl + '/studySetup/country/v1/findStatesByCountryId'),
      findCitiesByStateId: (baseUrl + '/studySetup/country/v1/findCitiesByStateId')
   },

   study: {
      findByStudyId: (baseUrl + '/studySetup/study/v1/findByStudyId'),
      editStudy: (baseUrl + '/studySetup/study/v1/saveOrUpdateStudy'),
      fetchAllStudies: (baseUrl + '/studySetup/study/v1/getAllStudies'),
   },

   sites: {
      findSiteBySiteName: (baseUrl + `/studySetup/site/v1/findSiteBySiteName`),
      fetchAllSites: (baseUrl + `/studySetup/site/v1/findAllSites`),
      addSite: (baseUrl + `/studySetup/site/v1/addSite`),
      deleteSite: (baseUrl + `/studySetup/site/v1/deleteSite`),
      restoreSite: (baseUrl + `/studySetup/site/v1/restoreSite`),
      saveOrUpdateSite: (baseUrl + `/studySetup/site/v1/saveOrUpdateSite`),
      findAllSitesByStudyId: (baseUrl + `/studySetup/site/v1/findAllSitesByStudyId`),
      findAllSitesByStudyIdCriteria: (baseUrl + `/studySetup/site/v1/findAllSitesByStudyIdCriteria`)
   },
   visits: {
      fetchVisitsAllByStudyId: (baseUrl + '/studySetup/visit/v1/fetchAllByStudyId'),
      updateDeleteRestoreVist: (baseUrl + '/studySetup/visit/v1/updateVisit'),
      findByVisitName: (baseUrl + '/studySetup/visit/v1/fetchByVisitNameOrFormName'),
      addVisit: (baseUrl + '/studySetup/visit/v1/addVisit'),
      fetchFormsByVisitId: (baseUrl + '/studySetup/visit/v1/getFormsByVisitId'),
      getAssignedFormFields: (baseUrl + '/studySetup/visit/v1/getAssignedFormFields'),
      saveRearrangeForms: (baseUrl + '/studySetup/visit/v1/reArrangeForms'),
      rearrangeVisits: (baseUrl + '/studySetup/visit/v1/fetchAllVisitsByOrdinalOrder'),
      updateVisitOrdinal: (baseUrl + '/studySetup/visit/v1/updateVisitOrdinal'),
      saveSelectFormsAndVariables: (baseUrl + '/studySetup/visit/v1/assignFormFieldsToVisit'),
      deleteOrRestoreVisit: (baseUrl + '/studySetup/visit/v1/deleteOrRestore'),
      fetchFormFieldsAssignedToVisit: (baseUrl + '/studySetup/visit/v1/fetchFormFieldsAssignedToVisit'),
      fetchVisitsAssignedToFormId: (baseUrl + '/studySetup/visit/v1/fetchVisitsAssignedToFormId'),
      findAllVisitsByStudyId: (baseUrl + '/studySetup/visit/v1/findAllVisitsByStudyId'),
      visitDateMapping: (baseUrl + '/studySetup/visit/v1/visitDateMapping'),
      addupdateVisitDateMapping: (baseUrl + '/studySetup/visit/v1/addUpdateVisitDateMapping'),
      fetchVisitsAssignedToFormByStudyId: (baseUrl + '/studySetup/visit/v1/fetchVisitsAssignedToFormByStudyId')
   },
   forms: {
      fetchAllActive: (baseUrl + '/studySetup/form/v1/fetchAllActive'),
      importForm: (baseUrl + '/studySetup/form/v1/importForm'),
      fetchAllByCriteria: (baseUrl + '/studySetup/form/v1/fetchAllByCriteria'),
      edit: (baseUrl + '/studySetup/form/v1/edit'),
      create: (baseUrl + '/studySetup/form/v1/create'),
      activeOrDeActive: (baseUrl + '/studySetup/form/v1/activeOrDeActive'),
      getFormsDetailsId: (baseUrl + '/studySetup/form/v1/getFormsDetailsId'),
      getFormsByStudyId: (baseUrl + '/studySetup/form/v1/getFormsByStudyId'),
      field: {
         importFieldsToForm: (baseUrl + '/studySetup/field/v1/importFieldsToForm'),
         fetchFieldsByFormId: (baseUrl + '/studySetup/field/v1/fetchFieldsByFormId'),
         deleteFields: (baseUrl + '/studySetup/field/v1/delete'),
         restoreFields: (baseUrl + '/studySetup/field/v1/restore'),
         addVariable: (baseUrl + '/studySetup/field/v1/add'),
         updateVariable: (baseUrl + '/studySetup/field/v1/update'),
         getVariableById: (baseUrl + '/studySetup/field/v1/get'),
         updateFieldsOrder: (baseUrl + '/studySetup/field/v1/updateFieldsOrder'),
         fetchVariableFieldsFormat: (baseUrl + '/studySetup/field/v1/fetchVariableFieldsFormat'),
         createUnits: (baseUrl + '/studySetup/field/createUnits'),
         fetchAllUnits: (baseUrl + '/studySetup/field/fetchAllUnits'),
      },
      group: {
         importUngroupedFields: (baseUrl + '/studySetup/group/v1/importUngroupedFields'),
         exportGroupedToUngrouped: (baseUrl + '/studySetup/group/v1/exportGroupToUngroupFields'),
         addGrpoup: (baseUrl + '/studySetup/group/v1/add'),
         updateGrpoup: (baseUrl + '/studySetup/group/v1/update'),
         getGroupbyId: (baseUrl + '/studySetup/group/v1/get'),
         deleteGroup: (baseUrl + '/studySetup/group/v1/delete'),
         restoreGroup: (baseUrl + '/studySetup/group/v1/restore'),
         getAllDefaultValues: (baseUrl + '/studySetup/group/v1/getAllDefaultValues'),
         getAllGroups: (baseUrl + '/studySetup/group/v1/fetchAllActiveGroups'),
         deleteDefaultValues: (baseUrl + '/studySetup/group/v1/deleteDefaultValues'),
         getFieldsForDefaultValues: (baseUrl + '/studySetup/group/v1/getFieldsForDefaultValues'),
         getGroupRows: (baseUrl + '/studySetup/group/v1/getGroupRows'),
         updateGroupRows: (baseUrl + '/studySetup/group/v1/updateGroupRows'),
         addDefaultValue: (baseUrl + '/studySetup/group/v1/addDefaultValue'),
         updateDefaultValues: (baseUrl + '/studySetup/group/v1/updateDefaultValues'),
      },
   },

   dynamics: {
      fetchAllFieldForms: (baseUrl + '/studySetup/fld/v1/fetchAllFLDForms/'),
      deleteFormData: (baseUrl + '/studySetup/fld/v1/delete'),
      restoreFormData: (baseUrl + '/studySetup/fld/v1/restore'),
      fetchAllByCriteria: (baseUrl + '/studySetup/fld/v1/fetchAllByCriteria'),
      save: (baseUrl + '/studySetup/fld/v1/add'),
      update: (baseUrl + '/studySetup/fld/v1/update'),
      get: (baseUrl + '/studySetup/fld/v1/get'),
      treeView: (baseUrl + '/studySetup/form/v1/getFormsDetailsIdTreeView'),
      fetchAllFormsOptionalVariables: (baseUrl + `/studySetup/form/v1/getVisitAssignedFormsByStudyId`)

   },
   derivations: {
      fetchAllDerivationsFroms: (baseUrl + '/studySetup/derivatives/v1/fetchAllFormsByDerivativeCreated'),
      deleteDerivative: (baseUrl + '/studySetup/derivatives/v1/deleteDerivative'),
      restoreDerivative: (baseUrl + '/studySetup/derivatives/v1/restoreDerivative'),
      findDerivative: (baseUrl + '/studySetup/derivatives/v1/findByFormId'),
      searchByTargetVariableCriteria: (baseUrl + '/studySetup/derivatives/v1/searchByTargetVariableCriteria'),
      searchByDerivationType: (baseUrl + '/studySetup/derivatives/v1/fetchAllActionTypeByDerivativeCreated'),
      saveDerivation: (baseUrl + '/studySetup/derivatives/v1/saveDerivative'),
      updateDerivation: (baseUrl + '/studySetup/derivatives/v1/updateDerivative'),
      fetchVisitsAssignedToFieldId: (baseUrl + '/studySetup/visit/v1/fetchVisitsAssignedToFieldId'),
      // editDerivation: (baseUrl + '/studySetup/derivatives/v1/getDerivationByDerivationId'),
      editDerivation: (baseUrl + '/studySetup/derivatives/v1/getDerivative'),
      findByAllByCriteria: (baseUrl + '/studySetup/derivatives/v1/findAllByCriteria'),
      units: (baseUrl + '/studySetup/derivatives/v1/units')
   },
   labranges: {
      findAllLabFormsByStudyId: (baseUrl + '/studySetup/labRange/v1/findAllLabFormsByStudyId'),
      getGroupsToAddLabRange: (baseUrl + '/studySetup/labRange/v1/getGroupsToAddLabRange'),
      findAllLabRanges: (baseUrl + '/studySetup/labRange/v1/findAllLabRanges'),
      getGroupFieldDefaultValues: (baseUrl + '/studySetup/labRange/v1/getGroupFieldDefaultValues'),
      fetchGenderForms: (baseUrl + '/studySetup/labRange/v1/fetchGenderForms'),
      fetchAgeForms: (baseUrl + '/studySetup/labRange/v1/fetchAgeForms'),
      fetchMultiLabFields: (baseUrl + '/studySetup/labRange/v1/fetchMultiLabFields'),
      saveOrUpdateLabForm: (baseUrl + '/studySetup/labRange/v1/saveOrUpdateLabForm'),
      deleteLabForm: (baseUrl + '/studySetup/labRange/v1/deleteLabForm'),
      // updateLabForm: (baseUrl + 'labRange/v1/updateLabForm'),
      getAllLabforms: (baseUrl + '/studySetup/labRange/v1/findAllFormGroupDefaultValues'),
      search: (baseUrl + '/studySetup/labRange/v1/fetchAllByCriteria'),
      deleteLabRange: (baseUrl + '/studySetup/labRange/v1/deleteLabRangesByLabId'),
      saveUpdateLabRange: (baseUrl + '/studySetup/labRange/v1/saveOrUpdateLabRange'),
      fetchAllLabRangesByCriteria: (baseUrl + '/studySetup/labRange/v1/fetchAllLabRangesByCriteria'),
   },
   rules: {
      fetchAllRules: (baseUrl + '/studySetup/rules/v1/fetchAllRules'),
      fetchAllByCriteria: (baseUrl + '/studySetup/rules/v1/fetchAllByCriteria'),
      fetchAllFormsForRulesDefined: (baseUrl + '/studySetup/rules/v1/fetchAllFormsForRulesDefined'),
      deleteRule: (baseUrl + '/studySetup/rules/v1/deleteRules'),
      fetchRulesByActionId: (baseUrl + '/studySetup/rules/v1/fetchRulesByActionId'),
      saveOrUpdateRule: (baseUrl + '/studySetup/rules/v1/saveOrUpdateRule'),
      fetchVisitFormTreeViewByStudyId: (baseUrl + '/studySetup/rules/v1/fetchVisitFormTreeViewByStudyId'),
      editRule: (baseUrl + '/studySetup/rules/v1/findByRuleId'),
      deleteAndRestoreRule: (baseUrl + '/studySetup/rules/v1/restoreOrDeleteRules')
   },
   roles: {
      fetchAllRolesByStudyId: (baseUrl + '/studySetup/role/v1/fetchAllRolesByStudyId'),
      fetchAllRoles: (baseUrl + '/studySetup/role/v1/fetchAllRoles'),
      fetchAllPrivileges: (baseUrl + '/studySetup/privilegeGroup/v1/getAllPrivilegesAssignedToGroup'),
      insertNewPrivilegesToGroup: (baseUrl + '/studySetup/privilegeGroup/v1/insertNewPrivilegesToGroup'),
      deleteRoleByRoleId: (baseUrl + '/studySetup/role/v1/deleteRoleByRoleId'),
      createRole: (baseUrl + '/studySetup/role/v1/createRole'),
      updateRole: (baseUrl + '/studySetup/role/v1/updateRole'),
      fetchRolePrivilegesByRoleIdGroupWise: (baseUrl + '/studySetup/role/v1/fetchRolePrivilegesByRoleIdGroupWise'),
      assignPrivilegesToUserRole: (baseUrl + '/studySetup/role/v1/assignPrivilegesToUserRole'),
      restoreRole: (baseUrl + '/studySetup/role/v1/restoreRoleByRoleId'),
      fetchRolePrivilegeFormData: (baseUrl + '/studySetup/rolePrivilegeForm/v1/fetchRolePrivilegeFormData'),
      updateRolePrivilegeFormData: (baseUrl + '/studySetup/rolePrivilegeForm/v1/updateRolePrivilegeFormData')
      // saveRolePrivilegeFormData: (baseUrl + `rolePrivilegeForm/v1/saveRolePrivilegeFormData`)


   },
   auditLogs: {
      fetchAuditLogsByStudyId: (baseUrl + '/studySetup/auditLog/v1/fetchAuditLogsByStudyId')
   },
   labs: {
      //Labs
      fetchAllLabs: (baseUrl + '/studySetup/Lab/getAllLabs'),
      createLab: (baseUrl + '/studySetup/Lab/createLab'),
      restoreLabs: (baseUrl + '/studySetup/Lab/restoreLab'),
      updateLab: (baseUrl + '/studySetup/Lab/updateLab'),
      //Unit
      createUnit: (baseUrl + '/studySetup/Lab/Unit/createUnit'),
      unitsList: (baseUrl + '/studySetup/Lab/Unit/unitsList'), //Not in user
      fetchByUnitName: (baseUrl + '/studySetup/Lab/fetchByUnitName'), //Search by Unit Name //Not in us er
      getAllUnits: (baseUrl + '/studySetup/Lab/Unit/getAllUnits'),
      deleteUnit: (baseUrl + '/studySetup/Lab/Unit/deleteUnit'),
      restoreUnit: (baseUrl + '/studySetup/Lab/Unit/restoreUnit'),
      updateUnit: (baseUrl + '/studySetup/Lab/Unit/updateUnit'),
      //Category
      getAllCategoriesList: (baseUrl + '/studySetup/Lab/Category/getAllCategoriesList'),
      categoriesList: (baseUrl + '/studySetup/Lab/Category/categoriesList'),
      createCategory: (baseUrl + '/studySetup/Lab/Category/createCategory'),
      updateCategory: (baseUrl + '/studySetup/Lab/Category/updateCategory'),
      deleteCategory: (baseUrl + '/studySetup/Lab/Category/deleteCategory'),
      restoreCategory: (baseUrl + '/studySetup/Lab/Category/restoreCategory'),
      fetchByCategoryName: (baseUrl + '/studySetup/Lab/Category/fetchByCategoryName'),
      //Test
      getAllTests: (baseUrl + '/studySetup/Lab/Test/getAllTests'),
      testsList: (baseUrl + '/studySetup/Lab/Test/testsList'),
      fetchByTestName: (baseUrl + '/studySetup/Lab/Test/fetchByTestName'),
      createTest: (baseUrl + '/studySetup/Lab/Test/createTest'),
      updateTest: (baseUrl + '/studySetup/Lab/Test/updateTest'),
      deleteTest: (baseUrl + '/studySetup/Lab/Test/deleteTest'),
      restoreTest: (baseUrl + '/studySetup/Lab/Test/restoreTest'),
      //Labranges
      getAllLabRangesByLabId: (baseUrl + '/studySetup/Lab/getAllLabRangesByLabId'),
      createLabRange: (baseUrl + '/studySetup/Lab/createLabRange'),
      updateLabRange: (baseUrl + '/studySetup/Lab/updateLabRange'),
      deleteLabs: (baseUrl + '/studySetup/Lab/deleteLab'),
      restoreLabRange: (baseUrl + '/studySetup/Lab/restoreLabRange'),
      deleteLabRange: (baseUrl + '/studySetup/Lab/deleteLabRange'),
      fetchByCategoryorTestName: (baseUrl + '/studySetup/Lab/fetchByCategoryorTestName'),
      restoreLab: (baseUrl + '/studySetup/labRanges/restoreLab'),
      deleteLab: (baseUrl + '/studySetup/labRanges/deleteLab'),



   },
   userManagement: {
      fetchAllUsersManagementData: (baseUrl + '/studySetup/UserM/fetchAllUsersManagementData'),
      saveUserManagementData: (baseUrl + '/studySetup/UserM/saveUserManagementData'),
      editUserManagementData: (baseUrl + '/studySetup/UserM/editUserManagementData'),
      deleteUserManagementData: (baseUrl + '/studySetup/UserM/deleteUserManagementData'),
      restoreUserManagementData: (baseUrl + '/studySetup/UserM/restoreUserManagementData'),
      updateUserManagementData: (baseUrl + '/studySetup/UserM/updateUserManagementData'),
      getUserByUserName: (baseUrl + '/studySetup/UserM/getUserByUserName'),
      approveOrRejectStudyByAdmin: (baseUrl + '/studySetup/UserM/approveOrRejectStudyByAdmin'),
   },
   importData: {
      allForms: (baseUrl + '/studySetup/form/v1/getAllForms'),
      downloadExcelTemplate: (baseUrl + '/studySetup/form/v1/downloadExcelTemplate')

   },
   downloads: {
      allDownloads: (baseUrl + '/studySetup/query/v1/fetchAllDownloads')
   },
   bulkLock: {
      subjectFormBulkLock: (baseUrl + '/dataEntry/bulklock/v1/subjectFormBulkLock')
   },
   approvals: {
      bulkReview: (baseUrl + '/studySetup/approvals/v1/BulkReview'),
      bulkMonitor: (baseUrl + '/studySetup/approvals/v1/BulkMonitor'),
      bulkSign: (baseUrl + '/studySetup/approvals/v1/BulkSign'),
   }
}