export const { NODE_ENV = 'development' } = process.env;
// export const baseUrl = 'http://192.168.10.118:8095/study-setup/edc';
declare global {
    interface Window {
        env: any
    }
}
export const baseUrl = window.env.REACT_APP_DOMAIN + '/study-setup/edc';

// export const baseUrl = 'http://10.22.242.78:8090/study-setup/edc/studySetup/';
// export const baseUrl = 'http://10.22.242.56:8090/study-setup/edc';
// export const baseUrl = 'http://10.22.242.56:8090/study-setup/edc'

export const requests = {
    api: {
        fetchAllDerivations: (baseUrl + 'fetchAllDerivations'),
    }
}
