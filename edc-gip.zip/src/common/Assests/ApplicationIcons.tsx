import React from 'react';
import { AnyObject } from 'immer/dist/internal';
import VisibilityRoundedIcon from '@mui/icons-material/VisibilityRounded';
import NoteAltOutlinedIcon from '@mui/icons-material/NoteAltOutlined';
import HighlightOffOutlinedIcon from '@mui/icons-material/HighlightOffOutlined';
import SettingsBackupRestoreIcon from '@mui/icons-material/SettingsBackupRestore';
import GridOnIcon from '@mui/icons-material/GridOn';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import ScheduleIcon from '@mui/icons-material/Schedule';
import TaskIcon from '@mui/icons-material/Task';
import EventBusyIcon from '@mui/icons-material/EventBusy';
import LockIcon from '@mui/icons-material/Lock';
import LockOpenIcon from '@mui/icons-material/LockOpen';
import NearbyErrorIcon from '@mui/icons-material/NearbyError';
import EditIcon from '@mui/icons-material/Edit';
import PasswordIcon from '@mui/icons-material/Password';
import PersonRemoveIcon from '@mui/icons-material/PersonRemove';
import FolderDeleteIcon from '@mui/icons-material/FolderDelete';
import AddCommentIcon from '@mui/icons-material/AddComment';
import SpeakerNotesOffIcon from '@mui/icons-material/SpeakerNotesOff';
import SpeakerNotesIcon from '@mui/icons-material/SpeakerNotes';
import QuestionAnswerIcon from '@mui/icons-material/QuestionAnswer';
import TextSnippetIcon from '@mui/icons-material/TextSnippet';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import SubtitlesOffIcon from '@mui/icons-material/SubtitlesOff';

export const ApplicationIcons: AnyObject = {
    "VisibilityRoundedIcon": () => <VisibilityRoundedIcon  />,
    "NoteAltOutlinedIcon": () => <NoteAltOutlinedIcon  />,
    "HighlightOffOutlinedIcon":()=> <HighlightOffOutlinedIcon />,
    "SettingsBackupRestoreIcon":()=> <SettingsBackupRestoreIcon />,
    "GridOnIcon":()=> <GridOnIcon />,
    "AddCircleOutlineIcon":()=> <AddCircleOutlineIcon />,
    "ScheduleIcon":()=> <ScheduleIcon />,
    "TaskIcon":()=> <TaskIcon />,
    "EventBusyIcon":()=> <EventBusyIcon />,
    "LockIcon":()=> <LockIcon />,
    "LockOpenIcon":()=> <LockOpenIcon />,
    "NearbyErrorIcon":()=> <NearbyErrorIcon />,
    "EditIcon":()=> <EditIcon />,
    "PasswordIcon":()=> <PasswordIcon />,
    "PersonRemoveIcon":()=> <PersonRemoveIcon />,
    "FolderDeleteIcon":()=> <FolderDeleteIcon />,
    "AddCommentIcon":()=> <AddCommentIcon />,
    "SpeakerNotesOffIcon":()=> <SpeakerNotesOffIcon />,
    "SpeakerNotesIcon":()=> <SpeakerNotesIcon />,
    "QuestionAnswerIcon":() => <QuestionAnswerIcon />,
    "TextSnippetIcon":() => <TextSnippetIcon />,
    "CalendarMonthIcon":()=> <CalendarMonthIcon />,
    "SubtitlesOffIcon":()=> <SubtitlesOffIcon />
};