import React from 'react';
import { styled } from '@mui/material/styles';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import '../style.scss'
const BootstrapDialog = styled(Dialog)(() => ({

}));

const BootstrapDialogTitle = (props: any) => {
  const { children, onClose, ...other } = props;
  return (
    <DialogTitle sx={{ m: 0, p: 2, display: 'flex', alignItems: 'center' }} {...other}>
      {children}
      {onClose ? (
        <IconButton
          aria-label="close"
          onClick={onClose}
          sx={{
            position: 'absolute',
            right: 8,
            color: (theme) => theme.palette.grey[500],
          }}
        >
          <CloseIcon />
        </IconButton>
      ) : null}
    </DialogTitle>
  );
};

function CustomDialog(props: any) {

  const onCloseHandler = () => {
    props.onClose();
  }

  return (
    <React.Fragment>
      <BootstrapDialog
        fullWidth={props.fullWidth === false ? false : true}
        maxWidth={props.maxWidth ? props.maxWidth : 'lg'}
        aria-labelledby="emodal-dialog"
        open={props.open}
        className={`md-container ${props.cssName}`}
      >
        <BootstrapDialogTitle className="dialog-header" onClose={onCloseHandler}>
          <span>{props.title}</span>
        </BootstrapDialogTitle>
        <DialogContent className={props.padding ? `p-0 dialog-content` : `dialog-content`}>
          {props.children}
        </DialogContent>
        {props.hideFooter ? '' : <DialogActions>
          <div className='d-flex justify-content-end'>
            {props.actionType === 'Close' ? <button className='btn-esecondary me-3' id="BtnCancel" onClick={() => onCloseHandler()}>{"Close"}</button> : <button className='btn-esecondary me-3' id="BtnCancel" onClick={() => onCloseHandler()}>{"Cancel"}</button>}
            {props.onResetHandler && <button type='reset' form={props.form ? props.form : ''}
              disabled={props.disabled !== undefined ? props.disabled : false}
              className={props.disabled !== undefined ? props.disabled ? "btn-esecondary me-3" : "btn btn-warning me-3 btn-reset" : "btn btn-warning me-3 btn-reset"}
              onClick={props.onResetHandler}>Reset</button>}
            {
              (props.actionType && props.actionType !== 'Close') && <button type='submit' form={props.form ? props.form : ''}
                disabled={props.disabled !== undefined ? props.disabled : false}
                className={props.disabled !== undefined ? props.disabled ? "btn-esecondary" : "btn-eprimary" : "btn-eprimary"}
                onClick={props.onSubmitHandler}>
                {props.actionType === 'Submit' ? "Submit" : props.actionType === 'Update' ? "Update" : props.actionType}
              </button>
            }

          </div>
        </DialogActions>}
      </BootstrapDialog>
    </React.Fragment>
  )
}

export default CustomDialog;
