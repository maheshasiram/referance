// import { Alert, Snackbar } from "@mui/material";
import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { Types } from "../../constants/Types";
import { useToasts } from 'react-toast-notifications';

function SnackBarToast() {
  const { addToast } = useToasts();
  const dispatch = useDispatch();
  const { isToast } = useSelector((state: any) => state.application);

  React.useEffect(() => {
    if(isToast.open){
      addToast(isToast.message , { appearance: isToast.status === 1 ? 'success' : 'error',  autoDismiss: true, autoDismissTimeout:10000 });
      dispatch({
        type: Types.IS_TOAST_ENABLED, payload: {
          status: null, message: "", open: false
        }
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isToast])

  // const handleClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
  //   if (reason === 'clickaway') {
  //     return;
  //   }
  //   dispatch({
  //     type: Types.IS_TOAST_ENABLED, payload: {
  //       status: null, message: "", open: false
  //     }
  //   });
  // };
  return (
    <div className="snackBar-Toast">
      {/* <Snackbar open={isToast.open}
        autoHideDuration={3000}
        anchorOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
        onClose={handleClose}>
        <Alert onClose={handleClose}
          severity={isToast.status === 1 ? "success" : "error"}
          sx={{ width: '100%' }}>
          {isToast.message}
        </Alert>
      </Snackbar> */}

    </div>
  )
}
export default SnackBarToast