import React from "react";

export default function PageCount(props: any) {
    const {value, onChange} = props;
    return (
        <div className="page-count-container" >
            <label>Page count : </label>
            <div className="page-count-select" >
                <select value={value} onChange={onChange}>
                    <option value={10} >10</option>
                    <option value={25}>25</option>
                    <option value={50}>50</option>
                    <option value={75} >75</option>
                    <option value={100}>100</option>
                </select>
            </div>
        </div>
    )
}