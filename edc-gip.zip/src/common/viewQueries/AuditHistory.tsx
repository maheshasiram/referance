import { Column } from 'primereact/column'
import { DataTable } from 'primereact/datatable'
import React from 'react'
import { queryData } from '../../constants/queryData'

function AuditHistory() {
    
  return (
    <div>
         <DataTable scrollable value={queryData.auditDetails}>
                <Column field="auditEvent" header="Audit event" ></Column>
                <Column field="reasonForChange" header="Reason for change" ></Column>
                <Column field="dateTimeInServer" header="Date/Time of server" ></Column>
                <Column field="user" header="User name"></Column>
                <Column field="itemName" header="Variable Id"></Column>
                <Column field="oldValue" header="Old values"></Column>
                <Column field="newValue" header="New values"></Column>
            </DataTable>
    </div>
  )
}

export default AuditHistory