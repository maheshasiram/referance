import React from 'react'
import { Formik, Form, Field } from 'formik';
import * as Yup from "yup";
import CustomDialog from '../../modals/CustomeDialog';
// import { queryData } from '../../../constants/queryData';
import { useDispatch, useSelector } from 'react-redux';
import { fetchViewQueryData, updateQuery } from '../../../modules/subjects/modules/subjectsList/components/dynamicForms/actions/actions';
import { Types } from '../../../constants/Types';
import { fetchAndFilterQueries } from '../../../modules/queryListing/actions/action';
import { queriesModel } from '../../../modules/queryListing/constants/modal';
import { Types as queryTypes } from '../../../modules/queryListing/reducers/Types';
// import { Types as Type } from '../../../modules/subjects/modules/subjectsList/reducers/Types';

const respondQuerySchema = Yup.object().shape({
    comments: Yup.string()
        .min(2, 'Too Short!')
        .max(100, 'Too Long!')
        .required('Enter the text')
});

function Respond(props: any) {
    const { subjectFieldId } = useSelector((state: any) => state.application);
    const { addQueryPayload, getQueryStatus } = useSelector((state: any) => state.subjects);
    const dispatch = useDispatch();


    const respondClose = () => {
        props.setOpenRespond(false);
        // props.setOpen(true);
        dispatch({ type: Types.OPEN_CUSTOM_DIALOG, payload: true });
    }

    const responseChange = (e: any, setFieldValue: any) => {
        console.log('response details', e.target.value);
        setFieldValue('comments', e.target.value);
    }

    const handleUserChange = (e: any) => {
        console.log('user details', e.target.value);
        // setFieldValue('assignedUserForRespondQuery', e.target.value);
    }

    const onSubmitRespondQuery = (values: any) => {
        const _payload = { ...{}, ...values };
        _payload.subjectFieldId = props.subjectFieldId;
        _payload.id = props.selectedQueryID;
        delete _payload.request
        delete _payload.resolutionType
        delete _payload.ruleId
        delete _payload.type
        delete _payload.assignTo
        getQueryStatus?.QUERY_STATUS.filter((item: any) => {
            if (item.code === 'QUERY_STATUS_RESPONDED') {
                _payload.status = item
            }
            return null
        });
        props.setOpenRespond(false);
        dispatch({ type: Types.OPEN_CUSTOM_DIALOG, payload: true });
        const _subjectFieldId = props.subjectFieldId ? props.subjectFieldId : subjectFieldId
        dispatch(updateQuery(_payload, (response: any) => {
            console.log("..52", response);
            if (window.location.pathname === '/querylisting') {
                dispatch(fetchAndFilterQueries(queriesModel, (response: any) => {
                    dispatch({ type: queryTypes.FETCH_ALL_QUERIES, payload: response });
                }));
                dispatch({ type: Types.OPEN_CUSTOM_DIALOG, payload: false });
            } else {
            dispatch(fetchViewQueryData(_subjectFieldId, (response: any) => {
                dispatch({ type: Types.GET_VIEW_QUERY_DATA, payload: response.data });
            }));
            }
        }));
        console.log("...3999", _payload);
    }

    return (
        <div>
            <CustomDialog
                open={props.openRespond}
                title={"Respond Query"}
                maxWidth='xs'
                fullWidth={true}
                actionType={"Submit"}
                onClose={respondClose}
                form='respondQuery'
            >
                <div className='query-list-container'>
                    <Formik
                        // initialValues={queriesInitialState.responseQuery}
                        initialValues={addQueryPayload}
                        validationSchema={respondQuerySchema}
                        onSubmit={(values: any) => {
                            onSubmitRespondQuery(values)
                        }}
                    >
                        {({ setFieldValue, values, errors, touched }) => (
                            <Form id="respondQuery">
                                <div className="pb-2">
                                    <label htmlFor="text-queryText">Query Text: </label>
                                    <Field
                                        as='textarea'
                                        id="text-queryText"
                                        name='comments'
                                        value={values.comments}
                                        className="form-control"
                                        onChange={(e: any) => responseChange(e, setFieldValue)}
                                    />
                                    {(errors && errors.comments && touched && touched.comments) &&
                                        <span className="text-danger">{errors.comments as string}</span>}
                                </div>

                                <div className="">
                                    <label htmlFor="txt-queryType">Assign user: </label>
                                    <Field as='select'
                                        name='queryType'
                                        id="txt-queryType"
                                        className="form-select"
                                        value={values.queryType}
                                        onChange={(e: any) => handleUserChange(e)}
                                    >
                                        <option value="">--Select user--</option>
                                        {/* {
                                            getQueryType?.RESOLUTION_TYPE.map((opt: any, i: any) => (
                                                <option key={i} value={opt.id}>{opt.name}</option>
                                            ))
                                        } */}
                                    </Field>
                                </div>

                            </Form>
                        )}
                    </Formik>
                </div>
            </CustomDialog>
        </div>
    )
}

export default Respond