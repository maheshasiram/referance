import React from 'react'
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from "yup";
import CustomDialog from '../../modals/CustomeDialog';
import { useDispatch, useSelector } from 'react-redux';
import { Types } from '../../../constants/Types';
import { queryData } from '../../../constants/queryData';
import { Types as Type } from '../../../modules/subjects/modules/subjectsList/reducers/Types';
import _ from 'lodash';
import { fetchViewQueryData, updateQuery } from '../../../modules/subjects/modules/subjectsList/components/dynamicForms/actions/actions';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import CustomToolTip from '../../../components/CustomToolTip';
import AddReasonToClose from '../../../modules/queryListing/components/AddReasonToClose';
import { queriesModel } from '../../../modules/queryListing/constants/modal';
import { fetchAndFilterQueries } from '../../../modules/queryListing/actions/action';
import { Types as queryTypes } from '../../../modules/queryListing/reducers/Types';

const closeQuerySchema = Yup.object().shape({
    resolutionType: Yup.object().shape({
        name: Yup.string().required(' Reason to close is required'),
    }),
    comments: Yup.string().when('resolutionType.name', {
        is: (val) => val === "Other",
        then: Yup.string()
            .required('Please enter description')
    })
});

function Close(props: any) {
    const dispatch = useDispatch();
    // const [openAddReasonDialog, setOpenAddReasonDialog] = React.useState(false);
    const { subjectFieldId, reasonsToClose, openAddReasonDialog } = useSelector((state: any) => state.application);
    const { getQueryType, addQueryPayload, getQueryStatus } = useSelector((state: any) => state.subjects);


    const closeQuery = () => {
        props.setOpenCloseQuery(false);
        dispatch({ type: Types.OPEN_CUSTOM_DIALOG, payload: true });
    }

    const responseChange = (e: any, setFieldValue: any) => {
        const _payload = _.cloneDeep(addQueryPayload);
        setFieldValue('comments', e.target.value);
        _payload.comments = e.target.value
        dispatch({ type: Type.CREATE_QUERY, payload: _payload });
    }

    const handleChange = (e: any, setFieldValue: any) => {
        const _payload = _.cloneDeep(addQueryPayload);
        const _data = reasonsToClose && reasonsToClose?.find((item: any) => parseInt(e.target.value) === parseInt(item.id));
        setFieldValue('resolutionType', _data ? _data : getQueryType.resolutionType);
        // let _data = getQueryType?.RESOLUTION_TYPE.find((item: any) => parseInt(e.target.value) === parseInt(item.id));
        // setFieldValue('resolutionType', _data ? _data : getQueryType.resolutionType);
        _payload.resolutionType = _data ? _data : getQueryType.resolutionType;
        // _payload.comments = _data && _data.code !== "RESOLUTION_TYPE_OTHER" ? _data.name : ''
        console.log("...677", _data);
        dispatch({ type: Type.CREATE_QUERY, payload: _payload });
        console.log("..399", _payload);
    }

   const handleUserChange = (e:any, setFieldValue:any)=>{
       setFieldValue('assignedUserForClosedQuery', e.target.value);
   }

    const onSubmitCloseQuery = () => {
        const _payload = _.cloneDeep(addQueryPayload);
        _payload.subjectFieldId = props.subjectFieldId;
        _payload.id = props.selectedQueryID;
        delete _payload.request
        delete _payload.ruleId
        delete _payload.type
        delete _payload.assignTo
        getQueryStatus?.QUERY_STATUS.filter((item: any) => {
            if (item.code === 'QUERY_STATUS_CLOSED') {
                _payload.status = item
            }
            return null
        })
        props.setOpenCloseQuery(false);
        const _subjectFieldId = props.subjectFieldId ? props.subjectFieldId : subjectFieldId
        dispatch(updateQuery(_payload, (response: any) => {
            console.log("..45",response);
            if (window.location.pathname === '/querylisting') {
                dispatch(fetchAndFilterQueries(queriesModel, (response: any) => {
                    dispatch({ type: queryTypes.FETCH_ALL_QUERIES, payload: response });
                }));
                dispatch({ type: Types.OPEN_CUSTOM_DIALOG, payload: false });
            } else {
            dispatch(fetchViewQueryData(_subjectFieldId, (response: any) => {
                dispatch({ type: Types.GET_VIEW_QUERY_DATA, payload: response.data });
            }));
            }
        }));
        dispatch({ type: Types.OPEN_CUSTOM_DIALOG, payload: true });
    }

    const onClickAddReasons = (e: any) => {
        dispatch({ type: Types.OPEN_ADD_REASON_DIALOG, payload: true })
    }

    return (
        <div>
            {openAddReasonDialog && <AddReasonToClose />}
            <CustomDialog
                open={props.openClosedQuery}
                title={"Closed Query"}
                maxWidth={'sm'}
                fullWidth={true}
                actionType={"Submit"}
                onClose={closeQuery}
                form='closeQuery'
            >
                <div className='query-list-container'>
                    <Formik
                        // initialValues={queriesInitialState.closedQuery}
                        initialValues={addQueryPayload}
                        validationSchema={closeQuerySchema}
                        onSubmit={() => onSubmitCloseQuery()}
                    >
                        {({ errors, values, setFieldValue }) => (
                            <Form id="closeQuery">
                                <div className='pb-2'>
                                    <div className='d-flex'>
                                        <label htmlFor="reason">Reason for close :</label>
                                        <div className="px-2"><CustomToolTip title={"Add reasons to Close query "}><AddCircleOutlineIcon className='addCloseReasonIcon' onClick={(e) => onClickAddReasons(e)}></AddCircleOutlineIcon></CustomToolTip></div>
                                    </div>
                                    <Field as='select' name="resolutionType.id" className='form-select w-100' onChange={(e: any) => handleChange(e, setFieldValue)}>
                                        <option value={''}>Select reason</option>
                                        {
                                            reasonsToClose && reasonsToClose?.map((opt: any, i: any) => (
                                                <option key={i} value={opt.id}>{opt.name}</option>
                                            ))
                                        }
                                </Field>
                                </div>
                                <>{console.log("90..", errors, values)}</>
                                <div className='text-danger'><ErrorMessage name="resolutionType.name" /></div>
                                {
                                    addQueryPayload.resolutionType.name === 'Other' &&
                                    <div className='pb-2'>
                                        <label htmlFor="desc">Query Text:</label>
                                        <Field name="comments" as="textarea"
                                            value={values.comments}
                                            placeholder='Enter description here'
                                            className='form-control w-100'
                                            rows={3}
                                                onChange={(e: any) => responseChange(e, setFieldValue)}
                                        />
                                            <div className='text-danger'><ErrorMessage name="comments" /></div>
                                    </div>
                                }
                                <div className='pb-2'>
                                <label htmlFor="user" className='mt-1'>Assign user :</label>
                                <Field as="select" name="user" id="" className="form-select" onChange={(e:any)=>handleUserChange(e,setFieldValue)}>
                                    <option value="" >Select user</option>
                                    {
                                        queryData.discrepancyNotes.assignUsersList.map((i: any,index: any) => {
                                            return <option key={index} value={i.userId}>{i.userName}</option>
                                        })
                                    }
                                </Field>
                                </div>
                            </Form>
                        )}
                    </Formik>

                </div>
            </CustomDialog>

        </div >
    )
}

export default Close