import React from 'react'
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from "yup";
import CustomDialog from '../../modals/CustomeDialog';
import { queryData } from '../../../constants/queryData';
import { useDispatch, useSelector } from 'react-redux';
import { Types } from '../../../constants/Types';
import _ from 'lodash';
import { Types as Type } from '../../../modules/subjects/modules/subjectsList/reducers/Types';
import { fetchViewQueryData, updateQuery } from '../../../modules/subjects/modules/subjectsList/components/dynamicForms/actions/actions';
import { fetchAndFilterQueries } from '../../../modules/queryListing/actions/action';
import { queriesModel } from '../../../modules/queryListing/constants/modal';
import { Types as queryTypes } from '../../../modules/queryListing/reducers/Types';
// import { queries } from '@testing-library/react';

const reOpenQuerySchema = Yup.object().shape({
    comments: Yup.string()
        .min(2, 'Too Short!')
        .max(100, 'Too Long!')
        .required('Please enter text')
});

function Reopen(props: any) {
    
    // const [assignedUser , setAssignedUser] = React.useState()
    const dispatch = useDispatch()
    const { subjectFieldId } = useSelector((state: any) => state.application)
    const { addQueryPayload, getQueryStatus } = useSelector((state: any) => state.subjects);

    console.log("...params", window.location.pathname);

    const reOpenClose = () => {
        props.setReOpenQuery(false);
        // props.setOpen(true);
        dispatch({ type: Types.OPEN_CUSTOM_DIALOG, payload: true });
    }

    const reOpenChange = (e: any, setFieldValue: any) => {
        setFieldValue('comments', e.target.value);
        const _payload = _.cloneDeep(addQueryPayload);
        _payload.comments = e.target.value
        dispatch({ type: Type.CREATE_QUERY, payload: _payload });
    }

    const handleUserChange = () => {
        // setAssignedUser(e.target.value)
        // setFieldValue('assignedUserForReopenQuery', e.target.value);
    }

    const onSubmitReopenQuery = () => {
        const _payload = _.cloneDeep(addQueryPayload);
        _payload.subjectFieldId = props.subjectFieldId;
        _payload.id = props.selectedQueryID;
        delete _payload.request
        delete _payload.resolutionType
        delete _payload.ruleId
        delete _payload.type
        delete _payload.assignTo
        getQueryStatus?.QUERY_STATUS.filter((item: any) => {
            if (item.code === 'QUERY_STATUS_REOPEN') {
                _payload.status = item
            }
            return null
        });
        props.setReOpenQuery(false);
        dispatch({ type: Types.OPEN_CUSTOM_DIALOG, payload: true });
        const _subjectFieldId = props.subjectFieldId ? props.subjectFieldId : subjectFieldId
        dispatch(updateQuery(_payload, (response: any) => {
            console.log("...63", _subjectFieldId,response);
            if (window.location.pathname === '/querylisting') {
                dispatch(fetchAndFilterQueries(queriesModel, (response: any) => {
                    dispatch({ type: queryTypes.FETCH_ALL_QUERIES, payload: response });
                }));
                dispatch({ type: Types.OPEN_CUSTOM_DIALOG, payload: false });
            } else {
            dispatch(fetchViewQueryData(_subjectFieldId, (response: any) => {
                dispatch({ type: Types.GET_VIEW_QUERY_DATA, payload: response.data });
            }));
            }
        }));
    }

    return (
        <div>
            <CustomDialog
                open={props.reOpenQuery}
                title={"Reopen Query"}
                maxWidth={'sm'}
                fullWidth={true}
                actionType={"Submit"}
                onClose={reOpenClose}
                form='respondQuery'
            >
                <div className='query-list-container'>
                    <Formik
                        // initialValues={queriesInitialState.reopenQuery}
                        initialValues={addQueryPayload}
                        validationSchema={reOpenQuerySchema}
                        onSubmit={() => { onSubmitReopenQuery() }}
                    >
                        {({ setFieldValue, values }) => (
                            <Form id="respondQuery">
                                <div>
                                    <label htmlFor="desc">Query Text:</label>
                                    <Field name="comments" as="textarea"
                                        value={values.comments}
                                        className='form-control w-100'
                                        rows={3}
                                        onChange={(e: any) => reOpenChange(e, setFieldValue)}
                                    />
                                    <div className='text-danger'><ErrorMessage name="comments" /></div>
                                </div>
                                <div className=''>
                                <label htmlFor="user" className='mt-1'>Assign user</label>
                                <Field as="select" name="user" id="" className="form-select" onChange={()=>handleUserChange()}>
                                    <option value="" >Select user</option>
                                    {
                                        queryData.discrepancyNotes.assignUsersList.map((i: any,index: any) => {
                                            return <option key={index} value={i.userId}>{i.userName}</option>
                                        })
                                    }
                                </Field>
                                </div>
                            </Form>
                        )}
                    </Formik>
                </div>
            </CustomDialog>
        </div>
    )
}

export default Reopen