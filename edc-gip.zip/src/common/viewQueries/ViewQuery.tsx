import React from 'react'
import CustomDialog from '../modals/CustomeDialog';
import Box from '@mui/material/Box';
// import Tab from '@mui/material/Tab';
import TabContext from '@mui/lab/TabContext';
// import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';
// import AuditHistory from './AuditHistory';
import QueryListing from './QueryListing';
import Respond from './Queries/Respond';
import Close from './Queries/Close';
import Reopen from './Queries/Reopen';
// import StickyNotes from './StickyNotes';
import { useDispatch, useSelector } from 'react-redux';
import { Types as Type } from '../../modules/subjects/modules/subjectsList/reducers/Types';
import { Types } from '../../constants/Types';
import { addQueryModal } from '../../modules/subjects/modules/subjectsList/constants/modal';
import { fetchReasonsToClose } from '../../modules/subjects/modules/subjectsList/components/dynamicForms/actions/actions';

function ViewQuery(props: any) {
    // const { setOpen } = props
    console.log(props)
    const { openCustomDialog, viewQueryData } = useSelector((state: any) => state.application);
    const dispatch = useDispatch();
    const [value] = React.useState('viewQuery');
    const [openRespond, setOpenRespond] = React.useState(false);
    const [openClosedQuery, setOpenCloseQuery] = React.useState(false);
    const [reOpenQuery, setReOpenQuery] = React.useState(false);
    const [selectedQueryID, setSelectedQueryID] = React.useState(0);

    const handleClose = () => {
        // setOpen(false);
        dispatch({ type: Types.OPEN_CUSTOM_DIALOG, payload: false });
    }
    // const handleTabChange = (event: React.SyntheticEvent, newValue: string) => {
    //     setValue(newValue);
    // };
    console.log("...38888000", viewQueryData.length);
    const openRespondDialog = (i: any) => {
        console.log("...388889", i);
        setSelectedQueryID(i.id);
        setOpenRespond(true);
        dispatch({ type: Type.CREATE_QUERY, payload: addQueryModal });
    }

    const openCloseDialog = (i: any) => {
        setOpenCloseQuery(true);
        setSelectedQueryID(i.id);
        dispatch(fetchReasonsToClose());
        dispatch({ type: Type.CREATE_QUERY, payload: addQueryModal });
    }

    const openReopenDialog = (i: any) => {
        setSelectedQueryID(i.id);
        setReOpenQuery(true);
        dispatch({ type: Type.CREATE_QUERY, payload: addQueryModal });
    }

    return (
        <div>
            <CustomDialog
                maxWidth={'md'}
                // open={props.open}
                open={openCustomDialog}
                onClose={handleClose}
                title={"View Query"}
            >
                <Box sx={{ width: '100%', typography: 'body1' }} >
                    <TabContext value={value}>
                        {/* <Box sx={{ borderBottom: 1, borderColor: 'divider', }}> */}
                        {/* <TabList onChange={handleTabChange} aria-label="lab API tabs example" >
                                <Tab label="Query listing" value="viewQuery" sx={{ fontSize: '13px' }} /> */}
                                {/* <Tab label="Audit history" value="auditHistory" sx={{ fontSize: '13px' }} />
                                <Tab label="Sticky notes" value="stickyNotes" sx={{ fontSize: '13px' }} /> */}
                        {/* </TabList> */}
                        {/* </Box> */}
                        <TabPanel value="viewQuery" className='view-query-container'>
                            {viewQueryData?.length > 0 ? <QueryListing openRespondDialog={openRespondDialog} openCloseDialog={openCloseDialog} openReopenDialog={openReopenDialog} /> : <p>No Queries are there to show</p>}
                        </TabPanel>
                        {/* <TabPanel value="auditHistory" className='view-query-container'><AuditHistory /></TabPanel>
                        <TabPanel value="stickyNotes" className='view-query-container'><StickyNotes/></TabPanel> */}
                    </TabContext>
                </Box>
            </CustomDialog >
            <Respond openRespond={openRespond} setOpenRespond={setOpenRespond} subjectFieldId={props.subjectFieldId} selectedQueryID={selectedQueryID} />
            <Close openClosedQuery={openClosedQuery} setOpenCloseQuery={setOpenCloseQuery} subjectFieldId={props.subjectFieldId} selectedQueryID={selectedQueryID} />
            <Reopen setReOpenQuery={setReOpenQuery} reOpenQuery={reOpenQuery} subjectFieldId={props.subjectFieldId} selectedQueryID={selectedQueryID} />
        </div>
    )
}

export default ViewQuery;