import React from 'react'
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import ReplyIcon from '@mui/icons-material/Reply';
import CloseIcon from '@mui/icons-material/Close';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
// import { queryData } from '../../constants/queryData';
import CustomToolTip from '../../components/CustomToolTip';
import FolderCopyIcon from '@mui/icons-material/FolderCopy';
import { useSelector } from 'react-redux';
import { styled } from '@mui/material/styles';
import MuiAccordion, { AccordionProps } from '@mui/material/Accordion';
import MuiAccordionSummary, {
    AccordionSummaryProps,
} from '@mui/material/AccordionSummary';
import MuiAccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';

const Accordion = styled((props: AccordionProps) => (
    <MuiAccordion disableGutters elevation={0} square {...props} />
))(({ theme }) => ({
    border: `1px solid ${theme.palette.divider}`,
    '&:not(:last-child)': {
        borderBottom: 0,
    },
    '&:before': {
        display: 'none',
    },
}));

const AccordionSummary = styled((props: AccordionSummaryProps) => (
    <MuiAccordionSummary
        {...props}
    />
))(({ theme }) => ({
    flexDirection: 'row-reverse',
    '& .MuiAccordionSummary-content': {
        marginLeft: theme.spacing(1),
    },
}));

const AccordionDetails = styled(MuiAccordionDetails)(({ theme }) => ({
    padding: theme.spacing(2),
    borderTop: '1px solid rgba(0, 0, 0, .125)',
}));


function QueryListing(props: any) {
    const { viewQueryData,configCodes } = useSelector((state: any) => state.application);
    // const { queriesData, viewQueryData } = useSelector((state: any) => state.application);
    const [expanded, setExpanded] = React.useState<string | false>(false);

    const handleChange =
        (panel: string) => (event: React.SyntheticEvent, isExpanded: boolean) => {
            setExpanded(isExpanded ? panel : false);
        };

    return (
        <div className='viewQuery'>
            {
                viewQueryData && viewQueryData.map((i: any, index: number) => {
                    // queriesData && queriesData.discrepancyNotes.dnDetails.map((i: any, index: number) => {
                    <>{console.log("...622", i.id, index)}</>
                    return <Accordion key={index}
                        expanded={expanded === `panel${index}`}
                        onChange={handleChange(`panel${index}`)}
                        className='accordion '
                    >
                        <AccordionSummary
                            aria-controls="panel1bh-content"
                            id="panel1bh-header"
                            sx={expanded === `panel${index}` ? { backgroundColor: '#202d3c', color: '#fff', height: '10px!important' }
                                : { backgroundColor: "", height: '0.75rem !important' }}
                        >
                            <Typography
                                className='d-flex justify-content-between w-100'
                                sx={{ fontSize: '13px !important', fontWeight: '500' }}
                            >
                                {/* <span>Query ID: {i.parentQueryId}({i.parentCurrentStatus})</span> */}
                                <span>Query ID: {i.id}({i.status.name})</span>
                                <span className='d-flex accordion-font'>
                                    {i.status.code === configCodes?.Open && i.respond !== true ? <span>
                                        <span onClick={(event) => {
                                            event.stopPropagation();
                                        }}>
                                            <CustomToolTip title='Respond query'>
                                                <ReplyIcon
                                                    onClick={() => props.openRespondDialog(i)}
                                                    className={expanded === `panel${index}` ? 'text-white' : 'text-secondary'} />
                                            </CustomToolTip>
                                        </span>
                                        <span onClick={(event) => {
                                            event.stopPropagation()
                                        }}>
                                            <CustomToolTip title='Closed query'>
                                                <CloseIcon
                                                    onClick={() => props.openCloseDialog(i)}
                                                    className={expanded === `panel${index}` ? 'text-white' : 'text-secondary'} />
                                            </CustomToolTip>
                                        </span>
                                    </span> : i.status.code !== configCodes?.Closed && i.status.code !== configCodes?.Responded && i.status.code !== configCodes?.['Re-Query']? <span onClick={(event) => {
                                        event.stopPropagation();
                                    }}>
                                        <CustomToolTip title='Respond query'>
                                            <ReplyIcon
                                                    onClick={() => props.openRespondDialog(i)}
                                                className={expanded === `panel${index}` ? 'text-white' : 'text-secondary'} />
                                        </CustomToolTip>
                                        </span> : <></>
                                    }
                                    {
                                        i.status.code === configCodes?.Closed && <span onClick={(event) => {
                                            event.stopPropagation();
                                        }}>
                                            <CustomToolTip title='Re-Query query'>
                                                <FolderCopyIcon
                                                    onClick={() => props.openReopenDialog(i)}
                                                    className={expanded === `panel${index}` ? 'text-white' : 'text-secondary'} />
                                            </CustomToolTip>
                                        </span>
                                    }
                                    {
                                        i.status.code === configCodes?.Responded && <span><span onClick={(event) => {
                                            event.stopPropagation();
                                        }}>
                                            <CustomToolTip title='Closed query'>
                                                <CloseIcon
                                                    onClick={() => props.openCloseDialog(i)}
                                                    className={expanded === `panel${index}` ? 'text-white' : 'text-secondary'} />
                                            </CustomToolTip>
                                        </span>
                                            <span onClick={(event) => {
                                                event.stopPropagation();
                                            }}>
                                                <CustomToolTip title='Re-Query query'>
                                                    <FolderCopyIcon
                                                        onClick={() => props.openReopenDialog(i)}
                                                        className={expanded === `panel${index}` ? 'text-white' : 'text-secondary'} />
                                                </CustomToolTip>
                                            </span>
                                        </span>
                                    }
                                    {
                                        i.status.code === configCodes?.['Re-Query'] && <span>
                                            <span onClick={(event) => {
                                                event.stopPropagation();
                                            }}>
                                                <CustomToolTip title='Closed query'>
                                                    <CloseIcon
                                                        onClick={() => props.openCloseDialog(i)}
                                                        className={expanded === `panel${index}` ? 'text-white' : 'text-secondary'} />
                                                </CustomToolTip>
                                            </span>
                                            <span onClick={(event) => {
                                                event.stopPropagation();
                                            }}>
                                                <CustomToolTip title='Respond query'>
                                                    <ReplyIcon
                                                        onClick={() => props.openRespondDialog(i)}
                                                        className={expanded === `panel${index}` ? 'text-white' : 'text-secondary'} />
                                                </CustomToolTip>
                                            </span>
                                        </span>
                                    }
                                    <ExpandMoreIcon
                                        sx={expanded === `panel${index}` ?
                                            { backgroundColor: '#202d3c', color: '#fff', transform: 'rotate(180deg)' }
                                            : { backgroundColor: "" }}
                                        className={expanded === `panel${index}` ? 'text-white' : 'text-secondary'}
                                    />
                                </span>
                            </Typography>
                        </AccordionSummary>
                        <AccordionDetails sx={{ backgroundColor: '#eaeaea' }}>
                            <Typography>
                                <div className='mt-1'>
                                    <div>
                                        <div className='row bg-light query-list'>
                                            <div className='col ms-3'>
                                                <p className='viewQueryText' >Create Date : {i.createdOn}</p>
                                                <p className='viewQueryText'>Created by : <span> {i.createdBy}</span></p>
                                            </div>
                                            <div className='col'>
                                                {/* <p className='viewQueryText'>Query Type : {i.parentQueryType}</p> */}
                                                <p className='viewQueryText'>Query text : {i.comments} </p>
                                            </div>
                                        </div>
                                        <h6 className='action-reason'>Action Reasons</h6>
                                        <>{console.log("...146", i)}</>
                                        <div className='transactionDatatable'>
                                        {/* <DataTable scrollable value={queryData && queryData.discrepancyNotes.dnDetails[index].cnDetails}> */}
                                            <DataTable className='' scrollable value={i?.transactions}>
                                            <Column field="comments" header="Action Reason" ></Column>
                                            <Column field="transStatus.name" header="Query Status" ></Column>
                                            <Column field="actionByUser" header="Created by" ></Column>
                                            <Column field="assignTo" header="Assign to"></Column>
                                            <Column field="actionOn" header="Date & Time" ></Column>
                                        </DataTable> 
                                        </div>
                                    </div>
                                </div>
                            </Typography>
                        </AccordionDetails>
                    </Accordion>
                })
            }
        </div >
    )
}

export default QueryListing