import styled from "styled-components";

export const FilterContainer = styled.div`
  display:flex;
  justify-content:center;
  align-items:center;
  gap:5px;
  border:1px solid rgba(0,0,0, .05);
  padding:0 0 0 10px;
  width:100%;
  border-radius:2px;
  position:relative;
  &:hover{
    border:1px solid #435597;
  }
  span.del-icon{
    position:absolute;
    background-color: rgba(0, 0, 0, 0.07);
    border-radius: 100px;
    padding: 5px;
    right: 40px;
    top: 6px;
    z-index: 1;
    height: 20px;
    width: 20px;
    display: inline-flex;
    justify-content: center;
    align-items: center;
    cursor:pointer;
    svg{
        font-size: 12px;
    }
  }
  select{
    border:0px;
    border-radius:0px;
    border-left:1px solid rgba(0,0,0,.05);
    &:focus{
        border:0px;
        border-left:1px solid rgba(0,0,0,.05);
    }
  }
`;


export const FilterSeachContainer = styled.div`
  width:100%;
  display:flex;
  border:1px solid rgba(0,0,0, .05);
  &:hover{
    border:1px solid #435597;
  }
  select {
    &:first-child{
      border-right:1px solid rgba(0,0,0,.05) !important;
    }
  }
  select, select.sub-dropdown, .search-container{
    border-radius:0px !important;
    margin-left:0px !important;
    border:0px !important;
  }
`
