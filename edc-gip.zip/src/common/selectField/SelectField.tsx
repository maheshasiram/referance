import React from 'react';
import Select from 'react-select';

export default function SelectField(props: any) {

  const options = props.isMulti && props.options ? [{ label: "Select All", value: 'all' }, ...props.options] : props.options
  const customStyles = {
    control: (provided: any, state: any) => ({
      ...provided,
      minHeight: '20px',
      // height: '35px'
    }),
    valueContainer: (provided: any, state: any) => ({
      ...provided,
      // height: '35px',
      padding: '0px',
      marginLeft:'8px',
      fontSize: '13px',
      cursor:'pointer'
    }),
    indicatorsContainer: (provided: any, state: any) => ({
      ...provided,
      // height: '35px',
    }),
    input: (provided: any, state: any) => ({
      ...provided,
      margin: '0px',
      padding:'0px'
    }),
    menu: (provided: any, state: any) => ({
      ...provided,
      zIndex: 9999,
      cursor:'pointer',
      width: "-webkit-fill-available",
      fontSize: '13px',
      marginTop: '0px'
    }),
  };

  return (
    <>
      <Select
        id={props.id}
        // className="basic-single"
        className={`common-Select ${props.className}`}
        classNamePrefix={props.classNamePrefix}
        defaultValue={props.defaultValue}
        isDisabled={props.isDisabled}
        // isClearable={props.isClearable}
        isClearable={true}
        isSearchable={props.isSearchable}
        name={props.name}
        isMulti={props.isMulti}
        styles={customStyles}
        value={props.value ? props.value : null}

        // onChange={props.onChange}
        // options={props.options}
        // menuIsOpen={true}
        onChange={(selected: any) => {
          console.log("24 selected...", props.value)
          props.isMulti && selected.length &&
            selected.find((option: any) => option.value === "all")
            ? props.onChange(options.slice(1))
            : !props.isMulti
              ? props.onChange((selected) || null)
              : props.onChange(selected)
        }}
        options={options}
        placeholder={props.placeholder}

      />
    </>
  );
}


