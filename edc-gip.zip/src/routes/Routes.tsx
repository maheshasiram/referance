import React, { Suspense, useEffect } from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import PrivateRoute from './PrivateRoute';
import PublicRoute from './PublicRoute';
import AppHeader from '../components/header/AppHeader';
import SignIn from '../components/signIn/SignIn';
import SnackBarToast from '../common/modals/SnackBarToast';
import { ToastProvider } from 'react-toast-notifications';
import { privateRoutes } from '../constants/lazyRoutes';
import LazyLoader from '../common/loader/LazyLoader';
import { findAllCountries } from '../actions/actions';
import { useDispatch } from "react-redux";

function Root() {
  const [isAuthenticated, setIsAuthenticated] = React.useState(false);
  const loaded = React.useRef(false);
  const dispatch = useDispatch();
  
  useEffect(() => {

    if (!loaded.current) {
      dispatch(findAllCountries());
      // dispatch(fetchAllConfigData());
      loaded.current = true
    }
  }, [dispatch]);


  React.useEffect(() => {
    setIsAuthenticated(true);
  }, []);
  return (
    <BrowserRouter>
      {isAuthenticated && <AppHeader />}
      <div className='app-container'>
        <div className='Toast-Alert-Container' >
          <ToastProvider>
            <SnackBarToast />
          </ToastProvider>
        </div>
        <Suspense fallback={<LazyLoader />} >
          <Routes>
            <Route
              path="/"
              element={
                <PublicRoute isAuthenticated={isAuthenticated} to="/home">
                  <SignIn />
                </PublicRoute>
              }
            />
            <>
              {privateRoutes.map((Item: any, index: number) => {
                return <Route key={index} path={Item.pathName} element={
                  <PrivateRoute isAuthenticated={isAuthenticated} to="/">
                    {
                      Item.children && Item.renderChild ? Item.children.map((child: any, childIndex: any) => {
                        return Item.renderChild && <Routes key={childIndex}><Route path={child.pathName} element={<child.Component />}></Route></Routes>
                      }) : <Item.Component />
                    }
                  </PrivateRoute>
                }  />
              })}
            </>
          </Routes>
        </Suspense>
      </div>
    </BrowserRouter>
  )
}
export default Root;