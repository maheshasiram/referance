import thunk from 'redux-thunk';
import reducer from '../reducers'
import { configureStore } from '@reduxjs/toolkit';

const store = configureStore({
  reducer: reducer,
  middleware: [thunk]
})

export default store;