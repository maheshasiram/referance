// import { type } from "os"

export type closedQueires = {
    reason ?: string,
    otherReasonDescription ?:string,
    assignedUserForClosedQuery ?:string
}
export type respondQueries = {
    description ?: string,
    assignedUserForRespondQuery?:string
}
export type reOpenQueries ={
    description ?: string,
    assignedUserForReopenQuery?:string
}
export type stickyNotes = {
    stickyNotesTitle:string,
    stickyNotesDescription : string,
}