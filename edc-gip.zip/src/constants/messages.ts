export const messages = {
    apiError: 'Something went wrong',
    delete: 'Are you sure do you want to delete ',
    restore: 'Are you sure do you want to restore ',
    deleted: 'deleted Successfully',
    restored: 'restored Successfully'
}