import { lazy } from "react";


export const privateRoutes = [
    {
        name: 'Home',
        pathName: '/home',
        Component: lazy(() => import('../components/home/index')),
        navigateTo: '/home'
    },
    {
        name: 'Subjects',
        pathName: '/subjects/*',
        Component: lazy(() => import('../modules/subjects/index')),
        navigateTo: '/subjects',
        showChild: true,
        renderChild: true,
        children: [
            {
                name: 'Subjects List',
                pathName: '/',
                Component: lazy(() => import('../modules/subjects/index')),
                navigateTo: 'subjects'
            },
            {
                name: 'Import Data',
                pathName: 'importdata',
                Component: lazy(() => import('../modules/subjects/modules/importData')),
                navigateTo: 'subjects/importdata'
            },
            {
                // name: 'Import CRF data',
                pathName: '/LabFileImportUpload/:selectVal',
                Component: lazy(() => import('../modules/subjects/modules/importData/components/importCrfData')),
                navigateTo: '/'
            },
            // {
            //     name: 'Downloads',
            //     pathName: 'downloads',
            //     Component: lazy(() => import('../modules/subjects/modules/downloads/Downloads')),
            //     navigateTo: 'subjects/downloads'
            // }
        ]
    },
    {
        name: 'Downloads',
        pathName: '/downloads',
        Component: lazy(() => import('../modules/downloads/index')),
        navigateTo: '/downloads',
        showChild: false,
    },
    {
        name: 'Query Listing',
        pathName: '/querylisting',
        Component: lazy(() => import('../modules/queryListing/index')),
        navigateTo: '/querylisting'
    },
    {
        name: 'Submission',
        pathName: '/submission/*',
        Component: lazy(() => import('../modules/submission/index')),
        navigateTo: '/submission',
        showChild: true,
        renderChild: true,
        children: [
            {
                name: 'Data Exports',
                pathName: 'dataexport',
                Component: lazy(() => import('../modules/submission/modules/dataExport/DataExport')),
                navigateTo: 'submission/dataexport',
            },
            {
                name: 'Case Books',
                pathName: 'casebooks',
                Component: lazy(() => import('../modules/submission/modules/caseBooks/CaseBooks')),
                navigateTo: 'submission/casebooks'
            },
        ]
    },
    {
        name: 'Reports',
        pathName: '/reports/*',
        Component: lazy(() => import('../modules/reports/index')),
        navigateTo: '/reports',
        showChild: true,
        children: [
            {
                name: 'Lock status report',
                pathName: 'lockStatusReport',
                Component: lazy(() => import('../modules/reports/components/Reports')),
                navigateTo: '/reports/lockStatusReport'
            },
            {
                name: 'Clean patient report',
                pathName: 'cleanPatientReport',
                Component: lazy(() => import('../modules/reports/components/Reports')),
                navigateTo: '/reports/cleanPatientReport'
            },
            {
                name: 'Form status report',
                pathName: 'formStatusReports',
                Component: lazy(() => import('../modules/reports/components/Reports')),
                navigateTo: '/reports/formStatusReports'
            },
            {
                name: 'Monitor report',
                pathName: 'monitorReports',
                Component: lazy(() => import('../modules/reports/components/Reports')),
                navigateTo: '/reports/monitorReports'
            },
            {
                name: 'Site listing report',
                pathName: 'siteListingReport',
                Component: lazy(() => import('../modules/reports/components/Reports')),
                navigateTo: '/reports/siteListingReport'
            },
            {
                name: 'Query details report',
                pathName: 'queryDetailsReports',
                Component: lazy(() => import('../modules/reports/components/Reports')),
                navigateTo: '/reports/queryDetailsReports'
            },
            {
                name: 'PI report',
                pathName: 'piReports',
                Component: lazy(() => import('../modules/reports/components/Reports')),
                navigateTo: '/reports/piReports'
            },
            {
                name: 'Audit report',
                pathName: 'auditReport',
                Component: lazy(() => import('../modules/reports/components/Reports')),
                navigateTo: '/reports/auditReport'
            },
            {
                name: 'Sticky notes report',
                pathName: 'stickyNotesReports',
                Component: lazy(() => import('../modules/reports/components/Reports')),
                navigateTo: '/reports/stickyNotesReports'
            },
            {
                name: 'Forms status report by subject',
                pathName: 'formStatusReportBySubject',
                Component: lazy(() => import('../modules/reports/components/Reports')),
                navigateTo: '/reports/formStatusReportBySubject'
            },
            {
                name: 'Query rate by variable report',
                pathName: 'queryRateByVariableReport',
                Component: lazy(() => import('../modules/reports/components/Reports')),
                navigateTo: '/reports/queryRateByVariableReport'
            },
            {
                name: 'Form status report by site',
                pathName: 'formStatusReportBysite',
                Component: lazy(() => import('../modules/reports/components/Reports')),
                navigateTo: '/reports/formStatusReportBysite'
            },
            {
                name: 'Query aging report',
                pathName: 'queryAgingReport',
                Component: lazy(() => import('../modules/reports/components/Reports')),
                navigateTo: '/reports/queryAgingReport'
            },
            {
                name: 'Variable status report',
                pathName: 'variableStatusReports',
                Component: lazy(() => import('../modules/reports/components/Reports')),
                navigateTo: '/reports/variableStatusReports'
            },
            {
                name: 'Query rate by form report',
                pathName: 'queryRateByFormReports',
                Component: lazy(() => import('../modules/reports/components/Reports')),
                navigateTo: '/reports/queryRateByFormReports'
            },
            {
                name: 'Query rate by site report',
                pathName: 'queryRateBySiteReports',
                Component: lazy(() => import('../modules/reports/components/Reports')),
                navigateTo: '/reports/queryRateBySiteReports'
            },
            {
                name: 'Reason for change report',
                pathName: 'reasonForChangeReport',
                Component: lazy(() => import('../modules/reports/components/Reports')),
                navigateTo: '/reports/reasonForChangeReport'
            },
            {
                name: 'Query assigned to report',
                pathName: 'queryAssignedToReports',
                Component: lazy(() => import('../modules/reports/components/Reports')),
                navigateTo: '/reports/queryAssignedToReports'
            },
            {
                name: 'User details report',
                pathName: 'userDetailsReports',
                Component: lazy(() => import('../modules/reports/components/Reports')),
                navigateTo: '/reports/userDetailsReports'
            },
            {
                name: 'User login audit details',
                pathName: 'userLoginAuditDetails',
                Component: lazy(() => import('../modules/reports/components/Reports')),
                navigateTo: '/reports/userLoginAuditDetails'
            },
            {
                name: 'Subject status report',
                pathName: 'subjectStatusReport',
                Component: lazy(() => import('../modules/reports/components/Reports')),
                navigateTo: '/reports/subjectStatusReport'
            },
            {
                name: 'Files data report',
                pathName: 'filesDataReports',
                Component: lazy(() => import('../modules/reports/components/Reports')),
                navigateTo: '/reports/filesDataReports'
            },
        ]
    },
    {
        name: 'Approvals',
        pathName: '/approvals/*',
        Component: lazy(() => import('../modules/approvals/index')),
        navigateTo: '/approvals',
        showChild: true,
        renderChild: true,
        children: [
            {
                name: 'Bulk Review',
                pathName: 'bulkreview',
                Component: lazy(() => import('../modules/approvals/modules/bulkReview/BulkReview')),
                navigateTo: 'approvals/bulkreview'
            },
            {
                name: 'Bulk Monitor',
                pathName: 'bulkmonitor',
                Component: lazy(() => import('../modules/approvals/modules/bulkMonitor/BulkMonitor')),
                navigateTo: 'approvals/bulkmonitor'
            },
            {
                name: 'Bulk Sign',
                pathName: 'bulksign',
                Component: lazy(() => import('../modules/approvals/modules/bulkSign/BulkSign')),
                navigateTo: 'approvals/bulksign'
            },
        ]
    },
    {
        name: 'Bulk Lock',
        pathName: '/bulklock',
        Component: lazy(() => import('../modules/bulkLock/components/BulkLock')),
        navigateTo: '/bulklock'
    },
    {
        name: 'User Management',
        pathName: '/usermanagement/*',
        Component: lazy(() => import('../modules/userManagement/index')),
        navigateTo: '/usermanagement',
        showChild: false,
        renderChild: true,
        children: [
            {
                name: 'User Management',
                pathName: '/',
                Component: lazy(() => import('../modules/userManagement/index')),
                navigateTo: '/',
            },
            {
                name: 'Create User',
                pathName: '/createUser/:id',
                Component: lazy(() => import('../modules/userManagement/components/CreateUser')),
                navigateTo: '/usermanagement/createUser',
            }
        ]
    },
    {
        name: 'Study SetUp',
        pathName: '/study/*',
        Component: lazy(() => import('../modules/studySetup/index')),
        navigateTo: '/study/study',
        showChild: false,
        renderChild: false,
        children: [
            {
                name: 'Study',
                pathName: 'study',
                Component: lazy(() => import('../modules/studySetup/modules/study')),
                navigateTo: 'study',
            },
            {
                name: 'Sites',
                pathName: 'sites',
                Component: lazy(() => import('../modules/studySetup/modules/sites')),
                navigateTo: 'sites'
            },
            {
                name: 'Visits',
                pathName: 'visits',
                Component: lazy(() => import('../modules/studySetup/modules/visits')),
                navigateTo: 'visits'
            },
            {
                name: 'SelectForms&Variables',
                pathName: '/assignFormsToVisit/:id',
                Component: lazy(() => import('../modules/studySetup/modules/visits/components/SelectFormVariables')),
                navigateTo: '/'
            },
            {
                name: 'Forms',
                pathName: 'forms',
                Component: lazy(() => import('../modules/studySetup/modules/forms')),
                navigateTo: 'forms'
            },
            {
                name: 'EditForm',
                pathName: '/EditForm/:id',
                Component: lazy(() => import('../modules/studySetup/modules/forms/components/formBuilder/Layout')),
                navigateTo: '/'
            },
            {
                name: 'Field Level Dynamics',
                pathName: 'dynamics',
                Component: lazy(() => import('../modules/studySetup/modules/fieldLevelDynamics')),
                navigateTo: 'dynamics'
            },
            {
                name: 'Create Field Level Dynamics',
                pathName: '/dynamics/:id',
                Component: lazy(() => import('../modules/studySetup/modules/fieldLevelDynamics/components/fieldDynamics/CreateFiledDynamics')),
                navigateTo: '/'
            },
            {
                name: 'Derivations',
                pathName: '/derivation/*',
                Component: lazy(() => import('../modules/studySetup/modules/derivations')),
                navigateTo: 'derivations'
            },
            {
                name: 'create Derivation',
                pathName: '/derivation/:id',
                Component: lazy(() => import('../modules/studySetup/modules/derivations/components/createDerivation/CreateDerivation')),
                navigateTo: 'derivations'
            },
            {
                name: 'Rules',
                pathName: 'rules',
                Component: lazy(() => import('../modules/studySetup/modules/rules')),
                navigateTo: 'rules'
            },
            {
                name: 'Rules',
                pathName: 'createRules',
                Component: lazy(() => import('../modules/studySetup/modules/rules/components/createRules/CreateRules')),
                navigateTo: '/'
            },
            {
                name: 'Labs',
                pathName: '/labs/*',
                Component: lazy(() => import('../modules/studySetup/modules/labs')),
                navigateTo: 'labs'
            },
            {
                name: 'Labs',
                pathName: '/labCategory/:id',
                Component: lazy(() => import('../modules/studySetup/modules/labs/components/labBuilder/labCategory/Category')),
                navigateTo: 'labs'
            },
            {
                name: 'Labs',
                pathName: '/labTest/:id',
                Component: lazy(() => import('../modules/studySetup/modules/labs/components/labBuilder/labTest/Test')),
                navigateTo: 'labs'
            },
            {
                name: 'Labs',
                pathName: '/labUnit/:id',
                Component: lazy(() => import('../modules/studySetup/modules/labs/components/labBuilder/labUnit/Unit')),
                navigateTo: 'labs'
            },
            {
                name: 'Labs',
                pathName: '/labRange/:id',
                Component: lazy(() => import('../modules/studySetup/modules/labs/components/labRangeBuilder/LabRange')),
                navigateTo: 'labs'
            },
            {
                name: 'Roles & Permissions',
                pathName: '/roles',
                Component: lazy(() => import('../modules/studySetup/modules/rolesandPermissions')),
                navigateTo: 'roles'
            },
            {
                name: 'Create Roles & Permissions',
                pathName: '/roles/:id',
                Component: lazy(() => import('../modules/studySetup/modules/rolesandPermissions/components/CreateRolesandPermissions')),
                navigateTo: 'roles'
            },
            {
                name: 'Study Migration',
                pathName: 'studyMigration',
                Component: lazy(() => import('../modules/studySetup/modules/studyMigration')),
                navigateTo: 'studyMigration'
            },
            {
                name: 'Audit Log',
                pathName: 'auditLogs',
                Component: lazy(() => import('../modules/studySetup/modules/auditLogs')),
                navigateTo: 'auditLogs'
            },

        ]

    },
]