export const studyData: any = {
    "StudyName": "Test Study - 04May2022",
    "data": {
        "Studies": [
            {
                "StudyName": "File Upload Study 1",
                "StudyId": 2091,
                "Studysites": {
                    "Sites": [
                        {
                            "siteName": "site22",
                            "siteId": 2713
                        }
                    ]
                },
                "checked": false
            },
            {
                "StudyName": "FOL-102",
                "StudyId": 6,
                "Studysites": {
                    "Sites": [
                        {
                            "siteName": "A_545",
                            "siteId": 2213
                        },
                        {
                            "siteName": "A_71028",
                            "siteId": 2341
                        },
                        {
                            "siteName": "apollo",
                            "siteId": 1433
                        },
                        {
                            "siteName": "apollo12",
                            "siteId": 1424
                        },
                        {
                            "siteName": "ayurved",
                            "siteId": 1461
                        },
                        {
                            "siteName": "Gabrail Cancer Center",
                            "siteId": 8
                        },
                        {
                            "siteName": "Site_01",
                            "siteId": 1428
                        },
                        {
                            "siteName": "Site_02",
                            "siteId": 1432
                        },
                        {
                            "siteName": "site1",
                            "siteId": 22
                        },
                        {
                            "siteName": "Site10",
                            "siteId": 1423
                        },
                        {
                            "siteName": "Site_10",
                            "siteId": 1460
                        },
                        {
                            "siteName": "test site",
                            "siteId": 2094
                        },
                        {
                            "siteName": "visitSite",
                            "siteId": 1427
                        },
                        {
                            "siteName": "visitsite1",
                            "siteId": 1431
                        }
                    ]
                },
                "checked": false
            },
            {
                "StudyName": "IQA DEMO Study",
                "StudyId": 1,
                "Studysites": {
                    "Sites": [
                        {
                            "siteName": "A_09570",
                            "siteId": 2045
                        },
                        {
                            "siteName": "a1",
                            "siteId": 2247
                        },
                        {
                            "siteName": "A_16940",
                            "siteId": 1750
                        },
                        {
                            "siteName": "a2",
                            "siteId": 2248
                        },
                        {
                            "siteName": "A_20279",
                            "siteId": 2046
                        },
                        {
                            "siteName": "A_2234",
                            "siteId": 12
                        },
                        {
                            "siteName": "A_23041",
                            "siteId": 2042
                        },
                        {
                            "siteName": "A_27283",
                            "siteId": 2101
                        },
                        {
                            "siteName": "a3",
                            "siteId": 2249
                        },
                        {
                            "siteName": "A_30942",
                            "siteId": 1696
                        },
                        {
                            "siteName": "A_3520",
                            "siteId": 1751
                        },
                        {
                            "siteName": "A_40733",
                            "siteId": 2044
                        },
                        {
                            "siteName": "A_41705",
                            "siteId": 1753
                        },
                        {
                            "siteName": "A_4565",
                            "siteId": 49
                        },
                        {
                            "siteName": "A_59358",
                            "siteId": 1752
                        },
                        {
                            "siteName": "A_59811",
                            "siteId": 2047
                        },
                        {
                            "siteName": "A_6328",
                            "siteId": 1553
                        },
                        {
                            "siteName": "A_6865",
                            "siteId": 1481
                        },
                        {
                            "siteName": "A_8020",
                            "siteId": 1458
                        },
                        {
                            "siteName": "A_8197",
                            "siteId": 1508
                        },
                        {
                            "siteName": "A_9328",
                            "siteId": 1554
                        },
                        {
                            "siteName": "abc",
                            "siteId": 1747
                        },
                        {
                            "siteName": "A_mv3545",
                            "siteId": 2043
                        },
                        {
                            "siteName": "ap",
                            "siteId": 2074
                        },
                        {
                            "siteName": "CHENNAI",
                            "siteId": 2244
                        },
                        {
                            "siteName": "def",
                            "siteId": 1748
                        },
                        {
                            "siteName": "fg67",
                            "siteId": 1665
                        },
                        {
                            "siteName": "ghi",
                            "siteId": 1749
                        },
                        {
                            "siteName": "hyd",
                            "siteId": 2217
                        },
                        {
                            "siteName": "jkl",
                            "siteId": 1776
                        },
                        {
                            "siteName": "kanada2",
                            "siteId": 2220
                        },
                        {
                            "siteName": "sai",
                            "siteId": 2171
                        },
                        {
                            "siteName": "site21",
                            "siteId": 2199
                        },
                        {
                            "siteName": "SIte 3",
                            "siteId": 11
                        },
                        {
                            "siteName": "Site333",
                            "siteId": 10
                        },
                        {
                            "siteName": "site 4",
                            "siteId": 13
                        },
                        {
                            "siteName": "site50",
                            "siteId": 2198
                        },
                        {
                            "siteName": "TAMIL",
                            "siteId": 2218
                        },
                        {
                            "siteName": "uknow",
                            "siteId": 2116
                        },
                        {
                            "siteName": "uppi hospital",
                            "siteId": 1779
                        },
                        {
                            "siteName": "Z_1794",
                            "siteId": 141
                        }
                    ]
                },
                "checked": false
            },
            {
                "StudyName": "IQA_TEST_Study",
                "StudyId": 2612,
                "Studysites": {
                    "Sites": [
                        {
                            "siteName": "Apollo",
                            "siteId": 2677
                        },
                        {
                            "siteName": "KIMS",
                            "siteId": 2687
                        },
                        {
                            "siteName": "NIMS",
                            "siteId": 2678
                        },
                        {
                            "siteName": "NIMS12",
                            "siteId": 2770
                        },
                        {
                            "siteName": "REDDY",
                            "siteId": 2695
                        },
                        {
                            "siteName": "site1",
                            "siteId": 2613
                        },
                        {
                            "siteName": "Site2",
                            "siteId": 2649
                        },
                        {
                            "siteName": "Site3",
                            "siteId": 2657
                        },
                        {
                            "siteName": "Site4",
                            "siteId": 2658
                        },
                        {
                            "siteName": "Site5",
                            "siteId": 2659
                        },
                        {
                            "siteName": "Site6",
                            "siteId": 2674
                        },
                        {
                            "siteName": "Site7",
                            "siteId": 2675
                        },
                        {
                            "siteName": "Site8",
                            "siteId": 2676
                        }
                    ]
                },
                "checked": false
            },
            {
                "StudyName": "Migration_Study",
                "StudyId": 3155,
                "Studysites": {
                    "Sites": [
                        {
                            "siteName": "A_73669",
                            "siteId": 3245
                        },
                        {
                            "siteName": "A_88125",
                            "siteId": 3247
                        },
                        {
                            "siteName": "B_41287",
                            "siteId": 3246
                        },
                        {
                            "siteName": "Site_2",
                            "siteId": 3198
                        },
                        {
                            "siteName": "Site_@2",
                            "siteId": 3199
                        }
                    ]
                },
                "checked": false
            },
            {
                "StudyName": "Test Study - 04May2022",
                "StudyId": 2196,
                "Studysites": {
                    "Sites": [
                        {
                            "siteName": "A_00006",
                            "siteId": 3137
                        },
                        {
                            "siteName": "A_00412",
                            "siteId": 3262
                        },
                        {
                            "siteName": "A_00545",
                            "siteId": 3131
                        },
                        {
                            "siteName": "A_01253",
                            "siteId": 3182
                        },
                        {
                            "siteName": "A_0261",
                            "siteId": 3107
                        },
                        {
                            "siteName": "A_0344",
                            "siteId": 3101
                        },
                        {
                            "siteName": "A_04749",
                            "siteId": 3251
                        },
                        {
                            "siteName": "A_05946",
                            "siteId": 3255
                        },
                        {
                            "siteName": "A_07411",
                            "siteId": 3176
                        },
                        {
                            "siteName": "A_18081",
                            "siteId": 3117
                        },
                        {
                            "siteName": "A_23374",
                            "siteId": 3257
                        },
                        {
                            "siteName": "A_25351",
                            "siteId": 3115
                        },
                        {
                            "siteName": "A_26288",
                            "siteId": 3135
                        },
                        {
                            "siteName": "A_2665",
                            "siteId": 3168
                        },
                        {
                            "siteName": "A_28793",
                            "siteId": 3174
                        },
                        {
                            "siteName": "A_31637",
                            "siteId": 3261
                        },
                        {
                            "siteName": "A_35537",
                            "siteId": 3170
                        },
                        {
                            "siteName": "A_36782",
                            "siteId": 3161
                        },
                        {
                            "siteName": "A_41104",
                            "siteId": 3180
                        },
                        {
                            "siteName": "A_4156",
                            "siteId": 3159
                        },
                        {
                            "siteName": "A_47656",
                            "siteId": 3178
                        },
                        {
                            "siteName": "A_4831",
                            "siteId": 3094
                        },
                        {
                            "siteName": "A_48331",
                            "siteId": 3129
                        },
                        {
                            "siteName": "A_49169",
                            "siteId": 3186
                        },
                        {
                            "siteName": "A_49861",
                            "siteId": 3260
                        },
                        {
                            "siteName": "A_49915",
                            "siteId": 3258
                        },
                        {
                            "siteName": "A_50756",
                            "siteId": 3133
                        },
                        {
                            "siteName": "A_54443",
                            "siteId": 3225
                        },
                        {
                            "siteName": "A_555",
                            "siteId": 3081
                        },
                        {
                            "siteName": "A_5773",
                            "siteId": 3091
                        },
                        {
                            "siteName": "A_5836",
                            "siteId": 3157
                        },
                        {
                            "siteName": "A_58588",
                            "siteId": 3123
                        },
                        {
                            "siteName": "A_58834",
                            "siteId": 3250
                        },
                        {
                            "siteName": "A_6309",
                            "siteId": 3087
                        },
                        {
                            "siteName": "A_6425",
                            "siteId": 3105
                        },
                        {
                            "siteName": "A_65101",
                            "siteId": 3113
                        },
                        {
                            "siteName": "A_65901",
                            "siteId": 3119
                        },
                        {
                            "siteName": "A_666",
                            "siteId": 3083
                        },
                        {
                            "siteName": "A_68110",
                            "siteId": 3263
                        },
                        {
                            "siteName": "A_69531",
                            "siteId": 3163
                        },
                        {
                            "siteName": "A_69655",
                            "siteId": 3125
                        },
                        {
                            "siteName": "A_72308",
                            "siteId": 3141
                        },
                        {
                            "siteName": "A_72906",
                            "siteId": 3127
                        },
                        {
                            "siteName": "A_75428",
                            "siteId": 3259
                        },
                        {
                            "siteName": "A_75709",
                            "siteId": 3248
                        },
                        {
                            "siteName": "A_777",
                            "siteId": 3082
                        },
                        {
                            "siteName": "A_78156",
                            "siteId": 3089
                        },
                        {
                            "siteName": "A_78313",
                            "siteId": 3103
                        },
                        {
                            "siteName": "A_79297",
                            "siteId": 3139
                        },
                        {
                            "siteName": "A_79578",
                            "siteId": 3121
                        },
                        {
                            "siteName": "A_79628",
                            "siteId": 3188
                        },
                        {
                            "siteName": "A_80596",
                            "siteId": 3109
                        },
                        {
                            "siteName": "A_8089",
                            "siteId": 3166
                        },
                        {
                            "siteName": "A_85492",
                            "siteId": 3111
                        },
                        {
                            "siteName": "A_85586",
                            "siteId": 3172
                        },
                        {
                            "siteName": "A_85769",
                            "siteId": 3256
                        },
                        {
                            "siteName": "A_8670",
                            "siteId": 3084
                        },
                        {
                            "siteName": "A_87762",
                            "siteId": 3184
                        },
                        {
                            "siteName": "A_9256",
                            "siteId": 3099
                        },
                        {
                            "siteName": "A_999",
                            "siteId": 3080
                        },
                        {
                            "siteName": "ads",
                            "siteId": 3226
                        },
                        {
                            "siteName": "adsa",
                            "siteId": 3227
                        },
                        {
                            "siteName": "A_eg6618",
                            "siteId": 3086
                        },
                        {
                            "siteName": "AfaFWKM",
                            "siteId": 3241
                        },
                        {
                            "siteName": "Amrutha hospital",
                            "siteId": 3143
                        },
                        {
                            "siteName": "aqqqq",
                            "siteId": 3222
                        },
                        {
                            "siteName": "asdf",
                            "siteId": 3194
                        },
                        {
                            "siteName": "asdfd123",
                            "siteId": 3223
                        },
                        {
                            "siteName": "A_tx5761",
                            "siteId": 3093
                        },
                        {
                            "siteName": "B_00414",
                            "siteId": 3095
                        },
                        {
                            "siteName": "B_05462",
                            "siteId": 3167
                        },
                        {
                            "siteName": "B_11443",
                            "siteId": 3112
                        },
                        {
                            "siteName": "B_14661",
                            "siteId": 3189
                        },
                        {
                            "siteName": "B_14852",
                            "siteId": 3092
                        },
                        {
                            "siteName": "B_16314",
                            "siteId": 3102
                        },
                        {
                            "siteName": "B_16980",
                            "siteId": 3177
                        },
                        {
                            "siteName": "B_17950",
                            "siteId": 3132
                        },
                        {
                            "siteName": "B_20068",
                            "siteId": 3085
                        },
                        {
                            "siteName": "B_22613",
                            "siteId": 3249
                        },
                        {
                            "siteName": "B_23866",
                            "siteId": 3116
                        },
                        {
                            "siteName": "B_23924",
                            "siteId": 3187
                        },
                        {
                            "siteName": "B_24049",
                            "siteId": 3108
                        },
                        {
                            "siteName": "B_26978",
                            "siteId": 3175
                        },
                        {
                            "siteName": "B_30172",
                            "siteId": 3162
                        },
                        {
                            "siteName": "B_31799",
                            "siteId": 3124
                        },
                        {
                            "siteName": "B_33183",
                            "siteId": 3128
                        },
                        {
                            "siteName": "B_33865",
                            "siteId": 3134
                        },
                        {
                            "siteName": "B_34646",
                            "siteId": 3160
                        },
                        {
                            "siteName": "B_36699",
                            "siteId": 3130
                        },
                        {
                            "siteName": "B_37664",
                            "siteId": 3114
                        },
                        {
                            "siteName": "B_38467",
                            "siteId": 3106
                        },
                        {
                            "siteName": "B_49374",
                            "siteId": 3169
                        },
                        {
                            "siteName": "B_51105",
                            "siteId": 3173
                        },
                        {
                            "siteName": "B_56183",
                            "siteId": 3110
                        },
                        {
                            "siteName": "B_64995",
                            "siteId": 3100
                        },
                        {
                            "siteName": "B_66992",
                            "siteId": 3179
                        },
                        {
                            "siteName": "B_68148",
                            "siteId": 3164
                        },
                        {
                            "siteName": "B_68358",
                            "siteId": 3136
                        },
                        {
                            "siteName": "B_69415",
                            "siteId": 3122
                        },
                        {
                            "siteName": "B_72733",
                            "siteId": 3183
                        },
                        {
                            "siteName": "B_73520",
                            "siteId": 3158
                        },
                        {
                            "siteName": "B_73704",
                            "siteId": 3090
                        },
                        {
                            "siteName": "B_75052",
                            "siteId": 3118
                        },
                        {
                            "siteName": "B_76671",
                            "siteId": 3138
                        },
                        {
                            "siteName": "B_77332",
                            "siteId": 3140
                        },
                        {
                            "siteName": "B_77354",
                            "siteId": 3142
                        },
                        {
                            "siteName": "B_79418",
                            "siteId": 3126
                        },
                        {
                            "siteName": "B_81212",
                            "siteId": 3171
                        },
                        {
                            "siteName": "B_83254",
                            "siteId": 3185
                        },
                        {
                            "siteName": "B_83620",
                            "siteId": 3104
                        },
                        {
                            "siteName": "B_84662",
                            "siteId": 3181
                        },
                        {
                            "siteName": "B_93329",
                            "siteId": 3120
                        },
                        {
                            "siteName": "B_95091",
                            "siteId": 3088
                        },
                        {
                            "siteName": "BlierUn",
                            "siteId": 3244
                        },
                        {
                            "siteName": "dfjkgvnl,dbshndb",
                            "siteId": 3253
                        },
                        {
                            "siteName": "f@#$fgvhbjnk",
                            "siteId": 3252
                        },
                        {
                            "siteName": "ghj",
                            "siteId": 3254
                        },
                        {
                            "siteName": "hgj",
                            "siteId": 3242
                        },
                        {
                            "siteName": "jhg",
                            "siteId": 3200
                        },
                        {
                            "siteName": "Kohli",
                            "siteId": 3151
                        },
                        {
                            "siteName": "kt",
                            "siteId": 3190
                        },
                        {
                            "siteName": "LAB_R",
                            "siteId": 3217
                        },
                        {
                            "siteName": "mnb",
                            "siteId": 3220
                        },
                        {
                            "siteName": "pBLKqGc",
                            "siteId": 3243
                        },
                        {
                            "siteName": "Rahul",
                            "siteId": 3150
                        },
                        {
                            "siteName": "rarbrcrrarr123",
                            "siteId": 3228
                        },
                        {
                            "siteName": "rarbrcrrr123",
                            "siteId": 3229
                        },
                        {
                            "siteName": "Rohit",
                            "siteId": 3149
                        },
                        {
                            "siteName": "Site10",
                            "siteId": 3191
                        },
                        {
                            "siteName": "Site106",
                            "siteId": 3192
                        },
                        {
                            "siteName": "Site123",
                            "siteId": 3097
                        },
                        {
                            "siteName": "Site_A101",
                            "siteId": 3016
                        },
                        {
                            "siteName": "Site_Control_5",
                            "siteId": 3224
                        },
                        {
                            "siteName": "t",
                            "siteId": 3165
                        },
                        {
                            "siteName": "u7ythfr",
                            "siteId": 3221
                        },
                        {
                            "siteName": "virat",
                            "siteId": 3144
                        },
                        {
                            "siteName": "Virat Kohli",
                            "siteId": 3148
                        },
                        {
                            "siteName": "wedsa",
                            "siteId": 3196
                        },
                        {
                            "siteName": "wKQOrw",
                            "siteId": 3240
                        },
                        {
                            "siteName": "zxy",
                            "siteId": 3219
                        }
                    ]
                },
                "checked": true
            },
            {
                "StudyName": "Test Study 1",
                "StudyId": 1233,
                "Studysites": {
                    "Sites": [
                        {
                            "siteName": "A_0285",
                            "siteId": 1468
                        },
                        {
                            "siteName": "A_06008",
                            "siteId": 2029
                        },
                        {
                            "siteName": "A_13628",
                            "siteId": 2369
                        },
                        {
                            "siteName": "A_2309",
                            "siteId": 1448
                        },
                        {
                            "siteName": "A_2533",
                            "siteId": 1445
                        },
                        {
                            "siteName": "A_29654",
                            "siteId": 2034
                        },
                        {
                            "siteName": "A_545",
                            "siteId": 2215
                        },
                        {
                            "siteName": "A_5647",
                            "siteId": 1238
                        },
                        {
                            "siteName": "A_5985",
                            "siteId": 1447
                        },
                        {
                            "siteName": "A_61240",
                            "siteId": 2384
                        },
                        {
                            "siteName": "A_62916",
                            "siteId": 2031
                        },
                        {
                            "siteName": "A_6854",
                            "siteId": 1237
                        },
                        {
                            "siteName": "A_7204",
                            "siteId": 1446
                        },
                        {
                            "siteName": "A_78503",
                            "siteId": 1875
                        },
                        {
                            "siteName": "A_7929",
                            "siteId": 1241
                        },
                        {
                            "siteName": "A_83977",
                            "siteId": 1768
                        },
                        {
                            "siteName": "A_85522",
                            "siteId": 2383
                        },
                        {
                            "siteName": "A_87407",
                            "siteId": 2382
                        },
                        {
                            "siteName": "A_9018",
                            "siteId": 1469
                        },
                        {
                            "siteName": "A_9915",
                            "siteId": 1456
                        },
                        {
                            "siteName": "B_00",
                            "siteId": 1236
                        },
                        {
                            "siteName": "B_0003",
                            "siteId": 1240
                        },
                        {
                            "siteName": "fdgfg",
                            "siteId": 2381
                        },
                        {
                            "siteName": "IQASite",
                            "siteId": 2495
                        },
                        {
                            "siteName": "S3M_10427",
                            "siteId": 1840
                        },
                        {
                            "siteName": "S3M_95217",
                            "siteId": 1839
                        },
                        {
                            "siteName": "site11",
                            "siteId": 2494
                        },
                        {
                            "siteName": "SiteABC",
                            "siteId": 2557
                        },
                        {
                            "siteName": "Test Site",
                            "siteId": 1235
                        },
                        {
                            "siteName": "UJ",
                            "siteId": 2380
                        }
                    ]
                },
                "checked": false
            },
            {
                "StudyName": "Test_study_2411",
                "StudyId": 1215,
                "Studysites": {
                    "Sites": [
                        {
                            "siteName": "site1",
                            "siteId": 1216
                        }
                    ]
                },
                "checked": false
            },
            {
                "StudyName": "Test Study - 31Mar2022",
                "StudyId": 2048,
                "Studysites": {
                    "Sites": [
                        {
                            "siteName": "A_10356",
                            "siteId": 2641
                        },
                        {
                            "siteName": "A_15029",
                            "siteId": 2640
                        },
                        {
                            "siteName": "A_2260",
                            "siteId": 2778
                        },
                        {
                            "siteName": "A_23532",
                            "siteId": 2633
                        },
                        {
                            "siteName": "A_34457",
                            "siteId": 2637
                        },
                        {
                            "siteName": "A_36634",
                            "siteId": 2780
                        },
                        {
                            "siteName": "A_57225",
                            "siteId": 2779
                        },
                        {
                            "siteName": "A_5781",
                            "siteId": 2639
                        },
                        {
                            "siteName": "A_60635",
                            "siteId": 2830
                        },
                        {
                            "siteName": "A_63190",
                            "siteId": 2831
                        },
                        {
                            "siteName": "A_72130",
                            "siteId": 2636
                        },
                        {
                            "siteName": "A_7456",
                            "siteId": 2751
                        },
                        {
                            "siteName": "A_75988",
                            "siteId": 2777
                        },
                        {
                            "siteName": "A_7904",
                            "siteId": 2638
                        },
                        {
                            "siteName": "A_82777",
                            "siteId": 2634
                        },
                        {
                            "siteName": "A_98641",
                            "siteId": 2755
                        },
                        {
                            "siteName": "apolloz",
                            "siteId": 2782
                        },
                        {
                            "siteName": "dfdf23",
                            "siteId": 2635
                        },
                        {
                            "siteName": "dfsf",
                            "siteId": 2798
                        },
                        {
                            "siteName": "fvv   -2",
                            "siteId": 2874
                        },
                        {
                            "siteName": "jkhk",
                            "siteId": 2754
                        },
                        {
                            "siteName": "jkk",
                            "siteId": 2781
                        },
                        {
                            "siteName": "kims",
                            "siteId": 2804
                        },
                        {
                            "siteName": "kmjk",
                            "siteId": 2771
                        },
                        {
                            "siteName": "sfsfsd",
                            "siteId": 2903
                        },
                        {
                            "siteName": "Site 001",
                            "siteId": 2049
                        },
                        {
                            "siteName": "Site834",
                            "siteId": 2752
                        },
                        {
                            "siteName": "sow",
                            "siteId": 2875
                        },
                        {
                            "siteName": "testSIte",
                            "siteId": 2769
                        }
                    ]
                },
                "checked": false
            }
        ]
    },
    "id": 2196
}