export const queryData = {
    "stickyNote": [],
    "discrepancyNotes": {
        "assignUsersList": [
            {
                "userName": "Pankaj Prajapati(pprajapati)",
                "userId": 414
            },
            {
                "userName": "sarfaraz alam(salam)",
                "userId": 417
            },
            {
                "userName": "Swathi Meesaragandam(Mswathi1)",
                "userId": 349
            },
            {
                "userName": "Ravikumar Thanugula(rkthanugula)",
                "userId": 306
            },
            {
                "userName": "Pradeep Medidhi(pmedidhi)",
                "userId": 16
            },
            {
                "userName": "Nikhila Seemakurthi(nseemakurthi)",
                "userId": 259
            },
            {
                "userName": "Swathi meesaragandam(smeesaragandam)",
                "userId": 15
            },
            {
                "userName": "Srilekha Gari(sgari)",
                "userId": 80
            },
            {
                "userName": "sirisha kuruva(skuruva1)",
                "userId": 319
            },
            {
                "userName": "Ganesh Vadde(gvadde)",
                "userId": 421
            },
            {
                "userName": "Ganesg Vadde(gvadde1)",
                "userId": 427
            },
            {
                "userName": "Srinivas Kolloju(skolloju)",
                "userId": 411
            },
            {
                "userName": "RamPrasad  Chitturi(rchitturi)",
                "userId": 430
            },
            {
                "userName": "Pankaj Prajapati(pprajapati1)",
                "userId": 431
            },
            {
                "userName": "Ram Prasad Chitturi(rchitturi1)",
                "userId": 432
            },
            {
                "userName": "Geetha Nagireddy(gnagireddy)",
                "userId": 434
            },
            {
                "userName": "Geetha Nagireddy(geetha1)",
                "userId": 437
            }
        ],
        "crfName": "Inference1",
        "itemName": "WORK",
        "dnDetails": [
            {
                "parentQueryId": 56746,
                "parentAssignedUser": "Mswathi1",
                "parentDescription": "please select your work",
                "parentCurrentStatus": "Reopen",
                "respondQuery": true,
                "assignQuery": false,
                "reQuery": false,
                "parentQueryType": "System_Query",
                "closeQuery": true,
                "parentCreatedDate": "01/09/2023 12:53:30",
                "parentCreatedBy": "system",
                "cnDetails": [
                    {
                        "createdDate": "01/09/2023 12:53:30",
                        "currentStatus": "Open",
                        "createdBy": "system",
                        "description": "please select your work",
                        "assignedUser": "",
                        "queryId": 56747,
                        "queryType": "System_Query"
                    },
                    {
                        "createdDate": "01/12/2023 16:55:27",
                        "currentStatus": "Closed",
                        "createdBy": "Mswathi1",
                        "description": "Query fired by error",
                        "assignedUser": "",
                        "queryId": 56776,
                        "queryType": "System_Query"
                    },
                    {
                        "createdDate": "01/12/2023 17:33:14",
                        "currentStatus": "Reopen",
                        "createdBy": "Mswathi1",
                        "description": "erfghj",
                        "assignedUser": "gvadde1",
                        "queryId": 56783,
                        "queryType": "System_Query"
                    },
                    {
                        "createdDate": "01/12/2023 17:47:06",
                        "currentStatus": "Closed",
                        "createdBy": "Mswathi1",
                        "description": "Data Consistent with source",
                        "assignedUser": "",
                        "queryId": 56784,
                        "queryType": "System_Query"
                    },
                    {
                        "createdDate": "01/12/2023 17:47:23",
                        "currentStatus": "Reopen",
                        "createdBy": "Mswathi1",
                        "description": "uyjuj",
                        "assignedUser": "smeesaragandam",
                        "queryId": 56785,
                        "queryType": "System_Query"
                    },
                    {
                        "createdDate": "01/20/2023 11:10:11",
                        "currentStatus": "Closed",
                        "createdBy": "smeesaragandam",
                        "description": "Additional Data Not Available",
                        "assignedUser": "",
                        "queryId": 56847,
                        "queryType": "System_Query"
                    },
                    {
                        "createdDate": "01/20/2023 11:14:02",
                        "currentStatus": "Reopen",
                        "createdBy": "smeesaragandam",
                        "description": "fddfdf",
                        "assignedUser": "",
                        "queryId": 56848,
                        "queryType": "System_Query"
                    }
                ]
            },
            {
                "parentQueryId": 56743,
                "parentAssignedUser": "Mswathi1",
                "parentDescription": "please select your work",
                "parentCurrentStatus": "Closed",
                "respondQuery": false,
                "assignQuery": false,
                "reQuery": true,
                "parentQueryType": "System_Query",
                "closeQuery": false,
                "parentCreatedDate": "01/09/2023 12:52:31",
                "parentCreatedBy": "system",
                "cnDetails": [
                    {
                        "createdDate": "01/09/2023 12:52:31",
                        "currentStatus": "Open",
                        "createdBy": "system",
                        "description": "please select your work",
                        "assignedUser": "",
                        "queryId": 56744,
                        "queryType": "System_Query"
                    },
                    {
                        "createdDate": "01/09/2023 12:52:46",
                        "currentStatus": "Closed",
                        "createdBy": "system",
                        "description": "System Query Closed with Correct Values",
                        "assignedUser": "",
                        "queryId": 56745,
                        "queryType": "System_Query"
                    }
                ]
            }
        ],
        "eventName": "inference"
    },
    "auditDetails": []
}