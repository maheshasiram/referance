import { closedQueires, respondQueries, reOpenQueries, stickyNotes } from "./dataTypes"


export const closedQueriesModal : closedQueires = {
    reason:'',
    otherReasonDescription:'',
    assignedUserForClosedQuery:''
}
export const respQueriesModal : respondQueries ={
    description:'',
    assignedUserForRespondQuery:''
}
export const reOpenQueryModal : reOpenQueries ={
    description:'',
    assignedUserForReopenQuery:''
}
export const stickyNotesModal : stickyNotes ={
    stickyNotesTitle:'',
    stickyNotesDescription : '',

}
