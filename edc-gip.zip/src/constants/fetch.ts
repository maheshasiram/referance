import axios from 'axios';
// import store from '../store/store'

export const fetch = (request:any) => {
    const options = {
        method: request.method,
        url: request.url,
        data: request.data,
        timeout: (60 * 2 * 1000), 
        headers: {
            "tenant-Id" : 'ABCD-1234'
        },
        responseType:request.responseType,
    };
    // store.dispatch(Loader(true));
    return axios(options)
        .then(response => {
            // console.log('.......___response', response);
            // store.dispatch(Loader(false));
            return response;
        });
}