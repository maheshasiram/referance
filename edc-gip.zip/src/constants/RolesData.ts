export const RolesData: any =
    [
        {
            "roleId": 478,
            "roleName": "Tstudy1",
            "checked": false
        },
        {
            "roleId": 362,
            "roleName": "CRC",
            "checked": false
        },
        {
            "roleId": 361,
            "roleName": "Study Developer",
            "checked": true
        },
        {
            "roleId": 363,
            "roleName": "Data Manager",
            "checked": false
        },
        {
            "roleId": 364,
            "roleName": "Monitor",
            "checked": false
        },
        {
            "roleId": 365,
            "roleName": "PI",
            "checked": false
        }
    ]