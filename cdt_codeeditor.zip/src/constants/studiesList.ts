export const studiesList = [
    {
        "id": 14,
        "studyName": "QA-12",
        "organization": {
            "id": 3,
            "orgName": "TestOrg_yfwb",
            "addressLine1": "Durgam cheruvu",
            "addressLine2": "Krishna Sapphire",
            "city": {
                "id": 6833,
                "name": "Eisenstadt",
                "state": {
                    "id": 280,
                    "name": "Burgenland",
                    "country": {
                        "id": 14,
                        "name": "Austria",
                        "countryCode": "AT",
                        "phoneCode": 43
                    }
                }
            },
            "state": {
                "id": 280,
                "name": "Burgenland",
                "country": {
                    "id": 14,
                    "name": "Austria",
                    "countryCode": "AT",
                    "phoneCode": 43
                }
            },
            "country": {
                "id": 14,
                "name": "Austria",
                "countryCode": "AT",
                "phoneCode": 43
            },
            "postalZipCode": "74124",
            "phone": "1277109130",
            "companyUrl": "iqaukkac.com",
            "passcode": "5NYM1Y7G1N",
            "isActive": true,
            "orgContacts": [
                {
                    "id": 13,
                    "organizationId": 3,
                    "firstName": "Monika",
                    "lastName": "Dronadula",
                    "email": "monika.dronadula1277@inductivequotient.com",
                    "phoneNo": "1277109130",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 26,
                        "name": "Primary Contact",
                        "code": "CONTACT_TYPE_PRIMARY_CONTACT",
                        "description": "Primary Contact For Organization",
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": null,
                    "studyId": null,
                    "orgName": null
                },
                {
                    "id": 16,
                    "organizationId": 3,
                    "firstName": "Swathi",
                    "lastName": "Meesaragandam",
                    "email": "swathi.meesaragandam1277@inductivequotient.com",
                    "phoneNo": "1277473588",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 44,
                        "name": "Others Contact",
                        "code": "CONTACT_TYPE_OTHERS_CONTACT",
                        "description": "Others Contact For Organization",
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": null,
                    "studyId": null,
                    "orgName": null
                }
            ],
            "orgDocuments": [],
            "orgShortname": "OrgStuazhf",
            "telephone": "1277473588",
            "orgType": {
                "id": 11,
                "name": "CRO",
                "code": "ORG_TYPE_CRO",
                "description": "indicates  organization type is cro",
                "configDataType": {
                    "id": 5,
                    "name": "Organization Type",
                    "code": "ORG_TYPE",
                    "description": "describes type of organization"
                }
            },
            "orgStudyStatus": false
        },
        "ctPhase": {
            "id": 23,
            "name": "Phase 2",
            "code": "STUDY_PHASE_PHASE2",
            "description": "indicates the study phase is phase 2",
            "configDataType": {
                "id": 11,
                "name": "Study Phase",
                "code": "STUDY_PHASE",
                "description": "describes the study phase"
            }
        },
        "approvalStatus": {
            "id": 6,
            "name": "Approved",
            "code": "WF_STATUS_TYPE_APPROVED",
            "description": "indicates the work flow  status approved",
            "configDataType": {
                "id": 2,
                "name": "Workflow Status",
                "code": "WF_STATUS_TYPE",
                "description": "describe workflow status of the user"
            }
        },
        "startDate": "2023-09-16",
        "endDate": "2023-09-25",
        "studySchema": "",
        "primaryContact": {
            "id": 24,
            "organizationId": 1,
            "firstName": "sravanthi",
            "lastName": "naramgari",
            "email": "sravanthi.naramgari@inductivequotient.com",
            "phoneNo": "1111111111",
            "contactDesgn": "",
            "contactType": {
                "id": 483,
                "name": "Primary Study Admin",
                "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                "description": null,
                "configDataType": {
                    "id": 13,
                    "name": "Contact Type",
                    "code": "CONTACT_TYPE",
                    "description": "descrides Contact Types"
                }
            },
            "active": true,
            "userName": "snaramgari",
            "studyId": 14,
            "orgName": "Clinic_123"
        },
        "secondaryContact": null,
        "request": {
            "id": 14,
            "reqObjectId": {
                "id": 18,
                "name": "Study Request Form",
                "code": "OBJECT_TYPE_STUDY_REQUEST_FORM",
                "description": "indicates the object is refering to study",
                "configDataType": {
                    "id": 9,
                    "name": "Object Type",
                    "code": "OBJECT_TYPE",
                    "description": "describes the type of the object for transaction"
                }
            },
            "reqWfStatusId": {
                "id": 6,
                "name": "Approved",
                "code": "WF_STATUS_TYPE_APPROVED",
                "description": "indicates the work flow  status approved",
                "configDataType": {
                    "id": 2,
                    "name": "Workflow Status",
                    "code": "WF_STATUS_TYPE",
                    "description": "describe workflow status of the user"
                }
            },
            "completedOn": "2023-09-19T03:49:13Z",
            "completedBy": 5
        },
        "approver": null,
        "studyRequestor": {
            "id": 5,
            "name": "snaramgari"
        },
        "studyType": {
            "id": 20,
            "name": "Clinical Trial",
            "code": "STUDY_TYPE_CLINICAL_TRIAL",
            "description": "indicates the study type is clinical trial",
            "configDataType": {
                "id": 10,
                "name": "Study Type",
                "code": "STUDY_TYPE",
                "description": "describes the study type as BABE / CT / Research etc"
            }
        },
        "protocolId": "QA-12",
        "comments": "",
        "studyDocuments": [
            {
                "id": 14,
                "fileName": "JD for references template (4).msg",
                "fileContentType": "application/vnd.ms-outlook",
                "study": "QA-12",
                "documentType": {
                    "id": 29,
                    "name": "Email",
                    "code": "DOC_TYPE_EMAIL",
                    "description": "Email Document Type",
                    "configDataType": {
                        "id": 14,
                        "name": "Document Type",
                        "code": "DOC_TYPE",
                        "description": "Document Type"
                    }
                }
            }
        ],
        "solutions": [
            {
                "id": 41,
                "name": "Inductive EDC",
                "code": "INDUCTIVE_EDC_APPLICATION",
                "description": "EDC Application",
                "configDataType": {
                    "id": 17,
                    "name": "Application",
                    "code": "APPLICATION",
                    "description": "EDC Solutions"
                }
            },
            {
                "id": 42,
                "name": "Clinical Data Quality",
                "code": "CLINICAL_DATA_QUALITY_APPLICATION",
                "description": "IWRS Application",
                "configDataType": {
                    "id": 17,
                    "name": "Application",
                    "code": "APPLICATION",
                    "description": "EDC Solutions"
                }
            }
        ],
        "studyStatus": true,
        "studyAdmin": null,
        "therapeuticArea": {
            "id": 294,
            "name": "Gastroenterology",
            "code": "THERAPEUTIC_GASTROENTEROLOGY",
            "description": "therapeutic area is Gastroenterology",
            "configDataType": {
                "id": 32,
                "name": "Therapeutic",
                "code": "THERAPEUTIC",
                "description": "List of Therapeutic areas"
            }
        },
        "indication": {
            "id": 329,
            "name": "Healthy Volunteers",
            "code": "INDICATION_HEALTHY_VOLUNTEERS",
            "description": "indication type is HEALTHY VOLUNTEERS",
            "configDataType": {
                "id": 33,
                "name": "Indication",
                "code": "INDICATION",
                "description": "List of Indications"
            }
        },
        "studyDesign": {
            "id": 339,
            "name": "Incomplete Block",
            "code": "STUDY_DESIGN_INCOMPLETE_BLOCK",
            "description": "study_design type is INCOMPLETE BLOCK",
            "configDataType": {
                "id": 34,
                "name": "Study Design",
                "code": "STUDY_DESIGN",
                "description": "List of Study Designs"
            }
        },
        "regulatory": {
            "id": 326,
            "name": "Pmda",
            "code": "REGULATORY_PMDA",
            "description": "regulatory type is PMDA",
            "configDataType": {
                "id": 35,
                "name": "Regulatory",
                "code": "REGULATORY",
                "description": "List of Regulatorys "
            }
        },
        "investigation": {
            "id": 278,
            "name": "Biological",
            "code": "INVESTIGATION_BIOLOGICAL",
            "description": "investigation type is Biological",
            "configDataType": {
                "id": 36,
                "name": "Investigation",
                "code": "INVESTIGATION",
                "description": "List of Investigation areas"
            }
        },
        "populations": {
            "id": 341,
            "name": "Healthy Volunteers",
            "code": "POPULATION_HEALTHY_VOLUNTEERS",
            "description": "population type is HEALTHY VOLUNTEERS",
            "configDataType": {
                "id": 37,
                "name": "Population",
                "code": "POPULATION",
                "description": "List of Population areas"
            }
        },
        "studyPasscodeDto": {
            "devPasscode": "WFhRWjZVOEpEVA==",
            "uatPasscode": "MFhJRllTQ1JCNw==",
            "prodPasscode": "QkdFVFdJRVhQQw=="
        },
        "visitsCount": 7,
        "subjectSampleSize": 9,
        "orgStudiesCount": 0,
        "regionId": null,
        "studyContacts": [
            {
                "id": 24,
                "organizationId": 1,
                "firstName": "sravanthi",
                "lastName": "naramgari",
                "email": "sravanthi.naramgari@inductivequotient.com",
                "phoneNo": "1111111111",
                "contactDesgn": "",
                "contactType": {
                    "id": 483,
                    "name": "Primary Study Admin",
                    "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                    "description": null,
                    "configDataType": {
                        "id": 13,
                        "name": "Contact Type",
                        "code": "CONTACT_TYPE",
                        "description": "descrides Contact Types"
                    }
                },
                "active": true,
                "userName": "snaramgari",
                "studyId": 14,
                "orgName": "Clinic_123"
            }
        ],
        "edcSolutions": []
    },
    {
        "id": 13,
        "studyName": "CCCCC",
        "organization": {
            "id": 4,
            "orgName": "TEST-QA",
            "addressLine1": "hyd",
            "addressLine2": "",
            "city": {
                "id": 6506,
                "name": "San Pedro",
                "state": {
                    "id": 217,
                    "name": "Jujuy",
                    "country": {
                        "id": 10,
                        "name": "Argentina",
                        "countryCode": "AR",
                        "phoneCode": 54
                    }
                }
            },
            "state": {
                "id": 217,
                "name": "Jujuy",
                "country": {
                    "id": 10,
                    "name": "Argentina",
                    "countryCode": "AR",
                    "phoneCode": 54
                }
            },
            "country": {
                "id": 10,
                "name": "Argentina",
                "countryCode": "AR",
                "phoneCode": 54
            },
            "postalZipCode": "5646444",
            "phone": "7657565676",
            "companyUrl": "poiu.in",
            "passcode": "0KQM5N8PRG",
            "isActive": true,
            "orgContacts": [
                {
                    "id": 19,
                    "organizationId": 4,
                    "firstName": "sravanthi",
                    "lastName": "sravanthi",
                    "email": "sravanthi.naramgari+1@inductivequotient.com",
                    "phoneNo": "2345672345",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 26,
                        "name": "Primary Contact",
                        "code": "CONTACT_TYPE_PRIMARY_CONTACT",
                        "description": "Primary Contact For Organization",
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": null,
                    "studyId": null,
                    "orgName": null
                }
            ],
            "orgDocuments": [],
            "orgShortname": "poui",
            "telephone": "4545454545",
            "orgType": {
                "id": 13,
                "name": "Hospital",
                "code": "ORG_TYPE_HOSPITAL",
                "description": "indicates  organization type is cro",
                "configDataType": {
                    "id": 5,
                    "name": "Organization Type",
                    "code": "ORG_TYPE",
                    "description": "describes type of organization"
                }
            },
            "orgStudyStatus": false
        },
        "ctPhase": {
            "id": 23,
            "name": "Phase 2",
            "code": "STUDY_PHASE_PHASE2",
            "description": "indicates the study phase is phase 2",
            "configDataType": {
                "id": 11,
                "name": "Study Phase",
                "code": "STUDY_PHASE",
                "description": "describes the study phase"
            }
        },
        "approvalStatus": {
            "id": 6,
            "name": "Approved",
            "code": "WF_STATUS_TYPE_APPROVED",
            "description": "indicates the work flow  status approved",
            "configDataType": {
                "id": 2,
                "name": "Workflow Status",
                "code": "WF_STATUS_TYPE",
                "description": "describe workflow status of the user"
            }
        },
        "startDate": "2023-09-16",
        "endDate": "2023-09-20",
        "studySchema": "",
        "primaryContact": {
            "id": 23,
            "organizationId": 1,
            "firstName": "sravanthi",
            "lastName": "naramgari",
            "email": "sravanthi.naramgari@inductivequotient.com",
            "phoneNo": "1111111111",
            "contactDesgn": "",
            "contactType": {
                "id": 483,
                "name": "Primary Study Admin",
                "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                "description": null,
                "configDataType": {
                    "id": 13,
                    "name": "Contact Type",
                    "code": "CONTACT_TYPE",
                    "description": "descrides Contact Types"
                }
            },
            "active": true,
            "userName": "snaramgari",
            "studyId": 13,
            "orgName": "Clinic_123"
        },
        "secondaryContact": null,
        "request": {
            "id": 13,
            "reqObjectId": {
                "id": 18,
                "name": "Study Request Form",
                "code": "OBJECT_TYPE_STUDY_REQUEST_FORM",
                "description": "indicates the object is refering to study",
                "configDataType": {
                    "id": 9,
                    "name": "Object Type",
                    "code": "OBJECT_TYPE",
                    "description": "describes the type of the object for transaction"
                }
            },
            "reqWfStatusId": {
                "id": 6,
                "name": "Approved",
                "code": "WF_STATUS_TYPE_APPROVED",
                "description": "indicates the work flow  status approved",
                "configDataType": {
                    "id": 2,
                    "name": "Workflow Status",
                    "code": "WF_STATUS_TYPE",
                    "description": "describe workflow status of the user"
                }
            },
            "completedOn": "2023-09-15T11:58:10Z",
            "completedBy": 6
        },
        "approver": null,
        "studyRequestor": {
            "id": 5,
            "name": "snaramgari"
        },
        "studyType": {
            "id": 21,
            "name": "Academic Research",
            "code": "STUDY_TYPE_ACADEMIC_RESEARCH",
            "description": "indicates the study type is academic research",
            "configDataType": {
                "id": 10,
                "name": "Study Type",
                "code": "STUDY_TYPE",
                "description": "describes the study type as BABE / CT / Research etc"
            }
        },
        "protocolId": "CCCCC",
        "comments": "",
        "studyDocuments": [
            {
                "id": 13,
                "fileName": "JD for references template (1).msg",
                "fileContentType": "application/vnd.ms-outlook",
                "study": "CCCCC",
                "documentType": {
                    "id": 29,
                    "name": "Email",
                    "code": "DOC_TYPE_EMAIL",
                    "description": "Email Document Type",
                    "configDataType": {
                        "id": 14,
                        "name": "Document Type",
                        "code": "DOC_TYPE",
                        "description": "Document Type"
                    }
                }
            }
        ],
        "solutions": [
            {
                "id": 41,
                "name": "Inductive EDC",
                "code": "INDUCTIVE_EDC_APPLICATION",
                "description": "EDC Application",
                "configDataType": {
                    "id": 17,
                    "name": "Application",
                    "code": "APPLICATION",
                    "description": "EDC Solutions"
                }
            },
            {
                "id": 42,
                "name": "Clinical Data Quality",
                "code": "CLINICAL_DATA_QUALITY_APPLICATION",
                "description": "IWRS Application",
                "configDataType": {
                    "id": 17,
                    "name": "Application",
                    "code": "APPLICATION",
                    "description": "EDC Solutions"
                }
            }
        ],
        "studyStatus": true,
        "studyAdmin": null,
        "therapeuticArea": {
            "id": 292,
            "name": "Endocrinology",
            "code": "THERAPEUTIC_ENDOCRINOLOGY",
            "description": "therapeutic area is Endocrinology",
            "configDataType": {
                "id": 32,
                "name": "Therapeutic",
                "code": "THERAPEUTIC",
                "description": "List of Therapeutic areas"
            }
        },
        "indication": {
            "id": 333,
            "name": "Rest Of The World",
            "code": "INDICATION_REST_OF_THE_WORLD",
            "description": "indication type is REST OF THE WORLD",
            "configDataType": {
                "id": 33,
                "name": "Indication",
                "code": "INDICATION",
                "description": "List of Indications"
            }
        },
        "studyDesign": {
            "id": 337,
            "name": "Parallel Group",
            "code": "STUDY_DESIGN_PARALLEL_GROUP",
            "description": "study_design type is PARALLEL GROUP",
            "configDataType": {
                "id": 34,
                "name": "Study Design",
                "code": "STUDY_DESIGN",
                "description": "List of Study Designs"
            }
        },
        "regulatory": {
            "id": 326,
            "name": "Pmda",
            "code": "REGULATORY_PMDA",
            "description": "regulatory type is PMDA",
            "configDataType": {
                "id": 35,
                "name": "Regulatory",
                "code": "REGULATORY",
                "description": "List of Regulatorys "
            }
        },
        "investigation": {
            "id": 281,
            "name": "Diagnostic_Test",
            "code": "INVESTIGATION_DIAGNOSTIC_TEST",
            "description": "investigation type is Diagnostic Test",
            "configDataType": {
                "id": 36,
                "name": "Investigation",
                "code": "INVESTIGATION",
                "description": "List of Investigation areas"
            }
        },
        "populations": {
            "id": 341,
            "name": "Healthy Volunteers",
            "code": "POPULATION_HEALTHY_VOLUNTEERS",
            "description": "population type is HEALTHY VOLUNTEERS",
            "configDataType": {
                "id": 37,
                "name": "Population",
                "code": "POPULATION",
                "description": "List of Population areas"
            }
        },
        "studyPasscodeDto": {
            "devPasscode": "Q0s2TVNUUVZCWQ==",
            "uatPasscode": "U1REREZZVkJORg==",
            "prodPasscode": "RlZUN1JYNjA4Nw=="
        },
        "visitsCount": 34,
        "subjectSampleSize": 67,
        "orgStudiesCount": 0,
        "regionId": null,
        "studyContacts": [
            {
                "id": 23,
                "organizationId": 1,
                "firstName": "sravanthi",
                "lastName": "naramgari",
                "email": "sravanthi.naramgari@inductivequotient.com",
                "phoneNo": "1111111111",
                "contactDesgn": "",
                "contactType": {
                    "id": 483,
                    "name": "Primary Study Admin",
                    "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                    "description": null,
                    "configDataType": {
                        "id": 13,
                        "name": "Contact Type",
                        "code": "CONTACT_TYPE",
                        "description": "descrides Contact Types"
                    }
                },
                "active": true,
                "userName": "snaramgari",
                "studyId": 13,
                "orgName": "Clinic_123"
            }
        ],
        "edcSolutions": []
    },
    {
        "id": 11,
        "studyName": "APOLO",
        "organization": {
            "id": 2,
            "orgName": "TestOrg_rwvy",
            "addressLine1": "Durgam cheruvu",
            "addressLine2": "Krishna Sapphire",
            "city": {
                "id": 6833,
                "name": "Eisenstadt",
                "state": {
                    "id": 280,
                    "name": "Burgenland",
                    "country": {
                        "id": 14,
                        "name": "Austria",
                        "countryCode": "AT",
                        "phoneCode": 43
                    }
                }
            },
            "state": {
                "id": 280,
                "name": "Burgenland",
                "country": {
                    "id": 14,
                    "name": "Austria",
                    "countryCode": "AT",
                    "phoneCode": 43
                }
            },
            "country": {
                "id": 14,
                "name": "Austria",
                "countryCode": "AT",
                "phoneCode": 43
            },
            "postalZipCode": "74124",
            "phone": "2949141864",
            "companyUrl": "iqatrapz.com",
            "passcode": "5NYM1Y7G1N",
            "isActive": true,
            "orgContacts": [
                {
                    "id": 84,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 23,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 83,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 22,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 204,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 33,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 160,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 27,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 157,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 25,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 75,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 20,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 210,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 34,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 162,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 28,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 164,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 30,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 78,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 21,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 159,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 26,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 163,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 29,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 61,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 17,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 74,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 19,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 165,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 31,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 203,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 32,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 7,
                    "organizationId": 2,
                    "firstName": "Swathi",
                    "lastName": "Meesaragandam",
                    "email": "swathi.meesaragandam2949@inductivequotient.com",
                    "phoneNo": "2949463721",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 44,
                        "name": "Others Contact",
                        "code": "CONTACT_TYPE_OTHERS_CONTACT",
                        "description": "Others Contact For Organization",
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": null,
                    "studyId": null,
                    "orgName": null
                },
                {
                    "id": 4,
                    "organizationId": 2,
                    "firstName": "Monika",
                    "lastName": "Dronadula",
                    "email": "monika.dronadula2949@inductivequotient.com",
                    "phoneNo": "2949141864",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 26,
                        "name": "Primary Contact",
                        "code": "CONTACT_TYPE_PRIMARY_CONTACT",
                        "description": "Primary Contact For Organization",
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": null,
                    "studyId": null,
                    "orgName": null
                }
            ],
            "orgDocuments": [],
            "orgShortname": "OrgSturhba",
            "telephone": "2949463721",
            "orgType": {
                "id": 11,
                "name": "CRO",
                "code": "ORG_TYPE_CRO",
                "description": "indicates  organization type is cro",
                "configDataType": {
                    "id": 5,
                    "name": "Organization Type",
                    "code": "ORG_TYPE",
                    "description": "describes type of organization"
                }
            },
            "orgStudyStatus": false
        },
        "ctPhase": {
            "id": 22,
            "name": "Phase 1",
            "code": "STUDY_PHASE_PHASE1",
            "description": "indicates the study phase is phase 1",
            "configDataType": {
                "id": 11,
                "name": "Study Phase",
                "code": "STUDY_PHASE",
                "description": "describes the study phase"
            }
        },
        "approvalStatus": {
            "id": 6,
            "name": "Approved",
            "code": "WF_STATUS_TYPE_APPROVED",
            "description": "indicates the work flow  status approved",
            "configDataType": {
                "id": 2,
                "name": "Workflow Status",
                "code": "WF_STATUS_TYPE",
                "description": "describe workflow status of the user"
            }
        },
        "startDate": "2023-09-16",
        "endDate": "2023-09-21",
        "studySchema": "",
        "primaryContact": {
            "id": 21,
            "organizationId": 1,
            "firstName": "sravanthi",
            "lastName": "naramgari",
            "email": "sravanthi.naramgari@inductivequotient.com",
            "phoneNo": "1111111111",
            "contactDesgn": "",
            "contactType": {
                "id": 483,
                "name": "Primary Study Admin",
                "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                "description": null,
                "configDataType": {
                    "id": 13,
                    "name": "Contact Type",
                    "code": "CONTACT_TYPE",
                    "description": "descrides Contact Types"
                }
            },
            "active": true,
            "userName": "snaramgari",
            "studyId": 11,
            "orgName": "Clinic_123"
        },
        "secondaryContact": null,
        "request": {
            "id": 11,
            "reqObjectId": {
                "id": 18,
                "name": "Study Request Form",
                "code": "OBJECT_TYPE_STUDY_REQUEST_FORM",
                "description": "indicates the object is refering to study",
                "configDataType": {
                    "id": 9,
                    "name": "Object Type",
                    "code": "OBJECT_TYPE",
                    "description": "describes the type of the object for transaction"
                }
            },
            "reqWfStatusId": {
                "id": 6,
                "name": "Approved",
                "code": "WF_STATUS_TYPE_APPROVED",
                "description": "indicates the work flow  status approved",
                "configDataType": {
                    "id": 2,
                    "name": "Workflow Status",
                    "code": "WF_STATUS_TYPE",
                    "description": "describe workflow status of the user"
                }
            },
            "completedOn": "2023-09-15T11:47:43Z",
            "completedBy": 6
        },
        "approver": null,
        "studyRequestor": {
            "id": 5,
            "name": "snaramgari"
        },
        "studyType": {
            "id": 19,
            "name": "BABE Study",
            "code": "STUDY_TYPE_BABE",
            "description": "indicates the study type is BABE",
            "configDataType": {
                "id": 10,
                "name": "Study Type",
                "code": "STUDY_TYPE",
                "description": "describes the study type as BABE / CT / Research etc"
            }
        },
        "protocolId": "APOLO",
        "comments": "",
        "studyDocuments": [
            {
                "id": 11,
                "fileName": "JD for references template (1).msg",
                "fileContentType": "application/vnd.ms-outlook",
                "study": "APOLO",
                "documentType": {
                    "id": 29,
                    "name": "Email",
                    "code": "DOC_TYPE_EMAIL",
                    "description": "Email Document Type",
                    "configDataType": {
                        "id": 14,
                        "name": "Document Type",
                        "code": "DOC_TYPE",
                        "description": "Document Type"
                    }
                }
            }
        ],
        "solutions": [
            {
                "id": 41,
                "name": "Inductive EDC",
                "code": "INDUCTIVE_EDC_APPLICATION",
                "description": "EDC Application",
                "configDataType": {
                    "id": 17,
                    "name": "Application",
                    "code": "APPLICATION",
                    "description": "EDC Solutions"
                }
            },
            {
                "id": 42,
                "name": "Clinical Data Quality",
                "code": "CLINICAL_DATA_QUALITY_APPLICATION",
                "description": "IWRS Application",
                "configDataType": {
                    "id": 17,
                    "name": "Application",
                    "code": "APPLICATION",
                    "description": "EDC Solutions"
                }
            }
        ],
        "studyStatus": true,
        "studyAdmin": null,
        "therapeuticArea": {
            "id": 294,
            "name": "Gastroenterology",
            "code": "THERAPEUTIC_GASTROENTEROLOGY",
            "description": "therapeutic area is Gastroenterology",
            "configDataType": {
                "id": 32,
                "name": "Therapeutic",
                "code": "THERAPEUTIC",
                "description": "List of Therapeutic areas"
            }
        },
        "indication": {
            "id": 333,
            "name": "Rest Of The World",
            "code": "INDICATION_REST_OF_THE_WORLD",
            "description": "indication type is REST OF THE WORLD",
            "configDataType": {
                "id": 33,
                "name": "Indication",
                "code": "INDICATION",
                "description": "List of Indications"
            }
        },
        "studyDesign": {
            "id": 335,
            "name": "Alter Nating Panel",
            "code": "STUDY_DESIGN_ALTER_NATING_PANEL",
            "description": "study_design type is ALTER NATING PANEL",
            "configDataType": {
                "id": 34,
                "name": "Study Design",
                "code": "STUDY_DESIGN",
                "description": "List of Study Designs"
            }
        },
        "regulatory": {
            "id": 327,
            "name": "Nmpa",
            "code": "REGULATORY_NMPA",
            "description": "regulatory type is NMPA",
            "configDataType": {
                "id": 35,
                "name": "Regulatory",
                "code": "REGULATORY",
                "description": "List of Regulatorys "
            }
        },
        "investigation": {
            "id": 279,
            "name": "Combination_Product",
            "code": "INVESTIGATION_COMBINATION_PRODUCT",
            "description": "investigation type is Combination Product",
            "configDataType": {
                "id": 36,
                "name": "Investigation",
                "code": "INVESTIGATION",
                "description": "List of Investigation areas"
            }
        },
        "populations": {
            "id": 343,
            "name": "Other Patients",
            "code": "POPULATION_OTHER_PATIENTS",
            "description": "population type is OTHER PATIENTS",
            "configDataType": {
                "id": 37,
                "name": "Population",
                "code": "POPULATION",
                "description": "List of Population areas"
            }
        },
        "studyPasscodeDto": {
            "devPasscode": "TjhMNE01VVRUSw==",
            "uatPasscode": "TUNYSUJQQlRWVw==",
            "prodPasscode": "RzVKSlVWRjNYRQ=="
        },
        "visitsCount": 3,
        "subjectSampleSize": 5,
        "orgStudiesCount": 0,
        "regionId": null,
        "studyContacts": [
            {
                "id": 21,
                "organizationId": 1,
                "firstName": "sravanthi",
                "lastName": "naramgari",
                "email": "sravanthi.naramgari@inductivequotient.com",
                "phoneNo": "1111111111",
                "contactDesgn": "",
                "contactType": {
                    "id": 483,
                    "name": "Primary Study Admin",
                    "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                    "description": null,
                    "configDataType": {
                        "id": 13,
                        "name": "Contact Type",
                        "code": "CONTACT_TYPE",
                        "description": "descrides Contact Types"
                    }
                },
                "active": true,
                "userName": "snaramgari",
                "studyId": 11,
                "orgName": "Clinic_123"
            }
        ],
        "edcSolutions": []
    },
    {
        "id": 10,
        "studyName": "UAI",
        "organization": {
            "id": 2,
            "orgName": "TestOrg_rwvy",
            "addressLine1": "Durgam cheruvu",
            "addressLine2": "Krishna Sapphire",
            "city": {
                "id": 6833,
                "name": "Eisenstadt",
                "state": {
                    "id": 280,
                    "name": "Burgenland",
                    "country": {
                        "id": 14,
                        "name": "Austria",
                        "countryCode": "AT",
                        "phoneCode": 43
                    }
                }
            },
            "state": {
                "id": 280,
                "name": "Burgenland",
                "country": {
                    "id": 14,
                    "name": "Austria",
                    "countryCode": "AT",
                    "phoneCode": 43
                }
            },
            "country": {
                "id": 14,
                "name": "Austria",
                "countryCode": "AT",
                "phoneCode": 43
            },
            "postalZipCode": "74124",
            "phone": "2949141864",
            "companyUrl": "iqatrapz.com",
            "passcode": "5NYM1Y7G1N",
            "isActive": true,
            "orgContacts": [
                {
                    "id": 84,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 23,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 83,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 22,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 204,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 33,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 160,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 27,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 157,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 25,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 75,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 20,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 210,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 34,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 162,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 28,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 164,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 30,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 78,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 21,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 159,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 26,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 163,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 29,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 61,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 17,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 74,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 19,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 165,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 31,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 203,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 32,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 7,
                    "organizationId": 2,
                    "firstName": "Swathi",
                    "lastName": "Meesaragandam",
                    "email": "swathi.meesaragandam2949@inductivequotient.com",
                    "phoneNo": "2949463721",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 44,
                        "name": "Others Contact",
                        "code": "CONTACT_TYPE_OTHERS_CONTACT",
                        "description": "Others Contact For Organization",
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": null,
                    "studyId": null,
                    "orgName": null
                },
                {
                    "id": 4,
                    "organizationId": 2,
                    "firstName": "Monika",
                    "lastName": "Dronadula",
                    "email": "monika.dronadula2949@inductivequotient.com",
                    "phoneNo": "2949141864",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 26,
                        "name": "Primary Contact",
                        "code": "CONTACT_TYPE_PRIMARY_CONTACT",
                        "description": "Primary Contact For Organization",
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": null,
                    "studyId": null,
                    "orgName": null
                }
            ],
            "orgDocuments": [],
            "orgShortname": "OrgSturhba",
            "telephone": "2949463721",
            "orgType": {
                "id": 11,
                "name": "CRO",
                "code": "ORG_TYPE_CRO",
                "description": "indicates  organization type is cro",
                "configDataType": {
                    "id": 5,
                    "name": "Organization Type",
                    "code": "ORG_TYPE",
                    "description": "describes type of organization"
                }
            },
            "orgStudyStatus": false
        },
        "ctPhase": {
            "id": 22,
            "name": "Phase 1",
            "code": "STUDY_PHASE_PHASE1",
            "description": "indicates the study phase is phase 1",
            "configDataType": {
                "id": 11,
                "name": "Study Phase",
                "code": "STUDY_PHASE",
                "description": "describes the study phase"
            }
        },
        "approvalStatus": {
            "id": 6,
            "name": "Approved",
            "code": "WF_STATUS_TYPE_APPROVED",
            "description": "indicates the work flow  status approved",
            "configDataType": {
                "id": 2,
                "name": "Workflow Status",
                "code": "WF_STATUS_TYPE",
                "description": "describe workflow status of the user"
            }
        },
        "startDate": "2023-09-16",
        "endDate": "2023-09-22",
        "studySchema": "",
        "primaryContact": {
            "id": 20,
            "organizationId": 1,
            "firstName": "sravanthi",
            "lastName": "naramgari",
            "email": "sravanthi.naramgari@inductivequotient.com",
            "phoneNo": "1111111111",
            "contactDesgn": "",
            "contactType": {
                "id": 483,
                "name": "Primary Study Admin",
                "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                "description": null,
                "configDataType": {
                    "id": 13,
                    "name": "Contact Type",
                    "code": "CONTACT_TYPE",
                    "description": "descrides Contact Types"
                }
            },
            "active": true,
            "userName": "snaramgari",
            "studyId": 10,
            "orgName": "Clinic_123"
        },
        "secondaryContact": null,
        "request": {
            "id": 10,
            "reqObjectId": {
                "id": 18,
                "name": "Study Request Form",
                "code": "OBJECT_TYPE_STUDY_REQUEST_FORM",
                "description": "indicates the object is refering to study",
                "configDataType": {
                    "id": 9,
                    "name": "Object Type",
                    "code": "OBJECT_TYPE",
                    "description": "describes the type of the object for transaction"
                }
            },
            "reqWfStatusId": {
                "id": 6,
                "name": "Approved",
                "code": "WF_STATUS_TYPE_APPROVED",
                "description": "indicates the work flow  status approved",
                "configDataType": {
                    "id": 2,
                    "name": "Workflow Status",
                    "code": "WF_STATUS_TYPE",
                    "description": "describe workflow status of the user"
                }
            },
            "completedOn": "2023-09-15T11:55:57Z",
            "completedBy": 5
        },
        "approver": null,
        "studyRequestor": {
            "id": 5,
            "name": "snaramgari"
        },
        "studyType": {
            "id": 20,
            "name": "Clinical Trial",
            "code": "STUDY_TYPE_CLINICAL_TRIAL",
            "description": "indicates the study type is clinical trial",
            "configDataType": {
                "id": 10,
                "name": "Study Type",
                "code": "STUDY_TYPE",
                "description": "describes the study type as BABE / CT / Research etc"
            }
        },
        "protocolId": "UAI",
        "comments": "",
        "studyDocuments": [
            {
                "id": 10,
                "fileName": "JD for references template (3).msg",
                "fileContentType": "application/vnd.ms-outlook",
                "study": "UAI",
                "documentType": {
                    "id": 29,
                    "name": "Email",
                    "code": "DOC_TYPE_EMAIL",
                    "description": "Email Document Type",
                    "configDataType": {
                        "id": 14,
                        "name": "Document Type",
                        "code": "DOC_TYPE",
                        "description": "Document Type"
                    }
                }
            }
        ],
        "solutions": [
            {
                "id": 41,
                "name": "Inductive EDC",
                "code": "INDUCTIVE_EDC_APPLICATION",
                "description": "EDC Application",
                "configDataType": {
                    "id": 17,
                    "name": "Application",
                    "code": "APPLICATION",
                    "description": "EDC Solutions"
                }
            },
            {
                "id": 42,
                "name": "Clinical Data Quality",
                "code": "CLINICAL_DATA_QUALITY_APPLICATION",
                "description": "IWRS Application",
                "configDataType": {
                    "id": 17,
                    "name": "Application",
                    "code": "APPLICATION",
                    "description": "EDC Solutions"
                }
            }
        ],
        "studyStatus": true,
        "studyAdmin": null,
        "therapeuticArea": {
            "id": 289,
            "name": "Dental_and_Oral_Health",
            "code": "THERAPEUTIC_DENTAL_AND_ORAL_HEALTH",
            "description": "therapeutic area is Dental and Oral Health",
            "configDataType": {
                "id": 32,
                "name": "Therapeutic",
                "code": "THERAPEUTIC",
                "description": "List of Therapeutic areas"
            }
        },
        "indication": {
            "id": 332,
            "name": "Special Population",
            "code": "INDICATION_SPECIAL_POPULATION",
            "description": "indication type is SPECIAL POPULATION",
            "configDataType": {
                "id": 33,
                "name": "Indication",
                "code": "INDICATION",
                "description": "List of Indications"
            }
        },
        "studyDesign": {
            "id": 335,
            "name": "Alter Nating Panel",
            "code": "STUDY_DESIGN_ALTER_NATING_PANEL",
            "description": "study_design type is ALTER NATING PANEL",
            "configDataType": {
                "id": 34,
                "name": "Study Design",
                "code": "STUDY_DESIGN",
                "description": "List of Study Designs"
            }
        },
        "regulatory": {
            "id": 326,
            "name": "Pmda",
            "code": "REGULATORY_PMDA",
            "description": "regulatory type is PMDA",
            "configDataType": {
                "id": 35,
                "name": "Regulatory",
                "code": "REGULATORY",
                "description": "List of Regulatorys "
            }
        },
        "investigation": {
            "id": 279,
            "name": "Combination_Product",
            "code": "INVESTIGATION_COMBINATION_PRODUCT",
            "description": "investigation type is Combination Product",
            "configDataType": {
                "id": 36,
                "name": "Investigation",
                "code": "INVESTIGATION",
                "description": "List of Investigation areas"
            }
        },
        "populations": {
            "id": 341,
            "name": "Healthy Volunteers",
            "code": "POPULATION_HEALTHY_VOLUNTEERS",
            "description": "population type is HEALTHY VOLUNTEERS",
            "configDataType": {
                "id": 37,
                "name": "Population",
                "code": "POPULATION",
                "description": "List of Population areas"
            }
        },
        "studyPasscodeDto": {
            "devPasscode": "T1dKRjZXUzJTSw==",
            "uatPasscode": "UUlHU0JaSlpHNA==",
            "prodPasscode": "VEJFSlJFTzdWUg=="
        },
        "visitsCount": 67,
        "subjectSampleSize": 66,
        "orgStudiesCount": 0,
        "regionId": null,
        "studyContacts": [
            {
                "id": 20,
                "organizationId": 1,
                "firstName": "sravanthi",
                "lastName": "naramgari",
                "email": "sravanthi.naramgari@inductivequotient.com",
                "phoneNo": "1111111111",
                "contactDesgn": "",
                "contactType": {
                    "id": 483,
                    "name": "Primary Study Admin",
                    "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                    "description": null,
                    "configDataType": {
                        "id": 13,
                        "name": "Contact Type",
                        "code": "CONTACT_TYPE",
                        "description": "descrides Contact Types"
                    }
                },
                "active": true,
                "userName": "snaramgari",
                "studyId": 10,
                "orgName": "Clinic_123"
            }
        ],
        "edcSolutions": []
    },
    {
        "id": 9,
        "studyName": "IS-1234",
        "organization": {
            "id": 1,
            "orgName": "Clinic_123",
            "addressLine1": "hyd",
            "addressLine2": "",
            "city": {
                "id": 705,
                "name": "Diu",
                "state": {
                    "id": 9,
                    "name": "Daman and Diu",
                    "country": {
                        "id": 101,
                        "name": "India",
                        "countryCode": "IN",
                        "phoneCode": 0
                    }
                }
            },
            "state": {
                "id": 9,
                "name": "Daman and Diu",
                "country": {
                    "id": 101,
                    "name": "India",
                    "countryCode": "IN",
                    "phoneCode": 0
                }
            },
            "country": {
                "id": 101,
                "name": "India",
                "countryCode": "IN",
                "phoneCode": 0
            },
            "postalZipCode": "343434",
            "phone": "5656565656",
            "companyUrl": "jiop.in",
            "passcode": "SPFIYPTQPW",
            "isActive": true,
            "orgContacts": [
                {
                    "id": 155,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 24,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 3,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 2,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 20,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 10,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 8,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 3,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 29,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 15,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 10,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 5,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 30,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 16,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 2,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 1,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 64,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 18,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 18,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 9,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 22,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 12,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 23,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 13,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 17,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 8,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 24,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 14,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 21,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 11,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 11,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 6,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 62,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 484,
                        "name": "Secondry Study Admin",
                        "code": "CONTACT_TYPE_SECONDRY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 17,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 9,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 4,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 12,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 7,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 1,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "sravanthi",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "3434343434",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 26,
                        "name": "Primary Contact",
                        "code": "CONTACT_TYPE_PRIMARY_CONTACT",
                        "description": "Primary Contact For Organization",
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": null,
                    "studyId": null,
                    "orgName": null
                }
            ],
            "orgDocuments": [],
            "orgShortname": "jio",
            "telephone": "3434343434",
            "orgType": {
                "id": 12,
                "name": "Govt Org",
                "code": "ORG_TYPE_GOVT_ORG",
                "description": "indicates  organization type is government organization",
                "configDataType": {
                    "id": 5,
                    "name": "Organization Type",
                    "code": "ORG_TYPE",
                    "description": "describes type of organization"
                }
            },
            "orgStudyStatus": false
        },
        "ctPhase": {
            "id": 25,
            "name": "Phase 4",
            "code": "STUDY_PHASE_PHASE4",
            "description": "indicates the study phase is phase 4",
            "configDataType": {
                "id": 11,
                "name": "Study Phase",
                "code": "STUDY_PHASE",
                "description": "describes the study phase"
            }
        },
        "approvalStatus": {
            "id": 6,
            "name": "Approved",
            "code": "WF_STATUS_TYPE_APPROVED",
            "description": "indicates the work flow  status approved",
            "configDataType": {
                "id": 2,
                "name": "Workflow Status",
                "code": "WF_STATUS_TYPE",
                "description": "describe workflow status of the user"
            }
        },
        "startDate": "2023-09-16",
        "endDate": "2023-09-30",
        "studySchema": "",
        "primaryContact": {
            "id": 18,
            "organizationId": 1,
            "firstName": "sravanthi",
            "lastName": "naramgari",
            "email": "sravanthi.naramgari@inductivequotient.com",
            "phoneNo": "1111111111",
            "contactDesgn": "",
            "contactType": {
                "id": 483,
                "name": "Primary Study Admin",
                "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                "description": null,
                "configDataType": {
                    "id": 13,
                    "name": "Contact Type",
                    "code": "CONTACT_TYPE",
                    "description": "descrides Contact Types"
                }
            },
            "active": true,
            "userName": "snaramgari",
            "studyId": 9,
            "orgName": "Clinic_123"
        },
        "secondaryContact": null,
        "request": {
            "id": 9,
            "reqObjectId": {
                "id": 18,
                "name": "Study Request Form",
                "code": "OBJECT_TYPE_STUDY_REQUEST_FORM",
                "description": "indicates the object is refering to study",
                "configDataType": {
                    "id": 9,
                    "name": "Object Type",
                    "code": "OBJECT_TYPE",
                    "description": "describes the type of the object for transaction"
                }
            },
            "reqWfStatusId": {
                "id": 6,
                "name": "Approved",
                "code": "WF_STATUS_TYPE_APPROVED",
                "description": "indicates the work flow  status approved",
                "configDataType": {
                    "id": 2,
                    "name": "Workflow Status",
                    "code": "WF_STATUS_TYPE",
                    "description": "describe workflow status of the user"
                }
            },
            "completedOn": "2023-09-15T11:56:14Z",
            "completedBy": 5
        },
        "approver": null,
        "studyRequestor": {
            "id": 5,
            "name": "snaramgari"
        },
        "studyType": {
            "id": 19,
            "name": "BABE Study",
            "code": "STUDY_TYPE_BABE",
            "description": "indicates the study type is BABE",
            "configDataType": {
                "id": 10,
                "name": "Study Type",
                "code": "STUDY_TYPE",
                "description": "describes the study type as BABE / CT / Research etc"
            }
        },
        "protocolId": "IS-1234",
        "comments": "",
        "studyDocuments": [
            {
                "id": 9,
                "fileName": "Organisation Details (1) (2).PDF",
                "fileContentType": "application/pdf",
                "study": "IS-1234",
                "documentType": {
                    "id": 29,
                    "name": "Email",
                    "code": "DOC_TYPE_EMAIL",
                    "description": "Email Document Type",
                    "configDataType": {
                        "id": 14,
                        "name": "Document Type",
                        "code": "DOC_TYPE",
                        "description": "Document Type"
                    }
                }
            }
        ],
        "solutions": [
            {
                "id": 41,
                "name": "Inductive EDC",
                "code": "INDUCTIVE_EDC_APPLICATION",
                "description": "EDC Application",
                "configDataType": {
                    "id": 17,
                    "name": "Application",
                    "code": "APPLICATION",
                    "description": "EDC Solutions"
                }
            },
            {
                "id": 42,
                "name": "Clinical Data Quality",
                "code": "CLINICAL_DATA_QUALITY_APPLICATION",
                "description": "IWRS Application",
                "configDataType": {
                    "id": 17,
                    "name": "Application",
                    "code": "APPLICATION",
                    "description": "EDC Solutions"
                }
            },
            {
                "id": 43,
                "name": "Clinical Data Transformation",
                "code": "CLINICAL_DATA_TRANSFORMATION_APPLICATION",
                "description": "Screening Application",
                "configDataType": {
                    "id": 17,
                    "name": "Application",
                    "code": "APPLICATION",
                    "description": "EDC Solutions"
                }
            }
        ],
        "studyStatus": true,
        "studyAdmin": null,
        "therapeuticArea": {
            "id": 291,
            "name": "Devices",
            "code": "THERAPEUTIC_DEVICES",
            "description": "therapeutic area is Devices",
            "configDataType": {
                "id": 32,
                "name": "Therapeutic",
                "code": "THERAPEUTIC",
                "description": "List of Therapeutic areas"
            }
        },
        "indication": {
            "id": 330,
            "name": "Oncology Patients",
            "code": "INDICATION_ONCOLOGY_PATIENTS",
            "description": "indication type is ONCOLOGY PATIENTS",
            "configDataType": {
                "id": 33,
                "name": "Indication",
                "code": "INDICATION",
                "description": "List of Indications"
            }
        },
        "studyDesign": {
            "id": 337,
            "name": "Parallel Group",
            "code": "STUDY_DESIGN_PARALLEL_GROUP",
            "description": "study_design type is PARALLEL GROUP",
            "configDataType": {
                "id": 34,
                "name": "Study Design",
                "code": "STUDY_DESIGN",
                "description": "List of Study Designs"
            }
        },
        "regulatory": {
            "id": 326,
            "name": "Pmda",
            "code": "REGULATORY_PMDA",
            "description": "regulatory type is PMDA",
            "configDataType": {
                "id": 35,
                "name": "Regulatory",
                "code": "REGULATORY",
                "description": "List of Regulatorys "
            }
        },
        "investigation": {
            "id": 286,
            "name": "Procedure",
            "code": "INVESTIGATION_PROCEDURE",
            "description": "investigation type is Procedure",
            "configDataType": {
                "id": 36,
                "name": "Investigation",
                "code": "INVESTIGATION",
                "description": "List of Investigation areas"
            }
        },
        "populations": {
            "id": 343,
            "name": "Other Patients",
            "code": "POPULATION_OTHER_PATIENTS",
            "description": "population type is OTHER PATIENTS",
            "configDataType": {
                "id": 37,
                "name": "Population",
                "code": "POPULATION",
                "description": "List of Population areas"
            }
        },
        "studyPasscodeDto": {
            "devPasscode": "VURaV1k1MzRQWA==",
            "uatPasscode": "Vk1KOExLQkhVUA==",
            "prodPasscode": "UjNKUVRPRjFIVA=="
        },
        "visitsCount": 3,
        "subjectSampleSize": 2,
        "orgStudiesCount": 0,
        "regionId": null,
        "studyContacts": [
            {
                "id": 18,
                "organizationId": 1,
                "firstName": "sravanthi",
                "lastName": "naramgari",
                "email": "sravanthi.naramgari@inductivequotient.com",
                "phoneNo": "1111111111",
                "contactDesgn": "",
                "contactType": {
                    "id": 483,
                    "name": "Primary Study Admin",
                    "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                    "description": null,
                    "configDataType": {
                        "id": 13,
                        "name": "Contact Type",
                        "code": "CONTACT_TYPE",
                        "description": "descrides Contact Types"
                    }
                },
                "active": true,
                "userName": "snaramgari",
                "studyId": 9,
                "orgName": "Clinic_123"
            }
        ],
        "edcSolutions": []
    },
    {
        "id": 7,
        "studyName": "XXX",
        "organization": {
            "id": 1,
            "orgName": "Clinic_123",
            "addressLine1": "hyd",
            "addressLine2": "",
            "city": {
                "id": 705,
                "name": "Diu",
                "state": {
                    "id": 9,
                    "name": "Daman and Diu",
                    "country": {
                        "id": 101,
                        "name": "India",
                        "countryCode": "IN",
                        "phoneCode": 0
                    }
                }
            },
            "state": {
                "id": 9,
                "name": "Daman and Diu",
                "country": {
                    "id": 101,
                    "name": "India",
                    "countryCode": "IN",
                    "phoneCode": 0
                }
            },
            "country": {
                "id": 101,
                "name": "India",
                "countryCode": "IN",
                "phoneCode": 0
            },
            "postalZipCode": "343434",
            "phone": "5656565656",
            "companyUrl": "jiop.in",
            "passcode": "SPFIYPTQPW",
            "isActive": true,
            "orgContacts": [
                {
                    "id": 155,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 24,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 3,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 2,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 20,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 10,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 8,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 3,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 29,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 15,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 10,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 5,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 30,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 16,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 2,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 1,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 64,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 18,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 18,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 9,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 22,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 12,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 23,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 13,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 17,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 8,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 24,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 14,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 21,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 11,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 11,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 6,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 62,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 484,
                        "name": "Secondry Study Admin",
                        "code": "CONTACT_TYPE_SECONDRY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 17,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 9,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 4,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 12,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 7,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 1,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "sravanthi",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "3434343434",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 26,
                        "name": "Primary Contact",
                        "code": "CONTACT_TYPE_PRIMARY_CONTACT",
                        "description": "Primary Contact For Organization",
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": null,
                    "studyId": null,
                    "orgName": null
                }
            ],
            "orgDocuments": [],
            "orgShortname": "jio",
            "telephone": "3434343434",
            "orgType": {
                "id": 12,
                "name": "Govt Org",
                "code": "ORG_TYPE_GOVT_ORG",
                "description": "indicates  organization type is government organization",
                "configDataType": {
                    "id": 5,
                    "name": "Organization Type",
                    "code": "ORG_TYPE",
                    "description": "describes type of organization"
                }
            },
            "orgStudyStatus": false
        },
        "ctPhase": {
            "id": 24,
            "name": "Phase 3",
            "code": "STUDY_PHASE_PHASE3",
            "description": "indicates the study phase is phase 3",
            "configDataType": {
                "id": 11,
                "name": "Study Phase",
                "code": "STUDY_PHASE",
                "description": "describes the study phase"
            }
        },
        "approvalStatus": {
            "id": 6,
            "name": "Approved",
            "code": "WF_STATUS_TYPE_APPROVED",
            "description": "indicates the work flow  status approved",
            "configDataType": {
                "id": 2,
                "name": "Workflow Status",
                "code": "WF_STATUS_TYPE",
                "description": "describe workflow status of the user"
            }
        },
        "startDate": "2023-09-16",
        "endDate": "2023-09-21",
        "studySchema": "",
        "primaryContact": {
            "id": 12,
            "organizationId": 1,
            "firstName": "sra",
            "lastName": "nar",
            "email": "sravanthi.naramgari@inductivequotient.com",
            "phoneNo": "1111111111",
            "contactDesgn": "",
            "contactType": {
                "id": 483,
                "name": "Primary Study Admin",
                "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                "description": null,
                "configDataType": {
                    "id": 13,
                    "name": "Contact Type",
                    "code": "CONTACT_TYPE",
                    "description": "descrides Contact Types"
                }
            },
            "active": true,
            "userName": "snaramgari",
            "studyId": 7,
            "orgName": "Clinic_123"
        },
        "secondaryContact": null,
        "request": {
            "id": 7,
            "reqObjectId": {
                "id": 18,
                "name": "Study Request Form",
                "code": "OBJECT_TYPE_STUDY_REQUEST_FORM",
                "description": "indicates the object is refering to study",
                "configDataType": {
                    "id": 9,
                    "name": "Object Type",
                    "code": "OBJECT_TYPE",
                    "description": "describes the type of the object for transaction"
                }
            },
            "reqWfStatusId": {
                "id": 6,
                "name": "Approved",
                "code": "WF_STATUS_TYPE_APPROVED",
                "description": "indicates the work flow  status approved",
                "configDataType": {
                    "id": 2,
                    "name": "Workflow Status",
                    "code": "WF_STATUS_TYPE",
                    "description": "describe workflow status of the user"
                }
            },
            "completedOn": "2023-09-15T10:23:05Z",
            "completedBy": 6
        },
        "approver": null,
        "studyRequestor": {
            "id": 5,
            "name": "snaramgari"
        },
        "studyType": {
            "id": 21,
            "name": "Academic Research",
            "code": "STUDY_TYPE_ACADEMIC_RESEARCH",
            "description": "indicates the study type is academic research",
            "configDataType": {
                "id": 10,
                "name": "Study Type",
                "code": "STUDY_TYPE",
                "description": "describes the study type as BABE / CT / Research etc"
            }
        },
        "protocolId": "XXX",
        "comments": "",
        "studyDocuments": [
            {
                "id": 7,
                "fileName": "JD for references template (3).msg",
                "fileContentType": "application/vnd.ms-outlook",
                "study": "XXX",
                "documentType": {
                    "id": 29,
                    "name": "Email",
                    "code": "DOC_TYPE_EMAIL",
                    "description": "Email Document Type",
                    "configDataType": {
                        "id": 14,
                        "name": "Document Type",
                        "code": "DOC_TYPE",
                        "description": "Document Type"
                    }
                }
            }
        ],
        "solutions": [
            {
                "id": 41,
                "name": "Inductive EDC",
                "code": "INDUCTIVE_EDC_APPLICATION",
                "description": "EDC Application",
                "configDataType": {
                    "id": 17,
                    "name": "Application",
                    "code": "APPLICATION",
                    "description": "EDC Solutions"
                }
            },
            {
                "id": 42,
                "name": "Clinical Data Quality",
                "code": "CLINICAL_DATA_QUALITY_APPLICATION",
                "description": "IWRS Application",
                "configDataType": {
                    "id": 17,
                    "name": "Application",
                    "code": "APPLICATION",
                    "description": "EDC Solutions"
                }
            }
        ],
        "studyStatus": true,
        "studyAdmin": null,
        "therapeuticArea": {
            "id": 300,
            "name": "Immunology",
            "code": "THERAPEUTIC_IMMUNOLOGY",
            "description": "therapeutic area is Immunology",
            "configDataType": {
                "id": 32,
                "name": "Therapeutic",
                "code": "THERAPEUTIC",
                "description": "List of Therapeutic areas"
            }
        },
        "indication": {
            "id": 329,
            "name": "Healthy Volunteers",
            "code": "INDICATION_HEALTHY_VOLUNTEERS",
            "description": "indication type is HEALTHY VOLUNTEERS",
            "configDataType": {
                "id": 33,
                "name": "Indication",
                "code": "INDICATION",
                "description": "List of Indications"
            }
        },
        "studyDesign": {
            "id": 337,
            "name": "Parallel Group",
            "code": "STUDY_DESIGN_PARALLEL_GROUP",
            "description": "study_design type is PARALLEL GROUP",
            "configDataType": {
                "id": 34,
                "name": "Study Design",
                "code": "STUDY_DESIGN",
                "description": "List of Study Designs"
            }
        },
        "regulatory": {
            "id": 326,
            "name": "Pmda",
            "code": "REGULATORY_PMDA",
            "description": "regulatory type is PMDA",
            "configDataType": {
                "id": 35,
                "name": "Regulatory",
                "code": "REGULATORY",
                "description": "List of Regulatorys "
            }
        },
        "investigation": {
            "id": 280,
            "name": "Device",
            "code": "INVESTIGATION_DEVICE",
            "description": "investigation type is Device",
            "configDataType": {
                "id": 36,
                "name": "Investigation",
                "code": "INVESTIGATION",
                "description": "List of Investigation areas"
            }
        },
        "populations": {
            "id": 342,
            "name": "Oncology Patients",
            "code": "POPULATION_ONCOLOGY_PATIENTS",
            "description": "population type is ONCOLOGY PATIENTS",
            "configDataType": {
                "id": 37,
                "name": "Population",
                "code": "POPULATION",
                "description": "List of Population areas"
            }
        },
        "studyPasscodeDto": {
            "devPasscode": "TDdSMjFQN1I2WA==",
            "uatPasscode": "UVhETkVJWlNSSA==",
            "prodPasscode": "VjZYWjhZTldaNg=="
        },
        "visitsCount": 87,
        "subjectSampleSize": 7,
        "orgStudiesCount": 0,
        "regionId": null,
        "studyContacts": [
            {
                "id": 12,
                "organizationId": 1,
                "firstName": "sra",
                "lastName": "nar",
                "email": "sravanthi.naramgari@inductivequotient.com",
                "phoneNo": "1111111111",
                "contactDesgn": "",
                "contactType": {
                    "id": 483,
                    "name": "Primary Study Admin",
                    "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                    "description": null,
                    "configDataType": {
                        "id": 13,
                        "name": "Contact Type",
                        "code": "CONTACT_TYPE",
                        "description": "descrides Contact Types"
                    }
                },
                "active": true,
                "userName": "snaramgari",
                "studyId": 7,
                "orgName": "Clinic_123"
            }
        ],
        "edcSolutions": []
    },
    {
        "id": 6,
        "studyName": "CASE-1",
        "organization": {
            "id": 1,
            "orgName": "Clinic_123",
            "addressLine1": "hyd",
            "addressLine2": "",
            "city": {
                "id": 705,
                "name": "Diu",
                "state": {
                    "id": 9,
                    "name": "Daman and Diu",
                    "country": {
                        "id": 101,
                        "name": "India",
                        "countryCode": "IN",
                        "phoneCode": 0
                    }
                }
            },
            "state": {
                "id": 9,
                "name": "Daman and Diu",
                "country": {
                    "id": 101,
                    "name": "India",
                    "countryCode": "IN",
                    "phoneCode": 0
                }
            },
            "country": {
                "id": 101,
                "name": "India",
                "countryCode": "IN",
                "phoneCode": 0
            },
            "postalZipCode": "343434",
            "phone": "5656565656",
            "companyUrl": "jiop.in",
            "passcode": "SPFIYPTQPW",
            "isActive": true,
            "orgContacts": [
                {
                    "id": 155,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 24,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 3,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 2,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 20,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 10,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 8,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 3,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 29,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 15,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 10,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 5,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 30,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 16,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 2,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 1,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 64,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 18,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 18,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 9,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 22,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 12,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 23,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 13,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 17,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 8,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 24,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 14,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 21,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 11,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 11,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 6,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 62,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 484,
                        "name": "Secondry Study Admin",
                        "code": "CONTACT_TYPE_SECONDRY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 17,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 9,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 4,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 12,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 7,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 1,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "sravanthi",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "3434343434",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 26,
                        "name": "Primary Contact",
                        "code": "CONTACT_TYPE_PRIMARY_CONTACT",
                        "description": "Primary Contact For Organization",
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": null,
                    "studyId": null,
                    "orgName": null
                }
            ],
            "orgDocuments": [],
            "orgShortname": "jio",
            "telephone": "3434343434",
            "orgType": {
                "id": 12,
                "name": "Govt Org",
                "code": "ORG_TYPE_GOVT_ORG",
                "description": "indicates  organization type is government organization",
                "configDataType": {
                    "id": 5,
                    "name": "Organization Type",
                    "code": "ORG_TYPE",
                    "description": "describes type of organization"
                }
            },
            "orgStudyStatus": false
        },
        "ctPhase": {
            "id": 24,
            "name": "Phase 3",
            "code": "STUDY_PHASE_PHASE3",
            "description": "indicates the study phase is phase 3",
            "configDataType": {
                "id": 11,
                "name": "Study Phase",
                "code": "STUDY_PHASE",
                "description": "describes the study phase"
            }
        },
        "approvalStatus": {
            "id": 6,
            "name": "Approved",
            "code": "WF_STATUS_TYPE_APPROVED",
            "description": "indicates the work flow  status approved",
            "configDataType": {
                "id": 2,
                "name": "Workflow Status",
                "code": "WF_STATUS_TYPE",
                "description": "describe workflow status of the user"
            }
        },
        "startDate": "2023-09-16",
        "endDate": "2023-09-20",
        "studySchema": "",
        "primaryContact": {
            "id": 11,
            "organizationId": 1,
            "firstName": "sra",
            "lastName": "nar",
            "email": "sravanthi.naramgari@inductivequotient.com",
            "phoneNo": "1111111111",
            "contactDesgn": "",
            "contactType": {
                "id": 483,
                "name": "Primary Study Admin",
                "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                "description": null,
                "configDataType": {
                    "id": 13,
                    "name": "Contact Type",
                    "code": "CONTACT_TYPE",
                    "description": "descrides Contact Types"
                }
            },
            "active": true,
            "userName": "snaramgari",
            "studyId": 6,
            "orgName": "Clinic_123"
        },
        "secondaryContact": null,
        "request": {
            "id": 6,
            "reqObjectId": {
                "id": 18,
                "name": "Study Request Form",
                "code": "OBJECT_TYPE_STUDY_REQUEST_FORM",
                "description": "indicates the object is refering to study",
                "configDataType": {
                    "id": 9,
                    "name": "Object Type",
                    "code": "OBJECT_TYPE",
                    "description": "describes the type of the object for transaction"
                }
            },
            "reqWfStatusId": {
                "id": 6,
                "name": "Approved",
                "code": "WF_STATUS_TYPE_APPROVED",
                "description": "indicates the work flow  status approved",
                "configDataType": {
                    "id": 2,
                    "name": "Workflow Status",
                    "code": "WF_STATUS_TYPE",
                    "description": "describe workflow status of the user"
                }
            },
            "completedOn": "2023-09-15T08:09:45Z",
            "completedBy": 6
        },
        "approver": null,
        "studyRequestor": {
            "id": 5,
            "name": "snaramgari"
        },
        "studyType": {
            "id": 19,
            "name": "BABE Study",
            "code": "STUDY_TYPE_BABE",
            "description": "indicates the study type is BABE",
            "configDataType": {
                "id": 10,
                "name": "Study Type",
                "code": "STUDY_TYPE",
                "description": "describes the study type as BABE / CT / Research etc"
            }
        },
        "protocolId": "CASE-1",
        "comments": "",
        "studyDocuments": [
            {
                "id": 6,
                "fileName": "JD for references template (1).msg",
                "fileContentType": "application/vnd.ms-outlook",
                "study": "CASE-1",
                "documentType": {
                    "id": 29,
                    "name": "Email",
                    "code": "DOC_TYPE_EMAIL",
                    "description": "Email Document Type",
                    "configDataType": {
                        "id": 14,
                        "name": "Document Type",
                        "code": "DOC_TYPE",
                        "description": "Document Type"
                    }
                }
            }
        ],
        "solutions": [
            {
                "id": 41,
                "name": "Inductive EDC",
                "code": "INDUCTIVE_EDC_APPLICATION",
                "description": "EDC Application",
                "configDataType": {
                    "id": 17,
                    "name": "Application",
                    "code": "APPLICATION",
                    "description": "EDC Solutions"
                }
            },
            {
                "id": 42,
                "name": "Clinical Data Quality",
                "code": "CLINICAL_DATA_QUALITY_APPLICATION",
                "description": "IWRS Application",
                "configDataType": {
                    "id": 17,
                    "name": "Application",
                    "code": "APPLICATION",
                    "description": "EDC Solutions"
                }
            }
        ],
        "studyStatus": true,
        "studyAdmin": null,
        "therapeuticArea": {
            "id": 294,
            "name": "Gastroenterology",
            "code": "THERAPEUTIC_GASTROENTEROLOGY",
            "description": "therapeutic area is Gastroenterology",
            "configDataType": {
                "id": 32,
                "name": "Therapeutic",
                "code": "THERAPEUTIC",
                "description": "List of Therapeutic areas"
            }
        },
        "indication": {
            "id": 332,
            "name": "Special Population",
            "code": "INDICATION_SPECIAL_POPULATION",
            "description": "indication type is SPECIAL POPULATION",
            "configDataType": {
                "id": 33,
                "name": "Indication",
                "code": "INDICATION",
                "description": "List of Indications"
            }
        },
        "studyDesign": {
            "id": 335,
            "name": "Alter Nating Panel",
            "code": "STUDY_DESIGN_ALTER_NATING_PANEL",
            "description": "study_design type is ALTER NATING PANEL",
            "configDataType": {
                "id": 34,
                "name": "Study Design",
                "code": "STUDY_DESIGN",
                "description": "List of Study Designs"
            }
        },
        "regulatory": {
            "id": 326,
            "name": "Pmda",
            "code": "REGULATORY_PMDA",
            "description": "regulatory type is PMDA",
            "configDataType": {
                "id": 35,
                "name": "Regulatory",
                "code": "REGULATORY",
                "description": "List of Regulatorys "
            }
        },
        "investigation": {
            "id": 278,
            "name": "Biological",
            "code": "INVESTIGATION_BIOLOGICAL",
            "description": "investigation type is Biological",
            "configDataType": {
                "id": 36,
                "name": "Investigation",
                "code": "INVESTIGATION",
                "description": "List of Investigation areas"
            }
        },
        "populations": {
            "id": 342,
            "name": "Oncology Patients",
            "code": "POPULATION_ONCOLOGY_PATIENTS",
            "description": "population type is ONCOLOGY PATIENTS",
            "configDataType": {
                "id": 37,
                "name": "Population",
                "code": "POPULATION",
                "description": "List of Population areas"
            }
        },
        "studyPasscodeDto": {
            "devPasscode": "SVJRRVgyRFFRTg==",
            "uatPasscode": "UlRYTEtEQTNSRw==",
            "prodPasscode": "QktKQVFGSUhNNA=="
        },
        "visitsCount": 34,
        "subjectSampleSize": 34,
        "orgStudiesCount": 0,
        "regionId": null,
        "studyContacts": [
            {
                "id": 11,
                "organizationId": 1,
                "firstName": "sra",
                "lastName": "nar",
                "email": "sravanthi.naramgari@inductivequotient.com",
                "phoneNo": "1111111111",
                "contactDesgn": "",
                "contactType": {
                    "id": 483,
                    "name": "Primary Study Admin",
                    "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                    "description": null,
                    "configDataType": {
                        "id": 13,
                        "name": "Contact Type",
                        "code": "CONTACT_TYPE",
                        "description": "descrides Contact Types"
                    }
                },
                "active": true,
                "userName": "snaramgari",
                "studyId": 6,
                "orgName": "Clinic_123"
            }
        ],
        "edcSolutions": []
    },
    {
        "id": 5,
        "studyName": "Test Study231",
        "organization": {
            "id": 2,
            "orgName": "TestOrg_rwvy",
            "addressLine1": "Durgam cheruvu",
            "addressLine2": "Krishna Sapphire",
            "city": {
                "id": 6833,
                "name": "Eisenstadt",
                "state": {
                    "id": 280,
                    "name": "Burgenland",
                    "country": {
                        "id": 14,
                        "name": "Austria",
                        "countryCode": "AT",
                        "phoneCode": 43
                    }
                }
            },
            "state": {
                "id": 280,
                "name": "Burgenland",
                "country": {
                    "id": 14,
                    "name": "Austria",
                    "countryCode": "AT",
                    "phoneCode": 43
                }
            },
            "country": {
                "id": 14,
                "name": "Austria",
                "countryCode": "AT",
                "phoneCode": 43
            },
            "postalZipCode": "74124",
            "phone": "2949141864",
            "companyUrl": "iqatrapz.com",
            "passcode": "5NYM1Y7G1N",
            "isActive": true,
            "orgContacts": [
                {
                    "id": 84,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 23,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 83,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 22,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 204,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 33,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 160,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 27,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 157,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 25,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 75,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 20,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 210,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 34,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 162,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 28,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 164,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 30,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 78,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 21,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 159,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 26,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 163,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 29,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 61,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 17,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 74,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 19,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 165,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 31,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 203,
                    "organizationId": 2,
                    "firstName": "Ganesh",
                    "lastName": "Vadde",
                    "email": "ganesh.vadde@inductivequotient.com",
                    "phoneNo": "2222222222",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "gvadde",
                    "studyId": 32,
                    "orgName": "TEST-QA"
                },
                {
                    "id": 7,
                    "organizationId": 2,
                    "firstName": "Swathi",
                    "lastName": "Meesaragandam",
                    "email": "swathi.meesaragandam2949@inductivequotient.com",
                    "phoneNo": "2949463721",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 44,
                        "name": "Others Contact",
                        "code": "CONTACT_TYPE_OTHERS_CONTACT",
                        "description": "Others Contact For Organization",
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": null,
                    "studyId": null,
                    "orgName": null
                },
                {
                    "id": 4,
                    "organizationId": 2,
                    "firstName": "Monika",
                    "lastName": "Dronadula",
                    "email": "monika.dronadula2949@inductivequotient.com",
                    "phoneNo": "2949141864",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 26,
                        "name": "Primary Contact",
                        "code": "CONTACT_TYPE_PRIMARY_CONTACT",
                        "description": "Primary Contact For Organization",
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": null,
                    "studyId": null,
                    "orgName": null
                }
            ],
            "orgDocuments": [],
            "orgShortname": "OrgSturhba",
            "telephone": "2949463721",
            "orgType": {
                "id": 11,
                "name": "CRO",
                "code": "ORG_TYPE_CRO",
                "description": "indicates  organization type is cro",
                "configDataType": {
                    "id": 5,
                    "name": "Organization Type",
                    "code": "ORG_TYPE",
                    "description": "describes type of organization"
                }
            },
            "orgStudyStatus": false
        },
        "ctPhase": {
            "id": 22,
            "name": "Phase 1",
            "code": "STUDY_PHASE_PHASE1",
            "description": "indicates the study phase is phase 1",
            "configDataType": {
                "id": 11,
                "name": "Study Phase",
                "code": "STUDY_PHASE",
                "description": "describes the study phase"
            }
        },
        "approvalStatus": {
            "id": 6,
            "name": "Approved",
            "code": "WF_STATUS_TYPE_APPROVED",
            "description": "indicates the work flow  status approved",
            "configDataType": {
                "id": 2,
                "name": "Workflow Status",
                "code": "WF_STATUS_TYPE",
                "description": "describe workflow status of the user"
            }
        },
        "startDate": "2022-12-31",
        "endDate": "2023-12-31",
        "studySchema": "",
        "primaryContact": {
            "id": 10,
            "organizationId": 1,
            "firstName": "sra",
            "lastName": "nar",
            "email": "sravanthi.naramgari@inductivequotient.com",
            "phoneNo": "1111111111",
            "contactDesgn": "",
            "contactType": {
                "id": 483,
                "name": "Primary Study Admin",
                "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                "description": null,
                "configDataType": {
                    "id": 13,
                    "name": "Contact Type",
                    "code": "CONTACT_TYPE",
                    "description": "descrides Contact Types"
                }
            },
            "active": true,
            "userName": "snaramgari",
            "studyId": 5,
            "orgName": "Clinic_123"
        },
        "secondaryContact": null,
        "request": {
            "id": 5,
            "reqObjectId": {
                "id": 18,
                "name": "Study Request Form",
                "code": "OBJECT_TYPE_STUDY_REQUEST_FORM",
                "description": "indicates the object is refering to study",
                "configDataType": {
                    "id": 9,
                    "name": "Object Type",
                    "code": "OBJECT_TYPE",
                    "description": "describes the type of the object for transaction"
                }
            },
            "reqWfStatusId": {
                "id": 6,
                "name": "Approved",
                "code": "WF_STATUS_TYPE_APPROVED",
                "description": "indicates the work flow  status approved",
                "configDataType": {
                    "id": 2,
                    "name": "Workflow Status",
                    "code": "WF_STATUS_TYPE",
                    "description": "describe workflow status of the user"
                }
            },
            "completedOn": "2023-09-15T08:06:06Z",
            "completedBy": 6
        },
        "approver": null,
        "studyRequestor": {
            "id": 5,
            "name": "snaramgari"
        },
        "studyType": {
            "id": 19,
            "name": "BABE Study",
            "code": "STUDY_TYPE_BABE",
            "description": "indicates the study type is BABE",
            "configDataType": {
                "id": 10,
                "name": "Study Type",
                "code": "STUDY_TYPE",
                "description": "describes the study type as BABE / CT / Research etc"
            }
        },
        "protocolId": "Study_kzws",
        "comments": "req",
        "studyDocuments": [
            {
                "id": 5,
                "fileName": "Study Details (9).PDF",
                "fileContentType": "application/pdf",
                "study": "Test Study231",
                "documentType": {
                    "id": 29,
                    "name": "Email",
                    "code": "DOC_TYPE_EMAIL",
                    "description": "Email Document Type",
                    "configDataType": {
                        "id": 14,
                        "name": "Document Type",
                        "code": "DOC_TYPE",
                        "description": "Document Type"
                    }
                }
            }
        ],
        "solutions": [
            {
                "id": 41,
                "name": "Inductive EDC",
                "code": "INDUCTIVE_EDC_APPLICATION",
                "description": "EDC Application",
                "configDataType": {
                    "id": 17,
                    "name": "Application",
                    "code": "APPLICATION",
                    "description": "EDC Solutions"
                }
            }
        ],
        "studyStatus": true,
        "studyAdmin": null,
        "therapeuticArea": {
            "id": 290,
            "name": "Dermatology",
            "code": "THERAPEUTIC_DERMATOLOGY",
            "description": "therapeutic area is Dermatology",
            "configDataType": {
                "id": 32,
                "name": "Therapeutic",
                "code": "THERAPEUTIC",
                "description": "List of Therapeutic areas"
            }
        },
        "indication": {
            "id": 333,
            "name": "Rest Of The World",
            "code": "INDICATION_REST_OF_THE_WORLD",
            "description": "indication type is REST OF THE WORLD",
            "configDataType": {
                "id": 33,
                "name": "Indication",
                "code": "INDICATION",
                "description": "List of Indications"
            }
        },
        "studyDesign": {
            "id": 334,
            "name": "Ascending Dose",
            "code": "STUDY_DESIGN_ASCENDING_DOSE",
            "description": "study_design type is ASCENDING DOSE",
            "configDataType": {
                "id": 34,
                "name": "Study Design",
                "code": "STUDY_DESIGN",
                "description": "List of Study Designs"
            }
        },
        "regulatory": {
            "id": 324,
            "name": "Fda",
            "code": "REGULATORY_FDA",
            "description": "regulatory type is FDA",
            "configDataType": {
                "id": 35,
                "name": "Regulatory",
                "code": "REGULATORY",
                "description": "List of Regulatorys "
            }
        },
        "investigation": {
            "id": 277,
            "name": "Behavioral",
            "code": "INVESTIGATION_BEHAVIORAL",
            "description": "investigation type is Behavioral",
            "configDataType": {
                "id": 36,
                "name": "Investigation",
                "code": "INVESTIGATION",
                "description": "List of Investigation areas"
            }
        },
        "populations": {
            "id": 341,
            "name": "Healthy Volunteers",
            "code": "POPULATION_HEALTHY_VOLUNTEERS",
            "description": "population type is HEALTHY VOLUNTEERS",
            "configDataType": {
                "id": 37,
                "name": "Population",
                "code": "POPULATION",
                "description": "List of Population areas"
            }
        },
        "studyPasscodeDto": {
            "devPasscode": "MU5BVEdIQ1dMWQ==",
            "uatPasscode": "OFQzVDMwRkk0WA==",
            "prodPasscode": "TldFRVVEUlFCSA=="
        },
        "visitsCount": 1,
        "subjectSampleSize": 1,
        "orgStudiesCount": 0,
        "regionId": null,
        "studyContacts": [
            {
                "id": 10,
                "organizationId": 1,
                "firstName": "sra",
                "lastName": "nar",
                "email": "sravanthi.naramgari@inductivequotient.com",
                "phoneNo": "1111111111",
                "contactDesgn": "",
                "contactType": {
                    "id": 483,
                    "name": "Primary Study Admin",
                    "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                    "description": null,
                    "configDataType": {
                        "id": 13,
                        "name": "Contact Type",
                        "code": "CONTACT_TYPE",
                        "description": "descrides Contact Types"
                    }
                },
                "active": true,
                "userName": "snaramgari",
                "studyId": 5,
                "orgName": "Clinic_123"
            }
        ],
        "edcSolutions": []
    },
    {
        "id": 4,
        "studyName": "qwqe",
        "organization": {
            "id": 1,
            "orgName": "Clinic_123",
            "addressLine1": "hyd",
            "addressLine2": "",
            "city": {
                "id": 705,
                "name": "Diu",
                "state": {
                    "id": 9,
                    "name": "Daman and Diu",
                    "country": {
                        "id": 101,
                        "name": "India",
                        "countryCode": "IN",
                        "phoneCode": 0
                    }
                }
            },
            "state": {
                "id": 9,
                "name": "Daman and Diu",
                "country": {
                    "id": 101,
                    "name": "India",
                    "countryCode": "IN",
                    "phoneCode": 0
                }
            },
            "country": {
                "id": 101,
                "name": "India",
                "countryCode": "IN",
                "phoneCode": 0
            },
            "postalZipCode": "343434",
            "phone": "5656565656",
            "companyUrl": "jiop.in",
            "passcode": "SPFIYPTQPW",
            "isActive": true,
            "orgContacts": [
                {
                    "id": 155,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 24,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 3,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 2,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 20,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 10,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 8,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 3,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 29,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 15,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 10,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 5,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 30,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 16,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 2,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 1,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 64,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 18,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 18,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 9,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 22,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 12,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 23,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 13,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 17,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 8,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 24,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 14,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 21,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 11,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 11,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 6,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 62,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 484,
                        "name": "Secondry Study Admin",
                        "code": "CONTACT_TYPE_SECONDRY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 17,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 9,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 4,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 12,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 7,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 1,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "sravanthi",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "3434343434",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 26,
                        "name": "Primary Contact",
                        "code": "CONTACT_TYPE_PRIMARY_CONTACT",
                        "description": "Primary Contact For Organization",
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": null,
                    "studyId": null,
                    "orgName": null
                }
            ],
            "orgDocuments": [],
            "orgShortname": "jio",
            "telephone": "3434343434",
            "orgType": {
                "id": 12,
                "name": "Govt Org",
                "code": "ORG_TYPE_GOVT_ORG",
                "description": "indicates  organization type is government organization",
                "configDataType": {
                    "id": 5,
                    "name": "Organization Type",
                    "code": "ORG_TYPE",
                    "description": "describes type of organization"
                }
            },
            "orgStudyStatus": false
        },
        "ctPhase": {
            "id": 23,
            "name": "Phase 2",
            "code": "STUDY_PHASE_PHASE2",
            "description": "indicates the study phase is phase 2",
            "configDataType": {
                "id": 11,
                "name": "Study Phase",
                "code": "STUDY_PHASE",
                "description": "describes the study phase"
            }
        },
        "approvalStatus": {
            "id": 6,
            "name": "Approved",
            "code": "WF_STATUS_TYPE_APPROVED",
            "description": "indicates the work flow  status approved",
            "configDataType": {
                "id": 2,
                "name": "Workflow Status",
                "code": "WF_STATUS_TYPE",
                "description": "describe workflow status of the user"
            }
        },
        "startDate": "2023-09-16",
        "endDate": "2023-09-20",
        "studySchema": "",
        "primaryContact": {
            "id": 9,
            "organizationId": 1,
            "firstName": "sra",
            "lastName": "nar",
            "email": "sravanthi.naramgari@inductivequotient.com",
            "phoneNo": "1111111111",
            "contactDesgn": "",
            "contactType": {
                "id": 483,
                "name": "Primary Study Admin",
                "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                "description": null,
                "configDataType": {
                    "id": 13,
                    "name": "Contact Type",
                    "code": "CONTACT_TYPE",
                    "description": "descrides Contact Types"
                }
            },
            "active": true,
            "userName": "snaramgari",
            "studyId": 4,
            "orgName": "Clinic_123"
        },
        "secondaryContact": null,
        "request": {
            "id": 4,
            "reqObjectId": {
                "id": 18,
                "name": "Study Request Form",
                "code": "OBJECT_TYPE_STUDY_REQUEST_FORM",
                "description": "indicates the object is refering to study",
                "configDataType": {
                    "id": 9,
                    "name": "Object Type",
                    "code": "OBJECT_TYPE",
                    "description": "describes the type of the object for transaction"
                }
            },
            "reqWfStatusId": {
                "id": 6,
                "name": "Approved",
                "code": "WF_STATUS_TYPE_APPROVED",
                "description": "indicates the work flow  status approved",
                "configDataType": {
                    "id": 2,
                    "name": "Workflow Status",
                    "code": "WF_STATUS_TYPE",
                    "description": "describe workflow status of the user"
                }
            },
            "completedOn": "2023-09-15T08:03:34Z",
            "completedBy": 6
        },
        "approver": null,
        "studyRequestor": {
            "id": 5,
            "name": "snaramgari"
        },
        "studyType": {
            "id": 19,
            "name": "BABE Study",
            "code": "STUDY_TYPE_BABE",
            "description": "indicates the study type is BABE",
            "configDataType": {
                "id": 10,
                "name": "Study Type",
                "code": "STUDY_TYPE",
                "description": "describes the study type as BABE / CT / Research etc"
            }
        },
        "protocolId": "TEST-1Q",
        "comments": "HELLOOOOOOOOOOOOO",
        "studyDocuments": [
            {
                "id": 4,
                "fileName": "JD for references template (1).msg",
                "fileContentType": "application/vnd.ms-outlook",
                "study": "qwqe",
                "documentType": {
                    "id": 29,
                    "name": "Email",
                    "code": "DOC_TYPE_EMAIL",
                    "description": "Email Document Type",
                    "configDataType": {
                        "id": 14,
                        "name": "Document Type",
                        "code": "DOC_TYPE",
                        "description": "Document Type"
                    }
                }
            }
        ],
        "solutions": [
            {
                "id": 41,
                "name": "Inductive EDC",
                "code": "INDUCTIVE_EDC_APPLICATION",
                "description": "EDC Application",
                "configDataType": {
                    "id": 17,
                    "name": "Application",
                    "code": "APPLICATION",
                    "description": "EDC Solutions"
                }
            },
            {
                "id": 42,
                "name": "Clinical Data Quality",
                "code": "CLINICAL_DATA_QUALITY_APPLICATION",
                "description": "IWRS Application",
                "configDataType": {
                    "id": 17,
                    "name": "Application",
                    "code": "APPLICATION",
                    "description": "EDC Solutions"
                }
            }
        ],
        "studyStatus": true,
        "studyAdmin": null,
        "therapeuticArea": {
            "id": 295,
            "name": "Gene_Therapy",
            "code": "THERAPEUTIC_GENE_THERAPY",
            "description": "therapeutic area is Gene Therapy",
            "configDataType": {
                "id": 32,
                "name": "Therapeutic",
                "code": "THERAPEUTIC",
                "description": "List of Therapeutic areas"
            }
        },
        "indication": {
            "id": 333,
            "name": "Rest Of The World",
            "code": "INDICATION_REST_OF_THE_WORLD",
            "description": "indication type is REST OF THE WORLD",
            "configDataType": {
                "id": 33,
                "name": "Indication",
                "code": "INDICATION",
                "description": "List of Indications"
            }
        },
        "studyDesign": {
            "id": 334,
            "name": "Ascending Dose",
            "code": "STUDY_DESIGN_ASCENDING_DOSE",
            "description": "study_design type is ASCENDING DOSE",
            "configDataType": {
                "id": 34,
                "name": "Study Design",
                "code": "STUDY_DESIGN",
                "description": "List of Study Designs"
            }
        },
        "regulatory": {
            "id": 325,
            "name": "Ema",
            "code": "REGULATORY_EMA",
            "description": "regulatory type is EMA",
            "configDataType": {
                "id": 35,
                "name": "Regulatory",
                "code": "REGULATORY",
                "description": "List of Regulatorys "
            }
        },
        "investigation": {
            "id": 279,
            "name": "Combination_Product",
            "code": "INVESTIGATION_COMBINATION_PRODUCT",
            "description": "investigation type is Combination Product",
            "configDataType": {
                "id": 36,
                "name": "Investigation",
                "code": "INVESTIGATION",
                "description": "List of Investigation areas"
            }
        },
        "populations": {
            "id": 341,
            "name": "Healthy Volunteers",
            "code": "POPULATION_HEALTHY_VOLUNTEERS",
            "description": "population type is HEALTHY VOLUNTEERS",
            "configDataType": {
                "id": 37,
                "name": "Population",
                "code": "POPULATION",
                "description": "List of Population areas"
            }
        },
        "studyPasscodeDto": {
            "devPasscode": "T1ozU0dLS045WA==",
            "uatPasscode": "V0JTREpKN0Q1Rg==",
            "prodPasscode": "RlowUEo4TTFHSg=="
        },
        "visitsCount": 45,
        "subjectSampleSize": 44,
        "orgStudiesCount": 0,
        "regionId": null,
        "studyContacts": [
            {
                "id": 9,
                "organizationId": 1,
                "firstName": "sra",
                "lastName": "nar",
                "email": "sravanthi.naramgari@inductivequotient.com",
                "phoneNo": "1111111111",
                "contactDesgn": "",
                "contactType": {
                    "id": 483,
                    "name": "Primary Study Admin",
                    "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                    "description": null,
                    "configDataType": {
                        "id": 13,
                        "name": "Contact Type",
                        "code": "CONTACT_TYPE",
                        "description": "descrides Contact Types"
                    }
                },
                "active": true,
                "userName": "snaramgari",
                "studyId": 4,
                "orgName": "Clinic_123"
            }
        ],
        "edcSolutions": []
    },
    {
        "id": 2,
        "studyName": "Test Study23",
        "organization": {
            "id": 1,
            "orgName": "Clinic_123",
            "addressLine1": "hyd",
            "addressLine2": "",
            "city": {
                "id": 705,
                "name": "Diu",
                "state": {
                    "id": 9,
                    "name": "Daman and Diu",
                    "country": {
                        "id": 101,
                        "name": "India",
                        "countryCode": "IN",
                        "phoneCode": 0
                    }
                }
            },
            "state": {
                "id": 9,
                "name": "Daman and Diu",
                "country": {
                    "id": 101,
                    "name": "India",
                    "countryCode": "IN",
                    "phoneCode": 0
                }
            },
            "country": {
                "id": 101,
                "name": "India",
                "countryCode": "IN",
                "phoneCode": 0
            },
            "postalZipCode": "343434",
            "phone": "5656565656",
            "companyUrl": "jiop.in",
            "passcode": "SPFIYPTQPW",
            "isActive": true,
            "orgContacts": [
                {
                    "id": 155,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 24,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 3,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 2,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 20,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 10,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 8,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 3,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 29,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 15,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 10,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 5,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 30,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 16,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 2,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 1,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 64,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 18,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 18,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 9,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 22,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 12,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 23,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 13,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 17,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 8,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 24,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 14,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 21,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 11,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 11,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 6,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 62,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "naramgari",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 484,
                        "name": "Secondry Study Admin",
                        "code": "CONTACT_TYPE_SECONDRY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 17,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 9,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 4,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 12,
                    "organizationId": 1,
                    "firstName": "sra",
                    "lastName": "nar",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "1111111111",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 483,
                        "name": "Primary Study Admin",
                        "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                        "description": null,
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": "snaramgari",
                    "studyId": 7,
                    "orgName": "Clinic_123"
                },
                {
                    "id": 1,
                    "organizationId": 1,
                    "firstName": "sravanthi",
                    "lastName": "sravanthi",
                    "email": "sravanthi.naramgari@inductivequotient.com",
                    "phoneNo": "3434343434",
                    "contactDesgn": "",
                    "contactType": {
                        "id": 26,
                        "name": "Primary Contact",
                        "code": "CONTACT_TYPE_PRIMARY_CONTACT",
                        "description": "Primary Contact For Organization",
                        "configDataType": {
                            "id": 13,
                            "name": "Contact Type",
                            "code": "CONTACT_TYPE",
                            "description": "descrides Contact Types"
                        }
                    },
                    "active": true,
                    "userName": null,
                    "studyId": null,
                    "orgName": null
                }
            ],
            "orgDocuments": [],
            "orgShortname": "jio",
            "telephone": "3434343434",
            "orgType": {
                "id": 12,
                "name": "Govt Org",
                "code": "ORG_TYPE_GOVT_ORG",
                "description": "indicates  organization type is government organization",
                "configDataType": {
                    "id": 5,
                    "name": "Organization Type",
                    "code": "ORG_TYPE",
                    "description": "describes type of organization"
                }
            },
            "orgStudyStatus": false
        },
        "ctPhase": {
            "id": 22,
            "name": "Phase 1",
            "code": "STUDY_PHASE_PHASE1",
            "description": "indicates the study phase is phase 1",
            "configDataType": {
                "id": 11,
                "name": "Study Phase",
                "code": "STUDY_PHASE",
                "description": "describes the study phase"
            }
        },
        "approvalStatus": {
            "id": 366,
            "name": "Provisioned",
            "code": "WF_STATUS_TYPE_PROVISIONED",
            "description": "Provisioner the study ",
            "configDataType": {
                "id": 2,
                "name": "Workflow Status",
                "code": "WF_STATUS_TYPE",
                "description": "describe workflow status of the user"
            }
        },
        "startDate": "2022-12-31",
        "endDate": "2023-12-31",
        "studySchema": "",
        "primaryContact": {
            "id": 3,
            "organizationId": 1,
            "firstName": "sra",
            "lastName": "nar",
            "email": "sravanthi.naramgari@inductivequotient.com",
            "phoneNo": "1111111111",
            "contactDesgn": "",
            "contactType": {
                "id": 483,
                "name": "Primary Study Admin",
                "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                "description": null,
                "configDataType": {
                    "id": 13,
                    "name": "Contact Type",
                    "code": "CONTACT_TYPE",
                    "description": "descrides Contact Types"
                }
            },
            "active": true,
            "userName": "snaramgari",
            "studyId": 2,
            "orgName": "Clinic_123"
        },
        "secondaryContact": null,
        "request": {
            "id": 2,
            "reqObjectId": {
                "id": 18,
                "name": "Study Request Form",
                "code": "OBJECT_TYPE_STUDY_REQUEST_FORM",
                "description": "indicates the object is refering to study",
                "configDataType": {
                    "id": 9,
                    "name": "Object Type",
                    "code": "OBJECT_TYPE",
                    "description": "describes the type of the object for transaction"
                }
            },
            "reqWfStatusId": {
                "id": 366,
                "name": "Provisioned",
                "code": "WF_STATUS_TYPE_PROVISIONED",
                "description": "Provisioner the study ",
                "configDataType": {
                    "id": 2,
                    "name": "Workflow Status",
                    "code": "WF_STATUS_TYPE",
                    "description": "describe workflow status of the user"
                }
            },
            "completedOn": "2023-09-15T07:59:05Z",
            "completedBy": 5
        },
        "approver": null,
        "studyRequestor": {
            "id": 5,
            "name": "snaramgari"
        },
        "studyType": {
            "id": 19,
            "name": "BABE Study",
            "code": "STUDY_TYPE_BABE",
            "description": "indicates the study type is BABE",
            "configDataType": {
                "id": 10,
                "name": "Study Type",
                "code": "STUDY_TYPE",
                "description": "describes the study type as BABE / CT / Research etc"
            }
        },
        "protocolId": "Study_kz",
        "comments": "",
        "studyDocuments": [
            {
                "id": 2,
                "fileName": "Study Details (6) (1).PDF",
                "fileContentType": "application/pdf",
                "study": "Test Study23",
                "documentType": {
                    "id": 29,
                    "name": "Email",
                    "code": "DOC_TYPE_EMAIL",
                    "description": "Email Document Type",
                    "configDataType": {
                        "id": 14,
                        "name": "Document Type",
                        "code": "DOC_TYPE",
                        "description": "Document Type"
                    }
                }
            }
        ],
        "solutions": [
            {
                "id": 41,
                "name": "Inductive EDC",
                "code": "INDUCTIVE_EDC_APPLICATION",
                "description": "EDC Application",
                "configDataType": {
                    "id": 17,
                    "name": "Application",
                    "code": "APPLICATION",
                    "description": "EDC Solutions"
                }
            }
        ],
        "studyStatus": true,
        "studyAdmin": null,
        "therapeuticArea": {
            "id": 288,
            "name": "Cardiology/Vascular_Diseases",
            "code": "THERAPEUTIC_CARDIOLOGY_VASCULAR_DISEASES",
            "description": "therapeutic area is Cardiology/Vascular Diseases",
            "configDataType": {
                "id": 32,
                "name": "Therapeutic",
                "code": "THERAPEUTIC",
                "description": "List of Therapeutic areas"
            }
        },
        "indication": {
            "id": 333,
            "name": "Rest Of The World",
            "code": "INDICATION_REST_OF_THE_WORLD",
            "description": "indication type is REST OF THE WORLD",
            "configDataType": {
                "id": 33,
                "name": "Indication",
                "code": "INDICATION",
                "description": "List of Indications"
            }
        },
        "studyDesign": {
            "id": 334,
            "name": "Ascending Dose",
            "code": "STUDY_DESIGN_ASCENDING_DOSE",
            "description": "study_design type is ASCENDING DOSE",
            "configDataType": {
                "id": 34,
                "name": "Study Design",
                "code": "STUDY_DESIGN",
                "description": "List of Study Designs"
            }
        },
        "regulatory": {
            "id": 324,
            "name": "Fda",
            "code": "REGULATORY_FDA",
            "description": "regulatory type is FDA",
            "configDataType": {
                "id": 35,
                "name": "Regulatory",
                "code": "REGULATORY",
                "description": "List of Regulatorys "
            }
        },
        "investigation": {
            "id": 277,
            "name": "Behavioral",
            "code": "INVESTIGATION_BEHAVIORAL",
            "description": "investigation type is Behavioral",
            "configDataType": {
                "id": 36,
                "name": "Investigation",
                "code": "INVESTIGATION",
                "description": "List of Investigation areas"
            }
        },
        "populations": {
            "id": 341,
            "name": "Healthy Volunteers",
            "code": "POPULATION_HEALTHY_VOLUNTEERS",
            "description": "population type is HEALTHY VOLUNTEERS",
            "configDataType": {
                "id": 37,
                "name": "Population",
                "code": "POPULATION",
                "description": "List of Population areas"
            }
        },
        "studyPasscodeDto": {
            "devPasscode": "QjVRTkFYT0JQUg==",
            "uatPasscode": "UzJJME1TS1U0RQ==",
            "prodPasscode": "RVJWS0tSSFpPRw=="
        },
        "visitsCount": 1,
        "subjectSampleSize": 1,
        "orgStudiesCount": 0,
        "regionId": null,
        "studyContacts": [
            {
                "id": 3,
                "organizationId": 1,
                "firstName": "sra",
                "lastName": "nar",
                "email": "sravanthi.naramgari@inductivequotient.com",
                "phoneNo": "1111111111",
                "contactDesgn": "",
                "contactType": {
                    "id": 483,
                    "name": "Primary Study Admin",
                    "code": "CONTACT_TYPE_PRIMARY_STUDY_ADMIN",
                    "description": null,
                    "configDataType": {
                        "id": 13,
                        "name": "Contact Type",
                        "code": "CONTACT_TYPE",
                        "description": "descrides Contact Types"
                    }
                },
                "active": true,
                "userName": "snaramgari",
                "studyId": 2,
                "orgName": "Clinic_123"
            }
        ],
        "edcSolutions": []
    }
]