export const messages = {
    apiError: 'Something went wrong',
    inActive: 'Are you sure do you want to inactive ',
    active: 'Are you sure do you want to active ',
    inActivated: 'Activated Successfully',
    activated: 'Inactivated Successfully'
}