export const fileManagerFiles = {
    "projectName": "project-1",
    "filemanager": [
        {
            "key": "0",
            "label": "module-1",
            "type": "folder",
            "opened": false,
            "children": [
                {
                    "key": "0-0",
                    "label": "module-1-1",
                    "type": "folder",
                    "opened": false,
                    "children": [
                        {
                            "key": "0-0-0",
                            "id":"1",
                            "label": "module-1 file-1",
                            "type": "file",
                            "active": false,
                            "code": "come file-1 code"
                        }
                    ]
                }
            ]
        },
        {
            "key": "1",
            "label": "module-2",
            "type": "folder",
            "opened": false,
            "children": [
                {
                    "key": "1-0",
                    "label": "module-2-file1",
                    "id":"2",
                    "type": "file",
                    "active": false,
                    "code": "some module 2 file -1 code"
                }
            ]
        },
        {
            "key": "2",
            "label": "module-3",
            "type": "folder",
            "opened": false,
            "children": [
                {
                    "key": "2-0",
                    "label": "module-3-1",
                    "type": "folder",
                    "opened": false,
                    "children": [
                        {
                            "key": "2-0-0",
                            "label": "file-1",
                            "id":"3",
                            "type": "file",
                            "active": false,
                            "code": "module 3 file -1 code"
                        }
                    ]
                }
            ]
        }
    ]
}