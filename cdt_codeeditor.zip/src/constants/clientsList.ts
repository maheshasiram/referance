export const clientsList = {
    totalRecords: 12,
    data: [
        {
            protocoltitle: "Protocol 1",
            myRole: "user",
            principalInvestigator: "william",
            status: true,
            version: '0.001',
            id: '0'

        },
        {
            protocoltitle: "Protocol 2",
            myRole: "CRM",
            principalInvestigator: "John",
            status: false,
            version: '0.002',
            id: '1'
        },
        {
            protocoltitle: "Protocol 3",
            myRole: "Admin",
            principalInvestigator: "wills",
            status: true,
            version: '0.004',
            id: '2'
        },
        {
            protocoltitle: "Protocol 4",
            myRole: "user",
            principalInvestigator: "kane",
            status: true,
            version: '0.007',
            id: '3'
        },
        {
            protocoltitle: "Protocol 5",
            myRole: "Monitor",
            principalInvestigator: "Stephen",
            status: false,
            version: '0.006',
            id: '4'
        },
        {
            protocoltitle: "Protocol 1",
            myRole: "user",
            principalInvestigator: "william",
            status: 'New',
            version: '0.001',
            id:'5'
        },
        {
            protocoltitle: "Protocol 2",
            myRole: "CRM",
            principalInvestigator: "John",
            status: "Inprogress",
            version: '0.002'
        },
        {
            protocoltitle: "Protocol 3",
            myRole: "Admin",
            principalInvestigator: "wills",
            status: 'Completed',
            version: '0.004'
        },
        {
            protocoltitle: "Protocol 4",
            myRole: "user",
            principalInvestigator: "kane",
            status: 'Yet to start phase III',
            version: '0.007'
        },
        {
            protocoltitle: "Protocol 5",
            myRole: "Monitor",
            principalInvestigator: "Stephen",
            status: 'Phase II completed',
            version: '0.006'
        }
    ]
}