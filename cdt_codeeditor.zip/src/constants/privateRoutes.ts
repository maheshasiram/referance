import { lazy } from "react";


export const privateRoutes = [
    {
        name: 'Modules',
        pathName: '/modules',
        Component: lazy(() => import('../components/modules/Modules')),
        navigateTo: '/modules',
        icon:lazy(()=> import('@mui/icons-material/ViewModule'))
    },
    {
        name: 'Tables',
        pathName: '/tables',
        Component: lazy(() => import('../components/tables/Tables')),
        navigateTo: '/tables',
        icon:lazy(()=> import('@mui/icons-material/TableChart'))
    },
    {
        name: 'Listing',
        pathName: '/listing',
        // Component: lazy(() => import('../components/modules/Modules')),
        Component: lazy(() => import('../components/listing/Listing')),
        navigateTo: '/listing',
        icon:lazy(()=> import('@mui/icons-material/ListAlt'))
    },
    {
        name: 'Figures',
        pathName: '/figures',
        Component: lazy(() => import('../components/figures/Figures')),
        navigateTo: '/figures',
        icon:lazy(()=> import('@mui/icons-material/InsertChart'))
    },
    {
        name: 'Clients',
        pathName: '/clients',
        Component: lazy(() => import('../components/clients/Clients')),
        navigateTo: '/clients',
        icon:lazy(()=> import('@mui/icons-material/Code')),
    },
    {
        name: 'Client',
        pathName: '/client/:clientId',
        Component: lazy(() => import('../components/studies/Studies')),
        navigateTo: '/',
        icon:lazy(()=> import('@mui/icons-material/Code')),
    },
    {
        name: 'Client',
        pathName: '/client/:clientId/:studyId',
        Component: lazy(() => import('../components/codeEditor/CodeEditor')),
        navigateTo: '/',
        icon:lazy(()=> import('@mui/icons-material/Code')),
    }
   
]