import React, { Suspense, useEffect } from 'react';
import { BrowserRouter, Navigate, Route, Routes, useLocation } from 'react-router-dom';
import AppHeader from '../components/header/AppHeader';
import Modules from '../components/modules/Modules';
import PublicRoute from './PublicRoute';
import PrivateRoute from './PrivateRoute';
import { privateRoutes } from '../constants/privateRoutes';
import SnackBarToast from '../common/modals/SnackBarToast';

function Root(): JSX.Element {
    // const { state } = useLocation();
    return (
        // <BrowserRouter>
        <div className='app-Container'>
            <Suspense fallback={<div>Loading......</div>}>
                <SnackBarToast />
                <Routes>
                    <Route
                        path="/"
                        element={
                            <PublicRoute isAuthenticated={true} to="/modules">
                                <div>Sign In</div>
                            </PublicRoute>
                        }
                    />
                    {privateRoutes.map((Item: any, index: number) => {
                        return <Route key={index} path={Item.pathName} element={
                            <PrivateRoute isAuthenticated={true} to="/">
                                {
                                    Item.children && Item.renderChild ? Item.children.map((child: any, childIndex: any) => {
                                        return Item.renderChild && <Routes key={childIndex}><Route path={child.pathName} element={<child.Component />}></Route></Routes>
                                    }) : <Item.Component />
                                }
                            </PrivateRoute>
                        } />
                    })}
                </Routes>
            </Suspense>
        </div>
        // </BrowserRouter>
    )
}
export default Root;