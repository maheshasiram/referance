import React, { useEffect } from 'react';
import FilesManager from './components/FilesManager';
import NoteAddOutlinedIcon from '@mui/icons-material/NoteAddOutlined';
import CreateNewFolderOutlinedIcon from '@mui/icons-material/CreateNewFolderOutlined';
import CustomToolTip from '../../common/CustomToolTip';
import ClearIcon from '@mui/icons-material/Clear';
import './styles.scss';
import EditorModule from './components/EditorModule';
import { useSelector } from 'react-redux';
import { useDispatch } from 'react-redux';
import { createFolder, createSubFolder, fetchAllFolders, getAllModules, updateFolder } from './actions/actions';
import { Switch } from '@mui/material';
import TerminalComponent from './components/TerminalComponent';


function CodeEditor() {
    let dispatch = useDispatch()
    const [btnState, setBtnState] = React.useState(true);
    const onClickHandler = (e: any) => {
        setBtnState(e.target.checked)
    }
    useEffect(() => {
        let _payload = {
            "projectId": 1000,
            "parentFolderId": 1,
            "id": 0,
            "name": "module-01",
            "action": "create"
        }
        // dispatch(createFolder(_payload))
        dispatch(getAllModules())
    }, [])

    const onClickHandler1 = () => {
        // update main folder
        // let payload = {
        //     "projectId": 1000,
        //     "parentFolderId": 1,
        //     "parentFolder": "module-01",
        //     "id": 0,
        //     "name": "module-01",
        //     "toName": "module-001",
        //     "action": "update"
        // }
        // dispatch(updateFolder(payload))
        // create sub folder
        let _payload = {
            "projectId": 1000,
            "parentFolderId": 1,
            "parentFolder": "module-001",
            "id": 0,
            "name": "module-001-1-1",
            "action": "create"
        }
        dispatch(createSubFolder(_payload))
    }
    return (
        <React.Fragment>
            <div className='l-and-d-mode'><span>Light Mode </span><Switch onClick={onClickHandler} defaultChecked /><span>Dark Mode </span></div>
            <div className='codeEditor-main card'>
                <div style={{ width: "100%", display: "flex" }}>
                    <FilesManager btnState={btnState} />
                    <EditorModule btnState={btnState} />
                </div>
                <TerminalComponent /> 
            </div>
        </React.Fragment>
    )
}

export default CodeEditor;