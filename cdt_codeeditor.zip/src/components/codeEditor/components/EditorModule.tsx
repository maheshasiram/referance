import React, { useRef, useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import Editor, { DiffEditor, useMonaco, loader } from '@monaco-editor/react';
import ClearIcon from '@mui/icons-material/Clear';
import _ from 'lodash';
import { useDispatch } from 'react-redux';
import { Types } from '../reducer/types';
import { executeModule, getAllModules, runModule, updateFile } from '../actions/actions';
import OpenedFiles from './OpenedFiles';

function EditorModule(props: any) {
    const { btnState } = props;

    const { openedFiles, code, selectedNode } = useSelector((state: any) => state.codeEditor);
    const dispatch = useDispatch();
    // const [code, setCode] = useState('')
    const monacoRef = useRef(null);

    const onCloseFile = (item: any, index: any) => {
        let _openedFiles = _.cloneDeep(openedFiles);
        _openedFiles.splice(index, 1);
        if (_openedFiles.length > 0) {
            _openedFiles[index - 1].active = true;
        }
        dispatch({ type: Types.OPENED_FILES, payload: _openedFiles });
    }

    const onSelectTab = (index: any) => {
        let _openedFiles = _.cloneDeep(openedFiles);
        _openedFiles.map((item: any, itmIndex: any) => {
            if (index === itmIndex) {
                _openedFiles[itmIndex].active = true;
            } else {
                _openedFiles[itmIndex].active = false;
            }
        })
        // let _filePath = e.node.parentPath.replace('/', '%2F')
        //     dispatch(readFile(e.node.name, _filePath));
        dispatch({ type: Types.OPENED_FILES, payload: _openedFiles });
        // dispatch({type: Types.GET_SELECTED_NODE, payload : e.node})
    }
    const onCodeChangeHandler = (value: any, event: any) => {
        // let _value = JSON.stringify(value)
        // var bodyFormData = new FormData();
        // // bodyFormData.append('codeValue', _value);
        // bodyFormData.append('userName', 'Fred');
        // console.log('event...........', value)
        // setCode(value)
        dispatch({ type: Types.GET_CODE, payload: value });

    }
    const onClickHandler = () => {
        var _data = new FormData();
        const _blob = new Blob([code], { type: 'application/octet-stream' })
        _data.append('data', _blob, 'code.r');
        dispatch(executeModule(_data))

        // run moduleee

    }
    const readFile = () => {
        dispatch(runModule((data: any) => {
            // setCode(data)
        }))

    }
    const handleEditorWillMount = (monaco: any) => {
        // here is the monaco instance
        // do something before editor is mounted
        monaco.languages.typescript.javascriptDefaults.setEagerModelSync(true);
    }

    const handleEditorDidMount = (editor: any, monaco: any) => {
        // here is another way to get monaco instance
        // you can also store it in `useRef` for further usage
        monacoRef.current = monaco;
    }
    function handleEditorValidation(markers: any) {
        // model markers

        markers.forEach((marker: any) => console.log('onValidate:', marker.message));
    }
    const onSaveCodeHandler = () => {
        console.log('selectedNode.....', selectedNode);
        if (selectedNode) {
            var _data = new FormData();
            const _blob = new Blob([code], { type: 'application/octet-stream' })
            _data.append('data', _blob, selectedNode.name);
            let fileDetails = {
                name: selectedNode.name,
                _filePath: selectedNode.parentPath.replace('/', '%2F')
            }
            dispatch(updateFile(fileDetails, _data, (response: any) => {
                // console.log('')
                // onSelcetNode({ node: node })
                dispatch(getAllModules())
            }))
        }
    }
    return (
        <div className='opened-files'>
            {/* <div className='header'> */}
            <div className={btnState ? 'header dark-header' : 'header light-header'}>
                {/* <nav>
                    <div className="nav nav-tabs" id="nav-tab" role="tablist">
                        {openedFiles.length > 0 &&
                            openedFiles?.map((item: any, index: any) =>
                                <button className={`nav-link ${item.active ? 'active showIcon' : 'hideIcon'}`} id="file2" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="false"> <label onClick={() => onSelectTab(index)}>{item.name} </label>
                                    <ClearIcon sx={{ opacity: 0.8, fontSize: '15px', color: '#ffff' }} onClick={() => { onCloseFile(item, index) }} />
                                </button>
                            )}
                    </div>
                </nav> */}
                <div> <OpenedFiles /> </div>
                <div className='d-flex' >
                    <div className='runCodebtn' onClick={onSaveCodeHandler} ><span><i className='pi pi-save' style={{ color: '#ffff' }}>save</i></span> </div>
                    <div className='runCodebtn'><span><i className='pi pi-caret-right' style={{ color: '#ffff' }}>Run</i></span> </div>
                </div>
            </div>
            {/* <Editor
                height="90vh"
                defaultLanguage="r"
                // theme="vs-light"
                theme={btnState ? 'vs-dark' : 'vs-light'}
                defaultValue="// some comment"
                beforeMount={handleEditorWillMount}
                onMount={handleEditorDidMount}
            /> */}
            <div className="overlay rounded-md overflow-hidden w-full h-full shadow-4xl">
                <Editor
                    height="85vh"
                    width={`100%`}
                    defaultLanguage="r"
                    theme={btnState ? 'vs-dark' : 'vs-light'}
                    // defaultValue="// some comment"
                    value={code}
                    onChange={onCodeChangeHandler}
                    onValidate={handleEditorValidation}
                />
            </div>
        </div>
    )
}
export default EditorModule;