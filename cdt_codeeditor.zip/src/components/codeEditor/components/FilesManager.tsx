import React, { useState, useEffect } from 'react';
import NoteAddOutlinedIcon from '@mui/icons-material/NoteAddOutlined';
import CreateNewFolderOutlinedIcon from '@mui/icons-material/CreateNewFolderOutlined';
import CustomToolTip from '../../../common/CustomToolTip';
import { Tree } from 'primereact/tree';
import { classNames } from 'primereact/utils';
import '../styles.scss';
import { fileManagerFiles } from '../../../constants/fileManagerFiles';
import { useSelector } from 'react-redux';
import _ from 'lodash';
import { useDispatch } from 'react-redux';
import { Types } from '../reducer/types';
import { getAllModules, readFile, renameFile, writeNewFile } from '../actions/actions';

function FilesManager(props: any) {
    const [nodes, setNodes] = useState<any>(fileManagerFiles);
    const [selectedKey, setSelectedKey] = useState<string>('');
    const [editFileData, setEditFileData] = useState<any>(null)
    const { allFilesList, openedFiles, selectedNode } = useSelector((state: any) => state.codeEditor);
    const [renameValue, setRenameValue] = useState('')
    const dispatch = useDispatch();
    const [expandedKeys, setExpandedKeys] = useState({});

    const onChangeFileName = (event: any, node: any) => {
        setRenameValue(event.target.value)
    }
    useEffect(() => {
        if (openedFiles?.length > 0) {
            openedFiles.map((item: any) => {
                if (item.active) {
                    // let _filePath = item.parentPath.replace('/', '%2F')
                    // dispatch(readFile(item.name, _filePath))
                    setSelectedKey(item.key)
                    dispatch({ type: Types.GET_SELECTED_NODE, payload: item })
                }
            })
        } else {
            setSelectedKey('')
            dispatch({ type: Types.GET_SELECTED_NODE, payload: null })
        }
    }, [openedFiles])
    const onSelcetNode = (e: any) => {
        if (e.node.type == "folder") {
            if (e.node.key in expandedKeys) {
                let _expandedKeys: any = { ...{}, ...expandedKeys }
                delete _expandedKeys[e.node.key]
                setExpandedKeys(_expandedKeys)
            } else {
                setExpandedKeys({ ...expandedKeys, [e.node.key]: true })
            }
        }
        let _openedFiles = _.cloneDeep(openedFiles);
        if (e.node.type === 'file') {
            if (_openedFiles.findIndex((item: any) => item.key === e.node.key) === -1) {
                _openedFiles.push(e.node)
            }
            _openedFiles.map((item: any, index: any) => {
                if (item.key === e.node.key) {
                    _openedFiles[index].active = true;
                } else {
                    _openedFiles[index].active = false;
                }
            })


            // let _path = e.node.path
            // let _filePath = e.node.parentPath.replace('/', '%2F')
            // dispatch(readFile(e.node.name, _filePath))
        }
        dispatch({ type: Types.OPENED_FILES, payload: _openedFiles });
        dispatch({ type: Types.GET_SELECTED_NODE, payload: e.node })
    }
    const onKeyDownHandler = (event: any, node: any) => {
        if (event.key == 'Enter') {
            // if (renameValue && renameValue != '') {
            //     setEditFileData(null)
            //     node.name = renameValue
            //     node.key = node.parentPath + '/' + renameValue

            //     var _data = new FormData();
            //     const _blob = new Blob(['# Start coding from here'], { type: 'application/octet-stream' })
            //     _data.append('data', _blob, renameValue);
            //     let fileDetails = {
            //         name: node.name,
            //         _filePath: node.parentPath.replace('/', '%2F')
            //     }
            //     dispatch(writeNewFile(fileDetails, _data, (response: any) => {
            //         // console.log('')
            //         // onSelcetNode({ node: node })
            //         dispatch(getAllModules())
            //     }))
            // }
            onSubmitRename(node)
        }
    }
    const onCancelRename = (node: any, options: any) => {
        if (node.id != '') {
            setEditFileData(null)
        } else {
            options?.props?.parent?.children.splice(options.props.index, 1)
            setEditFileData(null)
        }
    }
    const onSubmitRename = (node: any) => {
        if (renameValue && renameValue != '') {
            if (node.id != '') {
                let fileDetails = {
                    name: node.name,
                    toName: renameValue,
                    path: node.parentPath
                }
                dispatch(renameFile(fileDetails))
                setEditFileData(null)
            } else {
                node.name = renameValue
                node.key = node.parentPath + '/' + renameValue
                // onSelcetNode({ node: node })
                var _data = new FormData();
                const _blob = new Blob(['# Start coding from here'], { type: 'application/octet-stream' })
                _data.append('data', _blob, renameValue);
                let fileDetails = {
                    name: node.name,
                    _filePath: node.parentPath.replace('/', '%2F')
                }
                dispatch(writeNewFile(fileDetails, _data, (response: any) => {
                    // console.log('')
                    // onSelcetNode({ node: node })
                    dispatch(getAllModules())
                }))
            }
        }
    }
    const nodeTemplate = (node: any, options: any) => {
        // console.log('options......', node, options)
        let _classname = node.type == "folder" ? options.expanded ? 'pi pi-folder-open' : 'pi pi-folder' : 'pi pi-file'
        return <div className='fileName-cotainer' >
            <div className='d-flex align-items-center'>
                <span className={_classname}></span>
                {(editFileData && (editFileData.key == node.key)) ?
                    <input type='text' autoFocus
                        defaultValue={editFileData.name}
                        onChange={(e: any) => onChangeFileName(e, node)}
                        onKeyDown={(e: any) => onKeyDownHandler(e, node)}
                    /> : <span className='ps-1'>{node.name}</span>
                }
            </div>
            {(editFileData && (editFileData.key == node.key)) ?
                <div className='d-flex' >
                    <span className='pi pi-times px-1'
                        onClick={() => onCancelRename(node, options)}
                    ></span>
                    <span className='pi pi-check px-1'
                        // onClick={() => {
                        //     if (renameValue && renameValue != '') {
                        //         setEditFileData(null)
                        //         node.name = renameValue
                        //         node.key = node.parentPath + '/' + renameValue
                        //         onSelcetNode({ node: node })
                        //     }
                        // }}
                        onClick={() => onSubmitRename(node)}
                    ></span>
                </div>
                :
                <div className='file-action-icons' >
                    {node.type == "folder" && <span>
                        <CustomToolTip title='Add file'>
                            <NoteAddOutlinedIcon sx={{ height: '18px' }} onClick={() => addNewFileHandler(node, options)} />
                        </CustomToolTip>
                    </span>}
                    <span className='pi pi-pencil edit-icon px-1'
                        onClick={() => {
                            setEditFileData(node)
                            setRenameValue(node.name)
                        }}
                    ></span>
                    <span className='pi pi-trash delete-icon px-1' onClick={() => onDeleteFileFolder(node)} ></span>
                </div>
            }
        </div>
    }
    const addNewFileHandler = (node: any, options: any) => {
        let _obj = {
            "key": '',
            "id": '',
            "name": "",
            "type": "file",
            "active": false,
            "code": "come file-1 code",
            "parentPath": node.parentPath + '/' + node.name
        }
        // _allFilesList.filemanager.push(_obj)
        setEditFileData(_obj)
        setRenameValue(_obj.name)
        // node.children.push(_obj)
        node.children.splice(0, 0, _obj);
    }
    const onDeleteFileFolder = (node: any) => {
        let _allFilesList = _.cloneDeep(allFilesList)

    }
    const togglerTemplate = (node: any, options: any) => {
        if (!node) {
            return;
        }

        const expanded = options.expanded;
        const iconClassName = classNames('p-tree-toggler-icon pi pi-fw', {
            'pi-caret-right': !expanded,
            'pi-caret-down': expanded
        });

        return (
            <button type="button" className="p-tree-toggler p-link" tabIndex={-1} onClick={options.onClick}>
                <span className={iconClassName} aria-hidden="true"></span>
            </button>
        );
    };
    const addNewFile = () => {
        // console.log(selectedNode)
        if (!selectedNode) {
            alert('test')
            let _allFilesList: any = _.cloneDeep(allFilesList)
            let _obj = {
                "key": `${allFilesList.filemanager.length + 1}`,
                "id": `${allFilesList.filemanager.length + 1}`,
                "label": "",
                "type": "file",
                "active": false,
                "code": "come file-1 code"
            }
            _allFilesList.filemanager.push(_obj)
            // setEditFileData(_obj)
            // setRenameValue(_obj.label)
            // dispatch({ type: Types.GET_ALL_FOLDERS_LIST, payload: _allFilesList })



            // 
            insertNewFolder(allFilesList.children, allFilesList)


        }
        var _data = new FormData();
        const _blob = new Blob([''], { type: 'application/octet-stream' })
        _data.append('data', _blob, 'code.r');
        // dispatch(executeModule(_data))

    }
    const insertNewFolder = async (element: any, parent: any) => {
        element.map(async (ele: any, index: any) => {
            // ele.key = ele.path
            // ele.leaf = ele.type == "folder" ? false : true
            // ele.parentPath = parent.parentPath ? parent.parentPath + '/' + parent.name : parent.name

            if (ele.children) {
                await insertNewFolder(ele.children, ele)
            }
        })
    }

    const onAddNewFolder = () => {
        if (!selectedKey) {
            let _allFilesList: any = _.cloneDeep(allFilesList)
            let _obj = {
                "key": `${allFilesList.filemanager.length + 1}`,
                "id": `${allFilesList.filemanager.length + 1}`,
                "label": "",
                "type": "folder",
                "active": false,
                "code": "come file-1 code",
                "children": [],
                "leaf": false
            }
            _allFilesList.filemanager.push(_obj)
            setEditFileData(_obj)
            setRenameValue(_obj.label)
            dispatch({ type: Types.GET_ALL_FOLDERS_LIST, payload: _allFilesList })
        }
    }
    return (
        <div style={{ width: "35%" }}>
            <div className='projectName d-flex justify-content-between' >
                <label>{allFilesList.name}</label>
                <div className='d-flex'>
                    <CustomToolTip title='Add file'>
                        <NoteAddOutlinedIcon sx={{ height: '18px' }} onClick={addNewFile} />
                    </CustomToolTip>
                    <CustomToolTip title='Add Folder'>
                        <CreateNewFolderOutlinedIcon sx={{ height: '24px' }} onClick={() => onAddNewFolder()} />
                    </CustomToolTip>
                </div>
            </div>
            <div className="flex justify-content-center treeView-omponent">
                {allFilesList && <Tree value={allFilesList.children}
                    selectionMode="single"
                    selectionKeys={selectedKey}
                    onSelectionChange={(e: any) => {
                        // console.log('e........', e.value, e)
                        setSelectedKey(e.value)
                        if (editFileData && editFileData.key != e.value) {
                            setEditFileData(null)
                        }
                    }}
                    onSelect={onSelcetNode}
                    nodeTemplate={nodeTemplate}
                    togglerTemplate={togglerTemplate}
                    className="w-full md:w-30rem p-0"
                    expandedKeys={expandedKeys}
                    onToggle={(e: any) => {
                        setExpandedKeys(e.value)
                    }}
                />}
            </div>
        </div>
    )
}
export default FilesManager