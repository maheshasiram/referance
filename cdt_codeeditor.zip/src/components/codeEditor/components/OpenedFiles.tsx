import React, { useEffect } from "react";
import { useSelector } from "react-redux";
import ClearIcon from '@mui/icons-material/Clear';
import { useDispatch } from "react-redux";
import { Types } from "../reducer/types";
import _ from "lodash";
import { readFile } from "../actions/actions";

function OpenedFiles(props: any) {
    const dispatch = useDispatch();
    const { openedFiles } = useSelector((state: any) => state.codeEditor);
    useEffect(() => {
        if (openedFiles?.length>0) {
            openedFiles.map((item: any) => {
                if (item.active) {
                    let _filePath = item.parentPath.replace('/', '%2F')
                    dispatch(readFile(item.name, _filePath))
                }
            })
        }
    }, [openedFiles])

    const onSelectTab = (index: any) => {
        let _openedFiles = _.cloneDeep(openedFiles);
        _openedFiles.map((item: any, itmIndex: any) => {
            if (index === itmIndex) {
                _openedFiles[itmIndex].active = true;
            } else {
                _openedFiles[itmIndex].active = false;
            }
        })
        dispatch({ type: Types.OPENED_FILES, payload: _openedFiles });
    }
    const onCloseFile = (item: any, index: any) => {
        let _openedFiles = _.cloneDeep(openedFiles);
        _openedFiles.splice(index, 1);
        // console.log('item......', item.active)
        if (_openedFiles.length > 0 && item.active) {
            // alert('test')
            if (index != 0) {
                _openedFiles[index - 1].active = true;
            } else {
                _openedFiles[0].active = true;
            }
        }
        if(_openedFiles.length == 0){
            dispatch({type: Types.GET_CODE, payload: ''})
        }
        dispatch({ type: Types.OPENED_FILES, payload: _openedFiles });
    }
    // console.log('openedFiles....', openedFiles)
    return <div>
        <div className="nav " id="nav-tab" role="tablist">
            {openedFiles.length > 0 &&
                openedFiles?.map((item: any, index: any) =>
                    <button className={`nav-link ${item.active ? 'active showIcon' : 'hideIcon'}`}
                        id="file2" data-bs-toggle="tab" data-bs-target="#nav-profile"
                        type="button" role="tab" aria-controls="nav-profile"
                        aria-selected="false">
                        <label className={item.active ? 'text-primary' : 'text-white'} onClick={() => onSelectTab(index)}>{item.name} </label>
                        <ClearIcon sx={{ opacity: 0.8, fontSize: '15px', color: '#ffff' }}
                            onClick={() => {
                                onCloseFile(item, index)
                            }}
                        />
                    </button>
                )}
        </div>
    </div>
}
export default OpenedFiles