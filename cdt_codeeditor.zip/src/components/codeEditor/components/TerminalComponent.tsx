import React from "react";
import { Terminal } from "xterm";
import 'xterm/css/xterm.css'
function TerminalComponent(props: any) {

    const terminalref = React.useRef<any>(null)
    const [value, setValue] = React.useState('Hello, xtstf\n\r')
    React.useEffect(() => {
        const terminal = new Terminal({
            cursorBlink: true,
            fontFamily: 'monospace',
            fontSize: 14,
        })
        terminal.open(terminalref.current)
        terminal.write(value)
        // terminal.onData((data: any) => {
        //     setValue(value + data)
        // })

        return () => {
            terminal.dispose()
        }

    }, [])

    return (
        <div ref={terminalref} ></div>
    )
}
export default TerminalComponent