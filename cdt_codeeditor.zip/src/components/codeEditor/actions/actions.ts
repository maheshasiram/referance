import { Loader } from "../../../actions/actions";
import { requests } from "../../../configs/environment/env";
import { fetch } from "../../../constants/fetch";
import { Types } from "../reducer/types";

// export const fetchAllOpendedFiles: any = (payload: any) => {
//     return function (dispatch: any) {

//     //     fetch({
//     //         method: 'GET',
//     //         url: requests,
//     //         data: ''
//     //     })
//     //         .then((response: any) => {

//     //         })
//     //         .catch((err: any) => {
//     //             console.log("..err", err);
//     //         })
//     // }
// }

export const createFolder: any = (payload: any) => {
    return function (dispatch: any) {

        fetch({
            method: 'POST',
            url: `http://10.22.242.67:8080/api/folder/create`,
            data: payload
        })
            .then((response: any) => {
                console.log('response create.....', response)
            })
            .catch((err: any) => {
                console.log("..err", err);
            })
    }
}

export const updateFolder: any = (payload: any) => {
    return function (dispatch: any) {

        fetch({
            method: 'POST',
            url: `http://10.22.242.67:8080/api/folder/update`,
            data: payload
        })
            .then((response: any) => {
                console.log('response update.....', response)
            })
            .catch((err: any) => {
                console.log("..err", err);
            })
    }
}

export const createSubFolder: any = (payload: any) => {
    return function (dispatch: any) {

        fetch({
            method: 'POST',
            url: `http://10.22.242.67:8080/api/folder/createSubFolder`,
            data: payload
        })
            .then((response: any) => {
                console.log('response create sub folder.....', response)
            })
            .catch((err: any) => {
                console.log("..err", err);
            })
    }
}

export const fetchAllFolders: any = () => {
    return function (dispatch: any) {
        fetch({
            method: "GET",
            url: 'http://10.22.243.26:8899/api/folder/fetchAllFolders?projectId=2',
            data: ''
        })
            .then((response: any) => {
                console.log('response......', response)
            }).catch((error: any) => {
                console.log('error.........', error)
            })
    }
}


export const executeModule: any = (formData: any) => {
    return function (dispatch: any) {
        fetch({
            method: "POST",
            url: 'http://10.22.243.26:8899/api/folder/writeFile?fileName=script04.r&path=module-01&projectId=2',
            data: formData,
            headers: {
                "Accept": "*/*",
                "Content-Type": "multipart/form-data"
            }
        })
            .then((response: any) => {
                console.log('response......', response)
            }).catch((error: any) => {
                console.log('error.........', error)
            })
    }
}

export const runModule: any = (callback: any) => {
    return function (dispatch: any) {
        fetch({
            method: "GET",
            url: 'http://10.22.243.26:8899/api/folder/readFile?fileName=script04.r&path=module-01&projectId=2',
            data: '',
            headers: {
                "Accept": "*/*",
                "Content-Type": "application/octet-stream"
            }
        })
            .then((response: any) => {
                console.log('response......', response)
                callback(response.data)
            }).catch((error: any) => {
                console.log('error.........', error)
            })
    }
}

export const getAllModules: any = () => {
    return function (dispatch: any) {
        fetch({
            method: "GET",
            url: requests.codeEditor.getAllModules,
            data: '',
            // headers: {
            //     "Accept": "*/*",
            //     "Content-Type": "application/octet-stream"
            // }
        })
            .then(async (response: any) => {
                // await response.data.map(async (ele: any) => {
                if (response.data.children) {
                    response.data.parentPath = ''
                    await generateDynamicFolderId(response.data.children, response.data)
                }
                // })
                console.log('response get all mod.......', response.data)
                dispatch({ type: Types.GET_ALL_FOLDERS_LIST, payload: response.data })
            })
    }
}

const generateDynamicFolderId = async (element: any, parent: any) => {
    element.map(async (ele: any, index: any) => {
        ele.leaf = ele.type == "folder" ? false : true
        ele.parentPath = parent.parentPath ? parent.parentPath + '/' + parent.name : parent.name
        ele.key = ele.parentPath + '/' + ele.name
        if (ele.children) {
            await generateDynamicFolderId(ele.children, ele)
        }
    })
}

export const readFile: any = (fileName: any, pathName: any) => {
    return function (dispatch: any) {
        fetch({
            method: 'GET',
            url: `${requests.codeEditor.readFile}?fileName=${fileName}&filePath=${pathName}`,
            data: '',
            headers: {
                "Accept": "*/*",
                "Content-Type": "application/octet-stream"
            }
        })
            .then((response: any) => {
                console.log('resposne read file......', response)
                if (response.data) {
                    dispatch({ type: Types.GET_CODE, payload: response.data })
                }
            })
            .catch((error: any) => {

            })
    }
}

export const writeNewFile: any = (fileDetails: any, data: any, callback: any) => {
    return function (dispatch: any) {
        fetch({
            method: 'POST',
            url: `${requests.codeEditor.writeFile}?fileName=${fileDetails.name}&filePath=${fileDetails._filePath}`,
            data: data,
            headers: {
                "Accept": "*/*",
                "Content-Type": "multipart/form-data"
            }
        })
            .then((response: any) => {
                console.log('resposne read file......', response)
                if (callback) {
                    callback(response.data)
                }
            })
            .catch((error: any) => {

            })
    }
}

export const renameFile: any = (fileDetails: any, callback: any) => {
    return function (dispatch: any) {
        fetch({
            method: 'GET',
            url: `${requests.codeEditor.renameFile}?fileName=${fileDetails.name}&fileNameTo=${fileDetails.toName}&filePath=${fileDetails.path}`,
            data: '',
            // headers: {
            //     "Accept": "*/*",
            //     "Content-Type": "multipart/form-data"
            // }
        })
            .then((response: any) => {
                console.log('resposne read file......', response)
                dispatch(getAllModules())
                if (callback) {
                    callback(response.data)
                }
            })
            .catch((error: any) => {

            })
    }
}

export const updateFile: any = (fileDetails: any, data: any, callback: any) => {
    return function (dispatch: any) {
        fetch({
            method: 'POST',
            url: `${requests.codeEditor.updateFile}?fileName=${fileDetails.name}&filePath=${fileDetails._filePath}`,
            data: data,
            headers: {
                "Accept": "*/*",
                "Content-Type": "multipart/form-data"
            }
        })
            .then((response: any) => {
                console.log('resposne read file......', response)
                if (callback) {
                    callback(response.data)
                }
            })
            .catch((error: any) => {

            })
    }
}