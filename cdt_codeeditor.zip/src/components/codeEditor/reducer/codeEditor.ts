// import { moduleTypes } from "./types"

import { fileManagerFiles } from "../../../constants/fileManagerFiles"
import { Types } from "./types"

const initialState = {
    allFilesList: fileManagerFiles,
    openedFiles: [],
    code: '',
    selectedNode: null,
}
export const codeEditor = (state = initialState, action: { type: any, payload: any }) => {
    switch (action.type) {
        case Types.GET_ALL_FOLDERS_LIST:
            return { ...state, allFilesList: action.payload }
        case Types.OPENED_FILES:
            return { ...state, openedFiles: action.payload }
        case Types.GET_CODE:
            return { ...state, code: action.payload }
        case Types.GET_SELECTED_NODE:
            return { ...state, selectedNode: action.payload }
        default:
            return { ...state }
    }
}
