import { moduleTypes } from "./types"

const initialState = {
    modulesData: null,
    moduleParams: {
        "input": {
            "pth": "modules",
            "name": null,
            "status": "Development",
            "type": null,
            "TA": null,
            "domain": null,
            "indication": null,
            "keywords": null,
            "version": "latest"
        }
    },
    Parametrization: null,
    selectedModule: null,
}
export const modules = (state = initialState, action: { type: any, payload: any }) => {
    switch (action.type) {
        case moduleTypes.GET_ALL_MODULES:
            return { ...state, modulesData: action.payload }
        case moduleTypes.GET_MODULE_PARAMS:
            return { ...state, Parametrization: action.payload }
        case moduleTypes.SELECTED_MODULE:
            return { ...state, selectedModule: action.payload }
        default:
            return { ...state }
    }
}
