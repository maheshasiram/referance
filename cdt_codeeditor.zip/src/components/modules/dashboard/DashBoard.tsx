import React, { useState, useEffect } from 'react';
import CommonCard from '../../../common/CommonCard';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { InputText } from 'primereact/inputtext';
import { useSelector } from 'react-redux';
import { useDispatch } from 'react-redux';
import { getModuleParams } from '../actions/actions';
import CreateModule from '../Parametrization/CreateModule';
import { moduleTypes } from '../reducer/types';

interface Product {
  id: string;
  code: string;
  name: string;
  description: string;
  core: string,
  indication: string,
  Domian: string,
  status: string
}

function DashBoard(props: any) {
  let dispatch = useDispatch()
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [rowClick, setRowClick] = useState<boolean>(true);
  const [globalFilterValue, setGlobalFilterValue] = useState<string>('');
  const { moduleParams, modulesData } = useSelector((state: any) => state.modules)
  useEffect(() => {
    if (modulesData) {
      setSelectedProduct(modulesData[0])
    }
  }, [modulesData])
  const representativeRowFilterTemplate = (type: string) => {
    return (
      <span className="p-input-icon-left">
        <i className="pi pi-search" />
        <InputText placeholder={'search'} />
      </span>
    );
  };

  const statusBodyTemplate = (rowData: any) => {
    return (
      <span>{rowData?.Status}</span>
    );
  };

  const domainBodyTemplate = (rowData: any) => {
    return (
      <span>{rowData?.Domain}</span>
    );
  };

  const indicationBodyTemplate = (rowData: any) => {
    return (
      <span>{rowData?.Indication}</span>
    );
  };

  const coreBodyTemplate = (rowData: any) => {
    return (
      <span>{rowData?.core}</span>
    );
  };

  const descriptionBodyTemplate = (rowData: any) => {
    return (
      <span>{rowData?.Description}</span>
    );
  };

  const nameBodyTemplate = (rowData: any) => {
    return (
      <span>{rowData?.Name}</span>
    );
  };


  return (
    <CommonCard title={<div className='d-flex justify-content-between align-items-center'><span>List Of Modules</span>  </div>}>
      {/* <CommonCard title={<div className='d-flex justify-content-between align-items-center'><span>List Of Modules</span> <CreateModule /> </div>}> */}
      <React.Fragment>
        {modulesData && <DataTable value={modulesData}
          paginator
          rows={5}
          selectionMode={rowClick ? undefined : 'radiobutton'}
          selection={selectedProduct!}
          onSelectionChange={(e: any) => {
            const value = e.value as any;
            setSelectedProduct(value);
            console.log('value......', value)
            if (value) {
              dispatch({ type: moduleTypes.SELECTED_MODULE, payload: value })
              dispatch(getModuleParams({ "input": { "location": value.LocalPath } }, (response: any) => {
                const element = document.getElementById("parametrization-main") as HTMLElement
                element.scrollIntoView({ behavior: "smooth", block: "start", inline: "start" });
              }))

            }
          }}
          dataKey="RemotePath" tableStyle={{ minWidth: '50rem' }}
          emptyMessage="No customers found."
        // filterDisplay="row"

        >
          <Column selectionMode="single" headerStyle={{ width: '1rem' }}></Column>
          <Column filterField="Name" header="Name" showFilterMenu={false} body={nameBodyTemplate}
            filter filterElement={representativeRowFilterTemplate('name')} ></Column>
          <Column field='Version' header='Version' ></Column>
          <Column filterField="description" header="Description" showFilterMenu={false} body={descriptionBodyTemplate}
            filter filterElement={representativeRowFilterTemplate('description')} ></Column>
          <Column field='Type' header='Type' ></Column>
          <Column field='TA' header='TA' ></Column>
          {/* <Column filterField="core" header="core" showFilterMenu={false} body={coreBodyTemplate}
            filter filterElement={representativeRowFilterTemplate('core')} ></Column> */}
          <Column filterField="indication" header="Indication" showFilterMenu={false} body={indicationBodyTemplate}
            filter filterElement={representativeRowFilterTemplate('indication')}></Column>
          <Column filterField="Domian" header="Domian" showFilterMenu={false}
            body={domainBodyTemplate} filter filterElement={representativeRowFilterTemplate('domian')}></Column>
          <Column header="Status" filterField="status" showFilterMenu={false}
            body={statusBodyTemplate} filter filterElement={representativeRowFilterTemplate('status')} />
          <Column field='ADaMIG' header='ADaMIG' ></Column>
          <Column field='Keywords' header='Keywords' ></Column>
        </DataTable>}
      </React.Fragment>
    </CommonCard>
  )
}
export default DashBoard;