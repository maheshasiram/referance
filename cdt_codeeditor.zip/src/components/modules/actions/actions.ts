import { Loader, toastAlert } from "../../../actions/actions";
import { requests } from "../../../configs/environment/env";
import { fetch } from "../../../constants/fetch";
import { moduleTypes } from "../reducer/types";

export const fetchAllModules: any = (payload: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'POST',
            url: requests.module.findModules,
            data: payload
        })
            .then((response: any) => {
                console.log('response.......', response)
                if (response.data) {
                    dispatch({ type: moduleTypes.SELECTED_MODULE, payload: response.data[0] })
                    dispatch(getModuleParams({
                        "input": {
                            "location": response.data[0].LocalPath
                        }
                    }))
                    dispatch({ type: moduleTypes.GET_ALL_MODULES, payload: response.data })
                }
                // dispatch(Loader(false));

            })
            .catch((err: any) => {

            })
    }
}


export const getModuleParams: any = (payload: any, callback: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'POST',
            url: requests.module.fetchModuleParams,
            data: payload
        })
            .then((response: any) => {
                console.log('params response.......', response)
                if (response?.data) {
                    response.data.title_vector = response.data.title_vector[0]
                    response.data.footnote_vector = response.data.footnote_vector[0]
                    // response.data.path = response.data.path[0]
                }
                dispatch({ type: moduleTypes.GET_MODULE_PARAMS, payload: response.data })
                if (callback) {
                    callback(response.data)
                }
                dispatch(Loader(false));
            })
            .catch((err: any) => {
                dispatch(Loader(false));
                dispatch(toastAlert({ status: 0, message: 'Error fetching params', open: true }))
            })
    }
}

export const createModule: any = (payload: any, callback: any) => {
    return function (dispatch: any) {
        dispatch(Loader(true));
        fetch({
            method: 'PUT',
            url: requests.module.createModule,
            data: payload
        })
            .then((response: any) => {
                console.log('create response.......', response)
                dispatch(Loader(false));
                if (callback) {
                    callback(response.data)
                }
            })
            .catch((err: any) => {

            })
    }
}

export const runModule: any = (payload: any) => {
    return function (dispatch: any) {
        fetch({
            method: 'POST',
            url: requests.module.runModule,
            data: payload,
            responseType: 'blob'
        }).then((response: any) => {
            console.log("response in action for generate pdf", response, payload)
            const url = window.URL.createObjectURL(new Blob([response.data]));
            const link = document.createElement('a');
            link.href = url;
            // link.setAttribute('download', 'testfile.pdf');
            link.setAttribute('download', `${payload.input.prog_name}.rtf`);
            // link.download = `naaistam.rtf`
            document.body.appendChild(link);
            link.click();

        })
    }
}