import React, { useState } from 'react';
import CustomDialog from '../../../common/modals/CustomeDialog';
import { handleClose } from '../../../actions/actions';
import { useSelector } from 'react-redux';
import Button from '@mui/material/Button';
import './Styles.scss'

function Preview(props: any) {
  const [open, setOpen] = useState(false);
  const { openPreview, setOpenPreview } = props

  const onDevelopTLF = () => {
    setOpen(true);
  }

  return (
    <div className='preview-main'>
      <div className='d-flex'>
        <Button variant="outlined" className='me-2'>SAVE DRAFT</Button>

        <Button type='submit' form='ParametrizationForm' variant="contained" disableElevation
        // onClick={() => onDevelopTLF()} 
        > CREATE TLF </Button>
      </div>
      <CustomDialog
        title={'Preview'}
        open={openPreview}
        onClose={() => handleClose(setOpenPreview)}
        maxWidth={'md'}
        fullWidth={true}
        actionType={'Submit'}
        form={'preView'}
        padding={true}
      >
        <div className='mainContainer'>
          <div className='Table-1'>
            <p className='mainHeading text-center m-0 p-0'>Table 14-2.2.1.2.  Baseline Demographics</p>
            <p className='subHeading text-center  p-0'>(Safety Analysis Set) </p>
            <table className='table table-bordered'>
              <thead>
                <tr>
                  <th scope="col"></th>
                  <th scope="col"> Cohort 1 <br />0.001mg<br />QW<br />(N=16)<br />n(%)</th>
                  <th scope="col">Cohort 2<br />0.003mg<br />QW<br />(N=16)<br />n(%)</th>
                  <th scope="col">Cohort 3<br />0.001mg<br />QW<br />(N=17)<br />n(%)</th>
                  <th scope="col">Cohort 4<br />0.003 mg<br />QW<br />(N=14)<br />n(%)</th>
                </tr>
              </thead>
              <tbody>

                <tr>
                  <td >
                    <p className="SectionHeading">Sex - n(%)</p>
                    <p>Male</p>
                    <p>Female</p>
                  </td>
                  <td scope='row'>
                    <p className="SectionHeading"></p>
                    <p>9 ( 56.2)	</p>
                    <p>7 ( 43.8)	</p>
                  </td>
                  <td scope='row'>
                    <p className="SectionHeading"></p>
                    <p>8 ( 50.0)</p>
                    <p>8 ( 50.0)	</p>
                  </td>
                  <td scope='row'>
                    <p className="SectionHeading"></p>
                    <p> 9 ( 52.9)	</p>
                    <p> 8 ( 47.1)</p>
                  </td>
                  <td scope='row'>
                    <p className="SectionHeading"></p>
                    <p>9 ( 64.3)	</p>
                    <p>5 ( 35.7)	</p>
                  </td>
                </tr>
                <tr>
                  <td >

                    <p className="SectionHeading">Ethnicity - n(%)</p>
                    <p>Hispanic or Latino</p>
                    <p>Not Hispanic or Latino</p>
                    <p>Unknown</p>

                  </td>
                  <td scope='row' >
                    <p className="SectionHeading"></p>
                    <p>9 ( 56.2)	</p>
                    <p>7 ( 43.8)	</p>
                    <p>7 ( 43.8)	</p>
                  </td>
                  <td scope='row' >
                    <p className="SectionHeading"></p>
                    <p>9 ( 56.2)	</p>
                    <p>7 ( 43.8)	</p>
                    <p>7 ( 43.8)	</p>
                  </td>
                  <td scope='row' >
                    <p className="SectionHeading"></p>
                    <p>9 ( 56.2)	</p>
                    <p>7 ( 43.8)	</p>
                    <p>7 ( 43.8)	</p>
                  </td>
                  <td scope='row' >
                    <p className="SectionHeading"></p>
                    <p>9 ( 56.2)	</p>
                    <p>7 ( 43.8)	</p>
                    <p>7 ( 43.8)	</p>
                  </td>

                </tr>
              </tbody>
              <tfoot>
                <tr >
                  <td colSpan={5}>
                    Data cutoff date: 07DEC2022. N=Number of subjects in the analysis set. n=Number of subjects with observed data. SD=Standard Deviation, Q1=First Quartile, Q3=Third Quartile.S=Step Dosing. Safety analysis set includes all subjects that are enrolled an recieve at least 1 dose of AMG 509.
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
          <hr className='my-5' />
          <div className='Table-2 mt-2'>
            <p className='mainHeading text-center m-0 p-0'>Table 14-2.2.1.2.  Baseline Demographics</p>
            <p className='subHeading text-center  p-0'>(Safety Analysis Set) </p>
            <table className='table table-bordered'>
              <thead>

                <tr>
                  <th scope="col"></th>
                  <th scope="col"> Cohort 1 <br />0.001mg<br />QW<br />(N=16)<br />n(%)</th>
                  <th scope="col">Cohort 2<br />0.003mg<br />QW<br />(N=16)<br />n(%)</th>
                  <th scope="col">Cohort 3<br />0.001mg<br />QW<br />(N=17)<br />n(%)</th>
                  <th scope="col">Cohort 4<br />0.003 mg<br />QW<br />(N=14)<br />n(%)</th>
                </tr>
              </thead>
              <tbody>

                <tr>
                  <td >
                    <p className="SectionHeading">Race - n(%)</p>
                    <p >Asian</p>
                    <p>Black (or African American)</p>
                    <p>White</p>
                    <p>Other</p>
                  </td>
                  <td scope='row'  >
                    <p className="SectionHeading"></p>
                    <p>1 (  6.2)	</p>
                    <p>2 ( 12.5)	</p>
                    <p>12 ( 75.0)	</p>
                    <p>1 (  6.2)	</p>
                  </td>
                  <td scope='row'>
                    <p className="SectionHeading"></p>
                    <p>1 (  6.2)</p>
                    <p>2 ( 12.5)	</p>
                    <p>13 ( 81.2)	</p>
                    <p>1 (  6.2)	</p>
                  </td>
                  <td scope='row'>
                    <p className="SectionHeading"></p>
                    <p> 0 (  0.0)	</p>
                    <p>3 ( 17.6)	</p>
                    <p>14 ( 82.4)	</p>
                    <p> 0 (  0.0)	</p>
                  </td>
                  <td scope='row'>
                    <p className="SectionHeading"></p>
                    <p> 0 (  0.0)	</p>
                    <p> 0 (  0.0)	</p>
                    <p>14 (100.0)	</p>
                    <p> 0 (  0.0)	</p>
                  </td>
                </tr>
                <tr>
                  <td >

                    <p className="SectionHeading">Age (years)</p>
                    <p>n</p>
                    <p>Mean</p>
                    <p>SD</p>
                    <p>Median</p>
                    <p>Q1, Q3</p>
                    <p>Min, Max</p>

                  </td>

                  <td scope='row' >
                    <p className="SectionHeading"></p>
                    <p>16</p>
                    <p>49.9</p>
                    <p>18.34</p>
                    <p>49.9</p>
                    <p>35.5, 64.0</p>
                    <p>24, 75</p>
                  </td>
                  <td scope='row' >
                    <p className="SectionHeading"></p>
                    <p>16</p>
                    <p>46.6</p>
                    <p>13.48</p>
                    <p>46.6</p>
                    <p>34.8, 55.2</p>
                    <p>25, 71</p>
                  </td>
                  <td scope='row' >
                    <p className="SectionHeading"></p>
                    <p>17</p>
                    <p>53.3</p>
                    <p>14.45</p>
                    <p>53.3</p>
                    <p>49.0, 63.0</p>
                    <p>19, 70</p>
                  </td>
                  <td scope='row' >
                    <p className="SectionHeading"></p>
                    <p>14</p>
                    <p>53.9</p>
                    <p>14.94</p>
                    <p>53.9</p>
                    <p>44.8, 64.8</p>
                    <p>25, 71</p>
                  </td>
                </tr>
                <tr>
                  <td >

                    <p className="SectionHeading">Age Group - n(%)</p>
                    <p>  18-29 years</p>
                    <p>30-39 years</p>
                    <p>  50-65 years</p>
                    <p>  40-49 years</p>
                    <p> &gt; 65 years</p>
                  </td>

                  <td scope='row' >
                    <p className="SectionHeading">  </p>
                    <p>3 ( 18.8)</p>
                    <p>2 ( 12.5)</p>
                    <p>5 ( 31.2)</p>
                    <p>2 ( 12.5)</p>
                    <p>4 ( 25.0)</p>
                  </td>
                  <td scope='row' >
                    <p className="SectionHeading"></p>
                    <p>1 (  6.2)</p>
                    <p>5 ( 31.2)</p>
                    <p>5 ( 31.2)</p>
                    <p>3 ( 18.8)</p>
                    <p>2 ( 12.5)</p>
                  </td>
                  <td scope='row' >
                    <p className="SectionHeading"></p>
                    <p>2 ( 11.8)</p>
                    <p>1 (  5.9)</p>
                    <p>8 ( 47.1)</p>
                    <p>3 ( 17.6)</p>
                    <p> 3 ( 17.6)</p>
                  </td>
                  <td scope='row' >
                    <p className="SectionHeading"></p>
                    <p>2 ( 14.3)</p>
                    <p>0 (  0.0)</p>
                    <p> 6 ( 42.9)</p>
                    <p> 3 ( 21.4)</p>
                    <p>3 ( 21.4)</p>
                  </td>
                </tr>
              </tbody>
              <tfoot>
                <tr >
                  <td colSpan={5}>
                    Data cutoff date: 07DEC2022. N=Number of subjects in the analysis set. n=Number of subjects with
                    observed data. SD=Standard Deviation, Q1=First Quartile, Q3=Third Quartile.S=Step Dosing.
                    Safety analysis set includes all subjects that are enrolled an recieve at least 1 dose of AMG 509.
                  </td>
                </tr>
              </tfoot>
            </table>

          </div>
        </div>
      </CustomDialog>
    </div>
  )
}
export default Preview;