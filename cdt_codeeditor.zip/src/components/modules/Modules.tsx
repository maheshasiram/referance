import React, { useEffect, useState } from 'react';
import './styles.scss';
import DashBoard from './dashboard/DashBoard';
import Preview from './preview/Preview';
import Parametrization from './Parametrization/Parametrization';
import NavigationBar from './navBar/NavigationBar';
import KeyboardDoubleArrowRightIcon from '@mui/icons-material/KeyboardDoubleArrowRight';
import { useParams } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { fetchAllModules } from './actions/actions';
import CreateModule from './Parametrization/CreateModule';

function Modules() {
  let dispatch = useDispatch()
  const { moduleParams, modulesData } = useSelector((state: any) => state.modules)
  console.log('modules....', moduleParams, modulesData)

  useEffect(() => {
    dispatch(fetchAllModules(moduleParams))
  }, [])

  return (
    <div className='modules-main'>
      <div className='modulesRight-container' >
        <div className='dashboard-header'><h3 className='mt-1'>Modules </h3><CreateModule /></div>
        <div className='dashboard-main'><DashBoard /></div>
        <div className='parametrization-main' id='parametrization-main'> <Parametrization /></div>
      </div>
    </div>
  )
}
export default Modules;