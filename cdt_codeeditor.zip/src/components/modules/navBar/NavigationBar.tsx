import React from 'react';
import '../../../App.scss';
// import Root from './routes/Routes';
import { styled, useTheme, Theme, CSSObject } from '@mui/material/styles';
import Box from '@mui/material/Box';
import MuiDrawer from '@mui/material/Drawer';
import MuiAppBar, { AppBarProps as MuiAppBarProps } from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import List from '@mui/material/List';
import CssBaseline from '@mui/material/CssBaseline';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import InboxIcon from '@mui/icons-material/MoveToInbox';
import MailIcon from '@mui/icons-material/Mail';
import CancelPresentationIcon from '@mui/icons-material/CancelPresentation';
// import AppHeader from './components/header/AppHeader';
import newLogo from '../../../Assests/new_logo.png';
import CloseIcon from '@mui/icons-material/Close';
import DoubleArrowIcon from '@mui/icons-material/DoubleArrow';
import Root from '../../../routes/Routes';
import { NavLink, Navigate, useLocation, useParams } from 'react-router-dom';
import { privateRoutes } from '../../../constants/privateRoutes';
import CustomToolTip from '../../../common/CustomToolTip';
import { navigationRoutes } from '../../../constants/navigationRoutes';



const drawerWidth = 200;

const openedMixin = (theme: Theme): CSSObject => ({
    width: drawerWidth,
    background: '#435597',
    transition: theme.transitions.create('width', {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.enteringScreen,
    }),
    overflowX: 'hidden',
});

const closedMixin = (theme: Theme): CSSObject => ({
    transition: theme.transitions.create('width', {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: 'hidden',
    background: '#435597',
    width: `calc(${theme.spacing(7)} + 1px)`,
    // width: '0px',
    [theme.breakpoints.up('sm')]: {
        // width: '0px',
        width: `calc(${theme.spacing(8)} + 1px)`
    },
});

const DrawerHeader = styled('div')(({ theme }) => ({
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    padding: theme.spacing(0, 1),
    // necessary for content to be below app bar
    ...theme.mixins.toolbar,
}));

interface AppBarProps extends MuiAppBarProps {
    open?: boolean;
}

const AppBar = styled(MuiAppBar, {
    shouldForwardProp: (prop) => prop !== 'open',
})<AppBarProps>(({ theme, open }) => ({
    zIndex: theme.zIndex.drawer + 1,
    height: '53px',
    // background: '#455387',
    background: '#435597',
    transition: theme.transitions.create(['width', 'margin'], {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
    }),
    ...(open && {
        marginLeft: drawerWidth,
        width: `calc(100% - ${drawerWidth}px)`,
        transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.enteringScreen,
        }),
    }),
}));

const Drawer = styled(MuiDrawer, { shouldForwardProp: (prop) => prop !== 'open' })(
    ({ theme, open }) => ({
        width: drawerWidth,
        flexShrink: 0,
        // backgroundColor:'red',
        whiteSpace: 'nowrap',
        boxSizing: 'border-box',
        ...(open && {
            ...openedMixin(theme),
            '& .MuiDrawer-paper': openedMixin(theme),
        }),
        ...(!open && {
            ...closedMixin(theme),
            '& .MuiDrawer-paper': closedMixin(theme),
        }),
    }),
);


// export default function MiniDrawer() {
function NavigationBar() {
    const theme = useTheme();
    const { id } = useParams()
    let location = useLocation()
    // let _path =  matchPath("/users/123", { path: "/users/:id", exact: true, strict: false }as any)
    // console.log('params...22222.', id, useParams(), window.location, useLocation(),
    // )
    const [active, setActive] = React.useState('1')
    const [open, setOpen] = React.useState(false);
    const [moduleData, setModuleData] = React.useState([
        { label: 'IQA_Demo_1', id: 1 },
        { label: 'IQA_Demo_2', id: 2 },
        { label: 'IQA_Demo_3', id: 3 },
        { label: 'IQA_Demo_4', id: 4 },
        { label: 'IQA_Demo_5', id: 5 },
        { label: 'IQA_Demo_6', id: 6 },
        { label: 'IQA_Demo_7', id: 7 },
        { label: 'IQA_Demo_8', id: 8 },
        { label: 'IQA_Demo_9', id: 9 },
        { label: 'IQA_Demo_10', id: 10 },
    ])
    const handleDrawerOpen = () => {
        setOpen(!open);
    };

    const handleDrawerClose = () => {
        setOpen(false);
    };

    return (
        <Box className='App-navBar-main' sx={{ display: 'flex' }} >
            <CssBaseline />
            <AppBar position="fixed" className='appHeader-container'>
                <Toolbar className='appHeader-toolbar' >
                    <div className='logo-container' >
                        <div className='expand-close-Icon' >
                            <IconButton
                                color="inherit"
                                aria-label="open drawer"
                                onClick={handleDrawerOpen}
                                edge="start"
                                sx={{
                                    // marginRight: 5,
                                    // ...(open && { display: 'none' }),
                                }}
                            >
                                {open ?
                                    // <CloseIcon sx={{ stroke: '#f78c8c', strokeWidth: '1px', color: '#f78c8c', fontSize: '1.7rem' }} />
                                    <DoubleArrowIcon sx={{ stroke: '#566975', strokeWidth: '1px', color: '#566975', fontSize: '1.7rem', transform: 'rotate(180deg)' }} />
                                    : <MenuIcon sx={{ stroke: '#2d2e2e', strokeWidth: 1, color: '#2d2e2e', fontSize: '1.7rem' }} />}
                            </IconButton>
                        </div>
                        <div className='inductive-logo' >
                            <img alt="Server error" src={newLogo} />
                        </div>
                    </div>
                </Toolbar>
            </AppBar>
            <Drawer variant="permanent" open={open} className='app-drawer'>
                <DrawerHeader />
                <List className='module-list' sx={{ paddingTop: 7 }} >
                    {navigationRoutes.map((Item: any, index: any) => (
                        <React.Fragment key={Item.name} >
                            <ListItem key={Item.name} disablePadding sx={{ display: 'block' }}
                                className={`module-listItem ${(Item.navigateTo == location.pathname) ? 'active' : ''}`}>
                                <NavLink
                                    to={Item.navigateTo}
                                    style={{ textDecoration: 'none' }}
                                // onClick={() => { setActive() }}
                                >
                                    <ListItemButton
                                        sx={{
                                            minHeight: 48,
                                            justifyContent: open ? 'initial' : 'center',
                                            px: 1.5,
                                        }}
                                    >
                                        <ListItemIcon
                                            sx={{
                                                minWidth: 0,
                                                mr: open ? 3 : 'auto',
                                                justifyContent: 'center',
                                            }}
                                        >
                                            {open ? <Item.icon sx={{ color: (Item.navigateTo == location.pathname) ? '#435597' : '#fff' }} />
                                                : <CustomToolTip title={Item.name} >
                                                    <Item.icon sx={{ color: (Item.navigateTo == location.pathname) ? '#435597' : '#fff' }} />
                                                </CustomToolTip>}
                                        </ListItemIcon>
                                        <ListItemText primary={Item.name} className='listItem-Text'
                                            sx={{ opacity: open ? 1 : 0, color: '#fff' }}
                                        />
                                    </ListItemButton>
                                </NavLink>
                            </ListItem>
                            <Divider sx={{ borderColor: '#d9d9d9', opacity: 0.1 }} />
                        </React.Fragment>
                    ))}
                </List>
            </Drawer>
            <Box className='w-100' sx={{ position: 'relative' }}>
                <DrawerHeader />
                {/* {open ? <ArrowBackIosNewIcon className={'arrowIcon'} /> :
                <ArrowForwardIosIcon className={'arrowIcon'} />} */}
                <Root />
            </Box>
        </Box>
    );
}

export default NavigationBar;
