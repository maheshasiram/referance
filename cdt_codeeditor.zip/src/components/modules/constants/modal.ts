export const parameterizationModal = {
    "path": ["modules/t_dm_02_001"],
    "ColumnLables": [
        {
            "name": "column_labels",
            "default": "ARM A",
            "data_type": "character",
            "input_type": "text",
            "label": "Column Labels"
        },
        {
            "name": "column_labels",
            "default": "ARM B",
            "data_type": "character",
            "input_type": "text",
            "label": "Column Labels"
        },
        {
            "name": "column_labels",
            "default": "ARM C",
            "data_type": "character",
            "input_type": "text",
            "label": "Column Labels"
        },
        {
            "name": "column_labels",
            "default": "ARM D",
            "data_type": "character",
            "input_type": "text",
            "label": "Column Labels"
        }
    ],
    "blockVariables": [
        {
            "variable": "SEX",
            "page": 1
        },
        {
            "variable": "ETHNIC",
            "page": 1
        },
        {
            "variable": "RACE",
            "page": 1
        },
        {
            "variable": "AGE",
            "page": 2
        },
        {
            "variable": "AGEGR1",
            "page": 2
        }
    ],
    "title_vector": [
        {
            "name": "title_vct",
            "default": "Table",
            "data_type": "character",
            "input_type": "text",
            "label": "Title Vector"
        }
    ],
    "footnote_vector": [
        {
            "name": "footnote_vct",
            "default": "Footnote",
            "data_type": "character",
            "input_type": "text",
            "label": "Footnote Vector"
        }
    ]
}