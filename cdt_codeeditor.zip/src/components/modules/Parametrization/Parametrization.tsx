import React, { useState } from 'react';
import CommonCard from '../../../common/CommonCard';
import Button from '@mui/material/Button';
import { Formik, Field, FieldArray, ErrorMessage, Form } from 'formik';
import * as Yup from "yup";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import Preview from '../preview/Preview';
import { Types } from '../../../constants/Types';
import { useDispatch } from 'react-redux';
import { useSelector } from 'react-redux';
import { runModule } from '../actions/actions';

function Parametrization() {
  let dispatch = useDispatch()
  const [products, setProducts] = useState([]);
  const [selectedProducts, setSelectedProducts] = useState<any>(null);
  const [rowClick, setRowClick] = useState(true);
  const [openPreview, setOpenPreview] = useState(false);
  const { Parametrization, selectedModule } = useSelector((state: any) => state.modules)

  const pageNumberTemplate = (rowData: any, fieldData: any, values: any, setFieldValue: any) => {
    return <input type='number' className='input form-control'
      value={rowData.page}
      onChange={(event: any) => {
        let _values = [...[], ...values.blockVariables]
        console.log('_values......', _values, fieldData, event.target.value)
        _values[fieldData.rowIndex].page = event.target.value
        setFieldValue('blockVariables', _values)
      }}
    />
  }
  const onSubmitHandler = (values: any) => {
    console.log('values......', values, selectedModule)
    let payload: any = {
      "input": {
        "location": values.path,
        "prog_name": selectedModule?.Name,
        "data_dir": null,
        "output_dir": null,
        "column_labels": values.ColumnLables.map((item: any) => item.value),
        "block_vars": values.blockVariables.map((item: any) => item.variable),
        "block_pages": values.blockVariables.map((item: any) => item.page),
        "title_vct": [values.title_vector.value],
        "footnote_vct": [values.footnote_vector.value]
      }
    }
    console.log('payload........', payload.input)

    dispatch(runModule(payload))

    // setOpenPreview(true)

  }
  console.log('Parametrization........', Parametrization)
  return (
    <CommonCard title={'Parametrization'}>
      {Parametrization && <div className='Parametrization-container' >
        <Formik
          enableReinitialize={true}
          initialValues={Parametrization}
          validationSchema={Yup.object().shape({
            ColumnLables: Yup.array().of(
              Yup.object().shape({
                value: Yup.string().required('Please Enter values'), // these constraints take precedence
              })
            ),
            blockVariables: Yup.array().of(
              Yup.object().shape({
                page: Yup.string().required('Please Enter values'), // these constraints take precedence
              })
            ),
            title_vector: Yup.object().shape({
              value: Yup.string().required('Please Enter values'), // these constraints take precedence
            }),
            footnote_vector: Yup.object().shape({
              value: Yup.string().required('Please Enter values'), // these constraints take precedence
            })
          })}
          onSubmit={(values: any) => {
            onSubmitHandler(values)
          }}
        >
          {/* {({ errors, touched, values, setFieldValue, setFieldTouched, setFieldError }) => ()} */}
          {
            ({ errors, touched, values, setFieldValue }: any) => (
              <Form id='ParametrizationForm' >
                <div>
                  <div className='card' >
                    <div className='header'>Column Labels :</div>
                    <div className='d-flex body' >
                      <FieldArray
                        name="ColumnLables"
                        render={arrayHelpers => (
                          values.ColumnLables.map((item: any, index: number) => (
                            <div className='field-main' >
                              <label>{item.default}</label>
                              <Field name={`ColumnLables[${index}].value`} type={item.input_type}
                                className='input form-control'
                              // value={item.value} 
                              // onChange={() => { }}
                              />
                              <div className='text-danger' >
                                <ErrorMessage name={`ColumnLables[${index}].value`} />
                              </div>
                              {/* {(errors.armA && touched.armA) && <span className='text-danger'><ErrorMessage name={`armA`} /> </span>} */}
                            </div>
                          ))
                        )}
                      />
                      <>
                        {console.log('values......', values, errors, touched)}
                      </>
                    </div>
                  </div>
                  <div className='block-container d-flex'>
                    <div className='col-sm-6'>
                      <div>
                        <FieldArray
                          name="blockVariables"
                          render={arrayHelpers => (
                            <DataTable
                              value={values?.blockVariables}
                              selectionMode={'checkbox'}
                              selection={selectedProducts}
                              onSelectionChange={(e: any) => setSelectedProducts(e.value)}
                              dataKey="id"
                            >
                              <Column selectionMode="multiple" headerStyle={{ width: '1rem' }}></Column>
                              <Column field="variable" header="Variable"></Column>
                              <Column body={(rowData: any, fieldData: any) =>
                                <div>
                                  <Field
                                    type='number'
                                    className='input form-control'
                                    name={`blockVariables[${fieldData.rowIndex}].page`}
                                    value={rowData.page}
                                    onChange={(event: any) => {
                                      let _values = [...[], ...values.blockVariables]
                                      console.log('_values......', _values, fieldData, event.target.value)
                                      _values[fieldData.rowIndex].page = event.target.value
                                      setFieldValue('blockVariables', _values)
                                    }}
                                  />
                                  <div className='text-danger' >
                                    <ErrorMessage name={`blockVariables[${fieldData.rowIndex}].page`} />
                                  </div>
                                </div>
                              } header="Page Assignments."></Column>
                            </DataTable>
                          )}
                        />
                      </div>


                      {/* <label className='mb-2'>Block Variables :</label>
                      <DataTable
                        value={values?.blockVariables}
                        selectionMode={'checkbox'}
                        selection={selectedProducts}
                        onSelectionChange={(e: any) => setSelectedProducts(e.value)}
                        dataKey="id"
                      >
                        <Column selectionMode="multiple" headerStyle={{ width: '1rem' }}></Column>
                        <Column field="variable" header="Variable"></Column>
                        <Column body={(rowData: any, fieldData: any) => pageNumberTemplate(rowData, fieldData, values, setFieldValue)} header="Page Assignments."></Column>
                      </DataTable> */}
                    </div>
                    <div className='col-sm-6'>
                      <div className='field-main' >
                        <label>{Parametrization?.title_vector?.label}</label>
                        <Field name={'title_vector.value'}
                          className='input form-control'
                          as='textarea'
                        />
                        <div className='text-danger' >
                          <ErrorMessage name={`title_vector.value`} />
                        </div>
                        {/* {(errors.titleVector && touched.titleVector) && <span className='text-danger'><ErrorMessage name={`titleVector`} /> </span>} */}
                      </div>
                      <div className='field-main'>
                        <label>{Parametrization?.footnote_vector?.label}</label>
                        <Field name={'footnote_vector.value'}
                          as='textarea'
                          className='input form-control'
                        />
                        <div className='text-danger' >
                          <ErrorMessage name={`footnote_vector.value`} />
                        </div>
                        {/* {(errors.footNoteVector && touched.footNoteVector) && <span className='text-danger'><ErrorMessage name={`footNoteVector`} /> </span>} */}
                      </div>
                    </div>
                  </div>
                </div>
                {/* <Button type='submit' form='ParametrizationForm' variant="contained" disableElevation > Develop TLF</Button> */}
                <Preview
                  openPreview={openPreview}
                  setOpenPreview={setOpenPreview}
                />
              </Form>
            )
          }
        </Formik>
      </div>}
    </CommonCard>
  )
}
export default Parametrization;