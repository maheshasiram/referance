import React, { useState } from "react";
import CustomDialog from "../../../common/modals/CustomeDialog";
import { handleClose } from "../../../actions/actions";
import { Field, Form, Formik } from "formik";
import * as Yup from "yup";
import { Chip, FormControl, FormControlLabel, FormLabel, Switch } from "@mui/material";
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import { useDispatch } from "react-redux";
import { createModule, fetchAllModules } from "../actions/actions";
import { useSelector } from "react-redux";


function CreateModule(props: any) {

    const [openCreate, setOpenCreate] = useState(false)
    const { moduleParams, modulesData } = useSelector((state: any) => state.modules)

    let dispatch = useDispatch()
    const onAddBlockVarPages = (values: any, setFieldValue: any) => {
        let _blockVars: any = values.block_vars
        let _blockPages: any = values.block_pages
        _blockVars.default.push({ value: '' })
        _blockPages.default.push({ value: '' })
        setFieldValue('block_vars', _blockVars)
        setFieldValue('block_pages', _blockPages)
        console.log('values.....', _blockVars)
    }
    const generateLocalPath = (name: any) => {
        console.log('name.replace(/ /g,"_").......', name.replace(/ /g, "_"))
        return `modules/${name.replace(/ /g, "_")}`
    }
    const onSubmitHandler = (values: any) => {
        let payload = {
            "input": {
                "module_name": values.moduleName,
                "local_path": generateLocalPath(values.moduleName),
                "minor_version": values.version,
                "overwrite": values.overWrite,
                "push_cache": values.pushCache,
                "description": values.description,
                "keywords": values.keyWords,
                "dependancies": [
                    "dplyr",
                    "tibble",
                    "tidyr",
                    "common",
                    "fmtr",
                    "reporter"
                ],
                "parameters": [
                    values.column_labels,
                    { ...values.block_vars, default: values.block_vars.default.map((i: any) => i.value) },
                    { ...values.block_pages, default: values.block_pages.default.map((i: any) => i.value) },
                    values.title_vct,
                    values.footnote_vct
                ]
            }
        }
        dispatch(createModule(payload, (response: any) => {
            if (response) {
                console.log('payloadd........', response)
                dispatch(fetchAllModules(moduleParams))
                setOpenCreate(false)
            }
        }))
    }
    return (
        <div>
            <button className="btn-eprimary" onClick={() => setOpenCreate(true)} >Create Module</button>
            <div>
                <CustomDialog
                    title={'Create Module'}
                    open={openCreate}
                    onClose={() => handleClose(setOpenCreate)}
                    maxWidth={'md'}
                    fullWidth={true}
                    actionType={'Submit'}
                    form={'craeteModule'}
                    padding={true}
                >
                    <Formik
                        enableReinitialize={true}
                        initialValues={{
                            moduleName: '',
                            version: '',
                            overWrite: true,
                            pushCache: true,
                            description: '',
                            keyWords: ['demographics'],
                            column_labels: {
                                "name": "column_labels",
                                "default": {
                                    "ARM A": "ARM A",
                                    "ARM B": "ARM B"
                                },
                                "data_type": "character",
                                "input_type": "text",
                                "label": "",
                                "description": '',
                                "options": null
                            },
                            block_vars: {
                                "name": "block_vars",
                                "default": [
                                    { value: 'SEX' },
                                    { value: 'ETHNIC' },
                                    { value: 'RACE' }
                                ],
                                "data_type": "character",
                                "input_type": "text",
                                "label": "Variables",
                                "description": '',
                                "options": null
                            },
                            block_pages: {
                                "name": "block_pages",
                                "default": [
                                    { value: 1 },
                                    { value: 1 },
                                    { value: 2 }
                                ],
                                "data_type": "character",
                                "input_type": "text",
                                "label": "Page Assignments",
                                "description": '',
                                "options": null
                            },
                            title_vct: {
                                "name": "title_vct",
                                "default": "Table",
                                "data_type": "character",
                                "input_type": "text",
                                "label": "Title Vector",
                                "description": '',
                                "options": null
                            },
                            footnote_vct: {
                                "name": "footnote_vct",
                                "default": "Footnote",
                                "data_type": "character",
                                "input_type": "text",
                                "label": "Footnote Vector",
                                "description": '',
                                "options": null
                            },
                            columnLabelValue: '',
                            keyWordValues: '',
                        }}
                        validationSchema={Yup.object().shape({})}
                        onSubmit={(values: any) => {
                            console.log('submit................', values)
                            onSubmitHandler(values)
                        }}
                    >
                        {
                            ({ errors, touched, values, setFieldValue }: any) => (
                                <Form id='craeteModule' className="p-3">
                                    <div  >
                                        <div>
                                            <label>Module Name</label>
                                            <Field name={'moduleName'} type="text"
                                                className='input form-control'
                                            />
                                        </div>
                                        <div>
                                            <label>Version</label>
                                            <Field name={'version'} type='number'
                                                className='input form-control'
                                            />
                                        </div>
                                        <div>
                                            <div className="d-flex" >
                                                <label>OverWrite</label>
                                                <Switch name="overWrite" defaultChecked={values.overWrite} />
                                            </div>
                                            <div className="d-flex" >
                                                <label>Push Cache</label>
                                                <Switch name="pushCache" defaultChecked={values.pushCache} />
                                            </div>
                                        </div>
                                        <div>
                                            <label>Description</label>
                                            <Field name={'description'} as='textarea'
                                                className='input form-control'
                                            />
                                        </div>
                                        <div>
                                            <label>Keywords</label>
                                            <div>
                                                <div>
                                                    {values?.keyWords.map((i: any, index: number) => (
                                                        <Chip label={i} onDelete={() => {
                                                            let _arr: any = [...[], ...values.keyWords]
                                                            _arr.splice(index, 1)
                                                            setFieldValue('keyWords', _arr)
                                                        }}
                                                            sx={{ margin: '5px 5px 10px 0px' }}
                                                        />
                                                    ))}
                                                </div>
                                                <div className="d-flex align-item-center" >
                                                    <input value={values.keyWordValues}
                                                        onChange={(event: any) => {
                                                            setFieldValue('keyWordValues', event.target.value)
                                                            // event.preventDefault()
                                                        }}
                                                        onKeyDown={(event: any) => {
                                                            console.log('event......', event.key)
                                                            if (event.key == 'Enter') {
                                                                let _arr: any = [...[], ...values.keyWords]
                                                                _arr.push(values.keyWordValues)
                                                                setFieldValue('keyWords', _arr)
                                                                setFieldValue('keyWordValues', '')
                                                                event.preventDefault()
                                                            }
                                                        }} className="input form-control" />
                                                    <CheckCircleIcon
                                                        onClick={() => {
                                                            if (values.keyWordValues) {
                                                                let _arr: any = [...[], ...values.keyWords]
                                                                _arr.push(values.keyWordValues)
                                                                setFieldValue('keyWords', _arr)
                                                                setFieldValue('keyWordValues', '')
                                                            }
                                                        }}
                                                        sx={{ color: 'green' }} />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <label>Parameters</label>
                                        <div>
                                            <label className="text-danger">Column Labels</label>
                                            <div>
                                                <label>Data Type</label>
                                                <Field name={'column_labels.data_type'} as='select'
                                                    className='input form-select' disabled
                                                >
                                                    <option value="">select DataType</option>
                                                    <option value="character">character</option>
                                                </Field>
                                            </div>
                                            <div>
                                                <label>Data Type</label>
                                                <Field name={'column_labels.input_type'} as='select'
                                                    className='input form-select' disabled
                                                >
                                                    <option value="">select Input type</option>
                                                    <option value="text">text</option>
                                                </Field>
                                            </div>
                                            <div>
                                                <label>label</label>
                                                <Field name={'column_labels.label'}
                                                    className='input form-control'
                                                />
                                            </div>
                                            <div>
                                                <label>description</label>
                                                <Field name={'column_labels.description'}
                                                    className='input form-control'
                                                />
                                            </div>
                                            <div>
                                                <label>Default</label>
                                                <div>
                                                    <div>
                                                        {Object.keys(values?.column_labels?.default).map((i: any, index: number) => (
                                                            <Chip label={i} // onClick={handleClick}
                                                                onDelete={() => {
                                                                    let _obj: any = { ...{}, ...values.column_labels }
                                                                    delete _obj.default[i]
                                                                    setFieldValue('column_labels', _obj)
                                                                }}
                                                                sx={{ margin: '5px 5px 10px 0px' }}
                                                            />
                                                        ))}
                                                    </div>
                                                    <div className="d-flex align-item-center" >
                                                        <Field name="columnLabelValue"
                                                            className="input form-control"
                                                            value={values.columnLabelValue}
                                                            onChange={(event: any) => {
                                                                setFieldValue('columnLabelValue', event.target.value)
                                                                // event.preventDefault()
                                                            }}
                                                            onKeyDown={(event: any) => {
                                                                if (event.key == 'Enter') {
                                                                    let _Obj: any = { ...{}, ...values.column_labels }
                                                                    _Obj.default[values.columnLabelValue] = values.columnLabelValue
                                                                    setFieldValue('column_labels', _Obj)
                                                                    setFieldValue('columnLabelValue', '')
                                                                    event.preventDefault()
                                                                }
                                                            }}
                                                        />
                                                        <CheckCircleIcon
                                                            onClick={() => {
                                                                if (values.columnLabelValue) {
                                                                    let _Obj: any = { ...{}, ...values.column_labels }
                                                                    _Obj.default[values.columnLabelValue] = values.columnLabelValue
                                                                    setFieldValue('column_labels', _Obj)
                                                                    setFieldValue('columnLabelValue', '')
                                                                }
                                                            }}
                                                            sx={{ color: 'green' }} />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        {/* ---------------------------------------------------------------------------------------------------------------------------- */}
                                        <div className="d-flex" >
                                            <div className="col-sm-6 pe-2" >
                                                <label className="text-danger">Block variables</label>
                                                <div>
                                                    <label>Data Type</label>
                                                    <Field name={'block_vars.data_type'} as='select'
                                                        className='input form-select' disabled
                                                    >
                                                        <option value="">select DataType</option>
                                                        <option value="character">character</option>
                                                    </Field>
                                                </div>
                                                <div>
                                                    <label>Data Type</label>
                                                    <Field name={'block_vars.input_type'} as='select'
                                                        className='input form-select' disabled
                                                    >
                                                        <option value="">select Input type</option>
                                                        <option value="text">text</option>
                                                    </Field>
                                                </div>
                                                <div>
                                                    <label>label</label>
                                                    <Field name={'block_vars.label'}
                                                        className='input form-control'
                                                    />
                                                </div>
                                                <div>
                                                    <label>description</label>
                                                    <Field name={'block_vars.description'}
                                                        className='input form-control'
                                                    />
                                                </div>
                                                {/* <div>
                                                    <label>Default</label>
                                                    <div>
                                                        <div>
                                                            {Object.keys(values?.column_labels?.default).map((i: any) => (
                                                                <Chip label={i} // onClick={handleClick}
                                                                    onDelete={() => { }}
                                                                />
                                                            ))}
                                                        </div>
                                                        <div className="d-flex align-item-center" >
                                                            <input className="input form-control" />
                                                            <CheckCircleIcon sx={{ color: 'green' }} />
                                                        </div>
                                                    </div>
                                                </div> */}
                                            </div>
                                            <div className="col-sm-6 ps-2">
                                                <label className="text-danger">Block Pages</label>
                                                <div>
                                                    <label>Data Type</label>
                                                    <Field name={'block_pages.data_type'} as='select'
                                                        className='input form-select' disabled
                                                    >
                                                        <option value="">select DataType</option>
                                                        <option value="character">character</option>
                                                    </Field>
                                                </div>
                                                <div>
                                                    <label>Data Type</label>
                                                    <Field name={'block_pages.input_type'} as='select'
                                                        className='input form-select' disabled
                                                    >
                                                        <option value="">select Input type</option>
                                                        <option value="text">text</option>
                                                    </Field>
                                                </div>
                                                <div>
                                                    <label>label</label>
                                                    <Field name={'block_pages.label'}
                                                        className='input form-control'
                                                    />
                                                </div>
                                                <div>
                                                    <label>description</label>
                                                    <Field name={'block_pages.description'}
                                                        className='input form-control'
                                                    />
                                                </div>
                                                {/* <div>
                                                    <label>Default</label>
                                                    <div>
                                                        <div>
                                                            {Object.keys(values?.column_labels?.default).map((i: any) => (
                                                                <Chip label={i} // onClick={handleClick}
                                                                    onDelete={() => { }}
                                                                />
                                                            ))}
                                                        </div>
                                                        <div className="d-flex align-item-center" >
                                                            <input className="input form-control" />
                                                            <CheckCircleIcon sx={{ color: 'green' }} />
                                                        </div>
                                                    </div>
                                                </div> */}
                                            </div>
                                        </div>
                                        <div className="d-flex" >
                                            <label>Default</label>
                                            <AddCircleIcon onClick={() => onAddBlockVarPages(values, setFieldValue)} />
                                        </div>
                                        <div className="d-flex" >
                                            <div className="col-sm-6 ">
                                                {
                                                    values.block_vars.default.map((i: any, index: any) => (
                                                        <Field name={`block_vars.default[${index}].value`}
                                                            className='input form-control'
                                                        />
                                                    ))
                                                }
                                            </div>
                                            <div className="col-sm-6">
                                                {
                                                    values.block_pages.default.map((i: any, index: number) => (
                                                        <Field name={`block_pages.default[${index}].value`}
                                                            className='input form-control'
                                                        />
                                                    ))
                                                }
                                            </div>
                                        </div>
                                        {/* -------------------------------- */}
                                        <div>
                                            <label className="text-danger">Title Vector</label>
                                            <div>
                                                <label>Data Type</label>
                                                <Field name={'title_vct.data_type'} as='select'
                                                    className='input form-select' disabled
                                                >
                                                    <option value="">select DataType</option>
                                                    <option value="character">character</option>
                                                </Field>
                                            </div>
                                            <div>
                                                <label>Data Type</label>
                                                <Field name={'title_vct.input_type'} as='select'
                                                    className='input form-select' disabled
                                                >
                                                    <option value="">select Input type</option>
                                                    <option value="text">text</option>
                                                </Field>
                                            </div>
                                            <div>
                                                <label>label</label>
                                                <Field name={'title_vct.label'}
                                                    className='input form-control'
                                                />
                                            </div>
                                            <div>
                                                <label>description</label>
                                                <Field name={'title_vct.description'}
                                                    className='input form-control'
                                                />
                                            </div>
                                            <div>
                                                <label>Default</label>
                                                <Field name={'title_vct.default'}
                                                    className='input form-control'
                                                />
                                            </div>
                                        </div>
                                        {/* ------------------------------------- */}
                                        <div>
                                            <label className="text-danger">Title Vector</label>
                                            <div>
                                                <label>Data Type</label>
                                                <Field name={'title_vct.data_type'} as='select'
                                                    className='input form-select' disabled
                                                >
                                                    <option value="">select DataType</option>
                                                    <option value="character">character</option>
                                                </Field>
                                            </div>
                                            <div>
                                                <label>Data Type</label>
                                                <Field name={'title_vct.input_type'} as='select'
                                                    className='input form-select' disabled
                                                >
                                                    <option value="">select Input type</option>
                                                    <option value="text">text</option>
                                                </Field>
                                            </div>
                                            <div>
                                                <label>label</label>
                                                <Field name={'title_vct.label'}
                                                    className='input form-control'
                                                />
                                            </div>
                                            <div>
                                                <label>description</label>
                                                <Field name={'title_vct.description'}
                                                    className='input form-control'
                                                />
                                            </div>
                                            <div>
                                                <label>Default</label>
                                                <Field name={'title_vct.default'}
                                                    className='input form-control'
                                                />
                                            </div>
                                        </div>
                                        {/* ------------------------------------------------ */}
                                        <div>
                                            <label className="text-danger">Footnote Vector</label>
                                            <div>
                                                <label>Data Type</label>
                                                <Field name={'footnote_vct.data_type'} as='select'
                                                    className='input form-select' disabled
                                                >
                                                    <option value="">select DataType</option>
                                                    <option value="character">character</option>
                                                </Field>
                                            </div>
                                            <div>
                                                <label>Data Type</label>
                                                <Field name={'footnote_vct.input_type'} as='select'
                                                    className='input form-select' disabled
                                                >
                                                    <option value="">select Input type</option>
                                                    <option value="text">text</option>
                                                </Field>
                                            </div>
                                            <div>
                                                <label>label</label>
                                                <Field name={'footnote_vct.label'}
                                                    className='input form-control'
                                                />
                                            </div>
                                            <div>
                                                <label>description</label>
                                                <Field name={'footnote_vct.description'}
                                                    className='input form-control'
                                                />
                                            </div>
                                            <div>
                                                <label>Default</label>
                                                <Field name={'footnote_vct.default'}
                                                    className='input form-control'
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </Form>
                            )}
                    </Formik>
                </CustomDialog>
            </div>
        </div>
    )
}
export default CreateModule