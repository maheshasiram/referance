import React from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { clientsList } from '../../constants/clientsList';
import { NavLink } from "react-router-dom";
import { useDispatch } from 'react-redux';

function Clients() {
    const dispatch = useDispatch();

    const renderFormNames = (rowData: any) => {
        return (
            <div>
                <NavLink to={`../client/${rowData.id}`}> {rowData.protocoltitle}</NavLink>
            </div>
        )
    }

    return (
        <div>
            <div>Clients</div>
            <DataTable
                value={clientsList.data}
                paginator={clientsList?.totalRecords > 10 ? true : false}
                scrollable
                rows={8}
                selectionMode="single"
                emptyMessage="No Clients Are Available To Display."
                stripedRows={true}
            >
                <Column body={renderFormNames} field='protocoltitle' header='Protocol Title' />
                <Column field='myRole' header='Author' />
                <Column field='principalInvestigator' header='Project Manager' />
                {/* <Column field='status' header='status' /> */}
                <Column field='version' header='Version' />
                {/* <Column body={renderActions} header="Actions" /> */}
            </DataTable>
        </div>
    )
}
export default Clients;