import { DataTable } from 'primereact/datatable';
import React from 'react';
import { clientsList } from '../../constants/clientsList';
import { Column } from 'primereact/column';
import { useDispatch } from 'react-redux';
import { NavLink, useParams } from 'react-router-dom';
import { studiesList } from '../../constants/studiesList';

function Studies() {
  const dispatch = useDispatch();
  let params = useParams()
  console.log('parasms...', params);
  
  const renderFormNames = (rowData: any) => {
    return (
      <div>
        <NavLink to={`../client/${params.clientId}/${rowData.id}`}> {rowData.studyName}</NavLink>
      </div>
    )
  }

  return (
    <div>
      <div>Studies</div>
      <DataTable
        value={studiesList}
        paginator={studiesList?.length > 10 ? true : false}
        scrollable
        rows={8}
        selectionMode="single"
        emptyMessage="No Studies Are Available To Display."
        stripedRows={true}
      >
        <Column body={renderFormNames} field='studyName' header='Study Name' />
        <Column field='myRole' header='Author' />
        <Column field='principalInvestigator' header='Project Manager' />
        {/* <Column field='status' header='status' /> */}
        <Column field='version' header='Version' />
        {/* <Column body={renderActions} header="Actions" /> */}
      </DataTable>
    </div>
  )
}


export default Studies
