import React from "react";

function Figures(props:any) {
    return (
        <div>
            Figures....
        </div>
    )
}
export default Figures