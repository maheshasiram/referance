import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import InductiveLogo from './InductiveLogo'
import './styles.scss';

export default function AppHeader() {
    return (
        <Box sx={{ flexGrow: 1 }} className='header-navBar-container' >
            <div className='' >
                <AppBar position="static" className='app-header'>
                    <Toolbar className='app-bar'>
                        <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
                            <InductiveLogo />
                        </Typography>
                    </Toolbar>
                </AppBar>
            </div>
        </Box>

    )

}