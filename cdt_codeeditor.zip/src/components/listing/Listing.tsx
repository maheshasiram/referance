import React from "react";

function Listing(props:any) {
    return (
        <div>
            Listing.......
        </div>
    )
}
export default Listing