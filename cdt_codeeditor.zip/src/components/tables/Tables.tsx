import React, { useState, useEffect } from 'react';
// import CommonCard from '../../../common/CommonCard';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { InputText } from 'primereact/inputtext';
import CommonCard from '../../common/CommonCard';

interface Product {
  id: string;
  code: string;
  name: string;
  description: string;
  core: string,
  indication: string,
  Domian: string,
  status: string
}

function Tables() {
  const [products] = useState([
    {
      id: "1",
      name: "I_demo",
      description: "Baseline demography",
      core: "core",
      indication: "All",
      Domian: "ADSL",
      status: "Realse"
    },
    {
      id: "2",
      name: "I_demo-2",
      description: " demography",
      core: "core",
      indication: "All",
      Domian: "ADSL",
      status: "Realse"
    },
    {
      id: "3",
      name: "I_demo-3",
      description: " demography",
      core: "core",
      indication: "All",
      Domian: "ADSL",
      status: "Realse"
    },
    {
      id: "4",
      name: "I_demo-4",
      description: " demography",
      core: "core",
      indication: "All",
      Domian: "ADSL",
      status: "Realse"
    },
    {
      id: "5",
      name: "I_demo-5",
      description: " demography",
      core: "core",
      indication: "All",
      Domian: "ADSL",
      status: "Realse"
    },{
      id: "6",
      name: "I_demo-6",
      description: "Baseline demography",
      core: "core",
      indication: "All",
      Domian: "ADSL",
      status: "Realse"
    },
    {
      id: "7",
      name: "I_demo-7",
      description: " demography",
      core: "core",
      indication: "All",
      Domian: "ADSL",
      status: "Realse"
    },
    {
      id: "8",
      name: "I_demo-8",
      description: " Baseline demography",
      core: "core",
      indication: "All",
      Domian: "ADSL",
      status: "Realse"
    },
    {
      id: "9",
      name: "I_demo-9",
      description: " demography",
      core: "core",
      indication: "All",
      Domian: "ADSL",
      status: "Realse"
    },
    
  ]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [rowClick, setRowClick] = useState<boolean>(true);
  const [globalFilterValue, setGlobalFilterValue] = useState<string>('');

  const representativeRowFilterTemplate = (type: string) => {
    return (
      <span className="p-input-icon-left">
        <i className="pi pi-search" />
        <InputText placeholder={'search'} />
      </span>
    );
  };

  const statusBodyTemplate = (rowData: any) => {
    return (
      <span>{rowData?.status}</span>
    );
  };

  const domainBodyTemplate = (rowData: any) => {
    return (
      <span>{rowData?.Domian}</span>
    );
  };

  const indicationBodyTemplate = (rowData: any) => {
    return (
      <span>{rowData?.indication}</span>
    );
  };

  const coreBodyTemplate = (rowData: any) => {
    return (
      <span>{rowData?.core}</span>
    );
  };

  const descriptionBodyTemplate = (rowData: any) => {
    return (
      <span>{rowData?.description}</span>
    );
  };

  const nameBodyTemplate = (rowData: any) => {
    return (
      <span>{rowData?.name}</span>
    );
  };


  return (
    <CommonCard title={'List Of Tables'}>
      <DataTable value={products}
        paginator
        rows={5}
        selectionMode={rowClick ? undefined : 'radiobutton'}
        selection={selectedProduct!}
        onSelectionChange={(e:any) => {
          const value = e.value as Product;
          setSelectedProduct(value);
        }} dataKey="id" tableStyle={{ minWidth: '50rem' }}
        emptyMessage="No customers found."
        filterDisplay="row"

      >
        <Column selectionMode="single" headerStyle={{ width: '1rem' }}></Column>
        <Column filterField="name" header="Name" showFilterMenu={false}
          body={nameBodyTemplate} filter filterElement={representativeRowFilterTemplate('name')}></Column>
        <Column filterField="description" header="Description" showFilterMenu={false}
          body={descriptionBodyTemplate} filter filterElement={representativeRowFilterTemplate('description')}></Column>
        <Column filterField="core" header="core" showFilterMenu={false}
          body={coreBodyTemplate} filter filterElement={representativeRowFilterTemplate('core')}></Column>
        <Column filterField="indication" header="Indication" showFilterMenu={false}
          body={indicationBodyTemplate} filter filterElement={representativeRowFilterTemplate('indication')}></Column>
        <Column filterField="Domian" header="Domian" showFilterMenu={false}
          body={domainBodyTemplate} filter filterElement={representativeRowFilterTemplate('domian')}></Column>
        <Column header="Status" filterField="status" showFilterMenu={false}
          body={statusBodyTemplate} filter filterElement={representativeRowFilterTemplate('status')} />
      </DataTable>
    </CommonCard>
  )
}
export default Tables;