export const baseUrl = 'http://192.168.10.6:5100/iqa/v1/cdt/'; //server swagger
// export const baseUrl = 'http://10.22.242.54:5100/iqa/v1/cdt/'; // srikanth sir local
export const CodeEditorUrl = 'http://10.22.243.26:8899/api/'
export const requests = {
    module: {
        findModules: (baseUrl + 'module/find'),
        fetchModuleParams: (baseUrl + 'module/params'),
        createModule: (baseUrl + 'module/create'),
        runModule: (baseUrl + 'module/run'),
    },
    codeEditor:{
        getAllModules : (CodeEditorUrl + 'modules/getAllModules'),
        readFile : (CodeEditorUrl + 'modules/readFile'),
        writeFile : (CodeEditorUrl + 'modules/writeFile'),
        renameFile : (CodeEditorUrl + 'modules/renameFile'),
        updateFile : (CodeEditorUrl + 'modules/updateFile'),
    }
}