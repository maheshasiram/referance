import React from 'react';
import './App.scss';
import NavigationBar from './components/modules/navBar/NavigationBar';
import { useSelector } from 'react-redux';
import Loader from './common/loader/Loader';

function App() {
  const { isLoader } = useSelector((state: any) => state.application)

  return (
    <div className="App">
      <React.Suspense fallback={<div>Loading......</div>}>
        {/* { isLoader && <Loader /> } */}
        <NavigationBar />
      {/* <iframe src="http://192.168.10.114:8787" style={{ width: '100%', height: "100vh" }}></iframe> */}
      </React.Suspense>
    </div>
  );
}

export default App;