import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import './style.scss';

type Props = {
  children: JSX.Element,
  title: any
};

function CommonCard({ children, title }: Props) {

  return (
    <Card className={"card-main"} >
     { <div className='cardTitle'>
        <div className='w-100' > {title} </div>
      </div>}
      <CardContent className='card-content-div p-0'>
        <Typography component={'div'}>
          {children}
        </Typography>
      </CardContent>
    </Card>
  );
}
export default CommonCard;
