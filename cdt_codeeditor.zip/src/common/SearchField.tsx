import React from "react";
import SearchIcon from '@mui/icons-material/Search';
import CloseIcon from '@mui/icons-material/Close';
import ZoomInIcon from '@mui/icons-material/ZoomIn';

function SearchField(props: any) {
  return (
    <React.Fragment>
      <div className="search-container-common" >
        <input
          className=""
          placeholder={props.placeholder}
          value={props.value}
          disabled={props.disabled ? true : false}
          onChange={props.onChange}
          onMouseEnter={props.onMouseEnter}
          onMouseLeave={props.onMouseLeave}
          onKeyUp={props.onKeyUp? props.onKeyUp : ()=>{}}
        >
        </input>
        {props.value && <span className="del-icon"> <CloseIcon onClick={props.onClearSearch} /></span>}
        <span className="search px-1">
          <ZoomInIcon className="" />
        </span>
      </div>
    </React.Fragment>
  )
}
export default SearchField;