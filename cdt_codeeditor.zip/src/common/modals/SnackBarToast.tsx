import { Alert, Snackbar } from "@mui/material";
import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { ToastContainer, toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';

function SnackBarToast(props: any) {
  // const { addToast } = useToasts();
  const dispatch = useDispatch();
  const { isToast } = useSelector((state: any) => state.application);

  React.useEffect(() => {
    if (isToast.open) {
      (isToast.status == 1 ? toast.success : toast.error)(isToast.message)
    }
    // toast.error("kapadandi ayyaa")
  }, [isToast])

  return (
    <div>
      <ToastContainer
        position="top-right"
        autoClose={5000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="dark"
      />
    </div>
  )
}
export default SnackBarToast