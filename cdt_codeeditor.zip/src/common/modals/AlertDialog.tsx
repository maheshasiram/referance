import React from "react";
import { Dialog } from 'primereact/dialog';
import { useDispatch, useSelector } from "react-redux";
import { Types } from "../../constants/Types";


function AlertDialog(props: any) {
  const dispatch = useDispatch();
  const {modal} = useSelector((state: any) => state.application);

  const onCloseHandler = () => {
    dispatch({ type: Types.ON_CLOSE_ALERT_DIALOG, payload: { ...modal, open: false, actionType: '' } });
     modal.onCancel && modal.onCancel();
  }
  
  const onSubmit = () => {
    modal.onOk();
    onCloseHandler();
  }
  
  const renderFooter = () => {
    return (
      <div className="d-flex justify-content-end" style={{ color: '#fff' }}>
        {modal.header === 'Confirm' ?
          <React.Fragment>
            <button className="btn-eprimary " type="button" onClick={onSubmit} disabled={modal.disabled ? modal.disabled : false} >Ok</button>
            <button className="btn-esecondary" onClick={onCloseHandler} type="button">{"Cancel"}</button>
         </React.Fragment>:
          <button className="btn-esecondary" onClick={onSubmit} type="button">Ok</button>
        }
      </div>
    );
  }

  return (
      <Dialog
        header={modal.header}
        className="alert-dialog"
        footer={renderFooter}
        visible={modal.open}
        modal={true}
        onHide={onCloseHandler}
        closable={false}
      >
        <div className="d-flex justify-content-center align-items-center px-0">
          <span className="px-2 justify-content-center d-inline-flex align-items-center">
            {/* <img src={CustomDialogImg} style={{ width: '23px', margin: '6px' }} /> */}
            <span className={modal.status == 0 ? '' : (modal.status == 2 ? `text-success` : `text-danger`)} style={{ fontSize:13  }}> {modal.message}</span></span>
        </div>
      </Dialog>
  )
}

export default AlertDialog;