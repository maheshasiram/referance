
import { Types } from "../constants/Types"
import { fetch } from "../constants/fetch"
import { messages } from "../constants/messages"

export const Alert: any = (data: any) => {
  return (dispatch: any) => {
    dispatch({
      type: Types.ON_OPEN_ALERT_DIALOG,
      payload: {
        ...data,
        header: 'Alert',
        open: true
      }
    })
  }
}

export const Confirm: any = (data: any) => {
  return (dispatch: any) => {
    dispatch({
      type: Types.ON_OPEN_ALERT_DIALOG,
      payload: {
        ...data,
        header: 'Confirm',
        open: true
      }
    })
  }
}

export const Loader = (payload: any) => {
  return (dispatch: any) => {
    dispatch({ type: Types.ON_SET_LOADER, payload })
  }
}


export const toastAlert: any = (payload: any) => {
  return (dispatch: any) => {
    dispatch({
      type: Types.IS_TOAST_ENABLED,
      payload
    })
  }
}

export const errHandler: Function = (reload:any) => {
  return (dispatch: any) => {
    dispatch(Alert({
      status: 3,
      message: messages.apiError,
      onOk: () => { 
        if(reload){
          window.location.reload(); 
        }
      }
    }));
    dispatch(Loader(false));
  }
}

export const rowClassName = (rowData: any) => (rowData.status ? '' : 'rowDisabled');

export const handleClose = (setOpen: any) => {
  setOpen(false);
};




