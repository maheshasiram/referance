import { Types } from '../constants/Types';

const initialState = {
  isLoader: false,
  modal: {
    header: '',
    status: 0,
    open: false,
    message: "",
    disabled: false,
    actionType: '',
    onOk: () => { },
    onCancel: () => { },
  },
  isToast: { status: 0, message: '', open: false },
  currentUser: {
    id: 1,
    userName: "srikanth",
    role: "Admin"
  }

}

export const application = (state = initialState, action: { type: any, payload: any }) => {
  switch (action.type) {
    case Types.ON_OPEN_ALERT_DIALOG:
      return { ...state, modal: action.payload }

    case Types.ON_CLOSE_ALERT_DIALOG:
      return { ...state, modal: action.payload }

    case Types.IS_TOAST_ENABLED:
      return { ...state, isToast: action.payload }

    case Types.ON_SET_LOADER:
      return { ...state, isLoader: action.payload }
   
    default:
      return { ...state }
  }
}