import { combineReducers } from "redux";
import { application } from "./application";
import { modules } from "../components/modules/reducer/module";
import { codeEditor } from "../components/codeEditor/reducer/codeEditor";
const reducer = combineReducers({
    application,
    modules,
    codeEditor
})

export type RootState = ReturnType<typeof reducer>;

export default reducer;