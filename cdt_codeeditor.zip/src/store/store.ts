import thunk from 'redux-thunk';
import { configureStore } from '@reduxjs/toolkit';
import reducer from '../reducers';

const store = configureStore({
    reducer: reducer,
    middleware: [thunk]
})

export default store;